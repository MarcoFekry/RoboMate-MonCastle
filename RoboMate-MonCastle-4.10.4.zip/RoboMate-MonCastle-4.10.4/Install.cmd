@echo off
rem RoboMate MonCastle 4.10.4: installs to C:\RoboMate\RoboMate-MonCastle (older version files there are removed; data and configuration are kept)
net session >nul 2>&1
if errorlevel 1 (
  echo Asking for administrator rights...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
cd /d "%~dp0"
set "MCDIR=C:\RoboMate\RoboMate-MonCastle"
if not "%~1"=="" set "MCDIR=%~1"
where pwsh >nul 2>nul && (pwsh -NoProfile -ExecutionPolicy Bypass -File "%~dp0launcher\Install-MonCastle.ps1" -InstallDir "%MCDIR%" -SourceDir "%~dp0.") || (powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0launcher\Install-MonCastle.ps1" -InstallDir "%MCDIR%" -SourceDir "%~dp0.")
echo.
pause
