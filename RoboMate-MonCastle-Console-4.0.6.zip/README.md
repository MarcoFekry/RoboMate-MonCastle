# RoboMate MonCastle Console

Web console for IT operations: asset inventory, live monitoring, security auditing and remediation for
Active Directory and AD-integrated services, Windows servers and workstations, Hyper-V, VMware, failover
clusters, SQL Server, printers, network devices, Linux, containers and Kubernetes, cloud network and Entra ID / Intune.

Open it at **https://robomatemoncastle:5050**.

The console runs the PowerShell scripts from **RoboMate-MonCastle-Scripts** on demand and on schedule. It is licensed
through **RoboMate-MonCastle-Licenses**, ships its access log to **RoboMate-MonCastle-Access**, and updates itself from
**RoboMate-MonCastle-Console**.

## What's new in 4.7.4

- **Monitoring engines start off.** No monitoring engine runs until it is configured. Open an engine's **Targets** tab
  and pick *all devices of its type* (optionally only some groups), single devices, Active Directory scopes or hosts,
  and/or *Also read the engine's default scope*. Housekeeping engines and engines that read a service rather than
  machines (Intune, cloud) are configured by enabling them. **Upgrading from 4.7.3 or earlier:** engines you had
  enabled keep their schedule, but a machine engine with no targets now shows *Not configured* and skips its runs until
  you choose targets. The Engines list has a *Not configured* count and a **Configure…** button per engine.
- **Engine credentials per device or group.** On the Targets tab, *Engine credentials per device or group* sets the
  credential an engine uses for one device or a whole group. Order: engine credential for the device, for one of its
  groups, then the device's own credential, its groups' credentials and the default.
- **Engine run details and My jobs.** Each engine shows its last run (when, who started it, rows read, targets,
  unreachable hosts, errors and warnings) and a run history with a details view per run. **Actions › My jobs** lists the
  jobs you started (admins can see everyone's and the scheduled ones) with result, duration, rows, message, the full
  result and log, and **Run again**.
- **Monitoring profiles** (**Configure › Monitoring profiles**, above Sensor types). A profile bundles sensors (native,
  engine or probe, with interval and limits), options and actions for device types. Assign it to groups or devices;
  the sensors are added to every device it covers and removed when the profile or assignment goes away. Start from a
  device type, apply again after edits, and see and run the profile's actions on the device page.
- **Devices in several groups.** A device has a primary group and can also be a member of other groups (device
  settings › *Also a member of*, or `Primary;Other` in the import file). Group views, permissions, credentials and
  group-targeted jobs all count every group the device belongs to.
- **Auto-discovery detects the device type.** Found hosts are classified from SNMP, the operating system the other
  engines report, open ports, web server banners and certificates, name hints and TTL, so servers, workstations,
  domain controllers, Linux, switches, firewalls, printers, storage, cameras and phones land in the right type and
  group instead of all being network devices. Each candidate shows what it was detected from, and type and group can be
  changed before adding.
- **Software inventory** for Windows servers, workstations and Linux hosts (package manager, snap and flatpak).
- **Web server engine covers every common engine.** Windows and Linux: IIS, Apache, nginx, OpenResty, Tengine,
  LiteSpeed, lighttpd, Caddy, H2O, NGINX Unit, Tomcat, TomEE, Jetty, WildFly / JBoss, WebLogic, WebSphere / Liberty,
  GlassFish / Payara, Resin, HAProxy, Traefik, Varnish, Envoy, Apache Traffic Server, Kong, Node.js, Deno, Bun,
  Gunicorn, uWSGI, Uvicorn, PHP-FPM, Puma, Passenger, Kestrel and more. The Web server software tab filters by kind.
- **Database engine covers every engine in the catalog.** 97 engines in 13 categories: relational, distributed SQL,
  data warehouse, analytics, document, multi-model, key-value, in-memory grid, wide-column, search, time series, graph
  and vector. Every engine gets a port and answer-time check; the engine then reads it with its client (psql, mysql,
  sqlplus, mongosh, redis-cli, nodetool, cypher-shell), its REST health and version endpoints, its ODBC driver (Db2,
  Informix, SAP ASE and HANA, Teradata, Firebird, IRIS, Vertica, Exasol and more), memcached stats or its greeting. A
  missing client or driver is reported with what to install. The Databases page has tabs for *Relational & analytics*,
  *Document & key-value* and *Search, time series & graph*, each filtered by category.

## What's new in 4.7.3

- **Email notifications: SMTP Security setting.** *Settings › Notifications › SMTP* now has a **Security** choice
  instead of the old checkbox: *Auto (recommended)*, *STARTTLS* (port 587 or 25), *SSL/TLS* (port 465) and *None*
  (internal relay only). The test error `tls_validate_record_header: wrong version number` came from SSL/TLS being used
  on a STARTTLS port; Auto now detects the mode, retries the other one when they do not match and remembers what works.
  The certificate is always verified, and the password is never sent over a connection without TLS unless Security is
  *None*. **Test** saves the settings first and shows a plain message (wrong port or mode, certificate, refused,
  unknown host, timeout, authentication with a Microsoft 365 SMTP AUTH hint). After a connection failure alarm emails
  pause for five minutes and the failure is logged once, so there is no flood of errors.
- **Databases page.** New **Monitoring › Databases** with Overview, SQL Server, Relational (PostgreSQL, MySQL, MariaDB,
  Oracle), NoSQL & document (MongoDB, CouchDB, Couchbase, Redis, Cassandra, Elasticsearch and cloud document databases)
  and Cloud databases. The new *Cloud databases* engine reads Azure SQL Database, SQL Managed Instance, PostgreSQL and
  MySQL flexible servers, Cosmos DB and Redis; Amazon RDS, Aurora and DynamoDB; Cloud SQL, Spanner and Firestore;
  Oracle Autonomous Database, DB systems, MySQL HeatWave and NoSQL; Huawei RDS, GaussDB and DDS. Each cloud database is a
  device with its own sensor, and appears in Auto-discovery. Actions: start, stop, restart and fail over where the
  service supports it. The database engine also reads CouchDB and Couchbase.
- **Network page by device type.** Tabs for Overview, Switches & routers, Firewalls (including cloud firewalls), WAF,
  VPN (gateways, tunnels and clients), Wireless LAN controllers, Load balancers and Discovery. The network engine now
  classifies devices and reads vendor MIBs for Cisco, Fortinet, Palo Alto, Check Point, Juniper, Huawei, F5 and Citrix
  NetScaler: CPU, memory, sessions, VPN tunnels and users, access points and wireless clients, BGP peers, virtual
  servers and pool members.
- **Web servers page.** *Web & certificates* is now **Web servers**. A new *Web server hosts* engine reads IIS,
  Apache, nginx, Tomcat, HAProxy, Caddy, Traefik and Kestrel on Windows and Linux: service state, version, ports,
  sites, connections, requests per second, workers and a configuration test. Restart a web server from the page.
  Sites and certificates keep their tabs.
- **Temperature is a sensor, not a page.** The Temperature page is gone; temperature is offered as a sensor for every
  supported device type (servers, workstations, clusters, database servers, network and storage devices) and its
  readings are still collected.

## What's new in 4.7.2

- **Entra ID and Intune.** New engines read Microsoft Entra ID and Intune over Microsoft Graph with an app
  registration (a Cloud provider credential with provider Azure, the tenant ID, client ID and client secret):
  *Entra ID users* (state, last sign-in, MFA registration, admin roles, risk, licences, directory sync),
  *Entra ID devices* (Entra joined, hybrid joined and registered, compliance, stale devices), *Entra ID groups*,
  *Entra ID health* (directory sync, licences, app secrets and certificates that expire, failed sign-ins, risky users,
  Global Administrators, Conditional Access), *Intune managed devices* (compliance, check-in, encryption, jailbreak,
  storage) and *Intune health* (compliance policies, configuration profiles, app installs, Apple push certificate and
  tokens). The new **Monitoring › Entra ID & Intune** page has Overview, Users, Entra devices, Groups, Intune devices,
  Policies & apps and Actions & integrations. Actions: disable or enable a user, sign a user out everywhere, confirm
  compromised or dismiss risk, add or remove a group member, disable or enable a device; Intune sync, restart, remote
  lock, Defender scan and signature update, BitLocker key rotation, retire and wipe. Entra ID and Intune computers
  and phones show in Auto-discovery; a phone added from there is monitored through its Intune readings.
- **Containers and Kubernetes.** A *Kubernetes* engine reads clusters through the API (nodes, workloads, failing pods,
  pending volume claims, warning events; AKS, EKS, GKE, OKE, CCE, OpenShift, k3s) and a *Containers* engine reads Docker
  and Podman hosts over SSH. New device types *Kubernetes cluster*, *Kubernetes node* and *Container host*, and a
  **Monitoring › Containers & Kubernetes** page with tabs for clusters, nodes, workloads, failing pods, hosts and
  containers. Actions: restart or scale a workload, delete a pod, cordon or uncordon a node; start, stop, restart a
  container, read its logs, prune a host. Alertmanager alerts come in through Alert integrations.
- **Cloud firewalls, WAF and VPN.** The *Cloud network* engine reads Azure, AWS, Google Cloud, Oracle Cloud and
  Huawei Cloud: firewalls, web application firewalls, VPN gateways, tunnels and connected VPN clients. The Network
  page has new tabs *Cloud firewalls & WAF*, *VPN tunnels* and *VPN clients*. Actions: reset a VPN connection
  (Azure) or replace a tunnel (AWS), disconnect a VPN client (Azure, AWS), enable or disable a firewall rule (Google
  Cloud), switch an Azure WAF policy between Prevention and Detection.
- **More engines.** *Linux filesystems*, *Linux services* and *Linux audit* (tabs on the Linux page), *Web servers*
  and *Certificate audit* (the **Web servers** page since 4.7.3), and *Temperature*, which reads SNMP devices, BMCs over
  Redfish, Linux over SSH and Windows over WMI (a sensor on every device since 4.7.3). Each is also a sensor you can add to a
  device, so temperature can be applied to any supported device.
- **Auto-discovery from more sources.** Besides the network scan and Active Directory, candidates now come from
  workstation inventory, Hyper-V, VMware, Nutanix, OpenShift, Kubernetes, the Linux engine, SNMP network and storage
  engines, database engines, cloud network, Entra ID and Intune. *Discovery methods* on the Auto-discovery page lists
  each source with its last run and a *Run now* button.
- **No duplicate sensors on discovered devices.** A device added from Auto-discovery no longer gets a Ping or port
  check that an engine already covers (network discovery, Windows availability, the Linux engine); the template
  checks are removed once the engine reports.
- **"Manually added"** replaces "Added by you" in every view.

## What's new in 4.7.1

- **Scripts sync on their own.** There is no *Check GitHub* step any more: the console fetches and verifies the
  script library at start and every hour, retries every 5 minutes after a failure, and fetches it before a run or an
  engine task when it is not loaded yet. Remote scripting shows when it was last fetched.
- **Engines say what they need.** Monitoring engines show the system they read in a *Needs* column and on their
  General tab: AD Users needs Active Directory, the SQL engines need SQL Server, OpenShift needs the cluster API, and so on.
- **Engine targets.** Every engine that reads machines has a *Targets* tab: more AD scopes (servers, workstations,
  all computers, domain controllers, Linux computers in AD), AD groups (nested members included), OUs, workgroup
  hosts (names, addresses, ranges such as 10.0.0.10-40 or subnets up to /22, read with a chosen vault credential) and
  the devices you added, optionally only some groups. *Only these targets* replaces the default scope.
- **Linux, network and storage engines.** The Linux collector reads every Linux host (AD Linux computers, workgroup
  hosts and added Linux devices) over SSH with the vault credential per host. New *Network devices* and *Storage
  devices* engines read switches, routers, firewalls, SANs and NAS over SNMP v1/v2c (system, uptime, interfaces up and
  down, volumes and their use). Their results show on the Network page and on the Storage tab.
- **Access level for devices added by hand.** Adding a device asks for its access level: *Monitor only*
  (availability checks), *Read* (monitoring and inventory) or *Administrator* (also remote scripting and remote
  control). Change it in the device settings; imports take an *Access* column.
- **Full inventory for devices added by hand.** Every inventory collector that fits the device runs for it
  (hardware, software, roles, disks, services, events, patches, Defender, firewall, local admins, activation, OS
  updates, and IIS, file shares, printers or SQL when the server has them; packages and updates on Linux). The device page shows an *Inventory* panel with each area and its rows.
- **Remote control.** Devices with the Administrator access level get *Remote control*: Remote Desktop (a ready
  .rdp file) for Windows, SSH for Linux, network and storage devices, and the device's web interface (HTTPS or HTTP).
  The session opens in your own client with the user name of the device's credential filled in; the password is
  typed there and never leaves the console. Every session is in the access log.

## What's new in 4.7.0

- **No more nmap.** Auto-discovery, the port and vulnerability scans and every collector use the native scanner built
  into MonCastle (.NET ping sweep, TCP connects, service banners, TLS and certificate checks, SMBv1, HTTP headers).
  Nothing to install on the server.
- **Scripts run from GitHub, in memory.** By default (`scripts.cache: "memory"`) the console reads the script library
  from GitHub into memory, checks every file against the manifest's sha256 and runs it through `pwsh` from memory. No
  script is written to disk, and an older on-disk copy is removed at the next sync. The console checks GitHub at start
  and every hour. Set `scripts.cache` to `"disk"` to keep the old local cache instead. Monitoring engines fetch the
  same verified bundle from the console when a task runs.
- **Remote scripting (Actions › Remote scripting).** Replaces the script sync page. Run your own code on onboarded
  devices: PowerShell over WinRM on Windows, Bash, sh or Python 3 over SSH on Linux and appliances, and CLI lines over
  SSH on network devices. Administrators only, on every chosen device; you type a confirmation word; every run is in
  the access log with the code's sha256; WhatIf is available. The read-only library catalog is the second tab.
- **Found by engines and Manually added everywhere.** Windows servers, Virtualization, Network, Linux, Storage and Active
  Directory each start with an overview that lists both, with tabs for each source.
- **Windows servers.** A new overview tab and tabs for installed software, hardware (from system info), roles and SQL
  services, next to services and IIS. Each server shows uptime, last logged-on user, roles and SQL service state.
- **Virtualization** adds OpenShift and Nutanix next to Hyper-V and VMware, as their own tabs and as devices you can
  add (the API address of the cluster or Prism Central).
- **Active Directory reports and security.** About forty categorized reports: disabled, locked, expired, never
  logged on and inactive users, passwords not changed for N days or never expiring, inactive and deleted computers,
  deleted objects (with the Recycle Bin state), groups and membership, empty and privileged groups. A security tab
  maps the tier model (Tier 0 accounts and servers), shows tier violations from logon events and findings such as
  Kerberoastable and AS-REP roastable accounts, unconstrained delegation, adminCount orphans and the krbtgt password age.
- **Devices added by hand get inventory.** Adding a device (by hand, from auto-discovery or an import) runs the
  inventory collectors for that one device and merges its rows into the inventory, as if an engine had found it.
  *Collect inventory* on the device page runs them again. These devices are also on the resource map.
- **Audit from devices added by hand.** Inventory › Audit lists the Windows devices you added. Tick *Audited on
  schedule* to have the audit collector read their event logs with the engines' targets, or select some and *Collect
  now*. Their rows replace only their own rows in the audit data; filter the page by *Manually added*.

## What's new in 4.6.2

- **Every sensor runs directly, no engine needed.** *Add sensor* on any device offers every sensor type. For the
  Windows, Active Directory, DNS, DHCP, file server, Hyper-V, VMware, cluster, SQL, database, cloud, printer, update and
  Linux types, choose **Runs by: the probe, directly** (the default): the probe runs that type's PowerShell script for
  this one device on the sensor's own interval (CPU, memory, disk I/O, network and availability every 60 s, others
  every few minutes) and reads the result with the same rules as engine data. Types with several items per device
  (volumes, DHCP scopes, VMs, datastores, printers, buckets) take an optional *Item*, for example `C:`; empty means
  all of them in one sensor with one channel each. The device's credentials come from the vault as for engines.
  **Runs by: the engine** remains for the automatic way, where engines discover servers and roles and create these
  sensors themselves. Requirement steps on each sensor show what the chosen way needs.
- **Fixed:** opening Sensor types (or any page) while Auto-discovery was scanning jumped back to Auto-discovery. Every
  page now gets its own container, so a page's background refresh stops when you leave it.
- The Linux collector says clearly when the MonCastle server has no SSH client.

## What's new in 4.6.1

- **Add any sensor to any device, engine sensors included.** *Add sensor* on a device lists probe sensors and every
  engine sensor type (Windows, security, Active Directory, DNS, DHCP, file servers, Hyper-V, VMware, clusters, SQL,
  databases, cloud storage, printers, updates, Linux). Adding an engine sensor puts the device in that engine's target
  list, so its next run reads it. Until then the sensor shows as waiting.
- **Requirements on every sensor.** The add dialog and the sensor page list numbered steps with a status (Done, To do,
  Confirm, Note): the device address, the engine (with *Turn on and run* or *Run engine now*), the ports from the
  MonCastle server, the credential (named, never shown), the rights and PowerShell modules the engine needs, and whether
  data has arrived.
- **New menu**: **Insight** (dashboards, reports), **Configure** (overview, devices & sensors, auto-discovery, sensor
  types, notifications, alert integrations, credentials), **Monitoring** (alarms, Windows servers, Active Directory,
  virtualization, virtual machines, network, Linux, storage, security), **Inventory** (inventory, resource map, OS
  updates, compliance, audit), **Actions** (groups, actions & jobs, monitoring engines, script library) and
  **Administrate** (users & permissions, data retention, MonCastle servers, licences & access, updates, settings).
- **Found by engines / Manually added** on every Monitoring page: *Overview* is the page itself; the other two list the
  page's devices that an engine reported (for example a server found in Active Directory) and those added by hand, from
  auto-discovery or by import, with the engines that report each one.
- **One Active Directory page.** Directory tabs (domain controllers, replication, sites, AD services, Group Policy,
  users, privileged groups, computer accounts, workstations) and AD-integrated service tabs: all AD-integrated servers by
  role, DNS, DHCP, file servers, DFS, print servers, Certificate Authority, IIS, databases (SQL Server and other
  engines) and WSUS / NPS / RDS. Old links to DNS & DHCP, File servers, SQL Server and Printers open the matching tab.
- **Troubleshooting fixed.** The port test, DNS lookup and trace route now work: targets that are the MonCastle server
  itself run locally (no WinRM needed), a host that cannot be reached comes back as *Unreachable* with a WinRM hint
  instead of failing the whole run, the tests work in PowerShell on Linux, and the dialog asks for the target and port
  instead of silently testing 8.8.8.8.

## What's new in 4.6

- **HTTPS on the same port (5050).** Without a certificate in `config.tls`, the console makes its own for its names and
  addresses (kept in `data\tls\`); the setup app and launcher trust it in the local machine's Trusted Root store, so the
  browser on the server shows a normal padlock. Other PCs import `data\tls\moncastle.cer` or use a company CA
  certificate in `config.tls`.
- **Sign-in** with user name and password, an option to keep you signed in for 30 days, and the browser's own password
  manager to save the credentials.
- **Remove devices and sensors** (Devices & sensors › Select): one or many at once. Devices found by the engines go to a
  *Removed* list an administrator can restore them from.
- **Groups**: create, rename, move and delete device groups in Actions › Groups; deleting a group that still holds
  devices asks where to move them.
- **Auto-discovery** scans this machine's own networks (picked from a list) and any custom ranges, and **Clear results**
  empties the list so a new discovery starts clean.
- **One Monitoring menu** for every monitored resource (in 4.6.1 split into Configure, Monitoring, Inventory, Actions
  and Administrate; see above).
- **RMC_ scripts**: every script, task and folder uses the RMC_ prefix (scheduled tasks `\RoboMate\MonCastle\Engines\RMC_<id>`;
  older MC_ tasks are migrated when engines are installed or their schedule changes).
- **Engine notices**: a view whose data comes from an engine that is off or has not run says which engine to turn on,
  with *Turn on and run* for administrators.
- **Actions by environment** (Active Directory, Devices, Network, Linux, Storage, Virtualization, Databases, Cloud) with new
  actions: network show commands and save config, Linux reboot / user / diagnostics / network tests, Windows network info
  and tests, open or close a firewall port, Defender scan, Wake-on-LAN, shadow copies, VMware VM control.

### Virtual machines (Monitoring › Virtual machines)

One list of every VM from Hyper-V, VMware vSphere, **Red Hat OpenShift Virtualization** (KubeVirt API, bearer token in an
HTTP credential, engine `mon.openshift`) and **Nutanix AHV** (Prism Central v3 API, engine `mon.nutanix`), with power state,
guest OS, CPU, memory and host. *Add to monitoring* turns a VM into a device. **Troubleshoot** (on a VM or on any device page)
opens tasks for that item: Windows networking (current IP, routes, listening ports, ping, port, trace route, DNS lookup,
speed test, open or close a port, enable or disable the firewall), Windows data and system, Linux networking and system,
network device show commands and config backup, storage snapshots, and Hyper-V or VMware VM operations.

### Alert integrations: ingress, egress and incidents (Configure › Alert integrations)

Each direction has its own tab with what it does, what you need and the steps.

| Direction | What it does | Types |
|---|---|---|
| **Ingress** | other tools send alerts into MonCastle; each becomes a sensor | Prometheus, Grafana, Zabbix, Nagios, PRTG, SolarWinds, Datadog, Azure Monitor, CloudWatch, SCOM, generic JSON |
| **Egress** | MonCastle sends each matching state change out as an event | Webhook (JSON, optional HMAC `X-MonCastle-Signature`), Microsoft Teams (Workflows, Adaptive Card), Slack, Splunk HEC, syslog RFC 5424 (UDP, TCP, TLS) |
| **Incidents** | one ticket per alarm, opened when a sensor goes Down (optionally after a wait) and resolved when it is Up | ServiceNow (Table API), Jira Service Management, PagerDuty Events v2, Opsgenie |

Every integration chooses states and alarms (all, or any of chosen device groups, devices and sensors, optionally only some
sensor types). Tokens, passwords and webhook addresses that carry a key are stored encrypted on the console server
(`data\secrets\outbound-*.enc`) and never sent to a browser. **Test** sends a sample alarm; for incidents it opens a test
ticket and resolves it a few seconds later.

### Notifications (Configure › Notifications)

- **Rules** pick states, and alarms: all, or any of several device groups, devices and sensors, optionally limited to
  sensor types.
- **Recipients**: a single console user, a user group (every member with an e-mail address), e-mail addresses, Teams,
  Slack or a webhook. Users get an e-mail address in Administrate › Users & permissions.
- **E-mail templates**: the RoboMate default template (modern HTML for every alarm type, with a plain-text copy) or your
  own templates with `{{placeholders}}` (`{{state}}`, `{{device}}`, `{{sensor}}`, `{{group}}`, `{{message}}`, `{{time}}`,
  `{{rule}}`, `{{link}}`, `{{stateColor}}`…), a live preview, a console-wide default and a per-rule choice. Values are
  HTML-escaped, so alarm text cannot change your layout.

### Reports (Insight › Reports)

- **RoboMate reports** for each area: Monitoring and availability, Inventory, Auditing and security, Actions and jobs,
  Monitoring engines. Live data, printable, *Print / PDF* and *Data (CSV)*.
- **My reports**: build your own report from items: headings and notes, sensor status, alarms, device tiles, sensor graphs,
  gauges, top-N metrics, sensor metrics tables (pick a sensor type and its channels), and numbers, charts and tables from any
  data set (sensors by type, devices, alarm history, engines, job runs, console audit, and everything the engines collect).
  Save, share, duplicate, or start from *Customise a copy* of a RoboMate report.
- **Data explorer**: the single-table report builder from earlier versions.

## Quick start

Requirements on the console server:

- Windows Server 2019+ or Windows 10/11
- Node.js 18 or newer
- PowerShell 7 (`pwsh`)
- RSAT (AD, DHCP, Failover Clustering, Hyper-V)
- `dbatools` for SQL
- `VMware.PowerCLI` if you use vCenter

```powershell
# 1. unpack to D:\RoboMate-MonCastle (or anywhere)
# 2. start
.\launcher\Start-MonCastle.cmd
```

The launcher does the following:

1. Checks the prerequisites.
2. Creates `config\moncastle.config.json` from the example on first run.
3. Asks for the administrator override password if none is set yet.
4. Adds `robomatemoncastle` to the hosts file, which needs one elevation prompt.
5. Starts the server on port 5050 and opens http://robomatemoncastle:5050.

**Other PCs** need the name too. Add a DNS A record `robomatemoncastle` pointing at the console server's IP, or a hosts
file entry. Then open http://robomatemoncastle:5050. Allow TCP 5050 inbound in Windows Firewall on the server:

```powershell
New-NetFirewallRule -DisplayName 'RoboMate MonCastle 5050' -Direction Inbound -Protocol TCP -LocalPort 5050 -Action Allow
```

`launcher\Start-MonCastle-Demo.cmd` starts the console with generated data, so you can look around without a licence or PowerShell.

Run it as a background service (starts at boot, restarts on failure):

```powershell
.\launcher\Install-MonCastleService.ps1 -Account 'CORP\svc-moncastle$'
```

## Run from Visual Studio (graphical launcher)

`RoboMate-MonCastle.sln` holds the **MonCastle launcher**, a Windows Forms app in `host\` (.NET 8). It opens in Visual Studio 2022 with the ".NET desktop development" workload. The console's server, web and launcher files appear under the project for editing.

1. Install Node.js 18 or later (LTS from nodejs.org).
2. Open `RoboMate-MonCastle.sln` and press **F5**.
3. The launcher window opens and starts the server. When the server is up, the launcher opens http://robomatemoncastle:5050 in your browser.

The launcher follows the Windows light or dark theme (or the one you pick) and has a sidebar with:
- **Overview**: the server state with Start, Stop and Open console, and tiles for mode, port, node, address, uptime and installation, plus quick actions (hosts entry, logs folder, run setup);
- **Monitoring engines**: install, enable, disable, start, stop and restart the engines (see below);
- **MonCastle servers**: this server's role, and Join or Leave a multi-server infrastructure (the join code is typed into a masked box and passed to the server through the environment);
- **Server log**: the live output with a filter, errors in red, and a badge that counts new errors while you are on another page;
- **Settings**: mode, port, start automatically, open the browser, minimise to the tray, start with Windows, theme.

Closing the launcher stops the server, unless "minimise to the tray" is on: then it keeps running in the notification area. Settings are kept per user in `%LOCALAPPDATA%\RoboMate\MonCastle\launcher.json`, and the launcher's own log is `data\logs\launcher.log`.

To use the launcher without Visual Studio, publish it into the app folder: `dotnet publish host -c Release -o launcher\app`, then start `launcher\app\RoboMate.MonCastle.Launcher.exe`. It finds the app folder by itself.

### The user package (Build › Publish › UserPackage)

The release you give to users has no development sources. In Visual Studio choose **Build › Publish**, pick the
**UserPackage** profile and press **Publish** (or run `dotnet publish host -p:PublishProfile=UserPackage`). Visual Studio
publishes the launcher as one self-contained exe, then `tools\build-release.js` writes
`dist\package\RoboMate-MonCastle-<version>\` and a `.zip` of it:

| File | What it is |
|---|---|
| `RoboMate.MonCastle.Launcher.exe` | the launcher, no .NET install needed |
| `MonCastle-Setup.exe` | the setup app: prerequisites, service, firewall, licence (see below) |
| `runtime\node.exe` | the Node.js runtime, no Node.js install needed |
| `app.mcpak` | the console (server and web files), compressed and encrypted with AES-256-GCM |
| `moncastle.js` | the loader: checks `app.mcpak` (SHA-256 and GCM tag), decrypts it in memory and starts the console |
| `engine\`, `launcher\` | the PowerShell wrappers Windows runs directly (scheduled-task engines, service, join, override) |

Nothing from `app.mcpak` is written to disk, and a changed or damaged `app.mcpak` refuses to start. Honest limit: the
package key travels with the package (split inside `moncastle.js`), so this stops casual reading, copying and editing,
not a determined person with a debugger. The collector scripts are synced from the scripts repository into
`data\scripts` and are read by PowerShell as plain text; they are verified against the manifest's SHA-256 before every run.

### The setup app (MonCastle-Setup.exe)

The user package also holds **MonCastle-Setup.exe** (project `installer\`, built by the UserPackage publish). Run it as
administrator from the package folder. It is a wizard:

1. **Location**: install folder (default `C:\Program Files\RoboMate\MonCastle`) and port. Data and config are kept when you install over an existing copy.
2. **Prerequisites**: setup checks what is already there and installs what you tick: PowerShell 7, RSAT (AD, DNS, DHCP, Group Policy), Print Management, Hyper-V and Failover Clustering tools, WinRM, SecretManagement, dbatools, SqlServer, VMware PowerCLI and database clients.
3. **Service and role**: run as LocalSystem, a gMSA or a named account; standalone, or join an existing MonCastle infrastructure with a join code.
4. **Security and licence**: the admin override password (stored only as a salted hash) and the licence key (MonCastle serials starting with `320RMC` only).
5. **Install**: firewall rule, hosts entry, the background service, Start menu shortcuts and an Apps & features entry, then a check that the console answers.

Passwords, keys and join codes are handed to the install script in environment variables, never on a command line or in a log.
Unattended: `MonCastle-Setup.exe /quiet /dir=D:\MonCastle /port=5050 /components=PowerShell7,RSAT` with the secrets in
`MC_OVERRIDE_PASSWORD`, `MC_LICENSE_KEY`, `MC_JOIN` and `MC_SETUP_SVC_PASSWORD`. `MonCastle-Setup.exe /uninstall` removes it
(add the data option in the wizard to delete the data folder too). The same steps can be run with
`launcher\Install-MonCastle.ps1` (`-CheckOnly` lists the prerequisites).

In VS Code, open the folder and use the **MonCastle (live)** or **MonCastle (demo)** launch configuration. That route also lets you debug the JavaScript.

## Monitoring engines

Each collector is a **monitoring engine** that you switch on and off, schedule and run on demand.

- On Windows, the engines are installed as scheduled tasks under `\RoboMate\MonCastle\Engines\`, one task per collector named `RMC_<id>`. Each task runs `engine\Invoke-MCEngine.ps1 -Id <id>` with PowerShell 7 on the engine's interval.
- Monitoring keeps running when the console and the launcher are closed. Results wait in `data\inbox` and the console imports them within 10 seconds of starting.
- Every engine checks the collector's SHA-256 before it runs. Engines pause if the console has not confirmed a valid licence in the last 72 hours.
- Engines that are not installed as tasks run in the console's own scheduler while the console is running. This also covers non-Windows hosts.

**Controls.** Both the launcher's **Monitoring engines** tab and the console's **Act > Monitoring engines** page have the same controls. For one engine you can Start (run now), Stop, Restart, Enable, Disable and set the Interval. For all engines you can Enable all, Disable all, Stop all and Restart all, plus Install and Remove. Changing tasks needs administrator rights. The launcher can restart itself as administrator.

**Running as another account.** Install the engines as SYSTEM, or as a service account that can query your servers. The launcher asks for the account's password and passes it only to Task Scheduler. Credentials saved with `Set-MCCredential` (vCenter, Linux, workgroup hosts) must be saved while running as that same account.

**Command line.** `engine\MonCastle-Engines.ps1 -Action List|Install|Uninstall|Enable|Disable|Start|Stop|Restart|SetInterval [-Id <id>|All] [-Every 15m]`. Its log is `data\logs\engines.log`.

## Monitoring like PRTG (Configure and Monitoring menus)

MonCastle monitors the way PRTG does: **probe › groups › devices › sensors › channels**.

- **Devices & sensors** shows the tree with a coloured chip per sensor (Down red, acknowledged orange, Warning yellow, Up green, Paused blue, Unknown grey), filters by state, a tiles view, and the global status counters at the top of every page.
- **Sensor page**: last value, message, channels with their limits, live (2 h), 2-day and 30-day graphs with the limit lines, uptime and downtime, state log. Scan now, pause (1 h to forever), acknowledge an alarm with a note, change the name, interval, parameters and per-channel limits (warning/error above/below).
- **Alarms**: everything Down, Warning or Unknown, acknowledge and rescan from the list, plus the state log of every change.
- **Connectors** are the sensor types. **Probe sensors** run inside the console: Ping, TCP port, HTTP(S) with keyword check, DNS query, SSL certificate expiry, SNMP v1/v2c/v3 uptime, SNMP interface traffic (64-bit counters), SNMP custom OID and PowerShell script. **Engine sensors** are built from what the monitoring engines collect: CPU, memory, disks, disk I/O, network, availability, services, IIS, activation, Defender, updates, firewall, domain controllers, AD replication, accounts, computers, AD security events, Group Policy, DNS servers, DHCP scopes, file servers, file access audit, event log errors, Hyper-V hosts and VMs, VMware hosts, datastores and VMs, clusters and CSVs, SQL Server, printers and Linux over SSH.
- **Auto-discovery** lists devices found by the network discovery and AD engines and by range scans (TCP sweep of 22, 80, 135, 443, 445, 3389, 5985, 9100 plus SNMP and reverse DNS, up to a /22). Adding a device applies the template for its type (servers: ping, RDP, WinRM; switches and firewalls: ping, SNMP uptime and traffic, HTTPS and certificate; printers: ping and SNMP; Linux: ping and SSH; websites: HTTP and certificate).
- **Notifications**: rules pick the states (Down, Warning, Unknown, Up), a group, an optional delay that is cancelled if the sensor recovers, and targets: e-mail (SMTP with STARTTLS or TLS; the password is stored encrypted in `data\secrets\smtp.enc`), Microsoft Teams, Slack or a JSON webhook. Acknowledged alarms stay quiet.
- **Device page**: all sensors of the device, pause or scan the whole device, add probe or engine sensors (each with its requirement steps), and **client actions**: event viewer, live view, top processes, sessions, TCP connections, large files, system info (read-only); services, stop process, client maintenance (gpupdate, DNS flush and register, time sync, spooler reset, temp cleanup, update scan, Defender scan and signatures, Configuration Manager policy), sessions, scheduled tasks, Windows Update, RDP; and the high-risk power, firewall, isolation, local admin password and software removal actions, which ask you to type the device name.

Readers can look; contributors can also pause, resume, scan, acknowledge and change devices, sensors and limits in their device groups; administrators also manage groups, discovery and notifications. Every change goes to the access log. Without a valid licence the probe stops and the console shows the last states. Monitoring data lives in `data\monitor\` (config.json, state.json, history.json, log.json).

**File server audit.** The file sets of `aud.events` (FileModify 4663, FileDelete 4660, FilePermission 4670) need the "Audit File System" policy for success events and a SACL (auditing entry) on the shared folders. FileAccess (5145) needs "Audit Detailed File Share".

## Adding a device: access credentials and monitoring options

**Add device** is a three-step wizard:

1. **Device**: name, DNS name or IP, type (Windows server or workstation, Linux, switch/router/firewall, printer, appliance, VMware, SQL Server, cluster, website) and group.
2. **Access**: for every sign-in method the type supports (Windows WinRM/WMI, SSH password or key, SNMP v1/v2c, SNMP v3 with SHA/SHA-256/MD5 and AES/AES-256, VMware, HTTP Basic/Bearer/API key, SQL login or integrated) you **inherit** the credential from the device group or the probe default, **pick a saved one**, or **enter a new one**. A new one is either **saved to the console** for other devices or kept **private** to this device.
3. **Monitoring**: every option for that type, by area, with sensible defaults; select all or only some. Availability (ping, uptime, management ports, TCP checks, SNMP restarts), Performance (CPU, memory, disk I/O, network traffic, storage by volume, top processes, SNMP interface traffic per interface number, SNMP CPU, printer toner), Services (Windows services, sessions), Logs (System and Application event logs, Security log, file access audit), Inventory (software, hardware), Security (updates, Defender, firewall, activation), Roles (domain controller, DNS, DHCP, file server, IIS, SQL, Hyper-V, cluster, VMware), Web (HTTP, SSL certificate) and Linux over SSH. Probe options become sensors at once; engine options add the device to that engine's targets (`MC_EXTRA_TARGETS`).

The device **Settings** dialog has the same Access and Monitoring tabs, so you can change them later.

## Several MonCastle servers (Administrate › MonCastle servers)

One console manages any number of MonCastle servers. The server you sign in to is the **central console**: it keeps the
devices, sensors, credentials, alarms, history and reports. **Remote MonCastle servers** sit at branch offices, in other
networks or behind firewalls and do the probing and engine runs for the devices assigned to them.

1. On the central console: Administrate › MonCastle servers › **Add MonCastle server**. Enter the computer name and site and
   copy the one-time join code (it holds the server's secret; treat it like a password).
2. Install MonCastle on the remote server, then run `launcher\Join-MonCastleServer.ps1` and paste the code
   (or set `MC_JOIN` and run `node server\index.js` once). Start MonCastle there as usual.
3. The server checks in every 30 seconds and shows its CPU, memory, disk, engines and 24-hour history.
4. Choose the server for each device in the add-device wizard or the device settings (**Monitored by** lists every
   server with its current load), or move several devices at once on a server's page.

The remote server calls `POST /api/infra/sync` on the central console. Each call is signed with HMAC-SHA256 over the body
and a timestamp (5-minute window, replays refused); the credentials in the answer are encrypted with AES-256-GCM under a
key derived from that server's secret. Engines on the central console skip devices that a remote server collects
(`MC_EXCLUDE_TARGETS`), and a remote server's engines collect only their assigned targets (`MC_TARGETS_ONLY`). A remote
server keeps working for 72 hours without reaching the central console, then pauses until it can sync again. Removing a
server needs its devices moved first; **New join code** replaces the secret at once.

## Credentials (Configure › Credentials)

- Saved credentials are listed by method with where they are assigned (probe default, device groups, devices), who may use them, the devices that use them, last use and the last **Test** (SNMP and HTTP really sign in; Windows, SSH, VMware and SQL check that the service answers).
- **Resolution order** (like PRTG): the credential set on the device, then one assigned to the device, then its group and parent groups, then the probe default. "Which credential does a device use?" shows the answer per method.
- **Who may use one**: a minimum role, or only members of chosen user groups, or private to its creator. Contributors can save credentials and assign them to groups they contribute to; only administrators set probe defaults.
- **Secrets** live only in the AES-256-GCM secure store (`data\secrets\cred-<id>.enc`). `data\credentials.json` holds names, kinds and non-secret fields. Browsers never receive a secret, not even administrators.
- **Engines** get the credentials of their targets in the `MC_CREDS` environment variable (never on a command line or in a log). `Invoke-MCRemote` groups targets by credential automatically; `Get-MCDeviceCredential -ComputerName X -Kind windows|ssh|vmware|sql` returns one; `Get-MCCredential -Name` also finds credentials saved in the console. Windows task engines fetch the same context from the local console with the token in `data\secrets\engine.token` (loopback only).

## Users and permissions (Administrate › Users & permissions)

- **Roles**: `reader` (look, read-only tools), `contributor` (also change devices and sensors, use saved credentials, run low and medium risk actions, share dashboards and reports), `admin` (everything, plus users, credentials, licences, engines and updates). Users from 4.0 keep their access: viewer becomes reader, operator becomes contributor.
- **User groups** grant a role on chosen device groups (or all of them), like PRTG's group permissions. A user's role on a device is the highest of their console role and every grant that covers the device's group or a parent group.
- **Restricted users** see only the device groups their user groups grant, everywhere: tree, alarms, sensors, logs, actions.
- **Actions** need the role on every target device; high-risk actions need admin.
- **Permission matrix** and **Effective access** (per user, per device group, with where the role comes from) are on the same page.

## Dashboards and reports (Insight menu)

- **Dashboards**: ten built-in ones (Operations, Servers, Storage, Network, Active Directory, Security, Virtualization, Linux, Workstations, Printers and SQL). **Customise a copy** or start a **New dashboard** and add widgets: sensor status, gauges, top-N bars, fullest volumes, sensor graph, alarms, device tiles, a number (count, sum, average, max, min of any data set with filters), charts (bars, donut, columns) and tables, or a saved report. Widgets can be moved and set to one, two or three columns wide. Dashboards refresh every 30 seconds.
- **Reports**: pick the sensors (all or one type, with every channel and uptime) or any data set, add filters (is, contains, greater/less than, yes/no, empty, within/older than N days), group with count/sum/average/max/min, choose columns or a chart, then **Save** (private or shared), export **CSV** or **Print / PDF**. Seven templates to start from.
- Saved dashboards and reports live in `data\insights.json`. Readers keep theirs private; contributors and admins can share.

## Groups (Actions › Groups)

Every device sits in a group. The Groups page shows a health map of all groups, then one card per group with its
device tiles coloured by state, sensor states and top issues; click a group for its own page. **Alarms › By group** shows the
same groups with the alarms and errors open on each resource under them.

## Compliance (Inventory › Compliance)

Pick one standard or all common ones (CIS Controls v8, CIS Windows Server 2022, CIS network devices, NIST SP 800-53,
NIST CSF 2.0, ISO 27001, PCI DSS 4.0, HIPAA, SOC 2, Essential Eight, GDPR Article 32) and all devices, a group or one device. Each control is checked
automatically from what MonCastle collects (security, patching, Defender, firewall, AD, SQL, databases, cloud storage,
Linux, network, sensors and credentials) or marked manual when it needs documents or interviews. Export CSV or print.

## Data retention and archives (Administrate › Data retention)

Each sensor can keep its own history period; otherwise the system-wide policy applies, which also covers the alarm log,
the access log and engine runs. Data that leaves the live store is archived, not deleted: archive folder (local or UNC),
how many months to keep, a size cap (oldest months go first), daily or weekly dataset snapshots, and the time of the
nightly run. Archives are encrypted with the installation's key and can be browsed, filtered and exported to CSV from the
same page whenever needed.

## Cloud storage

Add a device with the Azure, AWS, Google Cloud, Oracle Cloud or Huawei Cloud profile and a **Cloud** credential
(tenant/access key/service account/OCI key/AK-SK; secrets stay in the secure store). The `mon.cloud.storage` collector
lists accounts and buckets with size, objects, 24 h growth, versioning, encryption, public access, replication and
lifecycle; buckets become sensors, and compliance checks flag public or unencrypted buckets. Read-only rights are enough.

## Databases

Database profiles cover SQL Server, Oracle, PostgreSQL, MySQL, MariaDB, MongoDB, Redis, Elasticsearch, Cassandra,
CouchDB, InfluxDB, ClickHouse, Neo4j, Db2 and SAP HANA. The **Database service** sensor speaks each engine's own
protocol (login, TLS offered, version, role) with a **Database** credential, and the `mon.databases` collector adds
connections, size, replication lag, cache hit ratio, slow queries and last backup. Investigation steps suggest the fix
for access, authentication, certificate and connectivity faults.

## Active Directory (Monitoring › Active Directory)

AD-integrated services have their own tabs on the same page: all AD-integrated servers by role, DNS, DHCP, file servers, DFS, print servers, Certificate Authority, IIS, databases and WSUS / NPS / RDS.

Domain controllers, **Replication** (matrix, lag per DC, links per partition), **Sites and site links** (topology map with cost and interval, sites without a DC, subnets in no site; new collector `mon.ad.sites`), **AD services** (NTDS, DNS, DFSR, Netlogon, KDC, Intersite Messaging, Time, ADWS per DC, SYSVOL/NETLOGON shares, time offset, FSMO holders), **Group Policy** (version mismatches, unlinked, empty and disabled GPOs, links per OU, run gpupdate), users, privileged groups, computer accounts and **Workstations** (inventory joined with AD: OS, out-of-support OS, TPM, memory, uptime, per site, gpupdate per machine).

## Product name and browser tab

The console calls itself **RoboMate MonCastle** everywhere: each page's browser title reads "Page - RoboMate MonCastle"
(for example "Network - RoboMate MonCastle"), and the web app manifest lets browsers install it as an app. The launcher opens
the console in the default browser as a normal tab at `http://robomatemoncastle:5050`; the first time, it offers to add
the `robomatemoncastle` host name to the hosts file and otherwise uses `robomatemoncastle.localhost`, so the address never
shows `localhost`.

## Bulk device import (Configure › Devices & sensors › Import devices)

Download the template, fill one device per line with **Name, Type, IP** (IP address or DNS name), and optionally Group,
Model and Server, then open the CSV or paste the cells. Type accepts any device type (Windows server, Linux server, switch
or router, firewall, SAN, NAS, UPS, ESXi, database …), a model name, or common words. **Check** shows each line's result
before anything is added; duplicates by name or address are skipped.

## Inventory (Inventory › Inventory)

Every monitored resource is listed, whatever its kind: Windows servers and workstations, Linux, network (switches,
routers, firewalls, wireless, load balancers), storage (SAN, NAS, FC switches, backup), power and hardware, virtualization,
databases, cloud storage and printers, joined with what the collectors know (model, OS, serial, CPU, memory, firmware).
Tabs per category; export CSV.

## Alert integrations (Configure › Alert integrations)

MonCastle receives alerts from other monitoring systems: Prometheus Alertmanager, Grafana, Zabbix, Nagios / Icinga, PRTG,
SolarWinds, Datadog, Azure Monitor, AWS CloudWatch (SNS), SCOM, LibreNMS, Elastic and any system that can send a JSON
webhook. Add an integration to get its URL and token (the token is shown once and stored only as a hash), follow the setup
guide for that system, and press **Send test**. Each alert becomes an external-alert sensor on the matching device (by
host or name) or on a new device in the integration's group; resolved alerts clear the sensor. The ingest URL is
`/api/ingest/<id>` with the token as a Bearer header, `X-MonCastle-Token` or `?token=`.

## OS updates (Inventory › OS updates)

The `mon.os.updates` collector reads each Windows machine's build and update revision, pending and security updates,
WSUS and restart state, and each Linux server's release, point release and pending (security) packages over SSH. Once a
day the console checks Microsoft's Windows release information and endoflife.date for the newest build or point release
of every release and its support end; without internet access it compares machines with the newest build in the fleet.
Machines show OK, Warning (behind, updates waiting, restart pending, support ending in 6 months) or Critical (out of
support, security updates waiting for more than 30 days, or nothing installed for 60 days). **Check online now** refreshes
the release list.

## Actions and scheduled jobs (Actions › Actions & jobs)

**Actions** lists every action and tool by resource (Active Directory, servers, network, Linux, storage, virtualization,
databases). Each card says which device kinds it works on, which account it runs as and the rights that account needs.
New in 4.5: AD user account (unlock, enable, disable, must change password), stale AD accounts (report, disable, move),
AD group membership, AD replication sync, Group Policy refresh, network configuration backup (versioned, with changes and
secrets masked), switch port shut / no shut, Linux updates (security only or all, restart if needed), Linux service, Linux
disk cleanup, storage volume snapshots (NetApp ONTAP and Pure FlashArray REST, with pruning) and Windows disk cleanup.

**Scheduled jobs** run an action on its own: every N minutes, hours or days, daily, weekly or monthly at set times, or once,
optionally between start and end dates. A job runs on all matching devices, on device groups (subgroups and devices added
later are included) or on chosen devices; only device kinds the action supports are used. Each job can run as a chosen
credential (for example a patching service account) instead of the credential assigned to each device. Options: WhatIf
(preview only), turned on or paused, and an e-mail address or webhook to tell when a run fails. High-risk actions need an
explicit "run without asking" tick. Administrators create and change jobs; everyone sees them, their next run and the run
history with each run's output. Every change and run is in the access log. Times are the MonCastle server's local time.

## Licence

- A licence key (the MonCastle serial) looks like `320RMC11AB…`: `320RMC` followed directly by the rest of the key, with no underscore. Keys written as `320RMC_…` by earlier builds still work. Only these keys are accepted when a licence is activated, replaced or registered; a raw GitHub token is refused. Internally the key maps to the GitHub access token that reads the licence repository.
- The token needs these permissions:

  | Repository | Contents |
  |---|---|
  | RoboMate-MonCastle-Licenses | Read |
  | RoboMate-MonCastle-Scripts | Read |
  | RoboMate-MonCastle-Console | Read |
  | RoboMate-MonCastle-Access | Read and write |

- **The console does not open without a valid licence.** The only exception is the **administrator override password**. It exists so an administrator can enter a new key or recover from an expired one, and every use is logged. Set it with `launcher\Set-MonCastleAdminPassword.ps1`. Only a salted scrypt hash is stored, in `data\secrets\override.json`.
- The key is stored AES-256-GCM encrypted (`data\secrets`). It is displayed as `320RMC••••••••abcd` and never written to logs. Administrators can reveal it on **Licences & access**.
- Revalidation runs every 6 hours, with 72 hours of grace when GitHub is unreachable. After that the console is read-only. Nothing is ever deleted.
- **Licence administration** (admins), under Licences & access:
  - issue a key from a token;
  - see all registered licences with holder, edition, expiry, node limit and fingerprint;
  - revoke or extend them;
  - download `licenses.json`, then upload it to the Licenses repo.

  The registry format is in `repo-templates/RoboMate-MonCastle-Licenses`.

## Updates and releases

**Publish (build machine, admin):** go to **Updates & releases > Publish a release**.
1. Pick the version and notes.
2. The console zips the app from `D:\RoboMate-MonCastle` into `C:\robomate\RoboMate-MonCastle-Console`, writing `version.json`, `CHANGELOG.md` and `releases\RoboMate-MonCastle-Console-<v>.zip`. These paths are configurable in `release`.
3. Upload those files to `RoboMate-MonCastle-Console`.

**Update (every console):** the console checks `version.json` every 12 hours with its licence key.
1. An admin clicks **Install** and types the version to confirm.
2. The package is verified against its SHA-256 and the current version is backed up to `data\backups`.
3. Files are replaced. The `data` folder and the config file are kept.
4. The console restarts.

## Configuration (`config\moncastle.config.json`)

| Key | Default | |
|---|---|---|
| `port` / `publicName` | `5050` / `robomatemoncastle` | URL shown and opened by the launcher |
| `mode` | `live` | `demo` serves generated data |
| `github.*` | MarcoFekry repos, `main` | Scripts, Licenses, Access, Console |
| `scripts.source` | `github` | `local` + `localPath` to run from a folder (development) |
| `scripts.syncEveryHours` | `12` | Pulls manifest + changed files, verifies SHA-256 |
| `release.sourceDir` / `outputDir` | `D:\RoboMate-MonCastle` / `C:\robomate\RoboMate-MonCastle-Console` | Publish paths |
| `tls.cert` / `tls.key` | none | PEM files to serve HTTPS |
| `accessLog.batchMinutes` / `batchSize` | `5` / `50` | Push cadence to the Access repo |

## Security model

- **Licence:** no licence means no access; the administrator override is the only exception.
- **Roles:** `reader`, `contributor` and `admin`, plus user groups that grant a role on device groups and restricted users (see Users and permissions).
- **Data at rest:** every file the console writes under `data\` (datasets, monitoring configuration, state and history, users, credential index, engine history, infrastructure, dashboards, schedules and each access-log line) is encrypted with AES-256-GCM under a key derived from `data\secrets\master.key` (or `MC_MASTER_KEY`, which keeps the key off the disk). Files from older versions are encrypted at the first start. The data is read only through the console. An administrator of the server who can read the key can still decrypt it, so limit the folder to the service account and keep the key out of backups.
- **Device credentials:** secrets only in the encrypted secure store, never sent to browsers, passed to engines in `MC_CREDS` only.
- **High-risk actions:** they need an administrator, and the target name must be typed to confirm. WhatIf preview is on by default.
- **Running scripts:**
  - Only scripts listed in the synced manifest can run, and only if their SHA-256 matches.
  - Parameters are validated against each script's `param()` block: types, allowed values, patterns and ranges.
  - PowerShell starts without a shell. Parameters go in `MC_PARAMS`, secrets in `MC_SECRET_*`.
- **Accounts and sessions:**
  - Passwords are stored as scrypt hashes.
  - Session cookies are `HttpOnly; SameSite=Strict`.
  - Sign-in is rate limited.
  - Every write request needs the `X-MC-Request` header.
  - Responses carry a strict CSP.
- **Access log:** every sign-in, override, run, licence, release and update event goes to the local log and to RoboMate-MonCastle-Access, with tokens masked.

## Layout

```
launcher/          Start-MonCastle(.cmd/.ps1), demo launcher, service installer, override password tool
host/              MonCastle launcher (Windows Forms, .NET 8), opened by RoboMate-MonCastle.sln
engine/            monitoring engines: MonCastle-Engines.ps1 (task control), Invoke-MCEngine.ps1 (what each task runs)
server/            Node server (no npm dependencies)
  lib/             config, licence, override, auth (users, user groups), credentials (vault), insights (dashboards, reports), scripts (sync + runner), scheduler, jobdefs (scheduled jobs), osreleases, engines, monitor (probe, SMTP, discovery), snmp (v1/v2c/v3), store, access-log, release, zip, github, mask
public/            web console (vanilla JS, SVG charts); js/sensors.js, js/monitor-core.js, js/rbac.js, js/credmodel.js, js/alertsources.js, js/osreleases.js and js/jobdefs.js are shared with the server
config/            moncastle.config.example.json
tools/             build-standalone.js (single-file demo), embed-manifest.js, set-override-password.js
repo-templates/    README + examples for the Licenses, Access and Console repositories
data/              created at runtime: secrets, datasets, history, logs, jobs, scripts cache, engines, inbox, backups (never shipped)
```
