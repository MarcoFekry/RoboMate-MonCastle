// The setup wizard: a step list on the left, one page at a time on the right, Back / Next at the bottom.
// Welcome > Location > Prerequisites > Service > Security > Install > Finish. Nothing changes on the server until
// the Install page; the Prerequisites page only reads (Install-MonCastle.ps1 -CheckOnly).
using System.Diagnostics;
using MonCastle.Ui;

namespace MonCastle.Setup;

internal sealed class SetupForm : Form
{
    readonly Options o = new();
    readonly bool uninstallMode;
    readonly string[] titles = { "Welcome", "Location", "Prerequisites", "Service and role", "Security and licence", "Install", "Finish" };
    readonly List<NavItem> nav = new();
    readonly Panel content = new() { Dock = DockStyle.Fill };
    readonly Panel side = new() { Dock = DockStyle.Left, Width = 250 };
    readonly FlowLayoutPanel footer = new() { Dock = DockStyle.Bottom, Height = 60, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(16, 12, 16, 10) };
    readonly ModernButton next = new("Next", ButtonKind.Primary, Glyph.Forward), back = new("Back", ButtonKind.Secondary, Glyph.Back), cancel = new("Cancel", ButtonKind.Ghost);
    int page;
    bool installing, finished, installOk;
    CancellationTokenSource? cts;

    // page controls
    readonly TextBox dir = new() { Width = 420 }, publicName = new() { Width = 220 }, account = new() { Width = 300 }, svcPassword = new() { Width = 300, UseSystemPasswordChar = true };
    readonly TextBox pw1 = new() { Width = 300, UseSystemPasswordChar = true }, pw2 = new() { Width = 300, UseSystemPasswordChar = true }, licence = new() { Width = 420, UseSystemPasswordChar = true }, join = new() { Width = 420, UseSystemPasswordChar = true, Enabled = false };
    readonly NumericUpDown port = new() { Minimum = 1, Maximum = 65535, Value = 5050, Width = 100 };
    readonly ToggleSwitch firewall = new("Allow the console port in Windows Firewall") { Checked = true }, hosts = new("Add robomatemoncastle to the hosts file") { Checked = true },
        shortcuts = new("Add Start menu entries") { Checked = true }, service = new("Run the console as a service (starts with Windows)") { Checked = true }, remote = new("This is a remote MonCastle server (joins a central console)");
    readonly RadioButton asSystem = new() { Text = "Local System (simplest; collectors use the credentials saved in the console)", AutoSize = true, Checked = true },
        asGmsa = new() { Text = "Group managed service account (gMSA, name ends with $)", AutoSize = true }, asUser = new() { Text = "Domain service account with a password", AutoSize = true };
    readonly FlowLayoutPanel preList = new() { FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoSize = true, Dock = DockStyle.Top };
    readonly Label preNote = new() { AutoSize = true, Tag = "muted", MaximumSize = new Size(640, 0) }, pwHint = new() { AutoSize = true, Tag = "muted" }, welcomeNote = new() { AutoSize = true, MaximumSize = new Size(640, 0) };
    readonly ProgressBar bar = new() { Height = 6, Dock = DockStyle.Top, Style = ProgressBarStyle.Continuous };
    readonly FlowLayoutPanel stepList = new() { FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, Dock = DockStyle.Fill };
    readonly RichTextBox log = new() { Dock = DockStyle.Fill, ReadOnly = true, BorderStyle = BorderStyle.None, Font = new Font("Consolas", 9f) };
    readonly Dictionary<string, StepRow> rows = new();
    readonly Dictionary<string, CheckBox> preBoxes = new();
    Label? finishTitle, finishText;
    bool alreadyInstalled;

    static readonly (string Id, string Name, bool Default)[] Components =
    {
        ("PowerShell7", "PowerShell 7 (runs the engines)", true), ("RSAT", "RSAT: Active Directory, DNS, DHCP, Group Policy", true), ("PrintManagement", "Print management", true),
        ("WinRM", "WinRM / PowerShell remoting", true), ("SecretManagement", "SecretManagement module", true), ("dbatools", "dbatools (SQL Server)", true),
        ("HyperV", "Hyper-V module", false), ("Clustering", "Failover clustering module", false), ("SqlServer", "SqlServer module", false), ("PowerCLI", "VMware PowerCLI", false),
        ("DatabaseClients", "Database client tools (psql, mysql, mongosh)", false),
    };

    public SetupForm(bool uninstall)
    {
        uninstallMode = uninstall;
        Text = uninstall ? "Remove RoboMate MonCastle" : "RoboMate MonCastle setup";
        try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
        AutoScaleDimensions = new SizeF(96f, 96f);
        AutoScaleMode = AutoScaleMode.Dpi;
        Font = Theme.Body;
        ClientSize = new Size(980, 640);
        MinimumSize = new Size(900, 600);
        StartPosition = FormStartPosition.CenterScreen;

        dir.Text = o.InstallDir;
        publicName.Text = o.PublicName;
        account.Text = "";
        account.Enabled = svcPassword.Enabled = false;
        foreach (var r in new[] { asSystem, asGmsa, asUser }) r.CheckedChanged += (_, _) => { account.Enabled = !asSystem.Checked; svcPassword.Enabled = asUser.Checked; };
        remote.CheckedChanged += (_, _) => join.Enabled = remote.Checked;
        pw1.TextChanged += (_, _) => PasswordHint();
        pw2.TextChanged += (_, _) => PasswordHint();

        BuildSide();
        footer.Controls.AddRange(new Control[] { next, back, cancel });
        next.Click += async (_, _) => await Next();
        back.Click += (_, _) => Show(page - 1);
        cancel.Click += (_, _) => { if (installing) cts?.Cancel(); else Close(); };
        Controls.Add(content);
        Controls.Add(footer);
        Controls.Add(side);
        Theme.Changed += () => { if (!IsDisposed) BeginInvoke(Recolor); };
        Recolor();
        Shown += async (_, _) => { Theme.Frame(this); await Check(); if (uninstallMode) ShowUninstall(); else Show(0); };
    }

    // ------------------------------------------------------------------ chrome
    void BuildSide()
    {
        var header = new Panel { Dock = DockStyle.Top, Height = 118, Tag = "keep" };
        header.Paint += (_, e) =>
        {
            var g = e.Graphics;
            g.Clear(Theme.Sidebar);
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            using var s = typeof(SetupForm).Assembly.GetManifestResourceStream("moncastle-180.png");
            if (s != null) { using var img = Image.FromStream(s); g.DrawImage(img, 22, 24, 44, 44); }
            TextRenderer.DrawText(g, "ROBOMATE", Theme.Small, new Point(76, 26), Theme.SidebarMuted);
            using var t = new Font("Segoe UI Semibold", 15f);
            TextRenderer.DrawText(g, "MonCastle", t, new Point(74, 40), Color.White);
            TextRenderer.DrawText(g, "Setup " + Runner.Version, Theme.Small, new Point(24, 84), Theme.SidebarMuted);
        };
        var list = new Panel { Dock = DockStyle.Fill, Padding = new Padding(0, 6, 0, 0), Tag = "keep" };
        for (var i = titles.Length - 1; i >= 0; i--)
        {
            var n = new NavItem(Glyph.Pending, titles[i]) { Cursor = Cursors.Default };
            var idx = i;
            n.Click += (_, _) => { if (!installing && !finished && idx < page) Show(idx); };
            nav.Insert(0, n);
            list.Controls.Add(n);
        }
        var themeBtn = new NavItem(Glyph.Moon, "Dark / light") { Dock = DockStyle.Bottom };
        themeBtn.Click += (_, _) => Theme.Set(Theme.Dark ? ThemeMode.Light : ThemeMode.Dark);
        side.Controls.Add(list);
        side.Controls.Add(themeBtn);
        side.Controls.Add(header);
    }

    void Recolor()
    {
        BackColor = content.BackColor = Theme.Page;
        footer.BackColor = Theme.Page;
        side.BackColor = Theme.Sidebar;
        foreach (Control c in side.Controls) { c.BackColor = Theme.Sidebar; c.Invalidate(true); }
        log.BackColor = Theme.Console; log.ForeColor = Color.FromArgb(0xD6, 0xE2, 0xF0);
        Restyle.Apply(content);
        Restyle.Apply(footer);
        foreach (var r in rows.Values) r.Recolor();
        Theme.Frame(this);
        Invalidate(true);
    }

    void Show(int p)
    {
        page = Math.Clamp(p, 0, titles.Length - 1);
        for (var i = 0; i < nav.Count; i++) { nav[i].Selected = i == page; nav[i].Icon = i < page ? Glyph.Check : i == page ? Glyph.Forward : Glyph.Pending; }
        content.Controls.Clear();
        var scroller = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(32, 26, 32, 10) };
        var stack = new FlowLayoutPanel { FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoSize = true, Dock = DockStyle.Top };
        scroller.Controls.Add(stack);
        content.Controls.Add(scroller);
        stack.Controls.Add(new Label { Text = titles[page], Font = Theme.Title, AutoSize = true, Margin = new Padding(0, 0, 0, 4) });
        switch (page)
        {
            case 0: PageWelcome(stack); break;
            case 1: PageLocation(stack); break;
            case 2: PagePrerequisites(stack); break;
            case 3: PageService(stack); break;
            case 4: PageSecurity(stack); break;
            case 5: PageInstall(); break;
            case 6: PageFinish(stack); break;
        }
        back.Visible = page > 0 && page < 5;
        next.Text = page == 4 ? "Install" : page == 6 ? "Close" : "Next";
        next.Icon = page == 4 ? Glyph.Download : page == 6 ? null : Glyph.Forward;
        next.Width = TextRenderer.MeasureText(next.Text, next.Font).Width + (next.Icon != null ? 52 : 32);
        next.Enabled = page != 5;
        cancel.Visible = page != 6;
        cancel.Text = page == 5 ? "Stop" : "Cancel";
        Recolor();
    }

    static Label Para(string text, int width = 640) => new() { Text = text, AutoSize = true, MaximumSize = new Size(width, 0), Tag = "muted", Margin = new Padding(0, 2, 0, 10) };
    static Card Group(params Control[] children)
    {
        var card = new Card { AutoSize = true, MinimumSize = new Size(660, 0), MaximumSize = new Size(760, 0) };
        var flow = new FlowLayoutPanel { FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoSize = true, Dock = DockStyle.Fill };
        flow.Controls.AddRange(children);
        card.Controls.Add(flow);
        return card;
    }
    static FlowLayoutPanel Row(params Control[] children)
    {
        var f = new FlowLayoutPanel { FlowDirection = FlowDirection.LeftToRight, AutoSize = true, WrapContents = false, Margin = new Padding(0) };
        f.Controls.AddRange(children);
        return f;
    }

    // ------------------------------------------------------------------ pages
    void PageWelcome(FlowLayoutPanel s)
    {
        s.Controls.Add(Para("This installs RoboMate MonCastle " + Runner.Version + " on this server: the web console, its runtime and the monitoring engines, " +
            "plus everything they need. You choose what to install on the next pages; nothing changes until you press Install."));
        welcomeNote.Text = alreadyInstalled ? "MonCastle is already installed in " + o.InstallDir + ". Setup upgrades it in place and keeps the data, configuration, licence and passwords." : "";
        welcomeNote.ForeColor = Theme.Accent;
        if (alreadyInstalled) s.Controls.Add(Group(new Label { Text = "Upgrade", Font = Theme.Heading, AutoSize = true }, welcomeNote));
        s.Controls.Add(Group(new Label { Text = "What setup does", Font = Theme.Heading, AutoSize = true },
            Para("• Checks and installs the prerequisites: PowerShell 7, RSAT modules, print management, WinRM and the optional modules for SQL Server, VMware, Hyper-V, clusters and databases.\n" +
                 "• Copies MonCastle to the install folder; the application stays encrypted and runs from memory.\n" +
                 "• Opens the console port in Windows Firewall and makes https://robomatemoncastle:5050 resolve on this server, with its HTTPS certificate trusted.\n" +
                 "• Runs the console as a service, sets the administrator override password and registers your 320RMC licence key.\n" +
                 "• Optionally joins this server to a central MonCastle console as a remote MonCastle server.")));
        if (alreadyInstalled)
        {
            var rm = new ModernButton("Remove MonCastle…", ButtonKind.Secondary, Glyph.Admin);
            rm.Click += (_, _) => ShowUninstall();
            s.Controls.Add(rm);
        }
    }

    void PageLocation(FlowLayoutPanel s)
    {
        var browse = new ModernButton("Browse…", ButtonKind.Secondary, Glyph.Folder) { Margin = new Padding(8, 0, 0, 0) };
        browse.Click += (_, _) => { using var d = new FolderBrowserDialog { SelectedPath = dir.Text, UseDescriptionForTitle = true, Description = "Install MonCastle in" }; if (d.ShowDialog(this) == DialogResult.OK) dir.Text = Path.Combine(d.SelectedPath, "MonCastle"); };
        s.Controls.Add(Group(new Caption("Install folder"), Row(dir, browse), Para("The data folder (data\\) is created inside it and is readable only by the service account, SYSTEM and administrators.")));
        s.Controls.Add(Group(new Caption("Console port"), port, new Caption("Console name"), publicName, Para("Users open https://" + publicName.Text + ":" + port.Value + ". Other computers need a DNS record (CNAME) for this name."),
            firewall, hosts, shortcuts));
    }

    void PagePrerequisites(FlowLayoutPanel s)
    {
        s.Controls.Add(Para("Setup checked this server. Ticked items are installed; items that are already present are left as they are. Optional items only affect the engines that use them."));
        var again = new ModernButton("Check again", ButtonKind.Secondary, Glyph.Refresh);
        again.Click += async (_, _) => { await Check(); Show(2); };
        s.Controls.Add(Group(new Label { Text = "Server", Font = Theme.Heading, AutoSize = true }, preNote));
        var box = new FlowLayoutPanel { FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoSize = true };
        foreach (var (id, name, def) in Components)
        {
            var present = checks.TryGetValue(id, out var c) && c.Present;
            if (!preBoxes.TryGetValue(id, out var cb)) { cb = new CheckBox { AutoSize = true, Checked = def }; preBoxes[id] = cb; }
            cb.Text = (present ? "✓ " : "") + name + (present ? "  (installed)" : "");
            cb.Enabled = !present;
            if (present) cb.Checked = false;
            cb.Margin = new Padding(0, 3, 0, 3);
            box.Controls.Add(cb);
        }
        s.Controls.Add(Group(new Label { Text = "Prerequisites", Font = Theme.Heading, AutoSize = true }, box));
        s.Controls.Add(again);
    }

    void PageService(FlowLayoutPanel s)
    {
        s.Controls.Add(Group(service, new Caption("Run as"), asSystem, asGmsa, asUser, new Caption("Account (DOMAIN\\name or DOMAIN\\gmsa$)"), account, new Caption("Password"), svcPassword,
            Para("The engines run under this account too, so give it the rights your collectors need (for example read access to Active Directory and local administrator on monitored servers), or save credentials per device in the console.")));
        s.Controls.Add(Group(new Label { Text = "MonCastle infrastructure", Font = Theme.Heading, AutoSize = true },
            Para("A single server, or the central console, needs nothing here. For a remote MonCastle server, create a join code on the central console (Monitor > MonCastle servers > Add MonCastle server) and paste it."),
            remote, new Caption("Join code (MCJ1.…)"), join));
    }

    void PageSecurity(FlowLayoutPanel s)
    {
        s.Controls.Add(Group(new Label { Text = "Administrator override password", Font = Theme.Heading, AutoSize = true },
            Para("Opens the console for an administrator without a valid licence, for example to enter a new key. Only a salted hash is stored. " + (alreadyInstalled ? "Leave empty to keep the current one." : "")),
            new Caption("Password (12+ characters)"), pw1, new Caption("Repeat"), pw2, pwHint));
        s.Controls.Add(Group(new Label { Text = "Licence", Font = Theme.Heading, AutoSize = true },
            Para("Paste your MonCastle licence key. It starts with 320RMC. You can also enter it later in the console under Settings > Licence."),
            new Caption("Licence key"), licence));
        PasswordHint();
    }

    void PasswordHint()
    {
        var a = pw1.Text; var b = pw2.Text;
        (pwHint.Text, pwHint.ForeColor) = a.Length == 0 ? (alreadyInstalled ? "The current password is kept." : "Required for a new installation.", Theme.Muted)
            : a.Length < 12 ? ($"{a.Length} of 12 characters", Theme.Warn)
            : a != b ? ("The two passwords do not match yet.", Theme.Warn)
            : ("Strong enough: " + Strength(a), Theme.Good);
    }
    static string Strength(string p) { var classes = new[] { p.Any(char.IsLower), p.Any(char.IsUpper), p.Any(char.IsDigit), p.Any(c => !char.IsLetterOrDigit(c)) }.Count(x => x); return classes >= 3 && p.Length >= 16 ? "very good" : classes >= 3 ? "good" : "acceptable (add digits and symbols)"; }

    void PageInstall()
    {
        var wrap = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, Padding = new Padding(32, 26, 32, 10) };
        wrap.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        wrap.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        wrap.RowStyles.Add(new RowStyle(SizeType.Percent, 62));
        wrap.RowStyles.Add(new RowStyle(SizeType.Percent, 38));
        wrap.Controls.Add(new Label { Text = uninstallMode ? "Removing" : "Installing", Font = Theme.Title, AutoSize = true }, 0, 0);
        bar.Margin = new Padding(0, 10, 0, 12);
        bar.Width = 600;
        bar.Dock = DockStyle.Fill;
        wrap.Controls.Add(bar, 0, 1);
        var card = new Card { Dock = DockStyle.Fill, Padding = new Padding(12, 8, 12, 8) };
        card.Controls.Add(stepList);
        wrap.Controls.Add(card, 0, 2);
        var frame = new Panel { Dock = DockStyle.Fill, Padding = new Padding(10), Tag = "keep", Margin = new Padding(0, 8, 0, 0) };
        frame.BackColor = Theme.Console;
        frame.Controls.Add(log);
        wrap.Controls.Add(frame, 0, 3);
        content.Controls.Clear();
        content.Controls.Add(wrap);
    }

    void PageFinish(FlowLayoutPanel s)
    {
        finishTitle = new Label { AutoSize = true, Font = Theme.Heading, ForeColor = installOk ? Theme.Good : Theme.Bad };
        finishText = Para("");
        if (uninstallMode)
        {
            finishTitle.Text = installOk ? "MonCastle was removed." : "Removal finished with problems.";
            finishText.Text = installOk ? (o.RemoveData ? "The program and its data were removed." : "The data folder was kept in " + o.InstallDir + "\\data.") : "See the log on the previous page for what needs attention.";
            s.Controls.Add(Group(finishTitle, finishText));
            return;
        }
        finishTitle.Text = installOk ? "MonCastle is installed." : "Setup finished with problems.";
        finishText.Text = installOk
            ? $"The console runs at https://{o.PublicName}:{o.Port}/. Sign in with your licence, or with the administrator override password."
            : "Some steps need attention; they are marked in red. Fix them and run setup again: it keeps what is already done.";
        var open = new ModernButton("Open the console", ButtonKind.Primary, Glyph.Globe);
        open.Click += (_, _) => Launch($"https://{o.PublicName}:{o.Port}/");
        var launcher = new ModernButton("Open the launcher", ButtonKind.Secondary, Glyph.Power);
        launcher.Click += (_, _) => Launch(Path.Combine(o.InstallDir, "RoboMate.MonCastle.Launcher.exe"));
        var logs = new ModernButton("Setup log", ButtonKind.Ghost, Glyph.Document);
        logs.Click += (_, _) => Launch(Path.GetTempPath());
        s.Controls.Add(Group(finishTitle, finishText, Row(open, launcher, logs)));
    }

    static void Launch(string target) { try { Process.Start(new ProcessStartInfo(target) { UseShellExecute = true }); } catch (Exception e) { MessageBox.Show(e.Message, "RoboMate MonCastle setup"); } }

    // ------------------------------------------------------------------ behaviour
    readonly Dictionary<string, CheckLine> checks = new();
    async Task Check()
    {
        checks.Clear();
        o.InstallDir = dir.Text.Trim();
        o.Port = (int)port.Value;
        Cursor = Cursors.WaitCursor;
        try { await Runner.RunAsync(o, "check", null, c => checks[c.Id] = c, null); }
        catch (Exception e) { preNote.Text = e.Message; }
        finally { Cursor = Cursors.Default; }
        alreadyInstalled = checks.TryGetValue("installed", out var inst) && inst.Present;
        var bad = checks.Values.Where(c => c.Id is "os" or "disk" or "port" or "runtime" && !c.Present).Select(c => c.Detail).ToList();
        var good = checks.Values.Where(c => c.Id is "os" or "disk" or "runtime" && c.Present).Select(c => c.Detail).ToList();
        preNote.Text = string.Join("\n", good.Select(x => "✓ " + x).Concat(bad.Select(x => "⚠ " + x)));
        preNote.ForeColor = bad.Count > 0 ? Theme.Warn : Theme.Muted;
    }

    string? CheckPage()
    {
        switch (page)
        {
            case 1:
                if (!Path.IsPathRooted(dir.Text.Trim())) return "Choose a full path for the install folder, for example C:\\Program Files\\RoboMate\\MonCastle.";
                if (!System.Text.RegularExpressions.Regex.IsMatch(publicName.Text.Trim(), "^[A-Za-z0-9][A-Za-z0-9.-]{0,62}$")) return "The console name can only use letters, digits, dots and dashes.";
                break;
            case 3:
                if (asGmsa.Checked && !account.Text.Trim().EndsWith("$")) return "A gMSA name ends with $ (DOMAIN\\name$).";
                if (asUser.Checked && (account.Text.Trim().Length == 0 || svcPassword.Text.Length == 0)) return "Give the service account and its password, or choose Local System.";
                if (remote.Checked && !System.Text.RegularExpressions.Regex.IsMatch(join.Text.Trim(), @"^MCJ1\.[A-Za-z0-9_-]+$")) return "Paste the join code from the central console; it starts with MCJ1.";
                break;
            case 4:
                if (pw1.Text.Length == 0 && !alreadyInstalled) return "Set the administrator override password.";
                if (pw1.Text.Length > 0 && pw1.Text.Length < 12) return "The override password needs 12 or more characters.";
                if (pw1.Text != pw2.Text) return "The two override passwords do not match.";
                // only MonCastle licence keys are accepted, never raw GitHub tokens
                if (licence.Text.Trim().Length > 0 && !licence.Text.Trim().StartsWith("320RMC", StringComparison.Ordinal)) return "The licence key must start with 320RMC.";
                break;
        }
        return null;
    }

    async Task Next()
    {
        if (page == 6) { Close(); return; }
        var err = CheckPage();
        if (err != null) { MessageBox.Show(this, err, "RoboMate MonCastle setup", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
        if (page == 1) { o.InstallDir = dir.Text.Trim(); o.Port = (int)port.Value; o.PublicName = publicName.Text.Trim(); o.Firewall = firewall.Checked; o.Hosts = hosts.Checked; o.Shortcuts = shortcuts.Checked; }
        if (page == 4) { await Install(); return; }
        Show(page + 1);
    }

    async Task Install()
    {
        o.Components.Clear();
        o.Components.AddRange(preBoxes.Where(kv => kv.Value.Enabled && kv.Value.Checked).Select(kv => kv.Key));
        o.Service = service.Checked;
        o.ServiceAccount = asSystem.Checked ? @"NT AUTHORITY\SYSTEM" : account.Text.Trim();
        o.ServicePassword = asUser.Checked ? svcPassword.Text : null;
        o.OverridePassword = pw1.Text.Length > 0 ? pw1.Text : null;
        o.LicenceKey = licence.Text.Trim().Length > 0 ? licence.Text.Trim() : null;
        o.JoinCode = remote.Checked ? join.Text.Trim() : null;
        // clear the secrets from the form once they are handed over
        pw1.Text = pw2.Text = svcPassword.Text = licence.Text = join.Text = "";
        await Run("install");
    }

    void ShowUninstall()
    {
        var keep = MessageBox.Show(this, "Remove RoboMate MonCastle from " + o.InstallDir + "?\n\nYes: remove the program and keep the data folder (monitoring history, configuration, licence).\nNo: remove the program and all its data.\nCancel: keep everything.",
            "Remove RoboMate MonCastle", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
        if (keep == DialogResult.Cancel) { if (uninstallMode) Close(); return; }
        o.RemoveData = keep == DialogResult.No;
        _ = Run("uninstall");
    }

    async Task Run(string mode)
    {
        installing = true;
        Show(5);
        rows.Clear();
        stepList.Controls.Clear();
        log.Clear();
        bar.Value = 0;
        var expected = mode == "uninstall" ? 6 : 12 + o.Components.Count;
        var done = 0;
        var failed = false;
        cts = new CancellationTokenSource();
        try
        {
            await Runner.RunAsync(o, mode, s => Ui(() =>
            {
                if (s.State == "fail") failed = true;
                if (!rows.TryGetValue(s.Id, out var row)) { row = new StepRow(); rows[s.Id] = row; stepList.Controls.Add(row); }
                row.Set(s.State, s.Text);
                stepList.ScrollControlIntoView(row);
                if (s.State != "run") { done++; bar.Value = Math.Min(100, done * 100 / Math.Max(expected, done + 1)); }
            }), null, l => Ui(() => { log.AppendText(l + Environment.NewLine); log.ScrollToCaret(); }), cts.Token);
            installOk = !failed;
        }
        catch (OperationCanceledException) { installOk = false; Ui(() => log.AppendText("Stopped." + Environment.NewLine)); }
        catch (Exception e) { installOk = false; Ui(() => log.AppendText("! " + e.Message + Environment.NewLine)); }
        bar.Value = 100;
        installing = false;
        finished = true;
        next.Enabled = true;
        next.Text = "Finish";
        cancel.Visible = false;
    }

    void Ui(Action a) { if (IsDisposed) return; if (InvokeRequired) BeginInvoke(a); else a(); }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (installing && MessageBox.Show(this, "Setup is still running. Stop it?", "RoboMate MonCastle setup", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No) { e.Cancel = true; return; }
        cts?.Cancel();
        base.OnFormClosing(e);
    }

    // one line of the install list: state icon, text
    sealed class StepRow : Control
    {
        string state = "run";
        public StepRow() { Height = 30; Width = 640; Font = Theme.Body; SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true); Margin = new Padding(0, 1, 0, 1); }
        public void Set(string s, string text) { state = s; Text = text; Width = Math.Max(640, (Parent?.ClientSize.Width ?? 660) - 30); Invalidate(); }
        public void Recolor() => Invalidate();
        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.Clear(Theme.Surface);
            var (glyph, color) = state switch { "ok" => (Glyph.Check, Theme.Good), "warn" => (Glyph.Warning, Theme.Warn), "fail" => (Glyph.Error, Theme.Bad), "skip" => (Glyph.Skip, Theme.Idle), _ => (Glyph.Pending, Theme.Accent) };
            using var f = Theme.Icons(11f);
            TextRenderer.DrawText(g, glyph, f, new Rectangle(4, 0, 22, Height), color, TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            TextRenderer.DrawText(g, Text, Font, new Rectangle(32, 0, Width - 36, Height), state == "run" ? Theme.Ink : state == "fail" ? Theme.Bad : Theme.Ink, TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
        }
    }
}
