// Runs launcher\Install-MonCastle.ps1 with Windows PowerShell (always present, unlike PowerShell 7 which setup may
// install) and turns its "##STEP|id|state|text" and "##CHECK|id|present|detail" lines into events. Secrets go to the
// script in environment variables of that one process, never on its command line.
using System.Diagnostics;

namespace MonCastle.Setup;

internal sealed record StepLine(string Id, string State, string Text);
internal sealed record CheckLine(string Id, bool Present, string Detail);

internal sealed class Options
{
    public string InstallDir { get; set; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "RoboMate", "MonCastle");
    public int Port { get; set; } = 5050;
    public string PublicName { get; set; } = "robomatemoncastle";
    public string ServiceAccount { get; set; } = @"NT AUTHORITY\SYSTEM";
    public string? ServicePassword { get; set; }
    public bool Service { get; set; } = true;
    public bool Firewall { get; set; } = true;
    public bool Hosts { get; set; } = true;
    public bool Shortcuts { get; set; } = true;
    public List<string> Components { get; } = new() { "PowerShell7", "RSAT", "PrintManagement", "WinRM", "SecretManagement", "dbatools" };
    public string? OverridePassword { get; set; }
    public string? LicenceKey { get; set; }
    public string? JoinCode { get; set; }
    public bool RemoveData { get; set; }
}

internal static class Runner
{
    public static string PackageDir => AppContext.BaseDirectory.TrimEnd('\\');
    public static string Script => Path.Combine(PackageDir, "launcher", "Install-MonCastle.ps1");
    public static string Version
    {
        get
        {
            try
            {
                using var doc = System.Text.Json.JsonDocument.Parse(File.ReadAllText(Path.Combine(PackageDir, "version.json")));
                return doc.RootElement.GetProperty("version").GetString() ?? "";
            }
            catch { return ""; }
        }
    }

    public static async Task<int> RunAsync(Options o, string mode, Action<StepLine>? onStep, Action<CheckLine>? onCheck, Action<string>? onLog, CancellationToken ct = default)
    {
        if (!File.Exists(Script)) throw new FileNotFoundException("launcher\\Install-MonCastle.ps1 is missing next to the setup app. Run setup from the MonCastle package folder.", Script);
        var psi = new ProcessStartInfo(Path.Combine(Environment.SystemDirectory, "WindowsPowerShell", "v1.0", "powershell.exe"))
        {
            UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true,
            StandardOutputEncoding = System.Text.Encoding.UTF8, StandardErrorEncoding = System.Text.Encoding.UTF8,
        };
        foreach (var a in new[] { "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", Script, "-InstallDir", o.InstallDir, "-SourceDir", PackageDir }) psi.ArgumentList.Add(a);
        switch (mode)
        {
            case "check":
                psi.ArgumentList.Add("-CheckOnly");
                psi.ArgumentList.Add("-Port"); psi.ArgumentList.Add(o.Port.ToString());
                break;
            case "uninstall":
                psi.ArgumentList.Add("-Uninstall");
                if (o.RemoveData) psi.ArgumentList.Add("-RemoveData");
                break;
            default:
                foreach (var a in new[] { "-Port", o.Port.ToString(), "-PublicName", o.PublicName, "-ServiceAccount", o.ServiceAccount, "-Unattended" }) psi.ArgumentList.Add(a);
                if (o.Components.Count > 0) { psi.ArgumentList.Add("-Components"); psi.ArgumentList.Add(string.Join(",", o.Components)); }
                if (!o.Service) psi.ArgumentList.Add("-NoService");
                if (!o.Firewall) psi.ArgumentList.Add("-NoFirewall");
                if (!o.Hosts) psi.ArgumentList.Add("-NoHosts");
                if (!o.Shortcuts) psi.ArgumentList.Add("-NoShortcuts");
                // secrets: environment of this one process only
                if (!string.IsNullOrEmpty(o.OverridePassword)) psi.Environment["MC_OVERRIDE_PASSWORD"] = o.OverridePassword;
                if (!string.IsNullOrEmpty(o.LicenceKey)) psi.Environment["MC_LICENSE_KEY"] = o.LicenceKey.Trim();
                if (!string.IsNullOrEmpty(o.JoinCode)) psi.Environment["MC_JOIN"] = o.JoinCode.Trim();
                if (!string.IsNullOrEmpty(o.ServicePassword)) psi.Environment["MC_SETUP_SVC_PASSWORD"] = o.ServicePassword;
                break;
        }
        using var p = new Process { StartInfo = psi, EnableRaisingEvents = true };
        void Line(string? l, bool err)
        {
            if (l == null) return;
            if (l.StartsWith("##STEP|"))
            {
                var f = l.Split('|', 4);
                if (f.Length == 4) { onStep?.Invoke(new StepLine(f[1], f[2], f[3])); onLog?.Invoke($"[{f[2]}] {f[3]}"); }
            }
            else if (l.StartsWith("##CHECK|"))
            {
                var f = l.Split('|', 4);
                if (f.Length == 4) onCheck?.Invoke(new CheckLine(f[1], f[2] == "yes", f[3]));
            }
            else if (l.Trim().Length > 0) onLog?.Invoke(err ? "! " + l : l);
        }
        p.OutputDataReceived += (_, e) => Line(e.Data, false);
        p.ErrorDataReceived += (_, e) => Line(e.Data, true);
        p.Start();
        p.BeginOutputReadLine();
        p.BeginErrorReadLine();
        // the secrets were copied into the child's environment block; drop our references
        o.OverridePassword = o.LicenceKey = o.JoinCode = o.ServicePassword = null;
        try { await p.WaitForExitAsync(ct); }
        catch (OperationCanceledException) { try { p.Kill(true); } catch { } throw; }
        return p.ExitCode;
    }
}
