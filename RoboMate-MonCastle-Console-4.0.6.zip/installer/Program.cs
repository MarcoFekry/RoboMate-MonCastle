// RoboMate MonCastle setup.
//   MonCastle-Setup.exe                      the setup wizard
//   MonCastle-Setup.exe /uninstall           remove MonCastle (Apps & features calls this)
//   MonCastle-Setup.exe /quiet [/dir=<folder>] [/port=<n>] [/account=<user>] [/components=PowerShell7,RSAT,...]
//                                            unattended install with no window; secrets come from the environment
//                                            (MC_OVERRIDE_PASSWORD, MC_LICENSE_KEY, MC_JOIN, MC_SETUP_SVC_PASSWORD)
//                                            and the exit code is 0 when every step succeeded
using MonCastle.Ui;

namespace MonCastle.Setup;

internal static class Program
{
    [STAThread]
    static int Main(string[] args)
    {
        string? Arg(string name) => args.FirstOrDefault(a => a.StartsWith("/" + name + "=", StringComparison.OrdinalIgnoreCase))?.Split('=', 2)[1];
        bool Flag(string name) => args.Any(a => a.Equals("/" + name, StringComparison.OrdinalIgnoreCase) || a.Equals("--" + name, StringComparison.OrdinalIgnoreCase));

        if (Flag("quiet"))
        {
            var o = new Options();
            if (Arg("dir") is { } d) o.InstallDir = d;
            if (int.TryParse(Arg("port"), out var port)) o.Port = port;
            if (Arg("account") is { } acct) o.ServiceAccount = acct;
            if (Arg("components") is { } comps) { o.Components.Clear(); o.Components.AddRange(comps.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)); }
            var failed = false;
            var code = Runner.RunAsync(o, Flag("uninstall") ? "uninstall" : "install", s => { if (s.State == "fail") failed = true; Console.WriteLine($"[{s.State}] {s.Text}"); }, null, null).GetAwaiter().GetResult();
            return failed || code != 0 ? 1 : 0;
        }

        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        Application.ThreadException += (_, e) => MessageBox.Show(e.Exception.Message, "RoboMate MonCastle setup", MessageBoxButtons.OK, MessageBoxIcon.Error);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
        Theme.WatchSystem();
        Application.Run(new SetupForm(Flag("uninstall")));
        return 0;
    }
}
