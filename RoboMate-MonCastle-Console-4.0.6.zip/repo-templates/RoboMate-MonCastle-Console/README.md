# RoboMate-MonCastle-Console

Release packages for the RoboMate MonCastle web console.

```
version.json                                   <- consoles read this to see if there is a newer version
CHANGELOG.md
releases/RoboMate-MonCastle-Console-<v>.zip    <- the package
```

`version.json`:

```json
{
  "product": "RoboMate MonCastle Console",
  "version": "4.1.0",
  "released": "2026-11-02T10:00:00.000Z",
  "notes": "What changed",
  "zip": "releases/RoboMate-MonCastle-Console-4.1.0.zip",
  "sha256": "<sha-256 of the zip>",
  "size": 412318,
  "files": 46,
  "minNode": "18.17"
}
```

## Publishing

1. In the console on the build machine: **Updates & releases > Publish a release**. It zips the app from
   `D:\RoboMate-MonCastle` into `C:\robomate\RoboMate-MonCastle-Console` with this layout and writes `version.json`.
2. Upload `version.json`, `CHANGELOG.md` and the new zip under `releases/` to this repository.

## Updating a console

Consoles check `version.json` every 12 hours with their licence key (the token needs Contents: Read here).
An administrator installs from **Updates & releases**: the zip is verified against `sha256` and `size`, the current
version is backed up to `data\backups`, files are replaced (the `data` folder and `config\moncastle.config.json` are kept),
and the console restarts.
