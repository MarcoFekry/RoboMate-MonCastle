# RoboMate-MonCastle-Licenses

This private repository is the licence authority for RoboMate MonCastle consoles.

## How a console is licensed

1. Create a **fine-grained personal access token** (or a token for a machine user) that has **read access to this repository** (Contents: Read). If the same token should also ship access logs, give it **Contents: Read and write** on `RoboMate-MonCastle-Access` and **Contents: Read** on `RoboMate-MonCastle-Scripts`.
2. Paste the token into the console launcher on first start. The console calls `GET /repos/MarcoFekry/RoboMate-MonCastle-Licenses`; a `200` means the token is genuine and authorised.
3. The console stores the token AES-256-GCM encrypted and only ever displays it masked as `••••••••••••abcd` (last four characters, no prefix). It re-checks every 6 hours and keeps working for 72 hours if GitHub is unreachable. After that, or when the licence is revoked or expired, the console becomes read-only. Nothing is deleted.

Revoking access is immediate: remove the token's access to this repository (or delete the token), or mark the entry `"revoked": true` below.

## licenses.json (optional registry)

Without this file every token that can read the repo is a valid "Standard" licence. With it, you can attach a holder, edition, expiry and node limit to each token, and with `policy.requireRegistration` only registered tokens are accepted.

Tokens are never stored here. Each entry is identified by a **fingerprint**: the first 16 hex characters of the SHA-256 of the token.

```powershell
# PowerShell 7
$t = Read-Host 'Token' -MaskInput
-join ([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($t)) | ForEach-Object { $_.ToString('x2') })[0..15]
```

```bash
printf %s "$TOKEN" | sha256sum | cut -c1-16
```

See `licenses.example.json` for the format. Fields:

| Field | Meaning |
|---|---|
| `id` | Your licence reference |
| `holder` | Customer or business unit shown in the console |
| `fingerprint` | First 16 hex of SHA-256(token) |
| `edition` | Free text, e.g. Standard / Enterprise |
| `expires` | ISO date; after it the console goes read-only |
| `maxNodes` | Informational node limit shown in the console |
| `revoked` | `true` blocks the token at the next check |
