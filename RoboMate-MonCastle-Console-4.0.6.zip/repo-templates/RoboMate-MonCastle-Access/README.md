# RoboMate-MonCastle-Access

Access logs shipped by RoboMate MonCastle consoles.

Each console appends JSON lines in batches (every 5 minutes or 50 events) to:

```
access-logs/{consoleId}/{YYYY}/{MM}/{YYYY-MM-DD}.jsonl
```

One line per event:

```json
{"time":"2026-10-23T09:41:12.512Z","console":"MC01","event":"run","user":"noc.operator","ip":"10.10.50.24","detail":"act.service ComputerName=DC02 ServiceName=DFSR Operation=Start"}
```

Events: `login`, `login-failed`, `logout`, `setup`, `view`, `run`, `license`, `license-failed`, `sync`, `schedule`, `user`.

Tokens, passwords and secrets are masked before anything is written, locally or here. The console keeps a local copy in `data/logs/` whether or not the push succeeds, and retries failed pushes.

The licence token needs **Contents: Read and write** on this repository for pushes to work. Keep the repository private.
