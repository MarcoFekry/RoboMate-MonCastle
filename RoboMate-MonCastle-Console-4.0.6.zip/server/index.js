'use strict';
/*
 * RoboMate MonCastle console server. Node 18+ with no npm dependencies.
 *   node server/index.js            (config/moncastle.config.json, see the .example file)
 *   MC_MODE=demo node server/index.js   generated data, no PowerShell needed
 */
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const cfg = require('./lib/config').load();
const { sanitize } = require('./lib/mask');
const log = (msg) => console.log(new Date().toISOString() + ' ' + sanitize(String(msg)));

const store = require('./lib/secure-store').create(path.join(cfg.dataDir, 'secrets'));
// encryption at rest for the data folder: everything the console writes is readable only through the console
const sealed = require('./lib/sealed');
sealed.init(store.masterKey(), { enabled: cfg.encryptData !== false });
{
  const D = (...p) => path.join(cfg.dataDir, ...p);
  const n = sealed.migrate(cfg.dataDir, [D('secrets'), D('scripts'), D('inbox'), D('engines', 'licence.json'), D('jobs'), D('releases'), D('backups'), D('tls')]);
  if (n) console.log(new Date().toISOString() + ' Encrypted ' + n + ' data files at rest');
}
let license;
const gh = require('./lib/github').create(cfg, () => license.token());
license = require('./lib/license').create(cfg, store, gh, log);
const access = require('./lib/access-log').create(cfg, gh, () => !!license.token(), log);
const data = require('./lib/store').create(cfg);
const auth = require('./lib/auth').create(cfg);
const override = require('./lib/override').create(cfg);
const release = require('./lib/release').create(cfg, gh, log);
// MonCastle infrastructure: this server is the central console, or a remote server joined to one (server/lib/infra.js)
// HTTPS on the console port: config.tls certificate, or a self-signed one made in data/tls (server/lib/tlscert.js)
cfg.tlsInfo = require('./lib/tlscert').ensure(cfg, log);
if (process.argv.includes('--make-cert')) {
  // used by the setup app and the launcher before they trust the certificate in the Windows certificate store
  const t = cfg.tlsInfo || require('./lib/tlscert').ensure(Object.assign({}, cfg, { tls: { enabled: true } }), log);
  console.log(JSON.stringify({ cer: path.join(cfg.dataDir, 'tls', 'moncastle.cer'), thumbprint: t.thumbprint, names: t.names, validTo: t.validTo, source: t.source }));
  process.exit(0);
}
const infra = require('./lib/infra').create(cfg, { store, log, version: release.current().version });
if (process.argv.includes('--join') || process.env.MC_JOIN) {
  const code = process.env.MC_JOIN || process.argv[process.argv.indexOf('--join') + 1];
  try { const j = infra.join(code); log('Joined ' + j.central + ' as ' + (j.name || j.id) + '. Start the server again to run as a remote MonCastle server.'); process.exit(0); } catch (e) { log('Join failed: ' + e.message); process.exit(1); }
}
const REMOTE = infra.role === 'remote';
const remoteQ = { readings: [], results: [], targets: {} };
// a remote server works while the central console answers (72 hours of grace, like the licence)
const remoteOk = () => { const r = infra.remoteStatus(); return !!r.lastSync && Date.now() - Date.parse(r.lastSync) < 72 * 36e5; };
let scheduler;
const scripts = require('./lib/scripts').create(cfg, gh, log, (job) => {
  if (REMOTE) { if (job.result && (scripts.manifest().scripts.find((x) => x.id === job.script) || {}).kind === 'collector') remoteQ.results.push(Object.assign({}, job.result, { script: job.script })); if (scheduler) scheduler.onJob(job); return; }
  if (job.result) { if (job.merge) data.merge(job.result, job.merge); else data.put(job.result); }
  if (scheduler) scheduler.onJob(job);
  if (jobdefs) jobdefs.onJob(job);
  // collector runs feed the engine run history (engine info page)
  if (engines && (scripts.manifest().scripts.find((x) => x.id === job.script) || {}).kind === 'collector') { const by = job.user && job.user.name ? job.user.name : job.user; const trig = by === 'scheduler' ? 'schedule' : 'manual'; engines.record(job.script, job.result ? engines.fromResult(job.result, Object.assign({ at: job.started, by, trigger: trig, job: job.id }, job.state === 'failed' ? { status: 'error', error: String(job.error || '').slice(0, 400) } : {})) : { at: job.started, finished: job.finished || null, status: 'error', errors: 1, message: String(job.error || job.message || 'failed').slice(0, 400), by, trigger: trig, job: job.id }); }
});
scheduler = require('./lib/scheduler').create(cfg, scripts, () => (REMOTE ? remoteOk() : !license.readOnly()) && cfg.mode === 'live', log);
const VERSION = release.current().version;
let engines, jobdefs;

// demo mode reuses the same generator as the browser demo
const demo = cfg.mode === 'demo' ? require(path.join(cfg.publicDir, 'js', 'demo-data.js')) : null;
const demoRun = demo ? (s, params, job) => {
  scripts.markRunning();
  job.state = 'running';
  setTimeout(() => {
    const r = s.kind === 'collector' ? demo.all()[s.dataset] : demo.simulate(s.id, params);
    scripts.finish(job, r || { status: 'ok', dataset: s.dataset, data: [], message: 'demo' });
    scripts.done();
  }, 800 + Math.random() * 1500);
} : null;
engines = require('./lib/engines').create(cfg, scheduler, scripts, data, () => !license.readOnly(), log, demoRun);
const credentials = require('./lib/credentials').create(cfg, store, log);
const insights = require('./lib/insights').create(cfg);
// retention policy and archive (Admin > Data retention)
const retention = require('./lib/retention').create(cfg, { data, datasets: () => (demo ? demo.all() : data.all()), log });
// newest Windows builds and Linux releases, checked online once a day (Govern > Updates)
const osreleases = require('./lib/osreleases').create(cfg, { log });
const monitor = require('./lib/monitor').create(cfg, { data, scripts, store, log, demo, osreleases, directory: () => auth.directory(), archive: (kind, ref, rows) => retention.archive(kind, ref, rows), retention: () => retention.policy(), licensed: () => (REMOTE ? remoteOk() : !readOnly()), credentials: REMOTE ? infra.remoteCredentials : credentials,
  // direct sensors: run one collector for one device; the target name is the one PowerShell connects to, so its credentials go under that name
  directEnv: (dev) => { const t = dev.host || dev.name; const vault = REMOTE ? infra.remoteCredentials : credentials; return { MC_EXTRA_TARGETS: JSON.stringify([t]), MC_TARGETS_ONLY: '1', MC_TARGET_INFO: targetInfo([dev.name]), MC_CREDS: REMOTE ? vault.envFor() : vault.envFor([Object.assign({}, dev, { name: t })], core.chain) }; },
  onDeviceAdded: (d) => collectInventory(d),
  servers: () => infra.brief(), runAll: cfg.mode === 'demo', onReading: REMOTE ? (id, reading, t) => { remoteQ.readings.push({ id, t, reading }); if (remoteQ.readings.length > 20000) remoteQ.readings.splice(0, 5000); } : null });
const MC = require(path.join(cfg.publicDir, 'js', 'monitor-core.js'));
const RB = require(path.join(cfg.publicDir, 'js', 'rbac.js'));
const REM = require(path.join(cfg.publicDir, 'js', 'remote.js'));
const core = monitor.core;
// scheduled jobs: actions and tools on a schedule, for all devices, device groups or chosen devices (Act > Actions & jobs)
jobdefs = require('./lib/jobdefs').create(cfg, { scripts, core, credentials, notify: (to, title, text) => monitor.notice(to, title, text), log, audit: (event, detail) => access.add({ event, user: 'system', ip: '127.0.0.1', detail }), canRun: () => !REMOTE && !readOnly(), demoRun });

// a signed-in user's role on one device group, from their console role and the user groups they are in
const withAccess = (user) => Object.assign({}, user, { access: (gid) => (user.override ? 'admin' : RB.access(user, gid, auth.groups(), core.chain)) });
const monHost = Object.assign({}, monitor, { credentialOk: (id, u) => { const c = credentials.get(id); return !!c && (!c.private || c.createdBy === u.name || RB.norm(u.role) === 'admin') && credentials.usable(c, withAccess(u), auth.groups()); } });
// devices a script run is aimed at: its host parameters matched to monitored devices
const hostsOf = (params) => [].concat(params.ComputerName || [], params.VMName || [], params.Target || [], params.HostName || []).map(String);
const devicesNamed = (names) => names.map((n) => core.deviceByName(n)).filter(Boolean);
// what a collector needs to know about its targets besides the name: address, database engine and port, cloud provider
const SENS = require(path.join(cfg.publicDir, 'js', 'sensors.js'));
const RC = require(path.join(cfg.publicDir, 'js', 'remotecontrol.js'));
// demo: devices onboarded earlier keep their inventory rows after a restart
if (demo) for (const d of core.config().devices || []) { demo.onboard(d, SENS.inventoryPlan(d)); if (d.audit) demo.auditOn(d); }
const targetInfo = (names) => {
  const out = {};
  const sensors = (core.config().sensors || []);
  for (const n of names) {
    const d = core.deviceByName(n);
    if (!d) continue;
    const db = sensors.find((x) => x.device === d.id && x.type === 'db.service');
    const engine = (db && db.params.engine) || d.engine || (/^db-/.test(d.profile || '') ? d.profile.slice(3) : null);
    const provider = d.provider || ((SENS.PROFILE[d.profile] || {}).provider) || null;
    out[n] = { host: d.host || null, kind: d.kind, profile: d.profile || null, engine, port: (db && +db.params.port) || null, provider, region: d.region || null };
  }
  return JSON.stringify(out);
};
// A device onboarded by hand, from auto-discovery or from an import gets the inventory the engines collect for the devices
// they find: the inventory collectors run for that one device and their rows are merged into the datasets (other rows stay).
function collectInventory(dev, user) {
  const list = scripts.manifest().scripts || [];
  // roles found by an earlier inventory decide the role-specific collectors (IIS, file shares, printers, SQL)
  if (!demo && !(dev.roles || []).length) { const r = ((data.all()['inventory.roles'] || {}).data || []).find((x) => String(x.ComputerName || '').split('.')[0].toUpperCase() === String(dev.name).split('.')[0].toUpperCase()); if (r) dev = Object.assign({}, dev, { roles: r.Roles || [] }); }
  const plan = SENS.inventoryPlan(dev, demo ? null : list);
  if (demo) { demo.onboard(dev, plan); return plan.map((x) => ({ script: x.script, label: x.label, dataset: x.dataset, state: 'done' })); }
  if (REMOTE || license.readOnly()) return [];
  const t = dev.host || dev.name;
  const env = { MC_EXTRA_TARGETS: JSON.stringify([t]), MC_TARGETS_ONLY: '1', MC_TARGET_INFO: targetInfo([dev.name]), MC_CREDS: credentials.envFor([Object.assign({}, dev, { name: t })], core.chain) };
  return plan.map((x) => {
    const s = list.find((y) => y.id === x.script);
    const pn = x.param ? x.param(dev) : 'ComputerName';
    const cn = (s.parameters || []).find((p) => p.name === pn);
    const params = cn ? { [pn]: /\[\]$/.test(cn.type || '') ? [t] : t } : {};
    try { const job = scripts.run({ script: x.script, params, user: user || { name: 'onboarding', role: 'system' }, role: 'admin', env, merge: x.key }); return { script: x.script, label: x.label, dataset: x.dataset, job: job.id, state: job.state }; }
    catch (e) { return { script: x.script, label: x.label, dataset: x.dataset, state: 'failed', error: e.message }; }
  });
}
// engine targets chosen by an administrator (Monitoring engines > engine > Targets): data/engines/scopes.json
const ES = require(path.join(cfg.publicDir, 'js', 'enginescope.js'));
const scopeFile = path.join(cfg.dataDir, 'engines', 'scopes.json');
let engineScopes = {};
try { engineScopes = sealed.readJson(scopeFile, {}) || {}; } catch (e) { engineScopes = {}; }
const scopeOf = (id) => { const meta = scripts.manifest().scripts.find((x) => x.id === id) || { id }; return ES.familyOf(meta) ? ES.migrate(meta, engineScopes[id]) : null; };
const localDevices = () => core.devices().filter((d) => core.serverOf(d.id) === infra.LOCAL);
// targets and credentials an engine scope adds: workgroup hosts (with the chosen credential), devices chosen one by one,
// all devices of its kinds (optionally in some groups), and engine credentials per device or group
function scopeTargets(id) {
  const meta = scripts.manifest().scripts.find((x) => x.id === id) || { id };
  const sc = scopeOf(id); if (!sc) return { names: [], devices: [], env: {}, scope: null };
  const fam = ES.FAMILIES[ES.familyOf(meta)];
  let hosts = []; try { hosts = ES.expand(sc.hosts); } catch (e) { hosts = []; }
  const added = ES.addedDevices(meta, sc, localDevices());
  const pseudo = hosts.map((h) => ({ name: h, host: h, group: null, credentials: sc.credential && fam.cred ? { [fam.cred]: sc.credential } : {} }));
  const env = {};
  const adChosen = sc.ad.length || sc.adGroups.length || sc.ous.length;
  // 4.7.4: the default scope (every AD server ...) is read only when an administrator turned it on
  if (adChosen || !sc.useDefault) env.MC_TARGET_SCOPE = JSON.stringify({ ad: sc.ad, adGroups: sc.adGroups, ous: sc.ous, replace: !sc.useDefault });
  if (!sc.useDefault && !adChosen) env.MC_TARGETS_ONLY = '1';
  return { names: added.map((d) => d.host || d.name).concat(hosts), devices: added.concat(pseudo), env, scope: sc };
}
// a device as one engine sees it: the engine credential chosen for the device or its group wins for this engine only
function withEngineCred(sc, d) {
  const o = sc ? ES.credentialFor(sc, d, [].concat(...(d.groups && d.groups.length ? d.groups : [d.group]).map((g) => core.chain(g)))) : null;
  const c = o ? credentials.get(o.credential) : null;
  return c ? Object.assign({}, d, { credentials: Object.assign({}, d.credentials || {}, { [c.kind]: c.id }) }) : d;
}
const engineConfigured = (meta, flag) => (REMOTE ? flag !== false && (meta.category === 'Engine' || (remoteQ.targets[meta.id] || []).length > 0) : ES.configured(meta, scopeOf(meta.id), (core.targets()[meta.id] || []).length, flag));
// collectors: the console vault's credentials and the devices whose monitoring options use this collector
const engineEnv = (scriptId) => {
  // remote server: only the targets the central console assigned to it, with the credentials it received
  if (REMOTE) return { MC_EXTRA_TARGETS: JSON.stringify(remoteQ.targets[scriptId] || []), MC_TARGETS_ONLY: '1', MC_CREDS: infra.remoteCredentials.envFor() };
  const names = core.targets()[scriptId] || [];
  // devices monitored by a remote MonCastle server are collected there, not here
  const elsewhere = core.devices().filter((d) => core.serverOf(d.id) !== infra.LOCAL).map((d) => d.name);
  const st = scopeTargets(scriptId);
  const mine = [...new Set(names.concat(st.names))].filter((n) => !elsewhere.includes(n));
  const local = localDevices().map((d) => withEngineCred(st.scope, d));
  const sched = scheduler.list().find((x) => x.id === scriptId);
  const out = Object.assign({ MC_EXTRA_TARGETS: JSON.stringify(mine), MC_TARGET_INFO: targetInfo(mine), MC_EXCLUDE_TARGETS: JSON.stringify(elsewhere), MC_CREDS: credentials.envFor(local.concat(st.devices.filter((d) => !d.id)), core.chain) }, st.env);
  if (sched && !sched.configured) out.MC_NOT_CONFIGURED = '1';
  return out;
};
// central: what one remote server monitors, and the credentials its devices use (sealed in the sync answer)
function assignment(serverId) {
  const devs = core.devices().filter((d) => core.serverOf(d.id) === serverId);
  const ids = new Set(devs.map((d) => d.id));
  const conf = core.config();
  const sensors = conf.sensors.filter((x) => ids.has(x.device));
  const overrides = Object.fromEntries(sensors.filter((x) => conf.overrides[x.id]).map((x) => [x.id, { limits: conf.overrides[x.id].limits, interval: conf.overrides[x.id].interval, paused: conf.overrides[x.id].paused }]));
  const names = devs.map((d) => d.name);
  const targets = Object.fromEntries(Object.entries(core.targets()).map(([k, v]) => [k, v.filter((n) => names.includes(n))]).filter(([, v]) => v.length));
  const byCred = new Map();
  for (const d of devs) for (const k of ['snmp', 'http']) { const c = credentials.forDevice(d, core.chain(d.group), k); if (c) { const e = byCred.get(c.id) || Object.assign({}, c, { devices: [] }); e.devices.push(d.id); byCred.set(c.id, e); } }
  return { devices: devs.map((d) => ({ id: d.id, name: d.name, host: d.host, kind: d.kind, group: d.group, profile: d.profile || null, ports: d.ports || [], credentials: d.credentials || {} })), sensors, overrides, targets, credentials: { list: [...byCred.values()].map((c) => ({ kind: c.kind, name: c.name, fields: c.fields, secret: c.secret, devices: c.devices })), env: credentials.envFor(devs, core.chain) } };
}
// central: readings and engine results sent by a remote server
function ingestRemote(serverId, readings, results) {
  let ok = 0;
  for (const r of readings) if (r && r.id && r.reading && core.applyReading(String(r.id), r.reading, +r.t, serverId)) ok++;
  for (const r of results) {
    if (!r || typeof r.dataset !== 'string' || !/^[\w.-]{1,80}$/.test(r.dataset) || !Array.isArray(r.data)) continue;
    const meta = scripts.manifest().scripts.find((x) => x.id === r.script);
    if (!meta || meta.dataset !== r.dataset) continue;
    data.put(Object.assign({}, r, { data: r.data.slice(0, 20000) }), serverId);
    if (engines) engines.record(meta.id + '@' + serverId, engines.fromResult(r, { server: serverId }));
  }
  return { readings: ok, results: results.length };
}
infra.setLoad(() => core.serverLoad());
retention.attach(core, (id) => (core.device(id) || {}).name || null);
engines.setArchive((id, runs) => retention.archive('engines', null, runs.map((r) => Object.assign({ engine: id }, r))));
scheduler.setEnv(engineEnv);
scheduler.setConfigured(engineConfigured);
// engine info page: the sensors an engine feeds, the devices added to it and which vault credential each of them uses (names only)
const EI = require(path.join(cfg.publicDir, 'js', 'engineinfo.js'));
engines.setInfo((id) => {
  const t = core.tree();
  const sens = t.sensors.filter((x) => x.script === id);
  const byState = sens.reduce((a, x) => ((a[x.state] = (a[x.state] || 0) + 1), a), {});
  const meta = scripts.manifest().scripts.find((x) => x.id === id) || {};
  const kinds = EI.permissions(meta).credentials;
  const devIds = [...new Set(sens.map((x) => x.device))];
  const names = core.targets()[id] || [];
  const st = scopeTargets(id);
  const devs = devIds.map((d) => core.device(d)).filter(Boolean).concat(devicesNamed(names), st.devices.filter((d) => d.id)).filter((d, i, a) => a.findIndex((x) => x.id === d.id) === i);
  const creds = devs.slice(0, 300).map((d0) => { const d = withEngineCred(st.scope, d0); const eo = st.scope ? ES.credentialFor(st.scope, d0, core.chain(d0.group)) : null; for (const k of kinds.concat(eo && credentials.get(eo.credential) && !kinds.includes(credentials.get(eo.credential).kind) ? [credentials.get(eo.credential).kind] : [])) { const c = credentials.forDevice(d, core.chain(d.group), k === 'snmpv2' || k === 'snmpv3' ? 'snmp' : k); if (c) return { device: d.name, kind: c.kind, credential: c.name, from: eo && c.id === eo.credential ? eo.from : c.from }; } return { device: d.name, kind: kinds[0] || null, credential: null, from: 'engine account' }; });
  return { sensors: { total: sens.length, devices: devIds.length, byState }, extraTargets: names, scopedTargets: st.names.length, credentialUse: creds };
});
// Windows task engines run outside the console process, so they ask the console for the same context with a local token
const crypto = require('crypto');
const engineTokenFile = path.join(cfg.dataDir, 'secrets', 'engine.token');
let engineToken;
try { engineToken = fs.readFileSync(engineTokenFile, 'utf8').trim(); } catch (e) { engineToken = crypto.randomBytes(32).toString('base64url'); fs.mkdirSync(path.dirname(engineTokenFile), { recursive: true }); fs.writeFileSync(engineTokenFile, engineToken, { mode: 0o600 }); }

// ------------------------------------------------------------------ http helpers
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.woff2': 'font/woff2', '.webmanifest': 'application/manifest+json' };
const SEC_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'",
};
function send(res, status, body, headers) {
  const json = typeof body !== 'string' && !Buffer.isBuffer(body);
  res.writeHead(status, Object.assign({}, SEC_HEADERS, { 'Content-Type': json ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' }, headers));
  res.end(json ? JSON.stringify(body) : body);
}
function readRaw(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > 16 * 1024 * 1024) { reject(Object.assign(new Error('Body too large'), { status: 413 })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
  });
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > 1024 * 1024) { reject(Object.assign(new Error('Body too large'), { status: 413 })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch (e) { reject(Object.assign(new Error('Invalid JSON'), { status: 400 })); } });
  });
}
const cookies = (req) => Object.fromEntries((req.headers.cookie || '').split(';').map((c) => c.trim().split('=')).filter((x) => x[0]).map(([k, ...v]) => [k, decodeURIComponent(v.join('='))]));
const ipOf = (req) => (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
const tls = !!cfg.tlsInfo;
// maxAge null: a browser-session cookie (ends when the browser closes); "Keep me signed in" sets 30 days
const sidCookie = (v, maxAge) => `mc_sid=${v}; Path=/; HttpOnly; SameSite=Strict${tls ? '; Secure' : ''}${maxAge == null ? '' : '; Max-Age=' + maxAge}`;

function statusView(user) {
  return {
    product: 'RoboMate MonCastle', version: VERSION, mode: cfg.mode, consoleId: cfg.consoleId, url: (tls ? 'https' : 'http') + '://' + (cfg.publicName || 'localhost') + ':' + cfg.port,
    license: cfg.mode === 'demo' && !license.token() ? { state: 'valid', masked: '320RMC••••••••demo', edition: 'Demo', holder: 'Demo mode', readOnly: false } : license.view(),
    setupRequired: auth.setupRequired(), user: user ? Object.assign({}, user, { groups: auth.groups().filter((g) => g.members.includes(user.name)).map((g) => ({ id: g.id, name: g.name, grants: g.grants })) }) : null, overrideConfigured: override.configured(),
    release: { version: VERSION, released: release.current().released, update: release.lastCheck() },
    protection: { encrypted: sealed.enabled(), keyFrom: process.env.MC_MASTER_KEY ? 'environment' : 'file', packaged: !!process.env.MC_PACKAGED },
    repos: { scripts: cfg.github.owner + '/' + cfg.github.scriptsRepo, licenses: cfg.github.owner + '/' + cfg.github.licensesRepo, access: cfg.github.owner + '/' + cfg.github.accessRepo, console: cfg.github.owner + '/' + cfg.github.consoleRepo },
    scripts: scripts.info(), accessLog: access.status(),
  };
}
const readOnly = () => (cfg.mode === 'demo' && !license.token() ? false : license.readOnly());
const licensed = () => !readOnly();

// ------------------------------------------------------------------ API
async function api(req, res, url) {
  const route = url.pathname.replace(/^\/api\//, '');
  const method = req.method;
  const ip = ipOf(req);
  // alerts from other monitoring systems: token auth, no session (Monitor > Alert integrations)
  if (/^ingest\/[\w:-]{3,40}$/.test(route)) {
    if (method !== 'POST') return send(res, 405, { error: 'Send alerts with POST' });
    if (readOnly()) return send(res, 402, { error: 'The MonCastle licence is not valid; alerts are not accepted.' });
    const auth = String(req.headers.authorization || '');
    const token = /^Bearer\s+/i.test(auth) ? auth.replace(/^Bearer\s+/i, '').trim() : url.searchParams.get('token') || req.headers['x-moncastle-token'];
    let body;
    const ct = String(req.headers['content-type'] || '');
    if (/x-www-form-urlencoded/.test(ct)) { const raw = await readRaw(req); body = Object.fromEntries(new URLSearchParams(raw.toString('utf8'))); }
    else body = await readBody(req);
    try { const r = await monitor.ingest(route.slice(7), token, body); return send(res, 200, { ok: true, received: r.received != null ? r.received : 0, confirmed: !!r.confirmed, error: r.error || undefined }); }
    catch (e) { if (e.status === 401) access.add({ event: 'integration-denied', user: 'anonymous', ip, detail: 'Alert integration ' + route.slice(7) + ' refused' }); throw e; }
  }
  if (method !== 'GET' && req.headers['x-mc-request'] !== '1') return send(res, 403, { error: 'Missing X-MC-Request header' });
  const sid = cookies(req).mc_sid;
  const user = auth.session(sid);
  const need = (role) => {
    if (!user) throw Object.assign(new Error('Sign in first.'), { status: 401 });
    if (role === 'admin' && user.role !== 'admin') throw Object.assign(new Error('Administrators only.'), { status: 403 });
  };
  const audit = (event, detail) => access.add({ event, user: user ? user.name : 'anonymous', ip, detail });

  if (route === 'status' && method === 'GET') return send(res, 200, statusView(user));
  // the console's HTTPS certificate, for trusting it on other PCs (public information)
  if (route === 'tls' && method === 'GET') return send(res, 200, cfg.tlsInfo ? { https: true, source: cfg.tlsInfo.source, thumbprint: cfg.tlsInfo.thumbprint, names: cfg.tlsInfo.names, validTo: cfg.tlsInfo.validTo } : { https: false });
  if (route === 'tls/moncastle.cer' && method === 'GET') { if (!cfg.tlsInfo) return send(res, 404, { error: 'HTTPS is off' }); return send(res, 200, new (require('crypto').X509Certificate)(cfg.tlsInfo.cert).raw, { 'Content-Type': 'application/pkix-cert', 'Content-Disposition': 'attachment; filename="RoboMate-MonCastle.cer"' }); }
  if (/^engine\/(context|bundle|manifest)$/.test(route) && method === 'GET') {
    // local engines only: loopback address and the token in data/secrets/engine.token
    const tok = String(req.headers['x-mc-engine'] || '');
    if (!['127.0.0.1', '::1'].includes(ip) || tok.length !== engineToken.length || !crypto.timingSafeEqual(Buffer.from(tok), Buffer.from(engineToken))) return send(res, 403, { error: 'Engine token required' });
    // scripts held in memory: engine tasks read the collector list and their script from here, not from disk
    await scripts.ensure().catch(() => null);
    if (route === 'engine/manifest') return send(res, 200, { cache: scripts.memory() ? 'memory' : 'disk', scripts: scripts.manifest().scripts.filter((s) => s.kind === 'collector') });
    const id = String(url.searchParams.get('script') || '');
    const s = scripts.manifest().scripts.find((x) => x.id === id);
    if (!s) return send(res, 404, { error: 'Unknown script' });
    if (route === 'engine/bundle') {
      if (!scripts.memory()) return send(res, 409, { error: 'This console keeps the scripts on disk (scripts.cache = disk).' });
      let b; try { b = scripts.bundle(s); } catch (e) { await scripts.ensure(true).catch(() => null); b = scripts.bundle(s); }
      return send(res, 200, { script: s.path, sha256: s.sha256, host: scripts.hostScript(), payload: JSON.stringify(b) });
    }
    return send(res, 200, engineEnv(id));
  }

  if (route === 'infra/sync' && method === 'POST') {
    if (REMOTE) return send(res, 400, { error: 'This is a remote MonCastle server, not the central console' });
    if (readOnly()) return send(res, 402, { error: 'The central console licence is not valid' });
    const raw = await readRaw(req);
    return send(res, 200, infra.sync(req, raw, assignment, ingestRemote));
  }
  if (route === 'infra/status' && method === 'GET') return send(res, 200, REMOTE ? Object.assign({ role: 'remote', version: VERSION }, infra.remoteStatus()) : { role: 'central', version: VERSION });

  if (route === 'license' && method === 'POST') {
    // first activation is open (nobody can sign in before there is a licence); replacing one needs an admin
    if (license.token() && license.view().state === 'valid') need('admin');
    const b = await readBody(req);
    try { await license.set(b.token); audit('license', 'Licence verified ' + license.view().masked); }
    catch (e) { audit('license-failed', e.message); throw e; }
    return send(res, 200, license.view());
  }
  if (route === 'license' && method === 'DELETE') { need('admin'); license.clear(); audit('license', 'Licence removed'); return send(res, 200, license.view()); }

  if (route === 'license/override' && method === 'POST') {
    const b = await readBody(req);
    try { override.verify(b.password, ip); } catch (e) { access.add({ event: 'override-failed', user: 'administrator', ip, detail: e.message }); throw e; }
    const u = { name: 'administrator', role: 'admin', override: true };
    const s2 = auth.grant(u);
    access.add({ event: 'override', user: 'administrator', ip, detail: 'Signed in with the administrator override (licence ' + license.view().state + ')' });
    return send(res, 200, { user: u }, { 'Set-Cookie': sidCookie(s2, 8 * 3600) });
  }

  if (route === 'setup' && method === 'POST') {
    if (!licensed()) throw Object.assign(new Error('Activate a licence first.'), { status: 402 });
    const b = await readBody(req);
    auth.setup(b.username, b.password);
    const r = auth.login(b.username, b.password, ip);
    audit('setup', 'First administrator created: ' + b.username);
    return send(res, 200, { user: r.user }, { 'Set-Cookie': sidCookie(r.sid, cfg.session.idleMinutes * 60) });
  }
  if (route === 'login' && method === 'POST') {
    if (!licensed()) throw Object.assign(new Error('This console has no valid licence. Activate one, or use the administrator override.'), { status: 402 });
    const b = await readBody(req);
    try {
      const r = auth.login(b.username, b.password, ip, { remember: !!b.remember });
      access.add({ event: 'login', user: r.user.name, ip, detail: 'Signed in' + (b.remember ? ' (kept signed in for 30 days on this browser)' : '') });
      return send(res, 200, { user: r.user }, { 'Set-Cookie': sidCookie(r.sid, r.maxAge) });
    } catch (e) { access.add({ event: 'login-failed', user: String(b.username || '').slice(0, 60), ip, detail: e.message }); throw e; }
  }
  if (route === 'logout' && method === 'POST') { if (user) audit('logout', 'Signed out'); auth.logout(sid); return send(res, 200, { ok: true }, { 'Set-Cookie': sidCookie('', 0) }); }

  need();
  // no licence: nothing opens except for the administrator override session
  if (!licensed() && !user.override) throw Object.assign(new Error('Licence required.'), { status: 402 });

  if (route === 'license/key' && method === 'GET') { need('admin'); audit('license-reveal', 'Licence key revealed'); return send(res, 200, { key: license.key() }); }
  if (route === 'license/override-password' && method === 'POST') {
    need('admin');
    const b = await readBody(req);
    if (override.configured() && !user.override) override.verify(b.current, ip);
    override.set(b.password);
    audit('override-password', 'Administrator override password changed');
    return send(res, 200, { ok: true });
  }
  if (route === 'license/registry' && method === 'GET') { need('admin'); return send(res, 200, await license.registry()); }
  if (route === 'license/issue' && method === 'POST') {
    need('admin');
    const b = await readBody(req);
    const r = await license.issue(b.token, b, b.verify !== false);
    audit('license-issue', 'Prepared licence ' + r.entry.id + ' for ' + (r.entry.holder || 'unnamed') + ' (' + r.masked + ')');
    return send(res, 200, r);
  }
  if (route === 'release' && method === 'GET') { need('admin'); return send(res, 200, { current: release.current(), published: release.published(url.searchParams.get('outputDir') || undefined), defaults: { sourceDir: cfg.release.sourceDir, outputDir: cfg.release.outputDir, repo: cfg.github.owner + '/' + cfg.github.consoleRepo } }); }
  if (route === 'release/publish' && method === 'POST') {
    need('admin');
    const b = await readBody(req);
    const r = release.publish({ version: String(b.version || ''), notes: b.notes, sourceDir: b.sourceDir, outputDir: b.outputDir, user: user.name });
    audit('publish', 'Release ' + r.manifest.version + ' built in ' + r.outputDir);
    return send(res, 200, r);
  }
  if (route === 'update' && method === 'GET') return send(res, 200, { current: release.current(), lastCheck: release.lastCheck(), repo: cfg.github.owner + '/' + cfg.github.consoleRepo });
  if (route === 'update/check' && method === 'POST') { const r = await release.check(); audit('update-check', r.available ? 'Update ' + r.latest + ' available' : 'Up to date (' + r.current + ')'); return send(res, 200, r); }
  if (route === 'update/install' && method === 'POST') {
    need('admin');
    if (!licensed()) throw Object.assign(new Error('Updates need a valid licence.'), { status: 402 });
    const b = await readBody(req);
    const r = await release.install({ expect: b.version });
    audit('update', 'Updated ' + r.from + ' -> ' + r.to + ' (' + r.files + ' files); restarting');
    send(res, 200, Object.assign(r, { restarting: true }));
    await access.flush().catch(() => null);
    return release.restart();
  }
  if (route === 'datasets' && method === 'GET') return send(res, 200, demo ? demo.all() : data.all());
  if (route === 'history' && method === 'GET') { const h = Math.min(168, +url.searchParams.get('hours') || 24); return send(res, 200, demo ? demo.computeHistory(h, 5) : data.history(h)); }
  if (route === 'scripts' && method === 'GET') return send(res, 200, scripts.manifest());
  if (route === 'scripts/sync' && method === 'POST') { need('admin'); const r = await scripts.sync(); audit('sync', `Scripts synced: ${r.scripts} scripts, ${r.changed} downloaded`); return send(res, 200, r); }
  if (route === 'run' && method === 'POST') {
    if (readOnly() && !user.override) throw Object.assign(new Error('The licence is not valid; the console is read-only.'), { status: 402 });
    const b = await readBody(req);
    if (b.script === 'act.remote.code') throw Object.assign(new Error('Run code from Actions › Remote scripting.'), { status: 400 });
    // effective role: the lowest role the user has on the device groups of the targets (console role when none is monitored)
    const targets = devicesNamed(hostsOf(b.params || {}));
    const u = withAccess(user);
    const role = targets.length ? targets.map((d) => u.access(d.group)).reduce((a, r) => (RB.RANK[r] < RB.RANK[a] ? r : a), 'admin') : user.restricted && user.role !== 'admin' ? 'reader' : RB.norm(user.role);
    if (role === 'none') throw Object.assign(new Error('You have no access to ' + targets.filter((d) => u.access(d.group) === 'none').map((d) => d.name).join(', ') + '.'), { status: 403 });
    const job = scripts.run({ script: b.script, params: b.params || {}, secrets: b.secrets, whatIf: !!b.whatIf, confirm: b.confirm, user, role: user.override ? 'admin' : role, demo: demoRun, env: { MC_CREDS: credentials.envFor(targets, core.chain) } });
    audit('run', job.script + ' ' + Object.entries(job.params).map(([k, v]) => k + '=' + v).join(' ').slice(0, 300) + (job.whatIf ? ' (WhatIf)' : ''));
    return send(res, 200, { job });
  }
  // remote scripting: administrator-written code on onboarded devices (act.remote.code), audited and confirmed
  if (route === 'remote/run' && method === 'POST') {
    if (readOnly() && !user.override) throw Object.assign(new Error('The licence is not valid; the console is read-only.'), { status: 402 });
    need();
    const b = await readBody(req);
    const devs = [...new Set([].concat(b.devices || []))].map((id) => core.device(id)).filter(Boolean);
    if (devs.length !== [].concat(b.devices || []).length) throw Object.assign(new Error('One of the devices is not onboarded any more.'), { status: 400 });
    const low = devs.filter((d) => SENS.accessOf(d) !== 'admin');
    if (low.length) throw Object.assign(new Error(low.map((d) => d.name).join(', ') + (low.length > 1 ? ' have' : ' has') + ' a lower access level than Administrator. Change it in the device settings (Access) to run code there.'), { status: 403 });
    const err = REM.check({ devices: devs, language: b.language, code: b.code });
    if (err) throw Object.assign(new Error(err), { status: 400 });
    const u = withAccess(user);
    const role = user.override ? 'admin' : devs.map((d) => u.access(d.group)).reduce((a, r) => (RB.RANK[r] < RB.RANK[a] ? r : a), 'admin');
    if (role !== 'admin') { audit('remote-code-denied', b.language + ' on ' + devs.map((d) => d.name).join(', ').slice(0, 200)); throw Object.assign(new Error('Remote scripting needs the administrator role on every selected device.'), { status: 403 }); }
    if (!b.whatIf && String(b.confirm || '').trim() !== REM.confirmWord(devs)) throw Object.assign(new Error('Type ' + (devs.length === 1 ? 'the device name' : 'the number of devices') + ' exactly to confirm.'), { status: 400 });
    const names = devs.map((d) => d.name);
    const code = String(b.code).replace(/\r/g, '');
    const hash = crypto.createHash('sha256').update(code).digest('hex');
    const remoteDemo = demo ? (s, params, job) => { scripts.markRunning(); job.state = 'running'; setTimeout(() => { scripts.finish(job, REM.demoResult(devs, b.language, code, !!b.whatIf)); scripts.done(); }, 900 + Math.random() * 1200); } : null;
    const job = scripts.run({ script: 'act.remote.code', params: { ComputerName: names, Language: b.language, TimeoutSeconds: Math.min(3600, Math.max(10, +b.timeout || 300)) }, secrets: { Code: code }, whatIf: !!b.whatIf, confirm: names.join(', '), user, role: 'admin', demo: remoteDemo, env: { MC_CREDS: credentials.envFor(devs, core.chain), MC_TARGET_INFO: targetInfo(names) } });
    job.code = sanitize(code.slice(0, 8000)); job.codeSha256 = hash; job.language = b.language; job.devices = devs.map((d) => d.id);
    audit('remote-code', `${b.language} on ${names.length} device(s): ${names.join(', ').slice(0, 200)} · ${code.split('\n').length} lines · sha256 ${hash.slice(0, 16)}${job.whatIf ? ' (WhatIf)' : ''}`);
    return send(res, 200, { job });
  }
  // remote control: prepares an RDP file, an SSH link or the device's web address for the person's own client, and logs it.
  // Needs the contributor role on the device and its access level Administrator. No password is sent to the browser.
  if (route === 'remote/control' && method === 'POST') {
    const b = await readBody(req);
    const d = core.device(String(b.device || ''));
    if (!d) throw Object.assign(new Error('No such device'), { status: 404 });
    if (!RB.atLeast(user.override ? 'admin' : withAccess(user).access(d.group), 'contributor')) throw Object.assign(new Error('Remote control needs the contributor role on this device.'), { status: 403 });
    if (SENS.accessOf(d) !== 'admin') throw Object.assign(new Error(d.name + ' has the access level ' + SENS.accessOf(d) + '. Remote control needs Administrator: change it in the device settings (Access).'), { status: 403 });
    const m = RC.METHODS[String(b.method || '')];
    if (!m) throw Object.assign(new Error('Choose RDP, SSH or the web interface.'), { status: 400 });
    const c = credentials.forDevice(d, core.chain(d.group), m.cred), f = (c && c.fields) || {};
    const username = f.username ? (m.cred === 'windows' && f.domain ? f.domain + '\\' + f.username : f.username) : '';
    let sess; try { sess = RC.session(d, m.id, { port: b.port, username }); } catch (e) { throw Object.assign(new Error(e.message), { status: 400 }); }
    audit('remote-control', m.label + ' to ' + d.name + ' (' + sess.host + ':' + sess.port + ')' + (username ? ' as ' + username : ''));
    return send(res, 200, sess);
  }
  // Collect inventory now for one onboarded device (device page, Windows servers overview)
  if (route === 'inventory/collect' && method === 'POST') {
    if (readOnly() && !user.override) throw Object.assign(new Error('The licence is not valid; the console is read-only.'), { status: 402 });
    const b = await readBody(req);
    const d = core.device(String(b.device || ''));
    if (!d) throw Object.assign(new Error('No such device'), { status: 404 });
    if (!RB.atLeast(user.override ? 'admin' : withAccess(user).access(d.group), 'contributor')) throw Object.assign(new Error('You need the contributor role on this device.'), { status: 403 });
    const jobs = collectInventory(d, user);
    audit('inventory', 'Collect inventory for ' + d.name + ': ' + (jobs.map((j) => j.script).join(', ') || 'nothing to collect'));
    return send(res, 200, { device: d.id, jobs });
  }
  // Collect audit events now from devices added by hand (Inventory > Audit > Sources). The audit collector reads their event
  // logs; its rows replace only these servers' rows in audit.events (the engines' rows stay).
  if (route === 'audit/collect' && method === 'POST') {
    if (readOnly() && !user.override) throw Object.assign(new Error('The licence is not valid; the console is read-only.'), { status: 402 });
    const b = await readBody(req);
    const ids = (Array.isArray(b.devices) ? b.devices : []).map(String).slice(0, 200);
    const devs = ids.map((id) => core.device(id)).filter(Boolean);
    if (!devs.length) throw Object.assign(new Error('Choose at least one device.'), { status: 400 });
    for (const d of devs) if (!RB.atLeast(user.override ? 'admin' : withAccess(user).access(d.group), 'contributor')) throw Object.assign(new Error('You need the contributor role on ' + d.name + '.'), { status: 403 });
    const SETS = ['BadLogon', 'Lockout', 'RemoteLogon', 'ShutdownRestart', 'FileAccess', 'FileModify', 'FileDelete', 'FilePermission', 'PrintJob', 'NPS', 'All'];
    const sets = (Array.isArray(b.sets) ? b.sets : []).filter((x) => SETS.includes(x));
    const days = Math.min(90, Math.max(0.04, +b.days || 1));
    const names = devs.map((d) => d.host || d.name);
    let job;
    if (demo) {
      for (const d of devs) demo.auditOn(d);
      job = { id: 'demo-audit', state: 'done' };
    } else {
      if (REMOTE) throw Object.assign(new Error('Collect audit events on the central console.'), { status: 400 });
      const env = { MC_TARGET_INFO: targetInfo(devs.map((d) => d.name)), MC_CREDS: credentials.envFor(devs, core.chain) };
      job = scripts.run({ script: 'aud.events', params: { ComputerName: names, EventSet: sets.length ? sets : ['All'], Days: days }, user, role: 'admin', env, merge: 'Server' });
    }
    audit('audit', 'Collect audit events from ' + names.join(', ').slice(0, 200) + ' (' + (sets.join(', ') || 'all sets') + ', ' + days + ' day(s))');
    return send(res, 200, { devices: devs.map((d) => d.id), job: { id: job.id, state: job.state } });
  }
  // the text of one library file, read from memory (or the disk cache); for the read-only catalog
  if (route === 'scripts/source' && method === 'GET') {
    need();
    await scripts.ensure().catch(() => null);
    const t = scripts.source(String(url.searchParams.get('path') || ''));
    const p = String(url.searchParams.get('path') || ''), known = (scripts.manifest().scripts || []).some((x) => x.path === p) || (scripts.manifest().support || []).some((x) => x.path === p);
    return t == null ? send(res, 404, { error: known ? 'MonCastle could not fetch this script from GitHub yet; it retries on its own every few minutes.' : 'Not in the script library' }) : send(res, 200, { path: url.searchParams.get('path'), text: t, cache: scripts.memory() ? 'memory' : 'disk' });
  }
  if (route === 'jobs' && method === 'GET') return send(res, 200, scripts.jobs());
  // scheduled jobs: everyone signed in sees them; administrators create, change, run and delete them
  if (route === 'jobdefs' && method === 'GET') { need(); return send(res, 200, jobdefs.list()); }
  if (route === 'jobdefs/preview' && method === 'POST') { need(); return send(res, 200, jobdefs.preview(await readBody(req))); }
  if (route === 'jobdefs' && method === 'POST') {
    need('admin');
    if (readOnly() && !user.override) throw Object.assign(new Error('The licence is not valid; the console is read-only.'), { status: 402 });
    const b = await readBody(req);
    const d = jobdefs.save(b, user);
    audit('jobdef', (b.id ? 'Changed' : 'Created') + ' scheduled job ' + d.name + ' (' + d.script + ', ' + d.when + ', ' + d.target.mode + (d.credential ? ', run as ' + d.credentialName : '') + (d.whatIf ? ', WhatIf' : '') + ')');
    return send(res, 200, d);
  }
  const jd = /^jobdefs\/([\w-]+)(?:\/(run|enable|disable))?$/.exec(route);
  if (jd && method === 'POST' && jd[2]) {
    need('admin');
    if (jd[2] === 'run') { if (readOnly() && !user.override) throw Object.assign(new Error('The licence is not valid; the console is read-only.'), { status: 402 }); const r = jobdefs.runNow(jd[1], user.name); return send(res, 200, { run: r, job: jobdefs.get(jd[1]) }); }
    const d = jobdefs.setEnabled(jd[1], jd[2] === 'enable');
    audit('jobdef', (jd[2] === 'enable' ? 'Turned on' : 'Paused') + ' scheduled job ' + d.name);
    return send(res, 200, d);
  }
  if (jd && method === 'DELETE' && !jd[2]) { need('admin'); const d = jobdefs.remove(jd[1]); audit('jobdef', 'Deleted scheduled job ' + d.name); return send(res, 200, { ok: true }); }
  if (route.startsWith('jobs/') && method === 'GET') { const j = scripts.job(decodeURIComponent(route.slice(5))); return j ? send(res, 200, j) : send(res, 404, { error: 'No such job' }); }
  if (route === 'access-log' && method === 'GET') return send(res, 200, access.view());
  if (route === 'access-log' && method === 'POST') { const b = await readBody(req); audit(String(b.event || 'view').slice(0, 20), String(b.detail || '').slice(0, 200)); return send(res, 200, { ok: true }); }
  if (route === 'engines' && method === 'GET') return send(res, 200, await engines.list(url.searchParams.has('refresh')));
  if (route === 'retention' && method === 'GET') { need('admin'); return send(res, 200, { policy: retention.policy(), lastRun: retention.lastRun(), usage: retention.usage() }); }
  if (route === 'retention' && method === 'POST') {
    need('admin');
    const b = await readBody(req);
    if (b.action === 'run') { const r = retention.run(user.name); audit('retention', 'Retention run: ' + r.sensorRows + ' rows archived'); return send(res, 200, { lastRun: r, usage: retention.usage(), policy: retention.policy() }); }
    if (b.action === 'policy') { const p = retention.setPolicy(b.policy || {}); audit('retention', 'Retention policy changed'); return send(res, 200, { policy: p, lastRun: retention.lastRun(), usage: retention.usage() }); }
    throw Object.assign(new Error('Unknown action'), { status: 400 });
  }
  if (route === 'archive' && method === 'GET') {
    // sensor history and alarms: any unrestricted user; access log, engine runs and collector snapshots: administrators
    const q = Object.fromEntries(url.searchParams);
    if (['access', 'engines', 'datasets'].includes(q.kind) || user.restricted) need('admin'); else need();
    const r = retention.read(q);
    audit('archive', 'Opened archive ' + q.kind + ' ' + q.month + (q.format === 'csv' ? ' (CSV export)' : ''));
    if (q.format === 'csv') {
      const cols = [...new Set(r.records.flatMap((x) => Object.keys(x)))];
      const cell = (v) => { const t = v == null ? '' : typeof v === 'object' ? JSON.stringify(v) : String(v); return /[",\n\r]/.test(t) || /^[=+\-@]/.test(t) ? '"' + t.replace(/^([=+\-@])/, "'$1").replace(/"/g, '""') + '"' : t; };
      return send(res, 200, [cols.join(',')].concat(r.records.map((x) => cols.map((c) => cell(x[c])).join(','))).join('\r\n'), { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="moncastle-' + q.kind + '-' + q.month + '.csv"' });
    }
    return send(res, 200, r);
  }
  if (route === 'infra' && method === 'GET') { need(); return send(res, 200, { role: infra.role, servers: infra.list() }); }
  if (route === 'infra' && method === 'POST') {
    need('admin');
    const b = await readBody(req);
    const a = String(b.action || ''), id = String(b.id || '');
    let r;
    if (a === 'add') r = infra.add(b, user.name);
    else if (a === 'rotate') r = infra.rotate(id);
    else if (a === 'update') r = { server: infra.update(id, b) };
    else if (a === 'remove') { infra.remove(id); r = { ok: true }; }
    else throw Object.assign(new Error('Unknown action'), { status: 400 });
    audit('infra', a + ' MonCastle server ' + (b.name || id));
    return send(res, 200, r);
  }
  // the machines an engine reads (Monitoring engines > engine > Targets)
  if (route === 'engines/scope' && method === 'GET') {
    need('reader');
    const id = String(url.searchParams.get('id') || ''), meta = scripts.manifest().scripts.find((x) => x.id === id);
    if (!meta) return send(res, 404, { error: 'Unknown engine' });
    const fam = ES.familyOf(meta), sc = scopeOf(id);
    const st = fam ? scopeTargets(id) : { names: [] };
    return send(res, 200, { id, family: fam, scope: sc, describe: ES.describe(meta, sc), configured: (scheduler.list().find((x) => x.id === id) || {}).configured, preview: { assigned: (core.targets()[id] || []).length, scoped: st.names.length } });
  }
  if (route === 'engines/scope' && method === 'POST') {
    need('admin');
    if (readOnly() && !user.override) throw Object.assign(new Error('The licence is not valid; the console is read-only.'), { status: 402 });
    const b = await readBody(req);
    const id = String(b.id || ''), meta = scripts.manifest().scripts.find((x) => x.id === id);
    if (!meta) return send(res, 404, { error: 'Unknown engine' });
    let sc; try { sc = ES.normalize(meta, b.scope); } catch (e) { return send(res, 400, { error: e.message }); }
    engineScopes[id] = sc; sealed.writeJson(scopeFile, engineScopes);
    audit('engine', 'Targets of ' + id + ': ' + ES.describe(meta, sc));
    return send(res, 200, { id, family: ES.familyOf(meta), scope: sc, describe: ES.describe(meta, sc), configured: (scheduler.list().find((x) => x.id === id) || {}).configured, preview: { assigned: (core.targets()[id] || []).length, scoped: scopeTargets(id).names.length } });
  }
  if (route.startsWith('engines/') && method === 'GET') return send(res, 200, await engines.detail(decodeURIComponent(route.slice(8))));
  if (route === 'engines' && method === 'POST') {
    need('admin');
    if (readOnly() && !user.override) throw Object.assign(new Error('The licence is not valid; the console is read-only.'), { status: 402 });
    const b = await readBody(req);
    const op = String(b.action || ''), id = String(b.id || 'All');
    const r = await engines.action(op, id, { every: b.every });
    audit('engine', op + ' ' + (id === 'All' ? 'all engines' : id) + (op === 'interval' ? ' every ' + b.every : ''));
    return send(res, 200, r);
  }
  if (route === 'osreleases' && method === 'GET') { need('reader'); return send(res, 200, osreleases.catalog()); }
  if (route === 'osreleases/refresh' && method === 'POST') { need('admin'); const c = await osreleases.refresh(); audit('osreleases', 'Checked the newest OS releases online' + (c.error ? ' (' + c.error.slice(0, 200) + ')' : '')); return send(res, 200, c); }
  if (route === 'monitor' && (method === 'GET' || method === 'POST')) {
    const b = method === 'POST' ? await readBody(req) : Object.fromEntries(url.searchParams);
    const op = String(b.op || '');
    if (method === 'GET' && MC.AUDIT[op]) return send(res, 405, { error: 'Use POST for changes' });
    if (MC.AUDIT[op] && readOnly() && !user.override) throw Object.assign(new Error('The licence is not valid; monitoring is read-only.'), { status: 402 });
    const r = await MC.handle(core, monHost, op, b, withAccess(user));
    if (MC.AUDIT[op]) audit('monitor', MC.auditText(op, b));
    return send(res, 200, r);
  }
  if (route === 'schedules' && method === 'GET') return send(res, 200, scheduler.list());
  if (route === 'schedules' && method === 'POST') { need('admin'); const b = await readBody(req); const r = scheduler.set(String(b.id), String(b.every), b.enabled !== false); audit('schedule', b.id + ' every ' + b.every + (b.enabled === false ? ' (paused)' : '')); return send(res, 200, r); }
  if (route === 'users' && method === 'GET') return send(res, 200, auth.list());
  if (route === 'users' && method === 'POST') { need('admin'); const b = await readBody(req); auth.addUser(b); audit('user', 'Added ' + b.username + ' (' + b.role + ')'); return send(res, 200, auth.list()); }
  if (route.startsWith('users/') && method === 'POST') { need('admin'); const n = decodeURIComponent(route.slice(6)); const b = await readBody(req); auth.updateUser(n, b, user.name); audit('user', 'Changed ' + n + (b.role ? ' role ' + RB.norm(b.role) : '') + (b.restricted != null ? (b.restricted ? ' restricted' : ' unrestricted') : '') + (b.email != null ? ' e-mail' : '') + (b.password ? ' password reset' : '')); return send(res, 200, auth.list()); }
  if (route === 'usergroups' && method === 'GET') return send(res, 200, { groups: auth.groups(), matrix: RB.MATRIX, roles: RB.ROLES });
  if (route === 'usergroups' && method === 'POST') { need('admin'); const b = await readBody(req); const g = auth.setGroup(b); audit('usergroup', (b.id ? 'Changed' : 'Added') + ' user group ' + g.name + ': ' + g.members.length + ' members, ' + g.grants.map((x) => x.role + ' on ' + x.scope).join(', ')); return send(res, 200, { groups: auth.groups() }); }
  if (route.startsWith('usergroups/') && method === 'DELETE') { need('admin'); const id = decodeURIComponent(route.slice(11)); auth.removeGroup(id); audit('usergroup', 'Removed user group ' + id); return send(res, 200, { groups: auth.groups() }); }
  const ins = /^(dashboards|reports)(?:\/(.+))?$/.exec(route);
  if (ins && method === 'GET' && !ins[2]) return send(res, 200, insights.list(ins[1], user));
  if (ins && method === 'POST' && !ins[2]) { const b = await readBody(req); const x = insights.save(ins[1], b, user); audit(ins[1].slice(0, -1), (b.id ? 'Changed ' : 'Saved ') + ins[1].slice(0, -1) + ' ' + x.name + (x.shared ? ' (shared)' : '')); return send(res, 200, x); }
  if (ins && method === 'DELETE' && ins[2]) { const x = insights.remove(ins[1], decodeURIComponent(ins[2]), user); audit(ins[1].slice(0, -1), 'Deleted ' + ins[1].slice(0, -1) + ' ' + x.name); return send(res, 200, { ok: true }); }
  if (route === 'credentials' && method === 'GET') {
    const list = credentials.list(withAccess(user), auth.groups());
    const used = {};
    for (const d of core.devices()) for (const id of Object.values(d.credentials || {})) (used[id] = used[id] || []).push(d.name);
    return send(res, 200, list.map((c) => Object.assign(c, { usedBy: used[c.id] || [], editable: credentials.editable(credentials.get(c.id), user) })));
  }
  if (route === 'credentials' && method === 'POST') {
    const grantsContributor = auth.groups().some((g) => g.members.includes(user.name) && g.grants.some((x) => RB.atLeast(x.role, 'contributor')));
    if (!RB.atLeast(RB.norm(user.role), 'contributor') && !grantsContributor) throw Object.assign(new Error('Readers cannot save credentials.'), { status: 403 });
    if (readOnly() && !user.override) throw Object.assign(new Error('The licence is not valid; the console is read-only.'), { status: 402 });
    const b = await readBody(req);
    if (b.id) { const old = credentials.get(String(b.id)); if (!old) throw Object.assign(new Error('No such credential'), { status: 404 }); if (!credentials.editable(old, user)) throw Object.assign(new Error('Only its creator or an administrator can change this credential.'), { status: 403 }); }
    if (user.role !== 'admin') {
      // contributors assign their credentials only where they are contributors, never as the probe-wide default
      const u = withAccess(user);
      if ((b.assign || {}).all) throw Object.assign(new Error('Only administrators can make a probe-wide default.'), { status: 403 });
      for (const g of (b.assign || {}).groups || []) if (!RB.atLeast(u.access(g), 'contributor')) throw Object.assign(new Error('You cannot assign credentials to group ' + g + '.'), { status: 403 });
      b.userGroups = (b.userGroups || []).filter((id) => auth.groups().some((g) => g.id === id && g.members.includes(user.name)));
    }
    const c = credentials.upsert(b, user.name);
    audit('credential', (b.id ? 'Changed' : 'Added') + ' ' + c.kind + ' credential ' + c.name + (c.private ? ' (private)' : '') + (c.assign.all ? ', probe default' : '') + (c.assign.groups.length ? ', groups ' + c.assign.groups.join(' ') : ''));
    return send(res, 200, credentials.list(withAccess(user), auth.groups()).find((x) => x.id === c.id) || { id: c.id, name: c.name, kind: c.kind });
  }
  if (route.startsWith('credentials/') && route.endsWith('/test') && method === 'POST') {
    const id = decodeURIComponent(route.slice(12, -5)); const c = credentials.get(id);
    if (!c || !monHost.credentialOk(id, user)) throw Object.assign(new Error('No such credential'), { status: 404 });
    const b = await readBody(req);
    const r = demo ? { ok: true, host: String(b.host || ''), at: new Date().toISOString(), ms: 42, message: 'Demo mode: test simulated' } : await credentials.test(id, b.host);
    audit('credential', 'Tested ' + c.name + ' against ' + r.host + ': ' + (r.ok ? 'ok' : 'failed'));
    return send(res, 200, r);
  }
  if (route.startsWith('credentials/') && method === 'DELETE') {
    const id = decodeURIComponent(route.slice(12)); const c = credentials.get(id);
    if (!c) throw Object.assign(new Error('No such credential'), { status: 404 });
    if (!credentials.editable(c, user)) throw Object.assign(new Error('Only its creator or an administrator can delete this credential.'), { status: 403 });
    const users = core.devices().filter((d) => Object.values(d.credentials || {}).includes(id));
    if (users.length) throw Object.assign(new Error(c.name + ' is still set on ' + users.map((d) => d.name).join(', ') + '. Change those devices first.'), { status: 409 });
    credentials.remove(id); audit('credential', 'Deleted credential ' + c.name);
    return send(res, 200, { ok: true });
  }
  if (route.startsWith('users/') && method === 'DELETE') { need('admin'); const n = decodeURIComponent(route.slice(6)); auth.removeUser(n, user.name); audit('user', 'Removed ' + n); return send(res, 200, auth.list()); }
  return send(res, 404, { error: 'Not found' });
}

// ------------------------------------------------------------------ static files
function serveStatic(req, res, url) {
  let p = decodeURIComponent(url.pathname);
  if (p === '/') p = '/index.html';
  const file = path.normalize(path.join(cfg.publicDir, p));
  if (!file.startsWith(cfg.publicDir + path.sep)) return send(res, 403, 'Forbidden');
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return send(res, 404, 'Not found');
    res.writeHead(200, Object.assign({}, SEC_HEADERS, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': p === '/index.html' ? 'no-cache' : 'max-age=300' }));
    fs.createReadStream(file).pipe(res);
  });
}

async function handler(req, res) {
  const url = new URL(req.url, 'http://localhost');
  try {
    if (REMOTE && !url.pathname.startsWith('/api/infra/') && !url.pathname.startsWith('/api/engine/') && !url.pathname.startsWith('/img/')) return send(res, 200, remotePage(), { 'Content-Type': 'text/html; charset=utf-8' });
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Method not allowed');
    return serveStatic(req, res, url);
  } catch (e) {
    const status = e.status && e.status >= 400 && e.status < 600 ? e.status : 500;
    if (status >= 500) log('error ' + req.method + ' ' + url.pathname + ': ' + (e.stack || e.message));
    return send(res, status, { error: sanitize(e.message) });
  }
}

// a remote MonCastle server has no console of its own: one status page, managed from the central console
function remotePage() {
  const r = infra.remoteStatus();
  const e = (x) => String(x == null ? '' : x).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MonCastle server ${e(cfg.consoleId)}</title><link rel="icon" href="/img/moncastle-icon.svg"><meta http-equiv="refresh" content="30"><style>body{font:15px/1.5 system-ui,Segoe UI,sans-serif;margin:0;background:#f4f6f9;color:#16202c}main{max-width:620px;margin:8vh auto;padding:28px;background:#fff;border-radius:14px;box-shadow:0 2px 12px #0001}h1{font-size:20px;margin:0 0 4px}dl{display:grid;grid-template-columns:150px 1fr;gap:6px 12px}dt{color:#5b6775}.ok{color:#0b7a0b}.bad{color:#b42318}img{width:44px;vertical-align:middle;margin-right:10px}@media(prefers-color-scheme:dark){body{background:#0e141b;color:#e6edf3}main{background:#16202a}dt{color:#9aa7b4}}</style></head><body><main><h1><img src="/img/moncastle-icon.svg" alt="">MonCastle server ${e(cfg.consoleId)}</h1><p>This is a remote MonCastle server. It is managed from the central console; open that console to see its devices, sensors and alarms.</p><dl><dt>Central console</dt><dd><a href="${e(r.central)}">${e(r.central)}</a></dd><dt>Server id</dt><dd>${e(r.id)}</dd><dt>Last sync</dt><dd class="${r.error ? 'bad' : 'ok'}">${e(r.lastSync || 'never')}${r.error ? ' · ' + e(r.error) : ''}</dd><dt>Devices</dt><dd>${r.devices}</dd><dt>Probe sensors</dt><dd>${r.sensors}</dd><dt>Version</dt><dd>${e(VERSION)}</dd></dl></main></body></html>`;
}

// ------------------------------------------------------------------ start
async function main() {
  scripts.loadManifest();
  // with HTTPS, the same port also answers plain http:// requests with a redirect to https:// (first byte 0x16 = TLS)
  let server;
  if (tls) {
    const t = cfg.tlsInfo;
    const secure = https.createServer({ cert: t.cert, key: t.key, passphrase: t.passphrase, minVersion: 'TLSv1.2' }, handler);
    const plain = http.createServer((req, res) => { const host = String(req.headers.host || cfg.publicName + ':' + cfg.port).replace(/[^\w.:\-\[\]]/g, ''); res.writeHead(301, { Location: 'https://' + host + (req.url || '/'), 'Cache-Control': 'no-store' }); res.end(); });
    server = require('net').createServer((sock) => {
      sock.on('error', () => sock.destroy());
      sock.once('data', (b) => {
        sock.pause();
        sock.unshift(b);
        (b[0] === 0x16 ? secure : plain).emit('connection', sock);
        process.nextTick(() => sock.resume());
      });
    });
  } else server = http.createServer(handler);
  server.listen(cfg.port, cfg.host, () => log(`MonCastle ${VERSION} (${cfg.mode}) listening on port ${cfg.port}: open ${tls ? 'https' : 'http'}://${cfg.publicName || 'localhost'}:${cfg.port}`));
  license.start();
  access.start();
  engines.start();
  monitor.start();
  infra.setEngines(() => scheduler.list().filter((x) => x.enabled).length);
  infra.start();
  retention.start();
  osreleases.start();
  if (!REMOTE) jobdefs.start();
  if (REMOTE) {
    scheduler.setSkip((id) => !(remoteQ.targets[id] || []).length);
    infra.startRemote({ core, readings: remoteQ.readings, results: remoteQ.results, onAssigned: (a) => { remoteQ.targets = a.targets || {}; } });
  }
  if (cfg.mode === 'live') {
    scheduler.start();
    // The script library is fetched from GitHub on its own: at start, every hour (memory) or syncEveryHours (disk cache),
    // whenever a script that is needed is missing, and every 5 minutes after a failed attempt until one succeeds.
    let retry = null;
    const syncNow = () => {
      if (license.readOnly()) return;
      scripts.sync().then((r) => { clearTimeout(retry); retry = null; if (r.changed) access.add({ event: 'sync', user: 'system', ip: '127.0.0.1', detail: `Scripts fetched from GitHub: ${r.scripts} scripts, ${r.changed} changed` }); })
        .catch((e) => { log('script sync failed (retrying in 5 minutes): ' + e.message); if (!retry) retry = setTimeout(() => { retry = null; syncNow(); }, 5 * 6e4); if (retry.unref) retry.unref(); });
    };
    if (cfg.scripts.syncOnStart !== false || scripts.memory()) setTimeout(syncNow, 1500).unref();
    setInterval(syncNow, (scripts.memory() ? Math.min(1, cfg.scripts.syncEveryHours) : cfg.scripts.syncEveryHours) * 36e5).unref();
  }
  if (cfg.mode === 'live') {
    const upd = () => licensed() && release.check().then((r) => r.available && log('update available: ' + r.current + ' -> ' + r.latest)).catch(() => null);
    setTimeout(upd, 60000).unref();
    setInterval(upd, cfg.update.checkEveryHours * 36e5).unref();
  }
  const stop = () => { log('stopping'); monitor.persist(); access.flush().finally(() => process.exit(0)); setTimeout(() => process.exit(0), 5000).unref(); };
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
}
main();
