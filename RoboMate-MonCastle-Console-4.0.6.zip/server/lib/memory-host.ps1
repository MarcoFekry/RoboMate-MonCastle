# RoboMate MonCastle - runs one library script from memory (the default: nothing from the script library is saved on disk).
# The console starts   pwsh -NoProfile -NonInteractive -EncodedCommand <this file>   and writes one JSON line to stdin:
#   { "script": "<path in the repo>", "root": "<virtual folder>", "files": { "<path>": "<base64>", ... } }
# The console fetched every file from GitHub and checked its sha256 before sending it. Parameters arrive in MC_PARAMS
# (JSON) and secrets in MC_SECRET_*, exactly as with the on-disk runner (Modules/MonCastle.Core/Invoke-MCScript.ps1).
$ErrorActionPreference = 'Stop'
$in = [Console]::In.ReadLine() | ConvertFrom-Json
$global:MCMemoryRoot = [string]$in.root
$global:MCMemoryFiles = @{}
foreach ($p in $in.files.PSObject.Properties) { $global:MCMemoryFiles[$p.Name] = [string]$p.Value }
$in = $null

# script text -> runnable text: $PSScriptRoot becomes the script's virtual folder, #Requires lines are checked here
$global:MCConvertMemoryCode = {
    param([string]$Rel, [string]$Text)
    $dir = (($global:MCMemoryRoot.TrimEnd('/', '\') + '/' + (Split-Path $Rel -Parent)) -replace '\\', '/').TrimEnd('/')
    $Text = [regex]::Replace($Text, '(?im)^\s*#Requires\s+-Version\s+(\d+)(\.\d+)?.*$', {
            param($m) if ($PSVersionTable.PSVersion.Major -lt [int]$m.Groups[1].Value) { throw "$Rel needs PowerShell $($m.Groups[1].Value) or later." }; '' })
    $lit = '$(''' + $dir.Replace("'", "''") + ''')'
    [regex]::Replace($Text, '\$PSScriptRoot\b', { param($m) $lit }, 'IgnoreCase')
}
function script:MemText([string]$Rel) {
    if (-not $global:MCMemoryFiles.ContainsKey($Rel)) { throw "$Rel is not in the script library." }
    [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($global:MCMemoryFiles[$Rel]))
}

# the shared module, built from its text; Import-Module of MonCastle.Core by path is then a no-op
$core = 'Modules/MonCastle.Core/MonCastle.Core.psm1'
New-Module -Name MonCastle.Core -ScriptBlock ([scriptblock]::Create((& $global:MCConvertMemoryCode $core (MemText $core)))) | Import-Module -Global -Force -DisableNameChecking
function global:Import-Module {
    if ("$($args[0])" -match 'MonCastle\.Core(\.psd1|\.psm1)?$') { return }
    Microsoft.PowerShell.Core\Import-Module @args
}

# parameters: converted to the types declared in the script's param() block, as Invoke-MCScript.ps1 does
$rel = [string]$env:MC_SCRIPT
$text = & $global:MCConvertMemoryCode $rel (MemText $rel)
$values = @{}
if ($env:MC_PARAMS) { ($env:MC_PARAMS | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $values[$_.Name] = $_.Value } }
$env:MC_PARAMS = $null
$ast = [System.Management.Automation.Language.Parser]::ParseInput($text, [ref]$null, [ref]$null)
$declared = @{}
foreach ($p in $ast.ParamBlock.Parameters) { $declared[$p.Name.VariablePath.UserPath] = $p.StaticType }
$splat = @{}
foreach ($k in $values.Keys) {
    if (-not $declared.ContainsKey($k)) { throw "Unknown parameter '$k' for $rel" }
    $t = $declared[$k]; $v = $values[$k]
    if ($null -eq $v -or "$v" -eq '') { continue }
    if ($t -eq [switch]) { if ([bool]$v) { $splat[$k] = $true }; continue }
    if ($t.IsArray) {
        $items = if ($v -is [array]) { $v } else { "$v" -split '[,;\r\n]+' | ForEach-Object { $_.Trim() } | Where-Object { $_ } }
        $splat[$k] = [System.Management.Automation.LanguagePrimitives]::ConvertTo(@($items), $t)
    } else { $splat[$k] = [System.Management.Automation.LanguagePrimitives]::ConvertTo($v, $t) }
}
$binding = $ast.ParamBlock.Attributes | Where-Object { $_.TypeName.Name -eq 'CmdletBinding' }
$shouldProcess = [bool]($binding.NamedArguments | Where-Object { $_.ArgumentName -eq 'SupportsShouldProcess' })
if ($shouldProcess -and $env:MC_CONFIRMED -eq '1') { $splat['Confirm'] = $false }
if ($shouldProcess -and $env:MC_WHATIF -eq '1') { $splat['WhatIf'] = $true }
if ($PSStyle) { $PSStyle.OutputRendering = 'PlainText' }
& ([scriptblock]::Create($text)) @splat
