// RoboMate MonCastle desktop UI kit, shared by the launcher and the setup app: light and dark palettes that follow
// Windows (or the user's choice), a dark title bar and Mica backdrop on Windows 11, and a few owner-drawn controls
// (cards, buttons, navigation items, status pills, toggle switches) so both apps look like current Windows apps
// instead of classic WinForms.
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace MonCastle.Ui;

internal enum ThemeMode { System, Light, Dark }

internal static class Theme
{
    public static ThemeMode Mode { get; private set; } = ThemeMode.System;
    public static bool Dark { get; private set; } = SystemDark();
    public static event Action? Changed;

    // RoboMate emblem colors (same in both themes)
    public static readonly Color Navy = Color.FromArgb(0x0A, 0x46, 0x7B), Blue = Color.FromArgb(0x1A, 0x84, 0xD2),
        Teal = Color.FromArgb(0x0A, 0x7D, 0x97), Green = Color.FromArgb(0x12, 0xC0, 0x8F);

    public static Color Page => Dark ? Color.FromArgb(0x0E, 0x16, 0x22) : Color.FromArgb(0xF3, 0xF6, 0xFA);
    public static Color Surface => Dark ? Color.FromArgb(0x17, 0x22, 0x31) : Color.White;
    public static Color Surface2 => Dark ? Color.FromArgb(0x1E, 0x2B, 0x3C) : Color.FromArgb(0xF7, 0xF9, 0xFC);
    public static Color Sidebar => Dark ? Color.FromArgb(0x0B, 0x12, 0x1C) : Color.FromArgb(0x0C, 0x2A, 0x4A);
    public static Color SidebarInk => Color.FromArgb(0xD7, 0xE4, 0xF2);
    public static Color SidebarMuted => Color.FromArgb(0x8F, 0xA6, 0xBF);
    public static Color SidebarHover => Color.FromArgb(28, 255, 255, 255);
    public static Color SidebarSelected => Color.FromArgb(44, 255, 255, 255);
    public static Color Ink => Dark ? Color.FromArgb(0xE6, 0xED, 0xF5) : Color.FromArgb(0x13, 0x22, 0x35);
    public static Color Muted => Dark ? Color.FromArgb(0x93, 0xA4, 0xB8) : Color.FromArgb(0x5B, 0x6B, 0x80);
    public static Color Line => Dark ? Color.FromArgb(0x2A, 0x3A, 0x4E) : Color.FromArgb(0xDD, 0xE4, 0xEC);
    public static Color Accent => Dark ? Color.FromArgb(0x4C, 0xA8, 0xEE) : Blue;
    public static Color AccentHover => Dark ? Color.FromArgb(0x6B, 0xB9, 0xF2) : Color.FromArgb(0x15, 0x70, 0xB5);
    public static Color Good => Dark ? Color.FromArgb(0x3C, 0xD3, 0x9C) : Color.FromArgb(0x0F, 0x9D, 0x6E);
    public static Color Warn => Dark ? Color.FromArgb(0xF2, 0xB8, 0x3A) : Color.FromArgb(0xC7, 0x8A, 0x00);
    public static Color Bad => Dark ? Color.FromArgb(0xF0, 0x6A, 0x6A) : Color.FromArgb(0xD1, 0x3B, 0x3B);
    public static Color Idle => Dark ? Color.FromArgb(0x6E, 0x80, 0x95) : Color.FromArgb(0x8A, 0x97, 0xA8);
    public static Color Console => Dark ? Color.FromArgb(0x0A, 0x10, 0x18) : Color.FromArgb(0x0F, 0x1B, 0x2A);

    public static Font Body => new("Segoe UI", 9.75f);
    public static Font Title => new("Segoe UI Semibold", 17f);
    public static Font Heading => new("Segoe UI Semibold", 12f);
    public static Font Strong => new("Segoe UI Semibold", 9.75f);
    public static Font Small => new("Segoe UI", 8.75f);
    // Segoe Fluent Icons on Windows 11, Segoe MDL2 Assets on Windows 10 / Server (same code points)
    public static readonly string IconFamily = FontInstalled("Segoe Fluent Icons") ? "Segoe Fluent Icons" : "Segoe MDL2 Assets";
    public static Font Icons(float size = 12f) => new(IconFamily, size);

    public static void Set(ThemeMode mode)
    {
        Mode = mode;
        var dark = mode == ThemeMode.Dark || (mode == ThemeMode.System && SystemDark());
        if (dark == Dark) return;
        Dark = dark;
        Changed?.Invoke();
    }

    public static bool SystemDark()
    {
        try { return Registry.GetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize", "AppsUseLightTheme", 1) is int v && v == 0; }
        catch { return false; }
    }

    // follow Windows when the user switches between light and dark while the app is open
    public static void WatchSystem()
    {
        SystemEvents.UserPreferenceChanged += (_, e) => { if (e.Category == UserPreferenceCategory.General && Mode == ThemeMode.System) Set(ThemeMode.System); };
    }

    [DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);

    // dark or light title bar to match, and the Mica backdrop on Windows 11 (ignored on older Windows)
    public static void Frame(Form form)
    {
        if (!form.IsHandleCreated) { form.HandleCreated += (_, _) => Frame(form); return; }
        try
        {
            var dark = Dark ? 1 : 0;
            DwmSetWindowAttribute(form.Handle, 20, ref dark, sizeof(int));          // DWMWA_USE_IMMERSIVE_DARK_MODE
            var round = 2;
            DwmSetWindowAttribute(form.Handle, 33, ref round, sizeof(int));         // DWMWA_WINDOW_CORNER_PREFERENCE: round
            var caption = ColorTranslator.ToWin32(Page);
            DwmSetWindowAttribute(form.Handle, 35, ref caption, sizeof(int));       // DWMWA_CAPTION_COLOR
        }
        catch { }
    }

    static bool FontInstalled(string name)
    {
        try { using var f = new Font(name, 10f); return f.Name.Equals(name, StringComparison.OrdinalIgnoreCase); }
        catch { return false; }
    }

    public static GraphicsPath Round(RectangleF r, float radius)
    {
        var p = new GraphicsPath();
        var d = Math.Max(1f, Math.Min(radius * 2, Math.Min(r.Width, r.Height)));
        p.AddArc(r.X, r.Y, d, d, 180, 90);
        p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure();
        return p;
    }

    public static Color Mix(Color a, Color b, float t) =>
        Color.FromArgb((int)(a.R + (b.R - a.R) * t), (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
}

// Segoe Fluent Icons / MDL2 code points used by the apps
internal static class Glyph
{
    public const string Home = "", Play = "", Stop = "", Settings = "", Globe = "", Document = "",
        Folder = "", Copy = "", Refresh = "", Check = "", Error = "", Warning = "", Info = "",
        Shield = "", Engines = "", Servers = "", Logs = "", Download = "", Sun = "", Moon = "",
        More = "", Forward = "", Back = "", Lock = "", Key = "", Cloud = "", Database = "",
        Package = "", Pending = "", Skip = "", Open = "", Power = "", Admin = "";
}

// A rounded card with a hairline border; children sit inside its padding.
internal class Card : Panel
{
    public int Radius { get; set; } = 10;
    public bool Accent { get; set; }
    public Card()
    {
        DoubleBuffered = true;
        ResizeRedraw = true;
        Padding = new Padding(18, 14, 18, 14);
        Margin = new Padding(0, 0, 0, 12);
        BackColor = Color.Transparent;
        SetStyle(ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
    }
    protected override void OnPaintBackground(PaintEventArgs e)
    {
        e.Graphics.Clear(Parent?.BackColor ?? Theme.Page);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        var r = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f);
        using var path = Theme.Round(r, Radius);
        using var fill = new SolidBrush(Theme.Surface);
        using var pen = new Pen(Accent ? Theme.Accent : Theme.Line);
        e.Graphics.FillPath(fill, path);
        e.Graphics.DrawPath(pen, path);
    }
    protected override void OnControlAdded(ControlEventArgs e) { base.OnControlAdded(e); if (e.Control is not Card) e.Control!.BackColor = Theme.Surface; }
}

internal enum ButtonKind { Primary, Secondary, Danger, Ghost }

// Rounded, flat button with hover and pressed states and an optional icon glyph.
internal sealed class ModernButton : Button
{
    bool hover, down;
    public ButtonKind Kind { get; set; }
    public string? Icon { get; set; }
    public ModernButton(string text, ButtonKind kind = ButtonKind.Secondary, string? icon = null)
    {
        Text = text; Kind = kind; Icon = icon;
        FlatStyle = FlatStyle.Flat;
        FlatAppearance.BorderSize = 0;
        Font = Theme.Strong;
        Cursor = Cursors.Hand;
        AutoSize = false;
        Height = 34;
        Margin = new Padding(0, 0, 8, 8);
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
        Width = TextRenderer.MeasureText(text, Font).Width + (icon != null ? 52 : 32);
    }
    protected override void OnMouseEnter(EventArgs e) { hover = true; Invalidate(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { hover = down = false; Invalidate(); base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e) { down = true; Invalidate(); base.OnMouseDown(e); }
    protected override void OnMouseUp(MouseEventArgs e) { down = false; Invalidate(); base.OnMouseUp(e); }
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.Clear(Parent?.BackColor ?? Theme.Page);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        var (fill, ink, border) = Kind switch
        {
            ButtonKind.Primary => (hover ? Theme.AccentHover : Theme.Accent, Color.White, Color.Empty),
            ButtonKind.Danger => (hover ? Theme.Mix(Theme.Bad, Color.Black, 0.12f) : Theme.Bad, Color.White, Color.Empty),
            ButtonKind.Ghost => (hover ? Theme.Surface2 : Parent?.BackColor ?? Theme.Surface, Theme.Ink, Color.Empty),
            _ => (hover ? Theme.Surface2 : Theme.Surface, Theme.Ink, Theme.Line),
        };
        if (down) fill = Theme.Mix(fill, Theme.Dark ? Color.White : Color.Black, 0.08f);
        if (!Enabled) { fill = Kind is ButtonKind.Primary or ButtonKind.Danger ? Theme.Mix(fill, Theme.Page, 0.55f) : fill; ink = Theme.Muted; }
        var r = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f);
        using (var path = Theme.Round(r, 7))
        {
            using var b = new SolidBrush(fill);
            g.FillPath(b, path);
            if (border != Color.Empty) { using var p = new Pen(border); g.DrawPath(p, path); }
        }
        var x = 14;
        if (Icon != null)
        {
            using var f = Theme.Icons(11f);
            TextRenderer.DrawText(g, Icon, f, new Rectangle(x, 0, 18, Height), ink, TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.NoPadding);
            x += 24;
        }
        TextRenderer.DrawText(g, Text, Font, new Rectangle(x, 0, Width - x - 10, Height), ink, TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
        if (Focused && ShowFocusCues) { using var p = new Pen(Theme.Accent, 1.5f) { DashStyle = DashStyle.Dot }; g.DrawRectangle(p, 3, 3, Width - 7, Height - 7); }
    }
}

// A sidebar navigation entry: icon, label and an accent bar when selected.
internal sealed class NavItem : Control
{
    bool hover;
    string icon;
    public string Icon { get => icon; set { icon = value; Invalidate(); } }
    public string? Badge { get; set; }
    public Color BadgeColor { get; set; } = Theme.Bad;
    bool selected;
    public bool Selected { get => selected; set { selected = value; Invalidate(); } }
    public NavItem(string icon, string text)
    {
        this.icon = icon; Text = text;
        Height = 40;
        Dock = DockStyle.Top;
        Cursor = Cursors.Hand;
        Font = Theme.Body;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
        AccessibleRole = AccessibleRole.PageTab;
    }
    protected override void OnMouseEnter(EventArgs e) { hover = true; Invalidate(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { hover = false; Invalidate(); base.OnMouseLeave(e); }
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.Clear(Theme.Sidebar);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        var r = new RectangleF(10, 3, Width - 20, Height - 6);
        if (Selected || hover) { using var path = Theme.Round(r, 7); using var b = new SolidBrush(Selected ? Theme.SidebarSelected : Theme.SidebarHover); g.FillPath(b, path); }
        if (Selected) { using var bar = new SolidBrush(Theme.Green); g.FillRectangle(bar, 10, 12, 3, Height - 24); }
        var ink = Selected ? Color.White : Theme.SidebarInk;
        using var f = Theme.Icons(12f);
        TextRenderer.DrawText(g, Icon, f, new Rectangle(24, 0, 22, Height), ink, TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
        using var tf = Selected ? Theme.Strong : Theme.Body;
        TextRenderer.DrawText(g, Text, tf, new Rectangle(54, 0, Width - 100, Height), ink, TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
        if (!string.IsNullOrEmpty(Badge))
        {
            var sz = TextRenderer.MeasureText(Badge, Theme.Small);
            var br = new RectangleF(Width - 24 - sz.Width, (Height - 18) / 2f, sz.Width + 8, 18);
            using var path = Theme.Round(br, 9); using var b = new SolidBrush(BadgeColor); g.FillPath(b, path);
            TextRenderer.DrawText(g, Badge, Theme.Small, Rectangle.Round(br), Color.White, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
        }
    }
}

// A colored status dot with a label, e.g. "● Running".
internal sealed class Pill : Control
{
    Color color = Theme.Idle;
    public Color Color { get => color; set { color = value; Invalidate(); } }
    public Pill() { Height = 26; Font = Theme.Strong; SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.SupportsTransparentBackColor, true); }
    protected override void OnTextChanged(EventArgs e) { Width = TextRenderer.MeasureText(Text, Font).Width + 34; Invalidate(); base.OnTextChanged(e); }
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.Clear(Parent?.BackColor ?? Theme.Surface);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        using (var path = Theme.Round(new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f), Height / 2f))
        using (var b = new SolidBrush(Color.FromArgb(Theme.Dark ? 48 : 30, color))) g.FillPath(b, path);
        using (var dot = new SolidBrush(color)) g.FillEllipse(dot, 10, Height / 2f - 4, 8, 8);
        TextRenderer.DrawText(g, Text, Font, new Rectangle(24, 0, Width - 26, Height), Theme.Mix(color, Theme.Ink, Theme.Dark ? 0.15f : 0.35f), TextFormatFlags.VerticalCenter | TextFormatFlags.Left);
    }
}

// An on/off switch that behaves like a check box.
internal sealed class ToggleSwitch : CheckBox
{
    public ToggleSwitch(string text) { Text = text; AutoSize = false; Height = 28; Cursor = Cursors.Hand; SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true); Width = TextRenderer.MeasureText(text, Theme.Body).Width + 60; Font = Theme.Body; }
    protected override void OnCheckedChanged(EventArgs e) { Invalidate(); base.OnCheckedChanged(e); }
    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.Clear(Parent?.BackColor ?? Theme.Surface);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        var track = new RectangleF(1, (Height - 20) / 2f, 40, 20);
        using (var path = Theme.Round(track, 10))
        {
            using var b = new SolidBrush(Checked ? Theme.Accent : Theme.Surface);
            g.FillPath(b, path);
            using var p = new Pen(Checked ? Theme.Accent : Theme.Muted);
            g.DrawPath(p, path);
        }
        var knob = Checked ? new RectangleF(track.Right - 17, track.Y + 3, 14, 14) : new RectangleF(track.X + 4, track.Y + 4, 12, 12);
        using (var k = new SolidBrush(Checked ? Color.White : Theme.Muted)) g.FillEllipse(k, knob);
        TextRenderer.DrawText(g, Text, Font, new Rectangle(50, 0, Width - 50, Height), Enabled ? Theme.Ink : Theme.Muted, TextFormatFlags.VerticalCenter | TextFormatFlags.Left | TextFormatFlags.EndEllipsis);
    }
}

// A label in the muted caption style used above fields.
internal sealed class Caption : Label
{
    public Caption(string text) { Text = text; AutoSize = true; ForeColor = Theme.Muted; Font = Theme.Strong; Margin = new Padding(0, 10, 0, 4); }
}

// Recolors standard controls inside a container for the current theme (text boxes, combo boxes, labels, lists).
internal static class Restyle
{
    public static void Apply(Control root)
    {
        foreach (Control c in root.Controls)
        {
            switch (c)
            {
                case Card: break;
                case TextBox t: t.BackColor = Theme.Surface2; t.ForeColor = Theme.Ink; t.BorderStyle = BorderStyle.FixedSingle; break;
                case ComboBox cb: cb.BackColor = Theme.Surface2; cb.ForeColor = Theme.Ink; cb.FlatStyle = FlatStyle.Flat; break;
                case NumericUpDown n: n.BackColor = Theme.Surface2; n.ForeColor = Theme.Ink; n.BorderStyle = BorderStyle.FixedSingle; break;
                case ListView lv: lv.BackColor = Theme.Surface; lv.ForeColor = Theme.Ink; break;
                case Caption cap: cap.ForeColor = Theme.Muted; break;
                case LinkLabel l: l.LinkColor = Theme.Accent; l.ActiveLinkColor = Theme.AccentHover; break;
                case Label l when l.Tag as string == "muted": l.ForeColor = Theme.Muted; break;
                case Label l: l.ForeColor = Theme.Ink; break;
            }
            if (c is not NavItem && c is not ModernButton && c is not Pill && c is not ToggleSwitch && c.Tag as string != "keep" && c is Panel or TableLayoutPanel or FlowLayoutPanel && c is not Card)
                c.BackColor = c.Parent is Card ? Theme.Surface : c.Parent?.BackColor ?? Theme.Page;
            if (c.HasChildren) Apply(c);
            c.Invalidate();
        }
    }
}
