/*
 * RoboMate MonCastle - Actions > Actions & jobs: the action catalog by environment (Active Directory, devices, network,
 * Linux, storage ...) with what each action needs (device kinds, run-as credential, permissions), and scheduled jobs:
 * an action run on an interval or calendar against all devices, device groups or chosen devices, as a chosen account.
 * Rules shared with the server are in jobdefs.js (window.MCJobDefs).
 */
(function (root) {
  'use strict';
  const MC = root.MC, JD = root.MCJobDefs, S = root.MCSensors;
  const { esc, pill, icon, ago, dt, $, $$ } = MC;
  const V = MC.views;
  const isAdmin = () => MC.user && (MC.user.role === 'admin' || MC.user.override);
  // the catalog by environment (Active Directory, Devices, Network, Linux, Storage ...), shared with the server
  const catOf = (s) => JD.categoryOf(s);
  const ORDER = JD.CATEGORY_ORDER;
  const ENV_NOTE = { 'Active Directory': 'users, groups, replication, Group Policy', Devices: 'Windows servers and workstations: services, power, firewall, updates, Defender, Wake-on-LAN', Network: 'switches, routers, firewalls: show commands, ports, configuration', Linux: 'services, patches, users, reboot, diagnostics', Storage: 'disk cleanup, shadow copies, SAN/NAS snapshots', Virtualization: 'Hyper-V virtual machines', MonCastle: 'the console itself' };
  const byOrder = (a, b) => (ORDER.indexOf(a) + 1 || 99) - (ORDER.indexOf(b) + 1 || 99) || a.localeCompare(b);
  const KIND_NAME = Object.assign({ domain: 'AD domain' }, Object.fromEntries(S.CLASSES.map(([k, l]) => [k, l])));
  const CRED_NAME = { windows: 'Windows account', ssh: 'SSH account', vmware: 'VMware account', sql: 'SQL Server login', database: 'Database login', cloud: 'Cloud identity', http: 'Web / API account' };
  const targetsText = (s) => ((s.targets || []).length ? s.targets.map((k) => KIND_NAME[k] || k).join(', ') : 'Any device');
  const statePill = (st) => (!st ? '<span class="muted">Not run yet</span>' : pill({ ok: 'OK', partial: 'Warning', failed: 'Critical', skipped: 'Unknown', running: 'Info' }[st] || 'Unknown', { ok: 'OK', partial: 'Partly failed', failed: 'Failed', skipped: 'Skipped', running: 'Running' }[st] || st));
  const until = (t) => { if (!t) return '–'; const m = Math.round((Date.parse(t) - Date.now()) / 6e4); return m <= 0 ? 'due now' : m < 60 ? 'in ' + m + ' min' : m < 1440 ? 'in ' + Math.round(m / 60) + ' h' : 'in ' + Math.round(m / 1440) + ' d'; };
  const runnable = () => (MC.manifest.scripts || []).filter((s) => s.kind !== 'collector');

  V.actions = {
    title: 'Actions & jobs',
    crumb: () => (MC.route.tab === 'jobs' ? 'actions that run on a schedule, on all devices or chosen groups, as the account you pick' : MC.route.tab === 'myjobs' ? 'the actions and tools you ran, with their results and details' : 'every action and tool from the verified catalog, by environment'),
    render(el, route) {
      clearTimeout(V.actions._mt);
      const tab = ['jobs', 'myjobs'].includes(route.tab) ? route.tab : 'catalog';
      el.innerHTML = MC.tabs('actions', [['catalog', 'Actions'], ['myjobs', 'My jobs'], ['jobs', 'Scheduled jobs']], tab) + '<div id="actBody"></div>';
      const body = $('#actBody', el);
      if (tab === 'jobs') return jobsTab(body, route);
      if (tab === 'myjobs') return myJobs(body, route);
      catalog(body, route);
    },
  };

  // ------------------------------------------------------------------ catalog
  function catalog(el, route) {
    const q = route.q || {};
    const kind = q.kind || '', cat = q.cat || '', text = (q.q || '').toLowerCase();
    const all = runnable();
    const cats = [...new Set(all.map(catOf))].sort(byOrder);
    const list = all.filter((s) => (!kind || s.kind === kind) && (!cat || catOf(s) === cat) && (!text || (s.title + ' ' + s.synopsis + ' ' + s.id).toLowerCase().includes(text)));
    const groups = {};
    list.forEach((s) => (groups[catOf(s)] = groups[catOf(s)] || []).push(s));
    const go = (p) => MC.go('actions', 'catalog', Object.assign({ kind, cat, q: q.q || '' }, p));
    el.innerHTML = `<div class="grid g-2-1">
      <div class="grid">
        <div class="toolbar"><div class="seg" id="kseg">${[['', 'All'], ['action', 'Changes'], ['ondemand', 'Read-only']].map(([k, t]) => `<button data-k="${k}" class="${kind === k ? 'on' : ''}">${t}</button>`).join('')}</div>

          <input class="input" id="actQ" placeholder="Search actions" value="${esc(q.q || '')}" style="width:auto;flex:1;min-width:140px">
        </div>
        <div class="mfilter env-chips" role="group" aria-label="Environment"><button class="btn sm ${!cat ? 'on' : ''}" data-env="">All <span class="muted">${all.length}</span></button>${cats.map((c) => `<button class="btn sm ${c === cat ? 'on' : ''}" data-env="${esc(c)}">${esc(c)} <span class="muted">${all.filter((x) => catOf(x) === c).length}</span></button>`).join('')}</div>
        <p class="muted" style="margin:0;font-size:12.5px">Signed in as ${esc(root.MCRbac.norm(MC.user.role))}: ${MC.user.role === 'admin' ? 'all actions, and you can schedule them' : root.MCRbac.norm(MC.user.role) === 'contributor' ? 'low and medium risk actions' : 'read-only tools'}${(MC.user.groups || []).length ? ', plus what your user groups grant on their device groups' : ''}. Each action lists the devices it works on, the account it runs as and the rights that account needs.</p>
        ${Object.keys(groups).sort(byOrder).map((g) => `<section><h4 class="cat-h">${esc(g)} <span class="muted">${groups[g].length}${ENV_NOTE[g] ? ' · ' + esc(ENV_NOTE[g]) : ''}</span></h4><div class="cards">${groups[g].map(card).join('')}</div></section>`).join('') || '<div class="empty">No action matches.</div>'}
      </div>
      <div>${MC.panel('Jobs', 'recent runs', '<div id="jobs" class="grid" style="gap:8px"></div>', { act: '<button class="btn sm ghost" id="jr">Refresh</button>' })}</div></div>`;
    $$('#kseg button', el).forEach((b) => b.addEventListener('click', () => go({ kind: b.dataset.k })));
    $$('[data-env]', el).forEach((b) => b.addEventListener('click', () => go({ cat: b.dataset.env })));
    let t; $('#actQ', el).addEventListener('input', (e) => { clearTimeout(t); t = setTimeout(() => { go({ q: e.target.value }); setTimeout(() => { const i = $('#actQ'); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }, 0); }, 350); });
    $$('[data-sched]', el).forEach((b) => b.addEventListener('click', () => jobDialog(null, b.dataset.sched)));
    V.actions.onJobs = drawJobs;
    $('#jr', el).addEventListener('click', drawJobs);
    drawJobs();
  }
  function card(s) {
    return `<div class="card acard"><div class="top"><span class="risk-tag ${esc(s.risk)}">${esc(s.risk)}</span><span class="muted" style="font-size:11.5px">${s.kind === 'action' ? 'changes target' : 'read-only'}</span></div>
      <b>${esc(s.title)}</b><p>${esc(s.synopsis)}</p>
      <dl class="needs"><dt>Works on</dt><dd>${esc(targetsText(s))}</dd>${s.credential ? `<dt>Runs as</dt><dd>${esc(CRED_NAME[s.credential] || s.credential)}</dd>` : ''}${s.permissions ? `<dt>Needs</dt><dd>${esc(s.permissions)}</dd>` : ''}</dl>
      ${(s.replaces || []).length ? `<span class="replaces">Replaces ${esc(s.replaces.map((r) => r.split(/[\\/]/).pop()).join(', ').slice(0, 120))}</span>` : ''}
      <div class="actions-row"><button class="btn sm ${s.risk === 'high' ? 'danger' : 'primary'}" ${MC.runAttr(s.id, {})}>${icon('play', 'sev-ico')}Run…</button>${isAdmin() ? `<button class="btn sm ghost" data-sched="${esc(s.id)}">${icon('clock', 'sev-ico')}Schedule…</button>` : ''}</div></div>`;
  }
  async function drawJobs() {
    const box = $('#jobs');
    if (!box) return;
    let jobs = [];
    try { jobs = await MC.api.jobs(); } catch (e) { jobs = MC.jobs; }
    box.innerHTML = jobs.length ? jobs.slice(0, 30).map((j) => `<div class="job"><div class="t">${esc(j.title || j.script)}</div><div>${pill(j.state === 'done' ? 'OK' : j.state === 'failed' ? 'Critical' : 'Info', j.state)}</div><div class="s">${esc(j.user)} · ${ago(j.started)}${j.whatIf ? ' · WhatIf' : ''} · <span class="mono">${esc(Object.entries(j.params || {}).map(([k, v]) => k + '=' + v).join(' ').slice(0, 80))}</span></div><div>${j.state !== 'running' ? `<button class="btn sm ghost" data-job="${esc(j.id)}">Output</button>` : ''}</div></div>`).join('') : '<div class="muted">No jobs yet. Run something from the catalog, or use a Fix button on an insight.</div>';
    $$('[data-job]', box).forEach((b) => b.addEventListener('click', () => jobOutput(b.dataset.job)));
  }
  async function jobOutput(id) {
    const j = await MC.api.job(id);
    MC.openDrawer(`<header><div class="row1">${pill(j.state === 'done' ? 'OK' : 'Critical', j.state)}<h2>${esc(j.title || j.script)}</h2><button class="iconbtn" data-close style="margin-left:auto" aria-label="Close">${icon('x')}</button></div><div class="meta"><span class="mono">${esc(j.script)}</span><span>${esc(j.user)}</span><span>${dt(j.started)}</span></div></header><div class="body"><div class="code">${esc(JSON.stringify(j.params, null, 2))}</div><div id="jo"></div></div>`, (d) => MC.showJobResult($('#jo', d), j));
  }

  // ------------------------------------------------------------------ my jobs: the actions and tools a user ran, with results and details
  const JOB_STATE = { done: ['OK', 'Completed'], failed: ['Critical', 'Failed'], running: ['Info', 'Running'], queued: ['Info', 'Queued'], cancelled: ['Unknown', 'Cancelled'] };
  const jobPill = (j) => { const r = j.result || {}; const w = j.state === 'done' && (r.status === 'warning' || r.status === 'partial'); const [c, t] = w ? ['Warning', 'Completed with warnings'] : JOB_STATE[j.state] || ['Unknown', j.state || '–']; return pill(c, t); };
  const jobSecs = (j) => (j.started && j.finished ? Math.max(0, Math.round((Date.parse(j.finished) - Date.parse(j.started)) / 100) / 10) : null);
  const jobTarget = (j) => { const p = j.params || {}; const v = p.ComputerName || p.Target || p.Host || p.Identity || p.Name || p.Device || p.Id || ''; return Array.isArray(v) ? v.join(', ') : String(v); };
  const isSystem = (u) => ['scheduler', 'monitor', 'system'].includes(String(u || '')) || /^job: /.test(String(u || ''));
  async function myJobs(el, route) {
    const q = route.q || {}, who = isAdmin() && q.who === 'all' ? 'all' : isAdmin() && q.who === 'scheduled' ? 'scheduled' : 'me', st = q.state || '';
    el.innerHTML = '<div class="notice">Loading jobs…</div>';
    let jobs = [];
    try { jobs = await MC.api.jobs(); } catch (e) { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; return; }
    if (!document.body.contains(el)) return;
    const me = (MC.user || {}).name;
    const runnableIds = new Set(runnable().map((x) => x.id));
    const scoped = jobs.filter((j) => (who === 'me' ? j.user === me : who === 'scheduled' ? /^job: /.test(String(j.user || '')) : !isSystem(j.user) || /^job: /.test(String(j.user || ''))) && (runnableIds.has(j.script) || (MC.script(j.script) || {}).kind !== 'collector'));
    const list = scoped.filter((j) => !st || (st === 'warning' ? j.state === 'done' && ['warning', 'partial'].includes((j.result || {}).status) : j.state === st));
    const n = (f) => scoped.filter(f).length;
    const day = n((j) => Date.now() - Date.parse(j.started) < 864e5);
    const go = (p) => MC.go('actions', 'myjobs', Object.assign({ who: who === 'me' ? '' : who, state: st }, p));
    el.innerHTML = `<div class="kpis">${MC.kpi(who === 'me' ? 'My jobs' : who === 'scheduled' ? 'Scheduled job runs' : 'Jobs', scoped.length, 'kept: the last 500 runs on the console')}${MC.kpi('Running', n((j) => j.state === 'running' || j.state === 'queued'), 'now')}${MC.kpi('Completed', n((j) => j.state === 'done'), n((j) => j.state === 'done' && ['warning', 'partial'].includes((j.result || {}).status)) + ' with warnings')}${MC.kpi('Failed', n((j) => j.state === 'failed'), 'need a look', { alert: n((j) => j.state === 'failed') > 0 })}${MC.kpi('Last 24 h', day, 'runs started')}</div>
      <div class="toolbar">${isAdmin() ? `<div class="seg" id="mjWho">${[['me', 'Mine'], ['all', 'Everyone'], ['scheduled', 'Scheduled jobs']].map(([k, t]) => `<button data-w="${k}" class="${who === k ? 'on' : ''}">${t}</button>`).join('')}</div>` : ''}
        <div class="mfilter" role="group" aria-label="Result">${[['', 'All'], ['running', 'Running'], ['done', 'Completed'], ['warning', 'Warnings'], ['failed', 'Failed']].map(([k, t]) => `<button class="btn sm ${st === k ? 'on' : ''}" data-st="${k}">${t}</button>`).join('')}</div>
        <span class="spacer" style="flex:1"></span><button class="btn sm ghost" id="mjR">${icon('refresh', 'sev-ico')}Refresh</button></div>
      ${MC.panel(who === 'me' ? 'Jobs you ran' : who === 'scheduled' ? 'Runs of scheduled jobs' : 'Jobs run by people and scheduled jobs', 'newest first · choose a job for its parameters, output and result rows', '<div id="mjT"></div>')}`;
    MC.table($('#mjT', el), list, [
      { key: 'started', label: 'Started', html: (j) => `<span title="${esc(dt(j.started))}">${ago(j.started)}</span>`, val: (j) => -Date.parse(j.started), csv: (j) => j.started },
      { key: 'title', label: 'Action', html: (j) => `<a href="#" data-mj="${esc(j.id)}"><b>${esc(j.title || j.script)}</b></a><div class="mono muted" style="font-size:11.5px">${esc(j.script)}</div>`, val: (j) => j.title || j.script },
      ...(who !== 'me' ? [{ key: 'user', label: 'By' }] : []),
      { key: 'target', label: 'Target', html: (j) => esc(jobTarget(j) || '–'), val: jobTarget },
      { key: 'kind', label: 'Type', html: (j) => (j.kind === 'action' ? 'Change' : 'Read-only') + (j.whatIf ? ' · <span class="muted">WhatIf</span>' : ''), val: (j) => j.kind },
      { key: 'state', label: 'Result', html: jobPill, val: (j) => j.state },
      { key: 'secs', label: 'Took s', n: true, val: jobSecs, html: (j) => (jobSecs(j) == null ? '–' : String(jobSecs(j))) },
      { key: 'rows', label: 'Rows', n: true, val: (j) => (j.result || {}).count, html: (j) => ((j.result || {}).count == null ? '–' : String(j.result.count)) },
      { key: 'msg', label: 'Message', html: (j) => `<span style="font-size:12.5px">${esc(String(j.error || (j.result || {}).message || '').slice(0, 140))}</span>`, val: (j) => j.error || (j.result || {}).message || '' },
      { key: 'det', label: '', noCsv: true, html: (j) => `<button class="btn sm ghost" data-mj="${esc(j.id)}">Details</button>` },
    ], { sort: 'started', dir: 1, name: 'my-jobs', limit: 50, empty: who === 'me' ? 'You have not run any action yet. Run one from the Actions tab or a Fix button on an insight.' : 'No jobs yet.', after: (w) => $$('[data-mj]', w).forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); jobDetails(a.dataset.mj); })) });
    $$('[data-w]', el).forEach((b) => b.addEventListener('click', () => go({ who: b.dataset.w === 'me' ? '' : b.dataset.w })));
    $$('[data-st]', el).forEach((b) => b.addEventListener('click', () => go({ state: b.dataset.st })));
    $('#mjR', el).addEventListener('click', () => myJobs(el, MC.route));
    V.actions.onJobs = () => { if (MC.route.page === 'actions' && MC.route.tab === 'myjobs') myJobs(el, MC.route); };
    if (q.job && V.actions._opened !== q.job) { V.actions._opened = q.job; jobDetails(q.job).catch(() => MC.toast('That job is no longer kept (the console holds the last 500 runs).', 'err')); }
    clearTimeout(V.actions._mt);
    if (scoped.some((j) => j.state === 'running' || j.state === 'queued')) { const seq = MC.renderSeq; V.actions._mt = setTimeout(() => { if (MC.renderSeq === seq && document.body.contains(el) && !document.querySelector('.drawer')) myJobs(el, MC.route); }, 5000); }
  }
  // one job: who ran it, when, on what, with which parameters; its messages, warnings and result rows
  async function jobDetails(id) {
    const j = await MC.api.job(id);
    const r = j.result || {}, p = Object.entries(j.params || {}), secs = jobSecs(j);
    MC.openDrawer(`<header><div class="row1">${jobPill(j)}<h2>${esc(j.title || j.script)}</h2><button class="iconbtn" data-close style="margin-left:auto" aria-label="Close">${icon('x')}</button></div><div class="meta"><span class="mono">${esc(j.script)}</span><span>${esc(j.user)}</span><span>${dt(j.started)}</span></div></header>
      <div class="body"><dl class="kv"><dt>Job</dt><dd class="mono">${esc(j.id)}</dd><dt>Run by</dt><dd>${esc(j.user || '–')}${/^job: /.test(String(j.user || '')) ? ' <span class="muted">(scheduled job)</span>' : ''}</dd><dt>Type</dt><dd>${j.kind === 'action' ? 'Changes the target' : 'Read-only'}${j.whatIf ? ' · WhatIf preview: nothing was changed' : ''}</dd><dt>Started</dt><dd>${dt(j.started)}</dd><dt>Finished</dt><dd>${j.finished ? dt(j.finished) : 'still running'}</dd><dt>Took</dt><dd>${secs == null ? '–' : secs + ' s'}</dd>${r.host ? `<dt>Ran on</dt><dd>${esc(r.host)}</dd>` : ''}<dt>Rows</dt><dd>${r.count == null ? '–' : r.count}</dd><dt>Warnings</dt><dd>${(r.warnings || []).length}</dd><dt>Parameters</dt><dd>${p.length ? p.map(([k, v]) => `<span class="mono">${esc(k)}=${esc(Array.isArray(v) ? v.join(',') : typeof v === 'object' && v ? JSON.stringify(v) : v)}</span>`).join('<br>') : '<span class="muted">defaults</span>'}</dd></dl>
      ${j.error ? `<div class="notice err" style="margin-top:10px">${esc(j.error)}</div>` : ''}
      ${r.summary && typeof r.summary === 'object' ? `<h4 style="margin:14px 0 6px">Summary</h4><dl class="kv">${Object.entries(r.summary).filter(([, v]) => v == null || typeof v !== 'object').map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v == null ? '–' : String(v))}</dd>`).join('')}</dl>` : ''}
      <div id="jo"></div>${(j.log || []).length ? `<h4 style="margin:14px 0 6px">Log</h4><div class="code" style="max-height:260px;overflow:auto">${esc((j.log || []).slice(-200).map((l) => (typeof l === 'string' ? l : (l.t || '') + ' ' + (l.level || '') + ' ' + (l.message || l.m || ''))).join('\n'))}</div>` : ''}
      ${j.state === 'done' || j.state === 'failed' ? `<div class="actions-row" style="margin-top:14px"><button class="btn" ${MC.runAttr(j.script, j.params || {})}>${icon('play', 'sev-ico')}Run again…</button></div>` : ''}</div>`, (d) => { if (j.state !== 'running' && j.state !== 'queued') MC.showJobResult($('#jo', d), j); });
  }

  // ------------------------------------------------------------------ scheduled jobs
  async function jobsTab(el, route) {
    el.innerHTML = '<div class="notice">Loading scheduled jobs…</div>';
    let defs, tree;
    try { [defs, tree] = await Promise.all([MC.api.jobdefs(), MC.monTree()]); } catch (e) { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; return; }
    if (!document.body.contains(el)) return;
    const gname = Object.fromEntries(tree.groups.map((g) => [g.id, g.name]));
    const dname = Object.fromEntries(tree.devices.map((d) => [d.id, d.name]));
    const scope = (d) => (d.target.mode === 'all' ? 'All matching devices' : d.target.mode === 'groups' ? d.target.groups.map((g) => gname[g] || g).join(', ') : d.target.mode === 'devices' ? (d.target.devices.length > 3 ? d.target.devices.length + ' devices' : d.target.devices.map((x) => dname[x] || x).join(', ')) : 'Whole directory (runs once)');
    const on = defs.filter((d) => d.enabled);
    const next = on.filter((d) => d.nextRun).sort((a, b) => Date.parse(a.nextRun) - Date.parse(b.nextRun))[0];
    const day = defs.flatMap((d) => (d.history || []).filter((h) => Date.now() - Date.parse(h.at) < 864e5));
    const bad = defs.filter((d) => ['failed', 'partial'].includes(d.lastStatus));
    const q = (route.q || {}).q || '';
    el.innerHTML = `<div class="kpis">${MC.kpi('Scheduled jobs', defs.length, on.length + ' on · ' + (defs.length - on.length) + ' paused')}${MC.kpi('Next run', next ? esc(until(next.nextRun)) : '–', next ? esc(next.name) : 'nothing scheduled')}${MC.kpi('Runs in 24 h', day.length, day.filter((h) => h.status === 'ok').length + ' OK')}${MC.kpi('Need attention', bad.length, bad.length ? esc(bad.map((d) => d.name).slice(0, 2).join(', ')) : 'last runs OK', { alert: bad.length > 0 })}</div>
      ${MC.panel('Scheduled jobs', 'times are the MonCastle server\'s local time', '<div id="jdt"></div>', { act: isAdmin() ? `<button class="btn sm primary" id="jdNew">${icon('plus', 'sev-ico')}New scheduled job</button>` : '' })}
      ${isAdmin() ? '' : '<p class="muted" style="font-size:12.5px">Administrators create and change scheduled jobs, because they run unattended with the account chosen for them.</p>'}`;
    const t = MC.table($('#jdt'), defs, [
      { key: 'name', label: 'Job', html: (d) => `<a href="#" data-open="${esc(d.id)}"><b>${esc(d.name)}</b></a><div class="muted" style="font-size:12px">${esc(d.title)}${d.missing ? ' · <span style="color:var(--crit-ink)">not in the catalog</span>' : ''}</div>` },
      { key: 'resource', label: 'Environment', html: (d) => esc(d.resource) },
      { key: 'risk', label: 'Risk', html: (d) => `<span class="risk-tag ${esc(d.risk || 'low')}">${esc(d.risk || '?')}</span>${d.whatIf ? ' <span class="muted" style="font-size:11.5px">WhatIf</span>' : ''}` },
      { key: 'scope', label: 'Devices', html: (d) => esc(scope(d)), val: scope },
      { key: 'when', label: 'Schedule' },
      { key: 'credentialName', label: 'Runs as', html: (d) => (d.credentialName ? esc(d.credentialName) : '<span class="muted">Device credentials</span>'), csv: (d) => d.credentialName || 'Device credentials' },
      { key: 'nextRun', label: 'Next run', html: (d) => (!d.enabled ? pill('Paused', 'Paused') : d.nextRun ? `<span title="${esc(dt(d.nextRun))}">${esc(until(d.nextRun))}</span>` : '<span class="muted">none</span>'), val: (d) => d.nextRun || '' },
      { key: 'lastRun', label: 'Last run', html: (d) => `${statePill(d.running ? 'running' : d.lastStatus)}${d.lastRun ? ` <span class="muted" style="font-size:12px">${ago(d.lastRun)}</span>` : ''}`, val: (d) => d.lastRun || '' },
      { key: 'act', label: '', noCsv: true, html: (d) => (isAdmin() ? `<div class="actions-row" style="flex-wrap:nowrap"><button class="btn sm" data-runnow="${esc(d.id)}" ${d.running || d.missing ? 'disabled' : ''}>${icon('play', 'sev-ico')}Run now</button><button class="btn sm ghost" data-edit="${esc(d.id)}">Edit</button><button class="btn sm ghost" data-toggle="${esc(d.id)}">${d.enabled ? 'Pause' : 'Turn on'}</button></div>` : '') },
    ], { q, sort: 'name', dir: 1, name: 'scheduled-jobs' });
    const wire = () => {
      $$('[data-open]', el).forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); jobDrawer(defs.find((d) => d.id === a.dataset.open), scope); }));
      $$('[data-edit]', el).forEach((b) => b.addEventListener('click', () => jobDialog(defs.find((d) => d.id === b.dataset.edit))));
      $$('[data-toggle]', el).forEach((b) => b.addEventListener('click', async () => { const d = defs.find((x) => x.id === b.dataset.toggle); try { await MC.api.jobdefAction(d.id, d.enabled ? 'disable' : 'enable'); MC.toast((d.enabled ? 'Paused ' : 'Turned on ') + esc(d.name), 'ok'); V.actions.refresh(); } catch (e) { MC.toast(esc(e.message), 'err'); } }));
      $$('[data-runnow]', el).forEach((b) => b.addEventListener('click', async () => { b.disabled = true; const d = defs.find((x) => x.id === b.dataset.runnow); try { const r = await MC.api.jobdefAction(d.id, 'run'); MC.toast(r.run.status === 'skipped' ? esc(r.run.message) : `${icon('play', 'sev-ico')} Started <b>${esc(d.name)}</b>${r.run.targets ? ' on ' + r.run.targets + ' devices' : ''}`, r.run.status === 'skipped' ? 'err' : 'ok'); setTimeout(V.actions.refresh, 2600); V.actions.refresh(); } catch (e) { b.disabled = false; MC.toast(esc(e.message), 'err'); } }));
    };
    wire();
    $('#jdt').addEventListener('click', () => setTimeout(wire, 0)); // sorting and paging redraw the rows
    const nb = $('#jdNew', el); if (nb) nb.addEventListener('click', () => jobDialog(null));
    V.actions.refresh = () => { if (MC.route.page === 'actions' && MC.route.tab === 'jobs') jobsTab(el, MC.route); };
    clearTimeout(V.actions._t);
    if (defs.some((d) => d.running)) V.actions._t = setTimeout(V.actions.refresh, 4000);
    void t;
  }

  function jobDrawer(d, scope) {
    if (!d) return;
    const s = MC.script(d.script) || {};
    const params = Object.entries(d.params || {});
    MC.openDrawer(`<header><div class="row1">${statePill(d.running ? 'running' : d.lastStatus)}<h2>${esc(d.name)}</h2><button class="iconbtn" data-close style="margin-left:auto" aria-label="Close">${icon('x')}</button></div><div class="meta"><span>${esc(d.title)}</span><span class="mono">${esc(d.script)}</span><span>${d.enabled ? 'On' : 'Paused'}</span></div></header>
      <div class="body">
        <dl class="kv"><dt>Schedule</dt><dd>${esc(d.when)}${d.nextRun && d.enabled ? ' · next ' + esc(dt(d.nextRun)) : ''}</dd><dt>Devices</dt><dd>${esc(scope(d))}${(s.targets || []).length ? ' <span class="muted">(only ' + esc(targetsText(s)) + ')</span>' : ''}</dd><dt>Runs as</dt><dd>${esc(d.credentialName || 'The credential assigned to each device or its group')}</dd>${s.permissions ? `<dt>Account needs</dt><dd>${esc(s.permissions)}</dd>` : ''}<dt>Parameters</dt><dd>${params.length ? params.map(([k, v]) => `<span class="mono">${esc(k)}=${esc(Array.isArray(v) ? v.join(',') : v)}</span>`).join('<br>') : '<span class="muted">defaults</span>'}</dd><dt>Options</dt><dd>${[d.whatIf ? 'WhatIf (preview only, changes nothing)' : 'Makes changes', d.notify && d.notify.onFailure && d.notify.to ? 'tells ' + esc(d.notify.to) + ' when it fails' : 'no failure notice'].join(' · ')}</dd><dt>Created</dt><dd>${esc(d.createdBy || '')} · ${dt(d.created)}${d.updated ? ' · changed by ' + esc(d.updatedBy || '') + ' ' + ago(d.updated) : ''}</dd></dl>
        <h4 style="margin:16px 0 8px">Run history</h4>
        ${(d.history || []).length ? `<table class="tbl"><thead><tr><th>Started</th><th>By</th><th>Devices</th><th>Result</th><th></th></tr></thead><tbody>${d.history.map((h) => `<tr><td>${dt(h.at)}</td><td>${esc(h.by)}</td><td>${h.targets || '–'}</td><td>${statePill(h.status)} <span class="muted" style="font-size:12px">${h.ok || h.failed ? h.ok + ' OK, ' + h.failed + ' failed' : ''} ${esc(h.message || '')}</span></td><td>${(h.jobs || []).slice(0, 3).map((j, i) => `<button class="btn sm ghost" data-jo="${esc(j)}">Output${h.jobs.length > 1 ? ' ' + (i + 1) : ''}</button>`).join('')}</td></tr>`).join('')}</tbody></table>` : '<p class="muted">Not run yet.</p>'}
        ${isAdmin() ? `<div class="actions-row" style="margin-top:16px"><button class="btn" data-ed>Edit</button><button class="btn danger" data-del>Delete job</button></div>` : ''}
      </div>`, (dr) => {
      $$('[data-jo]', dr).forEach((b) => b.addEventListener('click', async () => { try { await jobOutput(b.dataset.jo); } catch (e) { MC.toast('That output is no longer kept (the job list holds the last 500 runs).', 'err'); } }));
      const ed = $('[data-ed]', dr); if (ed) ed.addEventListener('click', () => { MC.closeDrawer(); jobDialog(d); });
      const del = $('[data-del]', dr);
      if (del) del.addEventListener('click', async () => { if (!confirm('Delete the scheduled job "' + d.name + '"? Its history goes with it.')) return; try { await MC.api.removeJobdef(d.id); MC.closeDrawer(); MC.toast('Deleted ' + esc(d.name), 'ok'); V.actions.refresh(); } catch (e) { MC.toast(esc(e.message), 'err'); } });
    });
  }

  // ------------------------------------------------------------------ create / edit dialog
  async function jobDialog(def, scriptId) {
    if (!isAdmin()) return MC.toast('Only administrators can schedule jobs.', 'err');
    let tree, creds;
    try { [tree, creds] = await Promise.all([MC.monTree(), MC.api.credentials().catch(() => [])]); } catch (e) { return MC.toast(esc(e.message), 'err'); }
    const all = runnable();
    const cats = {};
    all.forEach((s) => (cats[catOf(s)] = cats[catOf(s)] || []).push(s));
    const st = Object.assign({ name: '', script: scriptId || (def && def.script) || '', params: {}, target: { mode: 'groups', groups: [], devices: [] }, credential: null, schedule: { type: 'daily', times: ['02:00'] }, enabled: true, whatIf: false, notify: { onFailure: true, to: '' } }, def ? JSON.parse(JSON.stringify(def)) : {});
    if (scriptId) st.script = scriptId;
    const m = document.createElement('div');
    m.className = 'modal'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true');
    m.innerHTML = `<div class="card jd-card"><div style="display:flex;align-items:center;gap:8px"><h3>${def ? 'Edit scheduled job' : 'New scheduled job'}</h3><button class="iconbtn" data-x style="margin-left:auto" aria-label="Close">${icon('x')}</button></div>
      <form id="jdForm" autocomplete="off">
        <div class="field"><label for="jdScript">Action</label><select class="input" id="jdScript"><option value="">Choose an action or tool…</option>${Object.keys(cats).sort(byOrder).map((c) => `<optgroup label="${esc(c)}">${cats[c].map((s) => `<option value="${esc(s.id)}" ${s.id === st.script ? 'selected' : ''}>${esc(s.title)}${s.risk === 'high' ? ' (high risk)' : ''}</option>`).join('')}</optgroup>`).join('')}</select></div>
        <div id="jdAbout"></div>
        <div class="field"><label for="jdName">Job name</label><input class="input" id="jdName" maxlength="80" value="${esc(st.name)}" placeholder="For example: Nightly switch config backup"></div>
        <fieldset class="jd-sec"><legend>Settings for the action</legend><div id="jdParams"></div></fieldset>
        <fieldset class="jd-sec"><legend>Devices</legend><div id="jdTargets"></div></fieldset>
        <fieldset class="jd-sec"><legend>Run as</legend><div id="jdCred"></div></fieldset>
        <fieldset class="jd-sec"><legend>When</legend><div id="jdWhen"></div></fieldset>
        <fieldset class="jd-sec"><legend>Options</legend><div id="jdOpts"></div></fieldset>
        <div data-err></div>
        <div class="foot"><button type="button" class="btn" data-x>Cancel</button><button type="submit" class="btn primary">${icon('check', 'sev-ico')}${def ? 'Save changes' : 'Create job'}</button></div>
      </form></div>`;
    document.body.appendChild(m);
    const close = () => m.remove();
    $$('[data-x]', m).forEach((b) => b.addEventListener('click', close));
    m.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    const chainOf = (gid) => { const out = []; let g = tree.groups.find((x) => x.id === gid); while (g) { out.push(g.id); g = tree.groups.find((x) => x.id === g.parent); } return out.concat('probe'); };
    const depth = (g) => chainOf(g.id).length - 2;
    const groupsSorted = (() => { const out = []; const walk = (pid) => tree.groups.filter((g) => (g.parent || 'probe') === pid).sort((a, b) => (a.order || 0) - (b.order || 0) || a.name.localeCompare(b.name)).forEach((g) => { out.push(g); walk(g.id); }); walk('probe'); return out; })();
    const script = () => MC.script($('#jdScript', m).value);

    function drawScript() {
      const s = script();
      $('#jdAbout', m).innerHTML = s ? `<div class="risk ${esc(s.risk)}">${icon(s.risk === 'high' ? 'alert' : s.risk === 'medium' ? 'info' : 'check', 'sev-ico')}<span><b>${esc(s.title)}</b>: ${esc(s.synopsis || '')}<br><span class="muted">Works on ${esc(targetsText(s))}${s.credential ? ' · runs as a ' + esc(CRED_NAME[s.credential] || s.credential) : ''}${s.permissions ? ' · needs ' + esc(s.permissions) : ''}</span></span></div>` : '';
      if (s && !$('#jdName', m).value.trim()) $('#jdName', m).value = s.title;
      const hp = s && JD.hostParam(s);
      $('#jdParams', m).innerHTML = !s ? '<p class="muted">Choose an action first.</p>' : (s.parameters || []).filter((p) => !hp || p.name !== hp.name).map((p) => MC.inputFor(p, st.script === s.id ? st.params[p.name] : undefined, false)).join('') || '<p class="muted">This action takes no other settings.</p>';
      drawTargets(); drawCred(); drawOpts();
    }
    function drawTargets() {
      const s = script();
      const box = $('#jdTargets', m);
      if (!s) { box.innerHTML = '<p class="muted">Choose an action first.</p>'; return; }
      if (!JD.hostParam(s)) { box.innerHTML = `<p class="muted" style="margin:0">${esc(s.title)} works on the whole directory or service, not on single devices, so it runs once per schedule.${(s.parameters || []).some((p) => p.name === 'Server') ? ' Use the Server setting above to pick a domain controller.' : ''}</p>`; return; }
      const kinds = JD.kindsOf(s);
      const fits = tree.devices.filter((d) => !kinds.length || kinds.includes(d.kind));
      const mode = st.target.mode === 'none' ? 'groups' : st.target.mode;
      box.innerHTML = `<div class="seg" id="jdMode">${[['all', 'All devices'], ['groups', 'Device groups'], ['devices', 'Chosen devices']].map(([k, t]) => `<button type="button" data-m="${k}" class="${mode === k ? 'on' : ''}">${t}</button>`).join('')}</div>
        <p class="muted" style="font-size:12.5px;margin:6px 0">${kinds.length ? 'Only ' + esc(targetsText(s)) + ' are included; other devices in the groups are left out.' : 'Any monitored device can be a target.'} A group includes its subgroups, and devices added to it later are included on the next run.</p>
        ${mode === 'groups' ? `<div class="pick-list">${groupsSorted.map((g) => { const n = fits.filter((d) => chainOf(d.group).includes(g.id)).length; return `<label class="check" style="padding-left:${depth(g) * 16}px"><input type="checkbox" data-g="${esc(g.id)}" ${st.target.groups.includes(g.id) ? 'checked' : ''}> ${esc(g.name)} <span class="muted">${n}</span></label>`; }).join('')}</div>` : ''}
        ${mode === 'devices' ? `<input class="input" id="jdDevQ" placeholder="Filter devices" style="margin-bottom:6px"><div class="pick-list" id="jdDevList">${fits.sort((a, b) => a.name.localeCompare(b.name)).map((d) => `<label class="check" data-n="${esc((d.name + ' ' + (d.host || '')).toLowerCase())}"><input type="checkbox" data-d="${esc(d.id)}" ${st.target.devices.includes(d.id) ? 'checked' : ''}> ${esc(d.name)} <span class="muted">${esc(KIND_NAME[d.kind] || d.kind)}</span></label>`).join('') || '<p class="muted">No monitored device fits this action.</p>'}</div>` : ''}
        <p id="jdCount" style="margin:8px 0 0;font-size:13px"></p>`;
      $$('#jdMode button', box).forEach((b) => b.addEventListener('click', () => { st.target.mode = b.dataset.m; drawTargets(); }));
      $$('[data-g]', box).forEach((c) => c.addEventListener('change', () => { st.target.groups = $$('[data-g]', box).filter((x) => x.checked).map((x) => x.dataset.g); count(); }));
      $$('[data-d]', box).forEach((c) => c.addEventListener('change', () => { st.target.devices = $$('[data-d]', box).filter((x) => x.checked).map((x) => x.dataset.d); count(); }));
      const dq = $('#jdDevQ', box); if (dq) dq.addEventListener('input', () => { const v = dq.value.toLowerCase(); $$('#jdDevList label', box).forEach((l) => { l.hidden = !!v && !l.dataset.n.includes(v); }); });
      st.target.mode = mode;
      count();
    }
    function count() {
      const s = script(), out = $('#jdCount', m);
      if (!s || !out) return;
      const list = JD.targetsOf({ target: st.target }, s, tree.devices, chainOf);
      out.innerHTML = list.length ? `Runs on <b>${list.length}</b> device${list.length === 1 ? '' : 's'} now: ${esc(list.slice(0, 6).map((d) => d.name).join(', '))}${list.length > 6 ? ' …' : ''}` : '<span style="color:var(--warn-ink)">No device matches yet.</span>';
    }
    function drawCred() {
      const s = script(), box = $('#jdCred', m);
      if (!s) { box.innerHTML = '<p class="muted">Choose an action first.</p>'; return; }
      const kind = s.credential;
      const fit = creds.filter((c) => !kind || c.kind === kind);
      box.innerHTML = `<div class="field"><select class="input" id="jdCredSel"><option value="">${kind ? 'The ' + esc(CRED_NAME[kind] || kind) + ' assigned to each device or its group' : 'The MonCastle engine account'}</option>${fit.map((c) => `<option value="${esc(c.id)}" ${c.id === st.credential ? 'selected' : ''}>${esc(c.name)} (${esc(c.kindName || c.kind)})</option>`).join('')}</select>
        <span class="hint">${kind ? 'Pick an account to run this job as a dedicated service account (for example a patching or backup account) on every target. ' : ''}${s.permissions ? 'The account needs: ' + esc(s.permissions) : ''} Add accounts under <a href="#/credentials">Settings › Credentials</a>; their passwords stay in the secure store.</span></div>`;
      $('#jdCredSel', box).addEventListener('change', (e) => { st.credential = e.target.value || null; });
    }
    function drawWhen() {
      const sc = st.schedule, box = $('#jdWhen', m);
      const times = (sc.times || [sc.time || '02:00']).join(', ');
      const ev = /^(\d+)([mhd])$/.exec(sc.every || '1h') || [null, '1', 'h'];
      box.innerHTML = `<div class="jd-row"><div class="field"><label for="jdType">Repeat</label><select class="input" id="jdType">${Object.entries(JD.TYPES).map(([k, t]) => `<option value="${k}" ${sc.type === k ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></div>
        ${sc.type === 'interval' ? `<div class="field"><label for="jdEvery">Every</label><div style="display:flex;gap:6px"><input class="input" id="jdEvery" type="number" min="1" value="${esc(ev[1])}" style="width:90px"><select class="input" id="jdUnit" style="width:auto"><option value="m" ${ev[2] === 'm' ? 'selected' : ''}>minutes</option><option value="h" ${ev[2] === 'h' ? 'selected' : ''}>hours</option><option value="d" ${ev[2] === 'd' ? 'selected' : ''}>days</option></select></div></div>` : ''}
        ${['daily', 'weekly', 'monthly'].includes(sc.type) ? `<div class="field"><label for="jdTimes">At</label><input class="input mono" id="jdTimes" value="${esc(times)}" placeholder="02:00 or 08:00, 20:00"></div>` : ''}
        ${sc.type === 'monthly' ? `<div class="field"><label for="jdDay">Day of month</label><input class="input" id="jdDay" type="number" min="1" max="31" value="${esc(sc.day || 1)}" style="width:90px"></div>` : ''}
        ${sc.type === 'once' ? `<div class="field"><label for="jdAt">On</label><input class="input" id="jdAt" type="datetime-local" value="${esc(sc.at || '')}"></div>` : ''}</div>
        ${sc.type === 'weekly' ? `<div class="jd-days">${JD.DAYS.map((d, i) => `<label class="check"><input type="checkbox" data-day="${i}" ${(sc.days || [1]).includes(i) ? 'checked' : ''}> ${d}</label>`).join('')}</div>` : ''}
        ${!['once', 'manual'].includes(sc.type) ? `<div class="jd-row"><div class="field"><label for="jdStart">Starting</label><input class="input" id="jdStart" type="date" value="${esc(sc.start || '')}"></div><div class="field"><label for="jdEnd">Until</label><input class="input" id="jdEnd" type="date" value="${esc(sc.end || '')}"></div></div>` : ''}
        <p id="jdNext" class="muted" style="margin:4px 0 0;font-size:13px"></p>`;
      $('#jdType', box).addEventListener('change', (e) => { readWhen(); st.schedule.type = e.target.value; if (e.target.value === 'interval' && !st.schedule.every) st.schedule.every = '4h'; if (e.target.value === 'weekly' && !(st.schedule.days || []).length) st.schedule.days = [1]; drawWhen(); });
      box.addEventListener('input', next); box.addEventListener('change', next);
      next();
    }
    function readWhen() {
      const sc = { type: ($('#jdType', m) || {}).value || st.schedule.type };
      const v = (id) => { const e = $(id, m); return e ? e.value.trim() : ''; };
      if (sc.type === 'interval') sc.every = (v('#jdEvery') || '1') + (v('#jdUnit') || 'h');
      if (['daily', 'weekly', 'monthly'].includes(sc.type)) sc.times = v('#jdTimes').split(/[,;\s]+/).filter(Boolean);
      if (sc.type === 'weekly') sc.days = $$('[data-day]', m).filter((x) => x.checked).map((x) => +x.dataset.day);
      if (sc.type === 'monthly') sc.day = +v('#jdDay') || 1;
      if (sc.type === 'once') sc.at = v('#jdAt');
      if (v('#jdStart')) sc.start = v('#jdStart');
      if (v('#jdEnd')) sc.end = v('#jdEnd');
      st.schedule = sc;
      return sc;
    }
    function next() {
      const sc = readWhen(), out = $('#jdNext', m);
      if (!out) return;
      if (sc.type === 'manual') { out.textContent = 'Runs only when someone presses Run now.'; return; }
      const n = JD.nextRun({ schedule: sc }, Date.now(), null);
      out.innerHTML = n ? `${esc(JD.describe(sc))}. First run: <b>${esc(dt(new Date(n).toISOString()))}</b>` : '<span style="color:var(--warn-ink)">This schedule has no run left; check the times and dates.</span>';
    }
    function drawOpts() {
      const s = script(), box = $('#jdOpts', m);
      box.innerHTML = `${s && s.supportsWhatIf ? `<label class="check"><input type="checkbox" id="jdWhatIf" ${st.whatIf ? 'checked' : ''}> Preview only (WhatIf): report what would change, change nothing</label>` : ''}
        <label class="check"><input type="checkbox" id="jdEnabled" ${st.enabled !== false ? 'checked' : ''}> Turned on</label>
        <label class="check"><input type="checkbox" id="jdNotify" ${st.notify && st.notify.onFailure ? 'checked' : ''}> Tell someone when a run fails</label>
        <div class="field" style="margin-top:4px"><input class="input" id="jdNotifyTo" placeholder="it-ops@company.com or a Teams / Slack / webhook URL" value="${esc((st.notify && st.notify.to) || '')}"><span class="hint">E-mail uses the SMTP server under Monitoring › Notifications.</span></div>
        ${s && s.risk === 'high' ? `<label class="check" style="margin-top:6px"><input type="checkbox" id="jdConfirm" ${def && def.script === s.id && !def.whatIf ? 'checked' : ''}> <b>Run without asking each time.</b> ${esc(s.title)} is high risk; scheduled runs do not ask for the target name.</label>` : ''}`;
    }

    $('#jdScript', m).addEventListener('change', () => { st.params = {}; drawScript(); });
    drawScript(); drawWhen();
    $('#jdForm', m).addEventListener('submit', async (e) => {
      e.preventDefault();
      const s = script();
      const errBox = $('[data-err]', m);
      const fail = (msg) => { errBox.innerHTML = `<div class="notice err" style="margin-top:10px">${esc(msg)}</div>`; };
      if (!s) return fail('Choose an action.');
      const hp = JD.hostParam(s);
      const stub = Object.assign({}, s, { parameters: (s.parameters || []).filter((p) => !hp || p.name !== hp.name) });
      const { params, errors } = MC.readParams(stub, m);
      if (errors.length) return fail(errors.join(' · '));
      const body = { id: def ? def.id : undefined, name: $('#jdName', m).value.trim(), script: s.id, params, target: hp ? st.target : { mode: 'none' }, credential: ($('#jdCredSel', m) || {}).value || null, schedule: readWhen(),
        enabled: $('#jdEnabled', m).checked, whatIf: !!($('#jdWhatIf', m) || {}).checked, notify: { onFailure: $('#jdNotify', m).checked, to: $('#jdNotifyTo', m).value.trim() }, confirmHighRisk: !!($('#jdConfirm', m) || {}).checked };
      try { JD.clean(body, s); } catch (x) { return fail(x.message); }
      if (body.notify.onFailure && !body.notify.to) return fail('Enter an e-mail address or webhook URL to tell, or untick "Tell someone when a run fails".');
      const btn = $('button[type=submit]', m); btn.disabled = true;
      try {
        const r = await MC.api.saveJobdef(body);
        close();
        MC.toast(`${def ? 'Saved' : 'Created'} <b>${esc(r.name)}</b>: ${esc(r.when)}${r.nextRun ? ', next ' + esc(until(r.nextRun)) : ''}`, 'ok');
        if (MC.route.page === 'actions' && MC.route.tab === 'jobs' && V.actions.refresh) V.actions.refresh(); else MC.go('actions', 'jobs');
      } catch (x) { btn.disabled = false; fail(x.message); }
    });
  }
  MC.jobDialog = jobDialog;
})(window);
