/*
 * RoboMate MonCastle - monitoring core (PRTG-style): device tree, sensor states, limits, history, state log,
 * alarms with acknowledge, notification rules and auto-discovery. Shared by the server (real probes, files on disk)
 * and the browser demo (simulated probes, memory only), so both behave the same.
 *
 * createCore({ sensors: MCSensors, datasets(), config, save(config), probe(sensor) -> Promise<reading>,
 *              notify(rule, target, event), seed(sensor, channels) -> history|null, now(), probeName })
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCMonitorCore = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const LIVE_MAX = 180, FIVE_MAX = 600, HOUR_MAX = 760, LOG_MAX = 3000;
  const uid = (p) => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const clone = (x) => JSON.parse(JSON.stringify(x));

  function createCore(o) {
    const S = o.sensors;
    const now = o.now || (() => Date.now());
    const cfg = Object.assign({ groups: [], devices: [], sensors: [], overrides: {}, deviceOverrides: {}, notifications: { rules: [], smtp: {} }, dismissed: [], removedDevices: [], integrations: [], engineSensors: [], profiles: [] }, o.config || {});
    cfg.profiles = Array.isArray(cfg.profiles) ? cfg.profiles : [];
    cfg.engineSensors = cfg.engineSensors || [];
    cfg.notifications = Object.assign({ rules: [], smtp: {} }, cfg.notifications || {});
    const save = () => o.save && o.save(cfg);
    // drop probe sensors that were added twice before duplicates were refused (keeps the first one)
    { const seen = new Set(); cfg.sensors = cfg.sensors.filter((x) => { const k = x.device + '#' + S.sensorKey(x.type, x.params); if (seen.has(k)) return false; seen.add(k); return true; }); }

    const state = new Map(); // sensorId -> { state, message, channels, lastScan, since, upMs, downMs, lastCheck }
    const hist = new Map(); // sensorId -> { names:[], live:[[t,...]], five:[[t,...]], hour:[[t,...]] }
    let log = [];
    let derived = { devices: new Map(), sensors: [] };
    let derivedAt = 0, dsStamp = '';
    const pending = new Map(); // notification delays

    // ---------------------------------------------------------------- history
    function pushHistory(id, channels, t) {
      const names = channels.map((c) => c.name);
      let h = hist.get(id);
      if (!h || h.names.join('|') !== names.join('|')) { h = { names, live: [], five: [], hour: [], dirty: true }; hist.set(id, h); }
      const vals = channels.map((c) => (c.value == null ? null : +c.value));
      h.live.push([t, ...vals]);
      if (h.live.length > LIVE_MAX) h.live.splice(0, h.live.length - LIVE_MAX);
      const drop5 = bucket(h.five, t, 5 * 60e3, vals, FIVE_MAX);
      const drop1h = bucket(h.hour, t, 3600e3, vals, keepHours(id));
      // data leaving the live history goes to the archive (retention policy), never just away
      if (o.archive && sensorConf(id).archive !== false && (drop5.length || drop1h.length)) { const s = allSensors().find((x) => x.id === id) || {}; const ref = { id, name: (sensorConf(id).name || s.name), device: s.device, names }; if (drop5.length) o.archive('sensors-5m', ref, drop5); if (drop1h.length) o.archive('sensors-1h', ref, drop1h); }
      h.dirty = true;
    }
    // how long hourly averages stay in the live history: the sensor's own retention, else the system policy
    function keepHours(id) { const d = sensorConf(id).retentionDays || (o.retention && o.retention().historyDays) || 31; return Math.max(24, Math.min(3660, d) * 24); }
    // running average per bucket: [bucketStart, ...avg, n]; returns the buckets that fell out
    function bucket(arr, t, size, vals, max) {
      const b = Math.floor(t / size) * size;
      const last = arr[arr.length - 1];
      if (last && last[0] === b) {
        const n = last[last.length - 1];
        vals.forEach((v, i) => { if (v == null) return; last[i + 1] = last[i + 1] == null ? v : (last[i + 1] * n + v) / (n + 1); });
        last[last.length - 1] = n + 1;
        return [];
      }
      arr.push([b, ...vals, 1]);
      return arr.length > max ? arr.splice(0, arr.length - max) : [];
    }
    // retention run: trim every sensor to its retention (after a policy change), handing the rest to the archive
    function applyRetention() {
      let rows = 0;
      for (const [id, h] of hist) {
        const max = keepHours(id);
        if (h.hour.length > max) { const out = h.hour.splice(0, h.hour.length - max); rows += out.length; h.dirty = true; if (o.archive && sensorConf(id).archive !== false) { const s = allSensors().find((x) => x.id === id) || {}; o.archive('sensors-1h', { id, name: sensorConf(id).name || s.name, device: s.device, names: h.names }, out); } }
      }
      const days = (o.retention && o.retention().logDays) || 0;
      if (days) { const cut = new Date(now() - days * 864e5).toISOString(); const i = log.findIndex((e) => e.t < cut); if (i >= 0) { const out = log.splice(i); rows += out.length; if (o.archive) o.archive('alarms', null, out); } }
      return rows;
    }

    // ---------------------------------------------------------------- state
    function sensorConf(id) { return cfg.overrides[id] || {}; }
    function deviceOf(id) { return cfg.devices.find((d) => d.id === id) || (isRemoved(id) ? null : derived.devices.get(id)); }
    // engine-found devices the user removed: hidden with their sensors until restored, even while an engine still reports them
    const isRemoved = (id) => cfg.removedDevices.some((r) => r.id === id);
    function isPaused(sensor) {
      const ov = sensorConf(sensor.id), dov = cfg.deviceOverrides[sensor.device] || {};
      const until = (x) => x && x.paused && (!x.pausedUntil || Date.parse(x.pausedUntil) > now());
      return until(ov) || until(dov);
    }

    function record(sensor, reading, t) {
      t = t || now();
      const ov = sensorConf(sensor.id);
      const ev = S.evaluate(reading, ov.limits);
      const prev = state.get(sensor.id);
      const st = prev ? Object.assign({}, prev) : { since: t, upMs: 0, downMs: 0 };
      if (prev && prev.lastCheck) {
        const dt = Math.min(t - prev.lastCheck, 6 * 3600e3);
        if (prev.state === 'Down') st.downMs += dt; else if (prev.state !== 'Paused' && prev.state !== 'Unknown') st.upMs += dt;
      }
      st.state = ev.state; st.message = ev.message; st.channels = ev.channels; st.lastScan = t; st.lastCheck = t;
      if (ev.state === 'Up' || ev.state === 'Warning') st.lastUp = t;
      if (ev.state === 'Down') st.lastDown = t;
      let from = null;
      if (!prev || prev.state !== ev.state) {
        st.since = t;
        // first result of a probe sensor counts as a change from Unknown, so a new sensor that is down alerts at once
        if (prev && prev.state) from = prev.state;
        else if (sensor.source === 'native' && ev.state !== 'Up') from = 'Unknown';
        if (ev.state === 'Up' && ov.ack) { delete ov.ack; save(); }
      }
      state.set(sensor.id, st);
      if (from) change(sensor, from, ev.state, ev.message, t);
      if (ev.channels.length) pushHistory(sensor.id, ev.channels, t);
      return st;
    }

    function change(sensor, from, to, message, t) {
      const dev = deviceOf(sensor.device) || {};
      const entry = { t: new Date(t).toISOString(), sensor: sensor.id, sensorName: sensor.name, device: sensor.device, deviceName: dev.name, from, to, message };
      log.unshift(entry);
      if (log.length > LOG_MAX) { const out = log.splice(LOG_MAX); if (o.archive) o.archive('alarms', null, out); }
      if (o.onLog) o.onLog(entry);
      const gname = (cfg.groups.find((g) => g.id === dev.group) || {}).name || '';
      entry.groupName = gname;
      for (const rule of cfg.notifications.rules || []) {
        if (rule.enabled === false || !(rule.on || []).includes(to)) continue;
        if (!inScope(rule, sensor, dev)) continue;
        const key = rule.id + '|' + sensor.id;
        clearTimeout(pending.get(key));
        const fire = () => {
          pending.delete(key);
          if (!stillTrue(sensor, to)) return;
          for (const target of resolveTargets(rule.targets || [])) o.notify && o.notify(rule, target, entry);
        };
        if (rule.delayMin > 0 && to !== 'Up') pending.set(key, setTimeout(fire, rule.delayMin * 60e3)); else fire();
      }
      // egress and incident integrations: every enabled one whose filter matches
      for (const ob of cfg.outbound || []) {
        if (ob.enabled === false || !(ob.on || []).includes(to) || !inScope(ob, sensor, dev)) continue;
        const key = ob.id + '|' + sensor.id;
        clearTimeout(pending.get(key));
        const fire = () => { pending.delete(key); if (to === 'Up' || stillTrue(sensor, to)) o.outbound && o.outbound(clone(ob), entry); };
        if (ob.delayMin > 0 && to !== 'Up') pending.set(key, setTimeout(fire, ob.delayMin * 60e3)); else fire();
      }
    }
    function stillTrue(sensor, to) {
      const cur = state.get(sensor.id);
      if (!cur || cur.state !== to) return false; // recovered during the delay
      if (sensorConf(sensor.id).ack && to !== 'Up') return false; // acknowledged alarms stay quiet
      if (to !== 'Up') { const mine = S.markRelated(allSensors().filter((x) => x.device === sensor.device).map(sensorView)).find((v) => v.id === sensor.id); if (mine && mine.related) return false; } // covered by another alarm on this device
      return true;
    }
    // which alarms a rule or integration covers: any of its groups (with sub-groups), devices or sensors (none = all),
    // and, when sensor types are picked, only those types
    function inScope(r, sensor, dev) {
      const groups = r.groups || (r.group ? [r.group] : []), devices = r.devices || (r.device ? [r.device] : []), sensors = r.sensors || (r.sensor ? [r.sensor] : []);
      if (groups.length + devices.length + sensors.length) {
        const chain = [].concat(...deviceGroupsOf(dev.id, dev).map((g) => [g].concat(groupChain(g) || [])));
        if (!groups.some((g) => chain.includes(g)) && !devices.includes(sensor.device) && !sensors.includes(sensor.id)) return false;
      }
      if ((r.types || []).length && !r.types.includes(sensor.type)) return false;
      return true;
    }
    // user and user-group targets become e-mails to the addresses in the user directory (host.directory)
    function resolveTargets(list) {
      const dir = (o.directory && o.directory()) || { users: [], groups: [] };
      const mail = (n) => (dir.users.find((u) => u.name === n) || {}).email;
      const out = [];
      for (const t of list) {
        if (t.kind === 'user') { const m = mail(t.name); if (m) out.push({ kind: 'email', to: m, via: 'user ' + t.name }); else out.push({ kind: 'email', to: '', via: 'user ' + t.name, missing: t.name + ' has no e-mail address' }); }
        else if (t.kind === 'usergroup') {
          const g = dir.groups.find((x) => x.id === t.id);
          const to = g ? g.members.map(mail).filter(Boolean) : [];
          out.push({ kind: 'email', to: [...new Set(to)].join('; '), via: 'user group ' + (g ? g.name : t.id), missing: !g ? 'user group was deleted' : !to.length ? 'no member of ' + g.name + ' has an e-mail address' : '' });
        } else out.push(t);
      }
      return out;
    }
    // a device's groups: its primary group first, then the extra groups it is also a member of (4.7.4)
    function deviceGroupsOf(id, d) {
      const dov = cfg.deviceOverrides[id] || {};
      const own = cfg.devices.find((x) => x.id === id);
      const prim = dov.group || (d && d.group) || (own && own.group) || ((allDevices().get(id) || {}).group) || 'g:srv';
      const also = (own && Array.isArray(own.also) ? own.also : Array.isArray(dov.also) ? dov.also : []);
      return [prim].concat(also.filter((g) => g !== prim)).filter((g, i, a) => a.indexOf(g) === i);
    }
    function groupChain(gid) {
      const out = []; let g = cfg.groups.find((x) => x.id === gid);
      while (g && g.parent && g.parent !== 'probe' && out.length < 10) { out.push(g.parent); g = cfg.groups.find((x) => x.id === g.parent); }
      return out;
    }

    // ---------------------------------------------------------------- collector sensors (from datasets)
    // re-entrant calls (a notification fired while recording asks for allSensors) use the sensors being built
    let refreshing = false;
    function refreshDerived(force) {
      if (refreshing) return;
      refreshing = true;
      try { refreshNow(force); } finally { refreshing = false; }
    }
    function refreshNow(force) {
      const ds = o.datasets() || {};
      const stamp = Object.keys(ds).map((k) => k + ':' + (ds[k] && ds[k].finished)).join('|');
      if (!force && stamp === dsStamp && now() - derivedAt < 60e3) return;
      const before = new Map(derived.sensors.map((s) => [s.id, s.lastScan]));
      const alias = {};
      for (const d of cfg.devices || []) { if (d.host) alias[String(d.host).toLowerCase()] = d.name; if (d.name) alias[String(d.name).toLowerCase()] = d.name; }
      derived = S.derive(ds, { now: now(), alias });
      for (const dv of derived.devices.values()) {
        const ov = cfg.deviceOverrides[dv.id];
        if (ov && ov.group) dv.group = ov.group;
        if (ov && ov.name) dv.label = ov.name;
      }
      dsStamp = stamp; derivedAt = now();
      pruneCovered();
      const schedule = Object.fromEntries((o.scripts ? o.scripts() : []).map((x) => [x.id, x.schedule]));
      for (const s of derived.sensors) {
        if (cfg.dismissed.includes(s.id) || isRemoved(s.device)) continue;
        if (isPaused(s)) { setPaused(s); continue; }
        const t = s.lastScan ? Date.parse(s.lastScan) : now();
        const stale = s.staleMinutes != null && staleLimit(schedule[s.script]) && s.staleMinutes > staleLimit(schedule[s.script]);
        const reading = stale ? { channels: [], forced: 'Unknown', message: 'No new data for ' + Math.round(s.staleMinutes) + ' min; check the ' + s.script + ' engine' } : s.reading;
        if (before.get(s.id) !== s.lastScan || !state.has(s.id) || stale || state.get(s.id).state === 'Paused') record(s, reading, stale ? now() : t);
      }
    }
    const staleLimit = (every) => { const m = /^(\d+)\s*([smhd])$/i.exec(String(every || '')); if (!m) return null; const min = +m[1] * { s: 1 / 60, m: 1, h: 60, d: 1440 }[m[2].toLowerCase()]; return Math.max(30, min * 3); };
    function setPaused(s) {
      const prev = state.get(s.id);
      if (prev && prev.state === 'Paused') return;
      state.set(s.id, Object.assign({}, prev || { upMs: 0, downMs: 0 }, { state: 'Paused', message: 'Paused by ' + ((sensorConf(s.id).pausedBy) || (cfg.deviceOverrides[s.device] || {}).pausedBy || 'user'), since: now() }));
      if (prev && prev.state !== 'Paused') change(s, prev.state, 'Paused', 'Paused', now());
    }

    // ---------------------------------------------------------------- native sensors (run by the probe)
    const running = new Set();
    function nativeSensors() { return cfg.sensors.map((s) => Object.assign({ source: 'native' }, s)); }
    // multi-server: every device is monitored by one MonCastle server (default: this one). The demo runs them all.
    const LOCAL = o.serverId || 'srv:local';
    function serverOf(devId) { const own = cfg.devices.find((d) => d.id === devId); return (cfg.deviceOverrides[devId] || {}).server || (own && own.server) || LOCAL; }
    const mine = (s) => o.runAll || serverOf(s.device) === LOCAL;
    function due() {
      const t = now();
      return nativeSensors().filter((s) => {
        if (running.has(s.id) || !mine(s) || (S.TYPE[s.type] || {}).passive) return false;
        if (isPaused(s)) { setPaused(s); return false; }
        const st = state.get(s.id);
        const every = (sensorConf(s.id).interval || s.interval || (S.TYPE[s.type] || {}).interval || 60) * 1000;
        return !st || !st.lastScan || st.state === 'Paused' || t - st.lastScan >= every || st.scanNow;
      });
    }
    async function runDue(limit = 16) {
      const list = due().slice(0, limit);
      await Promise.all(list.map(scan));
      return list.length;
    }
    async function scan(s) {
      running.add(s.id);
      const st = state.get(s.id); if (st) st.scanNow = false;
      let reading;
      try {
        const lim = sensorConf(s.id).limits;
        if (s.direct) reading = o.direct ? await o.direct(s, deviceOf(s.device)) : S.directReading(s.type, o.datasets() || {}, deviceOf(s.device) || { id: s.device }, { item: (s.params || {}).item, simulate: true, now: now() });
        else reading = await o.probe(lim ? Object.assign({}, s, { limits: Object.values(lim)[0] }) : s, deviceOf(s.device));
      } catch (e) { reading = { channels: [], forced: 'Down', message: e.message || String(e) }; }
      running.delete(s.id);
      if (!cfg.sensors.find((x) => x.id === s.id)) return; // deleted while running
      const t = now();
      ingest(s, reading, t);
      if (o.onReading) o.onReading(s.id, reading, t); // a remote MonCastle server forwards it to the central console
    }
    function ingest(s, reading, t) {
      const type = S.TYPE[s.type] || {};
      const defs = Object.fromEntries((type.channels || []).map((c) => [c.name, c]));
      reading.channels = (reading.channels || []).map((c) => Object.assign({ limits: (defs[c.name] || {}).limits || {}, unit: (defs[c.name] || {}).unit || '' }, c));
      record(s, reading, t);
    }
    // central console: a reading that a remote MonCastle server took for one of its devices
    function applyReading(id, reading, t, server) {
      const s = cfg.sensors.find((x) => x.id === id);
      if (!s || serverOf(s.device) !== server || isPaused(s)) return false;
      const st = state.get(id);
      const at = Math.min(+t || now(), now());
      if (st && st.lastScan && at <= st.lastScan) return false;
      ingest(Object.assign({ source: 'native' }, s), { channels: (reading.channels || []).slice(0, 20).map((c) => ({ name: String(c.name).slice(0, 80), unit: String(c.unit || '').slice(0, 12), value: c.value == null || isNaN(+c.value) ? null : +c.value, primary: !!c.primary })), forced: ['Down', 'Warning'].includes(reading.forced) ? reading.forced : undefined, message: reading.message ? String(reading.message).slice(0, 500) : undefined }, at);
      return true;
    }
    // remote MonCastle server: the devices and sensors the central console assigned to it
    function loadAssigned(conf) {
      cfg.devices = (conf.devices || []).map((d) => Object.assign({}, d, { server: LOCAL }));
      cfg.sensors = conf.sensors || [];
      cfg.overrides = conf.overrides || {};
      cfg.deviceOverrides = {};
      for (const id of [...state.keys()]) if (!cfg.sensors.find((x) => x.id === id)) state.delete(id);
    }
    // what each MonCastle server monitors (devices and probe sensors)
    function serverLoad() {
      const out = {};
      for (const [id] of allDevices()) { const sv = serverOf(id); out[sv] = out[sv] || { devices: 0, sensors: 0, down: 0 }; out[sv].devices++; }
      for (const s of cfg.sensors) { const sv = serverOf(s.device); out[sv] = out[sv] || { devices: 0, sensors: 0, down: 0 }; out[sv].sensors++; if ((state.get(s.id) || {}).state === 'Down') out[sv].down++; }
      return out;
    }

    // ---------------------------------------------------------------- views
    function allSensors() {
      refreshDerived();
      const list = derived.sensors.filter((s) => !cfg.dismissed.includes(s.id) && !isRemoved(s.device) && optionAllows(s));
      return list.concat(pendingSensors(list), nativeSensors());
    }
    // engine sensor types on a device (reported or requested): the probe checks they cover are not added twice
    function engineTypesOf(devId) {
      const t = derived.sensors.filter((x) => x.device === devId && !cfg.dismissed.includes(x.id) && optionAllows(x)).map((x) => x.type);
      return [...new Set(t.concat(cfg.engineSensors.filter((r) => r.device === devId).map((r) => r.type)))];
    }
    // adds the default probe checks of a discovered or imported device, skipping those an engine sensor already makes
    function addTemplate(devId, kind, host, ports) {
      const et = engineTypesOf(devId);
      for (const t of S.templateFor(kind, host, ports || [])) {
        if (S.coveredBy(t, et)) continue;
        const v = addSensor({ device: devId, type: t.type, params: t.params, name: t.name, quiet: true });
        const n = cfg.sensors.find((x) => x.id === v.id); if (n) n.tpl = true;
      }
    }
    // after the engines report: drop template checks that an engine sensor on the same device now covers
    function pruneCovered() {
      const before = cfg.sensors.length;
      cfg.sensors = cfg.sensors.filter((x) => {
        if (!x.tpl || !S.coveredBy(x, engineTypesOf(x.device))) return true;
        state.delete(x.id); hist.delete(x.id); delete cfg.overrides[x.id];
        return false;
      });
      if (cfg.sensors.length !== before) save();
    }
    // engine sensors a user added to a device before the engine has reported it: shown as Unknown with what is missing
    function pendingSensors(list) {
      const have = new Set((list || derived.sensors).map((x) => x.device + '|' + x.type));
      return cfg.engineSensors.filter((r) => !have.has(r.device + '|' + r.type) && !isRemoved(r.device)).map((r) => { const t = S.TYPE[r.type] || {}; return { id: r.id, device: r.device, type: r.type, name: r.name, source: 'collector', script: t.script, dataset: t.dataset, pending: true, requested: r.at, requestedBy: r.by, profile: r.profile || null }; });
    }
    // monitoring options chosen for a device (own devices, or overrides on engine-found devices); null = everything
    function monitorOf(devId) { const own = cfg.devices.find((d) => d.id === devId); const ov = cfg.deviceOverrides[devId] || {}; return (own && own.monitor) || ov.monitor || null; }
    function credentialsOf(devId) { const own = cfg.devices.find((d) => d.id === devId); const ov = cfg.deviceOverrides[devId] || {}; return Object.assign({}, ov.credentials || {}, (own && own.credentials) || {}); }
    function optionAllows(sensor) { const m = monitorOf(sensor.device); const opts = S.TYPE_OPTION[sensor.type]; return !m || !opts || opts.some((o) => m.includes(o)); }
    // engine targets added through monitoring options: { scriptId: [host, …] } (read by Get-MCTarget via MC_EXTRA_TARGETS)
    function targets() {
      const out = {};
      for (const [id, d] of allDevices()) {
        const m = monitorOf(id); if (!m) continue;
        // API collectors (OpenShift, Nutanix) need the address; the others use the device name
        for (const o of S.OPTIONS) if (o.script && m.includes(o.id)) { const n = ['mon.openshift', 'mon.nutanix'].includes(o.script) ? d.host || d.name : d.name; (out[o.script] = out[o.script] || []).includes(n) || out[o.script].push(n); }
      }
      // devices onboarded by hand, from auto-discovery or an import: the inventory collectors also read them
      for (const d of cfg.devices) { if (d.inventory === false) continue; for (const x of S.inventoryPlan(d)) { if (x.param && x.param(d) !== 'ComputerName') continue; const n = d.host || d.name; (out[x.script] = out[x.script] || []).includes(n) || out[x.script].push(n); } }
      // devices chosen as audit sources (Inventory > Audit): the audit collector reads their event logs too
      for (const [id, d] of allDevices()) { const own = cfg.devices.find((x) => x.id === id); if (!((own && own.audit) || (cfg.deviceOverrides[id] || {}).audit)) continue; const n = d.host || d.name; (out['aud.events'] = out['aud.events'] || []).includes(n) || out['aud.events'].push(n); }
      // engine sensors added by hand: the engine also collects from that device
      const devs = allDevices();
      for (const r of cfg.engineSensors) { const t = S.TYPE[r.type], d = devs.get(r.device); if (!t || !t.script || !d) continue; const n = d.host || d.name; (out[t.script] = out[t.script] || []).includes(n) || out[t.script].push(n); }
      return out;
    }
    function cleanCreds(c) { const out = {}; for (const [k, v] of Object.entries(c || {})) if (/^[a-z0-9]+$/.test(k) && typeof v === 'string' && v.length < 40) out[k] = v; return out; }
    function syncOptionSensors(d, ids, extra) {
      // add probe sensors for newly chosen options, remove the ones whose option was dropped
      const want = S.sensorsForOptions(d.kind, d.host, ids, d.ports || [], extra);
      const have = cfg.sensors.filter((x) => x.device === d.id && x.option);
      for (const x of have) if (!ids.includes(x.option)) { cfg.sensors.splice(cfg.sensors.indexOf(x), 1); state.delete(x.id); }
      for (const o of S.OPTIONS) if (o.native && ids.includes(o.id) && !have.some((x) => x.option === o.id)) {
        for (const t of S.sensorsForOptions(d.kind, d.host, [o.id], d.ports || [], extra)) { const v = addSensor({ device: d.id, type: t.type, params: t.params, name: t.name, limits: t.limits, quiet: true }); const n = cfg.sensors.find((x) => x.id === v.id); if (n) n.option = o.id; }
      }
      return want.length;
    }
    const extraOf = (d, body) => ({ interfaces: (body.interfaces || []).map(Number).filter((n) => n > 0).slice(0, 48), volumes: (body.volumes || []).map(Number).filter((n) => n > 0).slice(0, 32), profile: d.profile || null });
    function allDevices() {
      const m = new Map([...derived.devices].filter(([id]) => !isRemoved(id)));
      for (const d of cfg.devices) m.set(d.id, Object.assign({}, m.get(d.id) || {}, d));
      return m;
    }
    function groups() {
      const base = S.GROUPS.map(([id, name], i) => ({ id, name, parent: 'probe', auto: true, order: i }));
      const custom = cfg.groups.map((g, i) => Object.assign({ order: 100 + i }, g));
      return base.filter((g) => !custom.find((c) => c.id === g.id)).concat(custom);
    }
    function primary(st, type) {
      if (!st || !st.channels || !st.channels.length) return null;
      const p = st.channels.find((c) => c.primary) || st.channels[0];
      return p;
    }
    function fmtVal(c) {
      if (!c || c.value == null) return '';
      const v = Math.abs(c.value) >= 100 || Number.isInteger(c.value) ? Math.round(c.value) : Math.round(c.value * 10) / 10;
      return v + (c.unit && c.unit !== '#' ? ' ' + c.unit : '');
    }
    function sensorView(s) {
      const st = state.get(s.id) || { state: 'Unknown', message: s.pending ? 'Waiting for the ' + s.script + ' engine to report this device; the Requirements steps on the sensor page show what is left' : 'Waiting for the first scan' };
      const ov = sensorConf(s.id);
      const p = primary(st);
      const h = hist.get(s.id);
      const spark = h ? (h.five.length > 4 ? h.five : h.live).slice(-36).map((r) => r[1]) : null;
      return {
        id: s.id, device: s.device, type: s.type, name: ov.name || s.name, source: s.source || 'native', script: s.script || null, dataset: s.dataset || null,
        state: st.state, message: st.message, since: st.since ? new Date(st.since).toISOString() : null, lastScan: st.lastScan ? new Date(st.lastScan).toISOString() : null,
        value: fmtVal(p), primary: p ? p.name : null, ack: ov.ack || null, paused: st.state === 'Paused', interval: ov.interval || s.interval || (S.TYPE[s.type] || {}).interval || null,
        typeName: (S.TYPE[s.type] || {}).name || s.type, pending: !!s.pending, direct: !!s.direct, profile: s.profile || null,
        uptime: st.upMs + st.downMs > 0 ? Math.round((st.upMs / (st.upMs + st.downMs)) * 10000) / 100 : null, spark,
      };
    }
    function tree() {
      const sensors = S.markRelated(allSensors().map(sensorView));
      const byEngine = new Map(); for (const x of derived.sensors) (byEngine.get(x.device) || byEngine.set(x.device, new Set()).get(x.device)).add(x.script);
      const devices = [...allDevices().values()].map((d) => {
        const list = sensors.filter((s) => s.device === d.id);
        const counts = countStates(list);
        const dov = cfg.deviceOverrides[d.id] || {};
        const gl = deviceGroupsOf(d.id, d);
        return { id: d.id, name: dov.name || d.label || d.name, kind: d.kind, group: gl[0], groups: gl, also: gl.slice(1), profiles: cfg.profiles.length ? profilesOf(d.id, d).map((p) => p.id) : [], host: d.host || null, os: d.os || null, site: d.site || null, model: d.model || null, roles: d.roles || null, ports: d.ports || null, profile: d.profile || null, server: serverOf(d.id), manual: !d.auto, origin: d.auto ? 'engine' : d.kind === 'external' ? 'integration' : d.origin || 'manual', foundBy: derived.devices.has(d.id) ? [...(byEngine.get(d.id) || [])] : [], paused: !!dov.paused, monitor: monitorOf(d.id), credentials: credentialsOf(d.id), accessLevel: (cfg.devices.find((x) => x.id === d.id) || {}).accessLevel || 'admin', audit: !!(dov.audit || (cfg.devices.find((x) => x.id === d.id) || {}).audit), state: list.length ? stateOf(counts) : 'Unknown', counts, sensors: list.length };
      }).filter((d) => d.sensors || d.manual);
      const gs = groups().map((g) => {
        const list = devices.filter((d) => d.groups.includes(g.id));
        const counts = list.reduce((a, d) => { for (const k in d.counts) a[k] = (a[k] || 0) + d.counts[k]; return a; }, {});
        return Object.assign({}, g, { devices: list.length, counts, state: list.length ? stateOf(counts) : 'Unknown' });
      });
      const counts = countStates(sensors);
      const open = sensors.filter((x) => !x.related && !x.ack);
      const alarms = { Down: open.filter((x) => x.state === 'Down').length, Warning: open.filter((x) => x.state === 'Warning').length, related: sensors.filter((x) => x.related).length };
      return { probe: { id: 'probe', name: o.probeName || 'Local probe', counts, alarms, state: stateOf(counts) }, groups: gs, devices, sensors, servers: o.servers ? o.servers() : [], removed: cfg.removedDevices.map((r) => Object.assign({}, r, { reported: derived.devices.has(r.id) })), generated: new Date(now()).toISOString() };
    }
    const countStates = (list) => list.reduce((a, s) => { a[s.state] = (a[s.state] || 0) + 1; if (s.ack && s.state === 'Down') a.Acknowledged = (a.Acknowledged || 0) + 1; return a; }, {});
    const stateOf = (c) => (c.Down ? 'Down' : c.Warning ? 'Warning' : c.Up ? 'Up' : c.Paused ? 'Paused' : 'Unknown');

    // last channel values of many sensors at once (gauges, dashboards, reports): filter by device, sensor type or ids
    function channels(f) {
      const ids = f.ids ? new Set(String(f.ids).split(',')) : null;
      return allSensors().filter((s) => (!f.device || s.device === f.device) && (!f.type || s.type === f.type) && (!ids || ids.has(s.id))).slice(0, 2000).map((s) => {
        const st = state.get(s.id) || {};
        const v = sensorView(s);
        return { id: s.id, device: s.device, deviceName: (allDevices().get(s.device) || {}).name, type: s.type, name: v.name, state: v.state, ack: v.ack, value: v.value, spark: v.spark, channels: (st.channels || []).map((c) => ({ name: c.name, unit: c.unit, value: c.value, text: fmtVal(c), state: c.state, primary: c.name === v.primary, limits: c.limits || {} })) };
      });
    }
    function detail(id) {
      const s = allSensors().find((x) => x.id === id);
      if (!s) return null;
      const st = state.get(id) || {};
      let h = hist.get(id);
      if ((!h || h.five.length < 3) && o.seed && st.channels && st.channels.length) {
        const seeded = o.seed(s, st.channels);
        if (seeded) { hist.set(id, Object.assign({ names: st.channels.map((c) => c.name) }, seeded)); h = hist.get(id); }
      }
      const type = S.TYPE[s.type] || {};
      const dev = allDevices().get(s.device) || {};
      const ov = sensorConf(id);
      const strip = (arr) => (arr || []).map((r) => r.slice(0, (h.names.length + 1)));
      return Object.assign(sensorView(s), {
        typeName: type.name, category: type.category, desc: type.desc, deviceName: dev.name, deviceHost: dev.host, deviceKind: dev.kind || null, deviceProfile: dev.profile || null, deviceServer: serverOf(s.device),
        channels: (st.channels || []).map((c) => ({ name: c.name, unit: c.unit, value: c.value, text: fmtVal(c), state: c.state, primary: !!c.primary || c.name === (primary(st) || {}).name, limits: c.limits || {} })),
        params: s.params ? maskParams(s.params, type) : null, overrides: { interval: ov.interval || null, limits: ov.limits || {}, retentionDays: ov.retentionDays || null, archive: ov.archive !== false }, retention: { days: keepHours(s.id) / 24, policyDays: (o.retention && o.retention().historyDays) || 31 },
        history: h ? { names: h.names, live: strip(h.live), five: strip(h.five), hour: strip(h.hour) } : { names: [], live: [], five: [], hour: [] },
        log: log.filter((e) => e.sensor === id).slice(0, 100),
        downMs: st.downMs || 0, upMs: st.upMs || 0, lastUp: st.lastUp ? new Date(st.lastUp).toISOString() : null, lastDown: st.lastDown ? new Date(st.lastDown).toISOString() : null,
      });
    }
    function maskParams(p, type) {
      const out = Object.assign({}, p);
      for (const d of type.params || []) if (d.secret && out[d.name]) out[d.name] = '••••••';
      return out;
    }

    // ---------------------------------------------------------------- changes
    const bad = (m, status = 400) => Object.assign(new Error(m), { status });
    function sensorAction(id, action, by, opts = {}) {
      const s = allSensors().find((x) => x.id === id);
      if (!s) throw bad('No such sensor', 404);
      const ov = (cfg.overrides[id] = cfg.overrides[id] || {});
      if (action === 'pause') { ov.paused = true; ov.pausedBy = by; ov.pausedUntil = opts.minutes ? new Date(now() + opts.minutes * 60e3).toISOString() : null; setPaused(s); }
      else if (action === 'resume') { delete ov.paused; delete ov.pausedUntil; delete ov.pausedBy; const st = state.get(id); if (st) { st.state = 'Unknown'; st.message = 'Resumed, waiting for the next scan'; st.scanNow = true; } if (s.source === 'collector') refreshDerived(true); }
      else if (action === 'scan') { const st = state.get(id); if (st) st.scanNow = true; else state.set(id, { scanNow: true, upMs: 0, downMs: 0 }); }
      else if (action === 'ack') { const st = state.get(id); if (!st || st.state !== 'Down' && st.state !== 'Warning') throw bad('Only alarms (down or warning) can be acknowledged'); ov.ack = { by, at: new Date(now()).toISOString(), note: String(opts.note || '').slice(0, 300) }; }
      else if (action === 'unack') delete ov.ack;
      else throw bad('Unknown action ' + action);
      save();
      return sensorView(s);
    }
    function setSensorSettings(id, body) {
      const s = allSensors().find((x) => x.id === id);
      if (!s) throw bad('No such sensor', 404);
      const ov = (cfg.overrides[id] = cfg.overrides[id] || {});
      if (body.name != null) ov.name = String(body.name).slice(0, 120) || undefined;
      if (body.interval != null) { const n = +body.interval; if (!(n >= 30 && n <= 86400)) throw bad('Interval must be 30 to 86400 seconds'); ov.interval = n; }
      if (body.retentionDays !== undefined) { const n = body.retentionDays === '' || body.retentionDays === null ? null : +body.retentionDays; if (n != null && !(n >= 1 && n <= 3650)) throw bad('Keep history for 1 to 3650 days'); ov.retentionDays = n || undefined; }
      if (body.archive !== undefined) ov.archive = body.archive === false ? false : undefined;
      if (body.limits) {
        ov.limits = ov.limits || {};
        for (const [chName, l] of Object.entries(body.limits)) {
          const clean = {};
          for (const k of ['warnHigh', 'errHigh', 'warnLow', 'errLow']) if (l[k] !== '' && l[k] != null && !Number.isNaN(+l[k])) clean[k] = +l[k]; else if (l[k] === '' || l[k] === null) clean[k] = null;
          ov.limits[chName] = clean;
        }
      }
      const native = cfg.sensors.find((x) => x.id === id);
      if (native && native.direct && body.params) { const item = String(body.params.item || '').trim().slice(0, 120); if (item && !/^[\w .:$\\/-]+$/.test(item)) throw bad('Item may only hold letters, digits, spaces and . : $ \\ / -'); native.params = item ? { item } : {}; }
      else if (native && body.params) native.params = Object.assign({}, native.params, cleanParams(native.type, body.params, native.params));
      save();
      const st = state.get(id);
      if (st && st.channels) { const ev = S.evaluate({ channels: st.channels.map((c) => ({ name: c.name, unit: c.unit, value: c.value, primary: c.primary, limits: ((S.TYPE[s.type] || {}).channels || []).find((d) => d.name === c.name)?.limits || c.limits })) }, ov.limits); const prevState = st.state; Object.assign(st, { channels: ev.channels }); if (prevState !== 'Paused' && ev.state !== prevState) { st.state = ev.state; st.message = ev.message; change(s, prevState, ev.state, ev.message, now()); st.since = now(); } }
      return detail(id);
    }
    function cleanParams(type, p, old) {
      const t = S.TYPE[type];
      if (!t) throw bad('Unknown sensor type ' + type);
      const out = {};
      for (const d of t.params || []) {
        let v = p[d.name];
        if ((v === '••••••' || v === undefined) && old && old[d.name] != null) v = old[d.name];
        if (v === undefined || v === '') v = d.def;
        if (v === undefined) continue;
        if (d.type === 'int') { v = parseInt(v, 10); if (Number.isNaN(v) || (d.min != null && v < d.min) || (d.max != null && v > d.max)) throw bad(d.label + ' is out of range'); }
        else { v = String(v).trim(); if (v.length > 2000 || /[\u0000-\u001f]/.test(v)) throw bad(d.label + ' is not valid'); if (d.values && !d.values.includes(v)) throw bad(d.label + ' must be one of ' + d.values.join(', ')); }
        out[d.name] = v;
      }
      return out;
    }
    function addSensor(body) {
      const t = S.TYPE[body.type];
      if (!t) throw bad('Unknown sensor type');
      const dev = allDevices().get(body.device);
      if (!dev) throw bad('No such device', 404);
      if (t.source !== 'native' && body.mode !== 'engine') { // run directly from the probe for this device, no engine needed
        if (!t.script || !t.dataset) throw bad('This sensor type is created by its integration and cannot be added by hand.');
        const item = String((body.params || {}).item || '').trim().slice(0, 120);
        if (item && !/^[\w .:$\\/-]+$/.test(item)) throw bad('Item may only hold letters, digits, spaces and . : $ \\ / -');
        const twin = cfg.sensors.find((x) => x.device === dev.id && x.type === t.id && x.direct && String((x.params || {}).item || '') === item);
        if (twin) { if (body.quiet) return sensorView(twin); throw bad((dev.label || dev.name) + ' already has ' + t.name + (item ? ' for ' + item : '') + ' run by the probe. Change its settings instead of adding it again.', 409); }
        const iv = body.interval ? +body.interval : S.directInterval(t.id);
        if (!(iv >= 30)) throw bad('Interval must be at least 30 seconds');
        const s = { id: uid('n:'), device: dev.id, type: t.id, name: String(body.name || t.name).slice(0, 120) + (item && !body.name ? ' ' + item : ''), interval: Math.min(86400, iv), params: item ? { item } : {}, direct: true, script: t.script };
        cfg.sensors.push(s); save();
        return sensorView(s);
      }
      if (t.source !== 'native') { // an engine sensor: the engine collects it from this device from now on
        if (!t.script) throw bad('This sensor type is created by its integration and cannot be added by hand.');
        const there = derived.sensors.find((x) => x.device === dev.id && x.type === t.id && !cfg.dismissed.includes(x.id));
        if (there && optionAllows(there)) throw bad((dev.label || dev.name) + ' already has ' + t.name + ' from the ' + t.script + ' engine.', 409);
        if (there) { const m = monitorOf(dev.id), add = (S.TYPE_OPTION[t.id] || [])[0]; if (m && add && !m.includes(add)) { const own = cfg.devices.find((d) => d.id === dev.id); if (own) own.monitor = m.concat(add); else cfg.deviceOverrides[dev.id] = Object.assign(cfg.deviceOverrides[dev.id] || {}, { monitor: m.concat(add) }); } }
        if (there) cfg.dismissed = cfg.dismissed.filter((x) => x !== there.id);
        if (cfg.engineSensors.some((r) => r.device === dev.id && r.type === t.id)) throw bad((dev.label || dev.name) + ' already has ' + t.name + '; it is waiting for the ' + t.script + ' engine.', 409);
        const m = monitorOf(dev.id), opt = (S.TYPE_OPTION[t.id] || [])[0];
        if (m && opt && !m.includes(opt)) { const own = cfg.devices.find((d) => d.id === dev.id); if (own) own.monitor = m.concat(opt); else cfg.deviceOverrides[dev.id] = Object.assign(cfg.deviceOverrides[dev.id] || {}, { monitor: m.concat(opt) }); }
        const r = { id: 'e:' + uid('').replace(/^:/, ''), device: dev.id, type: t.id, name: String(body.name || t.name).slice(0, 120), by: body.by || null, at: new Date(now()).toISOString() };
        if (!there) cfg.engineSensors.push(r);
        save();
        const v = (there ? [there] : pendingSensors()).find((x) => x.device === dev.id && x.type === t.id);
        return Object.assign(sensorView(v), { engine: t.script });
      }
      const params = Object.assign({}, body.params || {});
      for (const d of t.params || []) if (d.fromDevice && !params[d.name] && dev.host) params[d.name] = dev.host;
      const s = { id: uid('n:'), device: dev.id, type: t.id, name: String(body.name || t.name).slice(0, 120), interval: body.interval ? +body.interval : t.interval, params: cleanParams(t.id, params) };
      if (s.interval < 30) throw bad('Interval must be at least 30 seconds');
      // one sensor per check: the same type on the same target is refused (templates and discovery skip it quietly)
      const key = S.sensorKey(s.type, s.params);
      const twin = cfg.sensors.find((x) => x.device === dev.id && S.sensorKey(x.type, x.params) === key);
      if (twin) { if (body.quiet) return sensorView(twin); throw bad((dev.label || dev.name) + ' already has this sensor: ' + ((cfg.overrides[twin.id] || {}).name || twin.name) + '. Change its settings instead of adding it again.', 409); }
      cfg.sensors.push(s);
      if (body.limits && typeof body.limits === 'object') { const lim = {}; for (const [n, l] of Object.entries(body.limits).slice(0, 8)) { lim[String(n).slice(0, 80)] = {}; for (const k of ['warnHigh', 'errHigh', 'warnLow', 'errLow']) if (l && l[k] != null && !Number.isNaN(+l[k])) lim[String(n).slice(0, 80)][k] = +l[k]; } cfg.overrides[s.id] = Object.assign(cfg.overrides[s.id] || {}, { limits: lim }); }
      save();
      return sensorView(s);
    }
    function deleteSensor(id, quiet) {
      const i = cfg.sensors.findIndex((x) => x.id === id);
      const pr = cfg.engineSensors.findIndex((x) => x.id === id);
      if (pr >= 0) cfg.engineSensors.splice(pr, 1);
      else if (i >= 0) cfg.sensors.splice(i, 1);
      else if (derived.sensors.find((x) => x.id === id)) { const ds = derived.sensors.find((x) => x.id === id); if (!cfg.dismissed.includes(id)) cfg.dismissed.push(id); cfg.engineSensors = cfg.engineSensors.filter((r) => !(r.device === ds.device && r.type === ds.type)); }
      else throw bad('No such sensor', 404);
      delete cfg.overrides[id]; state.delete(id); hist.delete(id);
      if (!quiet) save();
    }
    function addDevice(body) {
      const name = String(body.name || '').trim();
      if (!name || name.length > 120) throw bad('Give the device a name');
      const host = String(body.host || '').trim();
      // tenants and phones are read through an API (Microsoft Graph), so they have no address of their own
      if (!(host === '' && ['tenant', 'mobile', 'clouddb'].includes(String(body.kind))) && !/^[\w.:-]{1,253}$/.test(host)) throw bad('Host must be a DNS name or an IP address');
      const id = S.devId(name);
      if (allDevices().has(id)) throw bad('A device called ' + name + ' already exists');
      const d = { id, name, host, kind: String(body.kind || 'server'), group: String(body.group || 'g:srv'), tags: [], auto: false, origin: ['discovery', 'import'].includes(body.origin) ? body.origin : 'manual', added: new Date(now()).toISOString(), ports: (body.ports || []).map(Number).filter((p) => p > 0 && p < 65536).slice(0, 40), credentials: cleanCreds(body.credentials) };
      if (body.profile && S.PROFILE[body.profile]) d.profile = body.profile;
      // access level: what MonCastle may do on the device (monitor only, read for inventory, admin for actions and remote control)
      d.accessLevel = S.ACCESS_LEVELS.some((a) => a.id === body.accessLevel) ? body.accessLevel : 'read';
      if (body.server) { if (o.servers && !o.servers().some((x) => x.id === String(body.server))) throw bad('No such MonCastle server'); d.server = String(body.server); }
      if (Array.isArray(body.also)) { const all = groups(); d.also = [...new Set(body.also.map(String))].filter((g) => g !== d.group && all.some((x) => x.id === g)).slice(0, 20); }
      cfg.devices.push(d);
      if (Array.isArray(body.monitor)) { d.monitor = body.monitor.filter((x) => S.OPTIONS.some((o) => o.id === x)); syncOptionSensors(d, d.monitor, extraOf(d, body)); }
      else if (body.template !== false) addTemplate(id, d.kind, host, body.ports || []);
      if (cfg.profiles.length) applyProfiles(id);
      save();
      // collect its inventory now, as the engines do for the devices they find (the host runs it in the background)
      let inventoryJobs = [];
      if (o.onDeviceAdded) { try { inventoryJobs = o.onDeviceAdded(Object.assign({}, d)) || []; } catch (e) { inventoryJobs = []; } }
      return Object.assign({}, d, { inventoryJobs });
    }
    function setDevice(id, body) {
      const dev = allDevices().get(id);
      if (!dev) throw bad('No such device', 404);
      const dov = (cfg.deviceOverrides[id] = cfg.deviceOverrides[id] || {});
      const own = cfg.devices.find((d) => d.id === id);
      if (body.group) { if (!groups().find((g) => g.id === body.group)) throw bad('No such group'); dov.group = body.group; if (own) own.group = body.group; }
      if (body.name) dov.name = String(body.name).slice(0, 120);
      // extra groups: the device also counts in these groups (dashboards, notifications, jobs, engines, access)
      if (Array.isArray(body.also)) {
        const all = groups(), prim = body.group || dov.group || (own && own.group) || dev.group || 'g:srv';
        const also = [...new Set(body.also.map(String))].filter((g) => g !== prim).slice(0, 20);
        for (const g of also) if (!all.find((x) => x.id === g)) throw bad('No such group ' + g);
        if (own) own.also = also; else dov.also = also;
      }
      if (body.server) {
        const sv = String(body.server);
        if (o.servers && !o.servers().some((x) => x.id === sv)) throw bad('No such MonCastle server');
        if (own) own.server = sv; else dov.server = sv;
        if (sv !== LOCAL) for (const x of cfg.sensors.filter((y) => y.device === id)) { const st = state.get(x.id); if (st) { st.state = 'Unknown'; st.message = 'Moved to another MonCastle server; waiting for its first reading'; } }
      }
      if (body.credentials) { if (own) own.credentials = cleanCreds(body.credentials); else dov.credentials = cleanCreds(body.credentials); }
      if (Array.isArray(body.monitor)) {
        const ids = body.monitor.filter((x) => S.OPTIONS.some((o) => o.id === x));
        if (own) { if (body.profile !== undefined && (body.profile || null) !== (own.profile || null)) { own.profile = S.PROFILE[body.profile] ? body.profile : undefined; cfg.sensors = cfg.sensors.filter((x) => !(x.device === own.id && x.option === 'vendor')); } own.monitor = ids; syncOptionSensors(own, ids, extraOf(own, body)); } else dov.monitor = ids;
      }
      if (body.accessLevel !== undefined && own) { if (!S.ACCESS_LEVELS.some((a) => a.id === body.accessLevel)) throw bad('Choose an access level'); own.accessLevel = body.accessLevel; }
      // audit: the audit collector (aud.events) also reads this device's event logs on its schedule
      if (body.audit !== undefined) { if (own) own.audit = !!body.audit; else dov.audit = !!body.audit; }
      if (body.host && own) { if (!/^[\w.:-]{1,253}$/.test(body.host)) throw bad('Host must be a DNS name or an IP address'); own.host = body.host; }
      if ((body.group || Array.isArray(body.also)) && cfg.profiles.length) applyProfiles(id);
      if (body.action === 'pause') { dov.paused = true; dov.pausedBy = body.by; dov.pausedUntil = body.minutes ? new Date(now() + body.minutes * 60e3).toISOString() : null; for (const s of allSensors().filter((x) => x.device === id)) setPaused(s); }
      if (body.action === 'resume') { delete dov.paused; delete dov.pausedUntil; for (const s of allSensors().filter((x) => x.device === id)) { const st = state.get(s.id); if (st) { st.state = 'Unknown'; st.scanNow = true; } } refreshDerived(true); }
      if (body.action === 'scan') for (const s of allSensors().filter((x) => x.device === id)) { const st = state.get(s.id); if (st) st.scanNow = true; }
      save();
      return id;
    }
    // removes a device and every sensor on it. A device found by an engine stays hidden (Removed devices) so the
    // next engine run does not bring it back; restoreDevice shows it again.
    function deleteDevice(id, by, quiet) {
      const own = cfg.devices.findIndex((d) => d.id === id);
      const found = derived.devices.get(id);
      if (own < 0 && (!found || isRemoved(id))) throw bad('No such device', 404);
      const dev = own >= 0 ? cfg.devices[own] : found;
      const name = (cfg.deviceOverrides[id] || {}).name || dev.label || dev.name;
      for (const s of allSensors().filter((x) => x.device === id)) { delete cfg.overrides[s.id]; state.delete(s.id); hist.delete(s.id); }
      if (own >= 0) cfg.devices.splice(own, 1);
      cfg.sensors = cfg.sensors.filter((s) => s.device !== id);
      cfg.dismissed = cfg.dismissed.filter((sid) => !derived.sensors.some((x) => x.id === sid && x.device === id));
      delete cfg.deviceOverrides[id];
      if (found && !isRemoved(id)) cfg.removedDevices.push({ id, name, kind: found.kind, at: new Date(now()).toISOString(), by: by || null });
      if (!quiet) save();
      return name;
    }
    function restoreDevice(id) {
      const i = cfg.removedDevices.findIndex((r) => r.id === id);
      if (i < 0) throw bad('That device is not in the removed list', 404);
      cfg.removedDevices.splice(i, 1);
      refreshDerived(true); save();
      return id;
    }
    // several devices and sensors in one go (Devices & sensors > Select). Sensors on removed devices go with them.
    function removeItems(body, by) {
      const devices = [...new Set((body.devices || []).map(String))].slice(0, 2000);
      const gone = new Set(devices);
      const sensors = [...new Set((body.sensors || []).map(String))].filter((sid) => { const s = allSensors().find((x) => x.id === sid); return s && !gone.has(s.device); }).slice(0, 5000);
      const out = { devices: [], sensors: 0 };
      for (const id of devices) out.devices.push(deleteDevice(id, by, true));
      for (const sid of sensors) { deleteSensor(sid, true); out.sensors++; }
      save();
      return out;
    }
    function addGroup(body) {
      const name = String(body.name || '').trim();
      if (!name) throw bad('Give the group a name');
      const g = { id: uid('g:'), name: name.slice(0, 80), parent: body.parent && groups().find((x) => x.id === body.parent) ? body.parent : 'probe' };
      cfg.groups.push(g); save(); return g;
    }
    // rename a group, give it a description or move it under another group (built-in groups can be renamed too)
    function setGroup(id, body) {
      const all = groups();
      const g = all.find((x) => x.id === id);
      if (!g) throw bad('No such group', 404);
      const next = {};
      if (body.name !== undefined) { const n = String(body.name || '').trim(); if (!n) throw bad('Give the group a name'); next.name = n.slice(0, 80); }
      if (body.description !== undefined) next.description = String(body.description || '').slice(0, 300);
      if (body.parent !== undefined) {
        const p = String(body.parent || 'probe');
        if (p !== 'probe' && !all.find((x) => x.id === p)) throw bad('No such parent group');
        if (p === id || groupChain(p).includes(id)) throw bad('A group cannot sit inside itself or one of its subgroups');
        next.parent = p;
      }
      let own = cfg.groups.find((x) => x.id === id);
      if (!own) { own = { id, name: g.name, parent: g.parent, builtIn: true }; cfg.groups.push(own); }
      Object.assign(own, next); save();
      return Object.assign({}, own);
    }
    // deletes a group. Its devices and subgroups move to `moveTo` (default: the parent group, or Servers at the top).
    function deleteGroup(id, body) {
      body = body || {};
      const i = cfg.groups.findIndex((g) => g.id === id);
      if (i < 0 || cfg.groups[i].builtIn || S.GROUPS.some(([gid]) => gid === id)) throw bad('Built-in groups cannot be deleted; rename them instead');
      const g = cfg.groups[i];
      const all = groups();
      const target = body.moveTo ? String(body.moveTo) : g.parent && g.parent !== 'probe' ? g.parent : 'g:srv';
      if (target === id || !all.find((x) => x.id === target) || groupChain(target).includes(id)) throw bad('Choose another group for its devices');
      const held = tree().devices.filter((d) => d.group === id);
      if (held.length && !body.moveTo && body.move !== true) throw bad('The group still holds ' + held.length + ' device(s). Choose where they go.', 409);
      for (const d of held) { (cfg.deviceOverrides[d.id] = cfg.deviceOverrides[d.id] || {}).group = target; const own = cfg.devices.find((x) => x.id === d.id); if (own) own.group = target; }
      for (const c of cfg.groups) if (c.parent === id) c.parent = g.parent || 'probe';
      for (const x of cfg.devices.concat(Object.values(cfg.deviceOverrides))) if (Array.isArray(x.also)) x.also = x.also.filter((y) => y !== id);
      cfg.groups.splice(i, 1); refreshDerived(true); save();
      return { moved: held.length, to: target };
    }

    // ---------------------------------------------------------------- monitoring profiles (4.7.4)
    // A profile is a set of monitoring options, sensors and actions for a type of device. It applies to the devices and
    // groups it is assigned to (a group covers its subgroups and the devices that are also members of it), and, with
    // "auto", to every device of its kinds. Sensors a profile adds carry its id, so removing the profile or the
    // assignment removes them again; options it adds are remembered per device for the same reason.
    const PKEY = (x) => x.type + '|' + (x.mode || '') + '|' + S.sensorKey(x.type, x.params || {});
    function cleanProfile(b, old) {
      const name = String(b.name || '').trim();
      if (!name) throw bad('Give the profile a name');
      const kinds = ids(b.kinds, 60).filter((k) => S.CLASSES.some(([c]) => c === k) || k === 'domain');
      const options = ids(b.options, 80).filter((x) => S.OPTIONS.some((op) => op.id === x));
      const sensors = [];
      for (const x of (Array.isArray(b.sensors) ? b.sensors : []).slice(0, 80)) {
        const t = S.TYPE[x && x.type]; if (!t) throw bad('Unknown sensor type ' + (x && x.type));
        if (t.passive) throw bad(t.name + ' receives alerts from another system and cannot be part of a profile.');
        const mode = t.source === 'native' ? '' : x.mode === 'probe' && t.script && t.dataset ? 'probe' : 'engine';
        if (t.source !== 'native' && !t.script) throw bad(t.name + ' is created by its integration and cannot be part of a profile.');
        const params = t.source === 'native' ? cleanParams(t.id, Object.assign({}, x.params || {})) : (x.params && x.params.item ? { item: String(x.params.item).slice(0, 120) } : {});
        const lim = {};
        if (x.limits && typeof x.limits === 'object') for (const [n, l] of Object.entries(x.limits).slice(0, 8)) { const one = {}; for (const k of ['warnHigh', 'errHigh', 'warnLow', 'errLow']) if (l && l[k] != null && l[k] !== '' && !Number.isNaN(+l[k])) one[k] = +l[k]; if (Object.keys(one).length) lim[String(n).slice(0, 80)] = one; }
        const it = { type: t.id, name: String(x.name || t.name).slice(0, 120), params, mode, interval: x.interval && +x.interval >= 30 ? Math.min(86400, +x.interval) : null, limits: lim };
        if (!sensors.some((y) => PKEY(y) === PKEY(it))) sensors.push(it);
      }
      const actions = [];
      for (const a of (Array.isArray(b.actions) ? b.actions : []).slice(0, 30)) { const sid = String((a || {}).script || ''); if (!/^[\w.-]{1,80}$/.test(sid)) continue; actions.push({ script: sid, label: String(a.label || '').slice(0, 80) || null, params: a.params && typeof a.params === 'object' ? Object.fromEntries(Object.entries(a.params).slice(0, 20).map(([k, v]) => [String(k).slice(0, 60), typeof v === 'object' ? JSON.stringify(v).slice(0, 300) : String(v).slice(0, 300)])) : {} }); }
      const all = groups(), devs = allDevices();
      const pg = ids(b.groups, 200).filter((g) => all.some((x) => x.id === g));
      const pd = ids(b.devices, 2000).filter((d) => devs.has(d));
      return Object.assign({}, old || {}, { id: (old && old.id) || uid('mp:'), name: name.slice(0, 80), description: String(b.description || '').slice(0, 400), kinds, options, sensors, actions, groups: pg, devices: pd, auto: !!b.auto, updated: new Date(now()).toISOString(), updatedBy: b.by || null }, old ? {} : { created: new Date(now()).toISOString(), createdBy: b.by || null });
    }
    // the profiles that cover a device, in the order they were created
    function profilesOf(devId, d) {
      d = d || allDevices().get(devId); if (!d) return [];
      const gl = deviceGroupsOf(devId, d);
      const chain = new Set([].concat(...gl.map((g) => [g].concat(groupChain(g)))));
      return cfg.profiles.filter((p) => (!p.kinds.length || p.kinds.includes(d.kind)) && (p.devices.includes(devId) || p.groups.some((g) => chain.has(g)) || (p.auto && p.kinds.includes(d.kind))));
    }
    function applyProfiles(only) {
      const devs = allDevices();
      const out = { added: 0, removed: 0, devices: 0 };
      const idsTo = only ? [].concat(only).filter((x) => devs.has(x)) : [...devs.keys()];
      for (const id of idsTo) {
        const d = devs.get(id); if (isRemoved(id) || d.kind === 'external') continue;
        const cover = profilesOf(id, d);
        const want = new Map(); for (const p of cover) for (const x of p.sensors) if (!want.has(PKEY(x))) want.set(PKEY(x), { p, x });
        let touched = false;
        // remove what a profile added that no profile covering the device wants any more
        for (const x of cfg.sensors.filter((y) => y.device === id && y.profile)) if (!want.has(x.pkey)) { cfg.sensors.splice(cfg.sensors.indexOf(x), 1); state.delete(x.id); hist.delete(x.id); delete cfg.overrides[x.id]; out.removed++; touched = true; }
        for (const r of cfg.engineSensors.filter((y) => y.device === id && y.profile)) if (!want.has(r.pkey)) { cfg.engineSensors.splice(cfg.engineSensors.indexOf(r), 1); for (const ds of derived.sensors.filter((y) => y.device === id && y.type === r.type)) if (!cfg.dismissed.includes(ds.id)) cfg.dismissed.push(ds.id); out.removed++; touched = true; }
        // options: add the profiles' options, take back the ones a profile added before and no profile wants now
        const own = cfg.devices.find((x) => x.id === id), dov = (cfg.deviceOverrides[id] = cfg.deviceOverrides[id] || {});
        const holder = own || dov;
        const wantOpts = [...new Set([].concat(...cover.map((p) => p.options)))].filter((x) => S.optionsFor(d.kind).some((op) => op.id === x));
        const had = Array.isArray(holder.profileOptions) ? holder.profileOptions : [];
        const cur = monitorOf(id);
        if (wantOpts.length || had.length) {
          let next = (cur || (wantOpts.length ? S.optionsFor(d.kind).filter((op) => S.optionDefault(op, d.kind, d.ports || [])).map((op) => op.id) : [])).filter((x) => !(had.includes(x) && !wantOpts.includes(x)));
          const added = wantOpts.filter((x) => !next.includes(x));
          next = next.concat(added);
          holder.profileOptions = [...new Set(had.filter((x) => wantOpts.includes(x)).concat(added))];
          if (!holder.profileOptions.length) delete holder.profileOptions;
          if (!cur || next.join() !== cur.join()) { holder.monitor = next; if (own) syncOptionSensors(own, next, extraOf(own, {})); touched = true; }
        }
        // add what is missing
        for (const [k, { p, x }] of want) {
          const t = S.TYPE[x.type]; if (!t) continue;
          if (t.source === 'native' || x.mode === 'probe') {
            if (cfg.sensors.some((y) => y.device === id && y.pkey === k)) continue;
            const before = cfg.sensors.length; // a sensor the device already had stays the user's: it is not tagged
            let v; try { v = addSensor({ device: id, type: x.type, params: x.params, name: x.name, limits: x.limits, interval: x.interval || undefined, mode: x.mode === 'probe' ? undefined : 'engine', quiet: true }); } catch (e) { continue; }
            const n = cfg.sensors.length > before ? cfg.sensors.find((y) => y.id === v.id) : null;
            if (n) { n.profile = p.id; n.pkey = k; out.added++; touched = true; }
          } else {
            if (cfg.engineSensors.some((r) => r.device === id && r.type === x.type)) continue;
            if (derived.sensors.some((y) => y.device === id && y.type === x.type && !cfg.dismissed.includes(y.id) && optionAllows(y))) continue;
            try { addSensor({ device: id, type: x.type, name: x.name, mode: 'engine', by: 'profile ' + p.name }); } catch (e) { continue; }
            const r = cfg.engineSensors.find((y) => y.device === id && y.type === x.type); if (r) { r.profile = p.id; r.pkey = k; out.added++; touched = true; }
          }
        }
        if (touched) out.devices++;
        if (!Object.keys(dov).length) delete cfg.deviceOverrides[id];
      }
      save();
      return out;
    }
    function profileView(p) {
      const devs = [...allDevices().keys()].filter((id) => !isRemoved(id) && profilesOf(id).some((x) => x.id === p.id));
      const sens = cfg.sensors.filter((x) => x.profile === p.id).length + cfg.engineSensors.filter((x) => x.profile === p.id).length;
      return Object.assign(clone(p), { covers: devs.length, coveredDevices: devs.slice(0, 500), sensorsAdded: sens });
    }
    function setProfile(b) {
      const i = b.id ? cfg.profiles.findIndex((x) => x.id === b.id) : -1;
      if (b.id && i < 0) throw bad('No such profile', 404);
      const p = cleanProfile(b, i >= 0 ? cfg.profiles[i] : null);
      if (cfg.profiles.some((x) => x.id !== p.id && x.name.toLowerCase() === p.name.toLowerCase())) throw bad('A profile called ' + p.name + ' already exists', 409);
      if (i >= 0) cfg.profiles[i] = p; else cfg.profiles.push(p);
      const r = applyProfiles();
      return Object.assign(profileView(p), { applied: r });
    }
    function deleteProfile(id) {
      const i = cfg.profiles.findIndex((x) => x.id === id);
      if (i < 0) throw bad('No such profile', 404);
      cfg.profiles.splice(i, 1);
      return applyProfiles();
    }
    // assign or unassign one profile on a device or a group (device page, group page)
    function assignProfile(id, b) {
      const p = cfg.profiles.find((x) => x.id === id); if (!p) throw bad('No such profile', 404);
      const on = b.on !== false;
      if (b.device) { const d = String(b.device); if (!allDevices().has(d)) throw bad('No such device', 404); p.devices = on ? [...new Set(p.devices.concat(d))] : p.devices.filter((x) => x !== d); }
      if (b.group) { const g = String(b.group); if (!groups().some((x) => x.id === g)) throw bad('No such group', 404); p.groups = on ? [...new Set(p.groups.concat(g))] : p.groups.filter((x) => x !== g); }
      return Object.assign(profileView(p), { applied: applyProfiles() });
    }

    // ---------------------------------------------------------------- notifications
    const EMAIL_LIST = /^\s*[^\s@<>;,]+@[^\s@<>;,]+(\s*[;,]\s*[^\s@<>;,]+@[^\s@<>;,]+)*\s*$/;
    const ids = (a, n) => [...new Set((Array.isArray(a) ? a : a ? [a] : []).map(String))].slice(0, n || 500);
    const scopeOf = (r) => ({ groups: ids(r.groups || r.group), devices: ids(r.devices || r.device), sensors: ids(r.sensors || r.sensor), types: ids(r.types, 100) });
    function cleanTarget(t) {
      if (t.kind === 'email' && EMAIL_LIST.test(t.to || '')) return { kind: 'email', to: String(t.to).trim().slice(0, 300) };
      if (t.kind === 'webhook' && /^https?:\/\//.test(t.url || '')) return { kind: 'webhook', url: String(t.url).slice(0, 500), format: t.format === 'teams' ? 'teams' : t.format === 'slack' ? 'slack' : 'json' };
      if (t.kind === 'user' && t.name) return { kind: 'user', name: String(t.name).slice(0, 40) };
      if (t.kind === 'usergroup' && t.id) return { kind: 'usergroup', id: String(t.id).slice(0, 40) };
      return null;
    }
    function setNotifications(body) {
      const n = cfg.notifications;
      if (body.smtp) n.smtp = { host: String(body.smtp.host || '').trim(), port: +body.smtp.port || 587, security: ['auto', 'tls', 'starttls', 'none'].includes(body.smtp.security) ? body.smtp.security : body.smtp.secure ? (+body.smtp.port === 465 ? 'tls' : 'auto') : 'auto', user: String(body.smtp.user || '').trim(), from: String(body.smtp.from || '').trim() };
      if (body.templates) n.templates = body.templates.slice(0, 50).map((t) => { const c = o.mail ? o.mail.clean(t) : t; c.id = c.id || uid('tpl:'); return c; });
      if (body.defaultTemplate !== undefined) n.defaultTemplate = body.defaultTemplate && (n.templates || []).some((t) => t.id === body.defaultTemplate) ? body.defaultTemplate : null;
      if (body.rules) {
        n.rules = body.rules.map((r) => Object.assign({
          id: r.id || uid('r:'), name: String(r.name || 'Rule').slice(0, 80), enabled: r.enabled !== false,
          on: (r.on || []).filter((x) => ['Down', 'Warning', 'Up', 'Unknown'].includes(x)), delayMin: Math.max(0, Math.min(1440, +r.delayMin || 0)),
          template: r.template && r.template !== 'default' ? String(r.template) : r.template === 'default' ? 'default' : null,
          targets: (r.targets || []).map(cleanTarget).filter(Boolean).slice(0, 50),
        }, scopeOf(r)));
      }
      // templates that were deleted fall back to the default
      const tids = (n.templates || []).map((t) => t.id);
      for (const r of n.rules) if (r.template && r.template !== 'default' && !tids.includes(r.template)) r.template = null;
      if (n.defaultTemplate && !tids.includes(n.defaultTemplate)) n.defaultTemplate = null;
      save();
      return clone(n);
    }
    // which template a rule sends with: its own, else the console default, else the RoboMate default (null)
    function templateFor(rule) {
      const n = cfg.notifications, id = rule && rule.template === 'default' ? null : (rule && rule.template) || n.defaultTemplate;
      return (n.templates || []).find((t) => t.id === id) || null;
    }

    // ---------------------------------------------------------------- egress and incident integrations
    // the record holds only non-secret fields; secrets stay on the server (host.setOutboundSecret)
    function setOutbound(b) {
      cfg.outbound = cfg.outbound || [];
      const O = o.outboundDefs;
      const def = O && O.TARGET[b.kind];
      if (!def) throw Object.assign(new Error('Unknown integration type.'), { status: 400 });
      const old = b.id ? cfg.outbound.find((x) => x.id === b.id) : null;
      const fields = {};
      for (const f of def.fields) if (!f.secret) { const v = String((b.fields || {})[f.id] == null ? '' : b.fields[f.id]).trim().slice(0, 500); if (f.required && !v) throw Object.assign(new Error(f.label + ' is required.'), { status: 400 }); if (f.type === 'url' && v && !/^https:\/\//.test(v) && !(f.allowHttp && /^http:\/\//.test(v))) throw Object.assign(new Error(f.label + ' must start with https://'), { status: 400 }); fields[f.id] = v; }
      const rec = Object.assign({
        id: old ? old.id : uid('out:'), kind: b.kind, direction: def.direction, name: String(b.name || def.name).slice(0, 80), enabled: b.enabled !== false,
        on: (b.on || def.on).filter((x) => ['Down', 'Warning', 'Up', 'Unknown'].includes(x)), delayMin: Math.max(0, Math.min(1440, +b.delayMin || 0)), fields,
        secretSet: old ? !!old.secretSet : false, created: old ? old.created : new Date().toISOString(),
      }, scopeOf(b));
      if (def.direction === 'incident' && !rec.on.includes('Up')) rec.on.push('Up'); // incidents are resolved on recovery
      if (old) Object.assign(old, rec); else cfg.outbound.push(rec);
      save();
      return clone(rec);
    }
    function outboundMark(id, patch) { const x = (cfg.outbound || []).find((y) => y.id === id); if (x) { Object.assign(x, patch); save(); } }
    function removeOutbound(id) { const n = (cfg.outbound || []).length; cfg.outbound = (cfg.outbound || []).filter((x) => x.id !== id); if (n === cfg.outbound.length) throw Object.assign(new Error('No such integration.'), { status: 404 }); save(); return { ok: true }; }

    // ---------------------------------------------------------------- discovery
    function candidates() {
      const ds = o.datasets() || {};
      const have = allDevices();
      const hosts = new Set([...have.values()].map((d) => String(d.host || '').toLowerCase()).filter(Boolean));
      const out = [];
      // after "Clear results" only engine data collected later counts again
      const fresh = (k) => { const d = ds[k] || {}; return !cfg.discoveryCleared || (d.finished && Date.parse(d.finished) > Date.parse(cfg.discoveryCleared)); };
      const rows = (k) => (fresh(k) ? (ds[k] || {}).data || [] : []);
      const push = (c) => { if (have.has(S.devId(c.name)) && (have.get(S.devId(c.name)).sensors || []).length !== 0 && cfg.devices.find((d) => d.id === S.devId(c.name))) return; if (out.find((x) => x.name === c.name)) return; out.push(c); };
      // what other engines know about a host (by name or address): its OS from AD, inventories, Intune or the Linux engine
      const osIdx = new Map();
      const keep = (k, v) => { if (k && v && !osIdx.has(String(k).toLowerCase())) osIdx.set(String(k).toLowerCase(), v); };
      for (const c of (ds['ad.computers'] || {}).data || []) { keep(c.Name, c.OperatingSystem); keep(c.DNSHostName, c.OperatingSystem); keep(c.IPv4Address, c.OperatingSystem); }
      for (const w of (ds['inventory.workstations'] || {}).data || []) { keep(w.Name, w.OperatingSystem || 'Windows 11'); for (const ip of [].concat(w.IPAddress || [])) keep(ip, w.OperatingSystem || 'Windows 11'); }
      for (const l of (ds['linux.hosts'] || {}).data || []) { keep(l.Name, l.os || 'Linux'); for (const ip of [].concat(l.ipAddresses || [])) keep(ip, l.os || 'Linux'); }
      for (const r of (ds['intune.devices'] || {}).data || []) keep(r.Name, r.OS);
      const osOf = (name, ip) => osIdx.get(String(name || '').toLowerCase()) || osIdx.get(String(name || '').split('.')[0].toLowerCase()) || osIdx.get(String(ip || '').toLowerCase()) || null;
      // the network discovery engine: classified from its ports, name, TTL and what the other engines know (4.7.4)
      for (const d of rows('network.discovery')) {
        const name = d.HostName ? d.HostName.split('.')[0].toUpperCase() : d.IPAddress;
        const c = S.classifyHost({ ports: d.OpenPorts || [], name: d.HostName || '', ttl: d.Ttl, os: osOf(d.HostName, d.IPAddress), sysDescr: d.SysDescr || null, sysOid: d.SysObjectID || null, http: d.HttpServer || null, cert: d.CertSubject || null });
        push({ name, host: d.IPAddress, kind: c.kind, profile: c.profile || null, group: c.group, confidence: c.confidence, why: c.reason, source: 'Network scan', detail: (S.CLASSES.find((x) => x[0] === c.kind) || [, c.kind])[1] + (d.OpenPorts && d.OpenPorts.length ? ' · ports ' + d.OpenPorts.join(', ') : '') + (d.MAC ? ' · ' + d.MAC : ''), ports: d.OpenPorts || [], monitored: hosts.has(String(d.IPAddress).toLowerCase()) && !!cfg.devices.find((x) => x.host === d.IPAddress) });
      }
      for (const p of rows('inventory.printers')) if (p.IPAddress) push({ name: p.Name, host: p.IPAddress, kind: 'printer', group: 'g:printers', source: 'Print server ' + p.PrintServer, detail: p.Model || p.Driver, ports: [9100, 161], monitored: !!cfg.devices.find((x) => x.host === p.IPAddress) });
      for (const c of rows('ad.computers')) {
        if (!c.Enabled || c.Stale) continue;
        const server = c.Role === 'Server' || /Server/.test(c.OperatingSystem || '');
        const dc = /domain controller/i.test(c.Role || '') || /Domain Controllers/i.test(c.OU || '') || c.IsDC === true;
        const lnx = /linux|ubuntu|red hat|centos|debian|suse|rocky|alma/i.test(c.OperatingSystem || '');
        push({ name: c.Name, host: c.DNSHostName || c.IPv4Address, kind: lnx ? 'linux' : server ? 'server' : 'workstation', group: lnx ? 'g:lnx' : dc ? 'g:dc' : server ? 'g:srv' : 'g:ws', confidence: 'high', why: 'Active Directory: ' + (c.OperatingSystem || (server ? 'server' : 'computer')) + (dc ? ', domain controller' : ''), source: 'Active Directory', detail: (c.OperatingSystem || '') + (c.OU ? ' · ' + c.OU : ''), ports: [], monitored: !!cfg.devices.find((x) => x.id === S.devId(c.Name)) || ((have.get(S.devId(c.Name)) || {}).auto === true) });
      }
      // the other engines that see machines: virtualization, workstation and Linux inventory, SNMP and database engines
      const known = (name, host) => { const h = String(host || '').toLowerCase(); return !!cfg.devices.find((x) => x.id === S.devId(name) || (h && String(x.host || '').toLowerCase() === h)) || ((have.get(S.devId(name)) || {}).auto === true); };
      const first = (v) => (Array.isArray(v) ? v.find((x) => /^\d+\.\d+\.\d+\.\d+$/.test(x)) || v[0] : v) || null;
      const osKind = (os) => (/linux|ubuntu|red hat|rhel|centos|debian|suse|rocky|alma/i.test(os || '') ? 'linux' : /windows/i.test(os || '') ? 'server' : 'vm');
      const grp = (k) => S.KIND_GROUP[k] || (k === 'linux' ? 'g:lnx' : k === 'server' ? 'g:srv' : 'g:srv');
      const add = (c) => push(Object.assign({ ports: [], group: grp(c.kind) }, c, { monitored: known(c.name, c.host) }));
      for (const w of rows('inventory.workstations')) { const ip = first(w.IPAddress); if (ip) add({ name: w.Name, host: ip, kind: 'workstation', group: 'g:ws', source: 'Workstation inventory', detail: [w.OperatingSystem, w.Model, w.ADSite].filter(Boolean).join(' · ') }); }
      const vmSrc = { 'virtualization.hyperv': 'Hyper-V', 'virtualization.vmware': 'VMware vCenter', 'virtualization.nutanix': 'Nutanix Prism', 'virtualization.openshift': 'OpenShift' };
      for (const [k, label] of Object.entries(vmSrc)) for (const v of rows(k)) {
        if (v.Kind === 'VM') { const ip = first(v.IPAddresses || v.IPAddress); if (!ip && !v.DnsName) continue; const nm = String(v.Name).split('.')[0].toUpperCase(); add({ name: nm, host: v.DnsName || ip, kind: osKind(v.GuestOS || ''), source: label, detail: 'Virtual machine on ' + (v.Host || v.Cluster || '') + (v.GuestOS ? ' · ' + v.GuestOS : '') }); }
        else if (/^(ESXi|AHV|Host|Node)$/.test(v.Kind) && /\./.test(v.Name || '')) add({ name: String(v.Name).split('.')[0].toUpperCase(), host: v.Name, kind: 'host', group: k === 'virtualization.vmware' ? 'g:vmw' : k === 'virtualization.nutanix' ? 'g:ntx' : 'g:hv', source: label, detail: (v.Kind || 'Host') + (v.Model ? ' · ' + v.Model : '') + (v.Cluster ? ' · ' + v.Cluster : '') });
      }
      for (const n of rows('containers.kubernetes')) if (n.Kind === 'Node' && n.Address) add({ name: String(n.Name).split('.')[0].toUpperCase(), host: n.Address, kind: 'k8snode', group: 'g:k8s', source: 'Kubernetes', detail: 'Node of ' + n.Cluster + (n.Roles ? ' · ' + n.Roles : '') + (n.OS ? ' · ' + n.OS : '') });
      for (const l of rows('linux.hosts')) { const ip = first(l.ipAddresses); if (ip) add({ name: String(l.Name).toUpperCase(), host: ip, kind: 'linux', group: 'g:lnx', source: 'Linux engine', detail: [l.os, l.machineType].filter(Boolean).join(' · '), ports: [22] }); }
      for (const [k, kind] of [['network.devices', 'network'], ['storage.devices', 'nas']]) for (const r of rows(k)) if (r.SysName) add({ name: String(r.SysName).toUpperCase(), host: r.Name, kind: /san|powerstore|netapp|pure/i.test(r.Description || '') ? 'san' : k === 'network.devices' ? ({ Firewall: 'firewall', 'Wireless controller': 'wireless', 'Access point': 'wireless', 'Load balancer': 'loadbalancer', WAF: 'waf', 'VPN gateway': 'vpn' }[r.Class] || kind) : kind, ...(r.Class === 'Firewall' ? { group: 'g:fw' } : {}), source: 'SNMP network and storage', detail: (r.Class && r.Class !== 'Other' ? r.Class + (r.Vendor ? ' · ' + r.Vendor : '') + ' · ' : '') + String(r.Description || '').slice(0, 80), ports: [161] });
      for (const r of rows('databases.health')) if (r.Address) add({ name: String(r.Host).toUpperCase(), host: r.Address, kind: /linux/i.test(r.Version || '') ? 'linux' : 'server', group: 'g:sql', source: 'Database engines', detail: r.Engine + ' ' + (r.Instance || '') + ' · port ' + r.Port, ports: [r.Port].filter(Boolean) });
      for (const r of rows('cloud.databases')) if (r.Service && r.Service !== 'Account') add({ name: String(r.Name).replace('/', ' / '), host: null, kind: 'clouddb', group: 'g:db', source: 'Cloud databases', detail: r.Provider + ' ' + r.Service + ' · ' + (r.Engine || '') + (r.Region ? ' · ' + r.Region : ''), noProbe: true });
      for (const r of rows('network.cloud')) if (r.Address && ['Firewall', 'WAF', 'VPN gateway'].includes(r.Type)) add({ name: String(r.Name).toUpperCase(), host: r.Address, kind: r.Type === 'WAF' ? 'waf' : r.Type === 'VPN gateway' ? 'vpn' : 'cloudfw', group: 'g:cloudnet', source: 'Cloud network', detail: r.Provider + ' ' + r.Type + (r.Region ? ' · ' + r.Region : '') });
      // Entra ID and Intune: computers by name (they resolve in DNS when hybrid joined or on the VPN); phones and tablets are
      // monitored through their Intune readings, so they are offered without probe checks
      const seenCloud = new Set();
      for (const r of rows('intune.devices')) {
        const mob = /iOS|iPadOS|Android/i.test(r.OS || ''), n = String(r.Name || '').toUpperCase(); if (!n) continue; seenCloud.add(n);
        add({ name: mob ? r.Name : n, host: mob ? null : r.Name, kind: mob ? 'mobile' : /server/i.test(r.OSVersion || '') ? 'server' : /linux/i.test(r.OS || '') ? 'linux' : 'workstation', group: mob ? 'g:entra' : 'g:ws', source: 'Intune', detail: [r.OS, r.OSVersion, r.User, r.Compliance].filter(Boolean).join(' · '), noProbe: mob });
      }
      for (const r of rows('entra.devices')) {
        const n = String(r.Name || '').toUpperCase();
        if (!n || seenCloud.has(n) || !r.Enabled || r.Stale || !/Windows|macOS|Linux/i.test(r.OS || '') || r.Join === 'Registered') continue;
        add({ name: n, host: r.Name, kind: /20\d\d\d|Server/i.test(r.OSVersion || '') && /^10\.0\.(14393|17763|20348|26100)/.test(r.OSVersion || '') && !r.Managed ? 'server' : 'workstation', source: 'Entra ID', detail: [r.Join, r.OS, r.OSVersion, r.Compliant === false ? 'not compliant' : null].filter(Boolean).join(' · ') });
      }
      for (const r of rows('entra.health')) if (r.Kind === 'Tenant' && r.TenantName) add({ name: 'Entra ID ' + r.TenantName, host: null, kind: 'tenant', group: 'g:entra', source: 'Entra ID', detail: 'Tenant ' + r.Tenant + ' · ' + r.Message, noProbe: true });
      return out.concat(lastScan);
    }
    let lastScan = [];
    function setScanResults(list) { lastScan = list || []; }
    // Auto-discovery > Clear results: empties the list so a new scan starts clean; engines add theirs again on their next run
    function clearDiscovery() { lastScan = []; cfg.discoveryCleared = new Date(now()).toISOString(); save(); return cfg.discoveryCleared; }
    function applyDiscovery(items) {
      const added = [];
      for (const it of items || []) {
        const name = String(it.name || it.host || '').trim();
        if (!name) continue;
        let id = S.devId(name);
        // the same machine under another name (an address from the scan, the FQDN from AD): add to that device
        const hostKey = (h) => String(h || '').toLowerCase().replace(/\.$/, '');
        const short = (h) => (/^\d+\.\d+\.\d+\.\d+$/.test(hostKey(h)) ? hostKey(h) : hostKey(h).split('.')[0]);
        if (!allDevices().has(id) && it.host) { const twin = [...allDevices().values()].find((d) => !isRemoved(d.id) && d.host && (hostKey(d.host) === hostKey(it.host) || short(d.host) === short(it.host) || short(d.name) === short(it.host))); if (twin) id = twin.id; }
        if (cfg.devices.find((d) => d.id === id)) continue;
        if (it.group === 'g:ws' && !cfg.groups.find((g) => g.id === 'g:ws')) cfg.groups.push({ id: 'g:ws', name: 'Workstations', parent: 'probe' });
        const existing = derived.devices.get(id);
        if (existing && isRemoved(id)) cfg.removedDevices = cfg.removedDevices.filter((r) => r.id !== id);
        if (existing) {
          // a collector device: add the probe's own sensors to it
          addTemplate(id, it.kind || existing.kind, it.host || existing.host, it.ports);
          added.push(name);
          continue;
        }
        // a recognised model gets the default monitoring options, which include its vendor health sensors
        const prof = it.profile && S.PROFILE[it.profile] ? it.profile : null;
        addDevice({ origin: 'discovery', name, host: it.host, kind: it.kind, group: it.group, ports: it.ports, profile: prof, monitor: prof ? S.optionsFor(it.kind).filter((o) => S.optionDefault(o, it.kind, it.ports)).map((o) => o.id) : undefined });
        for (const x of cfg.sensors) if (x.device === id) x.tpl = true;
        added.push(name);
      }
      save();
      return added;
    }

    // Bulk import from the Name, Type, IP template (plus optional Group, Model, Server). Every row is checked first;
    // with dryRun nothing is saved and the result says what each row would do. can(groupId) decides permission.
    function importDevices(rows, opts) {
      opts = opts || {};
      const can = opts.can || (() => true);
      const gs = groups();
      const known = allDevices();
      const hosts = new Map([...known.values()].filter((d) => d.host).map((d) => [String(d.host).toLowerCase(), d.name]));
      const names = new Set([...known.keys()]);
      const out = [];
      for (const [i, r] of (rows || []).slice(0, 2000).entries()) {
        const name = String(r.name || '').trim(), host = String(r.host || r.ip || '').trim(), typeText = String(r.type || '').trim();
        const row = { row: i + 1, name, host, type: typeText };
        const k = S.kindFor(typeText);
        const prof = r.model ? S.PROFILES.find((p) => p.id === String(r.model).trim().toLowerCase() || p.name.toLowerCase() === String(r.model).trim().toLowerCase()) : null;
        let group = null;
        // "Servers;Finance" puts the device in Servers and also in Finance
        const gparts = String(r.group || '').split(/[;|]/).map((x) => x.trim()).filter(Boolean);
        const findG = (t) => { const g = t.toLowerCase(); return gs.find((x) => x.id.toLowerCase() === g || x.name.toLowerCase() === g); };
        if (gparts.length) group = findG(gparts[0]);
        const alsoG = gparts.slice(1).map(findG);
        if (!name) row.error = 'Name is empty';
        else if (name.length > 120) row.error = 'Name is longer than 120 characters';
        else if (!host) row.error = 'IP or DNS name is empty';
        else if (!/^[\w.:-]{1,253}$/.test(host)) row.error = 'IP must be an IP address or a DNS name';
        else if (!k) row.error = 'Unknown type "' + typeText + '"';
        else if (r.model && !prof) row.error = 'Unknown model "' + r.model + '"';
        else if (prof && prof.kind !== k.kind) row.error = 'Model ' + prof.name + ' is not a ' + typeText;
        else if (gparts.length && !group) row.error = 'No group called "' + gparts[0] + '"';
        else if (alsoG.some((x) => !x)) row.error = 'No group called "' + gparts.slice(1)[alsoG.findIndex((x) => !x)] + '"';
        else if (names.has(S.devId(name))) row.skip = 'A device called ' + name + ' already exists';
        else if (hosts.has(host.toLowerCase())) row.skip = host + ' is already monitored as ' + hosts.get(host.toLowerCase());
        if (!row.error && !row.skip) {
          row.kind = k.kind; row.profile = (prof && prof.id) || k.profile || null;
          row.group = group ? group.id : S.KIND_GROUP[k.kind] || 'g:srv';
          row.also = alsoG.map((x) => x.id).filter((x) => x !== row.group);
          if (!can(row.group)) row.error = 'You cannot add devices to ' + ((gs.find((g) => g.id === row.group) || {}).name || row.group);
          else if (row.also.some((g) => !can(g))) row.error = 'You cannot add devices to ' + ((gs.find((g) => g.id === row.also.find((x) => !can(x))) || {}).name || '');
        }
        if (!row.error && !row.skip) { names.add(S.devId(name)); hosts.set(host.toLowerCase(), name); }
        row.result = row.error ? 'error' : row.skip ? 'skip' : opts.dryRun ? 'ready' : 'added';
        out.push(row);
      }
      if (!opts.dryRun) {
        for (const row of out.filter((x) => x.result === 'added')) {
          if (!gs.find((g) => g.id === row.group) && !cfg.groups.find((g) => g.id === row.group)) cfg.groups.push({ id: row.group, name: row.group === 'g:ws' ? 'Workstations' : row.group.slice(2), parent: 'probe' });
          try {
            addDevice({ origin: 'import', accessLevel: ((v) => (/^mon/.test(v) ? 'monitor' : /^adm/.test(v) ? 'admin' : 'read'))(String((rows[row.row - 1] || {}).access || '').toLowerCase()), name: row.name, host: row.host, kind: row.kind, group: row.group, also: row.also, profile: row.profile, server: (rows[row.row - 1] || {}).server || undefined, monitor: S.optionsFor(row.kind).filter((o) => S.optionDefault(o, row.kind, [])).map((o) => o.id) });
          } catch (e) { row.result = 'error'; row.error = e.message; }
        }
        save();
      }
      const n = (x) => out.filter((r) => r.result === x).length;
      return { rows: out, ready: n('ready'), added: n('added'), skipped: n('skip'), errors: n('error') };
    }

    // ---------------------------------------------------------------- alerts from other monitoring systems
    // Each integration has a token; only its hash is kept (o.hashToken on the server). An alert becomes an
    // "External alert" sensor on the matching device (by name or address), or on a device made for that host.
    const AS = o.alertSources;
    const hashToken = o.hashToken || ((t) => 'demo:' + String(t).split('').reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7).toString(16));
    const newToken = o.newToken || (() => 'mci_' + Array.from({ length: 32 }, () => 'abcdefghijkmnpqrstuvwxyz23456789'[Math.floor(Math.random() * 32)]).join(''));
    const shortKey = (k) => String(k).split('').reduce((a, c) => (a * 33 + c.charCodeAt(0)) >>> 0, 5381).toString(36);
    const intView = (x) => {
      const mine = cfg.sensors.filter((s) => s.type === 'ext.alert' && (s.params || {}).integration === x.id);
      const open = mine.filter((s) => { const st = state.get(s.id); return st && (st.state === 'Down' || st.state === 'Warning'); }).length;
      return { id: x.id, name: x.name, source: x.source, sourceName: (AS && AS.SOURCE[x.source] || {}).name || x.source, group: x.group, enabled: x.enabled !== false, created: x.created, createdBy: x.createdBy, lastAt: x.lastAt || null, received: x.received || 0, lastError: x.lastError || null, alerts: mine.length, open };
    };
    function integrations() { return cfg.integrations.map(intView); }
    function addIntegration(body, by) {
      if (!AS || !AS.SOURCE[body.source]) throw bad('Pick the monitoring system that will send the alerts');
      const name = String(body.name || AS.SOURCE[body.source].name).trim().slice(0, 80);
      const group = body.group && groups().find((g) => g.id === body.group) ? body.group : 'g:ext';
      const token = newToken();
      const x = { id: uid('i:'), name, source: body.source, group, tokenHash: hashToken(token), enabled: true, created: new Date(now()).toISOString(), createdBy: by || null, received: 0 };
      cfg.integrations.push(x); save();
      return Object.assign(intView(x), { token }); // the only time the token is shown
    }
    function setIntegration(id, body) {
      const x = cfg.integrations.find((i) => i.id === id);
      if (!x) throw bad('No such integration', 404);
      if (body.name) x.name = String(body.name).slice(0, 80);
      if (body.enabled != null) x.enabled = !!body.enabled;
      if (body.group && groups().find((g) => g.id === body.group)) x.group = body.group;
      let token;
      if (body.rotate) { token = newToken(); x.tokenHash = hashToken(token); }
      save();
      return Object.assign(intView(x), token ? { token } : {});
    }
    function deleteIntegration(id) {
      const i = cfg.integrations.findIndex((x) => x.id === id);
      if (i < 0) throw bad('No such integration', 404);
      cfg.integrations.splice(i, 1);
      for (const s of cfg.sensors.filter((y) => y.type === 'ext.alert' && (y.params || {}).integration === id)) { state.delete(s.id); hist.delete(s.id); }
      cfg.sensors = cfg.sensors.filter((y) => !(y.type === 'ext.alert' && (y.params || {}).integration === id));
      save();
    }
    // the server checks the token (constant time) before calling this; the demo's test button calls it directly
    const integrationById = (id) => cfg.integrations.find((x) => x.id === id) || null;
    function receiveAlerts(id, body) {
      const x = integrationById(id);
      if (!x) throw bad('No such integration', 404);
      if (x.enabled === false) throw bad('This integration is turned off', 409);
      const r = AS.normalize(x.source, body);
      x.lastAt = new Date(now()).toISOString(); x.received = (x.received || 0) + r.alerts.length; x.lastError = r.error || null;
      const devs = [...allDevices().values()];
      const find = (h) => {
        const k = String(h || '').toLowerCase(); if (!k) return null;
        const sh = k.split('.')[0];
        return devs.find((d) => String(d.host || '').toLowerCase() === k || String(d.name || '').toLowerCase() === k)
          || devs.find((d) => String(d.name || '').toLowerCase() === sh || String(d.host || '').toLowerCase().split('.')[0] === sh) || null;
      };
      const out = [];
      for (const a of r.alerts) {
        let dev = find(a.host);
        if (!dev) {
          const name = a.host || x.name;
          const did = S.devId(name);
          dev = cfg.devices.find((d) => d.id === did);
          if (!dev) {
            dev = { id: did, name, host: /^[\w.:-]{1,253}$/.test(a.host) ? a.host : '', kind: 'external', group: x.group || 'g:ext', tags: ['external'], auto: false, ports: [], credentials: {}, source: x.id };
            cfg.devices.push(dev); devs.push(dev);
          }
        }
        const sid = 'x:' + x.id.slice(2) + ':' + shortKey(a.key);
        let s = cfg.sensors.find((y) => y.id === sid);
        if (!s) {
          if (a.state === 'Up') { out.push({ host: a.host, name: a.name, state: 'Up', device: dev.id, note: 'resolved, nothing open' }); continue; }
          s = { id: sid, device: dev.id, type: 'ext.alert', name: (x.name + ': ' + a.name).slice(0, 160), params: { integration: x.id, key: String(a.key).slice(0, 300) }, url: a.url || undefined };
          cfg.sensors.push(s);
        }
        record(Object.assign({ source: 'native' }, s), { channels: [], forced: a.state === 'Up' ? null : a.state, message: (a.state === 'Up' ? 'Resolved in ' + x.name + (a.message ? ': ' + a.message : '') : a.message || a.name) }, now());
        out.push({ host: a.host, name: a.name, state: a.state, device: dev.id, sensor: s.id });
      }
      // resolved external alerts are kept for 7 days, then removed
      const old = now() - 7 * 864e5;
      cfg.sensors = cfg.sensors.filter((y) => { if (y.type !== 'ext.alert') return true; const st = state.get(y.id); const keep = !st || st.state !== 'Up' || (st.since || 0) > old; if (!keep) { state.delete(y.id); hist.delete(y.id); } return keep; });
      save();
      return { received: r.alerts.length, error: r.error || null, alerts: out };
    }
    function testIntegration(id) {
      const x = integrationById(id);
      if (!x) throw bad('No such integration', 404);
      return receiveAlerts(id, AS.SOURCE[x.source].sample);
    }

    // ---------------------------------------------------------------- persistence of history and log
    function exportHistory(onlyDirty) {
      const out = {};
      for (const [id, h] of hist) { if (onlyDirty && !h.dirty) continue; out[id] = { names: h.names, live: h.live, five: h.five, hour: h.hour }; h.dirty = false; }
      return out;
    }
    function importHistory(obj) { for (const [id, h] of Object.entries(obj || {})) hist.set(id, Object.assign({ live: [], five: [], hour: [] }, h, { dirty: false })); }
    function importState(obj) { for (const [id, st] of Object.entries(obj || {})) state.set(id, st); }
    function exportState() { return Object.fromEntries(state); }
    function importLog(list) { log = (list || []).slice(0, LOG_MAX); }

    function deviceGroupOf(id) { const d = allDevices().get(id); if (!d) return null; const dov = cfg.deviceOverrides[id] || {}; return dov.group || d.group || 'g:srv'; }
    function sensorDeviceOf(id) { const s = allSensors().find((x) => x.id === id); return s ? s.device : null; }
    return {
      chain: (gid) => [gid].concat(groupChain(gid)), deviceGroupOf, deviceGroupsOf: (id) => deviceGroupsOf(id), sensorDeviceOf, targets, credentialsOf, monitorOf, serverOf, serverLoad, applyReading, loadAssigned,
      device: (id) => { const d = allDevices().get(id); return d && Object.assign({}, d, { group: deviceGroupOf(id), groups: deviceGroupsOf(id, d), credentials: credentialsOf(id) }); },
      deviceByName: (n) => { const id = S.devId(String(n || '').split('.')[0]); const d = allDevices().get(id) || allDevices().get(S.devId(n)); return d && Object.assign({}, d, { group: deviceGroupOf(d.id), groups: deviceGroupsOf(d.id, d), credentials: credentialsOf(d.id) }); },
      devices: () => [...allDevices().values()].map((d) => Object.assign({}, d, { group: deviceGroupOf(d.id), groups: deviceGroupsOf(d.id, d), credentials: credentialsOf(d.id) })),
      config: () => cfg, tree, detail, channels, refreshDerived, runDue, due, scan, record,
      sensorAction, setSensorSettings, addSensor, deleteSensor, addDevice, importDevices, integrations, addIntegration, setIntegration, deleteIntegration, integrationById, receiveAlerts, testIntegration, setDevice, deleteDevice, restoreDevice, removeItems, addGroup, setGroup, deleteGroup, clearDiscovery, discoveryCleared: () => cfg.discoveryCleared || null, groups,
      notifications: () => clone(cfg.notifications), setNotifications, templateFor, resolveTargets, inScope,
      outbound: () => clone(cfg.outbound || []), setOutbound, removeOutbound, outboundMark,
      candidates, applyDiscovery, setScanResults,
      profiles: () => cfg.profiles.map(profileView), setProfile, deleteProfile, assignProfile, applyProfiles, profilesOf: (id) => profilesOf(id).map((p) => p.id),
      log: (limit) => log.slice(0, limit || 500),
      exportHistory, importHistory, exportState, importState, importLog, applyRetention, keepHours,
      types: () => S.TYPES.map((t) => ({ id: t.id, name: t.name, category: t.category, source: t.source, passive: !!t.passive, interval: t.interval || null, desc: t.desc, script: t.script || null, dataset: t.dataset || null, params: t.params || [], channels: (t.channels || []).map((c) => ({ name: c.name, unit: c.unit, limits: c.limits })) })),
    };
  }

  // One entry point for the API (server route GET/POST /api/monitor and the browser demo), so both check access the same way.
  //   user.access(deviceGroup) -> 'none'|'reader'|'contributor'|'admin' (public/js/rbac.js; falls back to the console role)
  //   readers look; contributors pause, scan, acknowledge and change devices and sensors in their device groups;
  //   administrators manage groups, notifications and discovery.
  // host = { notifications(), setNotifications(b), test(target), scan(range, by), scanStatus(), credentialOk(id, user)? } for the parts that differ.
  const READ = ['tree', 'sensor', 'channels', 'types', 'log', 'groups', 'notifications', 'discovery', 'outbound', 'profiles'];
  const RANK = { none: 0, reader: 1, viewer: 1, contributor: 2, operator: 2, admin: 3 };
  function handle(core, host, op, b, user) {
    b = b || {};
    const fail = (m, status) => { throw Object.assign(new Error(m), { status: status || 403 }); };
    if (!user) fail('Sign in first.', 401);
    const role = user.role === 'viewer' ? 'reader' : user.role === 'operator' ? 'contributor' : user.role;
    const acc = (gid) => (user.access ? user.access(gid) : user.restricted && role !== 'admin' ? 'none' : role);
    const can = (gid, need) => RANK[acc(gid) || 'none'] >= RANK[need];
    // a device in several groups gets the best role the user has on any of them
    const accDev = (gl) => (gl || []).map((g) => acc(g) || 'none').sort((a, b) => RANK[b] - RANK[a])[0] || 'none';
    const canDev = (gl, need) => RANK[accDev(gl)] >= RANK[need];
    const onDevice = (devId, need) => { const g = core.deviceGroupOf(devId); if (!g) fail('No such device', 404); const gl = core.deviceGroupsOf ? core.deviceGroupsOf(devId) : [g]; if (!canDev(gl, need)) fail(need === 'reader' ? 'You have no access to this device.' : 'Your role on this device group (' + accDev(gl) + ') cannot do this; it needs ' + need + '.'); return g; };
    const onSensor = (sid, need) => { const d = core.sensorDeviceOf(sid); if (!d) fail('No such sensor', 404); return onDevice(d, need); };
    const admin = () => { if (role !== 'admin') fail('Only administrators can change this.'); };
    const unrestricted = () => { if (user.restricted && role !== 'admin') fail('Your account only sees the device groups it was given.'); };
    const by = user.name;
    // saved credentials picked for a device must be ones this user may use (host.credentialOk; the demo allows all)
    const credsOk = (c) => { for (const id of Object.values(c || {})) if (id && host.credentialOk && !host.credentialOk(String(id), user)) fail('You cannot use the saved credential ' + id + ' on devices.'); };
    switch (op) {
      case 'tree': {
        const t = core.tree();
        if (role === 'admin' && !user.access) return t;
        const vis = new Set(t.devices.filter((d) => canDev(d.groups || [d.group], 'reader')).map((d) => d.id));
        const devices = t.devices.filter((d) => vis.has(d.id)).map((d) => Object.assign(d, { access: accDev(d.groups || [d.group]) }));
        const sensors = t.sensors.filter((s) => vis.has(s.device));
        const counts = sensors.reduce((a, s) => { a[s.state] = (a[s.state] || 0) + 1; if (s.ack && s.state === 'Down') a.Acknowledged = (a.Acknowledged || 0) + 1; return a; }, {});
        const groups = t.groups.filter((g) => devices.some((d) => (d.groups || [d.group]).includes(g.id)) || (!user.restricted && can(g.id, 'reader'))).map((g) => Object.assign(g, { access: acc(g.id) }));
        const open = sensors.filter((x) => !x.related && !x.ack);
        const alarms = { Down: open.filter((x) => x.state === 'Down').length, Warning: open.filter((x) => x.state === 'Warning').length, related: sensors.filter((x) => x.related).length };
        return Object.assign(t, { devices, sensors, groups, removed: role === 'admin' ? t.removed : [], probe: Object.assign(t.probe, { counts, alarms, state: counts.Down ? 'Down' : counts.Warning ? 'Warning' : counts.Up ? 'Up' : 'Unknown' }) });
      }
      case 'sensor': { onSensor(String(b.id), 'reader'); const d = core.detail(String(b.id)); if (!d) fail('No such sensor', 404); d.access = accDev(core.deviceGroupsOf ? core.deviceGroupsOf(d.device) : [core.deviceGroupOf(d.device)]); return d; }
      case 'channels': { if (b.device) onDevice(String(b.device), 'reader'); return core.channels({ device: b.device ? String(b.device) : null, type: b.type ? String(b.type) : null, ids: b.ids ? String(b.ids) : null }).filter((x) => canDev(core.deviceGroupsOf ? core.deviceGroupsOf(x.device) : [core.deviceGroupOf(x.device)], 'reader')).slice(0, 500); }
      case 'types': return core.types();
      case 'log': return core.log(Math.min(3000, +b.limit || 500)).filter((e) => { const g = core.deviceGroupOf(e.device); return !g || canDev(core.deviceGroupsOf ? core.deviceGroupsOf(e.device) : [g], 'reader'); });
      case 'groups': return core.groups().filter((g) => can(g.id, 'reader'));
      case 'notifications': unrestricted(); return host.notifications();
      case 'discovery': unrestricted(); return { candidates: core.candidates(), scan: host.scanStatus(), local: host.localNetworks ? host.localNetworks() : [], cleared: core.discoveryCleared() };
      case 'clearDiscovery': admin(); if (host.clearScan) host.clearScan(); return { cleared: core.clearDiscovery() };
      case 'sensorAction': onSensor(String(b.id), 'contributor'); return core.sensorAction(String(b.id), String(b.action), by, { minutes: +b.minutes || 0, note: b.note });
      case 'deviceAction': { onDevice(String(b.id), 'contributor'); if (!['pause', 'resume', 'scan'].includes(b.action)) fail('Unknown action', 400); core.setDevice(String(b.id), { action: b.action, by, minutes: +b.minutes || 0 }); return handle(core, host, 'tree', {}, user); }
      case 'sensorSettings': onSensor(String(b.id), 'contributor'); return core.setSensorSettings(String(b.id), b);
      case 'addSensor': onDevice(String(b.device), 'contributor'); return core.addSensor(Object.assign({}, b, { quiet: false, by }));
      case 'deleteSensor': onSensor(String(b.id), 'contributor'); core.deleteSensor(String(b.id)); return { ok: true };
      case 'addDevice': if (!can(String(b.group || 'g:srv'), 'contributor')) fail('You cannot add devices to this group.'); credsOk(b.credentials); return core.addDevice(Object.assign({}, b, { origin: 'manual' }));
      case 'setDevice': onDevice(String(b.id), 'contributor'); credsOk(b.credentials); if (b.group && !can(String(b.group), 'contributor')) fail('You cannot move devices into that group.'); if (Array.isArray(b.also)) { const had = core.deviceGroupsOf ? core.deviceGroupsOf(String(b.id)) : []; for (const g of b.also) if (!had.includes(String(g)) && !can(String(g), 'contributor')) fail('You cannot add devices to the group ' + g + '.'); } core.setDevice(String(b.id), { group: b.group, also: b.also, name: b.name, host: b.host, monitor: b.monitor, credentials: b.credentials, interfaces: b.interfaces, volumes: b.volumes, profile: b.profile, server: b.server, audit: b.audit, accessLevel: b.accessLevel }); return handle(core, host, 'tree', {}, user);
      case 'deleteDevice': onDevice(String(b.id), 'contributor'); core.deleteDevice(String(b.id), by); return { ok: true };
      case 'removeItems': {
        for (const id of b.devices || []) onDevice(String(id), 'contributor');
        for (const id of b.sensors || []) onSensor(String(id), 'contributor');
        return core.removeItems(b, by);
      }
      case 'restoreDevice': { const r = (core.tree().removed || []).find((x) => x.id === String(b.id)); if (!r) fail('That device is not in the removed list', 404); if (role !== 'admin') fail('Only administrators can bring back removed devices.'); core.restoreDevice(String(b.id)); return { ok: true }; }
      case 'importDevices': {
        const rows = Array.isArray(b.rows) ? b.rows : [];
        return core.importDevices(rows, { dryRun: !!b.dryRun, can: (g) => can(g, 'contributor') });
      }
      case 'integrations': admin(); return core.integrations();
      case 'addIntegration': admin(); return core.addIntegration(b, by);
      case 'setIntegration': admin(); return core.setIntegration(String(b.id), b);
      case 'deleteIntegration': admin(); core.deleteIntegration(String(b.id)); return { ok: true };
      case 'testIntegration': admin(); return core.testIntegration(String(b.id));
      case 'profiles': return core.profiles();
      case 'setProfile': admin(); return core.setProfile(Object.assign({}, b, { by }));
      case 'deleteProfile': admin(); return Object.assign({ ok: true }, core.deleteProfile(String(b.id)));
      case 'assignProfile': { if (b.device) onDevice(String(b.device), 'contributor'); else if (b.group) { if (!can(String(b.group), 'contributor')) fail('Your role on this group cannot assign profiles.'); } else fail('Choose a device or a group', 400); return core.assignProfile(String(b.id), b); }
      case 'applyProfiles': admin(); return core.applyProfiles();
      case 'addGroup': admin(); return core.addGroup(b);
      case 'setGroup': admin(); return core.setGroup(String(b.id), b);
      case 'deleteGroup': admin(); return Object.assign({ ok: true }, core.deleteGroup(String(b.id), b));
      case 'setNotifications': admin(); return host.setNotifications(b);
      case 'testNotification': admin(); return host.test(b.target || {}, b);
      case 'outbound': admin(); return { list: core.outbound(), sent: host.outboundLog ? host.outboundLog() : [] };
      case 'setOutbound': admin(); return host.setOutbound ? host.setOutbound(b) : core.setOutbound(b);
      case 'removeOutbound': admin(); if (host.removeOutboundSecret) host.removeOutboundSecret(String(b.id)); return core.removeOutbound(String(b.id));
      case 'testOutbound': admin(); return host.testOutbound(String(b.id));
      case 'scan': admin(); return host.scan(b.range, by);
      case 'applyDiscovery': admin(); return { added: core.applyDiscovery((b.items || []).slice(0, 500)) };
      default: fail('Unknown monitoring operation ' + op, 400);
    }
  }
  const AUDIT = { sensorAction: 1, deviceAction: 1, sensorSettings: 1, addSensor: 1, deleteSensor: 1, addDevice: 1, importDevices: 1, addIntegration: 1, setIntegration: 1, deleteIntegration: 1, testIntegration: 1, setDevice: 1, deleteDevice: 1, removeItems: 1, restoreDevice: 1, addGroup: 1, setGroup: 1, deleteGroup: 1, setNotifications: 1, testNotification: 1, setOutbound: 1, removeOutbound: 1, testOutbound: 1, scan: 1, applyDiscovery: 1, clearDiscovery: 1, setProfile: 1, deleteProfile: 1, assignProfile: 1, applyProfiles: 1 };
  function auditText(op, b) {
    b = b || {};
    switch (op) {
      case 'sensorAction': return b.action + ' sensor ' + b.id + (b.minutes ? ' for ' + b.minutes + ' min' : '');
      case 'deviceAction': return b.action + ' device ' + b.id;
      case 'sensorSettings': return 'Changed sensor ' + b.id + (b.limits ? ' limits' : '') + (b.interval ? ' interval ' + b.interval + ' s' : '');
      case 'addSensor': return 'Added ' + b.type + ' sensor to ' + b.device;
      case 'deleteSensor': return 'Deleted sensor ' + b.id;
      case 'addDevice': return 'Added device ' + b.name + ' (' + b.host + ')';
      case 'importDevices': return (b.dryRun ? 'Checked ' : 'Imported ') + (b.rows || []).length + ' device rows';
      case 'addIntegration': return 'Added alert integration ' + (b.name || b.source);
      case 'setIntegration': return 'Changed alert integration ' + b.id + (b.rotate ? ' (new token)' : '');
      case 'deleteIntegration': return 'Deleted alert integration ' + b.id;
      case 'testIntegration': return 'Sent a test alert through integration ' + b.id;
      case 'setDevice': return 'Changed device ' + b.id;
      case 'deleteDevice': return 'Removed device ' + b.id + ' and its sensors';
      case 'removeItems': return 'Removed ' + (b.devices || []).length + ' devices (' + (b.devices || []).slice(0, 20).join(', ') + ') and ' + (b.sensors || []).length + ' sensors';
      case 'restoreDevice': return 'Brought back removed device ' + b.id;
      case 'addGroup': return 'Added group ' + b.name;
      case 'setGroup': return 'Changed group ' + b.id + (b.name ? ' (name ' + b.name + ')' : '') + (b.parent ? ' (parent ' + b.parent + ')' : '');
      case 'deleteGroup': return 'Deleted group ' + b.id + (b.moveTo ? ', devices moved to ' + b.moveTo : '');
      case 'setNotifications': return 'Changed notification settings';
      case 'testNotification': return 'Test notification to ' + ((b.target || {}).kind || '');
      case 'setOutbound': return (b.id ? 'Changed' : 'Added') + ' ' + (b.kind || '') + ' integration ' + (b.name || '') + (b.secrets && Object.values(b.secrets).some(Boolean) ? ' (secret replaced)' : '');
      case 'removeOutbound': return 'Removed outgoing integration ' + b.id;
      case 'testOutbound': return 'Test sent to outgoing integration ' + b.id;
      case 'scan': return 'Discovery scan of ' + b.range;
      case 'clearDiscovery': return 'Cleared the auto-discovery results';
      case 'setProfile': return (b.id ? 'Changed' : 'Added') + ' monitoring profile ' + (b.name || b.id);
      case 'deleteProfile': return 'Deleted monitoring profile ' + b.id;
      case 'assignProfile': return (b.on === false ? 'Removed' : 'Assigned') + ' monitoring profile ' + b.id + (b.device ? (b.on === false ? ' from device ' : ' to device ') + b.device : '') + (b.group ? (b.on === false ? ' from group ' : ' to group ') + b.group : '');
      case 'applyProfiles': return 'Applied the monitoring profiles again';
      case 'applyDiscovery': return 'Added ' + (b.items || []).length + ' discovered devices';
      default: return op;
    }
  }

  return { createCore, handle, AUDIT, auditText };
});
