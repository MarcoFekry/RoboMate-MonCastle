/*
 * RoboMate MonCastle - Administrate › Data retention: the retention policy, storage use and growth, the retention run,
 * and the archive browser (sensor history, alarms, access log, engine runs and collector snapshots per month).
 * Archives are encrypted on disk and are opened here, through the console.
 */
(function (root) {
  'use strict';
  const MC = root.MC, C = root.MCCharts;
  const { esc, fmt, pill, ago, dt, $, $$ } = MC;
  const V = MC.views;
  const KIND = {
    'sensors-1h': ['Sensor history (hourly)', 'hourly averages that left the live history'],
    'sensors-5m': ['Sensor history (5-minute)', '5-minute averages, older than two days'],
    alarms: ['Alarms and state changes', 'every Up, Warning and Down change'],
    access: ['Access log', 'sign-ins, views, runs and changes (administrators)'],
    engines: ['Engine runs', 'older engine run history (administrators)'],
    datasets: ['Collector snapshots', 'daily or weekly copies of every collector\'s data (administrators)'],
  };
  const KCOL = { 'sensors-5m': '--s1', 'sensors-1h': '--s2', alarms: '--s3', access: '--s4', engines: '--s1', datasets: '--s2' };
  const size = (b) => (b == null ? '–' : b >= 1099511627776 ? fmt(b / 1099511627776, 2) + ' TB' : b >= 1073741824 ? fmt(b / 1073741824, 1) + ' GB' : b >= 1048576 ? fmt(b / 1048576, 1) + ' MB' : b >= 1024 ? fmt(b / 1024, 0) + ' KB' : b + ' B');
  const monthName = (m) => new Date(m + '-15T00:00:00Z').toLocaleDateString(undefined, { month: 'short', year: 'numeric' });
  const admin = () => MC.user && MC.user.role === 'admin';

  V.retention = {
    title: 'Data retention',
    crumb: () => 'retention policy, storage and archives',
    render(el, route) {
      const tab = route.tab || (admin() ? 'policy' : 'archives');
      el.innerHTML = MC.tabs('retention', (admin() ? [['policy', 'Policy & storage']] : []).concat([['archives', 'Archives']]), tab) + '<div id="rt" class="grid"></div>';
      const t = $('#rt', el);
      if (tab === 'policy' && admin()) policyTab(t); else archivesTab(t, route.q || {});
    },
  };

  async function policyTab(el) {
    el.innerHTML = '<div class="notice">Loading…</div>';
    let r;
    try { r = await MC.api.retention(); } catch (e) { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; return; }
    draw(r);
    function draw(r) {
      const p = r.policy, a = p.archive, u = r.usage, last = r.lastRun;
      const daysLeft = u.free && u.growthPerDay ? Math.floor(u.free / u.growthPerDay) : null;
      el.innerHTML = `<div class="kpis">${MC.kpi('Live data', size(u.liveBytes), 'in the console data folder')}${MC.kpi('Archives', size(u.archiveBytes), (u.months || []).length + ' months kept')}${MC.kpi('Archive growth', size(u.growthPerDay) + '/day', 'last three full months')}${MC.kpi('Free space', size(u.free), daysLeft != null ? (daysLeft > 3650 ? 'more than 10 years at this rate' : 'about ' + fmt(daysLeft, 0) + ' days at this rate') : '', { alert: daysLeft != null && daysLeft < 90 })}${MC.kpi('Last run', last ? ago(last.at) : 'never', last ? fmt(last.sensorRows, 0) + ' history rows archived' : 'runs daily at ' + esc(a.runAt))}</div>
        <div class="grid g2">
          ${MC.panel('Live data', 'what the console keeps in its data folder', C.barList(u.live.map((x, i) => ({ label: x.name, value: x.bytes, text: size(x.bytes), color: C.SERIES[i % C.SERIES.length] }))))}
          ${MC.panel('Archive per month', esc(u.archivePath), '<div id="rtMonths"></div>')}
        </div>
        <section class="card panel-c"><div class="panel-h"><h3>Retention policy</h3><span class="sub">applies to every device and sensor; a sensor can keep its history longer or shorter in its settings</span></div>
          <div class="rtform">
            <fieldset><legend>Live data</legend>
              <div class="field"><label for="rhd">Sensor history (days)</label><input class="input" id="rhd" type="number" min="1" max="3650" value="${p.historyDays}"><span class="hint">Hourly averages shown in sensor charts. Raw values stay 3 hours, 5-minute averages 2 days.</span></div>
              <div class="field"><label for="rld">Alarm and state log (days)</label><input class="input" id="rld" type="number" min="7" max="3650" value="${p.logDays}"></div>
              <div class="field"><label for="rad">Access log (days)</label><input class="input" id="rad" type="number" min="7" max="3650" value="${p.accessLogDays}"><span class="hint">Pushed to the Access repository as well, when that is on.</span></div>
            </fieldset>
            <fieldset><legend>Archive</legend>
              <label class="check"><input type="checkbox" id="rae" ${a.enabled ? 'checked' : ''}> <span>Archive data that leaves the live store (otherwise it is deleted)</span></label>
              <div class="field"><label for="rap">Archive folder</label><input class="input mono" id="rap" value="${esc(a.path || '')}" placeholder="data\\archive (default), D:\\MonCastle-Archive or \\\\nas01\\archive\\MonCastle"><span class="hint">A local folder or a network share the service account can write to.</span></div>
              <div class="field two"><div><label for="rkm">Keep archives (months)</label><input class="input" id="rkm" type="number" min="1" max="240" value="${a.keepMonths}"></div><div><label for="rmg">Size limit (GB, 0 = none)</label><input class="input" id="rmg" type="number" min="0" value="${a.maxGB}"></div></div>
              <div class="field two"><div><label for="rds">Collector snapshots</label><select class="input" id="rds">${[['daily', 'Daily'], ['weekly', 'Weekly'], ['off', 'Off']].map(([k, l]) => `<option value="${k}" ${a.datasets === k ? 'selected' : ''}>${l}</option>`).join('')}</select></div><div><label for="rrt">Run every day at</label><input class="input mono" id="rrt" value="${esc(a.runAt)}" placeholder="02:30"></div></div>
              <label class="check"><input type="checkbox" id="rcz" ${a.compress ? 'checked' : ''}> <span>Compress archives (gzip before encryption, about 10× smaller)</span></label>
            </fieldset>
          </div>
          <p class="muted" style="font-size:12.5px">Archives are encrypted (AES-256-GCM) with this console's data key and can only be opened here. The oldest months are removed first when the archive passes the size limit.</p>
          <div data-err></div>
          <div class="toolbar" style="margin:0"><span class="spacer"></span><button class="btn" id="rRun">Run retention now</button><button class="btn primary" id="rSave">Save policy</button></div>
        </section>
        ${last ? MC.panel('Last retention run', esc(dt ? dt(last.at) : last.at) + ' · by ' + esc(last.by), `<dl class="kv"><dt>Sensor history and alarms archived</dt><dd>${fmt(last.sensorRows, 0)} rows</dd><dt>Access-log entries archived</dt><dd>${fmt(last.accessEntries, 0)}</dd><dt>Collector snapshots</dt><dd>${fmt(last.datasets, 0)}</dd><dt>Old archive months removed</dt><dd>${fmt(last.months, 0)}</dd><dt>Took</dt><dd>${fmt(last.ms, 0)} ms</dd></dl>`) : ''}`;
      const keys = Object.keys(KIND).map((k) => ({ key: k, name: KIND[k][0], color: KCOL[k] }));
      C.columns($('#rtMonths', el), (u.months || []).map((m) => ({ label: m.month.slice(5), title: monthName(m.month) + ' · ' + size(m.bytes), values: Object.fromEntries(m.kinds.map((k) => [k.kind, Math.round(k.bytes / 1048576)])) })), keys, { height: 190, label: 'Archive size per month (MB)', onClick: (b) => MC.go('retention', 'archives', { month: (u.months.find((m) => m.month.slice(5) === b.label) || {}).month }) });
      const body = () => ({ historyDays: +$('#rhd', el).value, logDays: +$('#rld', el).value, accessLogDays: +$('#rad', el).value, archive: { enabled: $('#rae', el).checked, path: $('#rap', el).value.trim(), keepMonths: +$('#rkm', el).value, maxGB: +$('#rmg', el).value, datasets: $('#rds', el).value, runAt: $('#rrt', el).value.trim(), compress: $('#rcz', el).checked } });
      $('#rSave', el).addEventListener('click', async () => { try { const r2 = await MC.api.retentionAction({ action: 'policy', policy: body() }); MC.toast('Retention policy saved', 'ok'); draw(r2); } catch (e) { $('[data-err]', el).innerHTML = `<div class="notice err">${esc(e.message)}</div>`; } });
      $('#rRun', el).addEventListener('click', async (ev) => { ev.target.disabled = true; try { const r2 = await MC.api.retentionAction({ action: 'run' }); MC.toast('Retention run finished: ' + fmt(r2.lastRun.sensorRows, 0) + ' rows archived', 'ok'); draw(r2); } catch (e) { MC.toast(esc(e.message), 'err'); ev.target.disabled = false; } });
    }
  }

  async function archivesTab(el, q) {
    let months = [];
    if (admin()) { try { months = (await MC.api.retention()).usage.months || []; } catch (e) { months = []; } }
    if (!months.length) { const d = new Date(); for (let i = 11; i >= 0; i--) months.push({ month: new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - i, 1)).toISOString().slice(0, 7), kinds: [] }); }
    let tree = null; try { tree = await MC.api.monitor('tree'); } catch (e) { tree = { devices: [], sensors: [] }; }
    const kinds = Object.keys(KIND).filter((k) => admin() || !['access', 'engines', 'datasets'].includes(k));
    const cur = { month: q.month || months[months.length - 1].month, kind: q.kind || 'sensors-1h', device: q.device || '', sensor: q.sensor || '', dataset: q.dataset || '', q: q.q || '' };
    const devs = tree.devices.slice().sort((a, b) => a.name.localeCompare(b.name));
    el.innerHTML = `<section class="card panel-c"><div class="panel-h"><h3>Open an archive</h3><span class="sub">encrypted on disk, decrypted here for you</span></div>
      <div class="arch-filters">
        <div class="field"><label for="am">Month</label><select class="input" id="am">${months.slice().reverse().map((m) => `<option value="${m.month}" ${m.month === cur.month ? 'selected' : ''}>${monthName(m.month)}${m.bytes ? ' · ' + size(m.bytes) : ''}</option>`).join('')}</select></div>
        <div class="field"><label for="ak">Data</label><select class="input" id="ak">${kinds.map((k) => `<option value="${k}" ${k === cur.kind ? 'selected' : ''}>${esc(KIND[k][0])}</option>`).join('')}</select></div>
        <div class="field" data-for="dev"><label for="ad">Device</label><select class="input" id="ad"><option value="">All devices</option>${devs.map((d) => `<option value="${esc(d.id)}" ${d.id === cur.device ? 'selected' : ''}>${esc(d.name)}</option>`).join('')}</select></div>
        <div class="field" data-for="sen"><label for="as">Sensor</label><select class="input" id="as"></select></div>
        <div class="field" data-for="ds"><label for="ads">Collector</label><select class="input" id="ads"><option value="">All collectors (list of snapshots)</option>${Object.keys(MC.ds || {}).sort().map((k) => `<option ${k === cur.dataset ? 'selected' : ''}>${esc(k)}</option>`).join('')}</select></div>
        <div class="field"><label for="aq">Contains</label><input class="input" id="aq" value="${esc(cur.q)}" placeholder="text to find"></div>
        <div class="field"><label>&nbsp;</label><button class="btn primary" id="aGo">Open</button></div>
      </div>
      <p class="muted" id="aHint" style="font-size:12.5px;margin:4px 0 0"></p>
    </section>
    <div id="aOut"></div>`;
    const sensSel = () => {
      const d = $('#ad', el).value;
      const list = tree.sensors.filter((s) => !d || s.device === d).sort((a, b) => (a.deviceName + a.name).localeCompare(b.deviceName + b.name)).slice(0, 400);
      $('#as', el).innerHTML = `<option value="">All sensors</option>` + list.map((s) => `<option value="${esc(s.id)}" ${s.id === cur.sensor ? 'selected' : ''}>${esc((d ? '' : s.deviceName + ' › ') + s.name)}</option>`).join('');
    };
    const vis = () => {
      const k = $('#ak', el).value;
      $('[data-for="dev"]', el).hidden = !(k.startsWith('sensors') || k === 'alarms');
      $('[data-for="sen"]', el).hidden = !k.startsWith('sensors');
      $('[data-for="ds"]', el).hidden = k !== 'datasets';
      $('#aHint', el).textContent = KIND[k][1] + '.';
    };
    $('#ad', el).addEventListener('change', sensSel);
    $('#ak', el).addEventListener('change', vis);
    sensSel(); vis();
    const open = async () => {
      const k = $('#ak', el).value;
      const qq = { month: $('#am', el).value, kind: k, q: $('#aq', el).value.trim(), limit: 5000 };
      if (!$('[data-for="dev"]', el).hidden && $('#ad', el).value) qq.device = $('#ad', el).value;
      if (!$('[data-for="sen"]', el).hidden && $('#as', el).value) qq.sensor = $('#as', el).value;
      if (!$('[data-for="ds"]', el).hidden && $('#ads', el).value) qq.dataset = $('#ads', el).value;
      const out = $('#aOut', el);
      out.innerHTML = '<div class="notice">Decrypting and reading the archive…</div>';
      let r;
      try { r = await MC.api.archive(qq); } catch (e) { out.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; return; }
      const recs = r.records;
      const csv = MC.api.archiveCsvUrl ? `<a class="btn sm" href="${esc(MC.api.archiveCsvUrl(qq))}" download>Export CSV (up to 20 000 rows)</a>` : '';
      if (!recs.length) { out.innerHTML = `<div class="card panel-c empty">Nothing archived for ${esc(KIND[k][0].toLowerCase())} in ${esc(monthName(qq.month))}${qq.q ? ' that contains "' + esc(qq.q) + '"' : ''}.</div>`; return; }
      const cols = colsFor(k, recs, qq);
      out.innerHTML = (k.startsWith('sensors') ? MC.panel('Trend', qq.sensor ? esc(recs[0].deviceName + ' › ' + recs[0].sensorName) : 'up to 6 sensors from this result; pick a sensor for one', '<div id="aChart"></div>') : k === 'alarms' ? MC.panel('Changes per day', '', '<div id="aChart"></div>') : '')
        + MC.panel(KIND[k][0] + ' · ' + monthName(qq.month), fmt(r.total, 0) + ' records' + (r.truncated ? ', first ' + fmt(recs.length, 0) + ' shown' : ''), '<div id="aTbl"></div>', { act: csv });
      if (k.startsWith('sensors')) {
        const by = new Map();
        for (const x of recs) { if (!by.has(x.sensor)) { if (by.size >= 6) continue; by.set(x.sensor, { name: (qq.sensor ? '' : x.deviceName + ' › ') + x.sensorName, ch: Object.keys(x).find((c) => !['t', 'sensor', 'sensorName', 'device', 'deviceName', 'samples'].includes(c)), points: [] }); } const s = by.get(x.sensor); if (s && x[s.ch] != null) s.points.push({ t: Date.parse(x.t), v: x[s.ch] }); }
        C.timeSeries($('#aChart', out), [...by.values()].map((s, i) => ({ name: s.name + (s.ch ? ' · ' + s.ch : ''), points: s.points, color: C.SERIES[i % C.SERIES.length] })), { height: 220 });
      } else if (k === 'alarms') {
        const days = new Map();
        for (const x of recs) { const d = x.t.slice(0, 10); const o = days.get(d) || { Down: 0, Warning: 0, Up: 0 }; o[x.to] = (o[x.to] || 0) + 1; days.set(d, o); }
        C.columns($('#aChart', out), [...days.entries()].sort().map(([d, v]) => ({ label: d.slice(8), title: d, values: v })), [{ key: 'Down', name: 'Down', color: '--crit' }, { key: 'Warning', name: 'Warning', color: '--warn' }, { key: 'Up', name: 'Back up', color: '--ok' }], { height: 170 });
      }
      MC.table($('#aTbl', out), recs, cols, { name: 'moncastle-archive-' + k + '-' + qq.month, limit: 25 });
    };
    $('#aGo', el).addEventListener('click', open);
    if (q.month || q.kind) open();
  }

  function colsFor(k, recs, qq) {
    const when = (key) => ({ key, label: 'Time', html: (r) => esc(dt ? dt(r[key]) : r[key]), val: (r) => r[key] });
    if (k.startsWith('sensors')) {
      const chans = [...new Set(recs.slice(0, 500).flatMap((r) => Object.keys(r)))].filter((c) => !['t', 'sensor', 'sensorName', 'device', 'deviceName', 'samples'].includes(c));
      return [when('t'), { key: 'deviceName', label: 'Device' }, { key: 'sensorName', label: 'Sensor' }].concat(chans.slice(0, 6).map((c) => ({ key: c, label: c, n: true, html: (r) => (r[c] == null ? '<span class="muted">–</span>' : fmt(r[c], 2)) }))).concat([{ key: 'samples', label: 'Samples', n: true }]);
    }
    if (k === 'alarms') return [when('t'), { key: 'deviceName', label: 'Device' }, { key: 'sensorName', label: 'Sensor' }, { key: 'from', label: 'From', html: (r) => pill(r.from === 'Down' ? 'Critical' : r.from === 'Up' ? 'OK' : r.from === 'Warning' ? 'Warning' : 'Unknown', r.from) }, { key: 'to', label: 'To', html: (r) => pill(r.to === 'Down' ? 'Critical' : r.to === 'Up' ? 'OK' : r.to === 'Warning' ? 'Warning' : 'Unknown', r.to) }, { key: 'message', label: 'Message' }];
    if (k === 'access') return [when('time'), { key: 'user', label: 'User' }, { key: 'ip', label: 'IP', cls: 'mono' }, { key: 'event', label: 'Event' }, { key: 'detail', label: 'Detail' }];
    if (k === 'engines') return [when('at'), { key: 'engine', label: 'Engine', cls: 'mono' }, { key: 'status', label: 'Result', html: (r) => pill(r.status === 'ok' ? 'OK' : r.status === 'warning' ? 'Warning' : 'Critical', r.status) }, { key: 'durationSec', label: 'Seconds', n: true }, { key: 'count', label: 'Rows', n: true }, { key: 'message', label: 'Message' }];
    if (k === 'datasets' && !qq.dataset) return [when('at'), { key: 'dataset', label: 'Collector', cls: 'mono' }, { key: 'rows', label: 'Rows', n: true }, { key: 'collected', label: 'Collected', html: (r) => esc(r.collected ? (dt ? dt(r.collected) : r.collected) : '–') }];
    const keys = [...new Set(recs.slice(0, 200).flatMap((r) => Object.keys(r)))].slice(0, 12);
    return keys.map((c) => ({ key: c, label: c, html: (r) => { const v = r[c]; return v == null ? '' : typeof v === 'object' ? esc(JSON.stringify(v)).slice(0, 120) : esc(String(v)); } }));
  }
})(typeof self !== 'undefined' ? self : this);
