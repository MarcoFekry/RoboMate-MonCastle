/*
 * RoboMate MonCastle - Inventory › Compliance: devices checked against common standards (CIS, NIST, ISO 27001, PCI DSS,
 * HIPAA, SOC 2, Essential Eight, GDPR Art. 32), for everything, one group or one device. Evaluation runs in the
 * browser from the data the console already has (public/js/compliance.js); export as CSV or print as a report.
 */
(function (root) {
  'use strict';
  const MC = root.MC, C = root.MCCharts, CMP = root.MCCompliance;
  const { esc, fmt, pill, $, $$ } = MC;
  const V = MC.views;
  const enc = encodeURIComponent;
  const ST = { pass: ['OK', 'Pass'], fail: ['Critical', 'Fail'], partial: ['Warning', 'Partial'], manual: ['Unknown', 'Manual'], na: ['Unknown', 'Not applicable'] };
  const stPill = (s) => pill(ST[s][0], ST[s][1]);
  const scoreCls = (v) => (v == null ? '' : v >= 90 ? 'ok' : v >= 70 ? 'warn' : 'crit');

  async function inputs() {
    const [tree, creds, notes] = await Promise.all([MC.api.monitor('tree'), MC.api.credentials().catch(() => []), MC.api.monitor('notifications').catch(() => null)]);
    const credKinds = Object.fromEntries((creds || []).map((c) => [c.id, c.kind]));
    const snmpDefault = (creds || []).find((c) => c.isDefault && /^snmp/.test(c.kind));
    return { datasets: MC.ds || {}, tree, credKinds, defaultSnmp: snmpDefault ? snmpDefault.kind : null, rules: notes ? (notes.rules || []).filter((r) => r.enabled !== false).length : null };
  }

  V.compliance = {
    title: 'Compliance',
    crumb: () => 'devices checked against common security standards',
    async render(el, route) {
      const q = route.q || {};
      el.innerHTML = '<div class="notice">Checking devices…</div>';
      let inp;
      try { inp = await inputs(); } catch (e) { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; return; }
      const tr = inp.tree;
      const groups = tr.groups.filter((g) => tr.devices.some((d) => MC.inGroup(d, g.id))).sort((a, b) => a.name.localeCompare(b.name));
      const ui = { std: q.std || 'all', scope: q.scope || 'all' };
      const scopeDevs = () => { if (ui.scope === 'all') return null; if (ui.scope.startsWith('g:')) return tr.devices.filter((d) => MC.inGroup(d, ui.scope)).map((d) => d.id); return [ui.scope]; };
      el.innerHTML = `<section class="card panel-c no-print"><div class="cmp-bar">
          <div class="field"><label for="cStd">Standard</label><select class="input" id="cStd"><option value="all">All common standards (${CMP.STANDARDS.length})</option>${CMP.STANDARDS.map((s) => `<option value="${s.id}" ${ui.std === s.id ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select></div>
          <div class="field"><label for="cScope">Devices</label><select class="input" id="cScope"><option value="all">All devices (${tr.devices.length})</option><optgroup label="Group">${groups.map((g) => `<option value="${esc(g.id)}" ${ui.scope === g.id ? 'selected' : ''}>${esc(g.name)} (${tr.devices.filter((d) => MC.inGroup(d, g.id)).length})</option>`).join('')}</optgroup><optgroup label="Device">${tr.devices.slice().sort((a, b) => a.name.localeCompare(b.name)).map((d) => `<option value="${esc(d.id)}" ${ui.scope === d.id ? 'selected' : ''}>${esc(d.name)}</option>`).join('')}</optgroup></select></div>
          <div class="field"><label>&nbsp;</label><div class="toolbar" style="margin:0"><button class="btn" id="cCsv">Export CSV</button><button class="btn" id="cPrint">Print report</button></div></div>
        </div><p class="muted" style="font-size:12.5px;margin:6px 0 0">Automated checks use what MonCastle collects (security, patch, Defender, firewall, AD, SQL, Linux and network data, sensors and credentials). Controls that need documents or interviews are listed as manual. A result is evidence for an audit, not a certification.</p></section>
        <div id="cOut"></div>`;
      const out = $('#cOut', el);
      let last = null;
      const run = () => {
        const opt = { standards: ui.std === 'all' ? null : [ui.std], devices: scopeDevs() };
        last = CMP.evaluate(inp, opt);
        const scopeName = ui.scope === 'all' ? 'all devices' : ui.scope.startsWith('g:') ? 'group ' + ((groups.find((g) => g.id === ui.scope) || {}).name || ui.scope) : ((tr.devices.find((d) => d.id === ui.scope) || {}).name || ui.scope);
        if (ui.std === 'all') overview(out, last, scopeName, (id) => { ui.std = id; $('#cStd', el).value = id; run(); });
        else standard(out, last, scopeName);
        MC.api.audit && MC.api.audit('view', 'Compliance: ' + (ui.std === 'all' ? 'all standards' : ui.std) + ' on ' + scopeName);
      };
      $('#cStd', el).addEventListener('change', (e) => { ui.std = e.target.value; run(); });
      $('#cScope', el).addEventListener('change', (e) => { ui.scope = e.target.value; run(); });
      $('#cPrint', el).addEventListener('click', () => window.print());
      $('#cCsv', el).addEventListener('click', () => {
        const rows = [];
        for (const s of last.standards) for (const c of s.controls) {
          if (c.status === 'manual') { rows.push({ standard: s.short, control: c.ref, title: c.title, device: '', result: 'manual', evidence: c.manual || '' }); continue; }
          for (const d of c.devices) rows.push({ standard: s.short, control: c.ref, title: c.title, device: d.name, result: d.result, evidence: d.checks.filter((x) => x.result !== 'na').map((x) => x.title + ': ' + x.evidence).join(' | ') });
        }
        MC.downloadCsv('moncastle-compliance-' + new Date().toISOString().slice(0, 10), rows);
      });
      run();
    },
  };

  function overview(out, r, scopeName, pick) {
    const all = r.standards.filter((s) => s.score != null);
    const avg = all.length ? all.reduce((a, s) => a + s.score, 0) / all.length : null;
    const worstDevs = r.devices.slice().sort((a, b) => a.score - b.score).slice(0, 10);
    const failing = {};
    for (const d of r.devices) for (const [k, v] of Object.entries(d.results)) if (v.result === 'fail') failing[k] = (failing[k] || 0) + 1;
    out.innerHTML = `<div class="print-only"><h2>MonCastle compliance report</h2><p>${esc(scopeName)} · ${new Date(r.at).toLocaleString()}</p></div>
      <div class="kpis">${MC.kpi('Average score', avg == null ? '–' : fmt(avg, 1) + '%', 'over ' + all.length + ' standards')}${MC.kpi('Devices checked', r.devices.length, esc(scopeName))}${MC.kpi('Fully compliant devices', r.devices.filter((d) => d.failed === 0).length, 'every applicable check passes')}${MC.kpi('Failing checks', Object.values(failing).reduce((a, b) => a + b, 0), Object.keys(failing).length + ' different checks', { alert: Object.keys(failing).length > 0 })}${MC.kpi('Manual controls', r.standards.reduce((a, s) => a + s.manual, 0), 'need documents or interviews')}</div>
      <div class="cmpgrid">${r.standards.map((s) => `<button class="card cmpcard" data-std="${s.id}"><div class="cmpcard-g">${C.gauge(s.score, { label: 'score', warn: 90, crit: 70, invert: true })}</div><div><b>${esc(s.short)}</b><div class="muted" style="font-size:12px">${esc(s.name)}</div><div class="cmp-counts"><span class="ok">${s.passing} pass</span><span class="crit">${s.failing} fail or partial</span><span>${s.manual} manual</span></div></div></button>`).join('')}</div>
      <div class="grid g2">
        ${MC.panel('Most failed checks', 'devices failing each check', C.barList(Object.entries(failing).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([k, n]) => ({ label: CMP.CHECKS[k].title, value: n, text: n + ' devices', status: 'Critical' }))) || '<div class="mc-empty">No failing checks.</div>')}
        ${MC.panel('Lowest scoring devices', 'share of applicable checks passed', C.barList(worstDevs.map((d) => ({ label: d.name, value: d.score, text: fmt(d.score, 0) + '% · ' + d.failed + ' failed', status: d.score >= 90 ? 'OK' : d.score >= 70 ? 'Warning' : 'Critical', href: '#/device/' + enc(d.id) })), { max: 100 }))}
      </div>
      ${MC.panel('Standards × devices', 'score per device for each standard (top 40 devices by failures)', '<div id="cHeat"></div>')}
      ${MC.panel('Devices', '', '<div id="cDev"></div>')}`;
    $$('[data-std]', out).forEach((b) => b.addEventListener('click', () => pick(b.dataset.std)));
    $$('[data-href]', out).forEach((n) => n.addEventListener('click', () => { location.hash = n.dataset.href; }));
    // per device, per standard score
    const stdDev = r.standards.map((s) => { const m = new Map(); for (const c of s.controls) for (const d of c.devices) { const x = m.get(d.device) || { p: 0, n: 0 }; x.n++; if (d.result === 'pass') x.p++; m.set(d.device, x); } return m; });
    const heatDevs = r.devices.slice().sort((a, b) => b.failed - a.failed).slice(0, 40);
    C.heatmap($('#cHeat', out), heatDevs.map((d) => ({ label: d.name.length > 18 ? d.name.slice(0, 17) + '…' : d.name, values: stdDev.map((m) => { const x = m.get(d.id); return x ? Math.round((x.p / x.n) * 100) : null; }) })), r.standards.map((s) => s.short.replace('CIS Windows Server', 'CIS WS').replace('CIS network devices', 'CIS Net')), { labelWidth: 140, rowHeight: 18, max: 100, unit: '%', metric: 'Controls passed' });
    devTable($('#cDev', out), r);
  }

  function devTable(host, r) {
    MC.table(host, r.devices, [
      { key: 'name', label: 'Device', html: (d) => `<a href="#/device/${enc(d.id)}">${esc(d.name)}</a>` },
      { key: 'kind', label: 'Type' },
      { key: 'score', label: 'Score', n: true, html: (d) => `<span class="cmp-score ${scoreCls(d.score)}">${fmt(d.score, 0)}%</span>` },
      { key: 'passed', label: 'Passed', n: true }, { key: 'failed', label: 'Failed', n: true },
      { key: 'fails', label: 'Failing checks', val: (d) => Object.values(d.results).filter((x) => x.result === 'fail').map((x) => x.title).join('; '), html: (d) => Object.values(d.results).filter((x) => x.result === 'fail').slice(0, 3).map((x) => `<span class="tag">${esc(x.title)}</span>`).join(' ') },
      { key: 'act', label: '', noCsv: true, html: (d) => `<button class="btn sm" data-dev="${esc(d.id)}">Details</button>` },
    ], { name: 'compliance-devices', sort: 'score', dir: 1, limit: 25, after: (w) => $$('[data-dev]', w).forEach((b) => b.addEventListener('click', () => deviceDialog(r.devices.find((x) => x.id === b.dataset.dev)))) });
  }

  function standard(out, r, scopeName) {
    const s = r.standards[0];
    out.innerHTML = `<div class="print-only"><h2>${esc(s.name)}</h2><p>${esc(scopeName)} · ${new Date(r.at).toLocaleString()}</p></div>
      <div class="grid g-1-2">
        ${MC.panel(s.short, esc(s.scope), `<div style="display:flex;justify-content:center">${C.gauge(s.score, { label: 'compliance', warn: 90, crit: 70, invert: true })}</div><div class="cmp-counts" style="justify-content:center"><span class="ok">${s.passing} pass</span><span class="crit">${s.failing} fail or partial</span><span>${s.manual} manual</span><span>${s.notApplicable} n/a</span></div>`)}
        ${MC.panel('Controls', 'devices passing each control', C.barList(s.controls.filter((c) => c.status !== 'manual' && c.status !== 'na').map((c) => ({ label: c.ref + ' ' + c.title, value: c.passed + c.failed ? (c.passed / (c.passed + c.failed)) * 100 : 0, text: c.passed + ' / ' + (c.passed + c.failed), status: c.status === 'pass' ? 'OK' : c.status === 'partial' ? 'Warning' : 'Critical' })), { max: 100, compact: true }))}
      </div>
      <section class="card panel-c"><div class="panel-h"><h3>Controls</h3><span class="sub">open a control to see each device and the evidence</span></div>
        <div class="cmp-controls">${s.controls.map((c, i) => `<details class="cmpctl st-${c.status}" ${c.status === 'fail' || c.status === 'partial' ? '' : ''}><summary><span class="mono ref">${esc(c.ref)}</span><span class="t">${esc(c.title)}</span>${stPill(c.status)}<span class="muted n">${c.status === 'manual' ? esc(c.manual || '') : c.passed + ' pass · ' + c.failed + ' fail'}</span></summary>${c.status === 'manual' ? `<p class="muted" style="margin:6px 0 4px 12px">Not testable from monitoring data. Evidence: ${esc(c.manual || 'documents')}.</p>` : `<div data-ctl="${i}"></div>`}</details>`).join('')}</div>
      </section>
      ${MC.panel('Devices', '', '<div id="cDev"></div>')}`;
    $$('details.cmpctl', out).forEach((d) => d.addEventListener('toggle', () => {
      const host = $('[data-ctl]', d); if (!d.open || !host || host.dataset.done) return; host.dataset.done = '1';
      const c = s.controls[+host.dataset.ctl];
      MC.table(host, c.devices, [
        { key: 'result', label: 'Result', html: (x) => stPill(x.result) },
        { key: 'name', label: 'Device', html: (x) => `<a href="#/device/${enc(x.device)}">${esc(x.name)}</a>` },
        { key: 'evidence', label: 'Evidence', val: (x) => x.checks.filter((y) => y.result !== 'na').map((y) => y.evidence).join(' | '), html: (x) => x.checks.filter((y) => y.result !== 'na').map((y) => `<div style="font-size:12.5px">${y.result === 'pass' ? '✓' : '✗'} ${esc(y.title)}: <span class="muted">${esc(y.evidence)}</span></div>`).join('') },
      ], { name: 'control-' + c.ref, sort: 'result', dir: 1, limit: 20 });
    }));
    devTable($('#cDev', out), r);
  }

  function deviceDialog(d) {
    const m = document.createElement('div');
    m.className = 'modal'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true');
    const rows = Object.entries(d.results).filter(([, v]) => v.result !== 'na').sort((a, b) => (a[1].result === 'fail' ? 0 : 1) - (b[1].result === 'fail' ? 0 : 1));
    const stds = CMP.STANDARDS.map((s) => ({ s, refs: s.controls.filter((c) => c.checks.some((k) => d.results[k] && d.results[k].result === 'fail')).map((c) => c.ref) })).filter((x) => x.refs.length);
    m.innerHTML = `<div class="card wide"><h3>${esc(d.name)} · ${fmt(d.score, 0)}% compliant</h3>
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>Result</th><th>Check</th><th>Evidence</th></tr></thead><tbody>${rows.map(([, v]) => `<tr><td>${stPill(v.result)}</td><td>${esc(v.title)}</td><td style="font-size:12.5px">${esc(v.evidence)}</td></tr>`).join('')}</tbody></table></div>
      ${stds.length ? `<h4 style="margin:12px 0 4px;font-size:13px">Controls affected by the failures</h4><ul class="plain" style="font-size:12.5px">${stds.map((x) => `<li><b>${esc(x.s.short)}</b>: ${x.refs.map(esc).join(', ')}</li>`).join('')}</ul>` : ''}
      <div class="foot"><a class="btn" href="#/device/${enc(d.id)}">Open device</a><button class="btn primary" data-x>Close</button></div></div>`;
    document.body.appendChild(m);
    $$('[data-x]', m).forEach((b) => b.addEventListener('click', () => m.remove()));
    m.addEventListener('keydown', (e) => { if (e.key === 'Escape') m.remove(); });
  }
})(typeof self !== 'undefined' ? self : this);
