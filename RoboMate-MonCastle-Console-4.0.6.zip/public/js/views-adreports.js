/*
 * RoboMate MonCastle - Active Directory › Reports & investigations, and Security & tiering.
 * Reports are grouped like the AD reporting tools admins know: Users, Computers, Groups, Deleted objects, Security.
 * Every report reads the AD collectors (ad.users, ad.computers, ad.groups, ad.deleted, ad.security) and the audit
 * events; reports with "N days" take the number from the selector. Each report exports to CSV.
 */
(function (root) {
  'use strict';
  const MC = root.MC, C = root.MCCharts;
  const { esc, fmt, pill, icon, ago, dt, $, $$ } = MC;
  const enc = encodeURIComponent;
  const DAY = 864e5;
  const age = (t) => (t ? Math.floor((Date.now() - Date.parse(t)) / DAY) : null);
  const yes = (v) => (v ? 'Yes' : 'No');
  const SEV = { Critical: 'Critical', High: 'Critical', Medium: 'Warning', Low: 'Info', Info: 'Unknown' };
  const RANK = { Critical: 0, High: 1, Medium: 2, Low: 3, Info: 4 };
  const UNSUPPORTED = /Windows (XP|Vista|7|8(\.1)?)\b|Server 20(03|08|12)/i;

  // ---- columns per object type
  const COLS = {
    user: [
      { key: 'SamAccountName', label: 'Account', html: (r) => `<b>${esc(r.SamAccountName)}</b><div class="muted" style="font-size:12px">${esc(r.DisplayName || '')}</div>` },
      { key: 'Enabled', label: 'Enabled', val: (r) => yes(r.Enabled), html: (r) => (r.Enabled ? 'Yes' : pill('Unknown', 'Disabled')) },
      { key: 'Department', label: 'Department' },
      { key: 'LastLogonDate', label: 'Last logon', val: (r) => r.LastLogonDate || '', html: (r) => (r.LastLogonDate ? `<span title="${esc(dt(r.LastLogonDate))}">${age(r.LastLogonDate)} d ago</span>` : '<span class="muted">never</span>') },
      { key: 'PasswordAgeDays', label: 'Password age d', n: true },
      { key: 'PasswordNeverExpires', label: 'Never expires', val: (r) => yes(r.PasswordNeverExpires) },
      { key: 'Created', label: 'Created', html: (r) => esc(dt(r.Created)) },
      { key: 'OU', label: 'OU', cls: 'mono' },
      { key: 'act', label: '', noCsv: true, html: (r) => (r.LockedOut ? `<button class="btn sm" ${MC.runAttr('act.ad.user', { Identity: r.SamAccountName, Operation: 'Unlock' })}>Unlock…</button>` : r.Enabled ? `<button class="btn sm ghost" ${MC.runAttr('act.ad.user', { Identity: r.SamAccountName, Operation: 'Disable' })}>Disable…</button>` : `<button class="btn sm ghost" ${MC.runAttr('act.ad.user', { Identity: r.SamAccountName, Operation: 'Enable' })}>Enable…</button>`) },
    ],
    computer: [
      { key: 'Name', label: 'Computer', html: (r) => `<a href="#" data-host="${esc(r.Name)}"><b>${esc(r.Name)}</b></a>` },
      { key: 'Enabled', label: 'Enabled', val: (r) => yes(r.Enabled), html: (r) => (r.Enabled ? 'Yes' : pill('Unknown', 'Disabled')) },
      { key: 'Role', label: 'Role' }, { key: 'OperatingSystem', label: 'Operating system' },
      { key: 'LastLogonDate', label: 'Last logon', val: (r) => r.LastLogonDate || '', html: (r) => (r.LastLogonDate ? `<span title="${esc(dt(r.LastLogonDate))}">${age(r.LastLogonDate)} d ago</span>` : '<span class="muted">never</span>') },
      { key: 'PasswordAgeDays', label: 'Machine password d', n: true },
      { key: 'LAPS', label: 'LAPS', val: (r) => yes(r.LAPS), html: (r) => (r.LAPS == null ? '' : r.LAPS ? 'Yes' : pill('Warning', 'No')) },
      { key: 'OU', label: 'OU', cls: 'mono' },
    ],
    deleted: [
      { key: 'Name', label: 'Name', html: (r) => `<b>${esc(r.Name)}</b>${r.DisplayName ? `<div class="muted" style="font-size:12px">${esc(r.DisplayName)}</div>` : ''}` },
      { key: 'Type', label: 'Type' }, { key: 'Deleted', label: 'Deleted', html: (r) => `<span title="${esc(dt(r.Deleted))}">${ago(r.Deleted)}</span>` },
      { key: 'LastKnownOU', label: 'Last known location', cls: 'mono' }, { key: 'OperatingSystem', label: 'OS' }, { key: 'Created', label: 'Created', html: (r) => esc(dt(r.Created)) },
      { key: 'Restorable', label: 'Restore', val: (r) => (r.Restorable ? 'All attributes (Recycle Bin)' : 'Tombstone only'), html: (r) => (r.Restorable ? pill('OK', 'Recycle Bin') : pill('Warning', 'Tombstone')) },
    ],
    group: [
      { key: 'Group', label: 'Group', html: (r) => `<a href="#/identity/reports?r=g-members&g=${enc(r.Group)}"><b>${esc(r.Group)}</b></a>` },
      { key: 'Scope', label: 'Scope' }, { key: 'Category', label: 'Type' },
      { key: 'Members', label: 'Direct members', n: true }, { key: 'Nested', label: 'Nested groups', n: true },
      { key: 'Privileged', label: 'Privileged', val: (r) => yes(r.Privileged), html: (r) => (r.Privileged ? pill('Warning', 'Privileged') : '') },
    ],
    member: [
      { key: 'Group', label: 'Group', html: (r) => `<a href="#/identity/reports?r=g-members&g=${enc(r.Group)}">${esc(r.Group)}</a>` },
      { key: 'Member', label: 'Member', html: (r) => (r.MemberType === 'group' ? `<a href="#/identity/reports?r=g-members&g=${enc(r.Member)}">${esc(r.Member)}</a>` : esc(r.Member || '')) },
      { key: 'MemberType', label: 'Member type' }, { key: 'Via', label: 'Through', val: (r) => r.Via || 'direct' },
      { key: 'Privileged', label: 'Privileged group', val: (r) => yes(r.Privileged) },
    ],
    finding: [
      { key: 'Severity', label: 'Severity', val: (r) => r.Severity, sortVal: (r) => RANK[r.Severity], html: (r) => pill(SEV[r.Severity] || 'Unknown', r.Severity) },
      { key: 'Check', label: 'Finding' }, { key: 'Object', label: 'Object', html: (r) => `<b>${esc(r.Object)}</b> <span class="muted">${esc(r.ObjectType || '')}</span>` },
      { key: 'Tier', label: 'Tier', val: (r) => (r.Tier == null ? '' : 'Tier ' + r.Tier), html: (r) => (r.Tier == null ? '' : `<span class="tag tier${r.Tier}">Tier ${r.Tier}</span>`) },
      { key: 'Evidence', label: 'Evidence' }, { key: 'Fix', label: 'How to fix' },
    ],
  };
  COLS.userSec = COLS.user.slice(0, 2).concat([
    { key: 'SPNs', label: 'SPNs', val: (r) => (r.SPNs || []).join(', '), cls: 'mono' },
    { key: 'Groups', label: 'Groups', val: (r) => (r.Groups || []).filter((g) => g !== 'Domain Users').join(', ') },
    { key: 'ProtectedUsers', label: 'Protected Users', val: (r) => yes(r.ProtectedUsers) },
    { key: 'PasswordAgeDays', label: 'Password age d', n: true },
  ]);

  // ---- group helpers: summary per group and recursive membership
  function groupsIndex() {
    const rows = MC.data('ad.groups');
    const by = new Map();
    for (const r of rows) {
      const g = by.get(r.Group) || { Group: r.Group, Scope: r.Scope, Category: r.Category, Privileged: !!r.Privileged, Members: 0, Nested: 0, list: [] };
      if (r.Member) { g.Members++; g.list.push(r); if (r.MemberType === 'group') g.Nested++; }
      by.set(r.Group, g);
    }
    return by;
  }
  function membersOf(name, by, seen, via) {
    seen = seen || new Set(); const g = by.get(name); if (!g || seen.has(name)) return [];
    seen.add(name);
    return g.list.flatMap((m) => [Object.assign({}, m, { Group: name, Via: via || '' })].concat(m.MemberType === 'group' ? membersOf(m.Member, by, seen, (via ? via + ' › ' : '') + m.Member).map((x) => Object.assign({}, x, { Group: name })) : []));
  }

  // ---- tiers: Tier 0 from the security collector, Tier 1 servers and Tier 1 admin OUs, Tier 2 the rest
  function tiers() {
    const sec = MC.data('ad.security');
    const t0Acc = new Set(sec.filter((r) => r.Check === 'Tier 0 account').map((r) => String(r.Object).toLowerCase()));
    const t0Srv = new Set(sec.filter((r) => r.Check === 'Tier 0 server').map((r) => String(r.Object).toUpperCase()));
    const users = MC.data('ad.users'), comps = MC.data('ad.computers');
    const userTier = (u) => (t0Acc.has(String(u.SamAccountName).toLowerCase()) ? 0 : /Tier ?1|\/T1\b/i.test(u.OU || '') ? 1 : 2);
    const compTier = (c) => (t0Srv.has(String(c.Name).toUpperCase()) || c.DomainController ? 0 : c.Role === 'Server' ? 1 : 2);
    // Tier 0 accounts signing in on lower-tier computers, from the audit events (remote desktop and interactive logons)
    const logons = MC.data('audit.events').filter((e) => ['RemoteLogon', 'Logon', 'InteractiveLogon'].includes(e.EventSet));
    const viol = [];
    for (const e of logons) {
      const acc = String(e.Actor || e.Target || '').split('\\').pop().toLowerCase(), pc = String(e.Server || e.Workstation || '').split('.')[0].toUpperCase();
      if (acc && pc && t0Acc.has(acc) && !t0Srv.has(pc)) viol.push({ Category: 'Tiering', Check: 'Tier violation: Tier 0 logon on a lower tier', Object: acc, ObjectType: 'User', Tier: 0, Severity: 'Critical', Evidence: 'Signed in to ' + pc + ' (Tier ' + (/^WS-/.test(pc) ? 2 : 1) + ') ' + ago(e.Time), Fix: 'Use a Tier 0 privileged access workstation; deny Tier 0 logons on Tier 1 and 2 with "Deny log on" user rights.', Time: e.Time, Computer: pc });
    }
    // one row per account and computer, newest logon
    const seen = new Map(); for (const v of viol.sort((a, b) => (a.Time < b.Time ? 1 : -1))) { const k = v.Object + '|' + v.Computer; if (!seen.has(k)) seen.set(k, v); }
    return { t0Acc, t0Srv, userTier, compTier, violations: [...seen.values()], users, comps, sec };
  }

  // ---- the reports
  const U = () => MC.data('ad.users'), CP = () => MC.data('ad.computers'), DEL = () => MC.data('ad.deleted');
  const REPORTS = [
    ['Users', 'user', [
      ['u-all', 'All users', 'Every user account in the domain.', () => U()],
      ['u-disabled', 'Disabled users', 'Accounts that are turned off. Delete them after your retention period.', () => U().filter((u) => !u.Enabled)],
      ['u-locked', 'Locked-out users', 'Unlock from the row, or investigate the source under Audit › Lockouts.', () => U().filter((u) => u.LockedOut)],
      ['u-deleted', 'Deleted users', 'Users still in the AD Recycle Bin, newest first.', () => DEL().filter((x) => x.Type === 'User'), 'deleted'],
      ['u-pwdold', 'Password not changed in N days', 'Enabled users whose password is older than the chosen number of days.', (n) => U().filter((u) => u.Enabled && u.PasswordAgeDays >= n), null, 180],
      ['u-inactive', 'Inactive users (no logon in N days)', 'Enabled users that have not signed in for the chosen number of days. Disable or move them with the stale-objects action.', (n) => U().filter((u) => u.Enabled && u.LastLogonDate && age(u.LastLogonDate) >= n), null, 90, 'Users'],
      ['u-never', 'Never logged on', 'Accounts that were created but never used.', () => U().filter((u) => u.NeverLoggedOn || !u.LastLogonDate)],
      ['u-pne', 'Password never expires', 'Enabled accounts exempt from password expiry.', () => U().filter((u) => u.Enabled && u.PasswordNeverExpires)],
      ['u-pexp', 'Password expired', 'Users that must change their password before they can sign in.', () => U().filter((u) => u.PasswordExpired)],
      ['u-aexp', 'Account expired', 'Accounts past their expiry date (often contractors).', () => U().filter((u) => u.AccountExpired)],
      ['u-asoon', 'Account expires in N days', 'Accounts that expire soon.', (n) => U().filter((u) => u.AccountExpires && !u.AccountExpired && -age(u.AccountExpires) <= n), null, 30],
      ['u-created', 'Created in the last N days', 'New accounts.', (n) => U().filter((u) => age(u.Created) <= n), null, 30],
      ['u-pnr', 'Password not required', 'Accounts that may have an empty password (PASSWD_NOTREQD).', () => U().filter((u) => u.PasswordNotRequired)],
      ['u-priv', 'Privileged users (adminCount)', 'Accounts protected by AdminSDHolder: current or former members of privileged groups.', () => U().filter((u) => u.Privileged || u.AdminCount)],
    ]],
    ['Computers', 'computer', [
      ['c-all', 'All computers', 'Every computer account.', () => CP()],
      ['c-inactive', 'Inactive computers (no logon in N days)', 'Computers that have not signed in to the domain for the chosen number of days.', (n) => CP().filter((c) => c.Enabled && c.LastLogonDate && age(c.LastLogonDate) >= n), null, 90, 'Computers'],
      ['c-disabled', 'Disabled computers', 'Computer accounts that are turned off.', () => CP().filter((c) => !c.Enabled)],
      ['c-deleted', 'Deleted computers', 'Computers still in the AD Recycle Bin.', () => DEL().filter((x) => x.Type === 'Computer'), 'deleted'],
      ['c-never', 'Never logged on', 'Joined or pre-staged, never used.', () => CP().filter((c) => c.NeverLoggedOn || !c.LastLogonDate)],
      ['c-unsupported', 'Unsupported operating systems', 'Windows 7/8, Server 2003/2008/2012 and older.', () => CP().filter((c) => UNSUPPORTED.test(c.OperatingSystem || ''))],
      ['c-nolaps', 'No LAPS password', 'Computers without a managed local administrator password.', () => CP().filter((c) => c.Enabled && c.LAPS === false && !c.DomainController)],
      ['c-created', 'Created in the last N days', 'New computer accounts.', (n) => CP().filter((c) => age(c.Created) <= n), null, 30],
      ['c-servers', 'Servers', 'Computer accounts running a server OS.', () => CP().filter((c) => c.Role === 'Server')],
    ]],
    ['Groups', 'group', [
      ['g-all', 'All groups', 'Every group with its member count. Open a group for its members.', () => [...groupsIndex().values()]],
      ['g-members', 'Group membership', 'Members of one group, including members of nested groups.', (n, q) => { const by = groupsIndex(); const g = q.g || [...by.keys()][0]; return membersOf(g, by); }, 'member'],
      ['g-user', 'Groups of a user', 'Every group a user belongs to.', (n, q) => { const u = U().find((x) => x.SamAccountName === q.u) || U().find((x) => (x.Groups || []).length > 2) || U()[0]; return (u && u.Groups || []).map((g) => ({ Group: g, Member: u.SamAccountName, MemberType: 'user', Privileged: (groupsIndex().get(g) || {}).Privileged })); }, 'member'],
      ['g-empty', 'Empty groups', 'Groups without members: candidates for clean-up.', () => [...groupsIndex().values()].filter((g) => !g.Members)],
      ['g-nested', 'Nested groups', 'Groups that contain other groups.', () => [...groupsIndex().values()].filter((g) => g.Nested)],
      ['g-priv', 'Privileged group members', 'Everyone in the built-in privileged groups, through nesting too.', () => { const by = groupsIndex(); return [...by.values()].filter((g) => g.Privileged).flatMap((g) => membersOf(g.Group, by)); }, 'member'],
      ['g-deleted', 'Deleted groups', 'Groups still in the AD Recycle Bin.', () => DEL().filter((x) => x.Type === 'Group'), 'deleted'],
    ]],
    ['Security', 'finding', [
      ['s-all', 'All security findings', 'Every finding of the AD security collector and tier violations from logons, worst first.', () => tiers().sec.filter((r) => r.Severity !== 'Info').concat(tiers().violations)],
      ['s-violations', 'Tier violations', 'Links that let a lower tier control Tier 0: Tier 0 logons on Tier 1/2 computers, lower-tier objects in Tier 0 groups, unprotected Tier 0 accounts.', () => tiers().violations.concat(tiers().sec.filter((r) => r.Category === 'Tiering' && r.Severity !== 'Info'))],
      ['s-tier0', 'Tier 0 assets', 'Accounts and servers that control the domain.', () => tiers().sec.filter((r) => r.Severity === 'Info' && /^Tier 0/.test(r.Check))],
      ['s-kerb', 'Kerberoastable accounts (SPN)', 'Enabled accounts with a service principal name: their password can be cracked offline.', () => U().filter((u) => u.Enabled && (u.SPNs || []).length && u.SamAccountName !== 'krbtgt'), 'userSec'],
      ['s-asrep', 'AS-REP roastable accounts', 'Accounts without Kerberos pre-authentication.', () => U().filter((u) => u.Enabled && u.DoesNotRequirePreAuth), 'userSec'],
      ['s-deleg', 'Kerberos delegation', 'Unconstrained and constrained delegation on users and computers.', () => tiers().sec.filter((r) => /delegation/i.test(r.Check))],
      ['s-admincount', 'adminCount orphans', 'Accounts that left privileged groups but keep blocked inheritance.', () => tiers().sec.filter((r) => r.Check === 'adminCount orphan')],
      ['s-protected', 'Tier 0 without Protected Users', 'Privileged accounts whose credentials can be cached on other machines.', () => tiers().sec.filter((r) => /not in Protected Users|can be delegated/.test(r.Check))],
      ['s-krbtgt', 'krbtgt password age', 'The key that signs every Kerberos ticket. Reset it twice at least every 180 days.', () => tiers().sec.filter((r) => r.Object === 'krbtgt')],
    ]],
  ];
  const ALL = new Map(REPORTS.flatMap(([cat, type, list]) => list.map(([id, name, desc, fn, cols, days, stale]) => [id, { id, cat, name, desc, fn, cols: cols || type, days, stale }])));

  MC.adReports = (el, route) => {
    const q = route.q || {};
    const cur = ALL.get(q.r) || ALL.get('u-inactive');
    const n = +q.d || cur.days || 0;
    const counts = (r) => { try { return r.fn(r.days || 0, q).length; } catch (e) { return 0; } };
    el.innerHTML = `<div class="adr">
      <nav class="adr-nav card" aria-label="Reports">${REPORTS.map(([cat, , list]) => `<div class="adr-cat"><div class="adr-cat-h">${icon({ Users: 'users', Computers: 'server', Groups: 'grid', Security: 'shield' }[cat] || 'report', 'sev-ico')}${esc(cat)}</div>${list.map(([id, name]) => { const r = ALL.get(id); const c = counts(r); return `<a href="#/identity/reports?r=${id}" class="${id === cur.id ? 'on' : ''}" ${id === cur.id ? 'aria-current="page"' : ''}><span>${esc(name.replace(' N days', r.days ? ' ' + r.days + ' days' : ''))}</span><span class="n ${c && /^s-/.test(id) && id !== 's-tier0' ? 'bad' : ''}">${c}</span></a>`; }).join('')}</div>`).join('')}</nav>
      <div class="adr-main" id="adrM"></div></div>`;
    const box = $('#adrM', el);
    let rows = [];
    try { rows = cur.fn(n, q); } catch (e) { rows = []; }
    const opts = cur.days ? `<label class="rs-chk">N = <select class="input sm" id="adrD">${[7, 14, 30, 60, 90, 120, 180, 365, 730].map((d) => `<option ${d === n ? 'selected' : ''}>${d}</option>`).join('')}</select> days</label>` : '';
    const pickG = cur.id === 'g-members' ? `<label class="rs-chk">Group <select class="input sm" id="adrG">${[...groupsIndex().keys()].sort().map((g) => `<option ${g === (q.g || '') ? 'selected' : ''}>${esc(g)}</option>`).join('')}</select></label>` : cur.id === 'g-user' ? `<label class="rs-chk">User <input class="input sm" id="adrU" list="adrUL" value="${esc(q.u || (rows[0] || {}).Member || '')}" style="width:180px"><datalist id="adrUL">${U().slice(0, 600).map((u) => `<option value="${esc(u.SamAccountName)}">`).join('')}</datalist></label>` : '';
    const stale = cur.stale ? `<button class="btn sm" ${MC.runAttr('act.ad.stale', { Operation: 'Report', ObjectType: cur.stale, InactiveDays: n })}>Disable or move these…</button>` : '';
    box.innerHTML = MC.panel(cur.name.replace(' N days', ' ' + n + ' days').replace('in N days', 'in ' + n + ' days'), cur.cat + ' · ' + rows.length + ' result' + (rows.length === 1 ? '' : 's'), `<p class="muted" style="margin-top:0">${esc(cur.desc)}</p><div class="actions-row" style="margin-bottom:8px">${opts}${pickG}${stale}</div><div id="adrT"></div>`);
    MC.table($('#adrT', box), cur.cols === 'finding' ? rows.slice().sort((a, b) => RANK[a.Severity] - RANK[b.Severity]) : rows, COLS[cur.cols], { name: 'ad-' + cur.id, limit: 50, empty: 'Nothing found. Good.' });
    const nav = (extra) => MC.go('identity', 'reports', Object.assign({ r: cur.id }, n && cur.days ? { d: n } : {}, q.g ? { g: q.g } : {}, extra));
    if ($('#adrD', box)) $('#adrD', box).addEventListener('change', (e) => nav({ d: e.target.value }));
    if ($('#adrG', box)) $('#adrG', box).addEventListener('change', (e) => nav({ g: e.target.value }));
    if ($('#adrU', box)) $('#adrU', box).addEventListener('change', (e) => nav({ u: e.target.value }));
  };

  // ---- Security & tiering dashboard
  MC.adSecurity = (el) => {
    const T = tiers();
    const find = T.sec.filter((r) => r.Severity !== 'Info').concat(T.violations);
    const sum = (MC.ds['ad.security'] || {}).summary || {};
    const ut = [0, 1, 2].map((t) => T.users.filter((u) => u.Enabled && T.userTier(u) === t).length);
    const ct = [0, 1, 2].map((t) => T.comps.filter((c) => c.Enabled && T.compTier(c) === t).length);
    const tierViol = T.violations.length + T.sec.filter((r) => r.Category === 'Tiering' && r.Severity !== 'Info').length;
    const kerb = T.users.filter((u) => u.Enabled && (u.SPNs || []).length && u.SamAccountName !== 'krbtgt').length;
    const deleg = T.sec.filter((r) => /Unconstrained/.test(r.Check)).length;
    const byCat = Object.entries(find.reduce((a, r) => { (a[r.Category] = a[r.Category] || { Critical: 0, Warning: 0, Info: 0 })[SEV[r.Severity] === 'Critical' ? 'Critical' : SEV[r.Severity] === 'Warning' ? 'Warning' : 'Info']++; return a; }, {}));
    el.innerHTML = `<div class="kpis">${MC.kpi('Tier 0 accounts', ut[0], T.t0Srv.size + ' Tier 0 servers')}${MC.kpi('Tier violations', tierViol, T.violations.length + ' Tier 0 logons on lower tiers', { alert: tierViol > 0 })}${MC.kpi('Critical findings', find.filter((r) => r.Severity === 'Critical').length, find.length + ' findings in all', { alert: find.some((r) => r.Severity === 'Critical') })}${MC.kpi('Kerberoastable', kerb, 'accounts with an SPN', { alert: kerb > 0 })}${MC.kpi('Unconstrained delegation', deleg, 'users and computers', { alert: deleg > 0 })}${MC.kpi('krbtgt password', (sum.krbtgtAgeDays != null ? sum.krbtgtAgeDays : '–') + ' days', 'reset every 180 days', { alert: sum.krbtgtAgeDays > 180 })}</div>
      <div class="grid g-1-2">
        ${MC.panel('Tier model', 'enabled accounts and computers per tier', `<div class="tiers">${[0, 1, 2].map((t) => `<a class="tier tier${t}" href="#/identity/reports?r=${t === 0 ? 's-tier0' : 'u-all'}"><b>Tier ${t}</b><span>${['Domain controllers, AD CS, Entra Connect, domain and enterprise admins', 'Servers and server administrators', 'Workstations and users'][t]}</span><span class="tier-n">${ut[t]} accounts · ${ct[t]} computers</span></a>`).join('')}</div><p class="muted" style="font-size:12.5px">Control must only flow down: a Tier 0 account never signs in to Tier 1 or 2, and nothing in Tier 1 or 2 can change Tier 0. Name your Tier 1 groups and OUs on the AD security collector (Tier1Groups, Tier1OUs).</p>`)}
        ${MC.panel('Findings by area', 'worst first', C.barList(byCat.map(([k, v]) => ({ label: k, sub: v.Critical + ' critical · ' + v.Warning + ' warning', value: v.Critical * 3 + v.Warning * 2 + v.Info, text: String(v.Critical + v.Warning + v.Info), status: v.Critical ? 'Critical' : v.Warning ? 'Warning' : null, color: '--s1', href: '#/identity/reports?r=s-all' })), { compact: true }) || '<p class="muted">No findings.</p>')}
      </div>
      ${MC.panel('Tier violations', 'Tier 0 logons on Tier 1/2 computers come from the audit events; the rest from the AD security collector', '<div id="adsV"></div>', { act: `<button class="btn sm" ${MC.runAttr('inv.ad.security', {})}>Collect now…</button>` })}
      ${MC.panel('All findings', 'Kerberos, delegation, privilege and password findings', '<div id="adsF"></div>', { act: '<a class="btn sm ghost" href="#/identity/reports?r=s-all">Open as a report</a>' })}`;
    MC.table($('#adsV', el), T.violations.concat(T.sec.filter((r) => r.Category === 'Tiering' && r.Severity !== 'Info')), COLS.finding, { name: 'ad-tier-violations', search: false, empty: 'No tier violations found.' });
    MC.table($('#adsF', el), find.filter((r) => r.Category !== 'Tiering').sort((a, b) => RANK[a.Severity] - RANK[b.Severity]), COLS.finding, { name: 'ad-security-findings', limit: 25 });
  };
})(typeof self !== 'undefined' ? self : this);
