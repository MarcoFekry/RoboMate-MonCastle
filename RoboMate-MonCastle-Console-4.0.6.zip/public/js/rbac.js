/*
 * RoboMate MonCastle - role based access control, shared by the server (module.exports) and the browser (window.MCRbac).
 *   Roles: reader < contributor < admin.
 *   A user has a console role. User groups grant a role on device groups (or on everything), like PRTG's group permissions.
 *   A "restricted" user only sees the device groups that one of their user groups grants; their console role still caps
 *   console-wide features (users, licences, credentials).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCRbac = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const ROLES = ['reader', 'contributor', 'admin'];
  const RANK = { none: 0, reader: 1, contributor: 2, admin: 3 };
  const LEGACY = { viewer: 'reader', operator: 'contributor' };
  const norm = (r) => (ROLES.includes(r) ? r : LEGACY[r] || 'reader');
  const max = (a, b) => (RANK[a || 'none'] >= RANK[b || 'none'] ? a || 'none' : b);

  // what each role may do; shown in the console as the permission matrix
  const MATRIX = [
    ['See dashboards, devices, sensors, inventory, audit and reports', 'reader'],
    ['Run read-only tools (event viewer, live view, processes, sessions…)', 'reader'],
    ['Pause, resume, scan and acknowledge sensors', 'contributor'],
    ['Add and change devices, sensors and limits in their device groups', 'contributor'],
    ['Use saved credentials on devices (never see the secrets)', 'contributor'],
    ['Run low and medium risk actions (services, processes, client maintenance…)', 'contributor'],
    ['Create dashboards and reports and share them', 'contributor'],
    ['Run high-risk actions (power, isolate, firewall, passwords, software removal)', 'admin'],
    ['Manage credentials, notifications, engines, schedules and discovery scans', 'admin'],
    ['Manage users, user groups, permissions, licences, releases and updates', 'admin'],
  ];

  // groups: [{ id, name, members:[user], grants:[{ scope:'all'|deviceGroupId, role }] }]
  // chain(gid) -> [gid, parent, …] so a grant on a parent group covers its children
  function access(user, deviceGroup, groups, chain) {
    if (!user) return 'none';
    const role = norm(user.role);
    let r = user.restricted && role !== 'admin' ? 'none' : role;
    const path = chain ? chain(deviceGroup) : [deviceGroup];
    for (const g of groups || []) {
      if (!(g.members || []).some((m) => String(m).toLowerCase() === String(user.name).toLowerCase())) continue;
      for (const gr of g.grants || []) if (gr.scope === 'all' || path.includes(gr.scope)) r = max(r, norm(gr.role));
    }
    // a group grant never lifts a user above admin, and admins always see everything
    return role === 'admin' ? 'admin' : r;
  }
  const atLeast = (have, need) => RANK[have || 'none'] >= RANK[need];
  // role a script needs: read-only tools for readers, actions for contributors, high risk for admins
  const scriptRole = (s) => (s.kind === 'action' ? (s.risk === 'high' ? 'admin' : 'contributor') : 'reader');

  return { ROLES, RANK, MATRIX, norm, access, atLeast, scriptRole, max };
});
