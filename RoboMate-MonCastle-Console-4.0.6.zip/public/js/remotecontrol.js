/*
 * RoboMate MonCastle - remote control of onboarded devices (browser: window.MCRemoteControl, server: require).
 * RDP for Windows, SSH for Linux, network, storage and appliances, and the device's own web interface (HTTPS or HTTP).
 * The console prepares the session and logs it; the session itself runs in the person's own client: the Remote Desktop
 * client opens the .rdp file, an ssh:// link or the copied command opens their SSH client, and the web interface opens in a
 * new browser tab. No password leaves the console: the user name is filled in, the password is typed in the client.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCRemoteControl = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const NET = ['network', 'firewall', 'wireless', 'loadbalancer', 'fcswitch', 'voip'];
  const STORE = ['san', 'nas', 'backup', 'storage'];
  const isLinux = (d) => d.kind === 'linux' || /linux|ubuntu|debian|red hat|rhel|centos|suse|rocky|alma|unix/i.test(d.os || '');
  const isWin = (d) => ['server', 'workstation', 'domain'].includes(d.kind) && !isLinux(d) && !/esxi/i.test(d.os || '') || (d.kind === 'vm' && /windows/i.test(d.os || ''));
  const METHODS = {
    rdp: { id: 'rdp', label: 'Remote Desktop (RDP)', port: 3389, cred: 'windows', how: 'Opens in the Remote Desktop client (mstsc on Windows, Windows App on macOS).' },
    ssh: { id: 'ssh', label: 'SSH terminal', port: 22, cred: 'ssh', how: 'Opens your SSH client (Windows Terminal, PuTTY, macOS or Linux Terminal) through an ssh:// link, or paste the command.' },
    https: { id: 'https', label: 'Web interface (HTTPS)', port: 443, cred: 'http', how: 'Opens the device\'s own management page in a new browser tab.' },
    http: { id: 'http', label: 'Web interface (HTTP)', port: 80, cred: 'http', how: 'Opens the device\'s own management page in a new tab. HTTP is not encrypted: prefer HTTPS when the device offers it.' },
  };
  // the methods a device supports, best first; open ports from discovery (d.ports) add or confirm them
  function methodsFor(d) {
    if (!d) return [];
    const ports = (d.ports || []).map(Number), has = (p) => ports.includes(p);
    const out = [];
    if (isWin(d) || has(3389)) out.push('rdp');
    if (isLinux(d) || NET.includes(d.kind) || STORE.includes(d.kind) || ['appliance', 'host', 'cluster'].includes(d.kind) || has(22)) out.push('ssh');
    const web = NET.includes(d.kind) || STORE.includes(d.kind) || isLinux(d) || ['appliance', 'host', 'cluster', 'printer', 'ups', 'camera'].includes(d.kind) || has(443) || has(80) || has(8443);
    if (web) { out.push('https'); if (has(80) || ['printer', 'ups', 'camera'].includes(d.kind)) out.push('http'); }
    return [...new Set(out)];
  }
  const HOST_RE = /^[A-Za-z0-9][\w.:-]{0,252}$/;
  const safeUser = (u) => String(u || '').replace(/[^\w.@\\-]/g, '').slice(0, 104);
  // what the browser needs to start the session: an .rdp file, an ssh:// link and command, or a web address
  function session(d, method, opts) {
    opts = opts || {};
    const host = String(d.host || d.name || '');
    if (!HOST_RE.test(host)) throw new Error('The device has no usable address.');
    const m = METHODS[method];
    if (!m || !methodsFor(d).includes(method)) throw new Error((m ? m.label : 'That method') + ' is not available for ' + d.name + '.');
    const port = +opts.port > 0 && +opts.port < 65536 ? +opts.port : m.port;
    const user = safeUser(opts.username);
    const h6 = host.includes(':') && !host.startsWith('[') ? '[' + host + ']' : host;
    if (method === 'rdp') {
      const lines = ['full address:s:' + host + (port !== 3389 ? ':' + port : ''), 'prompt for credentials:i:1', 'authentication level:i:2', 'enablecredsspsupport:i:1', 'screen mode id:i:2', 'use multimon:i:0', 'redirectclipboard:i:1', 'redirectprinters:i:0', 'redirectdrives:i:0', 'audiomode:i:2', 'autoreconnection enabled:i:1'];
      if (user) lines.push('username:s:' + user);
      return { method, label: m.label, host, port, file: { name: String(d.name).replace(/[^\w.-]/g, '_') + '.rdp', type: 'application/x-rdp', text: lines.join('\r\n') + '\r\n' }, command: 'mstsc /v:' + host + (port !== 3389 ? ':' + port : ''), how: m.how };
    }
    if (method === 'ssh') {
      const at = (user ? user + '@' : '') + h6;
      return { method, label: m.label, host, port, url: 'ssh://' + at + (port !== 22 ? ':' + port : ''), command: 'ssh ' + (port !== 22 ? '-p ' + port + ' ' : '') + (user ? user + '@' : '') + host, how: m.how };
    }
    const def = method === 'https' ? 443 : 80;
    return { method, label: m.label, host, port, url: method + '://' + h6 + (port !== def ? ':' + port : '') + '/', how: m.how };
  }
  return { METHODS, methodsFor, session };
});
