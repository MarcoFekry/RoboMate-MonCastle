/*
 * RoboMate MonCastle - demo environment.
 * Produces datasets in exactly the shape the PowerShell scripts emit (the "data" + "summary"
 * of the result envelope), so the console renders the same way in demo and live mode.
 * Used by the browser (window.MCDemo) and by the Node server in demo mode (module.exports).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCDemo = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  function rng(seed) {
    let s = seed >>> 0;
    return function () {
      s = (s + 0x6D2B79F5) >>> 0;
      let t = s;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const R = rng(20261023);
  const pick = (a) => a[Math.floor(R() * a.length)];
  const between = (a, b) => a + R() * (b - a);
  const int = (a, b) => Math.floor(between(a, b + 1));
  const round = (v, d = 1) => Math.round(v * 10 ** d) / 10 ** d;
  const pad = (n, w = 2) => String(n).padStart(w, '0');
  const iso = (d) => new Date(d).toISOString();
  const NOW = () => Date.now();
  const H = 3600e3, D = 24 * H;

  const DOMAIN = 'corp.moncastle.local';
  const SITES = ['HQ-Main', 'DR-Site', 'Branch-North', 'Branch-South'];
  const SUBNETS = { 'HQ-Main': '10.10.', 'DR-Site': '10.20.', 'Branch-North': '10.30.', 'Branch-South': '10.40.' };
  const ip = (site, a, b) => SUBNETS[site] + a + '.' + b;

  // ------------------------------------------------------------------ servers
  const serverDefs = [
    ['DC01', ['DomainControllers', 'DNS', 'DHCP'], 'HQ-Main'], ['DC02', ['DomainControllers', 'DNS'], 'HQ-Main'],
    ['DC03', ['DomainControllers', 'DNS', 'DHCP'], 'DR-Site'], ['DC04', ['DomainControllers', 'DNS'], 'Branch-North'],
    ['FS01', ['FileServers', 'DFS'], 'HQ-Main'], ['FS02', ['FileServers', 'DFS'], 'HQ-Main'], ['FS03', ['FileServers'], 'Branch-South'],
    ['PRN01', ['PrintServers'], 'HQ-Main'], ['PRN02', ['PrintServers'], 'Branch-North'],
    ['SQL01', ['SQL'], 'HQ-Main'], ['SQL02', ['SQL'], 'HQ-Main'], ['SQL03', ['SQL'], 'DR-Site'], ['SQL04', ['SQL', 'Clusters'], 'HQ-Main'], ['SQL05', ['SQL', 'Clusters'], 'HQ-Main'],
    ['HV01', ['HyperV', 'Clusters'], 'HQ-Main'], ['HV02', ['HyperV', 'Clusters'], 'HQ-Main'], ['HV03', ['HyperV', 'Clusters'], 'HQ-Main'], ['HV04', ['HyperV'], 'DR-Site'],
    ['WEB01', ['IIS'], 'HQ-Main'], ['WEB02', ['IIS'], 'HQ-Main'], ['WEB03', ['IIS'], 'DR-Site'],
    ['CA01', ['CertificateAuthority'], 'HQ-Main'], ['WSUS01', ['WSUS'], 'HQ-Main'], ['NPS01', ['NPS'], 'HQ-Main'],
    ['RDS01', ['RDS'], 'HQ-Main'], ['RDS02', ['RDS'], 'HQ-Main'], ['BKP01', ['General'], 'DR-Site'], ['MC01', ['General'], 'HQ-Main'],
    ['APP01', ['General'], 'HQ-Main'], ['APP02', ['General'], 'HQ-Main'], ['APP03', ['General'], 'HQ-Main'], ['APP04', ['General'], 'DR-Site'],
    ['APP05', ['General'], 'Branch-North'], ['APP06', ['General'], 'Branch-South'], ['ERP01', ['General', 'IIS'], 'HQ-Main'], ['ERP02', ['General'], 'HQ-Main'],
    ['EXCH01', ['General'], 'HQ-Main'], ['EXCH02', ['General'], 'DR-Site'], ['SCCM01', ['General', 'IIS'], 'HQ-Main'], ['LOG01', ['General'], 'HQ-Main'],
  ];
  const physical = new Set(['HV01', 'HV02', 'HV03', 'HV04', 'SQL04', 'SQL05', 'BKP01', 'FS01', 'DC01']);
  const vmwareHosted = new Set(['APP01', 'APP02', 'APP03', 'APP05', 'APP06', 'ERP01', 'ERP02', 'EXCH01', 'EXCH02', 'SCCM01', 'LOG01', 'WEB01', 'WEB02']);
  const osFor = (n) => (/^DC0[34]|^APP0[56]|^FS03|^PRN02/.test(n) ? 'Windows Server 2019 Standard' : /^SQL0[123]|^WEB03|^EXCH02/.test(n) ? 'Windows Server 2016 Standard' : /^HV|^SQL0[45]/.test(n) ? 'Windows Server 2022 Datacenter' : 'Windows Server 2022 Standard');
  const hot = { SQL02: 88, APP03: 94, EXCH01: 72, RDS01: 81, FS02: 64 };
  const offline = new Set(['APP06']);

  const servers = serverDefs.map(([name, roles, site], i) => {
    const phys = physical.has(name);
    const cores = phys ? pick([32, 48, 64]) : pick([4, 4, 8, 8, 16]);
    const ram = phys ? pick([256, 384, 512]) : pick([8, 16, 16, 32, 64]);
    return {
      name, roles, site, i,
      fqdn: (name + '.' + DOMAIN).toLowerCase(),
      ip: ip(site, 1 + (i % 3), 10 + i),
      os: osFor(name),
      machineType: phys ? 'Physical' : vmwareHosted.has(name) ? 'Virtual (VMware)' : 'Virtual (Hyper-V)',
      manufacturer: phys ? pick(['Dell Inc.', 'HPE']) : vmwareHosted.has(name) ? 'VMware, Inc.' : 'Microsoft Corporation',
      model: phys ? pick(['PowerEdge R750', 'PowerEdge R740xd', 'ProLiant DL380 Gen10 Plus']) : vmwareHosted.has(name) ? 'VMware7,1' : 'Virtual Machine',
      cores, ram,
      baseCpu: hot[name] || between(8, 45),
      baseMem: between(35, 78) + (hot[name] ? 10 : 0),
      offline: offline.has(name),
    };
  });
  const byName = Object.fromEntries(servers.map((s) => [s.name, s]));

  function cpuAt(s, t) {
    const hour = new Date(t).getHours() + new Date(t).getMinutes() / 60;
    const business = Math.max(0, Math.sin(((hour - 7) / 12) * Math.PI));
    const seed = Math.sin(t / 7.3e5 + s.i * 1.7) * 4 + Math.sin(t / 2.1e6 + s.i) * 3;
    const v = s.baseCpu * (0.55 + 0.6 * business) + seed + (R() - 0.5) * 6;
    return Math.max(1, Math.min(100, v));
  }
  function memAt(s, t) {
    const v = s.baseMem + Math.sin(t / 3.6e6 + s.i) * 3 + (R() - 0.5) * 2;
    return Math.max(5, Math.min(99, v));
  }
  const statusOf = (v, w, c) => (v >= c ? 'Critical' : v >= w ? 'Warning' : 'OK');

  function compute(now = NOW()) {
    const data = servers.map((s) => {
      if (s.offline) return { Name: s.name, Online: false, Status: 'Offline', Error: 'WinRM cannot complete the operation: the host is unreachable.' };
      const cpu = round(cpuAt(s, now)), mem = round(memAt(s, now));
      const iopsBase = s.roles.includes('SQL') ? 2400 : s.roles.includes('FileServers') ? 900 : s.roles.includes('HyperV') ? 3200 : 180;
      const st = [statusOf(cpu, 75, 90), statusOf(mem, 80, 92)];
      return {
        Name: s.name, Time: iso(now), CPU: cpu, Memory: mem, MemoryTotalGB: s.ram, MemoryFreeGB: round(s.ram * (1 - mem / 100)),
        DiskReadIOPS: Math.round(iopsBase * between(0.4, 1.1)), DiskWriteIOPS: Math.round(iopsBase * between(0.2, 0.7)),
        DiskReadKBps: Math.round(iopsBase * between(20, 60)), DiskWriteKBps: Math.round(iopsBase * between(10, 40)),
        DiskLatencyMs: round(s.roles.includes('SQL') ? between(4, 18) : between(0.6, 6)), DiskQueue: round(between(0, s.name === 'SQL02' ? 6 : 1.4)),
        NetKBps: Math.round(between(200, s.roles.includes('FileServers') ? 48000 : 9000)), CPUQueue: round(between(0, cpu > 85 ? 9 : 2)),
        TopProcess: s.roles.includes('SQL') ? 'sqlservr (' + Math.round(cpu * 0.8) + '%)' : s.name === 'APP03' ? 'java (' + Math.round(cpu * 0.85) + '%)' : pick(['svchost', 'w3wp', 'MsMpEng', 'System', 'lsass']) + ' (' + Math.round(cpu / 3) + '%)',
        UptimeHours: round(s.name === 'APP02' ? 2650 : between(30, 900)), Online: true,
        Status: st.includes('Critical') ? 'Critical' : st.includes('Warning') ? 'Warning' : 'OK',
      };
    });
    const on = data.filter((d) => d.Online);
    return env('servers.compute', data, {
      targets: data.length, online: on.length, offline: data.length - on.length,
      avgCPU: round(on.reduce((a, d) => a + d.CPU, 0) / on.length), avgMemory: round(on.reduce((a, d) => a + d.Memory, 0) / on.length),
      critical: on.filter((d) => d.Status === 'Critical').length, warning: on.filter((d) => d.Status === 'Warning').length,
    }, now);
  }

  function computeHistory(hours = 24, stepMin = 5, now = NOW()) {
    const out = {};
    const pts = Math.floor((hours * 60) / stepMin);
    for (const s of servers) {
      if (s.offline) { out[s.name] = []; continue; }
      const series = [];
      for (let k = pts; k >= 0; k--) {
        const t = now - k * stepMin * 60e3;
        series.push({ t, cpu: round(cpuAt(s, t)), mem: round(memAt(s, t)), iops: Math.round((s.roles.includes('SQL') ? 2600 : 300) * (0.6 + 0.5 * Math.sin(t / 5e6 + s.i))), net: Math.round(between(300, 6000)) });
      }
      out[s.name] = series;
    }
    return out;
  }

  function disks() {
    const rows = [];
    for (const s of servers) {
      if (s.offline) continue;
      const vols = [['C:', 'System', s.machineType === 'Physical' ? 446 : 120]];
      if (s.roles.includes('SQL')) vols.push(['D:', 'SQLData', 2048], ['L:', 'SQLLogs', 512], ['T:', 'TempDB', 256]);
      else if (s.roles.includes('FileServers')) vols.push(['E:', 'Shares', 8192]);
      else if (s.roles.includes('HyperV')) vols.push(['D:', 'Local VMs', 1788]);
      else if (s.name.startsWith('EXCH')) vols.push(['E:', 'Mailbox DB', 4096], ['F:', 'Logs', 1024]);
      else if (R() > 0.4) vols.push(['D:', 'Data', pick([200, 500, 1000])]);
      for (const [v, label, size] of vols) {
        let used = between(28, 78);
        if (s.name === 'FS02' && v === 'E:') used = 93.4;
        if (s.name === 'SQL02' && v === 'L:') used = 91.2;
        if (s.name === 'EXCH01' && v === 'F:') used = 86.5;
        if (s.name === 'APP04' && v === 'C:') used = 88.1;
        if (s.name === 'LOG01' && v === 'C:') used = 82.3;
        const free = round(size * (1 - used / 100));
        let st = statusOf(used, 80, 90);
        if (st !== 'OK' && free > 200) st = 'OK';
        if (free < 20 && st === 'OK') st = 'Warning';
        rows.push({ ComputerName: s.name, Volume: v, Label: label, SizeGB: size, FreeGB: free, UsedPct: round(used), Status: st });
      }
    }
    return env('servers.disks', rows, { volumes: rows.length, critical: rows.filter((r) => r.Status === 'Critical').length, warning: rows.filter((r) => r.Status === 'Warning').length });
  }

  function availability(now = NOW()) {
    const rows = servers.map((s) => ({
      Name: s.name, Status: s.offline ? 'Offline' : 'Online', LatencyMs: s.offline ? null : round(s.site === 'HQ-Main' ? between(0.3, 2) : between(8, 38)),
      Address: s.ip, Port5985: !s.offline, Port3389: !s.offline, Port445: !s.offline && !s.name.startsWith('WEB'),
      LastBoot: s.offline ? null : iso(now - (s.name === 'APP02' ? 110 : between(1, 40)) * D), UptimeDays: s.offline ? null : (s.name === 'APP02' ? 110.4 : round(between(1, 40), 2)),
    }));
    const on = rows.filter((r) => r.Status === 'Online');
    return env('servers.availability', rows, { total: rows.length, online: on.length, offline: rows.length - on.length, avgLatencyMs: round(on.reduce((a, r) => a + r.LatencyMs, 0) / on.length), longUptime: rows.filter((r) => r.UptimeDays > 60).length });
  }

  const ROLE_NAME = { DomainControllers: 'Active Directory Domain Services', DNS: 'DNS Server', DHCP: 'DHCP Server', FileServers: 'File Server', PrintServers: 'Print and Document Services', IIS: 'Web Server (IIS)', HyperV: 'Hyper-V', CertificateAuthority: 'Active Directory Certificate Services', DFS: 'DFS Namespaces', WSUS: 'Windows Server Update Services', NPS: 'Network Policy and Access Services', RDS: 'Remote Desktop Services', Clusters: 'Failover Clustering', SQL: 'SQL Server (application)' };
  function hardware() {
    const rows = servers.map((s) => s.offline ? { Name: s.name, Online: false, Error: 'Unreachable' } : ({
      Name: s.name, Domain: DOMAIN, ADSite: s.site, Manufacturer: s.manufacturer, Model: s.model, SerialNumber: s.machineType === 'Physical' ? 'CZ' + int(10000000, 99999999) : 'VMware-42 1c ' + int(1000, 9999),
      BIOSVersion: s.machineType === 'Physical' ? pick(['2.17.1', '2.19.0', 'U46 v2.84']) : 'Hyper-V UEFI 4.1', ChassisTypes: [s.machineType === 'Physical' ? 23 : 1],
      OperatingSystem: 'Microsoft ' + s.os, OSVersion: s.os.includes('2022') ? '10.0.20348' : s.os.includes('2019') ? '10.0.17763' : '10.0.14393',
      OSBuild: s.os.includes('2022') ? '20348' : s.os.includes('2019') ? '17763' : '14393', InstallDate: iso(NOW() - int(200, 1400) * D),
      LastBoot: iso(NOW() - between(1, 40) * D), UptimeDays: round(between(1, 40)), CPUModel: s.machineType === 'Physical' ? 'Intel(R) Xeon(R) Gold 6338 CPU @ 2.00GHz' : 'Intel(R) Xeon(R) Gold 6338 CPU @ 2.00GHz',
      CPUSockets: s.machineType === 'Physical' ? 2 : 1, CPUCores: s.cores, CPULogical: s.machineType === 'Physical' ? s.cores * 2 : s.cores, RAMGB: s.ram,
      DiskTotalGB: 0, DiskFreeGB: 0, IPAddress: [s.ip], MacAddress: ['00:15:5D:' + pad(int(0, 99)) + ':' + pad(int(10, 99)) + ':' + pad(s.i)],
      LoggedOnUser: R() > 0.8 ? 'CORP\\admin.' + pick(['marco', 'sara', 'omar']) : null, TPMPresent: s.machineType === 'Physical' || R() > 0.5, TPMEnabled: s.machineType === 'Physical',
      Online: true, MachineType: s.machineType, Chassis: s.machineType === 'Physical' ? 'Rack Mount Chassis' : 'Other', Roles: s.roles,
      LastLoggedOnUser: 'CORP\\' + ['admin.marco', 'admin.sara', 'admin.omar', 'svc.backup', 'h.fouad'][s.i % 5],
      InstalledRoles: s.roles.map((r) => ROLE_NAME[r] || r).concat(['File and Storage Services']).filter((x, i, a) => a.indexOf(x) === i),
      SqlServices: s.roles.includes('SQL') ? ['MSSQLSERVER=Running', 'SQLSERVERAGENT=' + (s.name === 'SQL03' ? 'Stopped' : 'Running')] : [],
      IISState: s.roles.includes('IIS') ? (s.name === 'WEB03' ? 'Stopped' : 'Running') : null,
    }));
    const on = rows.filter((r) => r.Online);
    const group = (k) => Object.entries(on.reduce((a, r) => ((a[r[k]] = (a[r[k]] || 0) + 1), a), {})).map(([name, count]) => ({ name, count }));
    return env('inventory.hardware', rows, { targets: rows.length, online: on.length, offline: rows.length - on.length, physical: on.filter((r) => r.MachineType === 'Physical').length, virtual: on.filter((r) => r.MachineType !== 'Physical').length, totalCores: on.reduce((a, r) => a + r.CPUCores, 0), totalRAMGB: on.reduce((a, r) => a + r.RAMGB, 0), byManufacturer: group('Manufacturer'), byOS: group('OperatingSystem') });
  }

  function roles() {
    const rows = servers.map((s) => ({ ComputerName: s.name, Roles: s.roles, Features: int(8, 40), Online: !s.offline }));
    const counts = {};
    rows.forEach((r) => r.Roles.forEach((x) => (counts[x] = (counts[x] || 0) + 1)));
    return env('inventory.roles', rows, { servers: rows.length, byRole: Object.entries(counts).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count) });
  }

  function services() {
    const rows = [];
    const problems = [['APP04', 'Spooler', 'Print Spooler'], ['SQL03', 'SQLSERVERAGENT', 'SQL Server Agent (MSSQLSERVER)'], ['WEB03', 'W3SVC', 'World Wide Web Publishing Service'], ['BKP01', 'VeeamBackupSvc', 'Veeam Backup Service']];
    for (const [c, n, d] of problems) rows.push({ ComputerName: c, Name: n, DisplayName: d, State: 'Stopped', StartMode: 'Auto', Account: 'LocalSystem', Problem: true });
    for (const s of servers.filter((x) => !x.offline)) {
      for (const [n, d] of [['WinRM', 'Windows Remote Management (WS-Management)'], ['EventLog', 'Windows Event Log'], ['W32Time', 'Windows Time'], ['MpsSvc', 'Windows Defender Firewall']]) {
        rows.push({ ComputerName: s.name, Name: n, DisplayName: d, State: 'Running', StartMode: 'Auto', Account: 'LocalSystem', Problem: false });
      }
    }
    return env('servers.services', rows, { services: rows.length, stoppedAuto: rows.filter((r) => r.Problem).length });
  }

  function iis() {
    const rows = [];
    for (const s of servers.filter((x) => x.roles.includes('IIS'))) {
      for (const p of ['DefaultAppPool', s.name === 'SCCM01' ? 'CCM Server Framework Pool' : 'Portal', s.name.startsWith('ERP') ? 'ERP-API' : 'Intranet', 'Reports']) {
        rows.push({ ComputerName: s.name, Pool: p, State: s.name === 'WEB03' && p !== 'DefaultAppPool' ? 'Stopped' : 'Started', Runtime: p === 'DefaultAppPool' ? 'v4.0' : pick(['v4.0', 'No Managed Code']), Identity: 'ApplicationPoolIdentity', Sites: p === 'DefaultAppPool' ? 'Default Web Site' : p, Bindings: '*:443:' + p.toLowerCase() + '.' + DOMAIN });
      }
    }
    return env('servers.iis', rows, { pools: rows.length, stopped: rows.filter((r) => r.State !== 'Started').length });
  }

  function activation() {
    const rows = servers.filter((s) => !s.offline).map((s) => ({ ComputerName: s.name, Product: 'Windows(R), ServerStandard edition', Channel: s.machineType === 'Physical' ? 'MAK' : 'KMS', Status: s.name === 'APP05' ? 'Notification' : 'Licensed', GraceMinutes: s.name === 'APP05' ? 0 : 259200 }));
    return env('servers.activation', rows, { licensed: rows.filter((r) => r.Status === 'Licensed').length, notLicensed: rows.filter((r) => r.Status !== 'Licensed').length });
  }

  // ------------------------------------------------------------------ AD
  const depts = ['Finance', 'Sales', 'Operations', 'IT', 'HR', 'Marketing', 'Logistics', 'Legal', 'Customer Care', 'Procurement'];
  const offices = ['HQ-Main', 'Branch-North', 'Branch-South', 'DR-Site', 'Remote'];
  const first = ['Ahmed', 'Sara', 'Omar', 'Mona', 'Youssef', 'Nour', 'Karim', 'Laila', 'Hassan', 'Dina', 'Tarek', 'Rana', 'Mostafa', 'Hana', 'Ali', 'Salma', 'Khaled', 'Yasmin', 'Adel', 'Farida'];
  const last = ['Hassan', 'Ibrahim', 'Mahmoud', 'Saleh', 'Fathy', 'Nabil', 'Samir', 'Fouad', 'Kamal', 'Zaki', 'Adel', 'Gamal', 'Lotfy', 'Rizk', 'Shawky'];
  function adUsers(now = NOW()) {
    const rows = [];
    for (let i = 0; i < 420; i++) {
      const f = pick(first), l = pick(last);
      const sam = (f[0] + '.' + l).toLowerCase() + (i > 150 ? i : '');
      const enabled = R() > 0.08;
      const lastLogon = now - (R() > 0.9 ? between(95, 400) : between(0, 20)) * D;
      rows.push({
        SamAccountName: sam, DisplayName: f + ' ' + l, Mail: sam + '@moncastle.example', Company: 'MonCastle Demo Co.', Department: pick(depts), Office: pick(offices), Title: pick(['Specialist', 'Senior Specialist', 'Team Lead', 'Manager', 'Analyst', 'Engineer']),
        Enabled: enabled, LockedOut: enabled && R() > 0.985, PasswordExpired: enabled && R() > 0.97, PasswordNeverExpires: R() > 0.93, PasswordAgeDays: int(1, 260),
        LastLogonDate: iso(lastLogon), Stale: enabled && now - lastLogon > 90 * D, Privileged: i < 9, AccountExpires: null, Created: iso(now - int(20, 2400) * D),
      });
    }
    rows[0].SamAccountName = 'j.adel'; rows[0].DisplayName = 'Jana Adel'; rows[0].LockedOut = true; rows[0].Enabled = true; rows[0].Privileged = false;
    // 4.7 fields: never logged on, account expiry, Kerberos and delegation flags, Protected Users, groups
    rows.forEach((r, i) => {
      r.NeverLoggedOn = i % 37 === 5; if (r.NeverLoggedOn) { r.LastLogonDate = null; r.Stale = false; }
      r.AccountExpires = i % 53 === 7 ? iso(now - int(3, 90) * D) : i % 61 === 3 ? iso(now + int(10, 200) * D) : null; r.AccountExpired = !!(r.AccountExpires && Date.parse(r.AccountExpires) < now);
      r.Changed = iso(now - int(0, 60) * D); r.OU = DOMAIN + '/Users/' + r.Office;
      r.AdminCount = r.Privileged ? 1 : i % 97 === 11 ? 1 : 0; r.PasswordNotRequired = i % 151 === 9; r.DoesNotRequirePreAuth = i % 173 === 4; r.UnconstrainedDelegation = false; r.ConstrainedDelegation = i % 199 === 2;
      r.SensitiveNoDelegation = r.Privileged && i % 2 === 0; r.SPNs = []; r.SmartcardRequired = false; r.ReversibleEncryption = i % 211 === 6; r.DESOnly = false; r.SIDHistory = 0; r.ProtectedUsers = r.Privileged && i < 4;
      r.Groups = ['Domain Users', 'GRP-' + r.Department.replace(/\s/g, '')];
    });
    const svc = [['administrator', 'Administrator', true, 0, ['Domain Admins', 'Enterprise Admins', 'Schema Admins']], ['admin.marco', 'Marco (admin)', true, 0, ['Domain Admins', 'Enterprise Admins']], ['admin.sara', 'Sara (admin)', true, 0, ['Domain Admins']], ['admin.omar', 'Omar (admin)', true, 1, ['DnsAdmins', 'GRP-ServerAdmins']], ['svc_backup', 'Backup service', true, 0, ['Domain Admins', 'Backup Operators']], ['svc_sql', 'SQL service', false, 1, ['GRP-SQL-Services']], ['svc_web', 'IIS app pool', false, 1, []], ['svc_legacyscan', 'Legacy scanner', false, 2, []], ['krbtgt', 'Key Distribution Center Service Account', false, 0, []]];
    svc.forEach(([sam, dn, priv, tier, groups], i) => rows.push({ SamAccountName: sam, DisplayName: dn, Mail: null, Company: 'MonCastle Demo Co.', Department: 'IT', Office: 'HQ', Title: /^svc/.test(sam) ? 'Service account' : 'Administrator', Enabled: sam !== 'krbtgt', LockedOut: false, PasswordExpired: false, PasswordNeverExpires: /^svc|administrator/.test(sam), PasswordAgeDays: sam === 'krbtgt' ? 412 : /^svc/.test(sam) ? 900 + i * 40 : 30 + i * 9, LastLogonDate: sam === 'krbtgt' ? null : iso(now - int(0, 5) * D), Stale: false, Privileged: priv, AccountExpires: null, AccountExpired: false, NeverLoggedOn: sam === 'krbtgt', Created: iso(now - (2400 - i * 50) * D), Changed: iso(now - int(0, 30) * D), OU: DOMAIN + (tier === 0 ? '/Admin/Tier 0' : tier === 1 ? '/Admin/Tier 1' : '/Service Accounts'), AdminCount: priv || sam === 'admin.omar' ? 1 : 0, PasswordNotRequired: false, DoesNotRequirePreAuth: sam === 'svc_legacyscan', UnconstrainedDelegation: sam === 'svc_web', ConstrainedDelegation: sam === 'svc_sql', SensitiveNoDelegation: sam === 'administrator', SPNs: sam === 'svc_sql' ? ['MSSQLSvc/sql01.' + DOMAIN + ':1433'] : sam === 'svc_backup' ? ['BackupSvc/bkp01.' + DOMAIN] : sam === 'svc_web' ? ['HTTP/portal.' + DOMAIN] : [], SmartcardRequired: false, ReversibleEncryption: false, DESOnly: false, SIDHistory: 0, ProtectedUsers: sam === 'administrator' || sam === 'admin.marco', Groups: ['Domain Users'].concat(groups) }));
    const total = 1236;
    const scale = (n) => Math.round((n * total) / rows.length);
    const count = (k) => Object.entries(rows.reduce((a, r) => ((a[r[k]] = (a[r[k]] || 0) + 1), a), {})).map(([name, c]) => ({ name, count: scale(c) })).sort((a, b) => b.count - a.count);
    return env('ad.users', rows, {
      total, enabled: scale(rows.filter((r) => r.Enabled).length), disabled: scale(rows.filter((r) => !r.Enabled).length), locked: rows.filter((r) => r.LockedOut).length,
      passwordNeverExpires: scale(rows.filter((r) => r.PasswordNeverExpires).length), stale: scale(rows.filter((r) => r.Stale).length), privileged: 14,
      byDepartment: count('Department'), byOffice: count('Office'), byCompany: [{ name: 'MonCastle Demo Co.', count: total }],
    });
  }

  const workstationOS = [['Windows 11 Enterprise', 0.62], ['Windows 10 Enterprise', 0.33], ['Windows 10 Pro', 0.04], ['Windows 7 Professional', 0.01]];
  const wsModels = [['Dell Inc.', 'Latitude 5440'], ['Dell Inc.', 'OptiPlex 7010'], ['HP', 'EliteBook 840 G9'], ['HP', 'EliteDesk 800 G6'], ['Lenovo', 'ThinkPad T14 Gen 3'], ['Lenovo', 'ThinkCentre M70q']];
  const workstations = [];
  for (let i = 1; i <= 186; i++) {
    let r = R(), os = workstationOS[0][0];
    for (const [o, w] of workstationOS) { if ((r -= w) <= 0) { os = o; break; } }
    const [man, model] = pick(wsModels);
    const site = pick(['HQ-Main', 'HQ-Main', 'HQ-Main', 'Branch-North', 'Branch-South']);
    workstations.push({ Name: 'WS-' + pad(i, 4), OperatingSystem: os, Manufacturer: man, Model: model, ADSite: site, IPAddress: [ip(site, 50 + (i % 4), i % 250 + 2)], Online: R() > 0.22, CPUCores: pick([4, 6, 8, 12]), RAMGB: pick([8, 16, 16, 32]), MachineType: 'Physical', LoggedOnUser: 'CORP\\' + (pick(first)[0] + '.' + pick(last)).toLowerCase(), LastSeen: iso(NOW() - between(0, 6) * D), TPMEnabled: R() > 0.07, UptimeDays: round(between(0.1, 30)) });
  }
  workstations[141].Name = 'WS-0142';

  function adComputers() {
    const rows = servers.map((s) => ({ Name: s.name, DNSHostName: s.fqdn, Enabled: true, OperatingSystem: s.os, OSVersion: '', Role: 'Server', IPv4Address: s.ip, LastLogonDate: iso(NOW() - between(0, 6) * D), Stale: false, OU: DOMAIN + '/Servers/' + s.site }))
      .concat(workstations.map((w) => ({ Name: w.Name, DNSHostName: (w.Name + '.' + DOMAIN).toLowerCase(), Enabled: true, OperatingSystem: w.OperatingSystem, OSVersion: '', Role: 'Workstation', IPv4Address: w.IPAddress[0], LastLogonDate: w.LastSeen, Stale: R() > 0.93, OU: DOMAIN + '/Workstations/' + w.ADSite })));
    const byOS = Object.entries(rows.reduce((a, r) => ((a[r.OperatingSystem] = (a[r.OperatingSystem] || 0) + 1), a), {})).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count);
    rows.forEach((r, i) => { r.NeverLoggedOn = false; r.PasswordAgeDays = r.Stale ? int(95, 400) : int(1, 29); r.DomainController = /^DC0/.test(r.Name); r.UnconstrainedDelegation = ['APP03', 'SQL02'].includes(r.Name); r.ConstrainedDelegation = r.Name === 'WEB01'; r.LAPS = r.Role === 'Workstation' ? i % 9 !== 0 : !/^DC/.test(r.Name); r.Created = iso(NOW() - int(30, 2000) * D); });
    rows.push({ Name: 'WS-NEW-0201', DNSHostName: 'ws-new-0201.' + DOMAIN, Enabled: true, OperatingSystem: 'Windows 11 Enterprise', OSVersion: '', Role: 'Workstation', IPv4Address: null, LastLogonDate: null, Stale: false, OU: DOMAIN + '/Workstations/Staging', NeverLoggedOn: true, PasswordAgeDays: 12, DomainController: false, UnconstrainedDelegation: false, ConstrainedDelegation: false, LAPS: false, Created: iso(NOW() - 12 * D) });
    rows.push({ Name: 'WS-OLD-0007', DNSHostName: 'ws-old-0007.' + DOMAIN, Enabled: false, OperatingSystem: 'Windows 7 Professional', OSVersion: '', Role: 'Workstation', IPv4Address: null, LastLogonDate: iso(NOW() - 610 * D), Stale: true, OU: DOMAIN + '/Disabled', NeverLoggedOn: false, PasswordAgeDays: 640, DomainController: false, UnconstrainedDelegation: false, ConstrainedDelegation: false, LAPS: false, Created: iso(NOW() - 2900 * D) });
    return env('ad.computers', rows, { total: rows.length, enabled: rows.length, servers: servers.length, workstations: workstations.length, stale: rows.filter((r) => r.Stale).length, byOS });
  }

  function adGroups() {
    const rows = [];
    const priv = { 'Domain Admins': ['administrator', 'admin.marco', 'admin.sara', 'svc_backup'], 'Enterprise Admins': ['administrator', 'admin.marco'], 'Schema Admins': ['administrator'], 'Backup Operators': ['svc_backup'], 'DnsAdmins': ['admin.omar'] };
    for (const [g, m] of Object.entries(priv)) m.forEach((u) => rows.push({ Group: g, Scope: 'Global', Category: 'Security', Privileged: true, Member: u, MemberType: 'user' }));
    for (const d of depts) for (let i = 0; i < 6; i++) rows.push({ Group: 'GRP-' + d.replace(/\s/g, ''), Scope: 'Global', Category: 'Security', Privileged: false, Member: (pick(first)[0] + '.' + pick(last)).toLowerCase(), MemberType: 'user' });
    rows.push({ Group: 'GRP-Legacy-VPN', Scope: 'Global', Category: 'Security', Privileged: false, Member: null, MemberType: null });
    for (const g of ['GRP-Old-Project-Atlas', 'GRP-Temp-Contractors', 'DL-Marketing-2019']) rows.push({ Group: g, Scope: g.startsWith('DL') ? 'DomainLocal' : 'Global', Category: g.startsWith('DL') ? 'Distribution' : 'Security', Privileged: false, Member: null, MemberType: null });
    rows.push({ Group: 'Administrators', Scope: 'DomainLocal', Category: 'Security', Privileged: true, Member: 'Domain Admins', MemberType: 'group' }, { Group: 'Administrators', Scope: 'DomainLocal', Category: 'Security', Privileged: true, Member: 'APP03$', MemberType: 'computer' });
    rows.push({ Group: 'GRP-ServerAdmins', Scope: 'Global', Category: 'Security', Privileged: false, Member: 'admin.omar', MemberType: 'user' }, { Group: 'GRP-ServerAdmins', Scope: 'Global', Category: 'Security', Privileged: false, Member: 'GRP-Helpdesk', MemberType: 'group' }, { Group: 'GRP-Helpdesk', Scope: 'Global', Category: 'Security', Privileged: false, Member: 'h.fouad', MemberType: 'user' }, { Group: 'GRP-Helpdesk', Scope: 'Global', Category: 'Security', Privileged: false, Member: 'k.samir', MemberType: 'user' });
    rows.push({ Group: 'Protected Users', Scope: 'Global', Category: 'Security', Privileged: false, Member: 'administrator', MemberType: 'user' }, { Group: 'Protected Users', Scope: 'Global', Category: 'Security', Privileged: false, Member: 'admin.marco', MemberType: 'user' });
    return env('ad.groups', rows, { groups: 312, emptyGroups: 27, privilegedMembers: 6 });
  }

  function adDeleted(now = NOW()) {
    const rows = [];
    const ppl = ['m.hassan', 'n.ibrahim', 'o.saleh', 'r.mostafa', 'y.kamal', 's.nabil', 't.gamal', 'contractor.ali', 'temp.reception', 'svc_oldftp'];
    ppl.forEach((u, i) => rows.push({ Name: u, SamAccountName: u, DisplayName: u.replace('.', ' '), Type: 'User', Deleted: iso(now - (i * 11 + int(0, 9)) * D), Created: iso(now - int(300, 1800) * D), LastKnownOU: 'OU=' + pick(offices) + ',OU=Users,DC=corp,DC=moncastle,DC=local', OperatingSystem: null, Sid: 'S-1-5-21-3623811015-3361044348-30300820-' + (1400 + i), Restorable: true }));
    ['WS-0019', 'WS-0077', 'WS-0123', 'APP-OLD01', 'PRN-OLD'].forEach((c, i) => rows.push({ Name: c, SamAccountName: c + '$', DisplayName: null, Type: 'Computer', Deleted: iso(now - (i * 17 + 3) * D), Created: iso(now - int(900, 3000) * D), LastKnownOU: c.startsWith('WS') ? 'OU=Workstations,DC=corp,DC=moncastle,DC=local' : 'OU=Servers,DC=corp,DC=moncastle,DC=local', OperatingSystem: c.startsWith('WS') ? 'Windows 10 Enterprise' : 'Windows Server 2012 R2', Sid: 'S-1-5-21-3623811015-3361044348-30300820-' + (2400 + i), Restorable: true }));
    rows.push({ Name: 'GRP-Project-Nile', SamAccountName: 'GRP-Project-Nile', DisplayName: null, Type: 'Group', Deleted: iso(now - 40 * D), Created: iso(now - 700 * D), LastKnownOU: 'OU=Groups,DC=corp,DC=moncastle,DC=local', OperatingSystem: null, Sid: 'S-1-5-21-3623811015-3361044348-30300820-3101', Restorable: true });
    rows.sort((a, b) => (a.Deleted < b.Deleted ? 1 : -1));
    return env('ad.deleted', rows, { recycleBin: true, days: 180, users: rows.filter((r) => r.Type === 'User').length, computers: rows.filter((r) => r.Type === 'Computer').length, groups: 1 });
  }
  function adSecurity() {
    const rows = [];
    const F = (Category, Check, Object, ObjectType, Tier, Severity, Evidence, Fix) => rows.push({ Category, Check, Object, ObjectType, Tier, Severity, Evidence, Fix });
    for (const [u, g] of [['administrator', 'Domain Admins, Enterprise Admins, Schema Admins'], ['admin.marco', 'Domain Admins, Enterprise Admins'], ['admin.sara', 'Domain Admins'], ['svc_backup', 'Domain Admins, Backup Operators'], ['admin.omar', 'DnsAdmins']]) F('Tiering', 'Tier 0 account', u, 'User', 0, 'Info', 'Member of ' + g, '');
    for (const s of servers.filter((x) => x.roles.includes('DomainControllers') || x.roles.includes('CertificateAuthority'))) F('Tiering', 'Tier 0 server', s.name, 'Computer', 0, 'Info', s.roles.includes('DomainControllers') ? 'Domain controller' : 'Certificate Authority', '');
    F('Tiering', 'Tier 0 account not in Protected Users', 'admin.sara', 'User', 0, 'High', 'Credentials can be cached on lower-tier machines', 'Add the account to Protected Users (test service accounts first).');
    F('Tiering', 'Tier 0 account not in Protected Users', 'svc_backup', 'User', 0, 'High', 'Credentials can be cached on lower-tier machines', 'Use a gMSA for the backup service, then add it to Protected Users.');
    F('Tiering', 'Tier 0 account can be delegated', 'admin.marco', 'User', 0, 'Medium', '"Account is sensitive and cannot be delegated" is off', 'Turn on "Account is sensitive and cannot be delegated".');
    F('Tiering', 'Computer in a Tier 0 group', 'APP03', 'Computer', 1, 'High', 'Member of Administrators', 'Remove it; only Tier 0 servers belong in Tier 0 groups.');
    F('Passwords', 'Tier 0 password never expires', 'svc_backup', 'User', 0, 'Medium', 'Password age 900 days', 'Rotate it and let it expire, or use a managed service account.');
    F('Kerberos', 'Kerberoastable account (SPN)', 'svc_backup', 'User', 0, 'Critical', 'BackupSvc/bkp01.' + DOMAIN, 'Use a gMSA, or a 25+ character password with AES only.');
    F('Kerberos', 'Kerberoastable account (SPN)', 'svc_sql', 'User', 1, 'High', 'MSSQLSvc/sql01.' + DOMAIN + ':1433', 'Use a gMSA, or a 25+ character password with AES only.');
    F('Kerberos', 'Kerberoastable account (SPN)', 'svc_web', 'User', 1, 'High', 'HTTP/portal.' + DOMAIN, 'Use a gMSA, or a 25+ character password with AES only.');
    F('Kerberos', 'AS-REP roastable (no pre-authentication)', 'svc_legacyscan', 'User', 2, 'High', 'Kerberos pre-authentication is not required', 'Require Kerberos pre-authentication.');
    F('Kerberos', 'Unconstrained delegation (user)', 'svc_web', 'User', 1, 'Critical', 'TrustedForDelegation', 'Remove unconstrained delegation; use constrained or resource-based delegation.');
    F('Kerberos', 'Constrained delegation with protocol transition', 'svc_sql', 'User', 1, 'Medium', 'TrustedToAuthForDelegation', 'Check the services it may delegate to.');
    F('Kerberos', 'Unconstrained delegation (computer)', 'APP03', 'Computer', 1, 'Critical', 'TrustedForDelegation', 'Remove unconstrained delegation; a coerced DC authentication on this host gives domain takeover.');
    F('Kerberos', 'Unconstrained delegation (computer)', 'SQL02', 'Computer', 1, 'Critical', 'TrustedForDelegation', 'Remove unconstrained delegation; a coerced DC authentication on this host gives domain takeover.');
    F('Kerberos', 'krbtgt password age', 'krbtgt', 'User', 0, 'High', '412 days since the last reset', 'Reset the krbtgt password twice, 10 hours apart, at least every 180 days.');
    F('Privilege', 'adminCount orphan', 'h.fouad', 'User', 2, 'Low', 'adminCount=1 but no longer in a protected group; inheritance stays blocked', 'Clear adminCount and re-enable permission inheritance.');
    F('Passwords', 'Password not required', 'temp.kiosk', 'User', 2, 'High', 'PASSWD_NOTREQD flag', 'Clear the flag: Set-ADUser -PasswordNotRequired $false.');
    const sev = rows.filter((r) => r.Severity !== 'Info');
    return env('ad.security', rows, { domain: DOMAIN, tier0Accounts: 5, findings: sev.length, critical: sev.filter((r) => r.Severity === 'Critical').length, krbtgtAgeDays: 412 });
  }

  function adHealth() {
    const fsmo = { PDCEmulator: 'dc01.' + DOMAIN, RIDMaster: 'dc01.' + DOMAIN, InfrastructureMaster: 'dc02.' + DOMAIN, SchemaMaster: 'dc01.' + DOMAIN, DomainNamingMaster: 'dc01.' + DOMAIN };
    const rows = servers.filter((s) => s.roles.includes('DomainControllers')).map((s) => {
      const down = s.name === 'DC04' ? ['DFSR'] : [];
      const services = Object.fromEntries(['NTDS', 'DNS', 'DFSR', 'Netlogon', 'KDC', 'IsmServ', 'W32Time', 'ADWS'].map((x) => [x, down.includes(x) ? 'Stopped' : 'Running']));
      const problems = down.length ? ['Services down: ' + down.join(', ')] : [];
      const offset = s.name === 'DC04' ? 2.4 : round(between(-0.05, 0.05), 3);
      return { Name: s.name, HostName: s.fqdn, Site: s.site, IPv4: s.ip, OS: s.os, GlobalCatalog: s.name !== 'DC04', ReadOnly: false, Online: true, FSMO: Object.keys(fsmo).filter((k) => fsmo[k] === s.fqdn), Services: services, ServicesDown: down, Sysvol: true, Netlogon: true, DnsOK: true, TimeOffsetSec: offset, Problems: problems, Status: problems.length ? 'Warning' : 'OK' };
    });
    return env('ad.health', rows, { domain: DOMAIN, forestMode: 'Windows2016Forest', domainMode: 'Windows2016Domain', dcs: rows.length, healthy: rows.filter((r) => r.Status === 'OK').length, sites: 3, fsmo });
  }

  function adReplication(now = NOW()) {
    const dcs = ['DC01', 'DC02', 'DC03', 'DC04'];
    const rows = [];
    for (const s of dcs) for (const p of dcs) {
      if (s === p) continue;
      for (const part of ['DC=corp,DC=moncastle,DC=local', 'CN=Configuration,DC=corp,DC=moncastle,DC=local']) {
        const failing = s === 'DC04' && p === 'DC03';
        const age = failing ? 412 : int(1, 14);
        rows.push({ Server: s, Partner: p, Partition: part, LastSuccess: iso(now - age * 60e3), MinutesSinceSuccess: age, LastResult: failing ? 1722 : 0, ConsecutiveFailures: failing ? 27 : 0, FailureFirstSeen: failing ? iso(now - 7 * H) : null, Status: failing ? 'Critical' : 'OK' });
      }
    }
    return env('ad.replication', rows, { links: rows.length, failing: rows.filter((r) => r.Status === 'Critical').length, maxLagMinutes: Math.max(...rows.map((r) => r.MinutesSinceSuccess)), forced: false });
  }

  // ------------------------------------------------------------------ network
  function dhcp() {
    const scopes = [['DC01', '10.10.50.0', 'HQ Users Floor 1', 254, 231], ['DC01', '10.10.51.0', 'HQ Users Floor 2', 254, 188], ['DC01', '10.10.60.0', 'HQ VoIP', 254, 142], ['DC01', '10.10.70.0', 'HQ Wi-Fi Corp', 510, 489], ['DC01', '10.10.71.0', 'HQ Wi-Fi Guest', 254, 97],
      ['DC03', '10.20.50.0', 'DR Users', 254, 33], ['DC03', '10.30.50.0', 'North Users', 254, 176], ['DC03', '10.30.60.0', 'North VoIP', 126, 61], ['DC03', '10.40.50.0', 'South Users', 254, 205], ['DC03', '10.40.70.0', 'South Wi-Fi', 254, 248]];
    const rows = scopes.map(([srv, id, name, size, used]) => {
      const pct = round((used / size) * 100);
      return { Server: srv, ScopeId: id, Name: name, State: 'Active', SubnetMask: size > 254 ? '255.255.254.0' : size < 200 ? '255.255.255.128' : '255.255.255.0', Range: id.replace(/0$/, '10') + ' - ' + id.replace(/0$/, size > 254 ? '254' : '250'), LeaseDuration: '8.00:00:00', InUse: used, Free: size - used, PercentInUse: pct, Failover: srv === 'DC01' ? 'LoadBalance / Normal / dc03.' + DOMAIN : null, Status: statusOf(pct, 80, 95) };
    });
    return env('network.dhcp', rows, { servers: 2, scopes: rows.length, critical: rows.filter((r) => r.Status === 'Critical').length, warning: rows.filter((r) => r.Status === 'Warning').length, addressesInUse: rows.reduce((a, r) => a + r.InUse, 0), addressesFree: rows.reduce((a, r) => a + r.Free, 0) });
  }

  const netDevices = [];
  (function () {
    const add = (site, cls, name, host, ports) => netDevices.push({ Subnet: SUBNETS[site] + '0.0/16', IPAddress: SUBNETS[site] + host, HostName: name ? (name + '.' + DOMAIN).toLowerCase() : null, LatencyMs: round(site === 'HQ-Main' ? between(0.4, 3) : between(9, 40)), MAC: ['00:1B:54', 'F4:CF:E2', '00:50:56', '3C:52:82'][netDevices.length % 4] + ':' + pad(int(10, 99)) + ':' + pad(int(10, 99)) + ':' + pad(netDevices.length % 99), OpenPorts: ports, DeviceClass: cls, Ttl: cls === 'Network device' ? 255 : cls.startsWith('Linux') ? 64 : 128, Site: site, SysDescr: /^CORE-SW/.test(name || '') ? 'Cisco IOS Software, Catalyst L3 Switch Software (CAT9K_IOSXE), Version 17.9.4a' : /^ACC-SW/.test(name || '') ? 'HPE Aruba AOS-CX 10.13 JL659A 6300M' : null });
    for (const site of SITES) {
      const t = site.split('-')[0].slice(0, 2).toUpperCase();
      add(site, 'Network device', 'CORE-SW-' + t + '01', '0.1', [22, 161, 443]);
      add(site, 'Network device', 'FW-' + t + '01', '0.254', [22, 443]);
      for (let i = 1; i <= (site === 'HQ-Main' ? 8 : 3); i++) add(site, 'Network device', 'ACC-SW-' + t + pad(i), '0.' + (10 + i), [22, 23, 161]);
      for (let i = 1; i <= (site === 'HQ-Main' ? 10 : 4); i++) add(site, 'Network device', 'AP-' + t + pad(i), '5.' + (20 + i), [22, 80, 443]);
      for (let i = 1; i <= 3; i++) add(site, 'Appliance / Web', site === 'HQ-Main' && i === 1 ? 'SAN-CTRL-A' : null, '8.' + (30 + i), [80, 443]);
    }
    add('HQ-Main', 'Unknown', null, '50.77', []);
    add('Branch-South', 'Unknown', null, '50.199', [8080]);
    add('HQ-Main', 'Network device', 'IPPBX01', '60.5', [22, 80, 443, 5060]);
  })();

  // ------------------------------------------------------------------ printers
  const printerModels = ['HP LaserJet Enterprise M608', 'HP Color LaserJet Enterprise M555', 'Kyocera TASKalfa 3554ci', 'Ricoh IM C3000', 'Canon iR-ADV C5535', 'Brother HL-L6400DW'];
  const printerRows = [];
  for (let i = 1; i <= 24; i++) {
    const srv = i <= 16 ? 'PRN01' : 'PRN02';
    const site = srv === 'PRN01' ? (i % 5 === 0 ? 'Branch-South' : 'HQ-Main') : 'Branch-North';
    const model = pick(printerModels);
    const status = i === 7 ? 'Offline' : i === 12 ? 'Error' : i === 19 ? 'TonerLow' : i === 3 ? 'PaperJam' : 'Normal';
    printerRows.push({ PrintServer: srv, Name: 'PRT-' + site.split('-')[0].slice(0, 2).toUpperCase() + '-' + pad(i, 3), ShareName: 'PRT' + pad(i, 3), Shared: true, Published: i % 3 !== 0, Driver: model.replace(/ (Enterprise|TASKalfa|IM|iR-ADV)/, ''), Port: 'IP_' + SUBNETS[site] + '9.' + (10 + i), IPAddress: SUBNETS[site] + '9.' + (10 + i), Location: site + ' / Floor ' + int(1, 5), Status: status, Type: 'Local', JobCount: status === 'Error' ? 14 : int(0, 3), Model: model });
  }
  function printersInv() {
    const g = (k) => Object.entries(printerRows.reduce((a, r) => ((a[r[k]] = (a[r[k]] || 0) + 1), a), {})).map(([name, count]) => ({ name, count }));
    return env('inventory.printers', printerRows, { printServers: 2, printers: printerRows.length, byStatus: g('Status'), byLocation: g('Location'), byDriver: g('Driver') });
  }
  function printersHealth() {
    const rows = printerRows.map((p) => ({ PrintServer: p.PrintServer, Printer: p.Name, Status: p.Status, Location: p.Location, IPAddress: p.IPAddress, Reachable: p.Status !== 'Offline', Jobs: p.JobCount, StuckJobs: p.Status === 'Error' ? 9 : 0, Shared: true, Health: ['Offline', 'Error'].includes(p.Status) ? 'Critical' : ['TonerLow', 'PaperJam'].includes(p.Status) ? 'Warning' : 'OK' }));
    return env('printers.health', rows, { printers: rows.length, critical: rows.filter((r) => r.Health === 'Critical').length, warning: rows.filter((r) => r.Health === 'Warning').length, queuedJobs: rows.reduce((a, r) => a + r.Jobs, 0) });
  }

  // ------------------------------------------------------------------ virtualization
  const hvVMs = [];
  (function () {
    const hvHosted = servers.filter((s) => s.machineType === 'Virtual (Hyper-V)');
    const extras = ['TEST-APP01', 'TEST-APP02', 'DEV-SQL01', 'DEV-WEB01', 'JUMP01', 'JUMP02', 'K8S-NODE04', 'TEMPLATE-2022', 'LAB-DC01', 'OLD-ERP'];
    const names = hvHosted.map((s) => s.name).concat(extras);
    names.forEach((n, i) => {
      const s = byName[n];
      const host = s && s.site === 'DR-Site' ? 'HV04' : ['HV01', 'HV02', 'HV03'][i % 3];
      const state = n === 'TEMPLATE-2022' || n === 'OLD-ERP' || n === 'LAB-DC01' ? 'Off' : 'Running';
      const vcpu = s ? s.cores : pick([2, 4]);
      const mem = s ? s.ram : pick([4, 8]);
      const ckDays = n === 'OLD-ERP' ? 214 : n === 'DEV-SQL01' ? 38 : n === 'SQL01' ? 9 : null;
      hvVMs.push({ Kind: 'VM', Name: n, Host: host, State: state, Status: 'Operating normally', Generation: n.startsWith('OLD') ? 1 : 2, Version: '10.0', vCPU: vcpu, CPUUsage: state === 'Running' ? int(2, s && hot[n] ? 80 : 35) : 0, MemoryAssignedGB: state === 'Running' ? mem : 0, MemoryStartupGB: mem, MemoryMaxGB: mem, DynamicMemory: R() > 0.6, MemoryStatus: '', UptimeHours: state === 'Running' ? round(between(20, 900)) : 0, Heartbeat: state === 'Running' ? 'OkApplicationsHealthy' : '', IPAddresses: s ? [s.ip] : [], Switch: 'vSwitch-Prod', Disks: [{ Path: 'C:\\ClusterStorage\\Volume' + (1 + (i % 4)) + '\\' + n + '\\' + n + '.vhdx', Type: 'Dynamic', SizeGB: 127, FileGB: round(between(30, 120)) }], DiskProvisionedGB: 127 + (s && s.roles.includes('SQL') ? 2048 : 0), DiskUsedGB: round(between(40, 900)), Checkpoints: ckDays ? int(1, 4) : 0, OldestCheckpointDays: ckDays, CheckpointWarning: !!(ckDays && ckDays > 7), Replication: host === 'HV04' ? 'Normal' : 'NotApplicable', IsClustered: host !== 'HV04', Path: 'C:\\ClusterStorage\\Volume' + (1 + (i % 4)) });
    });
  })();
  function hyperv() {
    const hosts = ['HV01', 'HV02', 'HV03', 'HV04'].map((h) => {
      const s = byName[h], vms = hvVMs.filter((v) => v.Host === h);
      return { Kind: 'Host', Name: h, LogicalCPUs: s.cores * 2, MemoryGB: s.ram, MemoryFreeGB: round(s.ram - vms.reduce((a, v) => a + v.MemoryAssignedGB, 0) - 8), Clustered: h !== 'HV04', VMCount: vms.length, VMRunning: vms.filter((v) => v.State === 'Running').length, vCPUAssigned: vms.reduce((a, v) => a + v.vCPU, 0), MemoryAssignedGB: vms.reduce((a, v) => a + v.MemoryAssignedGB, 0) };
    });
    const lc = hosts.reduce((a, h) => a + h.LogicalCPUs, 0), vc = hosts.reduce((a, h) => a + h.vCPUAssigned, 0);
    return env('virtualization.hyperv', hosts.concat(hvVMs), { hosts: hosts.length, vms: hvVMs.length, running: hvVMs.filter((v) => v.State === 'Running').length, off: hvVMs.filter((v) => v.State === 'Off').length, oldCheckpoints: hvVMs.filter((v) => v.CheckpointWarning).length, vCPUPerCore: round(vc / lc, 2) });
  }

  function vmware(now = NOW()) {
    const rows = [];
    const esx = ['esx01', 'esx02', 'esx03', 'esx04'].map((n, i) => ({ Kind: 'ESXi', VCenter: 'vc01.' + DOMAIN, Name: n + '.' + DOMAIN, Cluster: 'PROD-Cluster', State: 'Connected', Power: 'PoweredOn', Model: 'Dell Inc. PowerEdge R650', Version: '8.0.2 (22380479)', CPUs: 48, CPUGHz: 134.4, CPUUsedPct: round([46, 58, 71, 39][i]), MemoryGB: 768, MemoryUsedPct: round([62, 74, 83, 55][i]), VMs: 0 }));
    rows.push(...esx);
    const ds = [['DS-PROD-01', 8192, 91.6], ['DS-PROD-02', 8192, 77.1], ['DS-PROD-03', 4096, 64.0], ['DS-SQL-01', 4096, 83.4], ['DS-BACKUP', 16384, 58.2], ['DS-ISO', 1024, 41.0]];
    ds.forEach(([n, cap, used]) => rows.push({ Kind: 'Datastore', VCenter: 'vc01.' + DOMAIN, Name: n, Type: 'VMFS', State: 'Available', CapacityGB: cap, FreeGB: Math.round(cap * (1 - used / 100)), UsedPct: used, Status: statusOf(used, 80, 90) }));
    const vmNames = Array.from(vmwareHosted).concat(['VDI-GOLD', 'CITRIX-SF01', 'CITRIX-DDC01', 'PROXY01', 'MAIL-GW01', 'SIEM01', 'NMS01', 'TEST-VM07']);
    vmNames.forEach((n, i) => {
      const s = byName[n];
      const host = esx[i % 4].Name;
      esx[i % 4].VMs++;
      rows.push({ Kind: 'VM', VCenter: 'vc01.' + DOMAIN, Name: n, Host: host, Power: n === 'TEST-VM07' || n === 'VDI-GOLD' ? 'PoweredOff' : 'PoweredOn', vCPU: s ? s.cores : pick([2, 4, 8]), MemoryGB: s ? s.ram : pick([4, 8, 16]), UsedSpaceGB: int(60, 900), ProvisionedGB: int(100, 1200), GuestOS: s ? 'Microsoft ' + s.os : pick(['Microsoft Windows Server 2022 (64-bit)', 'Ubuntu Linux (64-bit)', 'Red Hat Enterprise Linux 9 (64-bit)']), IPAddress: s ? [s.ip] : ['10.10.4.' + (60 + i)], DnsName: (n + '.' + DOMAIN).toLowerCase(), ToolsStatus: n === 'PROXY01' ? 'toolsOld' : n === 'NMS01' ? 'toolsNotRunning' : 'toolsOk', HardwareVersion: 'vmx-' + pick([19, 20, 21]), OldestSnapshotDays: n === 'SIEM01' ? 46 : n === 'ERP01' ? 3 : null, Notes: '' });
    });
    for (const e of esx) {
      for (let k = 84; k >= 0; k--) {
        const t = now - k * 2 * H;
        const hour = new Date(t).getHours();
        const b = Math.max(0, Math.sin(((hour - 7) / 12) * Math.PI));
        rows.push({ Kind: 'History', VCenter: e.VCenter, Name: e.Name, Time: iso(t), CPU: round(e.CPUUsedPct * (0.6 + 0.5 * b) + (R() - 0.5) * 6), Memory: round(e.MemoryUsedPct + (R() - 0.5) * 3), DiskKBps: int(20000, 90000) });
      }
    }
    const vms = rows.filter((r) => r.Kind === 'VM');
    return env('virtualization.vmware', rows, { vcenters: 1, hosts: 4, vms: vms.length, poweredOn: vms.filter((v) => v.Power === 'PoweredOn').length, datastores: ds.length, toolsIssues: vms.filter((v) => v.Power === 'PoweredOn' && v.ToolsStatus !== 'toolsOk').length });
  }

  function clusters() {
    const rows = [
      { Cluster: 'HVCL01', Domain: DOMAIN, QuorumType: 'NodeAndFileShareMajority', QuorumResource: 'File Share Witness', Nodes: ['HV01', 'HV02', 'HV03'].map((n, i) => ({ Name: n, State: 'Up', Id: i + 1 })), NodesUp: 3, Roles: hvVMs.filter((v) => v.IsClustered).slice(0, 8).map((v) => ({ Name: v.Name, State: v.State === 'Running' ? 'Online' : 'Offline', Owner: v.Host, Type: 'VirtualMachine' })), Networks: [{ Name: 'Management', State: 'Up', Role: 'ClusterAndClient', Address: '10.10.1.0/24' }, { Name: 'LiveMigration', State: 'Up', Role: 'Cluster', Address: '172.16.10.0/24' }, { Name: 'Storage', State: 'Up', Role: 'None', Address: '172.16.20.0/24' }], S2D: null, Problems: ['Role OLD-ERP Offline'], Status: 'Warning' },
      { Cluster: 'SQLCL01', Domain: DOMAIN, QuorumType: 'NodeAndDiskMajority', QuorumResource: 'Cluster Disk Witness', Nodes: [{ Name: 'SQL04', State: 'Up', Id: 1 }, { Name: 'SQL05', State: 'Up', Id: 2 }], NodesUp: 2, Roles: [{ Name: 'SQL Server (MSSQLSERVER)', State: 'Online', Owner: 'SQL04', Type: 'GenericService' }], Networks: [{ Name: 'Public', State: 'Up', Role: 'ClusterAndClient', Address: '10.10.2.0/24' }, { Name: 'Heartbeat', State: 'Up', Role: 'Cluster', Address: '172.16.30.0/24' }], S2D: null, Problems: [], Status: 'OK' },
    ];
    return env('virtualization.clusters', rows, { clusters: 2, healthy: 1 });
  }
  function clusterStorage() {
    const vols = [['HVCL01', 'Cluster Disk 1', 'C:\\ClusterStorage\\Volume1', 'HV01', 4096, 71.2], ['HVCL01', 'Cluster Disk 2', 'C:\\ClusterStorage\\Volume2', 'HV02', 4096, 84.9], ['HVCL01', 'Cluster Disk 3', 'C:\\ClusterStorage\\Volume3', 'HV03', 4096, 55.6], ['HVCL01', 'Cluster Disk 4', 'C:\\ClusterStorage\\Volume4', 'HV01', 2048, 92.3], ['SQLCL01', 'SQL Data', 'S:\\', 'SQL04', 3072, 68.0], ['SQLCL01', 'SQL Logs', 'L:\\', 'SQL04', 1024, 47.5]];
    const rows = vols.map(([c, n, p, o, size, used]) => ({ Cluster: c, Name: n, Type: p.startsWith('C:\\ClusterStorage') ? 'CSV' : 'Disk', Path: p, Owner: o, State: 'Online', SizeGB: size, FreeGB: Math.round(size * (1 - used / 100)), UsedPct: used, Redirected: false, Maintenance: false, Status: statusOf(used, 80, 90) }));
    return env('virtualization.clusterstorage', rows, { volumes: rows.length, critical: rows.filter((r) => r.Status === 'Critical').length, totalTB: round(rows.reduce((a, r) => a + r.SizeGB, 0) / 1024), freeTB: round(rows.reduce((a, r) => a + r.FreeGB, 0) / 1024) });
  }

  // ------------------------------------------------------------------ SQL
  function sqlDatabases(now = NOW()) {
    const rows = [];
    const inst = ['SQL01', 'SQL02', 'SQL03', 'SQLCL01'];
    const dbs = { SQL01: ['ERP_Prod', 'ERP_Staging', 'Payroll', 'HRMS'], SQL02: ['CRM_Prod', 'Reporting', 'DWH', 'SSISDB'], SQL03: ['ERP_DR', 'CRM_DR'], SQLCL01: ['SharePoint_Content', 'SharePoint_Config', 'Intranet', 'Ticketing', 'MonCastle_Archive'] };
    for (const i of inst) {
      for (const d of ['master', 'model', 'msdb'].concat(dbs[i])) {
        const sys = ['master', 'model', 'msdb'].includes(d);
        const full = d === 'DWH' ? 76 : d === 'Ticketing' ? null : between(2, 20);
        const rec = sys || d === 'DWH' || d.endsWith('_DR') ? 'Simple' : 'Full';
        const log = rec === 'Full' ? (d === 'CRM_Prod' ? 9.5 : between(0.1, 1)) : null;
        const problems = [];
        if (full === null || full > 26) problems.push('Full backup overdue');
        if (rec === 'Full' && d !== 'model' && (log === null || log > 2)) problems.push('Log backup overdue');
        rows.push({ Instance: i, Database: d, Status: 'Normal', RecoveryModel: rec, SizeMB: sys ? int(20, 900) : int(4000, d === 'DWH' ? 820000 : 240000), Owner: 'sa', Compatibility: 'Version150', LastFullBackup: full === null ? null : iso(now - full * H), FullBackupAgeHours: full === null ? null : round(full), LastLogBackup: log === null ? null : iso(now - log * H), LogBackupAgeHours: log === null ? null : round(log), AvailabilityGroup: null, Problems: problems, Health: problems.length ? 'Warning' : 'OK' });
      }
    }
    return env('sql.databases', rows, { instances: inst.length, databases: rows.length, totalGB: round(rows.reduce((a, r) => a + r.SizeMB, 0) / 1024), backupIssues: rows.filter((r) => r.Problems.length).length });
  }

  // ------------------------------------------------------------------ Linux
  const linuxDefs = [['LNX-WEB01', 'Ubuntu 22.04.4 LTS', 'HQ-Main', 22, 48, 41], ['LNX-WEB02', 'Ubuntu 22.04.4 LTS', 'HQ-Main', 18, 44, 39], ['ORA01', 'Oracle Linux Server 8.9', 'HQ-Main', 63, 87, 76], ['ORA02', 'Oracle Linux Server 8.9', 'DR-Site', 12, 52, 66], ['K8S-NODE01', 'Rocky Linux 9.3 (Blue Onyx)', 'HQ-Main', 54, 71, 58], ['K8S-NODE02', 'Rocky Linux 9.3 (Blue Onyx)', 'HQ-Main', 49, 69, 61], ['K8S-NODE03', 'Rocky Linux 9.3 (Blue Onyx)', 'HQ-Main', 92, 81, 62], ['NFS01', 'SUSE Linux Enterprise Server 15 SP5', 'HQ-Main', 8, 33, 91], ['MON01', 'Debian GNU/Linux 12 (bookworm)', 'HQ-Main', 15, 40, 47]];
  function linux() {
    const rows = linuxDefs.map(([n, os, site, cpu, mem, disk], i) => {
      const pm = /Ubuntu|Debian/.test(os) ? 'apt' : /SUSE/.test(os) ? 'zypper' : 'dnf';
      const updates = n === 'NFS01' ? 64 : n.startsWith('ORA') ? 23 : int(0, 12);
      const status = cpu >= 90 || mem >= 92 || disk >= 90 ? 'Critical' : cpu >= 75 || mem >= 80 || disk >= 80 ? 'Warning' : 'OK';
      return { Name: n, hostname: n.toLowerCase(), os, kernel: /Ubuntu/.test(os) ? '5.15.0-113-generic' : /SUSE/.test(os) ? '5.14.21-150500.55.52-default' : /Oracle/.test(os) ? '5.15.0-205.149.5.1.el8uek.x86_64' : '5.14.0-362.24.1.el9_3.x86_64', arch: 'x86_64', machineType: 'Virtual', vendor: 'VMware, Inc.', model: 'VMware7,1', serial: 'VMware-56 4d ' + int(1000, 9999), cpuModel: 'Intel(R) Xeon(R) Gold 6338 CPU @ 2.00GHz', cpuCount: n.startsWith('ORA') ? 16 : n.startsWith('K8S') ? 8 : 4, cpuPct: cpu, load: [round(cpu / 25), round(cpu / 28), round(cpu / 30)], memTotalGB: n.startsWith('ORA') ? 128 : n.startsWith('K8S') ? 32 : 8, memUsedPct: mem, swapTotalGB: 4, swapUsedPct: n === 'ORA01' ? 22 : 0, uptimeHours: int(100, 4000), ipAddresses: [ip(site, 3, 20 + i)], disks: [{ fs: '/dev/mapper/vg-root', type: 'xfs', sizeGB: 50, usedPct: Math.min(disk, 70), mount: '/' }, { fs: '/dev/sdb1', type: 'xfs', sizeGB: n.startsWith('ORA') ? 2000 : n === 'NFS01' ? 6000 : 200, usedPct: disk, mount: n.startsWith('ORA') ? '/u01' : n === 'NFS01' ? '/export' : '/data' }], topProcesses: [{ pid: 1201, user: n.startsWith('ORA') ? 'oracle' : 'root', cpu: round(cpu * 0.6), mem: round(mem * 0.4), cmd: n.startsWith('ORA') ? 'ora_dbw0_PROD' : n.startsWith('K8S') ? 'kubelet' : n.startsWith('LNX-WEB') ? 'nginx' : 'nfsd' }], packageManager: pm, packages: int(600, 1900), updates, securityUpdates: Math.round(updates / 3), oracleInstances: n === 'ORA01' ? ['PROD', 'REPORT'] : n === 'ORA02' ? ['PRODSTBY'] : [], loggedOnUsers: n.startsWith('ORA') ? ['oracle'] : [], failedUnits: n === 'K8S-NODE03' ? 1 : 0, Online: true, WorstDiskPct: disk, Status: status, Site: site };
    });
    return env('linux.hosts', rows, { hosts: rows.length, online: rows.length, critical: rows.filter((r) => r.Status === 'Critical').length, pendingUpdates: rows.reduce((a, r) => a + r.updates, 0) });
  }

  // ------------------------------------------------------------------ security
  function defender(now = NOW()) {
    const rows = servers.map((s) => {
      if (s.offline) return { ComputerName: s.name, Status: 'Unreachable' };
      const rtOff = s.name === 'LOG01';
      const sigAge = s.name === 'APP04' || s.name === 'WSUS01' ? 9 : int(0, 1);
      const det = s.name === 'WEB02' ? [{ Threat: 'Backdoor:ASP/Webshell.A', Severity: 'Severe', Detected: iso(now - 5 * H), Resources: 'file:_C:\\inetpub\\wwwroot\\upload\\cmd.aspx', Action: '3', User: 'IIS APPPOOL\\Portal', Process: 'w3wp.exe' }] : s.name === 'FS02' ? [{ Threat: 'Trojan:Win32/Wacatac.B!ml', Severity: 'High', Detected: iso(now - 2.2 * D), Resources: 'file:_E:\\Shares\\Finance\\invoice_0921.pdf.exe', Action: '2', User: 'CORP\\m.saleh', Process: 'Unknown' }, { Threat: 'PUA:Win32/Presenoker', Severity: 'Low', Detected: iso(now - 6 * D), Resources: 'file:_E:\\Shares\\Public\\tools\\setup.exe', Action: '2', User: 'CORP\\k.samir', Process: 'explorer.exe' }] : [];
      return { ComputerName: s.name, Installed: true, Mode: 'Normal', RealTime: !rtOff, Tamper: !rtOff, AntivirusEnabled: true, SignatureVersion: '1.419.' + int(100, 400) + '.0', SignatureAgeDays: sigAge, LastQuickScan: iso(now - between(2, 30) * H), LastFullScan: iso(now - between(2, 20) * D), EngineVersion: '1.1.24090.11', Detections: det, Status: rtOff ? 'Critical' : sigAge > 3 || det.length ? 'Warning' : 'OK' };
    });
    const det = rows.flatMap((r) => (r.Detections || []).map((d) => Object.assign({ ComputerName: r.ComputerName }, d)));
    const g = Object.entries(det.reduce((a, d) => ((a[d.Severity] = (a[d.Severity] || 0) + 1), a), {})).map(([name, count]) => ({ name, count }));
    return env('security.defender', rows, { machines: rows.length, protected: rows.filter((r) => r.Status === 'OK').length, realTimeOff: rows.filter((r) => r.RealTime === false).length, outdatedSignatures: rows.filter((r) => r.SignatureAgeDays > 3).length, detections: det.length, bySeverity: g });
  }

  function patches(now = NOW()) {
    const rows = servers.map((s) => {
      if (s.offline) return { ComputerName: s.name, Status: 'Unreachable' };
      const days = { APP02: 112, SQL03: 74, EXCH02: 66, WEB03: 49, APP05: 41, BKP01: 38 }[s.name] || int(4, 30);
      return { ComputerName: s.name, OS: 'Microsoft ' + s.os, LastPatched: iso(now - days * D), LastKB: 'KB50' + int(30000, 44999), HotfixCount: int(8, 40), RecentKBs: ['KB5044281', 'KB5043050', 'KB5041160'], PendingReboot: ['SQL01', 'HV02', 'APP01', 'RDS02'].includes(s.name), PendingUpdates: days > 35 ? int(6, 22) : int(0, 3), DaysSincePatch: days, Status: statusOf(days, 35, 60) };
    });
    return env('security.patches', rows, { machines: rows.length, current: rows.filter((r) => r.Status === 'OK').length, overdue: rows.filter((r) => r.Status === 'Critical').length, pendingReboot: rows.filter((r) => r.PendingReboot).length });
  }

  function firewall() {
    const rows = servers.filter((s) => !s.offline).map((s) => {
      const off = s.name === 'APP04' || s.name === 'ERP02';
      const noNla = s.name === 'RDS02' || s.name === 'APP03';
      const smb1 = s.name === 'FS03';
      const issues = [].concat(off ? ['Firewall profile disabled'] : [], noNla ? ['RDP without NLA'] : [], smb1 ? ['SMBv1 enabled'] : []);
      return { ComputerName: s.name, Domain: !off, Private: !off, Public: !off, RDPEnabled: true, NLA: !noNla, SMB1: smb1, Issues: issues, Status: off || smb1 ? 'Critical' : noNla ? 'Warning' : 'OK' };
    });
    return env('security.firewall', rows, { machines: rows.length, firewallOff: 2, noNLA: 2, smb1: 1 });
  }

  function localAdmins() {
    const rows = [];
    for (const s of servers.filter((x) => !x.offline)) {
      rows.push({ ComputerName: s.name, Member: s.name + '\\Administrator', Class: 'User', Source: 'Local' });
      rows.push({ ComputerName: s.name, Member: 'CORP\\Domain Admins', Class: 'Group', Source: 'Domain' });
      if (s.roles.includes('SQL')) rows.push({ ComputerName: s.name, Member: 'CORP\\GRP-DBA', Class: 'Group', Source: 'Domain' });
      if (s.name === 'APP03' || s.name === 'RDS01') rows.push({ ComputerName: s.name, Member: 'CORP\\h.fouad', Class: 'User', Source: 'Domain' });
      if (s.name === 'FS01') rows.push({ ComputerName: s.name, Member: 'CORP\\S-1-5-21-3623811015-3361044348-30300820-1013', Class: 'User', Source: 'Orphaned SID' });
    }
    return env('security.localadmins', rows, { machines: servers.length - 1, uniquePrincipals: new Set(rows.map((r) => r.Member)).size, orphaned: rows.filter((r) => r.Source === 'Orphaned SID').length });
  }

  function fileAcl() {
    const rows = [];
    const shares = { FS01: ['Finance', 'HR', 'Projects', 'Public'], FS02: ['Sales', 'Marketing', 'Home'], FS03: ['South-Office', 'Scans'] };
    for (const [c, list] of Object.entries(shares)) for (const sh of list) {
      rows.push({ ComputerName: c, Share: sh, Path: 'E:\\Shares\\' + sh, Identity: 'CORP\\GRP-' + sh.replace('-', ''), Rights: 'Modify, Synchronize', Type: 'Allow', Inherited: false, InheritanceBroken: true, Risky: false, OrphanedSid: false });
      rows.push({ ComputerName: c, Share: sh, Path: 'E:\\Shares\\' + sh, Identity: 'BUILTIN\\Administrators', Rights: 'FullControl', Type: 'Allow', Inherited: true, InheritanceBroken: true, Risky: false, OrphanedSid: false });
      if (sh === 'Public' || sh === 'Scans') rows.push({ ComputerName: c, Share: sh, Path: 'E:\\Shares\\' + sh, Identity: 'Everyone', Rights: 'FullControl', Type: 'Allow', Inherited: false, InheritanceBroken: true, Risky: true, OrphanedSid: false });
      if (sh === 'Projects') rows.push({ ComputerName: c, Share: sh, Path: 'E:\\Shares\\' + sh, Identity: 'CORP\\Domain Users', Rights: 'Modify, Synchronize', Type: 'Allow', Inherited: false, InheritanceBroken: true, Risky: true, OrphanedSid: false });
    }
    return env('security.fileacl', rows, { entries: rows.length, risky: rows.filter((r) => r.Risky).length, orphaned: 0 });
  }

  // ------------------------------------------------------------------ audit
  function audit(now = NOW()) {
    const rows = [];
    const dcs = ['DC01', 'DC02', 'DC03', 'DC04'];
    const users = Array.from({ length: 40 }, () => (pick(first)[0] + '.' + pick(last)).toLowerCase());
    const push = (set, title, id, sev, extra, ageH) => rows.push(Object.assign({ Time: iso(now - ageH * H), EventSet: set, Title: title, EventId: id, Server: pick(dcs), Actor: null, Target: null, Group: null, SourceIP: null, Workstation: null, Attribute: null, Value: null, Reason: null, Privileged: false, Severity: sev }, extra));
    for (let i = 0; i < 260; i++) {
      const u = pick(users), age = Math.pow(R(), 1.6) * 24 * 7;
      push('BadLogon', 'Failed logon', 4625, 'Warning', { Target: u, SourceIP: '10.10.' + int(50, 53) + '.' + int(2, 250), Workstation: 'WS-' + pad(int(1, 186), 4), Reason: pick(['Incorrect password', 'Incorrect password', 'Bad username or password', 'Account does not exist', 'Account disabled']) }, age);
    }
    for (let i = 0; i < 44; i++) push('BadLogon', 'Failed logon', 4625, 'Warning', { Target: 'j.adel', SourceIP: '10.10.51.142', Workstation: 'WS-0142', Reason: 'Incorrect password' }, between(0, 3));
    for (let i = 0; i < 9; i++) push('Lockout', 'Account locked out', 4740, 'Critical', { Target: 'j.adel', Workstation: 'WS-0142', Actor: 'CORP\\SYSTEM' }, between(0, 3));
    for (let i = 0; i < 6; i++) push('Lockout', 'Account locked out', 4740, 'Critical', { Target: pick(users), Workstation: 'WS-' + pad(int(1, 186), 4) }, between(0, 140));
    for (let i = 0; i < 5; i++) push('Unlock', 'Account unlocked', 4767, 'Info', { Target: i < 2 ? 'j.adel' : pick(users), Actor: 'CORP\\helpdesk.' + pick(['nour', 'adel']) }, between(0, 100));
    for (let i = 0; i < 70; i++) push('KerberosPreAuthFailed', 'Kerberos pre-auth failed', 4771, 'Warning', { Target: i < 18 ? 'svc_sharepoint' : pick(users), SourceIP: i < 18 ? '10.10.4.77' : '10.10.' + int(50, 53) + '.' + int(2, 250), Reason: 'Bad password (Kerberos)' }, Math.pow(R(), 1.4) * 160);
    for (let i = 0; i < 18; i++) push('ObjectCreated', 'Directory object created', 5137, 'Info', { Actor: 'CORP\\admin.' + pick(['marco', 'sara', 'omar']), Target: 'CN=' + pick(first) + ' ' + pick(last) + ',OU=Users,OU=HQ,DC=corp,DC=moncastle,DC=local' }, between(0, 160));
    for (let i = 0; i < 6; i++) push('ObjectDeleted', 'Directory object deleted', 5141, 'Warning', { Actor: 'CORP\\admin.' + pick(['marco', 'sara']), Target: 'CN=WS-' + pad(int(200, 260), 4) + ',OU=Workstations,DC=corp,DC=moncastle,DC=local' }, between(0, 160));
    for (let i = 0; i < 64; i++) push('ObjectModified', 'Directory object modified', 5136, 'Info', { Actor: 'CORP\\' + pick(['admin.marco', 'admin.sara', 'helpdesk.nour', 'svc_hrsync']), Target: 'CN=' + pick(first) + ' ' + pick(last) + ',OU=Users,DC=corp,DC=moncastle,DC=local', Attribute: pick(['title', 'department', 'telephoneNumber', 'manager', 'userAccountControl', 'memberOf']) }, between(0, 160));
    for (let i = 0; i < 8; i++) push('ObjectMoved', 'Directory object moved', 5139, 'Info', { Actor: 'CORP\\admin.omar', Target: 'CN=WS-' + pad(int(1, 186), 4) + ',OU=Disabled,DC=corp,DC=moncastle,DC=local' }, between(0, 160));
    for (let i = 0; i < 11; i++) push(i < 4 ? 'AccountEnabled' : 'AccountDisabled', i < 4 ? 'Account enabled' : 'Account disabled', i < 4 ? 4722 : 4725, 'Info', { Actor: 'CORP\\helpdesk.nour', Target: pick(users) }, between(0, 160));
    for (let i = 0; i < 26; i++) {
      const g = i === 0 ? 'Domain Admins' : i === 1 ? 'Enterprise Admins' : 'GRP-' + pick(depts).replace(/\s/g, '');
      const priv = i < 2;
      push(i % 4 === 3 ? 'GroupMemberRemoved' : 'GroupMemberAdded', i % 4 === 3 ? 'Group member removed' : 'Group member added', i % 4 === 3 ? 4729 : 4728, priv ? 'Critical' : 'Info', { Actor: priv ? 'CORP\\admin.sara' : 'CORP\\helpdesk.nour', Target: 'CN=' + (priv ? 'h.fouad' : pick(users)) + ',OU=Users,DC=corp,DC=moncastle,DC=local', Group: g, Privileged: priv }, priv ? (i === 0 ? 1.4 : 30) : between(0, 160));
    }
    for (let i = 0; i < 3; i++) push('GroupCreated', 'Group created', 4731, 'Info', { Actor: 'CORP\\admin.marco', Group: 'GRP-Project-' + pick(['Atlas', 'Nile', 'Delta']), Target: null }, between(0, 160));
    for (let i = 0; i < 22; i++) push(i < 15 ? 'PasswordReset' : 'PasswordChange', i < 15 ? 'Password reset (admin)' : 'Password change attempt (owner)', i < 15 ? 4724 : 4723, i < 15 ? 'Warning' : 'Info', { Actor: i < 15 ? 'CORP\\helpdesk.' + pick(['nour', 'adel']) : null, Target: i < 3 ? 'j.adel' : pick(users) }, between(0, 160));
    for (let i = 0; i < 90; i++) push('NPS', 'NPS authentication', i < 78 ? 6272 : 6273, i < 78 ? 'Info' : 'Warning', { Server: 'NPS01', Actor: 'CORP\\' + pick(users), SourceIP: '10.10.70.' + int(2, 250), Workstation: 'AP-HQ' + pad(int(1, 10)), Reason: i < 78 ? null : 'Authentication failed due to a user credentials mismatch' }, Math.pow(R(), 1.3) * 160);
    for (let i = 0; i < 46; i++) push('RemoteLogon', 'Remote desktop logon', 21, 'Info', { Server: pick(['RDS01', 'RDS02', 'APP01', 'SQL01', 'HV01', 'DC01']), Actor: 'CORP\\' + pick(['admin.marco', 'admin.sara', 'admin.omar', 'h.fouad', 'k.samir']), SourceIP: '10.10.' + pick([1, 51, 99]) + '.' + int(2, 250) }, between(0, 160));
    for (let i = 0; i < 14; i++) {
      const crash = i === 0;
      push('ShutdownRestart', 'Shutdown / restart', crash ? 41 : pick([1074, 6006, 6005]), crash ? 'Critical' : 'Info', { Server: crash ? 'APP03' : pick(servers).name, Actor: crash ? null : 'CORP\\admin.' + pick(['marco', 'sara']), Reason: crash ? 'The system has rebooted without cleanly shutting down first.' : 'The process C:\\Windows\\system32\\svchost.exe has initiated the restart: Operating System: Service pack (Planned)' }, crash ? 6.5 : between(0, 160));
    }
    for (let i = 0; i < 40; i++) push('FileAccess', 'File share access', 5145, 'Info', { Server: pick(['FS01', 'FS02']), Actor: 'CORP\\' + pick(users), Target: pick(['Finance', 'HR', 'Projects', 'Sales']) + '\\' + pick(['budget_2027.xlsx', 'salaries.xlsx', 'contract.docx', 'Q3-report.pptx']), SourceIP: '10.10.5' + int(0, 3) + '.' + int(2, 250) }, between(0, 160));
    const files = ['Finance\\budget_2027.xlsx', 'HR\\salaries.xlsx', 'Projects\\Atlas\\design.vsdx', 'Sales\\pipeline.xlsx', 'Legal\\contract-v4.docx'];
    for (let i = 0; i < 30; i++) push('FileModify', 'File or folder written', 4663, 'Info', { Server: pick(['FS01', 'FS02']), Actor: 'CORP\\' + pick(users), Target: 'E:\\Shares\\' + pick(files), Value: 'WriteData' }, between(0, 160));
    for (let i = 0; i < 9; i++) push('FileDelete', 'File or folder deleted', 4660, 'Warning', { Server: i < 6 ? 'FS02' : 'FS01', Actor: 'CORP\\' + (i < 6 ? 'k.samir' : pick(users)), Target: 'E:\\Shares\\' + pick(files) }, i < 6 ? between(0, 20) : between(0, 160));
    push('FilePermission', 'Permissions changed', 4670, 'Warning', { Server: 'FS01', Actor: 'CORP\\admin.omar', Target: 'E:\\Shares\\HR', Value: 'Everyone: Read added' }, 5.2);
    for (let i = 0; i < 36; i++) push('PrintJob', 'Print job', 307, 'Info', { Server: pick(['PRN01', 'PRN02']), Actor: 'CORP\\' + pick(users), Target: pick(printerRows).Name, Workstation: 'WS-' + pad(int(1, 186), 4) }, between(0, 160));
    rows.sort((a, b) => (a.Time < b.Time ? 1 : -1));
    const grp = (list, key) => Object.entries(list.reduce((a, r) => { const k = typeof key === 'function' ? key(r) : r[key]; if (k) a[k] = (a[k] || 0) + 1; return a; }, {})).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count);
    const fails = rows.filter((r) => ['BadLogon', 'KerberosPreAuthFailed', 'Lockout'].includes(r.EventSet));
    return env('audit.events', rows, { events: rows.length, since: iso(now - 7 * D), bySet: grp(rows, 'EventSet'), critical: rows.filter((r) => r.Severity === 'Critical').length, topFailedUsers: grp(fails.filter((r) => r.EventSet !== 'Lockout'), 'Target').slice(0, 10), topFailedSources: grp(fails, (r) => r.SourceIP || r.Workstation).slice(0, 10) });
  }

  // ------------------------------------------------------------------ inventory misc
  function software() {
    const pkgs = [['Microsoft Edge', 'Microsoft Corporation'], ['7-Zip 23.01 (x64)', 'Igor Pavlov'], ['Microsoft Visual C++ 2015-2022 Redistributable (x64)', 'Microsoft Corporation'], ['VMware Tools', 'VMware, Inc.'], ['Veeam Agent for Microsoft Windows', 'Veeam Software Group GmbH'], ['Microsoft SQL Server 2019 (64-bit)', 'Microsoft Corporation'], ['Notepad++ (64-bit x64)', 'Notepad++ Team'], ['Google Chrome', 'Google LLC'], ['Microsoft Monitoring Agent', 'Microsoft Corporation'], ['Java 8 Update 381', 'Oracle Corporation'], ['PowerShell 7-x64', 'Microsoft Corporation'], ['Zabbix Agent 2 (64-bit)', 'Zabbix SIA'], ['WinRAR 6.02 (64-bit)', 'win.rar GmbH'], ['Adobe Acrobat Reader DC', 'Adobe Inc.']];
    const wsPkgs = [['Microsoft 365 Apps for enterprise - en-us', 'Microsoft Corporation', 'Registry'], ['Microsoft Teams', 'Microsoft Corporation', 'Registry (user)'], ['Google Chrome', 'Google LLC', 'Registry'], ['Zoom Workplace', 'Zoom Video Communications, Inc.', 'Registry (user)'], ['Adobe Acrobat Reader DC', 'Adobe Inc.', 'Registry'], ['Microsoft Visual Studio Code (User)', 'Microsoft Corporation', 'Registry (user)'], ['FortiClient VPN', 'Fortinet Technologies Inc', 'Registry'], ['7-Zip 23.01 (x64)', 'Igor Pavlov', 'Registry'], ['Microsoft.CompanyPortal', 'Microsoft Corporation', 'Microsoft Store'], ['Mozilla Firefox (x64 en-US)', 'Mozilla', 'Registry'], ['Java 8 Update 381', 'Oracle Corporation', 'Registry'], ['Cisco Secure Client', 'Cisco Systems, Inc.', 'Registry']];
    const lnxPkgs = (os) => (/Ubuntu|Debian/.test(os)
      ? [['openssh-server', '1:8.9p1-3ubuntu0.10', 'dpkg', 'Ubuntu Developers'], ['nginx', '1.18.0-6ubuntu14.4', 'dpkg', 'Ubuntu Developers'], ['openssl', '3.0.2-0ubuntu1.18', 'dpkg', 'Ubuntu Developers'], ['docker-ce', '5:26.1.4-1~ubuntu.22.04~jammy', 'dpkg', 'Docker'], ['zabbix-agent2', '1:6.4.15-1+ubuntu22.04', 'dpkg', 'Zabbix SIA'], ['python3', '3.10.6-1~22.04.1', 'dpkg', 'Ubuntu Developers'], ['lxd', '5.21.1', 'snap', 'canonical'], ['curl', '7.81.0-1ubuntu1.17', 'dpkg', 'Ubuntu Developers']]
      : [['openssh-server', '8.7p1-38.el9', 'rpm', 'Red Hat, Inc.'], ['httpd', '2.4.57-8.el9', 'rpm', 'Red Hat, Inc.'], ['openssl', '3.0.7-27.el9', 'rpm', 'Red Hat, Inc.'], ['postgresql-server', '15.6-1.el9', 'rpm', 'Red Hat, Inc.'], ['zabbix-agent2', '6.4.15-release1.el9', 'rpm', 'Zabbix SIA'], ['python3', '3.9.18-3.el9', 'rpm', 'Red Hat, Inc.'], ['podman', '4.9.4-1.el9', 'rpm', 'Red Hat, Inc.'], ['java-17-openjdk', '17.0.11.0.9-2.el9', 'rpm', 'Red Hat, Inc.']]);
    const rows = [];
    for (const s of servers.filter((x) => !x.offline)) for (const [n, v] of pkgs) if (R() > 0.45 || n.startsWith('Microsoft Edge')) { if (n.includes('SQL Server') && !s.roles.includes('SQL')) continue; rows.push({ ComputerName: s.name, Platform: 'Windows', OS: s.os, Name: n, Version: int(1, 120) + '.' + int(0, 9) + '.' + int(0, 999), Vendor: v, InstallDate: '2025' + pad(int(1, 12)) + pad(int(1, 28)), Architecture: 'x64', Source: 'Registry' }); }
    for (const w of workstations.slice(0, 40)) for (const [n, v, src] of wsPkgs) if (R() > 0.3 || /365|Teams/.test(n)) rows.push({ ComputerName: w.Name, Platform: 'Windows', OS: w.OperatingSystem, Name: n, Version: int(1, 30) + '.' + int(0, 9) + '.' + int(0, 9999), Vendor: v, InstallDate: '2026' + pad(int(1, 10)) + pad(int(1, 28)), Architecture: src === 'Microsoft Store' ? 'X64' : 'x64', Source: src });
    for (const [n, os] of linuxDefs) for (const [p, ver, src, v] of lnxPkgs(os)) if (R() > 0.25 || p === 'openssh-server') rows.push({ ComputerName: n, Platform: 'Linux', OS: os, Name: p, Version: ver, Vendor: v, InstallDate: null, Architecture: src === 'snap' ? '' : /Ubuntu|Debian/.test(os) ? 'amd64' : 'x86_64', Source: src });
    const g = (k) => Object.entries(rows.reduce((a, r) => ((a[r[k]] = (a[r[k]] || 0) + 1), a), {})).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count).slice(0, 15);
    const machines = new Set(rows.map((r) => r.ComputerName));
    return env('inventory.software', rows, { machines: machines.size, windows: [...machines].filter((m) => rows.find((r) => r.ComputerName === m).Platform === 'Windows').length, linux: linuxDefs.length, unreachable: [], packages: rows.length, unique: new Set(rows.map((r) => r.Name)).size, topVendors: g('Vendor'), topSoftware: g('Name') });
  }
  function workstationsInv() {
    return env('inventory.workstations', workstations.map((w) => Object.assign({}, w, { Online: true })), { known: workstations.length, refreshed: workstations.filter((w) => w.Online).length });
  }

  function discovery() {
    const g = Object.entries(netDevices.reduce((a, r) => ((a[r.DeviceClass] = (a[r.DeviceClass] || 0) + 1), a), {})).map(([name, count]) => ({ name, count }));
    return env('network.discovery', netDevices, { subnets: 4, devices: netDevices.length, byClass: g });
  }

  // ------------------------------------------------------------------ SNMP engines: network and storage devices (4.7.1)
  function netSnmp() {
    const cls = (h) => (/^fw/.test(h) ? 'Firewall' : /^ap/.test(h) ? 'Access point' : 'Switch');
    const rows = netDevices.filter((r) => r.DeviceClass === 'Network device').slice(0, 30).map((r, i) => {
      const h = (r.HostName || r.IPAddress).split('.')[0], c = cls(h), ports = /core|dist/.test(h) ? 48 : c === 'Firewall' ? 12 : c === 'Access point' ? 2 : 24, down = c === 'Access point' ? 0 : i % 7 === 3 ? 2 : i % 11 === 5 ? 1 : 0, dead = i === 9;
      const model = c === 'Firewall' ? 'FortiGate-200F v7.2.8,build1639 (GA.M)' : c === 'Access point' ? 'Cisco Catalyst 9120AXI Access Point, IOS-XE 17.9.4' : 'Cisco IOS Software, Catalyst L3 Switch Software (CAT9K_IOSXE), Version 17.9.4';
      if (dead) return { Name: r.IPAddress, SysName: null, Description: null, ObjectId: null, Vendor: null, Class: null, Location: null, UptimeDays: null, Interfaces: 0, Up: 0, DownEnabled: 0, DownList: null, Status: 'Critical', Message: 'No SNMP answer from ' + r.IPAddress + ' (UDP 161): wrong community, ACL or the agent is off' };
      const o = { Name: r.IPAddress, SysName: h, Description: model, ObjectId: c === 'Firewall' ? '1.3.6.1.4.1.12356.101.1.2006' : '1.3.6.1.4.1.9.1.' + (2494 + i), Vendor: c === 'Firewall' ? 'Fortinet' : 'Cisco', Class: c, Location: r.Site, UptimeDays: 12 + ((i * 37) % 300), Interfaces: ports + 3, Up: ports - (c === 'Access point' ? 0 : 6) - down, DownEnabled: down, DownList: down ? ['Gi1/0/' + (10 + i), 'Gi1/0/' + (11 + i)].slice(0, down).join(', ') : null, InErrors: int(0, 40),
        CpuPct: int(4, 38), MemPct: int(22, 64) };
      if (c === 'Firewall') Object.assign(o, { Sessions: int(18000, 64000), SessionPct: int(8, 30), HaState: 'Active-passive', VpnTunnels: /hq/.test(h) ? 6 : 3, VpnTunnelsDown: /dr/.test(h) ? 1 : 0, VpnUsers: /hq/.test(h) ? int(30, 90) : int(2, 12) });
      if (c === 'Access point') Object.assign(o, { WifiClients: int(4, 46), CpuPct: int(3, 20) });
      const p = []; if (down) p.push(down + ' enabled interface(s) down'); if (o.VpnTunnelsDown) p.push(o.VpnTunnelsDown + ' of ' + o.VpnTunnels + ' VPN tunnels down');
      o.Status = p.length ? 'Warning' : 'OK';
      o.Message = p.length ? p.join(', ') : [o.Up + ' of ' + o.Interfaces + ' interfaces up'].concat(o.Sessions ? [o.Sessions + ' sessions', o.VpnTunnels + ' VPN tunnels', o.VpnUsers + ' VPN users'] : [], o.WifiClients != null ? [o.WifiClients + ' clients'] : []).join(' · ');
      return o;
    });
    // appliances that only the SNMP engine classifies: wireless controllers, WAN routers, VPN gateway, load balancer and WAF
    const extra = [
      { Name: '10.10.0.30', SysName: 'wlc-hq01', Description: 'Cisco Catalyst 9800-40 Wireless Controller, IOS-XE 17.9.4', ObjectId: '1.3.6.1.4.1.9.1.2530', Vendor: 'Cisco', Class: 'Wireless controller', Location: 'HQ-Main', UptimeDays: 143, Interfaces: 6, Up: 4, DownEnabled: 0, InErrors: 0, CpuPct: 18, MemPct: 41, APs: 14, APsDown: 0, WifiClients: 286 },
      { Name: '10.20.0.30', SysName: 'wlc-dr01', Description: 'Cisco Catalyst 9800-L Wireless Controller, IOS-XE 17.9.4', ObjectId: '1.3.6.1.4.1.9.1.2669', Vendor: 'Cisco', Class: 'Wireless controller', Location: 'DR-Site', UptimeDays: 61, Interfaces: 4, Up: 3, DownEnabled: 0, InErrors: 2, CpuPct: 9, MemPct: 37, APs: 4, APsDown: 1, WifiClients: 38 },
      { Name: '10.10.0.250', SysName: 'rtr-wan01', Description: 'Cisco IOS XE Software, ISR4451-X/K9, Version 17.9.4a', ObjectId: '1.3.6.1.4.1.9.1.2068', Vendor: 'Cisco', Class: 'Router', Location: 'HQ-Main', UptimeDays: 212, Interfaces: 8, Up: 5, DownEnabled: 0, InErrors: 118, CpuPct: 27, MemPct: 48, BgpPeers: 4, BgpDown: 1 },
      { Name: '10.30.0.250', SysName: 'rtr-br01', Description: 'Huawei Versatile Routing Platform Software, AR6280 V300R022C00', ObjectId: '1.3.6.1.4.1.2011.2.224.279', Vendor: 'Huawei', Class: 'Router', Location: 'Branch-North', UptimeDays: 88, Interfaces: 10, Up: 6, DownEnabled: 0, InErrors: 3, CpuPct: 12, MemPct: 33, BgpPeers: 2, BgpDown: 0 },
      { Name: '10.10.0.240', SysName: 'vpn-hq01', Description: 'Ivanti Connect Secure (Pulse Secure) VPN gateway 22.7R2', ObjectId: '1.3.6.1.4.1.12532.256.2.1', Vendor: 'Other', Class: 'VPN gateway', Location: 'HQ-Main', UptimeDays: 40, Interfaces: 3, Up: 2, DownEnabled: 0, InErrors: 0, CpuPct: 21, MemPct: 52, VpnUsers: 142 },
      { Name: '10.10.0.230', SysName: 'lb-hq01', Description: 'BIG-IP i5800 : Linux 3.10.0 : BIG-IP software release 17.1.1.3', ObjectId: '1.3.6.1.4.1.3375.2.1.3.4.130', Vendor: 'F5', Class: 'Load balancer', Location: 'HQ-Main', UptimeDays: 97, Interfaces: 8, Up: 6, DownEnabled: 0, InErrors: 0, CpuPct: 19, LbConnections: 8412, VirtualServersDown: 0, PoolMembersDown: 2, HaState: 'Active' },
      { Name: '10.10.0.231', SysName: 'waf-hq01', Description: 'FortiWeb-1000F v7.4.3 (Web Application Firewall)', ObjectId: '1.3.6.1.4.1.12356.107.1.1', Vendor: 'Fortinet', Class: 'WAF', Location: 'HQ-Main', UptimeDays: 55, Interfaces: 4, Up: 4, DownEnabled: 0, InErrors: 0, CpuPct: 31, MemPct: 58, Sessions: 2210 },
    ].map((o) => {
      const p = []; if (o.APsDown) p.push(o.APsDown + ' of ' + o.APs + ' access points down'); if (o.BgpDown) p.push(o.BgpDown + ' of ' + o.BgpPeers + ' BGP peers not established'); if (o.PoolMembersDown) p.push(o.PoolMembersDown + ' pool members down');
      const info = [o.Up + ' of ' + o.Interfaces + ' interfaces up'].concat(o.APs != null ? [o.APs + ' APs, ' + o.WifiClients + ' clients'] : [], o.VpnUsers != null ? [o.VpnUsers + ' VPN users'] : [], o.LbConnections != null ? [o.LbConnections + ' connections'] : [], o.Sessions != null ? [o.Sessions + ' sessions'] : []);
      return Object.assign({ DownList: null }, o, { Status: p.length ? 'Warning' : 'OK', Message: p.length ? p.join(', ') : info.join(' · ') });
    });
    const all = rows.concat(extra), by = {};
    all.forEach((r) => { if (r.Class) by[r.Class] = (by[r.Class] || 0) + 1; });
    return env('network.devices', all, { devices: all.length, ok: all.filter((r) => r.Status === 'OK').length, unreachable: all.filter((r) => r.Status === 'Critical').length, interfacesDown: all.reduce((a, r) => a + r.DownEnabled, 0), byClass: Object.entries(by).map(([name, count]) => ({ name, count })), vpnTunnelsDown: all.reduce((a, r) => a + (r.VpnTunnelsDown || 0), 0), apsDown: all.reduce((a, r) => a + (r.APsDown || 0), 0) });
  }
  function storageSnmp() {
    const devs = [['NAS01', '10.10.20.40', 'Synology DS1821+ DSM 7.2.1', [['/volume1', 21800, 71], ['/volume2', 10900, 88]]], ['NAS02', '10.20.20.40', 'QNAP TS-h1290FX QuTS hero h5.1', [['DataPool1', 43600, 64]]],
      ['SAN01', '10.10.20.10', 'NetApp Release 9.14.1P3: ONTAP', [['aggr1_node1', 98000, 79], ['aggr1_node2', 98000, 96], ['vol_sql_data', 12000, 82]]], ['BKP01', '10.10.20.60', 'Dell PowerProtect DD6900 DDOS 7.13', [['/data/col1', 288000, 58]]]];
    const rows = [];
    devs.forEach(([n, ip, d, vols], i) => vols.forEach(([v, sz, pct]) => rows.push({ Name: ip, SysName: n, Description: d, UptimeDays: 40 + i * 31, Volume: v, Type: 'Fixed', SizeGB: sz, UsedGB: Math.round(sz * pct / 100), UsedPct: pct, Status: pct >= 95 ? 'Critical' : pct >= 85 ? 'Warning' : 'OK', Message: pct + '% used of ' + sz + ' GB' })));
    return env('storage.devices', rows, { devices: devs.length, volumes: rows.length, full: rows.filter((r) => r.Status === 'Critical').length });
  }

  // ------------------------------------------------------------------ OpenShift Virtualization and Nutanix AHV (4.6)
  function openshift() {
    const nodes = ['ocp-worker-1', 'ocp-worker-2', 'ocp-worker-3'];
    const vms = [['prod', 'ocp-web01', 'RHEL 9.4', 2, 4], ['prod', 'ocp-web02', 'RHEL 9.4', 2, 4], ['prod', 'ocp-api01', 'RHEL 9.4', 4, 8], ['prod', 'ocp-win-app01', 'Windows Server 2022', 4, 16], ['dev', 'ocp-dev-db', 'Fedora 40', 2, 8], ['dev', 'ocp-build01', 'RHEL 8.10', 8, 16], ['test', 'ocp-test07', null, 2, 4]];
    const rows = vms.map(([ns, n, os, cpu, mem], i) => {
      const off = n === 'ocp-test07', err = n === 'ocp-dev-db';
      return { Kind: 'VM', Platform: 'OpenShift', Cluster: 'api.ocp.' + DOMAIN, Namespace: ns, Name: n, Power: off ? 'Stopped' : err ? 'CrashLoopBackOff' : 'Running', Host: off ? null : nodes[i % 3], vCPU: cpu, MemoryGB: mem, GuestOS: os, IPAddress: off ? [] : ['10.128.' + (i + 2) + '.' + (10 + i)], Agent: !off && !err, Status: err ? 'Critical' : 'OK', CPU: off ? 0 : int(4, 70) };
    });
    nodes.forEach((n, i) => rows.push({ Kind: 'Node', Platform: 'OpenShift', Cluster: 'api.ocp.' + DOMAIN, Name: n, State: 'Ready', CPUs: 32, MemoryGB: 128, VMs: rows.filter((v) => v.Host === n).length, Version: 'v1.29.6', Status: 'OK' }));
    const v = rows.filter((r) => r.Kind === 'VM');
    return env('virtualization.openshift', rows, { clusters: 1, vms: v.length, running: v.filter((x) => x.Power === 'Running').length, nodes: nodes.length });
  }
  function nutanix() {
    const hosts = ['ahv-01', 'ahv-02', 'ahv-03', 'ahv-04'];
    const vms = [['NTX-APP01', 'Windows Server 2022', 4, 16], ['NTX-APP02', 'Windows Server 2022', 4, 16], ['NTX-SQL01', 'Windows Server 2019', 8, 64], ['NTX-FS01', 'Windows Server 2022', 4, 12], ['NTX-LNX-WEB01', 'Ubuntu 22.04', 2, 4], ['NTX-LNX-WEB02', 'Ubuntu 22.04', 2, 4], ['NTX-VDI-01', 'Windows 11 Enterprise', 2, 8], ['NTX-OLD-CRM', 'Windows Server 2012 R2', 2, 8]];
    const rows = vms.map(([n, os, cpu, mem], i) => ({ Kind: 'VM', Platform: 'Nutanix', Cluster: 'NTX-CL1', Name: n, Power: n === 'NTX-OLD-CRM' ? 'Off' : 'Running', Host: hosts[i % 4], vCPU: cpu, MemoryGB: mem, IPAddress: ['10.50.0.' + (10 + i)], GuestOS: os, Agent: n !== 'NTX-OLD-CRM', DiskGB: int(80, 600), Status: 'OK', CPU: n === 'NTX-OLD-CRM' ? 0 : int(3, n === 'NTX-SQL01' ? 88 : 55) }));
    hosts.forEach((h) => rows.push({ Kind: 'Host', Platform: 'Nutanix', Cluster: 'NTX-CL1', Name: h, State: 'HYPER_CONVERGED', CPUs: 32, MemoryGB: 512, VMs: rows.filter((v) => v.Host === h && v.Power === 'Running').length, Version: 'AHV 20230302.101026', Status: 'OK' }));
    rows.push({ Kind: 'Cluster', Platform: 'Nutanix', Cluster: 'NTX-CL1', Name: 'NTX-CL1', Version: '6.8.1', Nodes: 4, Status: 'OK' });
    rows.push({ Kind: 'Container', Platform: 'Nutanix', Cluster: 'NTX-CL1', Name: 'default-container', CapacityGB: 40960, FreeGB: 6144, UsedPct: 85.0, Status: 'Warning' });
    const v = rows.filter((r) => r.Kind === 'VM');
    return env('virtualization.nutanix', rows, { vms: v.length, running: v.filter((x) => x.Power === 'Running').length, hosts: hosts.length });
  }

  // ------------------------------------------------------------------ 4.7.2 engines: Linux, web, TLS, temperature, containers, Kubernetes, cloud network
  const st = (v, w, c) => (v == null ? 'Unknown' : v >= c ? 'Critical' : v >= w ? 'Warning' : 'OK');
  function linuxFs() {
    const rows = [];
    for (const [n, , , , , disk] of linuxDefs) {
      const big = n.startsWith('ORA') ? ['/u01', 2000] : n === 'NFS01' ? ['/export', 6000] : ['/data', 200];
      const mk = (mount, dev, type, size, pct, ino, ro) => rows.push({ Name: n, Mount: mount, Device: dev, Type: type, SizeGB: size, UsedGB: round(size * pct / 100), UsedPct: pct, InodesPct: ino, ReadOnly: !!ro, Status: ro ? 'Critical' : st(Math.max(pct, ino || 0), 85, 95), Message: ro ? mount + ' is mounted read-only' : pct + '% used, ' + round(size * (100 - pct) / 100) + ' GB free' + (ino >= 85 ? ', inodes ' + ino + '%' : '') });
      mk('/', '/dev/mapper/vg-root', 'xfs', 50, Math.min(disk, 70), 12 + (disk % 20));
      mk('/boot', '/dev/sda1', 'xfs', 1, 31, 1);
      mk(big[0], '/dev/sdb1', n === 'NFS01' ? 'ext4' : 'xfs', big[1], disk, n === 'MON01' ? 91 : 8);
      if (n === 'ORA02') rows.push({ Name: n, Mount: '/backup', Device: 'nfs01:/export/backup', Type: 'nfs', SizeGB: null, UsedGB: null, UsedPct: null, InodesPct: null, ReadOnly: false, Status: 'Critical', Message: 'In /etc/fstab but not mounted' });
    }
    return env('linux.filesystems', rows, { hosts: linuxDefs.length, filesystems: rows.length, full: rows.filter((r) => r.Status === 'Critical').length });
  }
  function linuxServices() {
    const rows = [];
    for (const [n] of linuxDefs) {
      const watch = n.startsWith('LNX-WEB') ? ['nginx', 'sshd', 'chronyd'] : n.startsWith('ORA') ? ['oracle-ohasd', 'sshd', 'chronyd'] : n.startsWith('K8S') ? ['kubelet', 'containerd', 'sshd'] : n === 'NFS01' ? ['nfs-server', 'sshd'] : ['prometheus', 'grafana-server', 'sshd'];
      for (const s of watch) { const bad = n === 'LNX-WEB02' && s === 'chronyd'; rows.push({ Name: n, Kind: 'Watched service', Unit: s + '.service', Active: bad ? 'inactive' : 'active', Sub: bad ? 'dead' : 'running', Enabled: 'enabled', Status: bad ? 'Critical' : 'OK', Message: bad ? s + ' is enabled but not running' : s + ' running' }); }
      if (n === 'K8S-NODE03') rows.push({ Name: n, Kind: 'Failed unit', Unit: 'node-exporter.service', Active: 'failed', Sub: 'failed', Enabled: 'enabled', Status: 'Critical', Message: 'node-exporter.service failed (exit-code)' });
      rows.push({ Name: n, Kind: 'Host', Unit: null, Active: null, Sub: null, Enabled: null, Status: 'OK', Message: int(110, 240) + ' units loaded' });
    }
    return env('linux.services', rows, { hosts: linuxDefs.length, failed: rows.filter((r) => r.Kind === 'Failed unit').length, stopped: rows.filter((r) => r.Kind === 'Watched service' && r.Status === 'Critical').length });
  }
  function linuxAudit() {
    const rows = linuxDefs.map(([n], i) => {
      const exposed = n.startsWith('LNX-WEB'), fl = exposed ? 140 + i * 37 : int(0, 6), root = n === 'LNX-WEB01' ? 2 : 0, sf = n === 'MON01' ? 3 : 0;
      return { Name: n, HoursBack: 24, FailedLogins: fl, Logins: int(2, 30), RootLogins: root, SudoCommands: int(3, 60), SudoFailures: sf, NewUsers: n === 'ORA02' ? ['dbtemp'] : [], TopSources: exposed ? ['203.0.113.45 (' + Math.round(fl * 0.6) + ')', '198.51.100.7 (' + Math.round(fl * 0.2) + ')'] : [], Auditd: n === 'MON01' ? 'inactive' : 'active', PermitRootLogin: n === 'LNX-WEB01' ? 'yes' : 'prohibit-password', Status: root || fl >= 100 ? 'Critical' : sf || fl >= 20 || n === 'ORA02' ? 'Warning' : 'OK', Message: [fl + ' failed logins', root ? root + ' root SSH logins' : null, sf ? sf + ' refused sudo' : null, n === 'ORA02' ? 'new account dbtemp' : null, n === 'MON01' ? 'auditd not running' : null].filter(Boolean).join(', ') };
    });
    return env('linux.audit', rows, { hosts: rows.length, failedLogins: rows.reduce((a, r) => a + r.FailedLogins, 0), rootLogins: rows.reduce((a, r) => a + r.RootLogins, 0) });
  }
  const webSites = [['portal.' + DOMAIN, 'https://portal.' + DOMAIN + '/', 200, 182, 'Microsoft-IIS/10.0', 'IIS'], ['intranet.' + DOMAIN, 'https://intranet.' + DOMAIN + '/', 200, 96, 'nginx/1.24.0', 'nginx'], ['shop.moncastle-demo.com', 'https://shop.moncastle-demo.com/', 200, 2640, 'cloudflare', 'Cloudflare'], ['api.moncastle-demo.com', 'https://api.moncastle-demo.com/health', 503, 41, 'nginx', 'nginx'], ['grafana.' + DOMAIN, 'https://grafana.' + DOMAIN + '/login', 200, 77, null, 'Unknown'], ['legacy-crm.' + DOMAIN, 'http://legacy-crm.' + DOMAIN + '/', 200, 410, 'Apache/2.4.6 (CentOS)', 'Apache']];
  function webServers() {
    const rows = webSites.map(([n, url, code, ms, srv, kind]) => ({ Name: n, Url: url, StatusCode: code, ResponseMs: ms, Server: srv, ServerKind: kind, PoweredBy: kind === 'IIS' ? 'ASP.NET' : null, FinalUrl: url, Redirects: kind === 'Cloudflare' ? 1 : 0, ContentMatch: null, SizeKB: int(4, 300), Status: code >= 500 ? 'Critical' : ms >= 2000 || /2\.4\.6/.test(srv || '') ? 'Warning' : 'OK', Message: 'HTTP ' + code + ' in ' + ms + ' ms' + (/2\.4\.6/.test(srv || '') ? ', old Apache 2.4.6' : '') }));
    return env('web.servers', rows, { sites: rows.length, down: rows.filter((r) => r.Status === 'Critical').length });
  }
  // web server software on the hosts (4.7.3): IIS on Windows, nginx / Apache / Tomcat / HAProxy on Linux
  function webHosts() {
    const W = (Name, Product, more) => Object.assign({ Name, OS: /^LNX|^MON/.test(Name) ? 'Linux Ubuntu 22.04.5 LTS' : 'Microsoft Windows Server 2022 Standard', Product, Service: null, Running: true, Enabled: true, Version: null, Ports: null, Sites: null, SitesStopped: null, Connections: null, RequestsPerSec: null, Workers: null, BusyWorkers: null, ConfigOk: null, ConfigMessage: null, Errors: 0, Since: null }, more);
    const rows = [
      W('WEB01', 'IIS', { Service: 'W3SVC', Version: '10.0', Ports: '80,443', Sites: 4, SitesStopped: 0, Connections: int(120, 340), RequestsPerSec: round(int(40, 140) / 1), Workers: 5, Errors: 0 }),
      W('WEB02', 'IIS', { Service: 'W3SVC', Version: '10.0', Ports: '80,443', Sites: 3, SitesStopped: 1, Connections: int(40, 110), RequestsPerSec: int(8, 40), Workers: 4, Errors: 2 }),
      W('WEB03', 'IIS', { Service: 'W3SVC', Version: '10.0', Ports: '443', Sites: 2, SitesStopped: 0, Connections: int(10, 60), RequestsPerSec: int(2, 20), Workers: 2, Errors: 0 }),
      W('ERP01', 'IIS', { Service: 'W3SVC', Version: '10.0', Ports: '443,8443', Sites: 1, SitesStopped: 0, Connections: int(30, 90), RequestsPerSec: int(5, 30), Workers: 3, Errors: 0 }),
      W('ERP01', 'Apache Tomcat', { Service: 'Tomcat9', Version: '9.0.93', Ports: '8080,8005', Connections: int(10, 50), Workers: 1 }),
      W('LNX-WEB01', 'nginx', { Service: 'nginx.service', Version: '1.24.0', Ports: '80,443', Sites: 6, Connections: int(300, 900), ConfigOk: true, Errors: int(3, 30) }),
      W('LNX-WEB01', 'HAProxy', { Service: 'haproxy.service', Version: '2.8.5', Ports: '8404,443', Sites: 3, ConfigOk: true, Errors: 0 }),
      W('LNX-WEB02', 'Apache httpd', { Service: 'apache2.service', Version: '2.4.58', Ports: '80,443', Sites: 4, Connections: 142, RequestsPerSec: 31.4, Workers: 150, BusyWorkers: 142, ConfigOk: false, ConfigMessage: 'AH00526: Syntax error on line 41 of /etc/apache2/sites-enabled/legacy-crm.conf: Invalid command \'SSLProtocoll\'', Errors: 212 }),
      W('LNX-WEB02', 'nginx', { Service: 'nginx.service', Running: false, Enabled: true, Version: '1.24.0', Ports: null, ConfigOk: true, Errors: 4 }),
      W('MON01', 'Caddy', { Service: 'caddy.service', Version: '2.8.4', Ports: '443', Errors: 0 }),
      W('LNX-WEB01', 'Node.js', { Service: '(process)', Version: '22.11.0', Ports: '3000,3001', Connections: int(20, 90), Workers: 4 }),
      W('LNX-WEB01', 'Varnish', { Service: 'varnish.service', Version: '7.5.0', Ports: '6081,6082', Connections: int(100, 400), Workers: 2 }),
      W('LNX-WEB02', 'PHP-FPM', { Service: 'php8.3-fpm.service', Version: '8.3.12', Ports: null, Workers: 12, Errors: int(0, 6) }),
      W('LNX-WEB02', 'LiteSpeed', { Service: 'lsws.service', Version: '6.3.1', Ports: '8088,7080', Connections: int(5, 40), Workers: 3, Errors: 0 }),
      W('MON01', 'Gunicorn', { Service: 'gunicorn.service', Version: '22.0.0', Ports: '8000', Connections: int(2, 12), Workers: 5 }),
      W('ERP01', 'Oracle WebLogic', { Service: 'WebLogicAdminServer', Version: '14.1.1.0', Ports: '7001,7002', Connections: int(20, 80), Workers: 1 }),
      W('ERP01', 'Eclipse Jetty', { Service: null, Version: '12.0.14', Ports: '8181', Connections: int(1, 10), Workers: 1 }),
      W('WEB02', 'Kestrel (.NET)', { Service: null, Version: '8.0.11', Ports: '5000,5001', Connections: int(10, 60), Workers: 2 }),
      W('WEB03', 'WildFly / JBoss EAP', { Service: 'WildFly', Running: false, Enabled: true, Version: '33.0.2', Ports: null, Errors: 3 }),
      W('SCCM01', 'IIS', { Service: 'W3SVC', Version: '10.0', Ports: '80,443,8530,8531', Sites: 3, SitesStopped: 0, Connections: int(20, 80), RequestsPerSec: int(4, 25), Workers: 6, Errors: 0 }),
    ].map((r) => {
      const p = []; if (r.Running === false) p.push('not running'); if (r.ConfigOk === false) p.push('configuration test failed'); if (r.SitesStopped) p.push(r.SitesStopped + ' site(s) stopped'); if (r.Errors >= 50) p.push(r.Errors + ' errors in 60 min'); if (r.Workers && r.BusyWorkers >= 0.9 * r.Workers) p.push(r.BusyWorkers + ' of ' + r.Workers + ' workers busy');
      return Object.assign(r, { Status: r.Running === false ? 'Critical' : p.length ? 'Warning' : 'OK', Message: p.length ? p.join(', ') : ['running', r.Version, r.Ports ? 'ports ' + r.Ports : null, r.Connections != null ? r.Connections + ' connections' : null].filter(Boolean).join(' · ') });
    });
    return env('web.hosts', rows, { hosts: new Set(rows.map((r) => r.Name)).size, servers: rows.length, down: rows.filter((r) => r.Running === false).length, byProduct: Object.entries(rows.reduce((a, r) => ((a[r.Product] = (a[r.Product] || 0) + 1), a), {})).map(([name, count]) => ({ name, count })) });
  }
  // managed databases in the clouds (4.7.3)
  function cloudDatabases() {
    const D = (Provider, Account, Region, Service, Engine, Category, Name, more) => {
      const r = Object.assign({ Provider, Account, Region, Service, Engine, Category, Name, Id: null, Version: null, Tier: null, State: 'Available', Running: true, StorageGB: null, UsedPct: null, CpuPct: null, HighAvailability: null, Replicas: null, BackupDays: null, PublicAccess: false, Encrypted: true, Actions: null }, more);
      const p = []; if (r.Running === false) p.push('state ' + r.State); if (r.CpuPct >= 80) p.push('CPU ' + Math.round(r.CpuPct) + '%'); if (r.UsedPct >= 85) p.push('storage ' + Math.round(r.UsedPct) + '% used'); if (r.BackupDays === 0) p.push('no automated backups'); if (r.PublicAccess) p.push('reachable from the internet'); if (r.Encrypted === false) p.push('storage not encrypted');
      r.Status = r.Running === false && !/stop|paus/i.test(r.State) ? 'Critical' : r.CpuPct >= 95 || r.UsedPct >= 95 ? 'Critical' : p.length ? 'Warning' : 'OK';
      r.Message = p.length ? p.join(', ') : [r.Engine, r.Version, r.Tier].filter(Boolean).join(' · ');
      return r;
    };
    const sub = '7c3a2f4e-0000-4b8a-a6e2-3f0c5d9b1e74', az = (t, n) => '/subscriptions/' + sub + '/resourceGroups/rg-data/providers/' + t + '/' + n;
    const rows = [
      D('Azure', sub, 'westeurope', 'Azure SQL Database', 'SQL Server', 'SQL PaaS', 'sql-erp-weu/erpdb', { Id: az('Microsoft.Sql/servers', 'sql-erp-weu/databases/erpdb'), Version: '12.0', Tier: 'GeneralPurpose GP_Gen5 (8)', State: 'Online', StorageGB: 500, UsedPct: 71, CpuPct: int(30, 70), HighAvailability: 'Zone redundant', Actions: 'Failover' }),
      D('Azure', sub, 'westeurope', 'Azure SQL Database', 'SQL Server', 'SQL PaaS', 'sql-erp-weu/reporting', { Id: az('Microsoft.Sql/servers', 'sql-erp-weu/databases/reporting'), Version: '12.0', Tier: 'Standard S3 (100)', State: 'Online', StorageGB: 250, UsedPct: 88, CpuPct: 84, HighAvailability: 'Local', PublicAccess: true, Actions: 'Failover' }),
      D('Azure', sub, 'westeurope', 'Azure SQL Managed Instance', 'SQL Server', 'SQL PaaS', 'sqlmi-core', { Id: az('Microsoft.Sql/managedInstances', 'sqlmi-core'), Version: 'Managed Instance', Tier: 'BusinessCritical 16 vCores', State: 'Ready', StorageGB: 2048, UsedPct: 54, CpuPct: int(20, 50), HighAvailability: 'Built-in', Actions: 'Start,Stop' }),
      D('Azure', sub, 'westeurope', 'Azure Database for PostgreSQL', 'PostgreSQL', 'Open-source PaaS', 'pg-portal', { Id: az('Microsoft.DBforPostgreSQL/flexibleServers', 'pg-portal'), Version: '16', Tier: 'GeneralPurpose Standard_D4ds_v5', State: 'Ready', StorageGB: 256, UsedPct: 42, CpuPct: int(10, 40), HighAvailability: 'ZoneRedundant (Healthy)', BackupDays: 14, Actions: 'Start,Stop,Restart,Failover' }),
      D('Azure', sub, 'westeurope', 'Azure Database for MySQL', 'MySQL', 'Open-source PaaS', 'mysql-wordpress', { Id: az('Microsoft.DBforMySQL/flexibleServers', 'mysql-wordpress'), Version: '8.0.21', Tier: 'Burstable Standard_B2s', State: 'Stopped', Running: false, StorageGB: 64, HighAvailability: 'None', BackupDays: 7, PublicAccess: true, Actions: 'Start,Stop,Restart' }),
      D('Azure', sub, 'westeurope', 'Azure Cosmos DB', 'Cosmos DB (MongoDB)', 'Document', 'cosmos-orders', { Id: az('Microsoft.DocumentDB/databaseAccounts', 'cosmos-orders'), Version: '6.0', Tier: 'Provisioned', State: 'Succeeded', HighAvailability: '2 region(s), automatic failover', Replicas: 2, BackupDays: 30 }),
      D('Azure', sub, 'westeurope', 'Azure Cosmos DB', 'Cosmos DB (NoSQL)', 'Document', 'cosmos-catalog', { Id: az('Microsoft.DocumentDB/databaseAccounts', 'cosmos-catalog'), Tier: 'Serverless', State: 'Succeeded', HighAvailability: '1 region(s)', Replicas: 1, BackupDays: 0.3 }),
      D('Azure', sub, 'westeurope', 'Azure Cache for Redis', 'Redis', 'Key-value', 'redis-sessions', { Id: az('Microsoft.Cache/redis', 'redis-sessions'), Version: '6.0', Tier: 'Standard C2', State: 'Succeeded', HighAvailability: '2 nodes', Actions: 'Restart' }),
      D('AWS', '111122223333', 'eu-central-1', 'Amazon RDS', 'SQL Server', 'SQL PaaS', 'crm-sqlserver', { Id: 'arn:aws:rds:eu-central-1:111122223333:db:crm-sqlserver', Version: '15.00.4365.2', Tier: 'db.m6i.xlarge', State: 'available', StorageGB: 200, UsedPct: 91, CpuPct: int(20, 45), HighAvailability: 'Multi-AZ', Replicas: 0, BackupDays: 7, Actions: 'Start,Stop,Restart,Failover' }),
      D('AWS', '111122223333', 'eu-central-1', 'Amazon RDS', 'Oracle', 'SQL PaaS', 'billing-oracle', { Id: 'arn:aws:rds:eu-central-1:111122223333:db:billing-oracle', Version: '19.0.0.0.ru-2024-07', Tier: 'db.r6i.2xlarge', State: 'available', StorageGB: 1000, UsedPct: 63, CpuPct: int(15, 50), HighAvailability: 'Multi-AZ', Replicas: 0, BackupDays: 14, Actions: 'Start,Stop,Restart,Failover' }),
      D('AWS', '111122223333', 'eu-central-1', 'Amazon Aurora cluster', 'Aurora PostgreSQL', 'Open-source PaaS', 'shop-aurora', { Id: 'arn:aws:rds:eu-central-1:111122223333:cluster:shop-aurora', Version: '15.4', Tier: 'provisioned', State: 'available', HighAvailability: 'Multi-AZ', Replicas: 2, BackupDays: 7, Actions: 'Start,Stop,Failover' }),
      D('AWS', '111122223333', 'eu-central-1', 'Amazon RDS', 'MariaDB', 'Open-source PaaS', 'wiki-mariadb', { Id: 'arn:aws:rds:eu-central-1:111122223333:db:wiki-mariadb', Version: '10.11.8', Tier: 'db.t4g.medium', State: 'available', StorageGB: 50, UsedPct: 38, CpuPct: int(2, 12), HighAvailability: 'Single-AZ', BackupDays: 0, PublicAccess: true, Encrypted: false, Actions: 'Start,Stop,Restart' }),
      D('AWS', '111122223333', 'eu-central-1', 'Amazon DocumentDB cluster', 'DocumentDB (MongoDB)', 'Document', 'docs-cluster', { Id: 'arn:aws:rds:eu-central-1:111122223333:cluster:docs-cluster', Version: '5.0.0', Tier: 'provisioned', State: 'available', HighAvailability: 'Multi-AZ', Replicas: 1, BackupDays: 7, Actions: 'Start,Stop,Failover' }),
      D('AWS', '111122223333', 'eu-central-1', 'Amazon DynamoDB', 'DynamoDB', 'Key-value', 'user-sessions', { Id: 'arn:aws:dynamodb:eu-central-1:111122223333:table/user-sessions', Tier: 'On-demand', State: 'ACTIVE', StorageGB: 4.2, HighAvailability: 'Regional (3 AZ)', Replicas: 0 }),
      D('Google Cloud', 'moncastle-prod', 'europe-west1', 'Cloud SQL', 'PostgreSQL', 'Open-source PaaS', 'pg-analytics', { Id: 'moncastle-prod/pg-analytics', Version: '15', Tier: 'db-custom-4-16384', State: 'RUNNABLE', StorageGB: 100, HighAvailability: 'Regional (HA)', Replicas: 1, BackupDays: 7, PublicAccess: true, Actions: 'Start,Stop,Restart,Failover' }),
      D('Google Cloud', 'moncastle-prod', 'europe-west1', 'Cloud SQL', 'SQL Server', 'SQL PaaS', 'mssql-hr', { Id: 'moncastle-prod/mssql-hr', Version: '2019.STANDARD', Tier: 'db-custom-2-8192', State: 'RUNNABLE', StorageGB: 50, HighAvailability: 'Zonal', BackupDays: 7, Actions: 'Start,Stop,Restart' }),
      D('Google Cloud', 'moncastle-prod', 'europe-west1', 'Cloud Spanner', 'Spanner', 'SQL PaaS', 'ledger', { Id: 'projects/moncastle-prod/instances/ledger', Tier: '1000 processing units', State: 'READY', HighAvailability: 'regional-europe-west1' }),
      D('Google Cloud', 'moncastle-prod', 'eur3', 'Firestore', 'Firestore', 'Document', '(default)', { Id: 'projects/moncastle-prod/databases/(default)', Tier: 'FIRESTORE_NATIVE', State: 'Active', HighAvailability: 'Multi-region' }),
      D('Oracle Cloud', 'ocid1.compartment.oc1..prod', 'me-jeddah-1', 'Autonomous Database', 'Oracle', 'SQL PaaS', 'ADB-ERP', { Id: 'ocid1.autonomousdatabase.oc1.me-jeddah-1.adb1', Version: '19c', Tier: 'Transaction Processing · 4 ECPU', State: 'AVAILABLE', StorageGB: 1024, UsedPct: 92, CpuPct: 41, HighAvailability: 'Data Guard', BackupDays: 60, Actions: 'Start,Stop,Restart,Failover' }),
      D('Oracle Cloud', 'ocid1.compartment.oc1..prod', 'me-jeddah-1', 'Autonomous Database', 'Oracle', 'Document', 'AJD-CATALOG', { Id: 'ocid1.autonomousdatabase.oc1.me-jeddah-1.ajd1', Version: '23ai', Tier: 'JSON · 2 ECPU', State: 'STOPPED', Running: false, StorageGB: 20, HighAvailability: 'Built-in', BackupDays: 60, Actions: 'Start,Stop,Restart' }),
      D('Oracle Cloud', 'ocid1.compartment.oc1..prod', 'me-jeddah-1', 'MySQL HeatWave', 'MySQL', 'Open-source PaaS', 'heatwave-bi', { Id: 'ocid1.mysqldbsystem.oc1.me-jeddah-1.m1', Version: '8.4.0', Tier: 'MySQL.4', State: 'ACTIVE', StorageGB: 100, HighAvailability: 'High availability', BackupDays: 7, Actions: 'Start,Stop,Restart' }),
      D('Huawei Cloud', 'proj-me-east-1', 'me-east-1', 'RDS', 'PostgreSQL', 'Open-source PaaS', 'rds-billing', { Id: 'hw-rds-7f21a', Version: '14', Tier: 'rds.pg.n1.large.2.ha', State: 'ACTIVE', StorageGB: 200, HighAvailability: 'Primary/standby', BackupDays: 7, Actions: 'Start,Stop,Restart,Failover' }),
      D('Huawei Cloud', 'proj-me-east-1', 'me-east-1', 'GaussDB', 'GaussDB', 'SQL PaaS', 'gauss-core', { Id: 'hw-gauss-41c0', Version: '8.201', Tier: 'gaussdb.opengauss.ee.dn.m6.2xlarge.8', State: 'ACTIVE', StorageGB: 480, HighAvailability: 'centralization_standard', BackupDays: 7 }),
      D('Huawei Cloud', 'proj-me-east-1', 'me-east-1', 'Document Database (DDS)', 'MongoDB', 'Document', 'dds-catalog', { Id: 'hw-dds-0c9e', Version: '4.4', Tier: 'ReplicaSet', State: 'normal', HighAvailability: 'ReplicaSet', BackupDays: 7, Actions: 'Restart' }),
    ];
    const g = (k) => Object.entries(rows.reduce((a, r) => ((a[r[k]] = (a[r[k]] || 0) + 1), a), {})).map(([name, count]) => ({ name, count }));
    return env('cloud.databases', rows, { databases: rows.length, down: rows.filter((r) => r.Running === false).length, warnings: rows.filter((r) => r.Status !== 'OK').length, byProvider: g('Provider'), byEngine: g('Engine') });
  }
  function sslCerts(now = NOW()) {
    const list = [['portal.' + DOMAIN, 443, 'CN=portal.' + DOMAIN, 'CN=CORP-ROOT-CA', 212, true, true, 2048, 'TLS 1.3'], ['intranet.' + DOMAIN, 443, 'CN=intranet.' + DOMAIN, 'CN=CORP-ROOT-CA', 19, true, true, 2048, 'TLS 1.3'], ['shop.moncastle-demo.com', 443, 'CN=shop.moncastle-demo.com', "CN=R11, O=Let's Encrypt", 54, true, true, 2048, 'TLS 1.3'], ['api.moncastle-demo.com', 443, 'CN=*.moncastle-demo.com', 'CN=Sectigo RSA Domain Validation Secure Server CA', 4, true, true, 2048, 'TLS 1.2'], ['mail.' + DOMAIN, 443, 'CN=mail.' + DOMAIN, 'CN=CORP-ROOT-CA', 301, true, true, 4096, 'TLS 1.2'], ['legacy-crm.' + DOMAIN, 8443, 'CN=localhost', 'CN=localhost', -12, false, false, 1024, 'TLS 1.0'], ['vpn.moncastle-demo.com', 443, 'CN=vpn.moncastle-demo.com', 'CN=DigiCert Global G2 TLS RSA SHA256 2020 CA1', 88, true, true, 2048, 'TLS 1.2']];
    const rows = list.map(([n, port, subj, iss, days, trusted, match, bits, proto]) => {
      const p = [days < 0 ? 'expired ' + -days + ' days ago' : days + ' days left', !trusted ? 'chain not trusted' : null, !match ? 'name does not match' : null, bits < 2048 ? bits + '-bit key' : null, /1\.[01]$/.test(proto) ? proto : null].filter(Boolean);
      return { Name: n, Port: port, Subject: subj, Issuer: iss, NotBefore: iso(now - (365 - days) * D), NotAfter: iso(now + days * D), DaysLeft: days, Names: subj.replace('CN=', ''), NameMatch: match, Trusted: trusted, SelfSigned: subj === iss, KeyBits: bits, Signature: 'sha256RSA', Protocol: proto, Cipher: 'TLS_AES_256_GCM_SHA384', Thumbprint: Array.from({ length: 20 }, (_, i) => pad(((n.length * 7 + i * 13) % 255).toString(16))).join('').toUpperCase(), Status: days < 7 || !trusted ? 'Critical' : days < 30 || bits < 2048 || !match ? 'Warning' : 'OK', Message: p.join(', ') };
    });
    return env('ssl.certificates', rows, { endpoints: rows.length, expiring: rows.filter((r) => r.DaysLeft < 30).length });
  }
  function temperature() {
    const rows = [];
    const t = (name, sensor, source, c, w, cr) => rows.push({ Name: name, Sensor: sensor, Source: source, Celsius: c, WarningC: w, CriticalC: cr, Status: st(c, w, cr), Message: sensor + ' ' + c + ' °C' });
    for (const s of servers.filter((x) => physical.has(x.name))) { const hot = s.name === 'HV03' ? 22 : 0; t(s.name, 'CPU 1', 'Redfish (iDRAC)', 54 + hot + int(0, 6), 85, 95); t(s.name, 'CPU 2', 'Redfish (iDRAC)', 52 + hot + int(0, 6), 85, 95); t(s.name, 'System board inlet', 'Redfish (iDRAC)', 22 + int(0, 4) + (hot ? 9 : 0), 42, 47); t(s.name, 'Exhaust', 'Redfish (iDRAC)', 36 + int(0, 6) + hot / 2, 70, 75); }
    for (const site of SITES) { const tt = site.split('-')[0].slice(0, 2).toUpperCase(); t('CORE-SW-' + tt + '01', 'Switch 1 - Inlet Temp Sensor', 'CISCO-ENVMON', site === 'Branch-South' ? 47 : 29 + int(0, 6), 46, 56); t('CORE-SW-' + tt + '01', 'Switch 1 - Hotspot', 'CISCO-ENVMON', 41 + int(0, 8), 105, 125); t('FW-' + tt + '01', 'CPU', 'ENTITY-SENSOR', 48 + int(0, 10), 85, 95); }
    t('NAS01', 'System', 'Synology', 41, 60, 70); t('NAS01', 'Disk 3', 'Synology', 46, 55, 63); t('NAS02', 'System', 'ENTITY-SENSOR', 39, 60, 70);
    t('UPS-HQ01', 'Battery', 'APC PowerNet', 27, 40, 45); t('ENV-HQ-DC1', 'Rack A3 front', 'NetBotz', 24, 27, 32); t('ENV-HQ-DC1', 'Rack A3 rear', 'NetBotz', 33, 38, 45);
    for (const [n] of linuxDefs.filter(([x]) => /^K8S|^NFS/.test(x))) t(n, 'thermal_zone0 (x86_pkg_temp)', 'Linux sysfs', n === 'K8S-NODE03' ? 79 : 46 + int(0, 10), 80, 95);
    rows.push({ Name: 'LNX-WEB01', Sensor: null, Source: 'Linux sysfs', Celsius: null, WarningC: null, CriticalC: null, Status: 'Unknown', Message: 'No temperature sensors exposed (virtual machine)' });
    return env('hardware.temperature', rows, { devices: new Set(rows.map((r) => r.Name)).size, sensors: rows.length, hot: rows.filter((r) => r.Status !== 'OK' && r.Status !== 'Unknown').length });
  }
  function kubernetes() {
    const rows = [];
    const clusters = [['aks-prod-weu', 'https://aks-prod-weu-dns-4f1a.hcp.westeurope.azmk8s.io', 'v1.30.4', ['aks-system-0', 'aks-user-0', 'aks-user-1', 'aks-user-2']], ['k8s-onprem', 'https://10.10.3.10:6443', 'v1.29.8', ['K8S-NODE01', 'K8S-NODE02', 'K8S-NODE03']], ['eks-dr-euc1', 'https://4B2E.gr7.eu-central-1.eks.amazonaws.com', 'v1.30.2', ['ip-10-60-1-12.eu-central-1.compute.internal', 'ip-10-60-2-31.eu-central-1.compute.internal']]];
    const apps = [['shop', 'Deployment', 'storefront', 6], ['shop', 'Deployment', 'checkout', 3], ['shop', 'StatefulSet', 'redis', 3], ['platform', 'Deployment', 'ingress-nginx-controller', 2], ['platform', 'DaemonSet', 'node-exporter', 0], ['monitoring', 'StatefulSet', 'prometheus', 2], ['erp', 'Deployment', 'erp-api', 4], ['erp', 'Deployment', 'erp-worker', 2]];
    clusters.forEach(([c, addr, ver, nodes], ci) => {
      let pods = 0, failing = 0, degraded = 0;
      nodes.forEach((nd, i) => { const bad = c === 'k8s-onprem' && i === 2, p = int(14, 40); pods += p; rows.push({ Kind: 'Node', Cluster: c, Name: nd, Address: c === 'k8s-onprem' ? ip('HQ-Main', 3, 24 + i) : '10.' + (60 + ci) + '.' + (i + 1) + '.' + (10 + i), Roles: i === 0 && c === 'k8s-onprem' ? 'control-plane' : 'worker', Version: ver, OS: c === 'k8s-onprem' ? 'Rocky Linux 9.3 (Blue Onyx)' : c.startsWith('aks') ? 'Ubuntu 22.04.4 LTS' : 'Amazon Linux 2023', Ready: !bad, Unschedulable: false, Pressure: bad ? 'MemoryPressure' : null, CPUPct: bad ? 96 : int(18, 70), MemoryPct: bad ? 93 : int(30, 78), Pods: p, Status: bad ? 'Critical' : 'OK', Message: bad ? 'NotReady, MemoryPressure' : 'Ready' }); });
      for (const [ns, kind, n, desired0] of apps) {
        if (ci === 2 && ns === 'erp') continue;
        const desired = kind === 'DaemonSet' ? nodes.length : ci === 2 ? 1 : desired0;
        const ready = c === 'k8s-onprem' && n === 'checkout' ? 1 : c === 'k8s-onprem' && kind === 'DaemonSet' ? desired - 1 : c === 'aks-prod-weu' && n === 'erp-worker' ? 0 : desired;
        if (ready < desired) degraded++;
        rows.push({ Kind: kind, Cluster: c, Namespace: ns, Name: n, Desired: desired, ReadyCount: ready, Images: 'registry.moncastle-demo.com/' + n + ':' + (ci + 3) + '.2.' + int(0, 9), Status: ready === 0 && desired ? 'Critical' : ready < desired ? 'Warning' : 'OK', Message: ready + ' of ' + desired + ' ready' });
        if (ready < desired) { failing++; rows.push({ Kind: 'Pod', Cluster: c, Namespace: ns, Name: n + '-' + (7000 + ci * 111 + n.length).toString(36) + '-x' + ci, Node: nodes[nodes.length - 1], Phase: 'Running', Reason: n === 'erp-worker' ? 'CrashLoopBackOff' : kind === 'DaemonSet' ? 'Pending' : 'ImagePullBackOff', Restarts: n === 'erp-worker' ? 37 : 0, Status: 'Critical', Message: n === 'erp-worker' ? 'CrashLoopBackOff, 37 restarts' : kind === 'DaemonSet' ? 'Pending: node not ready' : 'ImagePullBackOff' }); }
      }
      if (ci === 0) rows.push({ Kind: 'PVC', Cluster: c, Namespace: 'erp', Name: 'erp-reports', StorageClass: 'managed-csi', Phase: 'Pending', Status: 'Warning', Message: 'Pending: waiting for first consumer' });
      const nn = rows.filter((r) => r.Cluster === c && r.Kind === 'Node'), ready = nn.filter((r) => r.Ready).length;
      rows.push({ Kind: 'Cluster', Cluster: c, Name: c, Address: addr, Version: ver, Nodes: nn.length, NodesReady: ready, Pods: pods, PodsRunning: pods - failing, PodsFailing: failing, Workloads: rows.filter((r) => r.Cluster === c && /Deployment|StatefulSet|DaemonSet/.test(r.Kind)).length, WorkloadsDegraded: degraded, PvcPending: ci === 0 ? 1 : 0, WarningEvents1h: ci === 1 ? 64 : int(2, 20), TopEvents: ci === 1 ? ['NodeNotReady (12)', 'FailedScheduling (9)', 'BackOff (7)'] : ['BackOff (' + int(1, 9) + ')'], CPUPct: round(nn.reduce((a, r) => a + r.CPUPct, 0) / nn.length), MemoryPct: round(nn.reduce((a, r) => a + r.MemoryPct, 0) / nn.length), Status: ready < nn.length || failing > 1 ? 'Critical' : failing || degraded ? 'Warning' : 'OK', Message: ready + ' of ' + nn.length + ' nodes ready, ' + failing + ' failing pods, ' + degraded + ' degraded workloads' });
    });
    const cl = rows.filter((r) => r.Kind === 'Cluster');
    return env('containers.kubernetes', rows, { clusters: cl.length, nodes: cl.reduce((a, r) => a + r.Nodes, 0), failingPods: cl.reduce((a, r) => a + r.PodsFailing, 0) });
  }
  function docker() {
    const rows = [];
    const hosts = [['MON01', 'Docker', '27.3.1', [['prometheus', 'prom/prometheus:v2.54.1', 'running', 'healthy', 0, 7, 41], ['grafana', 'grafana/grafana:11.2.0', 'running', 'healthy', 0, 2, 22], ['alertmanager', 'prom/alertmanager:v0.27.0', 'running', null, 0, 1, 6], ['loki', 'grafana/loki:3.1.1', 'restarting', null, 14, 0, 0]]], ['LNX-WEB01', 'Docker', '26.1.4', [['nginx-proxy', 'nginx:1.27-alpine', 'running', 'healthy', 0, 3, 4], ['portal-app', 'registry.moncastle-demo.com/portal:2.8.1', 'running', 'unhealthy', 2, 64, 88], ['certbot', 'certbot/certbot:v2.11.0', 'exited', null, 0, 0, 0]]], ['LNX-WEB02', 'Podman', '4.9.4', [['nginx-proxy', 'docker.io/library/nginx:1.27-alpine', 'running', null, 0, 2, 3], ['portal-app', 'registry.moncastle-demo.com/portal:2.8.1', 'running', 'healthy', 0, 31, 52]]]];
    for (const [h, engine, ver, cs] of hosts) {
      for (const [n, img, state, health, rs, cpu, mem] of cs) { const policy = n === 'certbot' ? 'no' : 'unless-stopped', bad = state === 'restarting' || health === 'unhealthy'; rows.push({ Kind: 'Container', Host: h, Engine: engine, Name: n, Image: img, State: state, Health: health, RestartPolicy: policy, Restarts: rs, ExitCode: state === 'exited' ? 0 : state === 'restarting' ? 1 : null, CPUPct: cpu, MemoryPct: mem, Ports: /nginx/.test(n) ? '0.0.0.0:443->443/tcp' : n === 'grafana' ? '0.0.0.0:3000->3000/tcp' : null, Status: state === 'restarting' ? 'Critical' : bad ? 'Warning' : 'OK', Message: state + (health ? ' (' + health + ')' : '') + (rs ? ', ' + rs + ' restarts' : '') }); }
      const list = rows.filter((r) => r.Host === h);
      rows.push({ Kind: 'Host', Host: h, Engine: engine, Name: h, Version: ver, Containers: list.length, Running: list.filter((r) => r.State === 'running').length, Images: list.length + int(2, 9), Status: list.some((r) => r.Status === 'Critical') ? 'Critical' : list.some((r) => r.Status === 'Warning') ? 'Warning' : 'OK', Message: list.filter((r) => r.State === 'running').length + ' of ' + list.length + ' containers running' });
    }
    return env('containers.docker', rows, { hosts: hosts.length, containers: rows.filter((r) => r.Kind === 'Container').length, problems: rows.filter((r) => r.Kind === 'Container' && r.Status !== 'OK').length });
  }
  function cloudNetwork(now = NOW()) {
    const rows = [];
    const r = (o) => rows.push(Object.assign({ Provider: null, Account: null, Region: null, Kind: null, Name: null, Id: null, Address: null, Gateway: null, Peer: null, State: null, Mode: null, Rules: null, BytesIn: null, BytesOut: null, User: null, ClientIp: null, ConnectedSince: null, Status: 'OK', Message: '' }, o, { Type: o.Kind }));
    const az = { Provider: 'Azure', Account: 'Production (sub 3f1a…)', Region: 'westeurope' }, aws = { Provider: 'AWS', Account: '4410-…-7781', Region: 'eu-central-1' }, gcp = { Provider: 'Google Cloud', Account: 'moncastle-prod', Region: 'europe-west1' }, oci = { Provider: 'Oracle Cloud', Account: 'moncastle (tenancy)', Region: 'eu-frankfurt-1' }, hw = { Provider: 'Huawei Cloud', Account: 'moncastle-me', Region: 'me-east-1' };
    const A = (p, o) => r(Object.assign(o, p));
    A(az, { Kind: 'Firewall', Name: 'azfw-hub-weu', Id: '/subscriptions/3f1a9c2e-5b7d-4e11-9a0c-7d2b8e4f6a10/resourceGroups/rg-hub/providers/Microsoft.Network/azureFirewalls/azfw-hub-weu', Address: '20.86.14.22', State: 'Succeeded', Mode: 'Premium, threat intel Deny', Rules: 42, Message: 'Running, policy fwpol-hub' });
    A(az, { Kind: 'WAF', Name: 'waf-portal', Id: '/subscriptions/3f1a9c2e-5b7d-4e11-9a0c-7d2b8e4f6a10/resourceGroups/rg-hub/providers/Microsoft.Network/ApplicationGatewayWebApplicationFirewallPolicies/waf-portal', State: 'Enabled', Mode: 'Prevention', Rules: 'OWASP 3.2 + 6 custom', Message: 'Enabled in Prevention mode' });
    A(az, { Kind: 'WAF', Name: 'waf-legacy', Id: '/subscriptions/3f1a9c2e-5b7d-4e11-9a0c-7d2b8e4f6a10/resourceGroups/rg-hub/providers/Microsoft.Network/ApplicationGatewayWebApplicationFirewallPolicies/waf-legacy', State: 'Enabled', Mode: 'Detection', Rules: 'OWASP 3.1', Status: 'Warning', Message: 'Detection mode only: attacks are logged, not blocked' });
    A(az, { Kind: 'VPN gateway', Name: 'vgw-hub-weu', Id: '/subscriptions/3f1a9c2e-5b7d-4e11-9a0c-7d2b8e4f6a10/resourceGroups/rg-hub/providers/Microsoft.Network/virtualNetworkGateways/vgw-hub-weu', Address: '20.86.14.40', State: 'Succeeded', Mode: 'RouteBased VpnGw2AZ, P2S on', Message: '2 of 2 tunnels connected, 3 P2S clients' });
    A(az, { Kind: 'VPN tunnel', Name: 'cn-hq-to-azure', Id: '/subscriptions/3f1a9c2e-5b7d-4e11-9a0c-7d2b8e4f6a10/resourceGroups/rg-hub/providers/Microsoft.Network/connections/cn-hq-to-azure', Gateway: 'vgw-hub-weu', Peer: '41.33.12.9', State: 'Connected', BytesIn: 98213345221, BytesOut: 45120992113, Message: 'Connected' });
    A(az, { Kind: 'VPN tunnel', Name: 'cn-dr-to-azure', Id: '/subscriptions/3f1a9c2e-5b7d-4e11-9a0c-7d2b8e4f6a10/resourceGroups/rg-hub/providers/Microsoft.Network/connections/cn-dr-to-azure', Gateway: 'vgw-hub-weu', Peer: '41.33.80.4', State: 'Connected', BytesIn: 2213345221, BytesOut: 1120992113, Message: 'Connected' });
    ['admin.marco', 'n.adel', 'k.samir'].forEach((u, i) => A(az, { Kind: 'VPN client', Name: u + '@' + DOMAIN, Id: '/subscriptions/3f1a9c2e-5b7d-4e11-9a0c-7d2b8e4f6a10/resourceGroups/rg-hub/providers/Microsoft.Network/virtualNetworkGateways/vgw-hub-weu', Gateway: 'vgw-hub-weu', User: u + '@' + DOMAIN, ClientIp: '172.16.201.' + (10 + i), Address: '156.204.' + (30 + i) + '.' + (7 + i * 9), ConnectedSince: iso(now - (i + 1) * 2.3 * H), BytesIn: int(1e7, 9e8), BytesOut: int(1e6, 9e7), Message: 'Connected ' + round((i + 1) * 2.3) + ' h' }));
    A(aws, { Kind: 'Firewall', Name: 'nfw-egress', Id: 'arn:aws:network-firewall:eu-central-1:…:firewall/nfw-egress', State: 'READY', Mode: 'policy egress-strict', Rules: 3, Message: 'READY, in sync' });
    A(aws, { Kind: 'WAF', Name: 'shop-acl', Id: 'arn:aws:wafv2:eu-central-1:…:regional/webacl/shop-acl', State: 'Enabled', Mode: 'Default Allow', Rules: 7, Message: '7 rules, default action Allow' });
    A(aws, { Kind: 'VPN gateway', Name: 'vpn-0a7c-hq', Id: 'vpn-0a7c41e2', State: 'available', Mode: 'ipsec.1 to cgw 41.33.12.9', Message: '1 of 2 tunnels up' });
    A(aws, { Kind: 'VPN tunnel', Name: 'vpn-0a7c-hq', Id: 'vpn-0a7c41e2', Gateway: 'vpn-0a7c-hq', Address: '3.120.44.10', Peer: '41.33.12.9', State: 'UP', Message: 'UP, 12 BGP routes' });
    A(aws, { Kind: 'VPN tunnel', Name: 'vpn-0a7c-hq', Id: 'vpn-0a7c41e2', Gateway: 'vpn-0a7c-hq', Address: '18.194.7.211', Peer: '41.33.12.9', State: 'DOWN', Status: 'Critical', Message: 'DOWN: IPSEC IS DOWN' });
    A(aws, { Kind: 'VPN gateway', Name: 'cvpn-staff', Id: 'cvpn-endpoint-0f2a6c9b81d3e4f50', State: 'available', Mode: 'Client VPN, SAML', Message: '2 clients connected' });
    ['s.ibrahim', 'o.saleh'].forEach((u, i) => A(aws, { Kind: 'VPN client', Name: u, Id: 'cvpn-endpoint-0f2a6c9b81d3e4f50', Gateway: 'cvpn-staff', User: u, ClientIp: '10.250.0.' + (34 + i), Address: '197.48.' + (2 + i) + '.66', ConnectedSince: iso(now - (i + 1) * 5 * H), Message: 'active' }));
    A(gcp, { Kind: 'Firewall', Name: 'vpc-prod firewall rules', Id: 'projects/moncastle-prod/global/networks/vpc-prod', Rules: 28, Mode: '2 rules open to 0.0.0.0/0 (allow-ssh-any, allow-rdp-any)', Status: 'Warning', Message: '28 rules, 2 allow any source on 22/3389' });
    A(gcp, { Kind: 'WAF', Name: 'armor-shop', Id: 'projects/moncastle-prod/global/securityPolicies/armor-shop', State: 'Enabled', Mode: 'CLOUD_ARMOR, preview off', Rules: 9, Message: '9 rules enforced' });
    A(gcp, { Kind: 'VPN gateway', Name: 'ha-vpn-euw1', Id: 'projects/moncastle-prod/regions/europe-west1/vpnGateways/ha-vpn-euw1', Address: '35.242.1.9', Message: '2 of 2 tunnels established' });
    ['tun-hq-0', 'tun-hq-1'].forEach((n) => A(gcp, { Kind: 'VPN tunnel', Name: n, Id: 'projects/moncastle-prod/regions/europe-west1/vpnTunnels/' + n, Gateway: 'ha-vpn-euw1', Peer: '41.33.12.9', State: 'ESTABLISHED', Message: 'Tunnel is up and running.' }));
    A(oci, { Kind: 'Firewall', Name: 'oci-nfw-hub', Id: 'ocid1.networkfirewall.oc1.eu-frankfurt-1.aaaa…', State: 'ACTIVE', Mode: 'policy hub-pol', Message: 'ACTIVE' });
    A(oci, { Kind: 'WAF', Name: 'oci-waf-erp', Id: 'ocid1.webappfirewall.oc1.eu-frankfurt-1.aaaa…', State: 'ACTIVE', Mode: 'policy erp-protect', Message: 'ACTIVE' });
    A(oci, { Kind: 'VPN gateway', Name: 'ipsec-hq', Id: 'ocid1.ipsecconnection.oc1.eu-frankfurt-1.aaaa…', State: 'AVAILABLE', Message: '2 of 2 tunnels up' });
    ['ipsec-hq tunnel 1', 'ipsec-hq tunnel 2'].forEach((n, i) => A(oci, { Kind: 'VPN tunnel', Name: n, Id: 'ocid1.ipsectunnel.oc1.eu-frankfurt-1.aaaa…' + i, Gateway: 'ipsec-hq', Address: '130.61.0.' + (40 + i), Peer: '41.33.12.9', State: 'UP', Message: 'UP' }));
    A(hw, { Kind: 'Firewall', Name: 'cfw-me1', Id: 'cfw-7d1…', State: 'Normal', Mode: 'Standard edition, IPS on', Message: 'Protection on' });
    A(hw, { Kind: 'WAF', Name: 'waf-shop-me', Id: 'policy 3c2f…', State: 'Enabled', Mode: 'log only', Status: 'Warning', Message: 'Basic protection set to log only' });
    A(hw, { Kind: 'VPN gateway', Name: 'vpngw-me1', Id: 'vgw-51a…', Address: '94.74.80.12', State: 'ACTIVE', Message: '1 of 1 connections up' });
    A(hw, { Kind: 'VPN tunnel', Name: 'vpnc-hq', Id: 'vpnc-9e0…', Gateway: 'vpngw-me1', Address: '94.74.80.12', Peer: '41.33.12.9', State: 'ACTIVE', Message: 'ACTIVE' });
    return env('network.cloud', rows, { firewalls: rows.filter((x) => x.Kind === 'Firewall').length, wafs: rows.filter((x) => x.Kind === 'WAF').length, tunnels: rows.filter((x) => x.Kind === 'VPN tunnel').length, tunnelsDown: rows.filter((x) => x.Kind === 'VPN tunnel' && x.Status !== 'OK').length, clients: rows.filter((x) => x.Kind === 'VPN client').length });
  }

  // ------------------------------------------------------------------ Entra ID and Intune (4.7.2): the tenant the AD users sync to
  const TENANT = '7c3a2f4e-91d5-4b8a-a6e2-3f0c5d9b1e74', TENANT_NAME = 'MonCastle Demo Co.';
  const hash = (s) => { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h; };
  const gid = (s) => { const h = (hash(s) + 0x10000000).toString(16).padStart(8, '0').slice(-8); return h + '-' + h.slice(0, 4) + '-4' + h.slice(1, 4) + '-a' + h.slice(4, 7) + '-' + (h + h).slice(0, 12); };
  // the AD users behind the tenant are random per build: one copy for 30 seconds keeps users, health and Intune in step
  const memo = (fn) => { let at = 0, v = null; return (now = NOW()) => { if (!v || Math.abs(now - at) > 30e3) { v = fn(now); at = now; } return v; }; };
  const entraUsers = memo(function (now) {
    const ad = adUsers(now).data.filter((u) => !/^(svc_|krbtgt|guest|administrator)/i.test(u.SamAccountName));
    const rows = ad.map((u, i) => {
      const h = hash(u.SamAccountName), upn = u.SamAccountName + '@moncastle.example', admin = /^admin\./.test(u.SamAccountName);
      const mfa = admin ? u.SamAccountName !== 'admin.omar' : h % 9 !== 0, risk = h % 41 === 0 ? 'medium' : u.SamAccountName === 'h.fouad' ? 'high' : null;
      const last = u.Enabled ? iso(now - (u.Stale ? 95 + (h % 200) : (h % 7) + 0.2) * D) : null;
      const p = [!u.Enabled ? 'disabled' : null, u.Enabled && u.Stale ? 'no sign-in for ' + (95 + (h % 200)) + ' days' : null, u.Enabled && !mfa ? 'no MFA method registered' : null, risk ? 'risk ' + risk : null].filter(Boolean);
      return { Tenant: TENANT, Id: gid(upn), DisplayName: u.DisplayName, UserPrincipalName: upn, Mail: u.Mail, Enabled: u.Enabled, UserType: 'Member', Department: u.Department, JobTitle: u.Title, Company: u.Company, Office: u.Office, Created: u.Created, LastSignIn: last, DaysSinceSignIn: last ? Math.round((now - Date.parse(last)) / D) : null, Stale: !!(u.Enabled && u.Stale), Synced: true, LastSync: iso(now - 0.4 * H), Licenses: admin ? 1 : 2, MfaRegistered: mfa, Methods: mfa ? (h % 3 ? 'microsoftAuthenticatorPush, softwareOneTimePasscode' : 'fido2, microsoftAuthenticatorPush') : '', Admin: admin, Roles: admin ? (u.SamAccountName === 'admin.marco' ? 'Global Administrator' : u.SamAccountName === 'admin.sara' ? 'Global Administrator, Intune Administrator' : 'User Administrator') : null, Risk: risk, PasswordNeverExpires: u.PasswordNeverExpires, PasswordLastSet: iso(now - u.PasswordAgeDays * D), Status: risk === 'high' || (admin && !mfa) ? 'Critical' : u.Enabled && (u.Stale || !mfa || risk) ? 'Warning' : 'OK', Message: p.join(', ') || 'OK' };
    });
    const cloud = [['Break Glass 1', 'breakglass1@moncastledemo.onmicrosoft.com', 'Member', true, 'Global Administrator', 40], ['Break Glass 2', 'breakglass2@moncastledemo.onmicrosoft.com', 'Member', true, 'Global Administrator', 62], ['Auditor (Contoso)', 'auditor_contoso.com#EXT#@moncastledemo.onmicrosoft.com', 'Guest', null, null, 12], ['Vendor support', 'support_vendor.io#EXT#@moncastledemo.onmicrosoft.com', 'Guest', null, null, 210], ['Teams Room HQ', 'room.hq@moncastle.example', 'Member', false, null, 0.1]];
    cloud.forEach(([dn, upn, type, mfa, role, days]) => rows.push({ Tenant: TENANT, Id: gid(upn), DisplayName: dn, UserPrincipalName: upn, Mail: null, Enabled: true, UserType: type, Department: null, JobTitle: null, Company: null, Office: null, Created: iso(now - 500 * D), LastSignIn: iso(now - days * D), DaysSinceSignIn: Math.round(days), Stale: days > 90, Synced: false, LastSync: null, Licenses: type === 'Guest' ? 0 : 1, MfaRegistered: mfa, Methods: mfa ? 'fido2' : '', Admin: !!role, Roles: role, Risk: null, PasswordNeverExpires: !!role, PasswordLastSet: iso(now - 300 * D), Status: days > 90 || mfa === false ? 'Warning' : 'OK', Message: days > 90 ? 'no sign-in for ' + days + ' days' : mfa === false ? 'no MFA method registered' : 'OK' }));
    const on = rows.filter((r) => r.Enabled);
    return env('entra.users', rows, { users: rows.length, enabled: on.length, guests: rows.filter((r) => r.UserType === 'Guest').length, stale: on.filter((r) => r.Stale).length, noMfa: on.filter((r) => r.MfaRegistered === false).length, admins: rows.filter((r) => r.Admin).length, atRisk: rows.filter((r) => r.Risk).length, synced: rows.filter((r) => r.Synced).length }, now);
  });
  const phones = [['iPhone-Sara', 'iOS', '18.1', 'Apple', 'iPhone 15', 's.ibrahim'], ['iPhone-Omar', 'iOS', '17.6.1', 'Apple', 'iPhone 13', 'o.gamal'], ['iPad-Reception', 'iPadOS', '18.0.1', 'Apple', 'iPad (10th generation)', 'reception'], ['Galaxy-Karim', 'Android', '14', 'samsung', 'SM-S921B', 'k.samir'], ['Pixel-Nour', 'Android', '15', 'Google', 'Pixel 8', 'n.adel'], ['Galaxy-Tab-WH1', 'Android', '13', 'samsung', 'SM-X205', 'warehouse'], ['iPhone-Hassan', 'iOS', '16.7.8', 'Apple', 'iPhone XR', 'h.fouad']];
  const macs = [['MAC-DESIGN01', 'macOS', '15.1', 'Apple', 'MacBook Pro (14-inch, M3)', 'l.saleh'], ['MAC-CEO', 'macOS', '14.7.1', 'Apple', 'MacBook Air (M2)', 'a.hassan']];
  const intuneDevices = memo(function (now) {
    const rows = [];
    const add = (name, os, ver, man, model, user, i, extra) => {
      const h = hash(name), days = name === 'iPhone-Hassan' ? 23 : h % 17 === 0 ? 9 + (h % 5) : round(((h % 40) + 1) / 24, 1);
      const jail = name === 'Galaxy-Tab-WH1', nc = jail || name === 'iPhone-Hassan' || /Windows 10 Pro|Windows 7/.test(ver) || h % 23 === 0, free = name === 'iPhone-Omar' ? 4 : 18 + (h % 60);
      const p = [nc ? 'compliance noncompliant' : null, days > 7 ? 'no check-in for ' + Math.floor(days) + ' days' : null, jail ? 'jailbroken or rooted' : null, free < 10 ? free + '% storage free' : null].filter(Boolean);
      rows.push(Object.assign({ Tenant: TENANT, Id: gid('md' + name), Name: name, User: user, UserPrincipalName: user + '@moncastle.example', OS: os, OSVersion: ver, Compliance: nc ? 'noncompliant' : 'compliant', Ownership: /Tab|iPad/.test(name) ? 'company' : os === 'Windows' || os === 'macOS' ? 'company' : 'personal', LastSync: iso(now - days * D), DaysSinceSync: days, Enrolled: iso(now - (60 + (h % 600)) * D), Manufacturer: man, Model: model, Serial: (h.toString(36) + 'X9').toUpperCase().slice(0, 10), Encrypted: os === 'Windows' ? h % 29 !== 0 : true, Jailbroken: jail ? 'True' : 'False', StorageGB: os === 'Windows' ? 476 : os === 'macOS' ? 512 : 128, StorageFreePct: free, Agent: os === 'Windows' ? 'mdm' : 'mdm', Enrollment: os === 'Windows' ? 'windowsAzureADJoin' : os === 'macOS' ? 'appleBulkWithUser' : 'userEnrollment', EntraDeviceId: gid('dev' + name), Mac: null, Status: jail || nc ? 'Critical' : p.length ? 'Warning' : 'OK', Message: p.join(', ') || 'compliant' }, extra || {}));
    };
    workstations.slice(0, 120).forEach((w, i) => add(w.Name, 'Windows', w.OperatingSystem.replace('Windows ', '') + ' · 10.0.' + (/11/.test(w.OperatingSystem) ? '22631.4391' : '19045.5011'), w.Manufacturer, w.Model, String(w.LoggedOnUser || 'user').replace(/^CORP\\/, '') || 'user', i));
    phones.concat(macs).forEach(([n, os, ver, man, model, user], i) => add(n, os, ver, man, model, user, i));
    return env('intune.devices', rows, { devices: rows.length, compliant: rows.filter((r) => r.Compliance === 'compliant').length, nonCompliant: rows.filter((r) => r.Compliance !== 'compliant').length, notSynced: rows.filter((r) => r.DaysSinceSync > 7).length, jailbroken: rows.filter((r) => r.Jailbroken === 'True').length }, now);
  });
  function entraDevices(now = NOW()) {
    const rows = workstations.map((w) => { const h = hash(w.Name), stale = h % 31 === 0, days = stale ? 120 + (h % 90) : round((h % 50) / 10, 1); return { Tenant: TENANT, Id: gid('o' + w.Name), DeviceId: gid('dev' + w.Name), Name: w.Name, OS: 'Windows', OSVersion: /11/.test(w.OperatingSystem) ? '10.0.22631.4391' : '10.0.19045.5011', Join: h % 4 ? 'Hybrid joined' : 'Entra joined', Enabled: true, Compliant: h % 23 !== 0, Managed: true, LastSignIn: iso(now - days * D), DaysSinceSignIn: Math.round(days), Stale: stale, Registered: iso(now - (90 + (h % 700)) * D), Manufacturer: w.Manufacturer, Model: w.Model, Synced: h % 4 !== 0, Status: stale || h % 23 === 0 ? 'Warning' : 'OK', Message: stale ? 'no sign-in for ' + Math.round(days) + ' days' : h % 23 === 0 ? 'not compliant' : 'OK' }; });
    phones.concat(macs).forEach(([n, os, ver, man, model]) => rows.push({ Tenant: TENANT, Id: gid('o' + n), DeviceId: gid('dev' + n), Name: n, OS: os, OSVersion: ver, Join: os === 'macOS' ? 'Entra joined' : 'Registered', Enabled: true, Compliant: n !== 'Galaxy-Tab-WH1' && n !== 'iPhone-Hassan', Managed: true, LastSignIn: iso(now - (n === 'iPhone-Hassan' ? 23 : 1) * D), DaysSinceSignIn: n === 'iPhone-Hassan' ? 23 : 1, Stale: false, Registered: iso(now - 300 * D), Manufacturer: man, Model: model, Synced: false, Status: n === 'Galaxy-Tab-WH1' || n === 'iPhone-Hassan' ? 'Warning' : 'OK', Message: n === 'Galaxy-Tab-WH1' || n === 'iPhone-Hassan' ? 'not compliant' : 'OK' }));
    servers.slice(0, 6).forEach((s) => rows.push({ Tenant: TENANT, Id: gid('o' + s.name), DeviceId: gid('dev' + s.name), Name: s.name, OS: 'Windows', OSVersion: '10.0.20348.2849', Join: 'Hybrid joined', Enabled: true, Compliant: null, Managed: false, LastSignIn: iso(now - 0.5 * D), DaysSinceSignIn: 0, Stale: false, Registered: iso(now - 600 * D), Manufacturer: s.manufacturer, Model: s.model, Synced: true, Status: 'OK', Message: 'OK' }));
    rows.push({ Tenant: TENANT, Id: gid('oldlaptop'), DeviceId: gid('devold'), Name: 'LAPTOP-8K2J1Q', OS: 'Windows', OSVersion: '10.0.19044.1288', Join: 'Registered', Enabled: true, Compliant: null, Managed: false, LastSignIn: iso(now - 400 * D), DaysSinceSignIn: 400, Stale: true, Registered: iso(now - 900 * D), Manufacturer: null, Model: null, Synced: false, Status: 'Warning', Message: 'no sign-in for 400 days' });
    return env('entra.devices', rows, { devices: rows.length, joined: rows.filter((r) => r.Join === 'Entra joined').length, hybrid: rows.filter((r) => r.Join === 'Hybrid joined').length, registered: rows.filter((r) => r.Join === 'Registered').length, stale: rows.filter((r) => r.Stale).length, nonCompliant: rows.filter((r) => r.Compliant === false).length }, now);
  }
  function entraGroups(now = NOW()) {
    const g = [['All Staff', 'Microsoft 365', true, 412, false, false], ['Finance Team', 'Microsoft 365', false, 38, false, false], ['SG-VPN-Users', 'Security', false, 96, true, false], ['SG-Intune-Windows-Pilot', 'Security', false, 14, false, false], ['SG-Intune-All-Devices', 'Security', true, 315, false, false], ['Helpdesk Admins', 'Security', false, 6, false, true], ['Conditional Access Exclusions', 'Security', false, 2, false, true], ['IT Announcements', 'Distribution', false, 44, true, false], ['Project Falcon (old)', 'Microsoft 365', false, 0, false, false], ['SG-License-E5', 'Security', false, 120, true, false], ['Guests - Auditors', 'Security', false, 1, false, false]];
    const rows = g.map(([n, type, dyn, m, sync, role]) => ({ Tenant: TENANT, Id: gid('g' + n), Name: n, Description: null, Mail: type !== 'Security' ? n.toLowerCase().replace(/[^a-z]+/g, '-') + '@moncastle.example' : null, Type: type, Dynamic: dyn, Rule: dyn ? (n === 'All Staff' ? '(user.accountEnabled -eq true) and (user.userType -eq "Member")' : '(device.managementType -eq "MDM")') : null, Members: m, Synced: sync, RoleAssignable: role, Visibility: type === 'Microsoft 365' ? 'Private' : null, Created: iso(now - (100 + hash(n) % 900) * D), Status: m === 0 && !dyn ? 'Warning' : 'OK', Message: (m === 0 ? 'no members' : m + ' members') + (role ? ', can be assigned admin roles' : '') }));
    return env('entra.groups', rows, { groups: rows.length, security: rows.filter((r) => /Security/.test(r.Type)).length, m365: rows.filter((r) => r.Type === 'Microsoft 365').length, dynamic: rows.filter((r) => r.Dynamic).length, empty: rows.filter((r) => r.Members === 0).length }, now);
  }
  function entraHealth(now = NOW()) {
    const u = entraUsers(now).data, rows = [], R2 = (o) => rows.push(Object.assign({ Tenant: TENANT, TenantName: null, Status: 'OK', Message: '' }, o));
    R2({ Kind: 'Tenant', Name: TENANT_NAME, TenantName: TENANT_NAME, Users: u.length, Guests: u.filter((x) => x.UserType === 'Guest').length, Disabled: u.filter((x) => !x.Enabled).length, Devices: 330, Domains: 3, SyncEnabled: true, LastSync: iso(now - 0.4 * H), SyncAgeHours: 0.4, Message: u.length + ' users, ' + u.filter((x) => x.UserType === 'Guest').length + ' guests, directory sync 0.4 h ago' });
    [['SPE_E3', 412, 425], ['SPE_E5', 120, 120], ['EMS', 330, 400], ['POWER_BI_PRO', 61, 75], ['Microsoft_Teams_Rooms_Pro', 3, 3]].forEach(([n, c, a]) => { const pct = Math.round((100 * c) / a); R2({ Kind: 'Licence', Name: n, Consumed: c, Available: a, UsedPct: pct, State: 'Enabled', Status: c > a ? 'Critical' : pct >= 95 ? 'Warning' : 'OK', Message: c + ' of ' + a + ' assigned' }); });
    [['MonCastle reader', 'mc-console', 'Client secret', 41], ['HR sync connector', 'prod', 'Client secret', 9], ['Payroll SFTP bridge', 'cert-2025', 'Certificate', -4], ['Intranet SSO', 'saml-signing', 'Certificate', 27]].forEach(([n, it, t, d]) => R2({ Kind: 'App credential', Name: n, AppId: gid('app' + n), Item: it, Type: t, Expires: iso(now + d * D), DaysLeft: d, Status: d <= 7 ? 'Critical' : d <= 30 ? 'Warning' : 'OK', Message: d < 0 ? t + ' expired ' + -d + ' days ago' : t + ' expires in ' + d + ' days' }));
    R2({ Kind: 'Sign-ins', Name: 'Failed sign-ins (24 h)', Failed: 137, TopReasons: ['Invalid username or password (88)', 'MFA denied; user declined (21)', 'Blocked by Conditional Access (17)'], TopUsers: ['h.fouad@moncastle.example (34)', 'admin.omar@moncastle.example (12)', 'k.samir@moncastle.example (9)'], TopCountries: ['EG (71)', 'NL (38)', 'RU (19)'], Status: 'Warning', Message: '137 failed sign-ins in 24 h' });
    const risky = u.filter((x) => x.Risk);
    R2({ Kind: 'Risky users', Name: 'Users at risk', AtRisk: risky.length, High: risky.filter((x) => x.Risk === 'high').length, Users: risky.slice(0, 5).map((x) => x.UserPrincipalName), Status: risky.some((x) => x.Risk === 'high') ? 'Critical' : risky.length ? 'Warning' : 'OK', Message: risky.length + ' users at risk, ' + risky.filter((x) => x.Risk === 'high').length + ' high' });
    const ga = u.filter((x) => /Global Administrator/.test(x.Roles || ''));
    R2({ Kind: 'Privileged roles', Name: 'Global Administrator', Members: ga.length, Users: ga.map((x) => x.UserPrincipalName), Status: ga.length > 5 || ga.length < 2 ? 'Warning' : 'OK', Message: ga.length + ' Global Administrators (Microsoft recommends 2 to 4)' });
    R2({ Kind: 'Conditional access', Name: 'Conditional Access policies', Enabled: 7, ReportOnly: 2, Disabled: 1, Policies: ['Require MFA for all users [enabled]', 'Block legacy authentication [enabled]', 'Require compliant device for admins [enabled]', 'Block sign-ins outside EG, NL [enabledForReportingButNotEnforced]'], Message: '7 enforced, 2 report-only, 1 off' });
    return env('entra.health', rows, { tenants: 1, expiringCredentials: rows.filter((r) => r.Kind === 'App credential' && r.Status !== 'OK').length, failedSignIns: 137 }, now);
  }
  function intuneHealth(now = NOW()) {
    const d = intuneDevices(now).data, rows = [], R2 = (o) => rows.push(Object.assign({ Tenant: TENANT, Status: 'OK', Message: '' }, o));
    const nc = d.filter((x) => x.Compliance !== 'compliant').length;
    R2({ Kind: 'Summary', Name: 'Intune', Enrolled: d.length, Mdm: d.length, Windows: d.filter((x) => x.OS === 'Windows').length, MacOS: d.filter((x) => x.OS === 'macOS').length, IOS: d.filter((x) => /iOS|iPadOS/.test(x.OS)).length, Android: d.filter((x) => x.OS === 'Android').length, Linux: 0, Compliant: d.length - nc, NonCompliant: nc, InGrace: 2, Conflict: 1, Autopilot: 96, Status: nc ? 'Warning' : 'OK', Message: d.length + ' enrolled devices, ' + nc + ' not compliant' });
    [['Compliance policy', 'Windows 11 baseline', 'windows10', 104, 6, 1, 0], ['Compliance policy', 'iOS minimum 17', 'ios', 4, 2, 0, 0], ['Compliance policy', 'Android Enterprise', 'androidWorkProfile', 2, 1, 0, 0], ['Compliance policy', 'macOS FileVault', 'macOS', 2, 0, 0, 0], ['Configuration profile', 'BitLocker silent encryption', 'windows10EndpointProtection', 112, 0, 4, 1], ['Configuration profile', 'Wi-Fi CORP-SECURE', 'windowsWifi', 118, 0, 0, 0], ['Configuration profile', 'Defender ASR rules', 'windows10EndpointProtection', 101, 3, 2, 2], ['Configuration profile', 'iOS restrictions', 'iosGeneral', 5, 0, 0, 0]].forEach(([k, n, plat, s, f, e, c]) => R2({ Kind: k, Name: n, Id: gid('p' + n), Platform: plat, Succeeded: s, Failed: f, Errors: e, Conflicts: c, Pending: 1, NotApplicable: 0, Modified: iso(now - (hash(n) % 90) * D), Status: f + e + c ? 'Warning' : 'OK', Message: s + ' succeeded, ' + f + ' failed, ' + e + ' errors, ' + c + ' conflicts' }));
    [['Company Portal', 'Microsoft', 'winGetApp', 120, 0, 0], ['Microsoft 365 Apps', 'Microsoft', 'officeSuiteApp', 114, 3, 3], ['MonCastle Agent', 'RoboMate', 'win32LobApp', 101, 9, 10], ['Microsoft Authenticator', 'Microsoft', 'iosStoreApp', 6, 0, 1], ['Zoom Workplace', 'Zoom', 'winGetApp', 77, 1, 0]].forEach(([n, pub, plat, i, f, p]) => R2({ Kind: 'App', Name: n, Id: gid('a' + n), Publisher: pub, Platform: plat, Installed: i, Failed: f, Pending: p, NotInstalled: 0, Status: f && f >= i ? 'Critical' : f ? 'Warning' : 'OK', Message: i + ' installed, ' + f + ' failed, ' + p + ' pending' }));
    [['Apple MDM push certificate', 23, ' (it@moncastle.example)'], ['Apple VPP token MonCastle Demo Co.', 188, ''], ['Apple enrolment token ABM-Main', 61, '']].forEach(([n, dl, more]) => R2({ Kind: 'Connector', Name: n, Expires: iso(now + dl * D), DaysLeft: dl, Status: dl < 7 ? 'Critical' : dl < 30 ? 'Warning' : 'OK', Message: 'expires in ' + dl + ' days' + more }));
    return env('intune.health', rows, { policies: rows.filter((r) => /policy|profile/.test(r.Kind)).length, failing: rows.filter((r) => r.Kind !== 'Summary' && r.Status !== 'OK').length }, now);
  }

  // ------------------------------------------------------------------ on-demand / actions
  function simulate(scriptId, params) {
    const target = String((params && (params.ComputerName || params.Target || params.Name)) || 'APP01').split(/[,;\s]+/)[0];
    const s = byName[target.toUpperCase()] || servers[28];
    switch (scriptId) {
      case 'mon.processes':
        return env('servers.processes', ['sqlservr', 'w3wp', 'MsMpEng', 'svchost', 'java', 'lsass', 'powershell', 'TiWorker', 'dwm', 'explorer'].map((n, i) => ({ ComputerName: s.name, Name: n, PID: 1000 + i * 37, CPU: round(Math.max(0.1, 40 / (i + 1) + (R() - 0.5) * 4)), MemoryMB: round(between(40, i === 0 ? 24000 : 900)), Threads: int(8, 140), Handles: int(200, 4000), Owner: i < 3 ? 'NT SERVICE\\' + n : 'NT AUTHORITY\\SYSTEM', CommandLine: 'C:\\Windows\\system32\\' + n + '.exe' })));
      case 'mon.network.tcp':
        return env('servers.tcp', Array.from({ length: 18 }, (_, i) => ({ ComputerName: s.name, LocalAddress: s.ip, LocalPort: [443, 3389, 5985, 1433, 445, 135][i % 6], RemoteAddress: i < 6 ? '0.0.0.0' : '10.10.5' + (i % 3) + '.' + int(2, 250), RemotePort: i < 6 ? 0 : int(49152, 65535), State: i < 6 ? 'Listen' : 'Established', Process: ['w3wp', 'svchost', 'System', 'sqlservr', 'System', 'svchost'][i % 6], PID: 400 + i })), { listening: 6, established: 12, topRemote: [] });
      case 'mon.sessions':
        return env('servers.sessions', [{ ComputerName: s.name, User: 'admin.marco', Session: 'rdp-tcp#12', Id: '2', State: 'Active', Idle: '.', LogonTime: '10/23/2026 7:41 AM' }, { ComputerName: s.name, User: 'h.fouad', Session: '', Id: '3', State: 'Disc', Idle: '2+03:11', LogonTime: '10/21/2026 4:02 PM' }], { sessions: 2, disconnected: 1 });
      case 'inv.systeminfo':
        return env('inventory.systeminfo', [{ 'Host Name': s.name, 'OS Name': 'Microsoft ' + s.os, 'OS Version': '10.0.20348 N/A Build 20348', 'System Manufacturer': s.manufacturer, 'System Model': s.model, 'Total Physical Memory': s.ram * 1024 + ' MB', Domain: DOMAIN, 'Logon Server': '\\\\DC01', 'Hotfix(s)': '3 Hotfix(s) Installed.', 'System Boot Time': new Date(NOW() - 9 * D).toLocaleString() }]);
      case 'mon.largefiles':
        return env('servers.largefiles', [['D:\\Backups\\ERP_Prod_full.bak', 182.4], ['E:\\Shares\\Projects\\video\\site-survey.mp4', 23.1], ['C:\\Windows\\MEMORY.DMP', 16.0], ['D:\\Logs\\iis\\u_ex2609.log', 7.8]].map(([p, g]) => ({ ComputerName: s.name, Path: p, SizeGB: g, Extension: p.slice(p.lastIndexOf('.')), LastWrite: iso(NOW() - between(1, 90) * D) })), { files: 4, totalGB: 229.3 });
      case 'act.dns':
        return env('tools.dns', [{ Name: params.Name || 'corp.moncastle.local', Type: 'A', TTL: 600, Section: 'Answer', Data: '10.10.1.10' }, { Name: params.Name || 'corp.moncastle.local', Type: 'A', TTL: 600, Section: 'Answer', Data: '10.20.1.12' }]);
      case 'sec.vulnscan': {
        const F = (port, svc, sev, check, ev, fix) => ({ ComputerName: s.name, Port: port, Service: svc, Severity: sev, Check: check, Vulnerable: ['Critical', 'High', 'Medium'].includes(sev), Evidence: ev, Fix: fix });
        const rows = [F('135/tcp', 'MS RPC', 'Info', 'Open port', 'Open', ''), F('445/tcp', 'SMB', 'Info', 'Open port', 'Open', ''), F('3389/tcp', 'RDP', 'Medium', 'Exposed service', 'RDP answers on 3389', 'Allow RDP only from management networks or through a gateway.'), F('3389/tcp', 'RDP', 'Low', 'Self-signed certificate', 'CN=' + s.name + '.' + DOMAIN, 'Use a certificate from your company or a public CA.'), F('5985/tcp', 'WinRM HTTP', 'Info', 'Open port', 'Open', '')];
        if (/^(WEB|ERP|SCCM)/.test(s.name)) rows.push(F('80/tcp', 'HTTP', 'Medium', 'Cleartext service', 'HTTP answers on 80', 'Unencrypted web. Redirect to HTTPS.'), F('443/tcp', 'HTTPS', 'Medium', 'Old TLS versions', 'Accepts TLS 1.0, TLS 1.1', 'Disable TLS 1.0 and 1.1; keep TLS 1.2 and 1.3.'), F('443/tcp', 'HTTPS', 'Low', 'Server version disclosed', 'Server: Microsoft-IIS/10.0', 'Hide the version in the Server header.'));
        if (/^(APP06|FS03|PRN02)/.test(s.name)) rows.push(F('445/tcp', 'SMB', 'Critical', 'SMBv1 enabled', 'The server accepted an SMB1 negotiate', 'Disable SMBv1 (Set-SmbServerConfiguration -EnableSMB1Protocol $false).'));
        return env('security.vulnscan', rows, { targets: 1, findings: rows.filter((r) => r.Severity !== 'Info').length, vulnerable: rows.filter((r) => r.Vulnerable).length, scanner: 'native' });
      }
      case 'act.nettest':
        if (params.Test === 'TraceRoute') return env('tools.network', [1, 2, 3, 4, 5].map((h) => ({ Hop: h, Address: h === 5 ? '93.184.215.14' : '10.10.0.' + h, LatencyMs: round(h * between(1, 6)), Name: h === 1 ? 'fw-he01.corp.moncastle.local' : null })));
        if (params.Test === 'InternetSpeed') return env('tools.network', [{ Test: 'Download', Bytes: 26214400, Seconds: 2.31, Mbps: 90.8 }]);
        return env('tools.network', [{ Target: params.Target, Port: params.Port || 443, Open: true, PingSucceeded: true, RemoteAddress: '10.10.1.10' }]);
      case 'aud.lockout': {
        const a = audit();
        const u = params.UserName || 'j.adel';
        const ev = a.data.filter((r) => String(r.Target || '').includes(u));
        return env('audit.lockout', ev, { user: u, state: { LockedOut: true, BadLogonCount: 5, LastBadPassword: iso(NOW() - 12 * 60e3) }, lockouts: ev.filter((e) => e.EventSet === 'Lockout').length, sources: [{ name: 'WS-0142', count: ev.length - 2 }], reasons: [{ name: 'Incorrect password', count: ev.length - 9 }] });
      }
      case 'dev.events': {
        const lv = { Critical: ['Critical'], Error: ['Error'], Warning: ['Warning'], Information: ['Information'], ErrorAndAbove: ['Critical', 'Error'], All: ['Critical', 'Error', 'Warning', 'Information'] }[params.Level] || ['Critical', 'Error', 'Warning'];
        const cat = [['Error', 'Service Control Manager', 7000, 'The Print Spooler service failed to start due to the following error: the service did not respond in a timely fashion.'], ['Warning', 'DistributedCOM', 10016, 'The application-specific permission settings do not grant Local Activation permission for the COM Server application.'], ['Error', 'Schannel', 36887, 'A fatal alert was received from the remote endpoint. The TLS protocol defined fatal alert code is 46.'], ['Critical', 'Microsoft-Windows-Kernel-Power', 41, 'The system has rebooted without cleanly shutting down first.'], ['Warning', 'Microsoft-Windows-Time-Service', 129, 'NtpClient was unable to set a domain peer to use as a time source.'], ['Information', 'Microsoft-Windows-Kernel-General', 16, 'The access history in hive was cleared updating 7 keys.'], ['Error', 'Microsoft-Windows-GroupPolicy', 1129, 'The processing of Group Policy failed because of lack of network connectivity to a domain controller.']];
        const rows = Array.from({ length: 40 }, (_, i) => { const c = cat[(i * 5) % cat.length]; return { Time: iso(NOW() - between(0, (params.Hours || 24)) * H), ComputerName: s.name, Log: params.LogName || 'System', Level: c[0], Status: c[0] === 'Warning' ? 'Warning' : c[0] === 'Information' ? 'OK' : 'Critical', EventId: c[2], Source: c[1], User: null, Message: c[3] }; }).filter((r) => lv.includes(r.Level)).sort((a, b) => (a.Time < b.Time ? 1 : -1));
        return env('device.events', rows, { events: rows.length, log: params.LogName || 'System', level: params.Level || 'WarningAndAbove' });
      }
      case 'dev.live':
        return env('device.live', [{ ComputerName: s.name, Sampled: iso(NOW()), Seconds: params.Seconds || 5, CPU: round(between(8, 70)), CpuQueue: round(between(0, 3)), Memory: round(between(40, 88)), Committed: round(between(40, 80)), DiskIOPS: Math.round(between(80, 2400)), DiskLatencyMs: round(between(0.6, 9)), NetKBps: round(between(200, 9000)), UptimeHours: round(between(20, 900)), RebootPending: s.name === 'APP02', Users: ['admin.marco'], TopProcesses: ['sqlservr 22.4% 18210 MB', 'w3wp 6.1% 1412 MB', 'MsMpEng 2.3% 388 MB', 'svchost 1.1% 96 MB'] }]);
      case 'act.process':
        return env('action.process', [{ ComputerName: s.name, Process: String(params.Name || 'notepad').replace(/\.exe$/, ''), Id: params.ProcessId || 4120, MemoryMB: 212, Result: /^(lsass|csrss|svchost|winlogon)$/i.test(params.Name || '') ? 'Refused: critical system process' : 'Stopped (demo - nothing was changed)' }]);
      case 'act.client':
        return env('action.client', [].concat(params.Operation || ['GpUpdate']).map((op) => ({ ComputerName: s.name, Operation: op, Status: 'OK', Detail: { GpUpdate: 'Computer Policy update has completed successfully.', FlushDns: 'DNS client cache cleared', SyncTime: 'The command completed successfully.', ResetSpooler: 'Spooler restarted, stuck jobs cleared', CleanTemp: 'Freed 1840 MB (files older than 2 days)', UpdateScan: '4 updates available', DefenderQuickScan: 'Quick scan finished', DefenderSignatures: 'Signatures 1.419.322.0', ConfigMgrPolicy: 'Machine policy retrieval triggered', RegisterDns: 'DNS records registered' }[op] + ' (demo)', Seconds: round(between(1, 40)) })));
      case 'act.net.config.backup':
        return env('action.net.config.backup', [].concat(params.ComputerName || ['CORE-SW01']).map((n, i) => ({ ComputerName: n, Result: i % 4 === 1 ? 'Changed' : 'Unchanged', Lines: 400 + i * 37, Added: i % 4 === 1 ? 3 : 0, Removed: i % 4 === 1 ? 1 : 0, Changes: i % 4 === 1 ? '+ interface Gi1/0/24\n+  shutdown\n+  description spare\n- interface Gi1/0/24' : '', File: '20261025-020000.cfg', Versions: 12 + i })));
      case 'act.lnx.patch':
        return env('action.lnx.patch', [].concat(params.ComputerName || ['LNX-WEB01']).map((n, i) => ({ ComputerName: n, Scope: params.Scope || 'SecurityOnly', Result: i % 5 === 3 ? 'Up to date' : 'Updated', Pending: i % 5 === 3 ? 0 : 3 + i, Installed: i % 5 === 3 ? 0 : 3 + i, StillPending: 0, RebootRequired: i % 3 === 0, Rebooting: i % 3 === 0 && !!params.RebootIfRequired, PackageManager: i % 2 ? 'dnf' : 'apt' })));
      case 'act.lnx.cleanup':
        return env('action.lnx.cleanup', [].concat(params.ComputerName || ['LNX-WEB01']).map((n, i) => ({ ComputerName: n, Result: 'Cleaned', Journal: (180 + i * 40) + 'M', PackageCacheMB: 220 + i * 31, OldTempFiles: 40 + i * 9, OldRotatedLogs: 12 + i, FreedMB: 410 + i * 77, RootFreeGB: round(between(6, 40)) })));
      case 'act.storage.snapshot':
        return env('action.storage.snapshot', [].concat(params.ComputerName || ['NETAPP01']).flatMap((n) => [].concat(params.Volume || ['vol_data']).map((v) => ({ ComputerName: n, Platform: /pure/i.test(n) ? 'FlashArray' : 'ONTAP', Volume: v, Result: 'Snapshot taken', Snapshot: 'mc-' + (params.Prefix || 'job') + '-20261025-0200', Pruned: 1, PrunedNames: 'mc-' + (params.Prefix || 'job') + '-20261018-0200' }))));
      case 'act.win.netinfo': {
        const sh = params.Show || 'Addresses', out = [];
        if (sh === 'Addresses' || sh === 'All') out.push({ ComputerName: s.name, Kind: 'Adapter', Name: 'Ethernet0', Status: 'Up', Address: s.ip, Prefix: '16', Gateway: s.ip.split('.').slice(0, 2).join('.') + '.0.1', Dns: '10.10.1.10, 10.10.1.11', Dhcp: 'Disabled', Speed: '10 Gbps', Mac: '00-15-5D-0A-1B-' + pad(s.i % 99), Profile: 'DomainAuthenticated' });
        if (sh === 'Routes' || sh === 'All') out.push(...[['0.0.0.0/0', s.ip.split('.').slice(0, 2).join('.') + '.0.1', 'metric 25'], [s.ip.split('.').slice(0, 2).join('.') + '.0.0/16', '0.0.0.0', 'metric 281']].map(([d, g, m]) => ({ ComputerName: s.name, Kind: 'Route', Name: d, Gateway: g, Status: 'Ethernet0', Speed: m })));
        if (sh === 'ListeningPorts' || sh === 'All') out.push(...[[135, 'svchost'], [445, 'System'], [3389, 'svchost'], [5985, 'System'], [1433, 'sqlservr']].map(([p, n]) => ({ ComputerName: s.name, Kind: 'Listening', Name: 'TCP ' + p, Address: '0.0.0.0', Status: n })));
        return env('action.win.netinfo', out);
      }
      case 'act.win.nettest': {
        const t = params.Test || 'Ping', tg = params.Target || '8.8.8.8';
        const d = { Ping: ['OK', '4/4 answered, 0% loss, min/avg/max 11/12.4/15 ms'], Port: ['Open', 'TCP ' + (params.Port || 443) + ' on ' + tg + ' answered in 14 ms'], TraceRoute: ['Reached', '1 10.10.0.1\n2 172.16.0.1\n3 81.21.96.1\n4 ' + tg], DnsLookup: ['Resolved', 'A 142.250.200.4 (DNS servers: 10.10.1.10, 10.10.1.11)'], Speed: ['OK', '25 MB in 2.4 s = 87.4 Mbit/s'] }[t];
        return env('action.win.nettest', [{ ComputerName: s.name, Test: t, Target: t === 'Speed' ? 'speed.cloudflare.com' : tg, Result: d[0], Detail: d[1] }]);
      }
      case 'act.lnx.nettest': {
        const t = params.Test || 'Addresses';
        const o = { Addresses: 'lo UNKNOWN 127.0.0.1/8\neth0 UP 10.10.6.21/16\n\ndefault via 10.10.0.1 dev eth0\n\nnameserver 10.10.1.10', ListeningPorts: 'tcp LISTEN 0 128 0.0.0.0:22 users:(("sshd",pid=812))\ntcp LISTEN 0 511 0.0.0.0:443 users:(("nginx",pid=1290))', Ping: '4 packets transmitted, 4 received, 0% packet loss\nrtt min/avg/max = 0.4/0.6/0.9 ms', Port: 'TCP ' + (params.Port || 443) + ' open', TraceRoute: ' 1  10.10.0.1  0.4 ms\n 2  172.16.0.1  1.2 ms', DnsLookup: '142.250.200.4 STREAM ' + (params.Target || 'example.com') }[t];
        return env('action.lnx.nettest', [{ ComputerName: target, Test: t, Target: params.Target || '-', Result: 'OK', Output: o }]);
      }
      case 'act.firewall.port':
        return env('action.firewall.port', [{ ComputerName: s.name, Operation: params.Operation, Port: (params.Protocol || 'TCP') + ' ' + (params.Port || 8080), Result: params.Operation === 'List' ? 'Done' : params.Hours ? 'Open for ' + params.Hours + ' h' : 'Done', SomethingListening: true, MonCastleRules: params.Operation === 'Close' ? '' : (params.Protocol || 'TCP') + ' ' + (params.Port || 8080) }]);
      case 'act.lnx.diag':
        return env('action.lnx.diag', [{ ComputerName: target, Result: 'Done', Load: '0.42 0.38 0.31', Cpus: '4', Memory: '2841 of 7821 MB used', UptimeDays: 41.2, FullestFileSystems: '/var 81%; / 46%; /boot 31%', TopProcesses: '1290 12.1 3.2 nginx\n2211 4.0 9.8 java', FailedUnits: target.includes('02') ? 'fwupd-refresh.service' : '', JournalErrors: '' }]);
      case 'act.lnx.user':
        return env('action.lnx.user', [{ ComputerName: target, User: params.UserName || 'deploy', Operation: params.Operation, Result: 'Done', State: params.Operation === 'Lock' ? 'Locked' : 'Active', PasswordChanged: 'Sep 30, 2026', LastLogin: 'Oct 30 18:02 from 10.10.5.20' }]);
      case 'act.lnx.reboot':
        return env('action.lnx.reboot', [{ ComputerName: target, Operation: params.Operation || 'Reboot', When: '+' + (params.DelayMinutes || 1), Result: params.OnlyIfRequired ? 'Not required' : 'Scheduled', RebootRequired: false, UptimeDays: 41.2 }]);
      case 'act.net.show':
        return env('action.net.show', [{ ComputerName: target, Command: 'show ' + String(params.Show || 'Version').toLowerCase(), Result: 'Done', Lines: 6, Output: params.Show === 'Interfaces' ? 'Port      Name       Status       Vlan  Duplex Speed Type\nGi1/0/1   UPLINK-FW  connected    trunk full   1000  1000BaseSX\nGi1/0/2   SRV-HV01   connected    10    full   10G   SFP-10GBase-SR\nGi1/0/3              notconnect   1     auto   auto  10/100/1000BaseTX' : 'Cisco IOS XE Software, Version 17.09.04a\nuptime is 41 weeks, 2 days\nModel Number: C9300-48P' }]);
      case 'act.net.config.save':
        return env('action.net.config.save', [{ ComputerName: target, Profile: 'cisco-ios', Result: 'Saved', Output: 'Building configuration...\n[OK]' }]);
      case 'act.defender.scan':
        return env('action.defender.scan', [{ ComputerName: s.name, ScanType: params.ScanType || 'Quick', Result: params.ScanType === 'Full' ? 'Started' : 'Done', Signatures: 'updated', SignatureVersion: '1.421.112.0', ThreatsFound: 0, Threats: '', Minutes: 3.4 }]);
      case 'act.storage.vss':
        return env('action.storage.vss', [{ ComputerName: s.name, Volume: params.Volume || 'C:', Operation: params.Operation || 'Create', Result: 'Done', Created: params.Operation === 'Create' ? '{6C1D0A0B-77F2-4F0E-9C59-1E0D2C5B8A21}' : null, Removed: 0, Copies: 6, Newest: iso(NOW() - 3 * H), Oldest: iso(NOW() - 9 * D), StorageUsedGB: 18.4, StorageMaxGB: 50 }]);
      case 'act.wol':
        return env('action.wol', [].concat(params.MacAddress || ['00:15:5D:0A:1B:2C']).map((m) => ({ MacAddress: String(m).toUpperCase(), Broadcast: params.BroadcastAddress || '255.255.255.255', Result: 'Sent' })));
      case 'act.vmware.vm':
        return env('action.vmware.vm', [].concat(params.VMName || ['APP01']).map((n) => ({ VM: n, Operation: params.Operation, Result: params.Operation === 'Status' ? 'Done' : 'Done (demo - nothing changed)', Power: 'PoweredOn', Host: 'esx02.' + DOMAIN, Tools: 'toolsOk', IPAddress: (byName[n] || s).ip, Snapshots: 1, NeedsConsolidation: false })));
      case 'act.k8s':
        return env('action.k8s', [].concat(params.ComputerName || ['k8s-onprem']).map((c) => ({ Cluster: c, Operation: params.Operation, Namespace: /Node$/.test(params.Operation || '') ? null : params.Namespace || 'default', Name: params.Name, Result: 'Done (demo - nothing changed)', Detail: { RestartWorkload: 'Rollout restart started', ScaleWorkload: 'Replicas set to ' + (params.Replicas == null ? 1 : params.Replicas), DeletePod: 'Pod deleted; the controller starts a new one', CordonNode: 'Node marked unschedulable', UncordonNode: 'Node schedulable again' }[params.Operation] || '' })));
      case 'act.containers':
        if (params.Operation === 'Logs') return env('action.containers', [].concat(params.ComputerName || ['MON01']).map((h) => ({ ComputerName: h, Container: params.Container, Operation: 'Logs', Result: 'Done', State: null, Output: ['level=info msg="Server is ready to receive web requests."', 'level=warn msg="Error on ingesting samples that are too old"', 'level=info msg="Completed loading of configuration file"'].join('\n') })));
        return env('action.containers', [].concat(params.ComputerName || ['MON01']).map((h) => ({ ComputerName: h, Container: params.Container || null, Operation: params.Operation, Result: 'Done (demo - nothing changed)', State: params.Operation === 'Stop' ? 'exited' : params.Operation === 'Prune' ? null : 'running', Output: params.Operation === 'Prune' ? 'Total reclaimed space: 1.42GB' : null })));
      case 'act.cloud.db':
        return env('action.cloud.db', [{ Provider: params.Provider, Service: params.Service, Operation: params.Operation, Database: String(params.Id || '').split(/[/:]/).pop(), Id: params.Id, Result: 'Sent (demo - nothing changed)', Detail: { Start: 'The database is starting; this takes a few minutes', Stop: 'The database is stopping; connections are closed', Restart: 'The database is restarting; connections drop for a short while', Failover: 'Failover started; the standby becomes the primary in a minute or two' }[params.Operation] }]);
      case 'act.cloud.network':
        return env('action.cloud.network', [{ Provider: params.Provider, Operation: params.Operation, Resource: params.ResourceId, Item: params.Item || null, Result: 'Done (demo - nothing changed)', Detail: { ResetVpnConnection: 'Connection reset; the tunnel renegotiates in a minute or two', DisconnectVpnClient: 'Disconnected ' + (params.Item || ''), EnableFirewallRule: 'Firewall rule ' + (params.Item || '') + ' is now enabled', DisableFirewallRule: 'Firewall rule ' + (params.Item || '') + ' is now disabled', SetWafPrevention: 'WAF policy set to Prevention', SetWafDetection: 'WAF policy set to Detection' }[params.Operation] || '' }]);
      default: {
        const meta = scriptId.startsWith('act.') ? 'action' : 'ondemand';
        const targets = String(params.ComputerName || params.VMName || target).split(/[,;\s]+/).filter(Boolean);
        return env('action.' + scriptId.replace(/^act\./, ''), targets.map((t) => ({ ComputerName: t, Operation: params.Operation || params.State || params.Mode || params.Test || 'Run', Result: meta === 'action' ? 'Completed (demo - nothing was changed)' : 'Done' })));
      }
    }
  }

  function env(dataset, data, summary, now) {
    const t = now || NOW();
    return { moncastle: '4.0.0', dataset, status: 'ok', message: '', host: 'MC01', started: iso(t - 4200), finished: iso(t), count: data.length, summary: summary || null, warnings: [], data };
  }

  // ------------------------------------------------------------------ DNS, file servers, GPO, event logs (4.1 collectors)
  function dnsServers() {
    const rows = servers.filter((s) => s.roles.includes('DomainControllers')).map((s, i) => ({
      ComputerName: s.name, ServiceState: 'Running', Zones: 6, ZonesPaused: 0, AdIntegrated: 5, ResolveMs: round(between(1, 9) + (s.name === 'DC03' ? 240 : 0)),
      FailedTests: s.name === 'DC04' ? ['www.microsoft.com (A): DNS name does not exist (forwarder 8.8.4.4 timed out)'] : [], Errors24h: s.name === 'DC04' ? 37 : int(0, 4),
      TopError: s.name === 'DC04' ? '4013 x31' : null, Forwarders: ['8.8.8.8', '8.8.4.4'], QueriesPerSec: round(between(20, 260)), Recursion: int(1000, 90000),
    }));
    return env('dns.servers', rows, { servers: rows.length, down: 0, failingTests: rows.filter((r) => r.FailedTests.length).length });
  }
  function fileServerHealth() {
    const rows = servers.filter((s) => s.roles.includes('FileServers')).map((s, i) => ({
      ComputerName: s.name, Shares: 14 + i * 5, Sessions: int(40, 260), Users: int(30, 180), OpenFiles: int(80, 900), QuotasNearLimit: s.name === 'FS02' ? 2 : 0, QuotaPaths: s.name === 'FS02' ? ['E:\\Shares\\Projects', 'E:\\Shares\\Media'] : [],
      LowestVolume: 'E:', LowestFreePct: s.name === 'FS02' ? 11.4 : round(between(25, 60)), ShadowCopyAgeHours: s.name === 'FS03' ? 52.5 : round(between(1, 11)), Message: s.name === 'FS02' ? '2 quota(s) over 90%' : null,
    }));
    return env('fileserver.health', rows, { servers: rows.length });
  }
  function gpo() {
    const names = ['Default Domain Policy', 'Default Domain Controllers Policy', 'SEC - Baseline Servers', 'SEC - Baseline Workstations', 'SEC - LAPS', 'SEC - Defender', 'WSUS - Servers', 'WSUS - Workstations', 'USR - Drive mappings', 'USR - Printers HQ', 'USR - Printers Branch', 'CMP - Power settings', 'CMP - BitLocker', 'CMP - Firewall', 'USR - Desktop wallpaper', 'TEST - Old proxy', 'CMP - RDP for admins', 'USR - Office settings', 'CMP - Time sync', 'TEST - Empty'];
    const rows = names.map((n, i) => ({ Name: n, Id: '{' + (31000000 + i * 7919).toString(16).toUpperCase() + '-0000-4000-8000-0000000000' + pad(i) + '}', Status: n === 'TEST - Old proxy' ? 'AllSettingsDisabled' : 'AllSettingsEnabled', Created: iso(NOW() - (400 + i * 20) * D), Modified: iso(NOW() - int(1, 300) * D), Links: /^TEST/.test(n) ? 0 : int(1, 4), LinkedTo: /^TEST/.test(n) ? [] : ['corp.moncastle.local/' + (n.startsWith('USR') ? 'Users' : n.startsWith('WSUS - W') ? 'Workstations' : 'Servers')], EnabledLinks: /^TEST/.test(n) ? 0 : 1, Empty: n === 'TEST - Empty', VersionMismatch: n === 'USR - Printers Branch', Versions: n === 'USR - Printers Branch' ? 'C 0/0 U 14/12' : 'C 3/3 U 2/2', WmiFilter: null }));
    return env('ad.gpo', rows, { gpos: rows.length, unlinked: rows.filter((r) => !r.Links).length, empty: 1, mismatched: 1 });
  }
  function adSites() {
    const dcs = servers.filter((s) => s.roles.includes('DomainControllers'));
    const sub = { 'HQ-Main': ['10.10.0.0/16'], 'DR-Site': ['10.20.0.0/16'], 'Branch-North': ['10.30.0.0/16'], 'Branch-South': ['10.40.0.0/16'] };
    const links = [['HQ-DR', ['HQ-Main', 'DR-Site'], 100, 15, true], ['HQ-North', ['HQ-Main', 'Branch-North'], 200, 60, false], ['HQ-South', ['HQ-Main', 'Branch-South'], 200, 180, false], ['DR-North', ['DR-Site', 'Branch-North'], 400, 180, false]];
    const rows = SITES.map((s) => {
      const d = dcs.filter((x) => x.site === s);
      const problems = d.length ? [] : ['No domain controller in this site'];
      return { Kind: 'site', Name: s, Description: { 'HQ-Main': 'Head office, Cairo', 'DR-Site': 'Disaster recovery data centre', 'Branch-North': 'North branch', 'Branch-South': 'South branch' }[s], Location: s, DomainControllers: d.map((x) => x.name), GlobalCatalogs: d.filter((x) => x.name !== 'DC04').length, ISTG: d.length ? d[0].name : null, Subnets: sub[s], SiteLinks: links.filter((l) => l[1].includes(s)).map((l) => l[0]), Problems: problems, Status: problems.length ? 'Warning' : 'OK' };
    });
    for (const [n, s, cost, iv, cn] of links) rows.push({ Kind: 'link', Name: n, Description: '', Sites: s, Cost: cost, IntervalMinutes: iv, ChangeNotification: cn, Scheduled: n === 'HQ-South', Transport: 'IP', Status: 'OK', Problems: [] });
    rows.push({ Kind: 'bridge', Name: 'DEFAULTIPSITELINKBRIDGE (automatic)', SiteLinks: links.map((l) => l[0]), Status: 'OK' });
    for (const [s, list] of Object.entries(sub)) for (const n of list) rows.push({ Kind: 'subnet', Name: n, Site: s, Location: s, Description: '', Status: 'OK' });
    rows.push({ Kind: 'subnet', Name: '10.50.0.0/24', Site: null, Location: 'Warehouse', Description: 'New warehouse VLAN', Status: 'Warning' });
    return env('ad.sites', rows, { sites: SITES.length, links: links.length, subnets: 5, orphanSubnets: 1, sitesWithoutDc: rows.filter((r) => r.Kind === 'site' && !r.DomainControllers.length).length });
  }
  function serverEvents() {
    const rows = servers.filter((s) => !s.offline).map((s) => {
      const hot = { APP03: [2, 41], SQL02: [0, 63], EXCH02: [0, 28] }[s.name];
      return { ComputerName: s.name, Hours: 24, Critical: hot ? hot[0] : 0, Errors: hot ? hot[1] : int(0, 9), Warnings: int(2, 60), TopSource: hot ? { APP03: 'Kernel-Power', SQL02: 'MSSQLSERVER', EXCH02: 'MSExchangeTransport' }[s.name] : pick(['Service Control Manager', 'DistributedCOM', 'Schannel']), TopEventId: hot ? { APP03: 41, SQL02: 17883, EXCH02: 15004 }[s.name] : pick([7000, 10016, 36887]), TopCount: hot ? hot[1] : int(1, 6), LastCritical: hot && hot[0] ? iso(NOW() - 6.5 * H) : null };
    });
    return env('servers.events', rows, { servers: rows.length, critical: rows.reduce((a, r) => a + r.Critical, 0), errors: rows.reduce((a, r) => a + r.Errors, 0) });
  }

  // ------------------------------------------------------------------ cloud storage (Azure, AWS, Google Cloud, OCI, Huawei Cloud)
  function cloudStorage() {
    const accts = [
      ['Azure', 'moncastlebackup', 'westeurope', [['vm-backups', 'Cool', 18420, 912000, 0.4], ['sql-dumps', 'Hot', 3360, 48800, 2.1], ['archive-2025', 'Archive', 41200, 2210000, 0], ['public-assets', 'Hot', 42, 6100, 0.2, 'public']]],
      ['Azure', 'moncastlelogs', 'northeurope', [['insights-logs', 'Hot', 912, 3420000, 6.8], ['diagnostics', 'Cool', 210, 880000, 1.2]]],
      ['AWS', '481516234200', 'eu-central-1', [['moncastle-veeam-offsite', 'STANDARD_IA', 26800, 1420000, 0.9], ['moncastle-cloudtrail', 'STANDARD', 640, 9100000, 1.6], ['moncastle-web-static', 'STANDARD', 18, 2400, 0, 'public'], ['moncastle-tmp-exports', 'STANDARD', 2900, 18200, 41.5, 'noenc']]],
      ['Google Cloud', 'moncastle-prod', 'europe-west3', [['mc-bq-exports', 'NEARLINE', 1740, 12400, 0.7], ['mc-ml-datasets', 'STANDARD', 5260, 410000, 3.4]]],
      ['Oracle Cloud', 'moncastle-tenancy', 'me-jeddah-1', [['erp-rman-backups', 'Standard', 12100, 3800, 1.1], ['erp-archive', 'Archive', 30200, 920, 0]]],
      ['Huawei Cloud', 'moncastle-hwc', 'af-north-1', [['obs-dr-replica', 'STANDARD', 8800, 640000, 0.6], ['obs-media', 'WARM', 1320, 220000, 0.3]]],
    ];
    const rows = [];
    for (const [prov, acct, region, buckets] of accts) {
      const lat = prov === 'Azure' ? int(38, 70) : prov === 'AWS' ? int(30, 55) : prov === 'Oracle Cloud' ? int(60, 95) : prov === 'Huawei Cloud' ? int(120, 180) : int(40, 75);
      const bs = buckets.map(([n, cls, gb, objs, growth, flag]) => {
        const problems = [];
        if (flag === 'public') problems.push('Public read access is enabled');
        if (flag === 'noenc') problems.push('Default encryption is off');
        if (growth > 25) problems.push('Grew ' + growth + '% in 24 hours');
        return { Kind: 'Bucket', Provider: prov, Account: acct, Region: region, Name: n, Class: cls, UsedGB: gb, Objects: objs, ChangePct24h: growth,
          Versioning: /backup|veeam|rman|replica|cloudtrail/.test(n) ? 'Enabled' : 'Disabled', Encryption: flag === 'noenc' ? 'None' : prov === 'Azure' ? 'Microsoft-managed keys' : prov === 'AWS' ? 'SSE-KMS' : 'Provider-managed',
          PublicAccess: flag === 'public', Replication: /backup|veeam|rman/.test(n) ? 'Cross-region' : 'None', Lifecycle: /archive|logs|cloudtrail|tmp/.test(n) ? 'Delete after 365 days' : /veeam|backup/.test(n) ? 'Move to archive after 90 days' : 'None',
          ImmutableDays: /veeam|rman/.test(n) ? 30 : 0, LastModified: iso(NOW() - int(1, 90) * 60e3), Status: problems.length ? (flag ? 'Critical' : 'Warning') : 'OK', Problems: problems };
      });
      rows.push({ Kind: 'Account', Provider: prov, Account: acct, Region: region, Endpoint: prov === 'Azure' ? acct + '.blob.core.windows.net' : prov === 'AWS' ? 's3.' + region + '.amazonaws.com' : prov === 'Google Cloud' ? 'storage.googleapis.com' : prov === 'Oracle Cloud' ? 'objectstorage.' + region + '.oraclecloud.com' : 'obs.' + region + '.myhuaweicloud.com',
        Buckets: bs.length, UsedGB: round(bs.reduce((a, b) => a + b.UsedGB, 0)), Objects: bs.reduce((a, b) => a + b.Objects, 0), PublicBuckets: bs.filter((b) => b.PublicAccess).length, Unencrypted: bs.filter((b) => b.Encryption === 'None').length,
        LatencyMs: lat, MonthlyCostUSD: round(bs.reduce((a, b) => a + b.UsedGB * ({ Hot: 0.018, Cool: 0.01, Archive: 0.002, STANDARD: 0.023, STANDARD_IA: 0.0125, NEARLINE: 0.01, Standard: 0.0255, WARM: 0.012 }[b.Class] || 0.02), 0), 0), Status: bs.some((b) => b.Status === 'Critical') ? 'Critical' : bs.some((b) => b.Status === 'Warning') ? 'Warning' : 'OK', Problems: [] });
      rows.push(...bs);
    }
    const b = rows.filter((r) => r.Kind === 'Bucket');
    return env('cloud.storage', rows, { accounts: rows.length - b.length, buckets: b.length, totalTB: round(b.reduce((a, x) => a + x.UsedGB, 0) / 1024), publicBuckets: b.filter((x) => x.PublicAccess).length, providers: [...new Set(rows.map((r) => r.Provider))].length });
  }

  // ------------------------------------------------------------------ database servers other than SQL Server
  function databases(now = NOW()) {
    const defs = [
      ['ORA01', 'oracle', 'ERPPRD', 'Oracle Database 19c Enterprise Edition 19.22.0.0.0', 1521, 2840, 412, 1000, 'Primary', null, 98.7, 3, 9.5],
      ['ORA02', 'oracle', 'ERPSTBY', 'Oracle Database 19c Enterprise Edition 19.22.0.0.0', 1521, 2836, 38, 1000, 'Physical standby', 14, 97.9, 0, 9.5],
      ['PGSQL01', 'postgres', 'pgsql01', 'PostgreSQL 16.4', 5432, 412, 186, 300, 'Primary', null, 99.4, 12, 20],
      ['PGSQL02', 'postgres', 'pgsql02', 'PostgreSQL 16.4', 5432, 410, 22, 300, 'Replica', 2, 99.1, 0, 20],
      ['MYSQL01', 'mysql', 'mysql01', 'MySQL 8.0.39', 3306, 168, 271, 300, 'Source', null, 96.2, 41, 30],
      ['MARIA01', 'mariadb', 'maria01', 'MariaDB 10.11.8', 3306, 54, 48, 151, 'Standalone', null, 98.8, 2, 76],
      ['MONGO01', 'mongodb', 'rs-prod', 'MongoDB 7.0.12', 27017, 960, 640, 51200, 'Primary', null, 94.1, 18, 22],
      ['MONGO02', 'mongodb', 'rs-prod', 'MongoDB 7.0.12', 27017, 958, 120, 51200, 'Secondary', 1, 93.8, 0, 22],
      ['REDIS01', 'redis', 'cache-prod', 'Redis 7.2.5', 6379, 11.6, 812, 10000, 'Master', null, 99.8, 0, null],
      ['ELASTIC01', 'elastic', 'logs-prod', 'Elasticsearch 8.15.1', 9200, 2210, 46, null, 'Yellow (2 unassigned shards)', null, null, 7, null],
      ['CASS01', 'cassandra', 'iot-ring', 'Apache Cassandra 4.1.5', 9042, 1640, 96, null, 'UN (3 of 3 nodes up)', null, 91.2, 0, null],
      ['COUCH01', 'couchdb', 'couch01', 'CouchDB 3.3.3', 5984, 84, 31, null, '3 of 3 nodes in cluster', null, null, 0, 20],
      ['CBASE01', 'couchbase', 'cbase01', 'Couchbase 7.6.2', 8091, 312, null, null, '3 of 3 nodes healthy · 4 buckets · 2140 ops/s', null, null, null, null],
      ['DB2PRD', 'db2', 'SAMPLE', 'IBM Db2 DB2 v11.5.9.0', 50000, 1220, 148, null, 'ODBC · DB2CLI.DLL', null, null, null, null],
      ['HANA01', 'hana', 'HDB', 'SAP HANA 2.00.076.00', 30015, 1890, 64, null, 'ODBC · HDBODBC', null, null, null, null],
      ['ASE01', 'sybase', 'ase01', 'SAP ASE Adaptive Server Enterprise/16.0 SP04', 5000, 140, 214, 250, 'ODBC · Adaptive Server Enterprise', null, null, null, null],
      ['CRDB01', 'cockroach', 'crdb-prod', 'CockroachDB CCL v24.2.3', 26257, 380, 96, null, null, null, null, null, null],
      ['CLICK01', 'clickhouse', 'click01', 'ClickHouse 24.8.4.13', 8123, 2650, null, null, 'HTTPS 200', null, null, null, null],
      ['MEMC01', 'memcached', 'memc01', 'Memcached 1.6.29', 11211, 3.2, 210, 1024, '80% of 4 GB used · 1.2M items', null, 91.4, null, null],
      ['INFLUX01', 'influxdb', 'influx01', 'InfluxDB 2.7.10', 8086, 420, null, null, 'HTTP 200', null, null, null, null],
      ['NEO4J01', 'neo4j', 'neo4j01', 'Neo4j Kernel 5.24.0 enterprise', 7687, 96, null, null, 'Bolt', null, null, null, null],
      ['QDRANT01', 'qdrant', 'qdrant01', 'Qdrant 1.12.4', 6333, 58, null, null, 'HTTP 200', null, null, null, null],
      ['AERO01', 'aerospike', 'aero01', 'Aerospike', 3000, null, null, null, 'Port answers', null, null, null, null],
    ];
    const CAT = { oracle: 'Relational', postgres: 'Relational', mysql: 'Relational', mariadb: 'Relational', db2: 'Relational', hana: 'Relational', sybase: 'Relational', cockroach: 'Distributed SQL', clickhouse: 'Analytics', mongodb: 'Document', couchdb: 'Document', couchbase: 'Document', redis: 'Key-value', memcached: 'Key-value', aerospike: 'Key-value', cassandra: 'Wide-column', elastic: 'Search', influxdb: 'Time series', neo4j: 'Graph', qdrant: 'Vector' };
    const PRODUCT = { oracle: 'Oracle Database', postgres: 'PostgreSQL', mysql: 'MySQL', mariadb: 'MariaDB', db2: 'IBM Db2', hana: 'SAP HANA', sybase: 'SAP ASE (Sybase)', cockroach: 'CockroachDB', clickhouse: 'ClickHouse', mongodb: 'MongoDB', couchdb: 'Apache CouchDB', couchbase: 'Couchbase', redis: 'Redis', memcached: 'Memcached', aerospike: 'Aerospike', cassandra: 'Apache Cassandra', elastic: 'Elasticsearch', influxdb: 'InfluxDB', neo4j: 'Neo4j', qdrant: 'Qdrant' };
    const BY = { oracle: 'sqlplus', postgres: 'psql', cockroach: 'psql', mysql: 'mysql', mariadb: 'mysql', mongodb: 'mongosh', redis: 'redis-cli', cassandra: 'nodetool', db2: 'ODBC', hana: 'ODBC', sybase: 'ODBC', memcached: 'memcached stats', neo4j: 'cypher-shell', aerospike: 'TCP' };
    const rows = defs.map(([host, engine, inst, ver, port, gb, conn, max, role, lag, hit, slow, backup]) => {
      const problems = [];
      if (backup != null && backup > 26) problems.push('Last backup ' + backup + ' h ago');
      if (max && conn / max > 0.85) problems.push('Connections at ' + Math.round((conn / max) * 100) + '% of the limit');
      if (lag != null && lag > 10) problems.push('Replication lag ' + lag + ' s');
      if (/Yellow/.test(role)) problems.push('Cluster health is yellow');
      if (slow > 30) problems.push(slow + ' slow queries in the last hour');
      const ms = engine === 'aerospike' ? 2 : int(3, engine === 'clickhouse' ? 90 : 40);
      return { Host: host, Address: { ORA01: '10.10.7.21', ORA02: '10.20.7.21', PGSQL01: '10.10.7.31', PGSQL02: '10.20.7.31', MYSQL01: '10.10.7.41', MARIA01: '10.10.7.42', MONGO01: '10.10.7.51', MONGO02: '10.20.7.51', REDIS01: '10.10.7.61', ELASTIC01: '10.10.7.71', CASS01: '10.10.7.81', COUCH01: '10.10.7.91', CBASE01: '10.10.7.92', DB2PRD: '10.10.8.11', HANA01: '10.10.8.21', ASE01: '10.10.8.31', CRDB01: '10.10.8.41', CLICK01: '10.10.8.51', MEMC01: '10.10.8.61', INFLUX01: '10.10.8.71', NEO4J01: '10.10.8.81', QDRANT01: '10.10.8.91', AERO01: '10.10.8.95' }[host], Engine: engine, Product: PRODUCT[engine], Category: CAT[engine], CheckedBy: BY[engine] || 'REST', ResponseMs: ms, ConnectMs: Math.max(1, Math.round(ms / 3)), Instance: inst, Version: ver, Port: port, Status: problems.length ? 'Warning' : 'OK', SizeGB: gb, Connections: conn, MaxConnections: max, ConnectionsPct: max && conn != null ? round((conn / max) * 100) : null,
        Role: role, ReplicationLagSec: lag, CacheHitPct: hit, SlowQueries1h: slow, LastBackupHours: backup, LastBackup: backup == null ? null : iso(now - backup * H), UptimeHours: int(200, 4000), Problems: problems, Note: engine === 'aerospike' ? 'Port check only: Aerospike has no deeper collector.' : undefined };
    });
    return env('databases.health', rows, { instances: rows.length, engines: [...new Set(rows.map((r) => r.Engine))].length, categories: [...new Set(rows.map((r) => r.Category))].length, totalTB: round(rows.reduce((a, r) => a + (r.SizeGB || 0), 0) / 1024), warnings: rows.filter((r) => r.Status === 'Warning').length, down: rows.filter((r) => r.Status === 'Down').length });
  }

  // ------------------------------------------------------------------ OS updates (4.5): release, build, pending updates
  // Own random stream, so adding it does not change the other datasets.
  const DEMO_LATEST = { ws2016: '14393.8519', ws2019: '17763.7922', ws2022: '20348.4294', ws2025: '26100.6905', 'win10-22h2': '19045.6456', 'win11-23h2': '22631.6060', 'win11-24h2': '26100.6905', 'ubuntu-22.04': '22.04.5', 'ubuntu-24.04': '24.04.3', 'debian-12': '12.12', 'rocky-9': '9.6', 'ol-8': '8.10', 'sles-15': '15.7' };
  function updatesStatus() {
    const U = rng(4504);
    const ui = (a, b) => a + Math.floor(U() * (b - a + 1));
    const t = NOW();
    const ubrBack = (latest, steps) => { const [b, r] = latest.split('.'); return b + '.' + Math.max(1, +r - steps); };
    const rows = [];
    for (const sv of servers) {
      if (sv.offline) { rows.push({ Name: sv.name, Platform: 'Windows', OS: sv.os, Status: 'Unreachable', Problems: ['WinRM did not answer'] }); continue; }
      const fam = /2016/.test(sv.os) ? 'ws2016' : /2019/.test(sv.os) ? 'ws2019' : /2025/.test(sv.os) ? 'ws2025' : 'ws2022';
      const back = U() < 0.55 ? 0 : U() < 0.7 ? ui(40, 120) : ui(200, 600);
      const days = back ? ui(35, 95) : ui(3, 28);
      const pend = back ? ui(1, 6) : U() < 0.2 ? 1 : 0;
      rows.push({ Name: sv.name, Platform: 'Windows', OS: sv.os, Version: { ws2016: '1607', ws2019: '1809', ws2022: '21H2', ws2025: '24H2' }[fam], Build: ubrBack(DEMO_LATEST[fam], back), Kernel: null,
        PendingUpdates: pend, PendingSecurity: back ? Math.min(pend, ui(1, 3)) : 0, LastUpdate: new Date(t - days * D).toISOString(), DaysSinceUpdate: days, LastUpdateName: 'KB50' + ui(40000, 49999),
        RebootPending: U() < 0.12, UpdateSource: sv.site === 'HQ-Main' ? 'WSUS (wsus01.' + DOMAIN + ')' : 'Windows Update for Business', Status: 'OK', Problems: [] });
    }
    for (const w of workstations.slice(0, 60)) {
      const fam = /Windows 11/.test(w.OperatingSystem) ? (U() < 0.7 ? 'win11-24h2' : 'win11-23h2') : /Windows 10/.test(w.OperatingSystem) ? 'win10-22h2' : null;
      if (!fam) { rows.push({ Name: w.Name, Platform: 'Windows', OS: w.OperatingSystem, Version: 'SP1', Build: '7601.24546', PendingUpdates: 0, PendingSecurity: 0, LastUpdate: new Date(t - 900 * D).toISOString(), DaysSinceUpdate: 900, RebootPending: false, UpdateSource: 'none', Status: 'OK', Problems: [] }); continue; }
      const back = U() < 0.6 ? 0 : ui(30, 300), days = back ? ui(30, 80) : ui(2, 25);
      rows.push({ Name: w.Name, Platform: 'Windows', OS: w.OperatingSystem, Version: fam.split('-')[1].toUpperCase(), Build: ubrBack(DEMO_LATEST[fam], back), PendingUpdates: back ? ui(1, 4) : 0, PendingSecurity: back && U() < 0.5 ? 1 : 0,
        LastUpdate: new Date(t - days * D).toISOString(), DaysSinceUpdate: days, LastUpdateName: 'KB50' + ui(40000, 49999), RebootPending: U() < 0.1, UpdateSource: 'Windows Update for Business', Status: 'OK', Problems: [] });
    }
    for (const [n, os] of linuxDefs) {
      const distro = /Ubuntu/.test(os) ? 'ubuntu' : /Oracle/.test(os) ? 'ol' : /Rocky/.test(os) ? 'rocky' : /SUSE/.test(os) ? 'sles' : /Debian/.test(os) ? 'debian' : 'linux';
      const point = (os.match(/(\d+\.\d+(?:\.\d+)?)/) || [])[1] || (/Debian/.test(os) ? '12.7' : '');
      const sp = (os.match(/(\d+) SP(\d+)/) || []);
      const pr = sp.length ? sp[1] + '.' + sp[2] : /Debian/.test(os) ? '12.7' : point;
      const version = distro === 'ubuntu' ? pr.split('.').slice(0, 2).join('.') : pr.split('.')[0];
      const pend = n === 'NFS01' ? 64 : n.startsWith('ORA') ? 23 : ui(0, 12), days = n === 'NFS01' ? 118 : ui(4, 40);
      rows.push({ Name: n, Platform: 'Linux', OS: os, Distro: distro, Version: version, PointRelease: pr, Build: null, Kernel: distro === 'ubuntu' ? '5.15.0-' + ui(100, 125) + '-generic' : '5.14.0-' + ui(300, 430) + '.el9.x86_64',
        PendingUpdates: pend, PendingSecurity: pend ? Math.min(pend, ui(0, 6)) : 0, LastUpdate: new Date(t - days * D).toISOString(), DaysSinceUpdate: days, LastUpdateName: distro === 'ubuntu' || distro === 'debian' ? 'apt upgrade' : distro === 'sles' ? 'zypper patch' : 'dnf update',
        RebootPending: U() < 0.3, UpdateSource: distro === 'ubuntu' ? 'archive.ubuntu.com' : distro === 'sles' ? 'SUSE Customer Center' : distro === 'debian' ? 'deb.debian.org' : 'Satellite / mirror', Status: 'OK', Problems: [] });
    }
    return env('updates.status', rows, { machines: rows.length, windows: rows.filter((r) => r.Platform === 'Windows').length, linux: rows.filter((r) => r.Platform === 'Linux').length, pending: rows.reduce((a, r) => a + (r.PendingUpdates || 0), 0) });
  }

  const builders = {
    'servers.compute': compute, 'servers.disks': disks, 'servers.availability': availability, 'servers.services': services, 'servers.iis': iis, 'servers.activation': activation,
    'inventory.hardware': hardware, 'inventory.roles': roles, 'inventory.software': software, 'inventory.printers': printersInv, 'inventory.workstations': workstationsInv,
    'ad.users': adUsers, 'ad.computers': adComputers, 'ad.groups': adGroups, 'ad.deleted': adDeleted, 'ad.security': adSecurity, 'ad.health': adHealth, 'ad.replication': adReplication,
    'network.dhcp': dhcp, 'network.discovery': discovery, 'network.devices': netSnmp, 'storage.devices': storageSnmp, 'printers.health': printersHealth,
    'virtualization.hyperv': hyperv, 'virtualization.vmware': vmware, 'virtualization.openshift': openshift, 'virtualization.nutanix': nutanix, 'virtualization.clusters': clusters, 'virtualization.clusterstorage': clusterStorage,
    'sql.databases': sqlDatabases, 'linux.hosts': linux, 'databases.health': databases, 'cloud.storage': cloudStorage,
    'security.defender': defender, 'security.patches': patches, 'security.firewall': firewall, 'security.localadmins': localAdmins, 'security.fileacl': fileAcl,
    'audit.events': audit,
    'dns.servers': dnsServers, 'fileserver.health': fileServerHealth, 'ad.gpo': gpo, 'ad.sites': adSites, 'servers.events': serverEvents,
    'updates.status': updatesStatus,
    'linux.filesystems': linuxFs, 'linux.services': linuxServices, 'linux.audit': linuxAudit, 'web.servers': webServers, 'ssl.certificates': sslCerts,
    'hardware.temperature': temperature, 'web.hosts': webHosts, 'cloud.databases': cloudDatabases, 'containers.kubernetes': kubernetes, 'containers.docker': docker, 'network.cloud': cloudNetwork,
    'entra.users': entraUsers, 'entra.devices': entraDevices, 'entra.groups': entraGroups, 'entra.health': entraHealth, 'intune.devices': intuneDevices, 'intune.health': intuneHealth,
  };

  // devices onboarded in the demo (by hand, auto-discovery or import): their inventory rows, as the collectors would return them
  const onboarded = new Map();
  function onboardRows(ds, d) {
    const h = Array.from(String(d.name)).reduce((a, c) => a + c.charCodeAt(0), 0);
    const n = String(d.name).toUpperCase(), when = (days) => iso(NOW() - days * D);
    const win = !/linux/i.test(d.kind + ' ' + (d.os || ''));
    switch (ds) {
      case 'inventory.hardware': return [{ Name: n, Domain: DOMAIN, ADSite: 'HQ-Main', Manufacturer: h % 2 ? 'VMware, Inc.' : 'Dell Inc.', Model: h % 2 ? 'VMware7,1' : 'PowerEdge R650', SerialNumber: 'MC' + (100000 + h * 37), BIOSVersion: '2.17.1', ChassisTypes: [h % 2 ? 1 : 23], OperatingSystem: d.kind === 'workstation' ? 'Microsoft Windows 11 Enterprise' : 'Microsoft Windows Server 2022 Standard', OSVersion: '10.0.20348', OSBuild: '20348', InstallDate: when(200 + h % 300), LastBoot: when(1 + h % 20), UptimeDays: 1 + h % 20, CPUModel: 'Intel(R) Xeon(R) Gold 6338 CPU @ 2.00GHz', CPUSockets: 1, CPUCores: 4 + (h % 3) * 4, CPULogical: 8 + (h % 3) * 8, RAMGB: 16 + (h % 4) * 16, DiskTotalGB: 200, DiskFreeGB: 90, IPAddress: [d.host], MacAddress: ['00:50:56:' + pad(h % 99) + ':1A:2B'], LoggedOnUser: null, LastLoggedOnUser: 'CORP\\admin.marco', InstalledRoles: d.kind === 'workstation' ? [] : ['File and Storage Services', 'Web Server (IIS)'], SqlServices: [], IISState: d.kind === 'workstation' ? null : 'Running', TPMPresent: true, TPMEnabled: true, Online: true, MachineType: h % 2 ? 'Virtual' : 'Physical', Chassis: h % 2 ? 'Other' : 'Rack Mount Chassis', Roles: [], Onboarded: true }];
      case 'inventory.software': return win ? [['Microsoft Edge', 'Microsoft Corporation'], ['7-Zip 23.01 (x64)', 'Igor Pavlov'], ['Microsoft Visual C++ 2015-2022 Redistributable (x64)', 'Microsoft Corporation'], ['Notepad++ (64-bit x64)', 'Notepad++ Team']].map(([nm, v], i) => ({ ComputerName: n, Name: nm, Version: (120 + i) + '.0.' + (h % 900), Vendor: v, InstallDate: '2026' + pad(1 + (h + i) % 12) + '01', Architecture: 'x64' })) : [['openssh-server', '1:9.6p1-3ubuntu13.5', 'OpenSSH'], ['openssl', '3.0.13-0ubuntu3.4', 'OpenSSL'], ['curl', '8.5.0-2ubuntu10.4', 'curl'], ['python3', '3.12.3-0ubuntu2', 'Python']].map(([nm, ver, v]) => ({ ComputerName: n, Platform: 'Linux', OS: d.os || 'Linux', Name: nm, Version: ver, Vendor: 'Ubuntu Developers', Architecture: 'amd64', Source: 'dpkg' }));
      case 'inventory.roles': return [{ ComputerName: n, Roles: ['FileServers', 'IIS'], Features: 14 + h % 10, Online: true }];
      case 'servers.services': return [['WinRM', 'Windows Remote Management (WS-Management)'], ['EventLog', 'Windows Event Log'], ['W32Time', 'Windows Time'], ['W3SVC', 'World Wide Web Publishing Service']].map(([sn, dn]) => ({ ComputerName: n, Name: sn, DisplayName: dn, State: 'Running', StartMode: 'Auto', Account: 'LocalSystem', Problem: false }));
      case 'linux.hosts': return win ? [] : [{ Name: n, hostname: n.toLowerCase(), os: 'Ubuntu 24.04.1 LTS', kernel: '6.8.0-45-generic', arch: 'x86_64', machineType: 'Virtual', vendor: 'VMware, Inc.', model: 'VMware7,1', serial: 'VMware-56 4d ' + h, cpuModel: 'Intel(R) Xeon(R) Gold 6338 CPU @ 2.00GHz', cpuCount: 4, cpuPct: 12 + h % 30, load: [0.4, 0.5, 0.6], memTotalGB: 16, memUsedPct: 40 + h % 30, swapTotalGB: 4, swapUsedPct: 0, uptimeHours: 100 + h % 900, ipAddresses: [d.host], disks: [{ fs: '/dev/sda1', type: 'ext4', sizeGB: 100, usedPct: 35 + h % 40, mount: '/' }], topProcesses: [], packageManager: 'apt', packages: 700 + h % 500, updates: h % 9, securityUpdates: h % 3, oracleInstances: [], loggedOnUsers: [], failedUnits: 0, Online: true, WorstDiskPct: 35 + h % 40, Status: 'OK', Site: 'HQ-Main', Onboarded: true }];
      default: {
        // any other inventory dataset: the rows the engines return for one comparable machine, renamed to this device
        const b = builders[ds] ? builders[ds]() : null, rows = (b && b.data) || [];
        const key = ['ComputerName', 'PrintServer', 'Name'].find((k) => rows[0] && k in rows[0]);
        if (!key) return [];
        const ws = d.kind === 'workstation', isWs = (r) => /^WS-/i.test(String(r[key])) || /Windows 1[01]/.test(r.OperatingSystem || '');
        let pickRows = rows.filter((r) => (win ? !/linux|ubuntu|red hat|debian/i.test(JSON.stringify(r)) : /linux|ubuntu|red hat|debian/i.test(JSON.stringify(r))));
        // a workstation looks like another workstation, a server like a plain server (not a SQL or file server)
        const like = pickRows.filter((r) => (ws ? isWs(r) : !isWs(r) && !/^(SQL|FS)/i.test(String(r[key]))));
        if (like.length) pickRows = like; else if (ws) return [];
        const first = (pickRows[h % Math.max(1, pickRows.length)] || rows[0])[key];
        return rows.filter((r) => r[key] === first).slice(0, 12).map((r) => Object.assign({}, r, { [key]: n }, r.OperatingSystem && d.os ? { OperatingSystem: d.os } : {}));
      }
    }
  }
  // audit events read from devices someone added by hand (Inventory > Audit > Sources): the same rows aud.events returns
  const audited = new Map();
  function auditRows(d, now = NOW()) {
    const name = String(d.name).split('.')[0].toUpperCase();
    let h = 0; for (const c of name) h = (h * 31 + c.charCodeAt(0)) >>> 0;
    const r = () => ((h = (h * 1103515245 + 12345) >>> 0) % 10000) / 10000;
    const base = { Server: name, Actor: null, Target: null, Group: null, SourceIP: null, Workstation: null, Attribute: null, Value: null, Reason: null, Privileged: false };
    const rows = [], ev = (set, title, id, sev, extra, ageH) => rows.push(Object.assign({ Time: new Date(now - ageH * 36e5).toISOString(), EventSet: set, Title: title, EventId: id, Severity: sev }, base, extra));
    const admins = ['admin.marco', 'admin.sara', 'admin.omar'];
    for (let i = 0; i < 6 + Math.floor(r() * 6); i++) ev('RemoteLogon', 'Remote desktop logon', 21, 'Info', { Actor: 'CORP\\' + admins[Math.floor(r() * 3)], SourceIP: '10.10.1.' + (20 + Math.floor(r() * 80)) }, r() * 160);
    for (let i = 0; i < 4 + Math.floor(r() * 10); i++) ev('BadLogon', 'Failed logon', 4625, 'Warning', { Target: i < 3 ? 'administrator' : 'svc_' + name.toLowerCase(), SourceIP: '10.10.51.' + (2 + Math.floor(r() * 240)), Reason: i < 3 ? 'Bad username or password' : 'Incorrect password' }, r() * 72);
    ev('ShutdownRestart', 'Shutdown / restart', 1074, 'Info', { Actor: 'CORP\\' + admins[Math.floor(r() * 3)], Reason: 'Operating System: Service pack (Planned)' }, 20 + r() * 120);
    if (/^(FS|FILE)/i.test(name) || /file/i.test(d.role || '')) for (let i = 0; i < 8; i++) ev('FileAccess', 'File share access', 5145, 'Info', { Actor: 'CORP\\' + ['m.hassan', 'n.adel', 'k.samir'][i % 3], Target: 'Shares\\Projects\\plan-' + i + '.docx' }, r() * 160);
    return rows.sort((a, b) => (a.Time < b.Time ? 1 : -1));
  }
  function auditOn(d) { if (d && d.name) audited.set(String(d.name).split('.')[0].toUpperCase(), d); }
  function onboard(d, plan) { if (d && d.name) onboarded.set(String(d.name).toUpperCase(), { d, sets: (plan || []).map((x) => x.dataset) }); }
  function all() {
    const out = {};
    for (const k of Object.keys(builders)) out[k] = builders[k]();
    for (const { d, sets } of onboarded.values()) for (const k of sets) {
      if (!out[k]) continue;
      const rows = onboardRows(k, d); if (!rows.length) continue;
      const key = ['ComputerName', 'PrintServer', 'Name'].find((x) => x in rows[0]) || 'ComputerName', names = new Set(rows.map((r) => r[key]));
      out[k] = Object.assign({}, out[k], { data: (out[k].data || []).filter((r) => !names.has(r[key])).concat(rows) });
      out[k].count = out[k].data.length;
    }
    if (audited.size && out['audit.events']) {
      const extra = [...audited.values()].flatMap((d) => auditRows(d)), names = new Set(audited.keys());
      const data = (out['audit.events'].data || []).filter((r) => !names.has(String(r.Server || '').toUpperCase())).concat(extra).sort((a, b) => (a.Time < b.Time ? 1 : -1));
      out['audit.events'] = Object.assign({}, out['audit.events'], { data, count: data.length });
    }
    return out;
  }

  return { all, onboard, auditOn, audited: () => [...audited.keys()], onboarded: () => [...onboarded.values()].map((x) => x.d.name), build: (id) => (builders[id] ? builders[id]() : null), computeHistory, simulate, datasets: Object.keys(builders), domain: DOMAIN, sites: SITES, DEMO_LATEST };
});
