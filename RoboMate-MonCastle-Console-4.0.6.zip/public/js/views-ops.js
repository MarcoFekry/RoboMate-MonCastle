/*
 * RoboMate MonCastle - operations views: overview, resource map, resource drawer, monitoring,
 * virtualization, identity & AD, network, Linux.
 */
(function (root) {
  'use strict';
  const MC = root.MC, C = root.MCCharts, M = root.MCModel;
  const { esc, fmt, pill, icon, sevIcon, ago, dt, minibar, $, $$ } = MC;
  const V = MC.views;
  const avg = (a) => { a = a.filter((v) => v != null && !isNaN(v)); return a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0; };
  const pct = (a, b) => (b ? Math.round((a / b) * 100) : 0);
  const sum = (a) => a.reduce((x, y) => x + (y || 0), 0);
  const countBy = (list, f) => Object.entries(list.reduce((a, x) => { const k = f(x) || 'Unknown'; a[k] = (a[k] || 0) + 1; return a; }, {})).sort((a, b) => b[1] - a[1]);
  const hostAttr = (n) => `data-host="${esc(n)}" tabindex="0" role="button" style="cursor:pointer"`;

  // fleet series from per-server history
  function fleetSeries(metric) {
    const h = MC.history || {};
    const names = Object.keys(h).filter((n) => h[n] && h[n].length);
    if (!names.length) return [];
    const len = Math.min(...names.map((n) => h[n].length));
    const out = [];
    for (let i = 0; i < len; i++) {
      const vals = names.map((n) => h[n][i][metric]).filter((v) => v != null);
      const sorted = vals.slice().sort((a, b) => a - b);
      out.push({ t: h[names[0]][i].t, avg: avg(vals), p95: sorted[Math.floor(sorted.length * 0.95)] || 0, max: sorted[sorted.length - 1] || 0 });
    }
    return out;
  }

  // ================================================================== OVERVIEW
  V.overview = {
    title: 'Overview',
    crumb: () => MC.summary.total + ' resources across ' + MC.summary.categories.filter((c) => c.total).length + ' categories',
    render(el) {
      const s = MC.summary, ins = MC.model.insights;
      const comp = MC.data('servers.compute'), avail = MC.data('servers.availability');
      const online = avail.filter((a) => a.Status !== 'Offline').length;
      const crit = (s.counts.Critical || 0) + (s.counts.Offline || 0);
      const patches = MC.data('security.patches').filter((p) => p.Status !== 'Unreachable');
      const patched = patches.filter((p) => p.DaysSincePatch <= 35).length;
      const ev24 = MC.data('audit.events').filter((e) => Date.now() - Date.parse(e.Time) < 864e5);
      const fails = ev24.filter((e) => e.EventSet === 'BadLogon' || e.EventSet === 'KerberosPreAuthFailed').length;
      const fs = fleetSeries('cpu');
      const empty = !Object.keys(MC.ds || {}).length;
      el.innerHTML = `
        ${empty ? `<div class="notice">${icon('info', 'sev-ico')} <b>No data collected yet.</b> Collectors run on their schedules once the licence is valid and the console has read the scripts from GitHub (Actions &gt; Remote scripting &gt; Script library). You can also run any collector now from the <a href="#/remote/library">Script library</a>.</div>` : ''}
        <div class="kpis">
          ${MC.kpi('Resources monitored', fmt(s.total, 0), `${s.counts.OK || 0} healthy`, { href: '#/map' })}
          ${MC.kpi('Need attention', crit + (s.counts.Warning || 0), `<span style="color:var(--crit-ink)">${crit} critical</span> · ${s.counts.Warning || 0} warning`, { alert: crit > 0, href: '#/map?status=bad' })}
          ${MC.kpi('Server availability', pct(online, avail.length) + '%', `${online} of ${avail.length} online`, { alert: online < avail.length, href: '#/monitoring/availability' })}
          ${MC.kpi('Fleet CPU (avg)', fmt(avg(comp.map((c) => c.CPU)), 0) + '%', (comp.length ? 'peak ' + fmt(Math.max(...comp.map((c) => c.CPU || 0)), 0) + '% on ' + esc((comp.slice().sort((a, b) => b.CPU - a.CPU)[0] || {}).Name || '') : 'no samples yet'), { spark: true, href: '#/monitoring/compute' })}
          ${MC.kpi('Patch compliance', pct(patched, patches.length) + '%', patched + ' of ' + patches.length + ' patched in 35 days', { href: '#/security/patches' })}
          ${MC.kpi('Failed sign-ins (24 h)', fmt(fails, 0), ev24.filter((e) => e.EventSet === 'Lockout').length + ' lockouts', { alert: fails > 50, href: '#/audit' })}
        </div>
        <div class="grid g-2-1">
          ${MC.panel('Fleet compute, last 24 hours', 'average and 95th percentile across ' + comp.length + ' servers', '<div id="fleetChart"></div>', { act: '<div class="seg" id="fleetMetric"><button class="on" data-m="cpu">CPU</button><button data-m="mem">Memory</button></div>' })}
          ${MC.panel('Health by category', 'unique resources', `<div class="cat-matrix">${s.categories.filter((c) => c.total).map((c) => `<div class="cat-row" data-href="#/map?cat=${c.id}" tabindex="0" role="button">${icon(MC.CAT_ICON[c.id])}<div><b>${esc(c.name)}</b><small>${esc(c.hint)}</small></div>${C.statusStack(c.counts)}<span class="n">${c.total}</span></div>`).join('')}</div>
            <div class="mc-legend" style="margin-top:12px">${['OK', 'Warning', 'Critical', 'Offline'].map((k) => `<span><i style="background:var(${C.STATUS[k]})"></i>${k}<b>${s.counts[k] || 0}</b></span>`).join('')}</div>`)}
        </div>
        <div class="grid g-2-1">
          ${MC.panel('What needs attention', ins.length + ' insights from the latest collection', `<div class="insights" id="insList">${ins.slice(0, 7).map(MC.insightRow).join('')}</div>${ins.length > 7 ? `<button class="btn sm" id="moreIns" style="margin-top:10px">Show all ${ins.length}</button>` : ''}`)}
          <div class="grid">
            ${MC.panel('Busiest servers', 'CPU now', C.barList(comp.slice().sort((a, b) => b.CPU - a.CPU).slice(0, 7).map((c) => ({ label: c.Name, sub: (c.TopProcess || '').split(' ')[0], value: c.CPU, text: fmt(c.CPU, 0) + '%', status: c.CPU >= 90 ? 'Critical' : c.CPU >= 75 ? 'Warning' : null, color: '--s1', href: '#/monitoring/compute' })), { max: 100, compact: true }))}
            ${MC.panel('Storage pressure', 'fullest volumes', C.barList(MC.data('servers.disks').slice().sort((a, b) => b.UsedPct - a.UsedPct).slice(0, 6).map((d) => ({ label: d.ComputerName + ' ' + d.Volume, sub: fmt(d.FreeGB, 0) + ' GB free', value: d.UsedPct, text: fmt(d.UsedPct, 0) + '%', status: d.Status !== 'OK' ? d.Status : null, color: '--s1', href: '#/monitoring/storage' })), { max: 100, compact: true }))}
          </div>
        </div>
        <div class="grid g3">
          ${MC.panel('Sign-in and change activity', 'audit events per hour, last 24 h', '<div id="auditCols"></div>', { act: '<button class="btn sm ghost" data-href="#/audit">Open audit</button>' })}
          ${MC.panel('Endpoint protection', 'Defender on servers', '<div id="defDonut"></div>', { act: '<button class="btn sm ghost" data-href="#/security/defender">Details</button>' })}
          ${MC.panel('Virtualization capacity', 'hosts and datastores', capBars(), { act: '<button class="btn sm ghost" data-href="#/virtualization">Open</button>' })}
        </div>`;
      const drawFleet = (m) => {
        const f = m === 'cpu' ? fs : fleetSeries('mem');
        C.timeSeries($('#fleetChart'), [
          { name: 'Average', points: f.map((p) => ({ t: p.t, v: p.avg })), color: '--s1' },
          { name: '95th percentile', points: f.map((p) => ({ t: p.t, v: p.p95 })), color: '--s4' },
        ], { unit: '%', yMax: 100, threshold: 85, height: window.innerWidth < 860 ? 240 : 440, label: 'Fleet ' + m });
      };
      drawFleet('cpu');
      $$('#fleetMetric button').forEach((b) => b.addEventListener('click', () => { $$('#fleetMetric button').forEach((x) => x.classList.toggle('on', x === b)); drawFleet(b.dataset.m); }));
      const sp = $('[data-spark]', el);
      if (sp) sp.appendChild(C.sparkline(fs.map((p) => p.avg), { max: 100, label: 'fleet CPU trend' }));
      if ($('#moreIns')) $('#moreIns').addEventListener('click', () => { $('#insList').innerHTML = ins.map(MC.insightRow).join(''); $('#moreIns').remove(); });
      auditColumns($('#auditCols'), ev24, 24);
      const def = MC.data('security.defender');
      C.donut($('#defDonut'), [
        { label: 'Protected', value: def.filter((d) => d.Status === 'OK').length, color: '--ok' },
        { label: 'Warnings', value: def.filter((d) => d.Status === 'Warning').length, color: '--warn' },
        { label: 'At risk', value: def.filter((d) => d.Status === 'Critical').length, color: '--crit' },
      ], { center: pct(def.filter((d) => d.Status === 'OK').length, def.length) + '%', centerLabel: 'protected', label: 'Defender status' });
    },
  };
  function capBars() {
    const hosts = MC.data('virtualization.hyperv').filter((h) => h.Kind === 'Host').map((h) => ({ label: h.Name, sub: h.VMRunning + ' VMs', value: pct(h.MemoryGB - h.MemoryFreeGB, h.MemoryGB), text: pct(h.MemoryGB - h.MemoryFreeGB, h.MemoryGB) + '% mem' }));
    const esx = MC.data('virtualization.vmware').filter((h) => h.Kind === 'ESXi').map((h) => ({ label: h.Name.split('.')[0], sub: h.VMs + ' VMs', value: h.MemoryUsedPct, text: h.MemoryUsedPct + '% mem' }));
    const dsx = MC.data('virtualization.vmware').filter((h) => h.Kind === 'Datastore').map((d) => ({ label: d.Name, sub: fmt(d.FreeGB, 0) + ' GB free', value: d.UsedPct, text: fmt(d.UsedPct, 0) + '%' }));
    const st = (i) => Object.assign(i, { status: i.value >= 90 ? 'Critical' : i.value >= 80 ? 'Warning' : null, color: '--s1', href: '#/virtualization' });
    return C.barList([...hosts, ...esx].map(st), { max: 100, compact: true }) + '<div style="height:10px"></div>' + C.barList(dsx.map(st), { max: 100, compact: true });
  }
  const AUDIT_GROUPS = [
    { key: 'fail', name: 'Failed sign-ins', color: '--s3', sets: ['BadLogon', 'KerberosPreAuthFailed', 'NPS'] },
    { key: 'lock', name: 'Lockouts', color: '--s4', sets: ['Lockout', 'Unlock'] },
    { key: 'chg', name: 'Directory changes', color: '--s1', sets: ['GroupMemberAdded', 'GroupMemberRemoved', 'ObjectModified', 'ObjectCreated', 'ObjectDeleted', 'ObjectMoved', 'GroupCreated', 'PasswordReset', 'PasswordChange', 'AccountDisabled', 'AccountEnabled'] },
    { key: 'oth', name: 'Other', color: '--s2', sets: [] },
  ];
  MC.AUDIT_GROUPS = AUDIT_GROUPS;
  function auditColumns(el, events, hours, onClick) {
    const now = Date.now(), step = hours > 48 ? 864e5 : 36e5, n = hours > 48 ? Math.round(hours / 24) : hours;
    const buckets = [];
    for (let i = n - 1; i >= 0; i--) {
      const end = now - i * step, start = end - step;
      const d = new Date(start);
      buckets.push({ start, end, label: step === 864e5 ? d.toLocaleDateString(undefined, { weekday: 'short' }) : d.getHours() + ':00', title: step === 864e5 ? d.toLocaleDateString() : d.toLocaleString(undefined, { weekday: 'short', hour: '2-digit', minute: '2-digit' }), values: {} });
    }
    events.forEach((e) => {
      const t = Date.parse(e.Time);
      const b = buckets.find((x) => t >= x.start && t < x.end);
      if (!b) return;
      const g = AUDIT_GROUPS.find((x) => x.sets.includes(e.EventSet)) || AUDIT_GROUPS[3];
      b.values[g.key] = (b.values[g.key] || 0) + 1;
    });
    C.columns(el, buckets, AUDIT_GROUPS, { height: 170, label: 'Audit events over time', onClick });
  }
  MC.auditColumns = auditColumns;

  // ================================================================== RESOURCE MAP
  const COLOR_BY = { status: 'Status', cpu: 'CPU', mem: 'Memory', disk: 'Disk' };
  V.map = {
    title: 'Resource map',
    crumb: () => 'Every resource, grouped and colored by health or load',
    render(el, route) {
      const q = route.q;
      const st = { cat: q.cat || 'all', group: q.group || '', by: q.by || 'group', color: q.color || 'status', dense: q.dense === '1', status: q.status || '', f: q.f || '' };
      const all = MC.model.resources.filter((r) => !r.linked);
      const cats = MC.summary.categories.filter((c) => c.total);
      el.innerHTML = `<div class="map-layout">
        <nav class="card tree" aria-label="Categories"></nav>
        <div class="grid" style="gap:12px">
          <div class="toolbar">
            <input class="input" id="mapF" type="search" placeholder="Filter by name, IP, OS, model" value="${esc(st.f)}" style="min-width:220px" aria-label="Filter resources">
            <div class="seg" id="segBy" aria-label="Group by">${[['group', 'Role'], ['site', 'Site'], ['status', 'Status']].map(([k, t]) => `<button data-v="${k}" class="${st.by === k ? 'on' : ''}">${t}</button>`).join('')}</div>
            <div class="seg" id="segColor" aria-label="Color by">${Object.entries(COLOR_BY).map(([k, t]) => `<button data-v="${k}" class="${st.color === k ? 'on' : ''}">${t}</button>`).join('')}</div>
            <div class="seg" id="segStatus">${[['', 'All'], ['bad', 'Issues only']].map(([k, t]) => `<button data-v="${k}" class="${st.status === k ? 'on' : ''}">${t}</button>`).join('')}</div>
            <div class="seg" id="segDense">${[['0', 'Cards'], ['1', 'Dense']].map(([k, t]) => `<button data-v="${k}" class="${(st.dense ? '1' : '0') === k ? 'on' : ''}">${t}</button>`).join('')}</div>
          </div>
          <div id="mapKey"></div>
          <div class="map-groups" id="groups"></div>
        </div></div>`;
      const tree = $('.tree', el);
      const dot = (list) => `<span class="dot" style="background:var(${C.STATUS[M.worst(...list.map((r) => r.status))] || '--muted'})"></span>`;
      tree.innerHTML = `<button data-cat="all" class="${st.cat === 'all' ? 'on' : ''}">${icon('map')}All resources<span class="c">${all.length}</span></button>` + cats.map((c) => {
        const list = all.filter((r) => r.category === c.id);
        const groups = [...new Set(list.map((r) => r.group))];
        return `<button data-cat="${c.id}" class="${st.cat === c.id && !st.group ? 'on' : ''}">${icon(MC.CAT_ICON[c.id])}${esc(c.name)}<span class="c">${list.length}</span></button>` +
          (st.cat === c.id ? groups.map((g) => { const gl = list.filter((r) => r.group === g); return `<button class="sub ${st.group === g ? 'on' : ''}" data-cat="${c.id}" data-group="${esc(g)}">${dot(gl)}${esc(g)}<span class="c">${gl.length}</span></button>`; }).join('') : '');
      }).join('');
      const nav = (patch) => MC.go('map', null, Object.assign({ cat: st.cat === 'all' ? '' : st.cat, group: st.group, by: st.by === 'group' ? '' : st.by, color: st.color === 'status' ? '' : st.color, dense: st.dense ? '1' : '', status: st.status, f: st.f }, patch));
      $$('button', tree).forEach((b) => b.addEventListener('click', () => nav({ cat: b.dataset.cat === 'all' ? '' : b.dataset.cat, group: b.dataset.group || '' })));
      const seg = (id, key, conv) => $$('#' + id + ' button', el).forEach((b) => b.addEventListener('click', () => nav({ [key]: conv ? conv(b.dataset.v) : b.dataset.v })));
      seg('segBy', 'by', (v) => (v === 'group' ? '' : v)); seg('segColor', 'color', (v) => (v === 'status' ? '' : v)); seg('segStatus', 'status'); seg('segDense', 'dense', (v) => (v === '1' ? '1' : ''));

      const metricOf = (r) => (st.color === 'status' ? null : r.metrics ? r.metrics[st.color] : null);
      const tileColor = (r) => {
        if (st.color === 'status') return `var(${C.STATUS[r.status] || '--muted'})`;
        const v = metricOf(r);
        if (v == null) return 'var(--surface-3)';
        return `color-mix(in srgb, var(--seq-hi) ${Math.round(Math.min(100, Math.max(6, v)))}%, var(--seq-lo))`;
      };
      $('#mapKey').innerHTML = st.color === 'status'
        ? `<div class="mc-legend">${['OK', 'Warning', 'Critical', 'Offline', 'Unknown'].map((k) => `<span><i style="background:var(${C.STATUS[k]})"></i>${k === 'Unknown' ? 'Not monitored / off' : k}</span>`).join('')}</div>`
        : `<div class="mc-scale" style="justify-content:flex-start"><span>0%</span><i style="background:linear-gradient(90deg,var(--seq-lo),var(--seq-hi))"></i><span>100% ${esc(COLOR_BY[st.color])}</span><span style="margin-left:12px"><i style="display:inline-block;width:10px;height:10px;border-radius:3px;background:var(--surface-3);vertical-align:-1px"></i> no data</span></div>`;

      const draw = () => {
        const f = st.f.toLowerCase();
        let list = all.filter((r) => (st.cat === 'all' || r.category === st.cat) && (!st.group || r.group === st.group) && (!st.status || ['Warning', 'Critical', 'Offline'].includes(r.status)) &&
          (!f || [r.name, r.ip, r.os, r.model, r.group, r.site].some((x) => String(x || '').toLowerCase().includes(f))));
        const key = (r) => (st.by === 'site' ? r.site || 'No site' : st.by === 'status' ? r.status : (st.cat === 'all' ? (MC.summary.categories.find((c) => c.id === r.category) || {}).name + ' · ' : '') + r.group);
        const groups = {};
        list.forEach((r) => (groups[key(r)] = groups[key(r)] || []).push(r));
        const catIdx = (g) => M.CATEGORIES.findIndex((c) => c.id === groups[g][0].category);
        const order = Object.keys(groups).sort((a, b) => (st.by === 'status' ? (M.RANK[b] || 0) - (M.RANK[a] || 0) : st.by === 'group' ? catIdx(a) - catIdx(b) || groups[b].length - groups[a].length || a.localeCompare(b) : groups[b].length - groups[a].length || a.localeCompare(b)));
        $('#groups').innerHTML = order.map((g) => {
          const gl = groups[g].slice().sort((a, b) => (M.RANK[b.status] || 0) - (M.RANK[a.status] || 0) || a.name.localeCompare(b.name, undefined, { numeric: true }));
          const counts = gl.reduce((a, r) => ((a[r.status] = (a[r.status] || 0) + 1), a), {});
          const dense = st.dense || gl.length > 60;
          return `<section class="map-group"><h4>${esc(g)} <span class="muted">${gl.length}</span>${C.statusStack(counts, { thin: true })}</h4>
            <div class="tiles${dense ? ' dense' : ''}">${gl.map((r) => {
              const m = metricOf(r);
              const tip = `${r.name} · ${r.status}${r.ip ? ' · ' + r.ip : ''}${m != null ? ' · ' + COLOR_BY[st.color] + ' ' + fmt(m, 0) + '%' : ''}${r.issues[0] ? ' · ' + r.issues[0].text : ''}`;
              return dense ? `<button class="tile" style="--tc:${tileColor(r)}" data-res="${esc(r.id)}" title="${esc(tip)}" aria-label="${esc(tip)}"></button>`
                : `<button class="tile" style="--tc:${tileColor(r)}" data-res="${esc(r.id)}" title="${esc(tip)}"><b>${esc(r.name)}</b><small>${esc(r.issues[0] ? r.issues[0].text : r.ip || r.os || r.model || r.kind)}</small><span class="m">${r.metrics && r.metrics.cpu != null ? '<span>CPU ' + fmt(r.metrics.cpu, 0) + '%</span>' : ''}${r.metrics && r.metrics.mem != null ? '<span>Mem ' + fmt(r.metrics.mem, 0) + '%</span>' : ''}${r.metrics && r.metrics.disk != null && r.metrics.cpu == null ? '<span>Disk ' + fmt(r.metrics.disk, 0) + '%</span>' : ''}${r.kind === 'workstation' || r.kind === 'network' || r.kind === 'printer' ? '<span>' + esc(r.site || '') + '</span>' : ''}</span></button>`;
            }).join('')}</div></section>`;
        }).join('') || '<div class="card empty">Nothing matches these filters.</div>';
      };
      draw();
      let t;
      $('#mapF').addEventListener('input', (e) => { st.f = e.target.value; clearTimeout(t); t = setTimeout(draw, 120); });
    },
  };

  // ================================================================== RESOURCE DRAWER
  V._resource = function (id) {
    const r = MC.model.byId.get(id);
    if (!r) return;
    const kv = (rows) => `<dl class="kv">${rows.filter((x) => x[1] != null && x[1] !== '').map(([k, v]) => `<dt>${esc(k)}</dt><dd>${v}</dd>`).join('')}</dl>`;
    const sec = (title, body, act) => `<section class="card panel-c"><div class="panel-h"><h3>${esc(title)}</h3>${act ? `<div class="act">${act}</div>` : ''}</div>${body}</section>`;
    const act = (sid, label, params, cls) => (MC.script(sid) ? `<button class="btn sm ${cls || ''}" ${MC.runAttr(sid, params)}>${esc(label)}</button>` : '');
    const issues = r.issues.length ? `<div class="issue-list">${r.issues.map((i) => `<div>${sevIcon(i.sev)}<span>${esc(i.text)} <span class="muted" style="font-size:11.5px">· ${esc(i.source)}</span></span></div>`).join('')}</div>` : '<div class="muted">No issues in the latest collection.</div>';
    let body = '', actions = '';
    const cn = { ComputerName: r.name };
    if (r.kind === 'server') {
      const c = MC.data('servers.compute').find((x) => x.Name === r.name) || {};
      const svc = MC.data('servers.services').filter((s) => s.ComputerName === r.name);
      const sw = MC.data('inventory.software').filter((s) => s.ComputerName === r.name);
      const admins = MC.data('security.localadmins').filter((s) => s.ComputerName === r.name);
      const fw = MC.data('security.firewall').find((s) => s.ComputerName === r.name);
      actions = [act('inv.systeminfo', 'System info', cn), act('mon.processes', 'Top processes', Object.assign({ SortBy: 'CPU', Top: 15 }, cn)), act('mon.sessions', 'Sessions', cn), act('mon.network.tcp', 'TCP connections', cn), act('mon.largefiles', 'Large files', Object.assign({ MinSizeMB: 1024 }, cn)), act('act.service', 'Service…', cn), act('act.windowsupdate', 'Windows Update…', Object.assign({ Mode: 'Scan' }, cn)), act('act.rdp', 'RDP…', cn), act('act.power', 'Restart…', Object.assign({ Operation: 'Restart' }, cn), 'danger'), act('act.isolate', 'Isolate…', Object.assign({ Mode: 'Isolate' }, cn), 'danger')].join('');
      body += `<div class="grid g3" style="gap:10px;justify-items:center">${C.gauge(c.CPU, { label: 'CPU' })}${C.gauge(c.Memory, { label: 'Memory', warn: 80, crit: 92 })}${C.gauge(r.metrics.disk, { label: 'Fullest disk', warn: 80, crit: 90 })}</div>`;
      body += sec('Last 24 hours', '<div id="drawerChart"></div>', '<div class="seg" id="dMetric"><button class="on" data-m="cpu">CPU & memory</button><button data-m="iops">Disk IOPS</button><button data-m="net">Network</button></div>');
      body += sec('Issues', issues);
      if (r.disks) body += sec('Volumes', C.barList(r.disks.map((d) => ({ label: d.Volume + ' ' + (d.Label || ''), sub: fmt(d.FreeGB, 0) + ' of ' + fmt(d.SizeGB, 0) + ' GB free', value: d.UsedPct, text: fmt(d.UsedPct, 0) + '%', status: d.Status !== 'OK' ? d.Status : null, color: '--s1' })), { max: 100 }));
      body += sec('Now', kv([['Top process', esc(c.TopProcess)], ['Processor queue', fmt(c.CPUQueue)], ['Memory', c.MemoryTotalGB ? fmt(c.MemoryTotalGB - c.MemoryFreeGB, 0) + ' of ' + fmt(c.MemoryTotalGB, 0) + ' GB' : null], ['Disk', c.DiskReadIOPS != null ? fmt(c.DiskReadIOPS + c.DiskWriteIOPS, 0) + ' IOPS · ' + fmt(c.DiskLatencyMs) + ' ms latency · queue ' + fmt(c.DiskQueue) : null], ['Network', c.NetKBps != null ? fmt(c.NetKBps / 1024) + ' MB/s' : null], ['Uptime', r.uptimeDays != null ? fmt(r.uptimeDays) + ' days' : null], ['Ping', r.metrics.latencyMs != null ? fmt(r.metrics.latencyMs) + ' ms' : null]]));
      if (r.dc) body += sec('Domain controller', kv([['Site', esc(r.dc.Site)], ['FSMO roles', esc((r.dc.FSMO || []).join(', ') || 'none')], ['Global catalog', r.dc.GlobalCatalog ? 'Yes' : 'No'], ['Time offset', fmt(r.dc.TimeOffsetSec, 3) + ' s']]) + `<div class="svc-dots" style="margin-top:8px">${Object.entries(r.dc.Services || {}).map(([k, v]) => `<span class="${v === 'Running' ? '' : 'bad'}">${esc(k)}</span>`).join('')}</div>`);
      body += sec('Hardware and OS', kv([['Operating system', esc(r.os)], ['Machine', esc([r.manufacturer, r.model].filter(Boolean).join(' ')) + (r.machineType ? ' · ' + esc(r.machineType) : '')], ['Serial', esc(r.serial)], ['CPU / RAM', r.cores ? r.cores + ' cores · ' + r.ramGB + ' GB' : null], ['Roles', esc((r.roles || []).join(', '))], ['Site', esc(r.site)], ['IP address', `<span class="mono">${esc(r.ip)}</span>`], ['Virtual machine', r.vm && r.vm.platform ? `<a href="#" data-res="${esc(r.vm.id)}">${esc(r.vm.platform)} on ${esc(r.vm.host)}</a>` : null]]));
      body += sec('Security', kv([['Defender', r.defender ? pill(r.defender.Status, r.defender.Status) + ' signatures ' + r.defender.SignatureAgeDays + ' d old' : null], ['Patching', r.patch ? pill(r.patch.Status, r.patch.DaysSincePatch + ' days since ' + r.patch.LastKB) + (r.patch.PendingReboot ? ' · reboot pending' : '') : null], ['Firewall', fw ? (fw.Domain && fw.Private && fw.Public ? 'All profiles on' : 'Some profiles off') + ' · RDP ' + (fw.RDPEnabled ? (fw.NLA ? 'with NLA' : 'without NLA') : 'off') + (fw.SMB1 ? ' · SMBv1 on' : '') : null], ['Local admins', admins.length ? esc(admins.map((a) => a.Member).join(', ')) : null]]));
      if (svc.length) body += sec('Watched services', `<div class="svc-dots">${svc.map((s) => `<span class="${s.Problem ? 'bad' : ''}" title="${esc(s.DisplayName)} · ${esc(s.State)}">${esc(s.Name)}</span>`).join('')}</div>`);
      if (sw.length) body += sec('Installed software', `<div class="muted" style="font-size:12.5px">${sw.length} packages · ${sw.slice(0, 12).map((s) => esc(s.Name)).join(', ')}${sw.length > 12 ? '…' : ''}</div>`, `<button class="btn sm ghost" data-href="#/inventory/software?q=${encodeURIComponent(r.name)}">All</button>`);
    } else if (r.kind === 'vm') {
      const v = r.vm || {};
      actions = r.platform === 'Hyper-V' ? ['Start', 'Stop', 'Restart', 'Checkpoint'].map((o) => act('act.hyperv.vm', o, { ComputerName: v.Host, VMName: v.Name, Operation: o })).join('') : '';
      body += sec('Issues', issues);
      body += sec('Virtual machine', kv([['Platform', esc(r.platform)], ['Host', `<a href="#" data-host="${esc(r.host)}">${esc(r.host)}</a>`], ['State', esc(v.State || v.Power)], ['vCPU / memory', (v.vCPU || '–') + ' vCPU · ' + fmt(v.MemoryAssignedGB || v.MemoryGB, 0) + ' GB' + (v.DynamicMemory ? ' (dynamic)' : '')], ['CPU usage', v.CPUUsage != null ? v.CPUUsage + '%' : null], ['Disks', v.Disks ? esc(v.Disks.map((d) => d.Path.split('\\').pop() + ' ' + d.FileGB + '/' + d.SizeGB + ' GB').join(', ')) : v.ProvisionedGB ? fmt(v.UsedSpaceGB, 0) + ' of ' + fmt(v.ProvisionedGB, 0) + ' GB' : null], ['Checkpoints', v.Checkpoints != null ? v.Checkpoints + (v.OldestCheckpointDays ? ', oldest ' + v.OldestCheckpointDays + ' d' : '') : v.OldestSnapshotDays ? 'oldest ' + v.OldestSnapshotDays + ' d' : null], ['Guest', esc(v.GuestOS || '')], ['Tools / heartbeat', esc(v.ToolsStatus || v.Heartbeat || '')], ['IP', `<span class="mono">${esc(r.ip || '')}</span>`], ['Network', esc(v.Switch || '')], ['Windows server', r.linked ? `<a href="#" data-res="${esc(r.linked)}">Open ${esc(r.name)}</a>` : null]]));
    } else if (r.kind === 'linux') {
      const l = r.linux;
      body += `<div class="grid g3" style="gap:10px;justify-items:center">${C.gauge(l.cpuPct, { label: 'CPU' })}${C.gauge(l.memUsedPct, { label: 'Memory', warn: 80, crit: 92 })}${C.gauge(l.WorstDiskPct, { label: 'Fullest mount', warn: 80, crit: 90 })}</div>`;
      body += sec('Issues', issues);
      body += sec('Filesystems', C.barList((l.disks || []).map((d) => ({ label: d.mount, sub: d.fs + ' · ' + d.sizeGB + ' GB', value: d.usedPct, text: d.usedPct + '%', status: d.usedPct >= 90 ? 'Critical' : d.usedPct >= 80 ? 'Warning' : null, color: '--s1' })), { max: 100 }));
      body += sec('Top processes', `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>PID</th><th>User</th><th>Command</th><th style="text-align:right">CPU %</th><th style="text-align:right">Mem %</th></tr></thead><tbody>${(l.topProcesses || []).map((p) => `<tr><td class="mono">${p.pid}</td><td>${esc(p.user)}</td><td class="mono">${esc(p.cmd)}</td><td class="n">${fmt(p.cpu)}</td><td class="n">${fmt(p.mem)}</td></tr>`).join('')}</tbody></table></div>`);
      body += sec('System', kv([['OS / kernel', esc(l.os + ' · ' + l.kernel)], ['Hardware', esc([l.vendor, l.model, l.machineType].filter(Boolean).join(' · '))], ['CPU', esc(l.cpuCount + ' × ' + l.cpuModel)], ['Load (1/5/15)', (l.load || []).join(' / ')], ['Memory', l.memTotalGB + ' GB · swap ' + l.swapUsedPct + '% of ' + l.swapTotalGB + ' GB'], ['Uptime', fmt(l.uptimeHours / 24) + ' days'], ['Packages', l.packages + ' (' + l.packageManager + ') · ' + l.updates + ' updates, ' + l.securityUpdates + ' security'], ['Failed units', l.failedUnits], ['Oracle instances', (l.oracleInstances || []).join(', ') || null], ['Logged on', (l.loggedOnUsers || []).join(', ') || null], ['IP', `<span class="mono">${esc((l.ipAddresses || []).join(', '))}</span>`]]));
      actions = act('lnx.collect', 'Collect now', { ComputerName: r.name });
    } else if (r.kind === 'sql') {
      body += sec('Issues', issues);
      body += sec('Databases', `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Database</th><th>Recovery</th><th style="text-align:right">Size GB</th><th>Full backup</th><th>Log backup</th><th>Health</th></tr></thead><tbody>${r.databases.map((d) => `<tr><td>${esc(d.Database)}</td><td>${esc(d.RecoveryModel)}</td><td class="n">${fmt(d.SizeMB / 1024)}</td><td>${d.FullBackupAgeHours != null ? fmt(d.FullBackupAgeHours, 0) + ' h ago' : '<span style="color:var(--crit-ink)">never</span>'}</td><td>${d.RecoveryModel === 'Full' ? (d.LogBackupAgeHours != null ? fmt(d.LogBackupAgeHours, 0) + ' h ago' : '<span style="color:var(--crit-ink)">never</span>') : '–'}</td><td>${pill(d.Health)}</td></tr>`).join('')}</tbody></table></div>`);
      actions = act('act.service', 'Restart SQL service…', { ComputerName: r.name, ServiceName: 'MSSQLSERVER', Operation: 'Restart' }) + `<button class="btn sm" data-host="${esc(r.name)}">Open server</button>`;
    } else if (r.kind === 'printer') {
      const p = r.printer, h = r.health || {};
      body += sec('Issues', issues);
      body += sec('Printer', kv([['Status', esc(p.Status)], ['Print server', `<a href="#" data-host="${esc(p.PrintServer)}">${esc(p.PrintServer)}</a>`], ['Share', esc(p.ShareName)], ['Model / driver', esc((p.Model || '') + ' · ' + p.Driver)], ['Port / IP', `<span class="mono">${esc(p.Port)}</span>`], ['Location', esc(p.Location)], ['Jobs', (h.Jobs || 0) + ' queued, ' + (h.StuckJobs || 0) + ' stuck'], ['Reachable', h.Reachable === false ? 'No' : 'Yes'], ['Published in AD', p.Published ? 'Yes' : 'No']]));
      actions = act('act.service', 'Restart spooler…', { ComputerName: p.PrintServer, ServiceName: 'Spooler', Operation: 'Restart' });
    } else if (r.kind === 'network') {
      const d = r.net;
      body += sec('Issues', issues);
      body += sec('Device', kv([['Class', esc(d.DeviceClass)], ['Host name', esc(d.HostName || 'not in DNS')], ['IP', `<span class="mono">${esc(d.IPAddress)}</span>`], ['MAC', `<span class="mono">${esc(d.MAC || '')}</span>`], ['Open ports', esc((d.OpenPorts || []).join(', '))], ['Latency', fmt(d.LatencyMs) + ' ms'], ['TTL', d.Ttl], ['Subnet', esc(d.Subnet)], ['Site', esc(d.Site || '')]]));
      actions = act('act.nettest', 'Trace route', { Test: 'TraceRoute', Target: d.IPAddress }) + act('act.nettest', 'Port test', { Test: 'Port', Target: d.IPAddress, Port: (d.OpenPorts || [443])[0] }) + act('act.dns', 'DNS lookup', { Name: d.HostName || d.IPAddress });
    } else if (r.kind === 'workstation') {
      const w = r.ws;
      body += sec('Issues', issues);
      body += sec('Workstation', kv([['Operating system', esc(w.OperatingSystem)], ['Machine', esc(w.Manufacturer + ' ' + w.Model + ' · ' + w.MachineType)], ['CPU / RAM', w.CPUCores + ' cores · ' + w.RAMGB + ' GB'], ['TPM', w.TPMEnabled ? 'Enabled' : 'Not enabled'], ['Logged on', esc(w.LoggedOnUser || '')], ['Last seen', dt(w.LastSeen)], ['Uptime', fmt(w.UptimeDays) + ' days'], ['Site', esc(w.ADSite)], ['IP', `<span class="mono">${esc((w.IPAddress || []).join(', '))}</span>`]]));
      actions = act('inv.systeminfo', 'System info', cn) + act('mon.processes', 'Top processes', cn) + act('act.sessions', 'Message user…', Object.assign({ Operation: 'Message' }, cn)) + act('act.isolate', 'Isolate…', Object.assign({ Mode: 'Isolate' }, cn), 'danger');
    } else if (r.kind === 'esxi') {
      const e = r.esx;
      body += `<div class="grid g2" style="gap:10px;justify-items:center">${C.gauge(e.CPUUsedPct, { label: 'CPU' })}${C.gauge(e.MemoryUsedPct, { label: 'Memory', warn: 80, crit: 90 })}</div>`;
      body += sec('Last 7 days', '<div id="esxChart"></div>');
      body += sec('Issues', issues);
      body += sec('ESXi host', kv([['vCenter', esc(e.VCenter)], ['Cluster', esc(e.Cluster)], ['State', esc(e.State + ' · ' + e.Power)], ['Model', esc(e.Model)], ['Version', esc(e.Version)], ['CPU', e.CPUs + ' cores · ' + e.CPUGHz + ' GHz'], ['Memory', e.MemoryGB + ' GB'], ['VMs', e.VMs]]));
    } else if (r.kind === 'datastore') {
      const d = r.datastore;
      body += `<div style="display:flex;justify-content:center">${C.gauge(d.UsedPct, { label: 'Used', warn: 80, crit: 90 })}</div>` + sec('Issues', issues) + sec('Datastore', kv([['Type', esc(d.Type)], ['Capacity', fmt(d.CapacityGB, 0) + ' GB'], ['Free', fmt(d.FreeGB, 0) + ' GB'], ['State', esc(d.State)], ['vCenter', esc(d.VCenter)]]));
    } else if (r.kind === 'cluster') {
      const c = r.cluster;
      body += sec('Issues', issues);
      body += sec('Nodes', `<div class="svc-dots">${c.Nodes.map((n) => `<span class="${n.State === 'Up' ? '' : 'bad'}">${esc(n.Name)} · ${esc(n.State)}</span>`).join('')}</div>`);
      body += sec('Roles', `<div class="svc-dots">${c.Roles.map((n) => `<span class="${n.State === 'Online' ? '' : 'bad'}" title="${esc(n.Type)} on ${esc(n.Owner)}">${esc(n.Name)}</span>`).join('')}</div>`);
      if (r.storage) body += sec('Cluster storage', C.barList(r.storage.map((v) => ({ label: v.Name, sub: v.Type, value: v.UsedPct, text: fmt(v.UsedPct, 0) + '%', status: v.Status !== 'OK' ? v.Status : null, color: '--s1' })), { max: 100 }));
      body += sec('Cluster', kv([['Quorum', esc(c.QuorumType + ' · ' + c.QuorumResource)], ['Networks', esc(c.Networks.map((n) => n.Name + ' ' + n.State).join(', '))]]));
      actions = act('mon.clusters', 'Re-check cluster', {});
    }
    const meta = [...new Set([r.kind === 'vm' ? r.platform + ' VM' : r.kind, r.group, r.site, r.ip, r.os].filter(Boolean))].map((x) => `<span>${esc(x)}</span>`).join('');
    MC.openDrawer(`<header><div class="row1">${pill(r.status)}<h2>${esc(r.name)}</h2><button class="iconbtn" data-close style="margin-left:auto" aria-label="Close">${icon('x')}</button></div><div class="meta">${meta}</div>${actions ? `<div class="actions-row" style="margin-top:6px">${actions}</div>` : ''}</header><div class="body">${body}</div>`, (d) => {
      const hc = $('#drawerChart', d);
      if (hc) {
        const h = (MC.history || {})[r.name] || [];
        const draw = (m) => {
          if (m === 'cpu') C.timeSeries(hc, [{ name: 'CPU', points: h.map((p) => ({ t: p.t, v: p.cpu })), color: '--s1' }, { name: 'Memory', points: h.map((p) => ({ t: p.t, v: p.mem })), color: '--s4' }], { unit: '%', yMax: 100, threshold: 90, height: 180 });
          else C.timeSeries(hc, [{ name: m === 'iops' ? 'Disk IOPS' : 'Network KB/s', points: h.map((p) => ({ t: p.t, v: p[m] })), color: '--s2' }], { height: 180, legend: true });
        };
        draw('cpu');
        $$('#dMetric button', d).forEach((b) => b.addEventListener('click', () => { $$('#dMetric button', d).forEach((x) => x.classList.toggle('on', x === b)); draw(b.dataset.m); }));
      }
      const ec = $('#esxChart', d);
      if (ec) {
        const h = MC.data('virtualization.vmware').filter((x) => x.Kind === 'History' && x.Name === r.fqdn).sort((a, b) => Date.parse(a.Time) - Date.parse(b.Time));
        C.timeSeries(ec, [{ name: 'CPU', points: h.map((p) => ({ t: Date.parse(p.Time), v: p.CPU })), color: '--s1' }, { name: 'Memory', points: h.map((p) => ({ t: Date.parse(p.Time), v: p.Memory })), color: '--s4' }], { unit: '%', yMax: 100, height: 170 });
      }
    });
  };

  // ================================================================== MONITORING
  const MON_TABS = [['overview', 'Overview'], ['compute', 'Compute'], ['storage', 'Storage'], ['availability', 'Availability & uptime'], ['services', 'Services & IIS'], ['software', 'Installed software'], ['hardware', 'Hardware & system'], ['roles', 'Roles'], ['sqlsvc', 'SQL services']];
  V.monitoring = {
    title: 'Windows servers',
    crumb: () => 'Live collectors: compute every 5 min, availability every 2 min, storage and services every 15 min',
    render(el, route) {
      // SQL Server and printers moved to Active Directory (Databases, Print servers)
      if (route.tab === 'sql' || route.tab === 'printers') return location.replace('#/identity/' + (route.tab === 'sql' ? 'databases' : 'printers'));
      const tab = route.tab || 'overview';
      const badge = (list) => { const c = list.filter((x) => x === 'Critical').length, w = list.filter((x) => x === 'Warning').length; return c ? { s: 'Critical', n: c } : w ? { s: 'Warning', n: w } : null; };
      const tabs = MON_TABS.map(([id, t]) => [id, t, badge({
        compute: MC.data('servers.compute').map((x) => x.Status), storage: MC.data('servers.disks').map((x) => x.Status), availability: MC.data('servers.availability').map((x) => (x.Status === 'Offline' ? 'Critical' : 'OK')),
        services: MC.data('servers.services').map((x) => (x.Problem ? 'Warning' : 'OK')), sqlsvc: sqlSvcRows().map((x) => (x.State === 'Running' ? 'OK' : 'Warning')), dhcp: MC.data('network.dhcp').map((x) => x.Status), sql: MC.data('sql.databases').map((x) => x.Health), printers: MC.data('printers.health').map((x) => x.Health),
      }[id] || [])]);
      el.innerHTML = MC.tabs('monitoring', tabs, tab) + '<div id="tab" class="grid"></div>';
      (MON[tab] || MON.compute)($('#tab', el), route);
    },
  };
  const MON = {};
  // ---- Windows servers: one row per server from every collector, for servers found by engines and manually added
  const shortN = (n) => String(n || '').split('.')[0].toUpperCase();
  const sqlSvcRows = () => MC.data('inventory.hardware').flatMap((h) => (h.SqlServices || []).map((x) => { const [n, st] = String(x).split('='); return { ComputerName: h.Name, Service: n, State: st || 'Unknown', Kind: /AGENT/i.test(n) ? 'SQL Server Agent' : 'Database engine' }; }));
  function serverRowsAll(tree) {
    const by = new Map();
    const row = (n) => { const k = shortN(n); if (!by.has(k)) by.set(k, { Name: k }); return by.get(k); };
    for (const h of MC.data('inventory.hardware')) Object.assign(row(h.Name), { hw: h });
    for (const a of MC.data('servers.availability')) Object.assign(row(a.Name), { av: a });
    for (const c of MC.data('servers.compute')) Object.assign(row(c.Name), { cp: c });
    const sw = new Map(), svc = new Map(), iisP = new Map();
    for (const x of MC.data('inventory.software')) sw.set(shortN(x.ComputerName), (sw.get(shortN(x.ComputerName)) || 0) + 1);
    for (const x of MC.data('servers.services')) if (x.Problem) svc.set(shortN(x.ComputerName), (svc.get(shortN(x.ComputerName)) || 0) + 1);
    for (const x of MC.data('servers.iis')) { const k = shortN(x.ComputerName), v = iisP.get(k) || { pools: 0, stopped: 0 }; v.pools++; if (x.State !== 'Started') v.stopped++; iisP.set(k, v); }
    const devs = new Map();
    for (const d of (tree && tree.devices) || []) if (['server'].includes(d.kind) && !/linux/i.test(d.os || '')) devs.set(shortN(d.name), d);
    for (const [k, d] of devs) Object.assign(row(k), { dev: d });
    return [...by.values()].filter((r) => r.hw || r.av || r.cp || r.dev).filter((r) => !r.hw || !/Windows 1[01]/.test(r.hw.OperatingSystem || '')).map((r) => {
      const hw = r.hw || {}, av = r.av || {}, d = r.dev || null;
      const sql = (hw.SqlServices || []).map((x) => String(x).split('='));
      return Object.assign(r, {
        Source: d ? (d.origin === 'engine' ? 'engine' : 'added') : 'engine', Device: d ? d.id : null, State: d ? d.state : av.Status === 'Offline' ? 'Down' : 'Up',
        OS: (hw.OperatingSystem || (d && d.os) || '').replace('Microsoft Windows Server ', 'WS '), UptimeDays: av.UptimeDays != null ? av.UptimeDays : hw.UptimeDays, LastBoot: av.LastBoot || hw.LastBoot,
        LastUser: hw.LastLoggedOnUser || hw.LoggedOnUser || '', CPU: hw.CPUCores || null, RAMGB: hw.RAMGB, Model: (hw.Model || '').replace(/^Microsoft Corporation /, '').replace('Virtual Machine', 'Hyper-V VM'), Vendor: hw.Manufacturer || '',
        Roles: (hw.InstalledRoles && hw.InstalledRoles.length ? hw.InstalledRoles : hw.Roles || []).filter((x) => x !== 'File and Storage Services' && x !== 'General'),
        SQL: sql.length ? (sql.every(([, st]) => st === 'Running') ? 'Running' : 'Stopped') : '', IIS: hw.IISState || (iisP.get(r.Name) ? (iisP.get(r.Name).stopped ? 'Stopped' : 'Running') : ''),
        ServiceProblems: svc.get(r.Name) || 0, Software: sw.get(r.Name) || 0, NoInventory: !r.hw,
      });
    });
  }
  const invBtn = (r) => (r.Device ? `<button class="btn sm ghost" data-inv="${esc(r.Device)}">Collect inventory</button>` : '');
  const wireInv = (el, redraw) => $$('[data-inv]', el).forEach((b) => b.addEventListener('click', async () => {
    b.disabled = true;
    try { const r = await MC.api.inventoryCollect(b.dataset.inv); MC.toast('Collecting inventory: ' + r.jobs.map((j) => esc(j.label.toLowerCase())).join(', '), 'ok'); setTimeout(async () => { MC.ds = await MC.api.datasets(); if (document.body.contains(el)) redraw(); }, r.jobs.some((j) => j.job) ? 20000 : 400); }
    catch (e) { MC.toast(esc(e.message), 'err'); b.disabled = false; }
  }));
  MON.overview = (el) => {
    el.innerHTML = '<div class="notice">Loading servers…</div>';
    const draw = () => MC.api.monitor('tree').catch(() => null).then((tree) => {
      if (!document.body.contains(el)) return;
      const rows = serverRowsAll(tree);
      const eng = rows.filter((r) => r.Source === 'engine').length, man = rows.length - eng, up = rows.filter((r) => r.UptimeDays != null);
      const roleCount = countBy(rows.flatMap((r) => r.Roles.map((x) => ({ x }))), (o) => o.x).filter(([k]) => k !== 'General');
      el.innerHTML = `<div class="kpis">${MC.kpi('Windows servers', rows.length, eng + ' found by engines · ' + man + ' manually added')}${MC.kpi('Down', rows.filter((r) => r.State === 'Down').length, 'offline or failing', { alert: rows.some((r) => r.State === 'Down') })}${MC.kpi('Longest uptime', up.length ? fmt(Math.max(...up.map((r) => r.UptimeDays)), 0) + ' days' : '–', up.filter((r) => r.UptimeDays > 60).length + ' above 60 days (patching?)')}${MC.kpi('SQL services', rows.filter((r) => r.SQL).length, rows.filter((r) => r.SQL === 'Stopped').length + ' with a stopped service', { alert: rows.some((r) => r.SQL === 'Stopped') })}${MC.kpi('IIS', rows.filter((r) => r.IIS).length, rows.filter((r) => r.IIS === 'Stopped').length + ' stopped')}${MC.kpi('Without inventory', rows.filter((r) => r.NoInventory).length, 'collect it from the row')}</div>
        <div class="grid g-1-2">${MC.panel('Installed roles', 'servers per role', C.barList(roleCount.slice(0, 10).map(([k, n]) => ({ label: k, value: n, text: n, color: '--s1', href: '#/monitoring/roles' })), { compact: true }) || '<p class="muted">No roles collected yet.</p>')}${MC.panel('Uptime', 'days since the last restart · longest first', C.barList(up.slice().sort((a, b) => b.UptimeDays - a.UptimeDays).slice(0, 8).map((r) => ({ label: r.Name, sub: r.LastUser || '', value: r.UptimeDays, text: fmt(r.UptimeDays, 0) + ' d', status: r.UptimeDays > 60 ? 'Warning' : null, color: '--s2' })), { compact: true }))}</div>
        ${MC.panel('Servers', 'hardware and system information, last signed-in user, roles, SQL and IIS, services and installed software · open a server for everything', '<div id="ovT"></div>')}`;
      MC.table($('#ovT', el), rows, [
        { key: 'Name', label: 'Server', html: (r) => `<a href="#" data-host="${esc(r.Name)}"><b>${esc(r.Name)}</b></a>` },
        { key: 'Source', label: 'Source', html: (r) => `<span class="tag ${r.Source === 'engine' ? 'collector' : 'native'}">${r.Source === 'engine' ? 'engine' : 'added'}</span>` },
        { key: 'State', label: 'State', html: (r) => pill(r.State, r.State) },
        { key: 'OS', label: 'OS' },
        { key: 'UptimeDays', label: 'Uptime', n: true, html: (r) => (r.UptimeDays != null ? `<span title="Last boot ${esc(dt(r.LastBoot))}">${fmt(r.UptimeDays, 1)} d</span>` : '<span class="muted">–</span>') },
        { key: 'LastUser', label: 'Last signed-in user', html: (r) => (r.LastUser ? `<span class="mono">${esc(r.LastUser)}</span>` : '<span class="muted">–</span>') },
        { key: 'CPU', label: 'Cores', n: true }, { key: 'RAMGB', label: 'RAM GB', n: true }, { key: 'Model', label: 'Model', html: (r) => `<span title="${esc(r.Vendor)}" style="white-space:nowrap">${esc(r.Model)}</span>` },
        { key: 'Roles', label: 'Roles', val: (r) => r.Roles.join(', '), html: (r) => `<span title="${esc(r.Roles.join(', '))}">` + r.Roles.slice(0, 2).map((x) => `<span class="tag" style="white-space:nowrap">${esc(x.replace('Active Directory ', 'AD ').replace(' (application)', ''))}</span>`).join(' ') + (r.Roles.length > 2 ? ` <span class="muted">+${r.Roles.length - 2}</span>` : '') + '</span>' },
        { key: 'SQL', label: 'SQL', html: (r) => (r.SQL ? pill(r.SQL === 'Running' ? 'OK' : 'Warning', r.SQL) : '<span class="muted">–</span>') },
        { key: 'IIS', label: 'IIS', html: (r) => (r.IIS ? pill(r.IIS === 'Running' ? 'OK' : 'Warning', r.IIS) : '<span class="muted">–</span>') },
        { key: 'ServiceProblems', label: 'Stopped services', n: true, html: (r) => (r.ServiceProblems ? pill('Warning', r.ServiceProblems) : '0') },
        { key: 'Software', label: 'Software', n: true, html: (r) => (r.Software ? `<a href="#/monitoring/software?q=${encodeURIComponent(r.Name)}">${r.Software}</a>` : r.NoInventory ? invBtn(r) || '<span class="muted">–</span>' : '0') },
      ], { name: 'windows-overview', sort: 'State', limit: 25, after: (w) => wireInv(w, draw) });
    });
    draw();
  };
  MON.software = (el, route) => {
    const sw = MC.data('inventory.software');
    const prod = Object.values(sw.reduce((a, x) => { const k = x.Name; (a[k] = a[k] || { Name: k, Vendor: x.Vendor, Servers: new Set(), Versions: new Set() }); a[k].Servers.add(x.ComputerName); a[k].Versions.add(x.Version); return a; }, {})).map((x) => ({ Name: x.Name, Vendor: x.Vendor, Servers: x.Servers.size, Versions: x.Versions.size, VersionList: [...x.Versions].join(', ') }));
    el.innerHTML = `<div class="kpis">${MC.kpi('Installs', sw.length, 'on ' + new Set(sw.map((x) => x.ComputerName)).size + ' servers')}${MC.kpi('Products', prod.length, '')}${MC.kpi('Version drift', prod.filter((p) => p.Versions > 1).length, 'products with more than one version')}${MC.kpi('Vendors', new Set(sw.map((x) => x.Vendor)).size, '')}</div>
      ${MC.panel('Products', 'one row per product across the servers', '<div id="swP"></div>')}
      ${MC.panel('Installed software per server', 'from the registry (not Win32_Product, which can trigger repairs)', '<div id="swT"></div>', { act: `<button class="btn sm" ${MC.runAttr('inv.software', {})}>Collect now…</button>` })}`;
    MC.table($('#swP', el), prod, [{ key: 'Name', label: 'Product' }, { key: 'Vendor', label: 'Vendor' }, { key: 'Servers', label: 'Servers', n: true }, { key: 'Versions', label: 'Versions', n: true, html: (r) => (r.Versions > 1 ? `<span title="${esc(r.VersionList)}">${pill('Warning', r.Versions)}</span>` : '1') }], { name: 'win-software-products', sort: 'Servers', dir: -1, limit: 10 });
    MC.table($('#swT', el), sw, [{ key: 'ComputerName', label: 'Server', html: (r) => `<a href="#" data-host="${esc(r.ComputerName)}">${esc(r.ComputerName)}</a>` }, { key: 'Name', label: 'Product' }, { key: 'Version', label: 'Version', cls: 'mono' }, { key: 'Vendor', label: 'Vendor' }, { key: 'InstallDate', label: 'Installed' }, { key: 'Architecture', label: 'Arch' }], { name: 'win-software', q: (route.q || {}).q, limit: 25 });
  };
  MON.hardware = (el) => {
    const hw = MC.data('inventory.hardware').filter((h) => !/Windows 1[01]/.test(h.OperatingSystem || ''));
    const on = hw.filter((h) => h.Online !== false);
    el.innerHTML = `<div class="kpis">${MC.kpi('Servers', hw.length, on.filter((h) => h.MachineType === 'Physical').length + ' physical · ' + on.filter((h) => h.MachineType !== 'Physical').length + ' virtual')}${MC.kpi('CPU cores', fmt(sum(on.map((h) => h.CPUCores)), 0), fmt(sum(on.map((h) => h.CPULogical)), 0) + ' logical')}${MC.kpi('Memory', fmt(sum(on.map((h) => h.RAMGB)), 0) + ' GB', '')}${MC.kpi('TPM enabled', on.filter((h) => h.TPMEnabled).length, 'of ' + on.length)}</div>
      ${MC.panel('Hardware and system information', 'what systeminfo shows, for every server · run System information on a server for the full report', '<div id="hwT"></div>', { act: `<button class="btn sm" ${MC.runAttr('inv.hardware', {})}>Collect now…</button>` })}`;
    MC.table($('#hwT', el), hw, [
      { key: 'Name', label: 'Server', html: (r) => `<a href="#" data-host="${esc(r.Name)}">${esc(r.Name)}</a>` }, { key: 'OperatingSystem', label: 'OS' }, { key: 'OSBuild', label: 'Build', cls: 'mono' }, { key: 'InstallDate', label: 'Installed', html: (r) => esc(dt(r.InstallDate)) },
      { key: 'Manufacturer', label: 'Vendor' }, { key: 'Model', label: 'Model' }, { key: 'SerialNumber', label: 'Serial', cls: 'mono' }, { key: 'BIOSVersion', label: 'BIOS' },
      { key: 'CPUModel', label: 'Processor' }, { key: 'CPUCores', label: 'Cores', n: true }, { key: 'RAMGB', label: 'RAM GB', n: true }, { key: 'MachineType', label: 'Type' },
      { key: 'LastLoggedOnUser', label: 'Last signed-in user', val: (r) => r.LastLoggedOnUser || r.LoggedOnUser || '' }, { key: 'Domain', label: 'Domain' }, { key: 'ADSite', label: 'AD site' },
      { key: 'TPMEnabled', label: 'TPM', html: (r) => (r.TPMEnabled ? 'Enabled' : r.TPMPresent ? pill('Warning', 'Off') : '<span class="muted">none</span>') },
      { key: 'act', label: '', noCsv: true, html: (r) => `<button class="btn sm ghost" ${MC.runAttr('inv.systeminfo', { ComputerName: r.Name })}>System information</button>` },
    ], { name: 'win-hardware', limit: 25 });
  };
  MON.roles = (el) => {
    const hw = MC.data('inventory.hardware'), rl = MC.data('inventory.roles');
    const rows = hw.filter((h) => (h.InstalledRoles || h.Roles || []).length).map((h) => ({ ComputerName: h.Name, Roles: (h.InstalledRoles && h.InstalledRoles.length ? h.InstalledRoles : h.Roles || []), Features: ((rl.find((r) => shortN(r.ComputerName) === shortN(h.Name)) || {}).Features) || null }));
    const counts = countBy(rows.flatMap((r) => r.Roles.map((x) => ({ x }))), (o) => o.x);
    el.innerHTML = `<div class="kpis">${MC.kpi('Servers with roles', rows.length, '')}${MC.kpi('Distinct roles', counts.length, '')}</div>
      <div class="grid g-1-2">${MC.panel('Servers per role', '', C.barList(counts.map(([k, n]) => ({ label: k, value: n, text: n, color: '--s1' })), { compact: true }))}${MC.panel('Roles installed per server', 'Server Manager roles; features are counted', '<div id="rlT"></div>', { act: `<button class="btn sm" ${MC.runAttr('inv.server.roles', {})}>Collect now…</button>` })}</div>`;
    MC.table($('#rlT', el), rows, [{ key: 'ComputerName', label: 'Server', html: (r) => `<a href="#" data-host="${esc(r.ComputerName)}">${esc(r.ComputerName)}</a>` }, { key: 'Roles', label: 'Roles', val: (r) => r.Roles.join(', '), html: (r) => r.Roles.map((x) => `<span class="tag">${esc(x)}</span>`).join(' ') }, { key: 'Features', label: 'Features', n: true }], { name: 'win-roles', limit: 25 });
  };
  MON.sqlsvc = (el) => {
    const rows = sqlSvcRows();
    el.innerHTML = `<div class="kpis">${MC.kpi('SQL Server hosts', new Set(rows.map((r) => r.ComputerName)).size, '')}${MC.kpi('Services', rows.length, rows.filter((r) => r.State !== 'Running').length + ' not running', { alert: rows.some((r) => r.State !== 'Running') })}</div>
      ${MC.panel('SQL Server services', 'database engine and agent per instance · databases, backups and jobs are under Active Directory › Databases', '<div id="sqT"></div>', { act: '<a class="btn sm ghost" href="#/identity/databases">Databases</a>' })}`;
    MC.table($('#sqT', el), rows, [{ key: 'ComputerName', label: 'Server', html: (r) => `<a href="#" data-host="${esc(r.ComputerName)}">${esc(r.ComputerName)}</a>` }, { key: 'Service', label: 'Service', cls: 'mono' }, { key: 'Kind', label: 'Kind' }, { key: 'State', label: 'State', html: (r) => pill(r.State === 'Running' ? 'OK' : 'Warning', r.State) },
      { key: 'act', label: '', noCsv: true, html: (r) => (r.State !== 'Running' ? `<button class="btn sm" ${MC.runAttr('act.service', { ComputerName: r.ComputerName, ServiceName: r.Service, Operation: 'Start' })}>Start…</button>` : '') }], { name: 'win-sql-services', sort: 'State', empty: 'No SQL Server services found. The hardware collector reads them on every server.' });
  };
  MON.compute = (el) => {
    const comp = MC.data('servers.compute');
    const on = comp.filter((c) => c.Online !== false);
    el.innerHTML = `
      <div class="kpis">${MC.kpi('Servers reporting', on.length + ' / ' + comp.length, 'collected ' + ago((MC.ds['servers.compute'] || {}).finished))}${MC.kpi('Average CPU', fmt(avg(on.map((c) => c.CPU)), 0) + '%', on.filter((c) => c.CPU >= 75).length + ' above 75%')}${MC.kpi('Average memory', fmt(avg(on.map((c) => c.Memory)), 0) + '%', on.filter((c) => c.Memory >= 80).length + ' above 80%')}${MC.kpi('Disk latency (worst)', fmt(Math.max(...on.map((c) => c.DiskLatencyMs || 0))) + ' ms', 'avg ' + fmt(avg(on.map((c) => c.DiskLatencyMs || 0))) + ' ms')}${MC.kpi('Total disk IOPS', fmt(sum(on.map((c) => c.DiskReadIOPS + c.DiskWriteIOPS)), 0), 'read + write')}</div>
      ${MC.panel('Load heatmap, last 24 hours', 'hourly average per server · click a name for details', '<div id="heat"></div>', { act: '<div class="seg" id="heatM"><button class="on" data-m="cpu">CPU</button><button data-m="mem">Memory</button></div>' })}
      ${MC.panel('Current load', 'latest sample per server', '<div id="ctbl"></div>')}`;
    const drawHeat = (m) => {
      const h = MC.history || {};
      const names = Object.keys(h).filter((n) => h[n] && h[n].length).sort((a, b) => avg(h[b].map((p) => p[m])) - avg(h[a].map((p) => p[m])));
      if (!names.length) { $('#heat').innerHTML = '<div class="empty">History builds up after the first collections.</div>'; return; }
      const first = h[names[0]];
      const per = Math.max(1, Math.round(first.length / 24));
      const cols = [];
      for (let i = 0; i < first.length; i += per) cols.push(new Date(first[i].t).getHours() + ':00');
      const rows = names.map((n) => { const v = []; for (let i = 0; i < h[n].length; i += per) v.push(avg(h[n].slice(i, i + per).map((p) => p[m]))); return { label: n, values: v }; });
      C.heatmap($('#heat'), rows, cols, { metric: m === 'cpu' ? 'CPU' : 'Memory', unit: '%', max: 100, rowHeight: 15, onRow: (r) => MC.openHost(r.label) });
    };
    drawHeat('cpu');
    $$('#heatM button', el).forEach((b) => b.addEventListener('click', () => { $$('#heatM button', el).forEach((x) => x.classList.toggle('on', x === b)); drawHeat(b.dataset.m); }));
    MC.table($('#ctbl'), comp, [
      { key: 'Name', label: 'Server', html: (r) => `<a href="#" data-host="${esc(r.Name)}">${esc(r.Name)}</a>` },
      { key: 'Status', label: 'Status', html: (r) => pill(r.Online === false ? 'Offline' : r.Status) },
      { key: 'CPU', label: 'CPU', n: true, html: (r) => minibar(r.CPU) },
      { key: 'Memory', label: 'Memory', n: true, html: (r) => minibar(r.Memory, 80, 92) },
      { key: 'CPUQueue', label: 'CPU queue', n: true, html: (r) => fmt(r.CPUQueue) },
      { key: 'IOPS', label: 'Disk IOPS', n: true, val: (r) => (r.DiskReadIOPS || 0) + (r.DiskWriteIOPS || 0), html: (r) => fmt((r.DiskReadIOPS || 0) + (r.DiskWriteIOPS || 0), 0) },
      { key: 'DiskLatencyMs', label: 'Latency ms', n: true, html: (r) => `<span style="${r.DiskLatencyMs >= 20 ? 'color:var(--crit-ink);font-weight:600' : ''}">${fmt(r.DiskLatencyMs)}</span>` },
      { key: 'NetKBps', label: 'Net MB/s', n: true, html: (r) => fmt((r.NetKBps || 0) / 1024) },
      { key: 'TopProcess', label: 'Top process' },
      { key: 'UptimeHours', label: 'Uptime d', n: true, html: (r) => fmt((r.UptimeHours || 0) / 24) },
      { key: 'act', label: '', noCsv: true, html: (r) => `<button class="btn sm ghost" ${MC.runAttr('mon.processes', { ComputerName: r.Name, SortBy: 'CPU', Top: 15 })}>Processes</button>` },
    ], { sort: 'CPU', name: 'compute' });
  };
  MON.storage = (el) => {
    const disks = MC.data('servers.disks');
    const csv = MC.data('virtualization.clusterstorage');
    const dsx = MC.data('virtualization.vmware').filter((d) => d.Kind === 'Datastore');
    const tot = sum(disks.map((d) => d.SizeGB)), free = sum(disks.map((d) => d.FreeGB));
    el.innerHTML = `
      <div class="kpis">${MC.kpi('Volumes', disks.length, 'on ' + new Set(disks.map((d) => d.ComputerName)).size + ' servers')}${MC.kpi('Capacity', fmt(tot / 1024) + ' TB', fmt(free / 1024) + ' TB free')}${MC.kpi('Over 80%', disks.filter((d) => d.UsedPct >= 80).length, disks.filter((d) => d.UsedPct >= 90).length + ' over 90%', { alert: disks.some((d) => d.UsedPct >= 90) })}${MC.kpi('Cluster volumes', csv.length, csv.filter((c) => c.Status !== 'OK').length + ' need attention')}${MC.kpi('Datastores', dsx.length, dsx.filter((c) => c.Status !== 'OK').length + ' need attention')}</div>
      <div class="grid g-2-1">
        ${MC.panel('Fullest volumes', 'servers', C.barList(disks.slice().sort((a, b) => b.UsedPct - a.UsedPct).slice(0, 14).map((d) => ({ label: d.ComputerName + ' ' + d.Volume, sub: d.Label, value: d.UsedPct, text: fmt(d.UsedPct, 0) + '%', status: d.Status !== 'OK' ? d.Status : null, color: '--s1', href: '' })), { max: 100 }))}
        <div class="grid">${MC.panel('Cluster shared volumes', '', C.barList(csv.map((d) => ({ label: d.Cluster + ' · ' + d.Name, sub: fmt(d.FreeGB, 0) + ' GB free', value: d.UsedPct, text: fmt(d.UsedPct, 0) + '%', status: d.Status !== 'OK' ? d.Status : null, color: '--s1' })), { max: 100, compact: true }))}
        ${MC.panel('VMware datastores', '', C.barList(dsx.map((d) => ({ label: d.Name, sub: fmt(d.FreeGB, 0) + ' GB free', value: d.UsedPct, text: fmt(d.UsedPct, 0) + '%', status: d.Status !== 'OK' ? d.Status : null, color: '--s1' })), { max: 100, compact: true }))}</div>
      </div>
      ${MC.panel('SAN, NAS and backup storage', 'storage devices engine (SNMP) · ' + new Set(MC.data('storage.devices').map((d) => d.Name)).size + ' devices', '<div id="sdtbl"></div>', { act: `<a class="btn sm ghost" href="#/engines/mon.storage.devices">Engine</a><button class="btn sm" ${MC.runAttr('mon.storage.devices', {})}>Collect now…</button>` })}
      ${MC.panel('All volumes', '', '<div id="dtbl"></div>')}`;
    MC.table($('#sdtbl'), MC.data('storage.devices'), [
      { key: 'Name', label: 'Device', html: (r) => `<a href="#" data-host="${esc(r.Name)}">${esc(r.SysName || r.Name)}</a><br><span class="muted mono" style="font-size:11.5px">${esc(r.Name)}</span>` },
      { key: 'Description', label: 'Model', html: (r) => `<span style="font-size:12.5px">${esc(String(r.Description || '').slice(0, 70))}</span>` },
      { key: 'Volume', label: 'Volume or pool' },
      { key: 'UsedPct', label: 'Used', n: true, html: (r) => (r.UsedPct == null ? '–' : minibar(r.UsedPct, 85, 95)) },
      { key: 'SizeGB', label: 'Size GB', n: true, html: (r) => (r.SizeGB == null ? '–' : fmt(r.SizeGB, 0)) },
      { key: 'UptimeDays', label: 'Up days', n: true, html: (r) => (r.UptimeDays == null ? '–' : fmt(r.UptimeDays, 0)) },
      { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }, { key: 'Message', label: 'Detail', html: (r) => `<span style="font-size:12.5px">${esc(r.Message || '')}</span>` },
    ], { sort: 'UsedPct', name: 'storage-devices', empty: 'No SAN or NAS read yet. Add storage devices with an SNMP credential; the storage devices engine reads them every 15 minutes.' });
    MC.table($('#dtbl'), disks, [
      { key: 'ComputerName', label: 'Server', html: (r) => `<a href="#" data-host="${esc(r.ComputerName)}">${esc(r.ComputerName)}</a>` },
      { key: 'Volume', label: 'Volume' }, { key: 'Label', label: 'Label' },
      { key: 'UsedPct', label: 'Used', n: true, html: (r) => minibar(r.UsedPct, 80, 90) },
      { key: 'FreeGB', label: 'Free GB', n: true, html: (r) => fmt(r.FreeGB, 0) }, { key: 'SizeGB', label: 'Size GB', n: true, html: (r) => fmt(r.SizeGB, 0) },
      { key: 'Status', label: 'Status', html: (r) => pill(r.Status) },
      { key: 'act', label: '', noCsv: true, html: (r) => `<button class="btn sm ghost" ${MC.runAttr('mon.largefiles', { ComputerName: r.ComputerName, Path: r.Volume + '\\', MinSizeMB: 1024 })}>Large files</button>` },
    ], { sort: 'UsedPct', name: 'volumes' });
  };
  MON.availability = (el) => {
    const a = MC.data('servers.availability');
    const on = a.filter((x) => x.Status !== 'Offline');
    const chk = (v) => (v ? `<span style="color:var(--ok-ink)">✓</span>` : `<span style="color:var(--crit-ink)">✕</span>`);
    el.innerHTML = `
      <div class="kpis">${MC.kpi('Online', on.length + ' / ' + a.length, pct(on.length, a.length) + '% available', { alert: on.length < a.length })}${MC.kpi('Median ping', fmt(on.map((x) => x.LatencyMs).sort((x, y) => x - y)[Math.floor(on.length / 2)]) + ' ms', 'max ' + fmt(Math.max(...on.map((x) => x.LatencyMs))) + ' ms')}${MC.kpi('WinRM reachable', a.filter((x) => x.Port5985).length, 'port 5985')}${MC.kpi('Rebooted in 7 days', a.filter((x) => x.UptimeDays < 7).length, a.filter((x) => x.UptimeDays > 60).length + ' up more than 60 days')}</div>
      <div class="grid g2">
        ${MC.panel('Response time', 'ICMP round trip, slowest first', C.barList(on.slice().sort((x, y) => y.LatencyMs - x.LatencyMs).slice(0, 12).map((x) => ({ label: x.Name, sub: x.Address, value: x.LatencyMs, text: fmt(x.LatencyMs) + ' ms', color: '--s1' })), {}))}
        ${MC.panel('Uptime', 'days since last boot, longest first', C.barList(on.slice().sort((x, y) => y.UptimeDays - x.UptimeDays).slice(0, 12).map((x) => ({ label: x.Name, sub: dt(x.LastBoot), value: x.UptimeDays, text: fmt(x.UptimeDays, 0) + ' d', status: x.UptimeDays > 60 ? 'Warning' : null, color: '--s2' })), {}))}
      </div>
      ${MC.panel('Reachability', 'ping and management ports', '<div id="atbl"></div>')}`;
    MC.table($('#atbl'), a, [
      { key: 'Name', label: 'Server', html: (r) => `<a href="#" data-host="${esc(r.Name)}">${esc(r.Name)}</a>` },
      { key: 'Status', label: 'Status', html: (r) => pill(r.Status === 'Online' ? 'OK' : 'Offline', r.Status) },
      { key: 'Address', label: 'Address', html: (r) => `<span class="mono">${esc(r.Address)}</span>` },
      { key: 'LatencyMs', label: 'Ping ms', n: true, html: (r) => fmt(r.LatencyMs) },
      { key: 'Port5985', label: 'WinRM', html: (r) => chk(r.Port5985) }, { key: 'Port3389', label: 'RDP', html: (r) => chk(r.Port3389) }, { key: 'Port445', label: 'SMB', html: (r) => chk(r.Port445) },
      { key: 'UptimeDays', label: 'Uptime d', n: true, html: (r) => fmt(r.UptimeDays) },
      { key: 'LastBoot', label: 'Last boot', html: (r) => dt(r.LastBoot) },
    ], { sort: 'Status', dir: 1, name: 'availability' });
  };
  MON.services = (el) => {
    const s = MC.data('servers.services'), iis = MC.data('servers.iis'), actv = MC.data('servers.activation');
    const bad = s.filter((x) => x.Problem);
    el.innerHTML = `
      <div class="kpis">${MC.kpi('Watched services', s.length, 'on ' + new Set(s.map((x) => x.ComputerName)).size + ' servers')}${MC.kpi('Stopped (automatic)', bad.length, bad.length ? 'need a start' : 'all running', { alert: bad.length > 0 })}${MC.kpi('IIS app pools', iis.length, iis.filter((p) => p.State !== 'Started').length + ' stopped')}${MC.kpi('Windows activation', actv.filter((a) => a.Status === 'Licensed').length + ' / ' + actv.length, 'licensed')}</div>
      ${MC.panel('Stopped automatic services', 'these should be running', '<div id="stbl"></div>')}
      <div class="grid g2">${MC.panel('IIS application pools', '', '<div id="itbl"></div>')}${MC.panel('Windows activation', '', '<div id="actbl"></div>')}</div>`;
    MC.table($('#stbl'), bad, [
      { key: 'ComputerName', label: 'Server', html: (r) => `<a href="#" data-host="${esc(r.ComputerName)}">${esc(r.ComputerName)}</a>` },
      { key: 'DisplayName', label: 'Service' }, { key: 'Name', label: 'Name', html: (r) => `<span class="mono">${esc(r.Name)}</span>` }, { key: 'State', label: 'State', html: (r) => pill('Warning', r.State) }, { key: 'Account', label: 'Runs as' },
      { key: 'act', label: '', noCsv: true, html: (r) => `<button class="btn sm" ${MC.runAttr('act.service', { ComputerName: r.ComputerName, ServiceName: r.Name, Operation: 'Start' })}>Start</button>` },
    ], { search: false, empty: 'All automatic services are running.' });
    MC.table($('#itbl'), iis, [{ key: 'ComputerName', label: 'Server' }, { key: 'Pool', label: 'Pool' }, { key: 'State', label: 'State', html: (r) => pill(r.State === 'Started' ? 'OK' : 'Warning', r.State) }, { key: 'Runtime', label: 'CLR' }, { key: 'Sites', label: 'Sites' }], { search: false, limit: 20 });
    MC.table($('#actbl'), actv, [{ key: 'ComputerName', label: 'Server' }, { key: 'Channel', label: 'Channel' }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status === 'Licensed' ? 'OK' : 'Warning', r.Status) }], { search: false, limit: 12, sort: 'Status', dir: -1 });
  };
  MON.dhcp = (el) => {
    const sc = MC.data('network.dhcp');
    el.innerHTML = `
      <div class="kpis">${MC.kpi('Scopes', sc.length, 'on ' + new Set(sc.map((x) => x.Server)).size + ' servers')}${MC.kpi('Leases in use', fmt(sum(sc.map((x) => x.InUse)), 0), fmt(sum(sc.map((x) => x.Free)), 0) + ' free')}${MC.kpi('Scopes over 85%', sc.filter((x) => x.PercentInUse >= 85).length, '', { alert: sc.some((x) => x.Status === 'Critical') })}${MC.kpi('Failover', sc.filter((x) => x.Failover).length + ' / ' + sc.length, 'scopes protected')}</div>
      ${MC.panel('Scope utilization', 'all DHCP servers (fixed: the legacy script only read the last server)', C.barList(sc.slice().sort((a, b) => b.PercentInUse - a.PercentInUse).map((x) => ({ label: x.Name, sub: x.ScopeId + ' · ' + x.Server, value: x.PercentInUse, text: fmt(x.PercentInUse, 0) + '%', status: x.Status !== 'OK' ? x.Status : null, color: '--s1' })), { max: 100 }))}
      ${MC.panel('Scopes', '', '<div id="dh"></div>')}`;
    MC.table($('#dh'), sc, [{ key: 'Server', label: 'Server' }, { key: 'ScopeId', label: 'Scope', html: (r) => `<span class="mono">${esc(r.ScopeId)}</span>` }, { key: 'Name', label: 'Name' }, { key: 'Range', label: 'Range', cls: 'mono' }, { key: 'InUse', label: 'In use', n: true }, { key: 'Free', label: 'Free', n: true }, { key: 'PercentInUse', label: 'Used', n: true, html: (r) => minibar(r.PercentInUse, 85, 95) }, { key: 'LeaseDuration', label: 'Lease' }, { key: 'Failover', label: 'Failover' }], { sort: 'PercentInUse', name: 'dhcp-scopes' });
  };
  MON.sql = (el) => {
    const db = MC.data('sql.databases');
    const inst = [...new Set(db.map((d) => d.Instance))];
    el.innerHTML = `
      <div class="kpis">${MC.kpi('Instances', inst.length, db.length + ' databases')}${MC.kpi('Total size', fmt(sum(db.map((d) => d.SizeMB)) / 1024 / 1024) + ' TB', '')}${MC.kpi('Backup problems', db.filter((d) => d.Problems && d.Problems.length).length, 'missing or stale backups', { alert: db.some((d) => d.Problems && d.Problems.length) })}${MC.kpi('Full recovery', db.filter((d) => d.RecoveryModel === 'Full').length, 'need log backups')}</div>
      <div class="grid g-1-2">
        ${MC.panel('Size by instance', 'GB', '<div id="sqlDonut"></div>')}
        ${MC.panel('Backup age', 'hours since last full backup, oldest first', C.barList(db.filter((d) => !['tempdb', 'model'].includes(d.Database)).sort((a, b) => (b.FullBackupAgeHours == null ? 1e6 : b.FullBackupAgeHours) - (a.FullBackupAgeHours == null ? 1e6 : a.FullBackupAgeHours)).slice(0, 10).map((d) => ({ label: d.Instance + ' · ' + d.Database, value: d.FullBackupAgeHours == null ? 200 : d.FullBackupAgeHours, text: d.FullBackupAgeHours == null ? 'never' : fmt(d.FullBackupAgeHours, 0) + ' h', status: d.Health !== 'OK' ? d.Health : null, color: '--s1' })), { max: 200 }))}
      </div>
      ${MC.panel('Databases', '', '<div id="sqt"></div>')}`;
    C.donut($('#sqlDonut'), inst.slice(0, 4).map((i, k) => ({ label: i, value: Math.round(sum(db.filter((d) => d.Instance === i).map((d) => d.SizeMB)) / 1024), color: C.SERIES[k] })).concat(inst.length > 4 ? [{ label: 'Other', value: Math.round(sum(db.filter((d) => inst.indexOf(d.Instance) >= 4).map((d) => d.SizeMB)) / 1024), color: '--muted' }] : []), { centerLabel: 'GB', label: 'SQL size by instance' });
    MC.table($('#sqt'), db, [{ key: 'Instance', label: 'Instance', html: (r) => `<a href="#" data-res="sql-${esc(r.Instance)}">${esc(r.Instance)}</a>` }, { key: 'Database', label: 'Database' }, { key: 'Status', label: 'State' }, { key: 'RecoveryModel', label: 'Recovery' }, { key: 'SizeMB', label: 'Size GB', n: true, html: (r) => fmt(r.SizeMB / 1024) }, { key: 'FullBackupAgeHours', label: 'Full backup h', n: true, html: (r) => (r.FullBackupAgeHours == null ? '<span style="color:var(--crit-ink)">never</span>' : fmt(r.FullBackupAgeHours, 0)) }, { key: 'LogBackupAgeHours', label: 'Log backup h', n: true, html: (r) => (r.RecoveryModel !== 'Full' ? '–' : r.LogBackupAgeHours == null ? '<span style="color:var(--crit-ink)">never</span>' : fmt(r.LogBackupAgeHours, 0)) }, { key: 'AvailabilityGroup', label: 'AG' }, { key: 'Health', label: 'Health', html: (r) => pill(r.Health) }], { sort: 'Health', dir: -1, name: 'sql-databases' });
  };
  MON.printers = (el) => {
    const p = MC.data('printers.health');
    el.innerHTML = `
      <div class="kpis">${MC.kpi('Printers', p.length, 'on ' + new Set(p.map((x) => x.PrintServer)).size + ' print servers')}${MC.kpi('Healthy', p.filter((x) => x.Health === 'OK').length, '')}${MC.kpi('Problems', p.filter((x) => x.Health !== 'OK').length, sum(p.map((x) => x.StuckJobs)) + ' stuck jobs', { alert: p.some((x) => x.Health === 'Critical') })}${MC.kpi('Queued jobs', sum(p.map((x) => x.Jobs)), '')}</div>
      <div class="grid g-1-2">${MC.panel('Queue depth', 'jobs per printer', C.barList(p.slice().sort((a, b) => b.Jobs - a.Jobs).slice(0, 10).map((x) => ({ label: x.Printer, sub: x.Location, value: x.Jobs, text: x.Jobs + (x.StuckJobs ? ' (' + x.StuckJobs + ' stuck)' : ''), status: x.StuckJobs ? 'Warning' : null, color: '--s1' })), {}))}
      ${MC.panel('Printers', '', '<div id="pt"></div>')}</div>`;
    MC.table($('#pt'), p, [{ key: 'Printer', label: 'Printer', html: (r) => `<a href="#" data-res="prt-${esc(r.Printer)}">${esc(r.Printer)}</a>` }, { key: 'PrintServer', label: 'Server' }, { key: 'Location', label: 'Location' }, { key: 'Status', label: 'Status' }, { key: 'Jobs', label: 'Jobs', n: true }, { key: 'StuckJobs', label: 'Stuck', n: true }, { key: 'Health', label: 'Health', html: (r) => pill(r.Health) }], { sort: 'Health', dir: -1, name: 'printers', limit: 30 });
  };

  // ================================================================== INFRASTRUCTURE SERVICES (DNS, DHCP, file servers)
  // DNS, DHCP and file servers now live on the Active Directory page; old links keep working
  V.services = {
    title: 'Active Directory',
    render(el, route) { const tab = ['dns', 'dhcp', 'files'].includes(route.tab) ? route.tab : 'dns'; location.replace('#/identity/' + tab); },
  };
  function dnsTab(el, rows) {
    const failing = rows.filter((x) => (x.FailedTests || []).length);
    el.innerHTML = `<div class="kpis">${MC.kpi('DNS servers', rows.length, 'collected ' + ago((MC.ds['dns.servers'] || {}).finished))}${MC.kpi('Service stopped', rows.filter((x) => x.ServiceState !== 'Running').length, '', { alert: rows.some((x) => x.ServiceState !== 'Running') })}${MC.kpi('Failing lookups', failing.length, 'resolution tests', { alert: failing.length > 0 })}${MC.kpi('Slowest lookup', rows.length ? fmt(Math.max(...rows.map((x) => x.ResolveMs || 0)), 0) + ' ms' : '–', '')}${MC.kpi('DNS errors (24 h)', sum(rows.map((x) => x.Errors24h)), 'event log')}</div>
      ${failing.length ? MC.panel('Failing resolution tests', '', failing.map((x) => `<div class="insight Critical">${sevIcon('Critical')}<div><span class="area">${esc(x.ComputerName)}</span><b>${esc((x.FailedTests || []).join('; '))}</b></div></div>`).join('')) : ''}
      <div class="grid g-1-2">${MC.panel('Lookup time', 'ms, slowest first', C.barList(rows.slice().sort((a, b) => b.ResolveMs - a.ResolveMs).map((x) => ({ label: x.ComputerName, value: x.ResolveMs || 0, text: fmt(x.ResolveMs, 0) + ' ms', status: x.ResolveMs > 200 ? 'Warning' : 'OK' })), { compact: true }))}${MC.panel('DNS servers', '', '<div id="dnsT"></div>')}</div>`;
    MC.table($('#dnsT', el), rows, [
      { key: 'ComputerName', label: 'Server', html: (r) => `<span ${hostAttr(r.ComputerName)}>${esc(r.ComputerName)}</span>` },
      { key: 'ServiceState', label: 'Service' }, { key: 'Zones', label: 'Zones', n: true }, { key: 'AdIntegrated', label: 'AD-integrated', n: true },
      { key: 'ResolveMs', label: 'Lookup ms', n: true }, { key: 'QueriesPerSec', label: 'Queries/s', n: true }, { key: 'Errors24h', label: 'Errors 24 h', n: true },
      { key: 'Forwarders', label: 'Forwarders', html: (r) => `<span class="mono">${esc((r.Forwarders || []).join(', '))}</span>`, val: (r) => (r.Forwarders || []).join(', ') },
    ], { name: 'dns-servers', sort: 'ResolveMs', dir: -1 });
  }
  function files(el, rows) {
    el.innerHTML = `<div class="kpis">${MC.kpi('File servers', rows.length, 'collected ' + ago((MC.ds['fileserver.health'] || {}).finished))}${MC.kpi('Shares', sum(rows.map((x) => x.Shares)), '')}${MC.kpi('Sessions', sum(rows.map((x) => x.Sessions)), sum(rows.map((x) => x.OpenFiles)) + ' open files')}${MC.kpi('Quotas near limit', sum(rows.map((x) => x.QuotasNearLimit)), 'over 90%', { alert: rows.some((x) => x.QuotasNearLimit) })}${MC.kpi('Old shadow copies', rows.filter((x) => x.ShadowCopyAgeHours > 24).length, 'older than 24 h')}</div>
      <div class="grid g-1-2">${MC.panel('Lowest free space', '% free on the fullest data volume', C.barList(rows.slice().sort((a, b) => a.LowestFreePct - b.LowestFreePct).map((x) => ({ label: x.ComputerName, sub: x.LowestVolume, value: x.LowestFreePct, max: 100, text: fmt(x.LowestFreePct, 1) + '%', status: x.LowestFreePct < 15 ? 'Critical' : x.LowestFreePct < 25 ? 'Warning' : 'OK' })), { compact: true }))}${MC.panel('File servers', 'share permissions are under Security › File permissions', '<div id="fsT"></div>')}</div>`;
    MC.table($('#fsT', el), rows, [
      { key: 'ComputerName', label: 'Server', html: (r) => `<span ${hostAttr(r.ComputerName)}>${esc(r.ComputerName)}</span>` },
      { key: 'Shares', label: 'Shares', n: true }, { key: 'Sessions', label: 'Sessions', n: true }, { key: 'Users', label: 'Users', n: true }, { key: 'OpenFiles', label: 'Open files', n: true },
      { key: 'LowestFreePct', label: 'Lowest free %', n: true }, { key: 'QuotasNearLimit', label: 'Quotas near limit', n: true }, { key: 'ShadowCopyAgeHours', label: 'Shadow copy age h', n: true },
      { key: 'Message', label: 'Note', html: (r) => esc(r.Message || '') },
    ], { name: 'file-servers', sort: 'LowestFreePct', dir: 1 });
  }

  // ================================================================== VIRTUALIZATION
  // every virtual machine MonCastle knows, from the Hyper-V, VMware, OpenShift Virtualization and Nutanix engines
  const VM_SOURCES = [['virtualization.hyperv', 'Hyper-V', 'mon.hyperv'], ['virtualization.vmware', 'VMware', 'mon.vmware'], ['virtualization.openshift', 'OpenShift', 'mon.openshift'], ['virtualization.nutanix', 'Nutanix', 'mon.nutanix']];
  function allVMs() {
    const out = [];
    for (const v of MC.data('virtualization.hyperv').filter((x) => x.Kind === 'VM')) out.push({ id: 'hvvm-' + v.Name, Name: v.Name, Platform: 'Hyper-V', Host: v.Host, State: v.State === 'Running' ? 'Running' : v.State, vCPU: v.vCPU, MemoryGB: v.MemoryAssignedGB || v.MemoryStartupGB, CPU: v.CPUUsage, DiskGB: v.DiskProvisionedGB, IP: (v.IPAddresses || [])[0] || '', GuestOS: v.GuestOS || v.OS || '', Snap: v.OldestCheckpointDays, Health: v.Heartbeat || '', vmHost: v.Host });
    for (const v of MC.data('virtualization.vmware').filter((x) => x.Kind === 'VM')) out.push({ id: 'vmw-' + v.Name, Name: v.Name, Platform: 'VMware', Host: (v.Host || '').split('.')[0], State: v.Power === 'PoweredOn' ? 'Running' : v.Power === 'PoweredOff' ? 'Off' : v.Power, vCPU: v.vCPU, MemoryGB: v.MemoryGB, CPU: null, DiskGB: v.ProvisionedGB, IP: [].concat(v.IPAddress || [])[0] || '', GuestOS: v.GuestOS || '', Snap: v.OldestSnapshotDays, Health: v.ToolsStatus || '', vcenter: v.VCenter, dns: v.DnsName });
    for (const v of MC.data('virtualization.openshift').filter((x) => x.Kind === 'VM')) out.push({ id: 'ocp-' + v.Namespace + '-' + v.Name, Name: v.Name, Platform: 'OpenShift', Host: v.Host || '', State: v.Power, vCPU: v.vCPU, MemoryGB: v.MemoryGB, CPU: v.CPU != null ? v.CPU : null, DiskGB: null, IP: [].concat(v.IPAddress || [])[0] || '', GuestOS: v.GuestOS || '', Snap: null, Health: v.Agent ? 'guest agent connected' : 'no guest agent', Namespace: v.Namespace, Status: v.Status });
    for (const v of MC.data('virtualization.nutanix').filter((x) => x.Kind === 'VM')) out.push({ id: 'ntx-' + v.Name, Name: v.Name, Platform: 'Nutanix', Host: v.Host || '', State: v.Power === 'Off' ? 'Off' : v.Power, vCPU: v.vCPU, MemoryGB: v.MemoryGB, CPU: v.CPU != null ? v.CPU : null, DiskGB: v.DiskGB, IP: [].concat(v.IPAddress || [])[0] || '', GuestOS: v.GuestOS || '', Snap: null, Health: v.Agent ? 'NGT enabled' : 'no NGT', Status: v.Status });
    return out;
  }
  MC.allVMs = allVMs;
  const vmTarget = (r) => ({ name: r.dns || r.IP || r.Name, label: r.Name, kind: 'vm', platform: r.Platform, guestOS: r.GuestOS, vmHost: r.vmHost, vcenter: r.vcenter, vmName: r.Name });

  async function vmsTab(el, route) {
    const q = route.q || {};
    const vms = allVMs();
    let tree = null; try { tree = await MC.monTree(); } catch (e) { tree = null; }
    if (!document.body.contains(el)) return;
    const known = new Set(tree ? tree.devices.flatMap((d) => [String(d.name).toUpperCase(), String(d.host || '').toUpperCase()]) : []);
    for (const v of vms) v.Monitored = known.has(v.Name.toUpperCase()) || (v.IP && known.has(v.IP.toUpperCase()));
    const plat = q.platform || '';
    const list = vms.filter((v) => !plat || v.Platform === plat);
    const by = (p) => vms.filter((v) => v.Platform === p);
    const run = list.filter((v) => v.State === 'Running');
    const canAdd = MC.user && (MC.user.role === 'admin' || MC.user.override);
    el.innerHTML = `<div class="kpis">${MC.kpi('Virtual machines', vms.length, VM_SOURCES.map(([, p]) => by(p).length + ' ' + p).join(' · '))}${MC.kpi('Running', run.length + ' / ' + list.length, plat || 'all platforms')}${MC.kpi('vCPU', sum(run.map((v) => v.vCPU)), 'on running VMs')}${MC.kpi('Memory', fmt(sum(run.map((v) => v.MemoryGB)), 0) + ' GB', 'on running VMs')}${MC.kpi('Not monitored', list.filter((v) => !v.Monitored).length, 'no device in MonCastle yet')}${MC.kpi('Problems', list.filter((v) => v.Status === 'Critical' || /Critical|Crash|Error/i.test(v.State)).length, '', { alert: list.some((v) => v.Status === 'Critical') })}</div>
      <div class="toolbar"><div class="mfilter" role="group" aria-label="Platform"><button class="btn sm ${!plat ? 'on' : ''}" data-plat="">All <span class="muted">${vms.length}</span></button>${VM_SOURCES.map(([, p]) => `<button class="btn sm ${plat === p ? 'on' : ''}" data-plat="${p}">${p} <span class="muted">${by(p).length}</span></button>`).join('')}</div><span class="spacer"></span><a class="btn sm" href="#/engines" style="white-space:normal;max-width:100%;text-align:left">Engines: ${VM_SOURCES.map(([, , id]) => id).join(', ')}</a></div>
      ${MC.panel('Virtual machines', 'Troubleshoot opens the tasks that fit the VM: its power and snapshots on the platform, and networking and data inside the guest', '<div id="vmAll"></div>')}`;
    MC.table($('#vmAll', el), list, [
      { key: 'Name', label: 'VM', html: (r) => `<b>${esc(r.Name)}</b>${r.Namespace ? `<div class="muted" style="font-size:11.5px">${esc(r.Namespace)}</div>` : ''}` },
      { key: 'Platform', label: 'Platform' }, { key: 'Host', label: 'Host / node' },
      { key: 'State', label: 'State', html: (r) => pill(r.State === 'Running' ? 'OK' : /Crash|Error|Fail/i.test(r.State) ? 'Critical' : 'Unknown', r.State) },
      { key: 'GuestOS', label: 'Guest OS', html: (r) => esc(r.GuestOS || '–') }, { key: 'IP', label: 'IP address', cls: 'mono' },
      { key: 'vCPU', label: 'vCPU', n: true }, { key: 'MemoryGB', label: 'Memory GB', n: true, html: (r) => fmt(r.MemoryGB, 0) },
      { key: 'CPU', label: 'CPU %', n: true, html: (r) => (r.CPU == null ? '–' : minibar(r.CPU)) },
      { key: 'Snap', label: 'Oldest snapshot d', n: true, html: (r) => (r.Snap ? `<span style="${r.Snap > 7 ? 'color:var(--warn-ink);font-weight:600' : ''}">${r.Snap}</span>` : '–') },
      { key: 'Monitored', label: 'Monitored', html: (r) => (r.Monitored ? pill('OK', 'yes') : canAdd ? `<button class="btn sm" data-addvm="${esc(r.id)}">Add to monitoring</button>` : pill('Unknown', 'no')), val: (r) => (r.Monitored ? 'yes' : 'no') },
      { key: 'ts', label: '', noCsv: true, html: (r) => `<button class="btn sm primary" data-ts="${esc(r.id)}">${icon('bolt', 'sev-ico')}Troubleshoot</button>` },
    ], { sort: 'Name', dir: 1, name: 'virtual-machines-all', limit: 100, after: (w) => {
      $$('[data-ts]', w).forEach((b) => b.addEventListener('click', () => MC.troubleshoot(vmTarget(list.find((v) => v.id === b.dataset.ts)))));
      $$('[data-addvm]', w).forEach((b) => b.addEventListener('click', async () => {
        const v = list.find((x) => x.id === b.dataset.addvm);
        const os = root.MCTroubleshoot.osOf({ guestOS: v.GuestOS, kind: 'vm' });
        b.disabled = true;
        try { const r = await MC.api.monitor('applyDiscovery', { items: [{ name: v.Name, host: v.dns || v.IP || v.Name, kind: os === 'linux' ? 'linux' : 'server', group: os === 'linux' ? 'g:lnx' : 'g:srv', ports: os === 'linux' ? [22] : [3389, 5985] }] }); MC.toast(r.added.length ? 'Added ' + esc(v.Name) + ' with its default sensors' : esc(v.Name) + ' is already a device', 'ok'); await MC.monTree(true); MC.render(); } catch (e) { b.disabled = false; MC.toast(esc(e.message), 'err'); }
      }));
    } });
    $$('[data-plat]', el).forEach((b) => b.addEventListener('click', () => MC.go('virtualization', 'vms', { platform: b.dataset.plat })));
  }

  V.virtualization = {
    title: 'Virtualization',
    crumb: () => (MC.route.tab === 'vms' ? 'every virtual machine on Hyper-V, VMware, OpenShift Virtualization and Nutanix AHV' : 'Hyper-V, VMware vSphere, OpenShift Virtualization, Nutanix AHV and failover clusters'),
    render(el, route) {
      const tab = ['vms', 'hyperv', 'vmware', 'openshift', 'nutanix'].includes(route.tab) ? route.tab : 'hosts';
      const vmn = allVMs().length;
      el.innerHTML = MC.tabs('virtualization', [['hosts', 'Overview'], ['hyperv', 'Hyper-V'], ['vmware', 'VMware'], ['openshift', 'OpenShift'], ['nutanix', 'Nutanix'], ['vms', 'Virtual machines (' + vmn + ')']], tab) + '<div id="vtab"></div>';
      const box = $('#vtab', el);
      if (tab === 'vms') { VM_SOURCES.forEach(([ds]) => MC.data(ds)); return vmsTab(box, route); }
      if (tab !== 'hosts') return platformTab(box, tab);
      hostsTab(box);
    },
  };
  // one platform: its hosts or nodes, its VMs, its storage; add a cluster from here
  const PLAT = {
    hyperv: { name: 'Hyper-V', ds: 'virtualization.hyperv', script: 'mon.hyperv', hosts: (r) => r.Kind === 'Host', vms: (r) => r.Kind === 'VM', add: { kind: 'server', group: 'g:hv' }, how: 'Hyper-V hosts are found in Active Directory by the Hyper-V engine, or add a host and tick "Hyper-V host and virtual machines".' },
    vmware: { name: 'VMware vSphere', ds: 'virtualization.vmware', script: 'mon.vmware', hosts: (r) => r.Kind === 'ESXi', vms: (r) => r.Kind === 'VM', store: (r) => r.Kind === 'Datastore', add: { kind: 'host', group: 'g:vmw' }, how: 'Add the vCenter and tick "VMware hosts, datastores and virtual machines". Assign a VMware credential.' },
    openshift: { name: 'OpenShift Virtualization', ds: 'virtualization.openshift', script: 'mon.openshift', hosts: (r) => r.Kind === 'Node', vms: (r) => r.Kind === 'VM', add: { kind: 'cluster', group: 'g:ocp' }, how: 'Add the cluster with its API address (for example api.ocp.example.com), tick "OpenShift Virtualization nodes and virtual machines" and assign a web/API credential with a service-account token that can read nodes and VirtualMachineInstances.' },
    nutanix: { name: 'Nutanix AHV', ds: 'virtualization.nutanix', script: 'mon.nutanix', hosts: (r) => r.Kind === 'Host', vms: (r) => r.Kind === 'VM', store: (r) => r.Kind === 'Container', add: { kind: 'cluster', group: 'g:ntx' }, how: 'Add Prism Central (or Prism Element) by address, tick "Nutanix AHV hosts, virtual machines and storage containers" and assign a web/API credential (a Prism viewer account is enough).' },
  };
  function platformTab(el, id) {
    const P = PLAT[id], rows = MC.data(P.ds);
    const hosts = rows.filter(P.hosts), vms = rows.filter(P.vms), store = P.store ? rows.filter(P.store) : [];
    const on = (v) => /Running|PoweredOn/.test(v.State || v.Power || '');
    const canAdd = MC.user.role !== 'reader';
    el.innerHTML = `<div class="kpis">${MC.kpi(id === 'openshift' ? 'Nodes' : 'Hosts', hosts.length, [...new Set(hosts.map((h) => h.Cluster).filter(Boolean))].length + ' clusters')}${MC.kpi('VMs running', vms.filter(on).length + ' / ' + vms.length, vms.filter((v) => !on(v)).length + ' stopped')}${MC.kpi('vCPU assigned', sum(vms.map((v) => v.vCPU || 0)), '')}${MC.kpi('VM memory', fmt(sum(vms.map((v) => v.MemoryGB || v.MemoryAssignedGB || 0)), 0) + ' GB', '')}${store.length ? MC.kpi(id === 'nutanix' ? 'Storage containers' : 'Datastores', store.length, store.filter((x) => x.Status && x.Status !== 'OK').length + ' need attention') : ''}</div>
      ${rows.length ? '' : `<div class="notice">${icon('info', 'sev-ico')} No ${esc(P.name)} data yet. ${esc(P.how)}</div>`}
      ${MC.panel(id === 'openshift' ? 'Nodes' : 'Hosts', P.name, '<div id="plH"></div>', { act: (canAdd ? `<button class="btn sm primary" id="plAdd">Add ${id === 'openshift' ? 'an OpenShift cluster' : id === 'nutanix' ? 'a Nutanix cluster' : id === 'vmware' ? 'a vCenter' : 'a Hyper-V host'}</button>` : '') + `<button class="btn sm" ${MC.runAttr(P.script, {})}>Collect now…</button>` })}
      ${store.length ? MC.panel(id === 'nutanix' ? 'Storage containers' : 'Datastores', '', C.barList(store.map((x) => ({ label: x.Name, sub: x.Cluster || x.VCenter || '', value: x.UsedPct, text: fmt(x.UsedPct, 1) + '% used · ' + fmt(x.FreeGB, 0) + ' GB free', status: x.UsedPct >= 90 ? 'Critical' : x.UsedPct >= 80 ? 'Warning' : null, color: '--s1' })), { max: 100 })) : ''}
      ${MC.panel('Virtual machines', vms.length + ' on ' + P.name, '<div id="plV"></div>')}`;
    MC.table($('#plH', el), hosts, [{ key: 'Name', label: id === 'openshift' ? 'Node' : 'Host', html: (r) => `<b>${esc(r.Name)}</b>` }, { key: 'Cluster', label: 'Cluster', val: (r) => r.Cluster || r.VCenter || '' }, { key: 'State', label: 'State', html: (r) => pill(/Ready|Connected|HYPER|OK|Running/i.test(r.State || r.Status || 'OK') ? 'OK' : 'Warning', r.State || r.Status || 'OK') }, { key: 'CPUs', label: 'CPUs', n: true, val: (r) => r.CPUs || r.LogicalCPUs }, { key: 'MemoryGB', label: 'Memory GB', n: true }, { key: 'VMs', label: 'VMs', n: true, val: (r) => (r.VMs != null ? r.VMs : r.VMCount) }, { key: 'Version', label: 'Version' }], { name: 'virt-' + id + '-hosts', empty: P.how });
    MC.table($('#plV', el), vms, [{ key: 'Name', label: 'VM', html: (r) => `<b>${esc(r.Name)}</b>${r.Namespace ? `<div class="muted" style="font-size:12px">namespace ${esc(r.Namespace)}</div>` : ''}` }, { key: 'Host', label: 'Host / node' }, { key: 'State', label: 'State', val: (r) => r.State || r.Power, html: (r) => pill(on(r) ? 'OK' : r.Status === 'Critical' ? 'Critical' : 'Unknown', r.State || r.Power) }, { key: 'GuestOS', label: 'Guest OS', val: (r) => r.GuestOS || r.OS || '' }, { key: 'vCPU', label: 'vCPU', n: true }, { key: 'MemoryGB', label: 'Memory GB', n: true, val: (r) => r.MemoryGB || r.MemoryAssignedGB }, { key: 'CPU', label: 'CPU %', n: true, val: (r) => (r.CPU != null ? r.CPU : r.CPUUsage), html: (r) => { const v = r.CPU != null ? r.CPU : r.CPUUsage; return v == null ? '–' : minibar(v); } }, { key: 'Agent', label: 'Guest agent', val: (r) => (r.Agent == null ? r.ToolsStatus || r.Heartbeat || '' : r.Agent ? 'Connected' : 'Not running') }], { name: 'virt-' + id + '-vms', limit: 25 });
    if ($('#plAdd', el)) $('#plAdd', el).addEventListener('click', () => MC.addDevice(P.add));
  }
  function hostsTab(el) {
    {
      const hv = MC.data('virtualization.hyperv'), vw = MC.data('virtualization.vmware');
      const hosts = hv.filter((x) => x.Kind === 'Host'), hvms = hv.filter((x) => x.Kind === 'VM');
      const esx = vw.filter((x) => x.Kind === 'ESXi'), dsx = vw.filter((x) => x.Kind === 'Datastore'), vvms = vw.filter((x) => x.Kind === 'VM');
      const cl = MC.data('virtualization.clusters');
      const ocp = MC.data('virtualization.openshift'), ntx = MC.data('virtualization.nutanix');
      const ocpN = ocp.filter((x) => x.Kind === 'Node'), ntxH = ntx.filter((x) => x.Kind === 'Host'), ntxC = ntx.filter((x) => x.Kind === 'Container');
      const running = hvms.filter((v) => v.State === 'Running').length + vvms.filter((v) => v.Power === 'PoweredOn').length;
      const vcpu = sum(hosts.map((h) => h.vCPUAssigned)), lcpu = sum(hosts.map((h) => h.LogicalCPUs));
      el.innerHTML = `
        <div class="kpis">${MC.kpi('Hosts', hosts.length + esx.length, hosts.length + ' Hyper-V · ' + esx.length + ' ESXi')}${MC.kpi('VMs running', running + ' / ' + (hvms.length + vvms.length), '')}${MC.kpi('Hyper-V vCPU ratio', fmt(vcpu / (lcpu || 1), 2) + ' : 1', vcpu + ' vCPU on ' + lcpu + ' logical')}${MC.kpi('Datastore used', pct(sum(dsx.map((d) => d.CapacityGB - d.FreeGB)), sum(dsx.map((d) => d.CapacityGB))) + '%', fmt(sum(dsx.map((d) => d.FreeGB)) / 1024) + ' TB free', { alert: dsx.some((d) => d.Status === 'Critical') })}${MC.kpi('Clusters', cl.length, cl.filter((c) => c.Status !== 'OK').length + ' with problems', { alert: cl.some((c) => c.Status === 'Critical') })}</div>
        ${MC.panel('Hosts', 'capacity and load', `<div class="host-cards">${hosts.map((h) => {
          const memPct = pct(h.MemoryGB - h.MemoryFreeGB, h.MemoryGB);
          const r = MC.model.byId.get('srv-' + h.Name) || {};
          return `<div class="card host-card" data-host="${esc(h.Name)}" tabindex="0" role="button"><div style="display:flex;gap:8px;align-items:center"><b>${esc(h.Name)}</b><span class="muted" style="font-size:12px">Hyper-V${h.Clustered ? ' · clustered' : ''}</span><span style="margin-left:auto">${pill(r.status || 'OK')}</span></div>
            <div class="gauges">${C.gauge(r.metrics ? r.metrics.cpu : 0, { label: 'CPU' })}${C.gauge(memPct, { label: 'Memory', warn: 80, crit: 92 })}</div>
            <div class="cap"><div class="lbl"><span>vCPU assigned</span><span>${h.vCPUAssigned} / ${h.LogicalCPUs}</span></div>${C.barList([{ label: '', value: h.vCPUAssigned, text: fmt(h.vCPUAssigned / h.LogicalCPUs, 2) + ':1', color: '--s1' }], { max: h.LogicalCPUs }).replace('<div class="lbl" title=""></div>', '')}</div>
            <div class="muted" style="font-size:12px">${h.VMRunning} of ${h.VMCount} VMs running · ${h.MemoryAssignedGB} of ${h.MemoryGB} GB assigned</div></div>`;
        }).join('')}${esx.map((e) => `<div class="card host-card" data-res="esx-${esc(e.Name)}" tabindex="0" role="button"><div style="display:flex;gap:8px;align-items:center"><b>${esc(e.Name.split('.')[0])}</b><span class="muted" style="font-size:12px">ESXi · ${esc(e.Cluster)}</span><span style="margin-left:auto">${pill((MC.model.byId.get('esx-' + e.Name) || {}).status || 'OK')}</span></div>
            <div class="gauges">${C.gauge(e.CPUUsedPct, { label: 'CPU' })}${C.gauge(e.MemoryUsedPct, { label: 'Memory', warn: 80, crit: 90 })}</div>
            <div class="muted" style="font-size:12px">${e.VMs} VMs · ${e.CPUs} cores · ${e.MemoryGB} GB · ${esc(e.Version.split(' ')[0])}</div></div>`).join('')}</div>`)}
        <div class="grid g2">
          ${MC.panel('ESXi load, last 7 days', 'CPU % per host', '<div id="esxTrend"></div>')}
          ${MC.panel('Failover clusters', '', cl.map((c) => `<div style="margin-bottom:12px" data-res="cl-${esc(c.Cluster)}" tabindex="0" role="button" class="cat-row" style="grid-template-columns:auto 1fr auto"><span>${icon('layers')}</span><div><b>${esc(c.Cluster)}</b><small>${c.NodesUp}/${c.Nodes.length} nodes up · ${c.Roles.length} roles · ${esc(c.QuorumType)}</small>${(c.Problems || []).length ? `<small style="color:var(--crit-ink)">${esc(c.Problems.join('; '))}</small>` : ''}</div><div class="svc-dots">${c.Nodes.map((n) => `<span class="${n.State === 'Up' ? '' : 'bad'}">${esc(n.Name)}</span>`).join('')}</div>${pill(c.Status)}</div>`).join('') + C.barList(MC.data('virtualization.clusterstorage').map((d) => ({ label: d.Cluster + ' · ' + d.Name, sub: d.Owner, value: d.UsedPct, text: fmt(d.UsedPct, 0) + '%', status: d.Status !== 'OK' ? d.Status : null, color: '--s1' })), { max: 100, compact: true }))}
        </div>
        ${(ocpN.length || ntxH.length) ? MC.panel('OpenShift nodes and Nutanix hosts', ocpN.length + ' OpenShift nodes · ' + ntxH.length + ' Nutanix hosts', '<div id="vh2"></div>') : ''}
        ${ntxC.length ? MC.panel('Nutanix storage containers', '', C.barList(ntxC.map((x) => ({ label: x.Name, sub: x.Cluster, value: x.UsedPct, max: 100, text: fmt(x.UsedPct, 1) + '% · ' + x.FreeGB + ' GB free', status: x.Status }))))  : ''}
        ${MC.panel('Virtual machines', (hvms.length + vvms.length) + ' on Hyper-V and VMware · <a href="#/virtualization/vms">all ' + allVMs().length + ' VMs with troubleshooting</a>', '<div id="vmt"></div>')}`;
      if ($('#vh2', el)) MC.table($('#vh2', el), ocpN.concat(ntxH), [{ key: 'Name', label: 'Host / node' }, { key: 'Platform', label: 'Platform' }, { key: 'Cluster', label: 'Cluster' }, { key: 'State', label: 'State' }, { key: 'CPUs', label: 'CPUs', n: true }, { key: 'MemoryGB', label: 'Memory GB', n: true }, { key: 'VMs', label: 'VMs', n: true }, { key: 'Version', label: 'Version' }], { name: 'virt-nodes', sort: 'Name', dir: 1 });
      const hist = vw.filter((x) => x.Kind === 'History');
      C.timeSeries($('#esxTrend'), esx.slice(0, 4).map((e, i) => ({ name: e.Name.split('.')[0], color: C.SERIES[i], points: hist.filter((h) => h.Name === e.Name).sort((a, b) => Date.parse(a.Time) - Date.parse(b.Time)).map((h) => ({ t: Date.parse(h.Time), v: h.CPU })) })), { unit: '%', yMax: 100, area: false, height: 210 });
      const vms = hvms.map((v) => ({ id: 'hvvm-' + v.Name, Name: v.Name, Platform: 'Hyper-V', Host: v.Host, State: v.State, vCPU: v.vCPU, MemoryGB: v.MemoryAssignedGB, CPU: v.CPUUsage, DiskGB: v.DiskProvisionedGB, Snap: v.OldestCheckpointDays, Health: v.Heartbeat }))
        .concat(vvms.map((v) => ({ id: 'vmw-' + v.Name, Name: v.Name, Platform: 'VMware', Host: (v.Host || '').split('.')[0], State: v.Power, vCPU: v.vCPU, MemoryGB: v.MemoryGB, CPU: null, DiskGB: v.ProvisionedGB, Snap: v.OldestSnapshotDays, Health: v.ToolsStatus })));
      MC.table($('#vmt'), vms, [
        { key: 'Name', label: 'VM', html: (r) => `<a href="#" data-res="${esc(r.id)}">${esc(r.Name)}</a>` }, { key: 'Platform', label: 'Platform' }, { key: 'Host', label: 'Host' },
        { key: 'State', label: 'State', html: (r) => pill(/Running|PoweredOn/.test(r.State) ? 'OK' : 'Unknown', r.State) },
        { key: 'vCPU', label: 'vCPU', n: true }, { key: 'MemoryGB', label: 'Memory GB', n: true, html: (r) => fmt(r.MemoryGB, 0) }, { key: 'CPU', label: 'CPU %', n: true, html: (r) => (r.CPU == null ? '–' : minibar(r.CPU)) },
        { key: 'DiskGB', label: 'Disk GB', n: true, html: (r) => fmt(r.DiskGB, 0) }, { key: 'Snap', label: 'Oldest snapshot d', n: true, html: (r) => (r.Snap ? `<span style="${r.Snap > 7 ? 'color:var(--warn-ink);font-weight:600' : ''}">${r.Snap}</span>` : '–') }, { key: 'Health', label: 'Tools / heartbeat' },
      ], { sort: 'Snap', name: 'virtual-machines' });
    }
  }

  // ================================================================== IDENTITY & AD
  V.identity = {
    title: 'Active Directory',
    crumb: () => MC.data('ad.health').length + ' domain controllers · ' + MC.data('ad.users').length + ' users · ' + MC.data('ad.computers').length + ' computer accounts',
    render(el, route) {
      const tab = route.tab || 'health';
      const repBad = MC.data('ad.replication').filter((x) => x.Status === 'Critical').length;
      const svcBad = MC.data('ad.health').reduce((a, d) => a + Object.values(d.Services || {}).filter((v) => v !== 'Running').length, 0);
      const gpoBad = MC.data('ad.gpo').filter((x) => x.VersionMismatch).length;
      const siteBad = MC.data('ad.sites').filter((x) => x.Status !== 'OK').length;
      const b = (n, s) => (n ? { n, s } : null);
      const dns = MC.data('dns.servers'), dh = MC.data('network.dhcp'), fsv = MC.data('fileserver.health'), prn = MC.data('printers.health'), sqlDb = MC.data('sql.databases'), iis = MC.data('servers.iis');
      const secCrit = MC.data('ad.security').filter((x) => x.Severity === 'Critical').length;
      const dir = [['health', 'Domain controllers'], ['reports', 'Reports & investigations'], ['security', 'Security & tiering', b(secCrit, 'Critical')], ['replication', 'Replication', b(repBad, 'Critical')], ['sites', 'Sites and site links', b(siteBad, 'Warning')], ['services', 'AD services', b(svcBad, 'Critical')], ['gpo', 'Group Policy', b(gpoBad, 'Critical')], ['users', 'Users'], ['groups', 'Privileged groups'], ['computers', 'Computer accounts'], ['workstations', 'Workstations']];
      const roles = [['roles', 'All AD-integrated servers'], ['dns', 'DNS', b(dns.filter((x) => x.ServiceState !== 'Running' || (x.FailedTests || []).length).length, 'Critical')], ['dhcp', 'DHCP', b(dh.filter((x) => x.Status !== 'OK').length, 'Warning')], ['files', 'File servers', b(fsv.filter((x) => x.Message || x.QuotasNearLimit || x.LowestFreePct < 15).length, 'Warning')], ['dfs', 'DFS'], ['printers', 'Print servers', b(prn.filter((x) => x.Health !== 'OK').length, 'Warning')], ['ca', 'Certificate Authority'], ['iis', 'IIS', b(iis.filter((x) => x.State !== 'Started').length, 'Warning')], ['databases', 'Databases', b(sqlDb.filter((x) => (x.Problems || []).length).length, 'Warning')], ['other', 'WSUS, NPS, RDS']];
      el.innerHTML = `<div class="tab-rows"><div class="tab-row"><span class="tab-lbl">Directory</span>${MC.tabs('identity', dir, tab)}</div><div class="tab-row"><span class="tab-lbl">AD-integrated services</span>${MC.tabs('identity', roles, tab)}</div></div><div id="tab" class="grid"></div>`;
      const t = $('#tab', el);
      const ROLE_TABS = {
        roles: (x) => roleOverview(x), dns: (x) => dnsTab(x, dns), dhcp: (x) => MON.dhcp(x), files: (x) => files(x, fsv), printers: (x) => MON.printers(x), databases: (x) => dbTab(x), iis: (x) => iisTab(x),
        dfs: (x) => roleTab(x, ['DFS'], 'DFS namespace and replication servers', 'DFS namespaces and DFS Replication (DFSR service)', ['DFSR', 'Dfs']),
        ca: (x) => roleTab(x, ['CertificateAuthority'], 'Certificate Authority servers', 'Active Directory Certificate Services (CertSvc). Add an SSL certificate sensor to watch the CA web enrolment certificate.', ['CertSvc']),
        other: (x) => roleTab(x, ['WSUS', 'NPS', 'RDS'], 'WSUS, NPS and Remote Desktop servers', 'Other AD-integrated roles', ['WsusService', 'IAS', 'TermService', 'Tssdis']),
      };
      ({ reports: (x) => MC.adReports(x, route), security: (x) => MC.adSecurity(x), health: idHealth, replication: idReplication, sites: idSites, services: idServices, gpo: idGpo, users: (x) => idUsers(x, route.q.q), groups: idGroups, computers: idComputers, workstations: (x) => idWorkstations(x, route.q.q) }[tab] || ROLE_TABS[tab] || idHealth)(t);
    },
  };
  // ---- AD-integrated servers: every server whose role ties it to the domain, with the state MonCastle sees
  const AD_ROLE_NAMES = { DomainControllers: 'Domain controller', DNS: 'DNS', DHCP: 'DHCP', FileServers: 'File server', DFS: 'DFS', PrintServers: 'Print server', CertificateAuthority: 'Certificate Authority', IIS: 'IIS web server', SQL: 'SQL Server', WSUS: 'WSUS', NPS: 'NPS (RADIUS)', RDS: 'Remote Desktop', Clusters: 'Failover cluster', HyperV: 'Hyper-V' };
  const AD_ROLE_TAB = { DomainControllers: 'health', DNS: 'dns', DHCP: 'dhcp', FileServers: 'files', DFS: 'dfs', PrintServers: 'printers', CertificateAuthority: 'ca', IIS: 'iis', SQL: 'databases', WSUS: 'other', NPS: 'other', RDS: 'other' };
  function serverRows(roleList) {
    const comp = MC.data('servers.compute'), av = MC.data('servers.availability'), svc = MC.data('servers.services');
    const up = (n) => n.toUpperCase();
    return MC.data('inventory.roles').filter((x) => !roleList || (x.Roles || []).some((r) => roleList.includes(r))).map((x) => {
      const c = comp.find((r) => up(r.ComputerName || r.Name || '') === up(x.ComputerName)) || {}, a = av.find((r) => up(r.Name || r.ComputerName || '') === up(x.ComputerName)) || {};
      const stopped = svc.filter((r) => up(r.ComputerName) === up(x.ComputerName) && r.Problem).map((r) => r.Name);
      const state = x.Online === false || a.Status === 'Offline' ? 'Critical' : stopped.length || c.Status === 'Critical' ? 'Warning' : c.Status === 'Warning' ? 'Warning' : 'OK';
      return { ComputerName: x.ComputerName, Roles: (x.Roles || []).filter((r) => AD_ROLE_NAMES[r]), State: state, CPU: c.CPU, Memory: c.Memory, UptimeDays: a.UptimeDays != null ? a.UptimeDays : c.UptimeDays, Stopped: stopped };
    });
  }
  const roleCols = (svcHint) => [
    { key: 'ComputerName', label: 'Server', html: (r) => `<span ${hostAttr(r.ComputerName)}><b>${esc(r.ComputerName)}</b></span>` },
    { key: 'State', label: 'State', html: (r) => pill(r.State, r.State === 'OK' ? 'OK' : r.State === 'Critical' ? 'Offline' : 'Needs attention') },
    { key: 'Roles', label: 'Roles', val: (r) => r.Roles.map((x) => AD_ROLE_NAMES[x]).join(', '), html: (r) => r.Roles.map((x) => `<a class="tag" href="#/identity/${AD_ROLE_TAB[x] || 'roles'}">${esc(AD_ROLE_NAMES[x])}</a>`).join(' ') },
    { key: 'CPU', label: 'CPU %', n: true }, { key: 'Memory', label: 'Memory %', n: true }, { key: 'UptimeDays', label: 'Up days', n: true },
    { key: 'Stopped', label: 'Stopped services', val: (r) => r.Stopped.join(', '), html: (r) => (r.Stopped.length ? r.Stopped.map((n) => `<span class="mono" style="color:var(--crit-ink)">${esc(n)}</span>`).join(', ') : `<span class="muted">${esc(svcHint || 'none')}</span>`) },
    { key: 'act', label: '', noCsv: true, html: (r) => `<button class="btn sm ghost" ${hostAttr(r.ComputerName)}>Open</button>` },
  ];
  function roleOverview(el) {
    const rows = serverRows(Object.keys(AD_ROLE_TAB));
    const by = Object.keys(AD_ROLE_TAB).map((r) => [r, rows.filter((x) => x.Roles.includes(r))]).filter(([, l]) => l.length);
    el.innerHTML = `<div class="kpis">${MC.kpi('AD-integrated servers', rows.length, by.length + ' roles')}${MC.kpi('Need attention', rows.filter((x) => x.State === 'Warning').length, 'stopped services or high load', { alert: rows.some((x) => x.State === 'Warning') })}${MC.kpi('Offline', rows.filter((x) => x.State === 'Critical').length, '', { alert: rows.some((x) => x.State === 'Critical') })}${MC.kpi('Domain controllers', MC.data('ad.health').length, MC.data('ad.replication').filter((x) => x.Status === 'Critical').length + ' failing replication links')}</div>
      <div class="role-cards">${by.map(([r, l]) => { const bad = l.filter((x) => x.State !== 'OK').length; return `<a class="card role-card" href="#/identity/${AD_ROLE_TAB[r]}"><b>${esc(AD_ROLE_NAMES[r])}</b><span class="big">${l.length}</span><span class="${bad ? 'bad' : 'muted'}">${bad ? bad + ' need attention' : 'all healthy'}</span><span class="muted" style="font-size:12px">${esc(l.slice(0, 4).map((x) => x.ComputerName).join(', '))}${l.length > 4 ? ' …' : ''}</span></a>`; }).join('')}</div>
      ${MC.panel('Servers by role', 'roles from the server inventory; state from the compute, availability and services engines', '<div id="roT"></div>')}`;
    MC.table($('#roT', el), rows, roleCols(), { name: 'ad-integrated-servers', sort: 'State' });
  }
  function roleTab(el, roleList, title, sub, services) {
    const rows = serverRows(roleList);
    const svc = MC.data('servers.services').filter((r) => rows.some((x) => x.ComputerName.toUpperCase() === String(r.ComputerName).toUpperCase()) && (!services || services.some((n) => String(r.Name).toLowerCase() === n.toLowerCase())));
    el.innerHTML = `<div class="kpis">${MC.kpi('Servers', rows.length, roleList.map((r) => AD_ROLE_NAMES[r]).join(', '))}${MC.kpi('Need attention', rows.filter((x) => x.State !== 'OK').length, '', { alert: rows.some((x) => x.State !== 'OK') })}${MC.kpi('Role services stopped', svc.filter((x) => x.Problem).length, (services || []).join(', '))}</div>
      ${MC.panel(title, sub, '<div id="rlT"></div>')}
      ${rows.length ? '' : `<div class="notice">No server with this role has been found yet. The server inventory engine (inv.roles) finds roles; you can also add the server under <a href="#/sensors">Configure › Devices & sensors</a> and give it sensors.</div>`}`;
    MC.table($('#rlT', el), rows, roleCols('role services running'), { name: 'ad-role-' + roleList.join('-').toLowerCase() });
  }
  function iisTab(el) {
    const iis = MC.data('servers.iis'), rows = serverRows(['IIS']);
    el.innerHTML = `<div class="kpis">${MC.kpi('IIS servers', rows.length, '')}${MC.kpi('Application pools', iis.length, iis.filter((x) => x.State !== 'Started').length + ' not started', { alert: iis.some((x) => x.State !== 'Started') })}</div>
      <div class="grid g2">${MC.panel('IIS servers', '', '<div id="iisS"></div>')}${MC.panel('Application pools', 'pools that are not started come first', '<div id="iisP"></div>')}</div>`;
    MC.table($('#iisS', el), rows, roleCols('W3SVC running').slice(0, 7), { name: 'iis-servers', search: false });
    MC.table($('#iisP', el), iis, [{ key: 'ComputerName', label: 'Server' }, { key: 'Pool', label: 'Pool' }, { key: 'State', label: 'State', html: (r) => pill(r.State === 'Started' ? 'OK' : 'Warning', r.State) }, { key: 'Runtime', label: 'CLR' }, { key: 'Sites', label: 'Sites', val: (r) => [].concat(r.Sites || []).join(', ') }], { name: 'iis-pools', sort: 'State', dir: -1 });
  }
  function dbTab(el) {
    const box = document.createElement('div'); box.className = 'grid'; box.style.minWidth = '0'; el.appendChild(box);
    MON.sql(box);
    const other = MC.data('databases.health');
    if (other.length) {
      const p = document.createElement('div'); p.style.minWidth = '0'; el.appendChild(p);
      p.innerHTML = MC.panel('Other database engines', 'MySQL, PostgreSQL, Oracle, MongoDB and more, from the database engine', '<div id="dbO"></div>');
      MC.table($('#dbO', p), other, Object.keys(other[0]).filter((k) => typeof other[0][k] !== 'object').slice(0, 9).map((k) => ({ key: k, label: k })), { name: 'database-instances' });
    }
  }
  function idHealth(el) {
    const dcs = MC.data('ad.health'), rep = MC.data('ad.replication');
    const names = dcs.map((d) => d.Name);
    const cell = (s, p) => {
      if (s === p) return '<td class="self"></td>';
      const links = rep.filter((x) => x.Server === s && x.Partner === p);
      if (!links.length) return '<td class="muted">·</td>';
      const bad = links.some((x) => x.Status === 'Critical');
      const m = Math.max(...links.map((x) => x.MinutesSinceSuccess));
      return `<td class="${bad ? 'Critical' : 'OK'}" title="${esc(p)} → ${esc(s)}: last success ${m} min ago${bad ? ', error ' + links.find((x) => x.Status === 'Critical').LastResult : ''}">${bad ? '✕ ' + Math.round(m / 60) + 'h' : m + 'm'}</td>`;
    };
    el.innerHTML = `
      <div class="dc-cards">${dcs.map((d) => `<div class="card dc-card" data-host="${esc(d.Name)}" tabindex="0" role="button" style="cursor:pointer"><div style="display:flex;gap:8px;align-items:center"><b>${esc(d.Name)}</b><span class="muted" style="font-size:12px">${esc(d.Site)}</span><span style="margin-left:auto">${pill(d.Status)}</span></div>
        <div class="muted" style="font-size:12px">${esc(d.IPv4)} · ${d.GlobalCatalog ? 'GC' : 'no GC'}${d.ReadOnly ? ' · RODC' : ''} · offset ${fmt(d.TimeOffsetSec, 3)} s</div>
        <div class="svc-dots">${Object.entries(d.Services || {}).map(([k, v]) => `<span class="${v === 'Running' ? '' : 'bad'}" title="${esc(k)}: ${esc(v)}">${esc(k)}</span>`).join('')}</div>
        <div class="svc-dots">${['Sysvol', 'Netlogon', 'DnsOK'].map((k) => `<span class="${d[k] ? '' : 'bad'}">${k === 'DnsOK' ? 'DNS test' : k + ' share'}</span>`).join('')}</div>
        ${(d.FSMO || []).length ? `<div style="font-size:12px"><span class="muted">FSMO</span> ${esc(d.FSMO.join(', '))}</div>` : ''}
        ${(d.Problems || []).length ? `<div style="font-size:12px;color:var(--crit-ink)">${esc(d.Problems.join('; '))}</div>` : ''}</div>`).join('')}</div>
      <div class="grid g-1-2">
        ${MC.panel('Replication matrix', 'inbound to row from column · minutes since last success', `<div style="overflow-x:auto"><table class="repl"><thead><tr><th></th>${names.map((n) => `<th scope="col">${esc(n)}</th>`).join('')}</tr></thead><tbody>${names.map((s) => `<tr><th scope="row">${esc(s)}</th>${names.map((p) => cell(s, p)).join('')}</tr>`).join('')}</tbody></table></div>`, { act: `<button class="btn sm" ${MC.runAttr('mon.ad.replication', { Force: true })}>Force sync…</button>` })}
        ${MC.panel('Replication links', '', '<div id="rt"></div>')}
      </div>`;
    MC.table($('#rt'), rep, [{ key: 'Server', label: 'Destination' }, { key: 'Partner', label: 'Source' }, { key: 'Partition', label: 'Partition', html: (r) => `<span class="mono" style="font-size:11.5px">${esc(r.Partition)}</span>` }, { key: 'MinutesSinceSuccess', label: 'Min since success', n: true }, { key: 'ConsecutiveFailures', label: 'Failures', n: true }, { key: 'LastResult', label: 'Result', n: true }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }], { sort: 'ConsecutiveFailures', limit: 12, name: 'ad-replication' });
  }
  function idUsers(el, q) {
    const u = MC.data('ad.users');
    const en = u.filter((x) => x.Enabled);
    const depts = Object.entries(u.reduce((a, x) => ((a[x.Department || 'None'] = (a[x.Department || 'None'] || 0) + 1), a), {})).sort((a, b) => b[1] - a[1]);
    el.innerHTML = `
      <div class="kpis">${MC.kpi('Users', u.length, en.length + ' enabled')}${MC.kpi('Locked out', u.filter((x) => x.LockedOut).length, '', { alert: u.some((x) => x.LockedOut) })}${MC.kpi('Password expired', u.filter((x) => x.PasswordExpired).length, '')}${MC.kpi('Never expires', u.filter((x) => x.PasswordNeverExpires).length, 'password policy exceptions')}${MC.kpi('Stale (90 d)', u.filter((x) => x.Stale).length, 'no recent sign-in')}${MC.kpi('Privileged', u.filter((x) => x.Privileged).length, 'admin group members')}</div>
      <div class="grid g-1-2">
        ${MC.panel('Users by department', '', C.barList(depts.slice(0, 10).map(([d, n]) => ({ label: d, value: n, text: n, color: '--s1' })), {}))}
        ${MC.panel('Password age', 'enabled accounts', '<div id="pwCols"></div>')}
      </div>
      ${MC.panel('Accounts', '', '<div id="ut"></div>', { act: `<button class="btn sm" ${MC.runAttr('aud.lockout', { Days: 1 })}>Lockout investigation…</button>` })}`;
    const bands = [[0, 30, '0–30'], [30, 60, '31–60'], [60, 90, '61–90'], [90, 180, '91–180'], [180, 365, '181–365'], [365, 1e9, '365+']];
    C.columns($('#pwCols'), bands.map(([a, b, l]) => ({ label: l, title: l + ' days', values: { n: en.filter((x) => x.PasswordAgeDays >= a && x.PasswordAgeDays < b && !x.PasswordNeverExpires).length, ne: en.filter((x) => x.PasswordAgeDays >= a && x.PasswordAgeDays < b && x.PasswordNeverExpires).length } })), [{ key: 'n', name: 'Normal', color: '--s1' }, { key: 'ne', name: 'Never expires', color: '--s3' }], { height: 170 });
    MC.table($('#ut'), u, [
      { key: 'SamAccountName', label: 'Account', html: (r) => `<span class="mono">${esc(r.SamAccountName)}</span>` }, { key: 'DisplayName', label: 'Name' }, { key: 'Department', label: 'Department' }, { key: 'Title', label: 'Title' },
      { key: 'State', label: 'State', val: (r) => (r.LockedOut ? 'Locked' : !r.Enabled ? 'Disabled' : r.PasswordExpired ? 'Expired' : 'Active'), html: (r) => (r.LockedOut ? pill('Warning', 'Locked out') : !r.Enabled ? pill('Unknown', 'Disabled') : r.PasswordExpired ? pill('Warning', 'Pwd expired') : pill('OK', 'Active')) },
      { key: 'PasswordAgeDays', label: 'Pwd age d', n: true }, { key: 'LastLogonDate', label: 'Last sign-in', html: (r) => ago(r.LastLogonDate) },
      { key: 'Privileged', label: 'Admin', html: (r) => (r.Privileged ? '<span class="risk-tag high">admin</span>' : '') },
      { key: 'act', label: '', noCsv: true, html: (r) => (r.LockedOut ? `<button class="btn sm ghost" ${MC.runAttr('aud.lockout', { UserName: r.SamAccountName, Days: 1 })}>Why locked?</button>` : '') },
    ], { q: q || '', sort: 'State', dir: 1, name: 'ad-users' });
  }
  function idGroups(el) {
    const g = MC.data('ad.groups');
    const priv = g.filter((x) => x.Privileged);
    const byGroup = Object.entries(priv.reduce((a, x) => ((a[x.Group] = (a[x.Group] || 0) + 1), a), {})).sort((a, b) => b[1] - a[1]);
    const recent = MC.data('audit.events').filter((e) => e.EventSet === 'GroupMemberAdded' && e.Privileged);
    el.innerHTML = `
      <div class="grid g-1-2">${MC.panel('Members per privileged group', '', C.barList(byGroup.map(([k, n]) => ({ label: k, value: n, text: n, color: '--s4' })), {}))}
      ${MC.panel('Recent privileged additions', 'from the audit trail', recent.length ? recent.map((e) => `<div class="insight Critical">${sevIcon('Critical')}<div><span class="area">${dt(e.Time)} · ${esc(e.Server)}</span><b>${esc(String(e.Target).replace(/^CN=([^,]+).*/, '$1'))} added to ${esc(e.Group)}</b><p>By ${esc(e.Actor)}</p></div><span></span></div>`).join('') : '<div class="muted">No privileged additions in the audit window.</div>')}</div>
      ${MC.panel('Group membership', g.length + ' memberships in watched groups', '<div id="gt"></div>')}`;
    MC.table($('#gt'), g, [{ key: 'Group', label: 'Group' }, { key: 'Member', label: 'Member', cls: 'mono' }, { key: 'MemberType', label: 'Type' }, { key: 'Scope', label: 'Scope' }, { key: 'Privileged', label: '', html: (r) => (r.Privileged ? '<span class="risk-tag high">privileged</span>' : '') }], { sort: 'Group', dir: 1, name: 'ad-groups' });
  }
  function idComputers(el) {
    const c = MC.data('ad.computers');
    const os = Object.entries(c.reduce((a, x) => ((a[x.OperatingSystem || 'Unknown'] = (a[x.OperatingSystem || 'Unknown'] || 0) + 1), a), {})).sort((a, b) => b[1] - a[1]);
    el.innerHTML = `
      <div class="kpis">${MC.kpi('Computer accounts', c.length, c.filter((x) => x.Enabled).length + ' enabled')}${MC.kpi('Servers', c.filter((x) => x.Role === 'Server').length, '')}${MC.kpi('Workstations', c.filter((x) => x.Role !== 'Server').length, '')}${MC.kpi('Stale', c.filter((x) => x.Stale).length, 'no logon in 90 days', { alert: c.filter((x) => x.Stale).length > 10 })}</div>
      <div class="grid g-1-2">${MC.panel('Operating systems', '', '<div id="osD"></div>')}${MC.panel('Accounts', '', '<div id="ct"></div>')}</div>`;
    C.donut($('#osD'), os.slice(0, 4).map(([k, n], i) => ({ label: k.replace('Windows ', 'Win ').replace(' Enterprise', ' Ent.').replace(' Standard', ' Std'), value: n, color: C.SERIES[i] })).concat(os.length > 4 ? [{ label: 'Other', value: sum(os.slice(4).map((x) => x[1])), color: '--muted' }] : []), { centerLabel: 'accounts' });
    MC.table($('#ct'), c, [{ key: 'Name', label: 'Name', html: (r) => `<a href="#" data-host="${esc(r.Name)}">${esc(r.Name)}</a>` }, { key: 'OperatingSystem', label: 'OS' }, { key: 'IPv4Address', label: 'IP', cls: 'mono' }, { key: 'LastLogonDate', label: 'Last logon', html: (r) => ago(r.LastLogonDate) }, { key: 'Stale', label: 'Stale', html: (r) => (r.Stale ? pill('Warning', 'stale') : '') }, { key: 'OU', label: 'OU' }], { sort: 'Stale', name: 'ad-computers' });
  }

  function idReplication(el) {
    const rep = MC.data('ad.replication'), dcs = MC.data('ad.health');
    const names = dcs.map((d) => d.Name);
    const fail = rep.filter((x) => x.Status === 'Critical');
    const cell = (s, p) => {
      if (s === p) return '<td class="self"></td>';
      const links = rep.filter((x) => x.Server === s && x.Partner === p);
      if (!links.length) return '<td class="muted">·</td>';
      const bad = links.some((x) => x.Status === 'Critical');
      const m = Math.max(...links.map((x) => x.MinutesSinceSuccess));
      return `<td class="${bad ? 'Critical' : 'OK'}" title="${esc(p)} → ${esc(s)}: last success ${m} min ago${bad ? ', error ' + links.find((x) => x.Status === 'Critical').LastResult : ''}">${bad ? '✕ ' + Math.round(m / 60) + 'h' : m + 'm'}</td>`;
    };
    const lag = names.map((n) => ({ label: n, value: Math.max(0, ...rep.filter((x) => x.Server === n).map((x) => x.MinutesSinceSuccess)), status: rep.some((x) => x.Server === n && x.Status === 'Critical') ? 'Critical' : null }));
    const parts = Object.entries(rep.reduce((a, x) => { const k = x.Partition.split(',')[0].replace(/^(CN|DC)=/, ''); a[k] = a[k] || { ok: 0, bad: 0 }; a[k][x.Status === 'Critical' ? 'bad' : 'ok']++; return a; }, {}));
    el.innerHTML = `
      <div class="kpis">${MC.kpi('Replication links', rep.length, names.length + ' domain controllers')}${MC.kpi('Failing', fail.length, fail.length ? [...new Set(fail.map((f) => f.Partner + ' → ' + f.Server))].join(', ') : 'all links healthy', { alert: fail.length > 0 })}${MC.kpi('Worst lag', fmt(Math.max(0, ...rep.map((x) => x.MinutesSinceSuccess)) / 60, 1) + ' h', 'since last success')}${MC.kpi('Consecutive failures', sum(rep.map((x) => x.ConsecutiveFailures)), '')}</div>
      <div class="grid g-1-2">
        ${MC.panel('Replication matrix', 'inbound to row from column · minutes since last success', `<div style="overflow-x:auto"><table class="repl"><thead><tr><th></th>${names.map((n) => `<th scope="col">${esc(n)}</th>`).join('')}</tr></thead><tbody>${names.map((s) => `<tr><th scope="row">${esc(s)}</th>${names.map((p) => cell(s, p)).join('')}</tr>`).join('')}</tbody></table></div>`, { act: `<button class="btn sm" ${MC.runAttr('mon.ad.replication', { Force: true })}>Force sync…</button>` })}
        ${MC.panel('Oldest inbound success per DC', 'minutes', C.barList(lag, { unit: ' min' }))}
      </div>
      <div class="grid g-1-2">
        ${MC.panel('Links per partition', '', '<div id="rpParts"></div>')}
        ${MC.panel('Replication links', '', '<div id="rt"></div>')}
      </div>`;
    C.columns($('#rpParts'), parts.map(([k, v]) => ({ label: k, values: v })), [{ key: 'ok', name: 'Healthy', color: '--ok' }, { key: 'bad', name: 'Failing', color: '--crit' }], { height: 170 });
    MC.table($('#rt'), rep, [{ key: 'Server', label: 'Destination' }, { key: 'Partner', label: 'Source' }, { key: 'Partition', label: 'Partition', html: (r) => `<span class="mono" style="font-size:11.5px">${esc(r.Partition)}</span>` }, { key: 'MinutesSinceSuccess', label: 'Min since success', n: true }, { key: 'ConsecutiveFailures', label: 'Failures', n: true }, { key: 'LastResult', label: 'Result', n: true }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }], { sort: 'ConsecutiveFailures', limit: 12, name: 'ad-replication' });
  }

  // site topology: sites on a circle, site links as edges labelled with cost and interval
  function siteMap(sites, links) {
    const W = 560, H = 300, cx = W / 2, cy = H / 2, R = Math.min(cx, cy) - 46;
    const pos = Object.fromEntries(sites.map((s, i) => { const a = -Math.PI / 2 + (i / sites.length) * 2 * Math.PI; return [s.Name, [cx + R * Math.cos(a) * 1.5, cy + R * Math.sin(a)]]; }));
    const edges = links.filter((l) => (l.Sites || []).length >= 2).map((l) => {
      const [a, b] = l.Sites.map((s) => pos[s]); if (!a || !b) return '';
      const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
      return `<g><title>${esc(l.Name)}: cost ${l.Cost}, every ${l.IntervalMinutes} min${l.ChangeNotification ? ', change notification on' : ''}</title><line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="var(--s1)" stroke-width="2" stroke-dasharray="${l.Scheduled ? '5 4' : ''}"/><rect x="${mx - 38}" y="${my - 10}" width="76" height="20" rx="10" fill="var(--surface)" stroke="var(--line-strong)"/><text x="${mx}" y="${my + 4}" text-anchor="middle" style="font-size:11px;fill:var(--text-2)">${l.Cost} · ${l.IntervalMinutes}m</text></g>`;
    }).join('');
    const nodes = sites.map((s) => {
      const [x, y] = pos[s.Name], st = s.Status === 'OK' ? '--ok' : s.Status === 'Critical' ? '--crit' : '--warn';
      return `<g><title>${esc(s.Name)}: ${(s.DomainControllers || []).length} DCs, ${(s.Subnets || []).length} subnets${(s.Problems || []).length ? ' · ' + esc(s.Problems.join('; ')) : ''}</title><rect x="${x - 66}" y="${y - 24}" width="132" height="48" rx="10" fill="var(--surface-2)" stroke="var(${st})" stroke-width="2"/><text x="${x}" y="${y - 4}" text-anchor="middle" style="font-size:13px;font-weight:600;fill:var(--text)">${esc(s.Name)}</text><text x="${x}" y="${y + 13}" text-anchor="middle" style="font-size:11px;fill:var(--muted)">${(s.DomainControllers || []).join(', ') || 'no DC'}</text></g>`;
    }).join('');
    return `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="Site topology: ${sites.length} sites, ${links.length} site links" class="mc-chart">${edges}${nodes}</svg><div class="mc-legend"><span><i style="background:var(--s1)"></i>Site link (cost · interval)</span><span><i style="background:var(--ok)"></i>Site healthy</span><span><i style="background:var(--warn)"></i>Site needs attention</span></div>`;
  }
  function idSites(el) {
    const all = MC.data('ad.sites');
    const sites = all.filter((r) => r.Kind === 'site'), links = all.filter((r) => r.Kind === 'link'), subnets = all.filter((r) => r.Kind === 'subnet'), bridges = all.filter((r) => r.Kind === 'bridge');
    if (!all.length) { el.innerHTML = MC.panel('Sites and site links', '', `<div class="muted">No data yet. Run the AD sites collector.</div><p><button class="btn" ${MC.runAttr('mon.ad.sites', {})}>Collect now…</button></p>`); return; }
    const orphan = subnets.filter((s) => !s.Site);
    el.innerHTML = `
      <div class="kpis">${MC.kpi('Sites', sites.length, sum(sites.map((s) => (s.DomainControllers || []).length)) + ' domain controllers')}${MC.kpi('Site links', links.length, bridges.length + ' bridge(s)')}${MC.kpi('Subnets', subnets.length, orphan.length + ' not in a site', { alert: orphan.length > 0 })}${MC.kpi('Sites without a DC', sites.filter((s) => !(s.DomainControllers || []).length).length, 'clients authenticate over the WAN', { alert: sites.some((s) => !(s.DomainControllers || []).length) })}</div>
      <div class="grid g-2-1">
        ${MC.panel('Site topology', 'hover a link or site for details', siteMap(sites, links), { act: `<button class="btn sm" ${MC.runAttr('mon.ad.sites', {})}>Collect now…</button>` })}
        ${MC.panel('Site link cost', 'lower cost is preferred; interval in minutes', C.barList(links.map((l) => ({ label: l.Name, sub: (l.Sites || []).join(' ↔ '), value: l.Cost, text: l.Cost + ' · ' + l.IntervalMinutes + ' min' })), {}))}
      </div>
      ${MC.panel('Sites', '', '<div id="stT"></div>')}
      <div class="grid g2">${MC.panel('Site links', '', '<div id="slT"></div>')}${MC.panel('Subnets', '', '<div id="snT"></div>')}</div>`;
    MC.table($('#stT'), sites, [{ key: 'Name', label: 'Site' }, { key: 'Description', label: 'Description' }, { key: 'DomainControllers', label: 'Domain controllers', val: (r) => (r.DomainControllers || []).join(', ') }, { key: 'GlobalCatalogs', label: 'GCs', n: true }, { key: 'ISTG', label: 'ISTG' }, { key: 'Subnets', label: 'Subnets', val: (r) => (r.Subnets || []).join(', '), cls: 'mono' }, { key: 'SiteLinks', label: 'Site links', val: (r) => (r.SiteLinks || []).join(', ') }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status, (r.Problems || []).join('; ') || r.Status) }], { sort: 'Status', name: 'ad-sites' });
    MC.table($('#slT'), links, [{ key: 'Name', label: 'Link' }, { key: 'Sites', label: 'Sites', val: (r) => (r.Sites || []).join(' ↔ '), html: (r) => `<span style="white-space:nowrap">${esc((r.Sites || []).join(' ↔ '))}</span>` }, { key: 'Cost', label: 'Cost', n: true }, { key: 'IntervalMinutes', label: 'Every min', n: true }, { key: 'ChangeNotification', label: 'Change notify', val: (r) => (r.ChangeNotification ? 'On' : 'Off'), html: (r) => (r.ChangeNotification ? 'On' : 'Off') }, { key: 'Scheduled', label: 'Schedule', val: (r) => (r.Scheduled ? 'Restricted' : 'Always'), html: (r) => (r.Scheduled ? 'Restricted' : 'Always') }], { sort: 'Cost', dir: 1, name: 'ad-site-links' });
    MC.table($('#snT'), subnets, [{ key: 'Name', label: 'Subnet', cls: 'mono' }, { key: 'Site', label: 'Site', html: (r) => (r.Site ? esc(r.Site) : pill('Warning', 'No site')) }, { key: 'Location', label: 'Location' }, { key: 'Description', label: 'Description' }], { sort: 'Site', dir: 1, name: 'ad-subnets' });
  }

  function idServices(el) {
    const dcs = MC.data('ad.health');
    const svcs = [...new Set(dcs.flatMap((d) => Object.keys(d.Services || {})))];
    const SVC = { NTDS: 'AD Domain Services', DNS: 'DNS Server', DFSR: 'DFS Replication (SYSVOL)', Netlogon: 'Netlogon', KDC: 'Kerberos KDC', IsmServ: 'Intersite Messaging', W32Time: 'Windows Time', ADWS: 'AD Web Services' };
    const down = dcs.flatMap((d) => Object.entries(d.Services || {}).filter(([, v]) => v !== 'Running').map(([k]) => ({ dc: d.Name, svc: k })));
    const fsmo = ((MC.ds['ad.health'] || {}).summary || {}).fsmo || {};
    el.innerHTML = `
      <div class="kpis">${MC.kpi('AD services', svcs.length * dcs.length, svcs.length + ' services × ' + dcs.length + ' DCs')}${MC.kpi('Not running', down.length, down.map((d) => d.svc + ' on ' + d.dc).join(', ') || 'all running', { alert: down.length > 0 })}${MC.kpi('SYSVOL / NETLOGON shared', dcs.filter((d) => d.Sysvol && d.Netlogon).length + ' / ' + dcs.length, '')}${MC.kpi('Worst time offset', fmt(Math.max(0, ...dcs.map((d) => Math.abs(d.TimeOffsetSec || 0))), 2) + ' s', 'Kerberos allows 300 s', { alert: dcs.some((d) => Math.abs(d.TimeOffsetSec || 0) > 1) })}</div>
      ${MC.panel('Services per domain controller', 'running · stopped', `<div style="overflow-x:auto"><table class="repl svc"><thead><tr><th></th>${dcs.map((d) => `<th scope="col">${esc(d.Name)}</th>`).join('')}</tr></thead><tbody>${svcs.map((s) => `<tr><th scope="row" style="text-align:left">${esc(SVC[s] || s)} <span class="muted mono" style="font-size:11px">${esc(s)}</span></th>${dcs.map((d) => { const v = (d.Services || {})[s]; return v ? `<td class="${v === 'Running' ? 'OK' : 'Critical'}">${v === 'Running' ? '✓' : '✕ ' + esc(v)}</td>` : '<td class="muted">·</td>'; }).join('')}</tr>`).join('')}
        <tr><th scope="row" style="text-align:left">SYSVOL and NETLOGON shares</th>${dcs.map((d) => `<td class="${d.Sysvol && d.Netlogon ? 'OK' : 'Critical'}">${d.Sysvol && d.Netlogon ? '✓' : '✕'}</td>`).join('')}</tr>
        <tr><th scope="row" style="text-align:left">DNS registration test</th>${dcs.map((d) => `<td class="${d.DnsOK ? 'OK' : 'Critical'}">${d.DnsOK ? '✓' : '✕'}</td>`).join('')}</tr></tbody></table></div>`, { act: down.length ? `<button class="btn sm" ${MC.runAttr('act.service', { ComputerName: down[0].dc, Name: down[0].svc, Action: 'Start' })}>Start ${esc(down[0].svc)} on ${esc(down[0].dc)}…</button>` : '' })}
      <div class="grid g-1-2">
        ${MC.panel('Time offset from the PDC emulator', 'seconds', C.barList(dcs.map((d) => ({ label: d.Name, value: Math.abs(d.TimeOffsetSec || 0), text: fmt(d.TimeOffsetSec, 3) + ' s', status: Math.abs(d.TimeOffsetSec || 0) > 1 ? 'Warning' : 'OK' })), { max: Math.max(1, ...dcs.map((d) => Math.abs(d.TimeOffsetSec || 0))) }))}
        ${MC.panel('FSMO role holders', '', `<table class="tbl"><tbody>${Object.entries(fsmo).map(([k, v]) => `<tr><td>${esc(k.replace(/([a-z])([A-Z])/g, '$1 $2'))}</td><td class="mono">${esc(String(v).split('.')[0].toUpperCase())}</td></tr>`).join('') || '<tr><td class="muted">Not collected yet</td></tr>'}</tbody></table>`)}
      </div>`;
  }

  function idGpo(el) {
    const g = MC.data('ad.gpo');
    if (!g.length) { el.innerHTML = MC.panel('Group Policy', '', `<div class="muted">No data yet.</div><p><button class="btn" ${MC.runAttr('mon.ad.gpo', {})}>Collect now…</button></p>`); return; }
    const now = Date.now(), recent = g.filter((x) => now - Date.parse(x.Modified) < 30 * 864e5);
    const issue = (r) => (r.VersionMismatch ? ['Critical', 'AD and SYSVOL versions differ'] : r.Status === 'AllSettingsDisabled' ? ['Warning', 'All settings disabled'] : !r.Links ? ['Warning', 'Not linked'] : r.Empty ? ['Warning', 'Empty'] : ['OK', 'Healthy']);
    const byOu = Object.entries(g.flatMap((x) => x.LinkedTo || []).reduce((a, k) => ((a[k] = (a[k] || 0) + 1), a), {})).sort((a, b) => b[1] - a[1]);
    const byPrefix = Object.entries(g.reduce((a, x) => { const k = (x.Name.match(/^([A-Z]+) - /) || [, 'Default'])[1]; a[k] = (a[k] || 0) + 1; return a; }, {}));
    el.innerHTML = `
      <div class="kpis">${MC.kpi('GPOs', g.length, g.filter((x) => x.Links).length + ' linked')}${MC.kpi('Version mismatch', g.filter((x) => x.VersionMismatch).length, 'AD vs SYSVOL', { alert: g.some((x) => x.VersionMismatch) })}${MC.kpi('Unlinked', g.filter((x) => !x.Links).length, 'apply to nothing')}${MC.kpi('Empty', g.filter((x) => x.Empty).length, '')}${MC.kpi('Disabled', g.filter((x) => x.Status === 'AllSettingsDisabled').length, '')}${MC.kpi('Changed in 30 days', recent.length, '')}</div>
      <div class="grid g3">
        ${MC.panel('Health', '', '<div id="gpD"></div>')}
        ${MC.panel('Links per OU', '', C.barList(byOu.slice(0, 8).map(([k, n]) => ({ label: k.split('/').slice(1).join('/') || k, sub: k.split('/')[0], value: n, text: n })), {}))}
        ${MC.panel('GPOs by purpose', 'from the name prefix', C.barList(byPrefix.sort((a, b) => b[1] - a[1]).map(([k, n]) => ({ label: { SEC: 'Security', USR: 'User settings', CMP: 'Computer settings', WSUS: 'Updates', TEST: 'Test', Default: 'Default policies' }[k] || k, value: n, text: n, color: '--s2' })), {}))}
      </div>
      ${MC.panel('Group Policy objects', '', '<div id="gpT"></div>', { act: `<button class="btn sm" ${MC.runAttr('mon.ad.gpo', {})}>Collect now…</button> <button class="btn sm" ${MC.runAttr('act.client', { Operation: ['GpUpdate'] })}>Run gpupdate…</button>` })}`;
    const h = g.reduce((a, r) => { const s = issue(r)[0]; a[s] = (a[s] || 0) + 1; return a; }, {});
    C.donut($('#gpD'), [['OK', 'Healthy', '--ok'], ['Warning', 'Needs attention', '--warn'], ['Critical', 'Version mismatch', '--crit']].filter(([k]) => h[k]).map(([k, l, c]) => ({ label: l, value: h[k], color: c })), { centerLabel: 'GPOs' });
    MC.table($('#gpT'), g, [{ key: 'Name', label: 'GPO' }, { key: 'Status', label: 'Settings', val: (r) => r.Status.replace('AllSettings', 'All ').replace('Enabled', 'enabled').replace('Disabled', 'disabled') }, { key: 'Links', label: 'Links', n: true }, { key: 'LinkedTo', label: 'Linked to', val: (r) => (r.LinkedTo || []).join(', ') }, { key: 'Versions', label: 'Versions (AD/SYSVOL)', cls: 'mono' }, { key: 'Modified', label: 'Changed', html: (r) => ago(r.Modified), val: (r) => r.Modified }, { key: 'health', label: 'Health', val: (r) => issue(r)[1], html: (r) => pill(issue(r)[0], issue(r)[1]) }], { sort: 'health', name: 'ad-gpo' });
  }

  function idWorkstations(el, q) {
    const inv = MC.data('inventory.workstations');
    const ad = Object.fromEntries(MC.data('ad.computers').filter((c) => c.Role !== 'Server').map((c) => [c.Name, c]));
    const rows = inv.map((w) => Object.assign({}, w, { Stale: (ad[w.Name] || {}).Stale, OU: (ad[w.Name] || {}).OU, LastLogonDate: (ad[w.Name] || {}).LastLogonDate }));
    const count = (f) => Object.entries(rows.reduce((a, x) => { const k = f(x) || 'Unknown'; a[k] = (a[k] || 0) + 1; return a; }, {})).sort((a, b) => b[1] - a[1]);
    const os = count((x) => x.OperatingSystem), sites = count((x) => x.ADSite), models = count((x) => x.Manufacturer + ' ' + x.Model);
    const eol = rows.filter((x) => /Windows (7|8|10)/.test(x.OperatingSystem));
    const online = rows.filter((x) => x.Online);
    el.innerHTML = `
      <div class="kpis">${MC.kpi('Workstations', rows.length, Object.keys(ad).length + ' computer accounts')}${MC.kpi('Online now', online.length, pct(online.length, rows.length) + '% of the fleet')}${MC.kpi('Windows 11', pct(rows.filter((x) => /Windows 11/.test(x.OperatingSystem)).length, rows.length) + '%', '')}${MC.kpi('Out of support OS', eol.length, 'Windows 7, 8 and 10', { alert: eol.length > 0 })}${MC.kpi('No TPM', rows.filter((x) => !x.TPMEnabled).length, 'cannot use BitLocker / Windows 11')}${MC.kpi('Stale accounts', rows.filter((x) => x.Stale).length, 'no logon in 90 days')}</div>
      <div class="grid g3">
        ${MC.panel('Operating systems', '', '<div id="wsOs"></div>')}
        ${MC.panel('Workstations per site', '', C.barList(sites.map(([k, n]) => ({ label: k, value: n, text: n + ' · ' + online.filter((x) => x.ADSite === k).length + ' online' })), {}))}
        ${MC.panel('Top models', '', C.barList(models.slice(0, 6).map(([k, n]) => ({ label: k, value: n, text: n, color: '--s2' })), { compact: true }))}
      </div>
      <div class="grid g-1-2">
        ${MC.panel('Memory', 'GB per workstation', '<div id="wsRam"></div>')}
        ${MC.panel('Uptime', 'days since last restart', '<div id="wsUp"></div>')}
      </div>
      ${MC.panel('Workstations', 'inventory joined with the AD computer account', '<div id="wsT"></div>', { act: `<button class="btn sm" ${MC.runAttr('inv.workstations', {})}>Collect now…</button>` })}`;
    C.donut($('#wsOs'), os.slice(0, 3).map(([k, n], i) => ({ label: k.replace('Windows ', 'Win ').replace(' Enterprise', ' Ent.').replace(' Professional', ' Pro'), value: n, color: C.SERIES[i] })).concat(os.length > 3 ? [{ label: 'Other', value: sum(os.slice(3).map((x) => x[1])), color: '--muted' }] : []), { centerLabel: 'workstations' });
    const ram = [...new Set(rows.map((x) => x.RAMGB))].sort((a, b) => a - b);
    C.columns($('#wsRam'), ram.map((g) => ({ label: g + ' GB', values: { on: online.filter((x) => x.RAMGB === g).length, off: rows.filter((x) => x.RAMGB === g && !x.Online).length } })), [{ key: 'on', name: 'Online', color: '--s1' }, { key: 'off', name: 'Offline', color: '--s3' }], { height: 160 });
    const ub = [[0, 1, '< 1'], [1, 3, '1–3'], [3, 7, '3–7'], [7, 14, '7–14'], [14, 1e9, '14+']];
    C.columns($('#wsUp'), ub.map(([a, b, l]) => ({ label: l, title: l + ' days', values: { n: rows.filter((x) => x.UptimeDays >= a && x.UptimeDays < b).length } })), [{ key: 'n', name: 'Workstations', color: '--s1' }], { height: 160 });
    MC.table($('#wsT'), rows, [
      { key: 'Name', label: 'Name', html: (r) => `<a href="#" data-host="${esc(r.Name)}">${esc(r.Name)}</a>` }, { key: 'Online', label: 'State', val: (r) => (r.Online ? 'Online' : 'Offline'), html: (r) => pill(r.Online ? 'OK' : 'Offline', r.Online ? 'Online' : 'Offline') },
      { key: 'OperatingSystem', label: 'OS', html: (r) => (/Windows (7|8|10)/.test(r.OperatingSystem) ? `<span style="color:var(--warn-ink)">${esc(r.OperatingSystem)}</span>` : esc(r.OperatingSystem)) }, { key: 'Model', label: 'Model', val: (r) => r.Manufacturer + ' ' + r.Model },
      { key: 'ADSite', label: 'Site' }, { key: 'LoggedOnUser', label: 'User', cls: 'mono' }, { key: 'CPUCores', label: 'Cores', n: true }, { key: 'RAMGB', label: 'RAM GB', n: true }, { key: 'TPMEnabled', label: 'TPM', val: (r) => (r.TPMEnabled ? 'Yes' : 'No') },
      { key: 'UptimeDays', label: 'Uptime d', n: true, html: (r) => fmt(r.UptimeDays, 1) }, { key: 'LastSeen', label: 'Last seen', html: (r) => ago(r.LastSeen), val: (r) => r.LastSeen }, { key: 'Stale', label: 'AD', html: (r) => (r.Stale ? pill('Warning', 'stale') : '') },
      { key: 'act', label: '', noCsv: true, html: (r) => (r.Online ? `<button class="btn sm ghost" ${MC.runAttr('act.client', { ComputerName: r.Name, Operation: ['GpUpdate'] })}>gpupdate</button>` : '') },
    ], { q: q || '', sort: 'Online', name: 'ad-workstations' });
  }

  // ================================================================== NETWORK
  V.network = {
    title: 'Network',
    crumb: () => MC.data('network.discovery').length + ' devices discovered · ' + MC.data('network.dhcp').length + ' DHCP scopes',
    render(el) {
      const d = MC.data('network.discovery');
      const nets = MC.model.resources.filter((r) => r.kind === 'network');
      const groups = Object.entries(nets.reduce((a, r) => ((a[r.group] = (a[r.group] || 0) + 1), a), {}));
      const subnets = Object.entries(d.reduce((a, x) => ((a[x.Subnet] = (a[x.Subnet] || 0) + 1), a), {}));
      const ports = {};
      d.forEach((x) => (x.OpenPorts || []).forEach((p) => (ports[p] = (ports[p] || 0) + 1)));
      el.innerHTML = `
        <div class="kpis">${MC.kpi('Devices discovered', d.length, subnets.length + ' subnets swept')}${MC.kpi('Network devices', nets.filter((r) => r.group !== 'Unknown').length, groups.map(([g, n]) => n + ' ' + g.toLowerCase()).slice(0, 2).join(' · '))}${MC.kpi('Unidentified', d.filter((x) => x.DeviceClass === 'Unknown').length, 'no DNS name or known ports', { alert: d.some((x) => x.DeviceClass === 'Unknown') })}${MC.kpi('DHCP use', pct(sum(MC.data('network.dhcp').map((x) => x.InUse)), sum(MC.data('network.dhcp').map((x) => x.InUse + x.Free))) + '%', 'all scopes', { href: '#/monitoring/dhcp' })}</div>
        <div class="grid g3">
          ${MC.panel('Device classes', '', '<div id="clsD"></div>')}
          ${MC.panel('Open ports seen', 'devices per port', C.barList(Object.entries(ports).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([p, n]) => ({ label: 'TCP ' + p, sub: { 22: 'SSH', 23: 'Telnet', 80: 'HTTP', 443: 'HTTPS', 161: 'SNMP', 445: 'SMB', 3389: 'RDP', 9100: 'printing', 8443: 'admin UI' }[p] || '', value: n, text: n, status: p === '23' ? 'Warning' : null, color: '--s1' })), { compact: true }))}
          ${MC.panel('Network tools', 'run from the console server', `<form id="ntForm" class="grid" style="gap:8px"><select class="input" id="ntTest"><option value="dns">DNS lookup</option><option value="Port">Port test</option><option value="TraceRoute">Trace route</option><option value="GeoIP">Public IP / GeoIP</option><option value="InternetSpeed">Internet speed</option></select><input class="input" id="ntTarget" placeholder="Host name or IP"><input class="input" id="ntPort" type="number" placeholder="Port (port test)" min="1" max="65535"><button class="btn primary" type="submit">${icon('play', 'sev-ico')}Run</button></form>`)}
        </div>
        ${MC.panel('Network devices (SNMP engine)', MC.data('network.devices').length + ' devices read · interfaces down while enabled are flagged', '<div id="nsT"></div>', { act: `<a class="btn sm ghost" href="#/engines/mon.network.devices">Engine</a><button class="btn sm" ${MC.runAttr('mon.network.devices', {})}>Collect now…</button>` })}
        ${MC.panel('Discovered devices', 'ping sweep, reverse DNS, ARP and port fingerprint', '<div id="nt"></div>', { act: `<button class="btn sm" ${MC.runAttr('mon.network.discovery', {})}>Sweep now…</button>` })}`;
      C.donut($('#clsD'), groups.sort((a, b) => b[1] - a[1]).slice(0, 4).map(([g, n], i) => ({ label: g, value: n, color: g === 'Unknown' ? '--warn' : C.SERIES[i] })), { centerLabel: 'devices' });
      $('#ntForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const t = $('#ntTest').value, target = $('#ntTarget').value.trim(), port = $('#ntPort').value;
        if (t === 'dns') MC.runDialog('act.dns', { Name: target });
        else MC.runDialog('act.nettest', Object.assign({ Test: t }, target ? { Target: target } : {}, port ? { Port: +port } : {}));
      });
      MC.table($('#nsT'), MC.data('network.devices'), [
        { key: 'Name', label: 'Device', html: (r) => `<a href="#" data-host="${esc(r.Name)}">${esc(r.SysName || r.Name)}</a><br><span class="muted mono" style="font-size:11.5px">${esc(r.Name)}</span>` },
        { key: 'Description', label: 'Model / OS', html: (r) => `<span style="font-size:12.5px">${esc(String(r.Description || '').slice(0, 80))}</span>` },
        { key: 'Location', label: 'Location' }, { key: 'UptimeDays', label: 'Up days', n: true, html: (r) => (r.UptimeDays == null ? '–' : fmt(r.UptimeDays, 0)) },
        { key: 'Interfaces', label: 'Ports', n: true }, { key: 'Up', label: 'Up', n: true }, { key: 'DownEnabled', label: 'Down (enabled)', n: true, html: (r) => (r.DownEnabled ? pill('Warning', String(r.DownEnabled)) : '0') },
        { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }, { key: 'Message', label: 'Detail', html: (r) => `<span style="font-size:12.5px" title="${esc(r.DownList || '')}">${esc(r.Message || '')}</span>` },
      ], { sort: 'Status', name: 'network-devices', empty: 'No network device read yet. Add switches, routers or firewalls with an SNMP credential; the network devices engine reads them every 10 minutes.' });
      MC.table($('#nt'), d, [
        { key: 'IPAddress', label: 'IP', html: (r) => `<a href="#" class="mono" data-res="${esc((MC.model.resources.find((x) => x.ip === r.IPAddress && !x.linked) || {}).id || '')}">${esc(r.IPAddress)}</a>`, val: (r) => r.IPAddress.split('.').map((x) => x.padStart(3, '0')).join('.') },
        { key: 'HostName', label: 'Host name' }, { key: 'DeviceClass', label: 'Class', html: (r) => (r.DeviceClass === 'Unknown' ? pill('Warning', 'Unknown') : esc(r.DeviceClass)) },
        { key: 'MAC', label: 'MAC', cls: 'mono' }, { key: 'OpenPorts', label: 'Open ports' }, { key: 'LatencyMs', label: 'Ping ms', n: true, html: (r) => fmt(r.LatencyMs) }, { key: 'Ttl', label: 'TTL', n: true }, { key: 'Site', label: 'Site' }, { key: 'Subnet', label: 'Subnet', cls: 'mono' },
      ], { sort: 'DeviceClass', dir: -1, name: 'network-discovery' });
    },
  };

  // ================================================================== LINUX
  V.linux = {
    title: 'Linux',
    crumb: () => MC.data('linux.hosts').length + ' hosts collected over SSH every 10 minutes',
    render(el) {
      const l = MC.data('linux.hosts');
      const on = l.filter((x) => x.Online !== false);
      el.innerHTML = `
        <div class="kpis">${MC.kpi('Hosts', on.length + ' / ' + l.length, 'reachable over SSH', { alert: on.length < l.length })}${MC.kpi('Average CPU', fmt(avg(on.map((x) => x.cpuPct)), 0) + '%', '')}${MC.kpi('Security updates', sum(on.map((x) => x.securityUpdates)), sum(on.map((x) => x.updates)) + ' updates in total')}${MC.kpi('Failed units', sum(on.map((x) => x.failedUnits)), 'systemd')}${MC.kpi('Oracle instances', sum(on.map((x) => (x.oracleInstances || []).length)), '')}</div>
        <div class="host-cards">${l.map((x) => `<div class="card host-card" data-res="lnx-${esc(x.Name)}" tabindex="0" role="button"><div style="display:flex;gap:8px;align-items:center"><b>${esc(x.Name)}</b><span style="margin-left:auto">${pill(x.Online === false ? 'Offline' : x.Status)}</span></div><div class="muted" style="font-size:12px">${esc(x.os || 'unreachable')}${x.kernel ? ' · ' + esc(x.kernel) : ''}</div>
          ${x.Online === false ? '<div class="muted">No SSH response in the last collection.</div>' : `<div class="gauges">${C.gauge(x.cpuPct, { label: 'CPU' })}${C.gauge(x.memUsedPct, { label: 'Memory', warn: 80, crit: 92 })}${C.gauge(x.WorstDiskPct, { label: 'Disk', warn: 80, crit: 90 })}</div><div class="muted" style="font-size:12px">load ${(x.load || []).join(' / ')} · up ${fmt(x.uptimeHours / 24, 0)} d · ${x.securityUpdates} security updates</div>`}</div>`).join('')}</div>
        ${MC.panel('Hosts', '', '<div id="lt"></div>')}`;
      MC.table($('#lt'), l, [
        { key: 'Name', label: 'Host', html: (r) => `<a href="#" data-res="lnx-${esc(r.Name)}">${esc(r.Name)}</a>` }, { key: 'os', label: 'OS' }, { key: 'cpuPct', label: 'CPU', n: true, html: (r) => minibar(r.cpuPct) }, { key: 'memUsedPct', label: 'Memory', n: true, html: (r) => minibar(r.memUsedPct, 80, 92) }, { key: 'WorstDiskPct', label: 'Disk', n: true, html: (r) => minibar(r.WorstDiskPct, 80, 90) },
        { key: 'updates', label: 'Updates', n: true }, { key: 'securityUpdates', label: 'Security', n: true }, { key: 'failedUnits', label: 'Failed units', n: true }, { key: 'machineType', label: 'Type' }, { key: 'Status', label: 'Status', html: (r) => pill(r.Online === false ? 'Offline' : r.Status) },
      ], { sort: 'cpuPct', name: 'linux-hosts' });
    },
  };
  MC.MON = MON; // shared with the Databases page (views-cloud.js)
})(typeof self !== 'undefined' ? self : this);
