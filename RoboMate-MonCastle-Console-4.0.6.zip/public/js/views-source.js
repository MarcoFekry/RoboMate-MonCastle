/*
 * RoboMate MonCastle - Monitoring pages split by where a device came from. Every page under Monitoring gets a switch:
 *   Overview | Found by engines (n) | Manually added (n)
 * "Found by engines" are devices a monitoring engine reported (a server found in Active Directory, a VM found on a host).
 * "Manually added" are devices someone added by hand, from auto-discovery or from an import. The lists use the page's own
 * scope (kind, group, roles and the engines that report the device) and link to each device.
 */
(function (root) {
  'use strict';
  const MC = root.MC;
  const { esc, pill, icon, ago, $, $$ } = MC;
  const enc = encodeURIComponent;

  const has = (a, list) => (a || []).some((x) => list.includes(x));
  const pre = (a, prefixes) => (a || []).some((x) => prefixes.some((p) => String(x).indexOf(p) === 0));
  const AD_ROLES = ['DomainControllers', 'DNS', 'DHCP', 'FileServers', 'PrintServers', 'SQL', 'IIS', 'CertificateAuthority', 'DFS', 'WSUS', 'NPS', 'RDS'];
  const AD_GROUPS = ['g:dc', 'g:ad', 'g:dns', 'g:fs', 'g:prn', 'g:sql', 'g:web', 'g:db'];
  const AD_ENGINES = ['mon.ad.', 'inv.ad.', 'mon.dns', 'mon.dhcp', 'mon.fileserver', 'mon.printers', 'mon.sql', 'mon.iis', 'mon.databases', 'aud.'];
  const WIN = (d) => ['server', 'workstation'].includes(d.kind) && !/linux/i.test(d.os || '');
  // page (or page/tab) -> which devices belong on it
  const SCOPE = {
    alarms: { label: 'devices with an open alarm', test: (d) => (d.counts || {}).Down > 0 || (d.counts || {}).Warning > 0 },
    monitoring: { label: 'Windows servers', test: (d) => WIN(d) || pre(d.foundBy, ['mon.compute', 'mon.disks', 'mon.availability', 'mon.services', 'mon.events']) },
    identity: { label: 'Active Directory and AD-integrated servers', test: (d) => d.kind === 'domain' || has(d.roles, AD_ROLES) || AD_GROUPS.includes(d.group) || pre(d.foundBy, AD_ENGINES) },
    virtualization: { label: 'hosts, clusters, datastores and VMs', test: (d) => ['host', 'cluster', 'datastore', 'vm'].includes(d.kind) || ['g:hv', 'g:vmw', 'g:ocp', 'g:ntx', 'g:cl'].includes(d.group) || has(d.roles, ['HyperV', 'Clusters']) || pre(d.foundBy, ['mon.hyperv', 'mon.vmware', 'mon.clusters', 'mon.openshift', 'mon.nutanix']) },
    'virtualization/vms': { label: 'virtual machines and the hosts that run them', test: (d) => d.kind === 'vm' || d.types.has('hv.vm') || d.types.has('vmw.vm') },
    network: { label: 'network devices', test: (d) => ['cloudfw', 'waf', 'vpn', 'network', 'firewall', 'wireless', 'loadbalancer', 'appliance', 'fcswitch', 'voip', 'ups', 'pdu', 'environment', 'camera'].includes(d.kind) || ['g:net', 'g:fw', 'g:power'].includes(d.group) || pre(d.foundBy, ['mon.network']) },
    linux: { label: 'Linux hosts', test: (d) => d.kind === 'linux' || d.group === 'g:lnx' || /linux/i.test(d.os || '') || pre(d.foundBy, ['lnx.']) },
    'monitoring/storage': { label: 'storage systems and volumes', test: (d) => ['san', 'nas', 'storage', 'backup', 'datastore'].includes(d.kind) || ['g:storage', 'g:cloud'].includes(d.group) || pre(d.foundBy, ['mon.storage', 'mon.cloud.storage', 'mon.clusters.storage']) },
    entra: { label: 'tenants and Intune managed devices', test: (d) => ['tenant', 'mobile'].includes(d.kind) || d.group === 'g:entra' || d.types.has('intune.device') || pre(d.foundBy, ['inv.entra.', 'mon.entra.', 'inv.intune.', 'mon.intune']) },
    containers: { label: 'clusters, nodes and container hosts', test: (d) => ['k8scluster', 'k8snode', 'container'].includes(d.kind) || d.group === 'g:k8s' || pre(d.foundBy, ['mon.kubernetes', 'mon.containers']) },
    web: { label: 'web servers, websites and TLS endpoints', test: (d) => d.kind === 'web' || ['g:web-checks', 'g:web'].includes(d.group) || pre(d.foundBy, ['mon.web.servers', 'mon.web.hosts', 'mon.ssl.certificates', 'mon.iis']) || d.types.has('http') || d.types.has('ssl') || d.types.has('web.host') },
    databases: { label: 'database servers and cloud databases', test: (d) => ['database', 'clouddb', 'sql'].includes(d.kind) || ['g:db', 'g:sql'].includes(d.group) || d.types.has('db.service') || d.types.has('db.instance') || d.types.has('cloud.db') || pre(d.foundBy, ['mon.databases', 'mon.cloud.databases', 'inv.sql', 'mon.sql']) },
    security: { label: 'devices with security sensors', test: (d) => WIN(d) || pre(d.foundBy, ['sec.']) },
  };
  const key = (r) => (SCOPE[r.page + '/' + (r.tab || '')] ? r.page + '/' + r.tab : SCOPE[r.page] ? r.page : null);
  const ORIGIN = { engine: 'Found by an engine', manual: 'Added by hand', discovery: 'Added from auto-discovery', import: 'Imported', integration: 'From an alert integration' };
  const isEngine = (d) => d.origin === 'engine';

  let treeAt = 0, treeP = null;
  const devices = () => { if (!treeP || Date.now() - treeAt > 20000) { treeAt = Date.now(); treeP = MC.api.monitor('tree').then((t) => { const ty = new Map(); for (const x of t.sensors || []) (ty.get(x.device) || ty.set(x.device, new Set()).get(x.device)).add(x.type); return (t.devices || []).map((d) => Object.assign({}, d, { types: ty.get(d.id) || new Set() })); }).catch(() => { treeAt = 0; return null; }); } return treeP; };
  MC.sourceReset = () => { treeAt = 0; };

  // the switch above the page; returns the chosen mode ('' = the page itself)
  function bar(el, route) {
    const k = key(route); if (!k) return '';
    const mode = ['engine', 'manual'].includes((route.q || {}).src) ? route.q.src : '';
    const base = '#/' + route.page + (route.tab ? '/' + route.tab : '');
    const box = document.createElement('div');
    box.className = 'src-bar'; box.setAttribute('role', 'tablist'); box.setAttribute('aria-label', 'Show');
    box.innerHTML = [['', 'Overview'], ['engine', 'Found by engines'], ['manual', 'Manually added']].map(([m, l]) => `<a role="tab" href="${base}${m ? '?src=' + m : ''}" class="${m === mode ? 'on' : ''}" aria-selected="${m === mode}" data-src="${m}">${esc(l)}${m ? ' <span class="n" data-n="' + m + '">…</span>' : ''}</a>`).join('');
    el.prepend(box);
    devices().then((list) => {
      if (!list || !document.body.contains(box)) return;
      const mine = list.filter(SCOPE[k].test);
      $('[data-n="engine"]', box).textContent = mine.filter(isEngine).length;
      $('[data-n="manual"]', box).textContent = mine.filter((d) => !isEngine(d)).length;
    });
    return mode;
  }

  function list(el, route, mode) {
    const k = key(route), sc = SCOPE[k];
    const host = document.createElement('div');
    el.appendChild(host);
    host.innerHTML = '<div class="notice">Loading devices…</div>';
    devices().then((all) => {
      if (!document.body.contains(host)) return;
      if (!all) { host.innerHTML = '<div class="notice err">The device list is not available with your access.</div>'; return; }
      const rows = all.filter(sc.test).filter((d) => (mode === 'engine' ? isEngine(d) : !isEngine(d)));
      const title = mode === 'engine' ? 'Found by engines' : 'Manually added';
      const sub = mode === 'engine' ? `${sc.label} that a monitoring engine reported, for example a server found in Active Directory or a VM found on its host` : `${sc.label} added by hand, from auto-discovery or from an import`;
      host.innerHTML = MC.panel(title, sub, '<div id="srcT"></div>') + (mode === 'manual' ? `<p class="muted" style="font-size:12.5px">Add a device under <a href="#/sensors">Configure › Devices & sensors</a> or find devices with <a href="#/discovery">Auto-discovery</a>. Any sensor type can be added to any device, engine sensors included.</p>` : `<p class="muted" style="font-size:12.5px">Engines add these devices on their own. Turn engines on or off under <a href="#/engines">Actions › Monitoring engines</a>.</p>`);
      const eng = (id) => ((MC.script(id) || {}).title || id);
      MC.table($('#srcT', host), rows, [
        { key: 'name', label: 'Device', html: (d) => `<a href="#/device/${enc(d.id)}"><b>${esc(d.name)}</b></a>${d.host && d.host !== d.name ? `<div class="muted mono" style="font-size:12px">${esc(d.host)}</div>` : ''}` },
        { key: 'state', label: 'State', html: (d) => pill(d.state, d.state) },
        { key: 'kind', label: 'Type', val: (d) => d.kind },
        { key: 'origin', label: 'Source', val: (d) => ORIGIN[d.origin] || d.origin },
        { key: 'foundBy', label: 'Reported by', val: (d) => (d.foundBy || []).map(eng).join(', '), html: (d) => (d.foundBy || []).length ? (d.foundBy || []).map((x) => `<span class="tag" title="${esc(x)}">${esc(eng(x))}</span>`).join(' ') : '<span class="muted">probe sensors only</span>' },
        { key: 'roles', label: 'Roles', val: (d) => (d.roles || []).join(', ') },
        { key: 'sensors', label: 'Sensors', n: true },
      ], { name: 'devices-' + k.replace('/', '-') + '-' + mode, empty: mode === 'engine' ? 'No engine has reported a device for this page yet. Turn on the engines this page uses.' : 'Nobody has added a device for this page yet.' });
    });
  }
  // Overview: every device of the page in one table, found by engines and manually added, with key readings from its sensors
  let sensP = null, sensAt = 0;
  const sensors = () => { if (!sensP || Date.now() - sensAt > 20000) { sensAt = Date.now(); sensP = MC.api.monitor('tree').then((t) => t.sensors || []).catch(() => []); } return sensP; };
  const PICK = [
    ['cpu', 'CPU', (x) => /cpu|processor/i.test(x.type + ' ' + x.name + ' ' + (x.primary || ''))],
    ['mem', 'Memory', (x) => /mem/i.test(x.type + ' ' + x.name + ' ' + (x.primary || ''))],
    ['disk', 'Disk / storage', (x) => /disk|volume|datastore|capacity|storage/i.test(x.type + ' ' + x.name)],
    ['ping', 'Response', (x) => x.type === 'ping' || x.type === 'port' || x.type === 'http'],
  ];
  const COMBINED = ['identity', 'virtualization', 'virtualization/vms', 'network', 'linux', 'monitoring/storage', 'containers', 'web', 'entra', 'databases'];
  function combined(el, route) {
    const k = key(route); if (!k) return;
    const sc = SCOPE[k];
    if (!COMBINED.includes(k) || (['identity', 'network', 'linux', 'containers', 'web', 'entra', 'databases'].includes(route.page) && route.tab)) return;
    const host = document.createElement('div');
    host.className = 'src-all';
    el.after(host); // a sibling after the page, so a page that redraws itself later keeps it
    Promise.all([devices(), sensors()]).then(([all, sens]) => {
      if (!all || !document.body.contains(host)) return;
      const rows = all.filter(sc.test);
      if (!rows.length) return;
      const by = new Map(); for (const x of sens) (by.get(x.device) || by.set(x.device, []).get(x.device)).push(x);
      const val = (d, f) => { const x = (by.get(d.id) || []).find(f); return x ? x : null; };
      const eng = rows.filter(isEngine).length, man = rows.length - eng;
      const st = (s) => rows.filter((d) => d.state === s).length;
      host.innerHTML = MC.panel('All ' + sc.label, `${eng} found by engines · ${man} manually added · ${st('Down')} down · ${st('Warning')} warning`, '<div id="cmbT"></div>', { act: `<a class="btn sm ghost" href="#/${route.page}${route.tab ? '/' + route.tab : ''}?src=manual">Manually added</a><a class="btn sm ghost" href="#/${route.page}${route.tab ? '/' + route.tab : ''}?src=engine">Found by engines</a>` });
      const cell = (x) => (x ? `<span title="${esc(x.name)}">${pill(x.state, x.value || x.state)}</span>` : '<span class="muted">–</span>');
      MC.table($('#cmbT', host), rows, [
        { key: 'name', label: 'Device', html: (d) => `<a href="#/device/${enc(d.id)}"><b>${esc(d.name)}</b></a>${d.host && d.host !== d.name ? `<div class="muted mono" style="font-size:12px">${esc(d.host)}</div>` : ''}` },
        { key: 'origin', label: 'Source', val: (d) => (isEngine(d) ? 'Found by an engine' : ORIGIN[d.origin] || 'Added by hand'), html: (d) => `<span class="tag ${isEngine(d) ? 'collector' : 'native'}">${isEngine(d) ? 'engine' : 'added'}</span>` },
        { key: 'state', label: 'State', html: (d) => pill(d.state, d.state) },
        { key: 'kind', label: 'Type', val: (d) => d.kind + (d.os ? ' · ' + d.os : '') },
      ].concat(PICK.map(([id, label, f]) => ({ key: id, label, val: (d) => { const x = val(d, f); return x ? x.value : ''; }, html: (d) => cell(val(d, f)) }))).concat([
        { key: 'sensors', label: 'Sensors', n: true },
      ]), { name: 'overview-all-' + k.replace('/', '-'), sort: 'state', limit: 10, empty: 'No devices yet.' });
    });
  }
  MC.sourceView = { bar, list, key, SCOPE, combined };
})(typeof self !== 'undefined' ? self : this);
