/*
 * RoboMate MonCastle - MonCastle infrastructure: the central console and the remote MonCastle servers joined to it.
 * Each device is monitored by one server; this page shows every server's utilisation and load, adds a server
 * (one-time join code), rotates or removes it, and moves devices between servers.
 */
(function (root) {
  'use strict';
  const MC = root.MC, C = root.MCCharts;
  const { esc, fmt, pill, icon, ago, $, $$ } = MC;
  const V = MC.views;
  const ST = { Up: 'OK', Warning: 'Warning', Down: 'Critical', Unknown: 'Unknown' };
  const pct = (v) => (v == null ? '–' : fmt(v, 0) + '%');
  const modal = (html, onReady) => {
    const m = document.createElement('div');
    m.className = 'modal'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true');
    m.innerHTML = `<div class="card">${html}</div>`;
    document.body.appendChild(m);
    const close = () => m.remove();
    $$('[data-x]', m).forEach((b) => b.addEventListener('click', close));
    m.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    const f = $('input,textarea,select', m); if (f) f.focus();
    if (onReady) onReady(m, close);
    return m;
  };
  const errBox = (m, e) => { $('[data-err]', m).innerHTML = `<div class="notice err" style="margin-top:10px">${esc(e.message)}</div>`; };

  function joinDialog(r) {
    modal(`<h3>Join ${esc(r.server.name)} to this console</h3>
      <p class="muted">This code is shown once. It holds the server's secret, so treat it like a password. Run one of these on <b>${esc(r.server.name)}</b> after installing MonCastle there:</p>
      <div class="field"><label>Join code</label><textarea class="input mono" id="jc" rows="4" readonly>${esc(r.code)}</textarea></div>
      <div class="cmdline mono">launcher\\Join-MonCastleServer.ps1</div>
      <p class="muted" style="font-size:12.5px;margin:4px 0 8px">It asks for the code (hidden input), joins, and the server starts as a remote MonCastle server on its next start. Without PowerShell: set the code in the MC_JOIN environment variable and run <span class="mono">node server\\index.js</span> once.</p>
      <p class="muted" style="font-size:12.5px">The remote server checks in every 30 seconds over HTTPS (or HTTP) to this console. Requests are signed with HMAC-SHA256 and the credentials it receives are encrypted with AES-256-GCM. Allow the console port from the remote server through the firewall.</p>
      <div class="foot"><button class="btn" id="cp">${icon('copy')} Copy code</button><button class="btn primary" data-x>Done</button></div>`, (m) => {
      $('#cp', m).addEventListener('click', async () => { try { await navigator.clipboard.writeText(r.code); MC.toast('Join code copied', 'ok'); } catch (e) { $('#jc', m).select(); document.execCommand && document.execCommand('copy'); } });
    });
  }

  function addDialog(done) {
    modal(`<h3>Add a MonCastle server</h3>
      <p class="muted">A remote MonCastle server runs probe sensors and engines for the devices you give it, for example at a branch office or behind a firewall, and reports to this console.</p>
      <div class="field"><label for="sn">Computer name</label><input class="input mono" id="sn" placeholder="MONCASTLE-BR02"></div>
      <div class="field"><label for="ss">Site</label><input class="input" id="ss" placeholder="Branch office, data centre…"></div>
      <div class="field"><label for="sh">DNS name (optional)</label><input class="input mono" id="sh" placeholder="moncastle-br02.corp.local"></div>
      <div class="field"><label for="su">This console as the remote server reaches it</label><input class="input mono" id="su" value="${esc(location.origin)}"><span class="hint">Use the name or address the remote server can resolve, and HTTPS when the link crosses sites.</span></div>
      <div data-err></div>
      <div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Create join code</button></div>`, (m, close) => {
      $('#go', m).addEventListener('click', async () => {
        try { const r = await MC.api.infraAction({ action: 'add', name: $('#sn', m).value, site: $('#ss', m).value, host: $('#sh', m).value, url: $('#su', m).value }); close(); joinDialog(r); done(); } catch (e) { errBox(m, e); }
      });
    });
  }

  function editDialog(s, done) {
    modal(`<h3>${esc(s.name)}</h3>
      <div class="field"><label for="es">Site</label><input class="input" id="es" value="${esc(s.site || '')}"></div>
      ${s.role === 'central' ? '' : `<div class="field"><label for="eh">DNS name</label><input class="input mono" id="eh" value="${esc(s.host || '')}"></div>`}
      <div data-err></div>
      <div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Save</button></div>`, (m, close) => {
      $('#go', m).addEventListener('click', async () => { try { await MC.api.infraAction({ action: 'update', id: s.id, site: $('#es', m).value, host: $('#eh', m) ? $('#eh', m).value : undefined }); close(); done(); } catch (e) { errBox(m, e); } });
    });
  }

  function confirmDialog(title, text, label, run) {
    modal(`<h3>${esc(title)}</h3><p class="muted">${text}</p><div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn danger" id="go">${esc(label)}</button></div>`, (m, close) => {
      $('#go', m).addEventListener('click', async () => { try { await run(); close(); } catch (e) { errBox(m, e); } });
    });
  }

  const bar = (label, v, sub) => `<div class="srvbar big"><span>${esc(label)}</span><span class="track"><span class="fill ${v >= 90 ? 'crit' : v >= 75 ? 'warn' : ''}" style="width:${Math.max(2, Math.min(100, v || 0))}%"></span></span><b>${pct(v)}</b>${sub ? `<small class="muted">${sub}</small>` : ''}</div>`;

  function card(s, admin) {
    const u = s.util || {};
    return `<section class="card srvcard" data-srv="${esc(s.id)}">
      <div class="srvcard-h"><span class="srv-ico">${icon('server')}</span><div><a href="#/servers/${encodeURIComponent(s.id)}"><b>${esc(s.name)}</b></a><div class="muted" style="font-size:12.5px">${esc(s.role === 'central' ? 'Central console' : 'Remote server')}${s.site ? ' · ' + esc(s.site) : ''}</div></div><span class="spacer"></span>${pill(ST[s.state] || 'Unknown', s.state === 'Unknown' && s.role !== 'central' ? 'Waiting to join' : s.state)}</div>
      ${s.util ? `<div class="gauges">${C.gauge(u.cpu, { label: 'CPU', warn: 75, crit: 90 })}${C.gauge(u.mem, { label: 'Memory', warn: 80, crit: 92 })}${C.gauge(u.disk, { label: 'Disk', warn: 80, crit: 90 })}</div>` : `<div class="notice">No check-in yet. Run the join code on ${esc(s.name)}; the server appears here within 30 seconds.</div>`}
      <dl class="kv srvkv"><dt>Devices</dt><dd><b>${s.devices || 0}</b> · ${s.sensors || 0} probe sensors${s.down ? ` · <span class="sev-text crit">${s.down} down</span>` : ''}</dd>
        <dt>Hardware</dt><dd>${u.cores ? u.cores + ' cores · ' + fmt(u.memGB, 0) + ' GB RAM' : '–'}${u.diskFreeGB != null ? ' · ' + fmt(u.diskFreeGB, 0) + ' GB free' : ''}</dd>
        <dt>Engines</dt><dd>${u.engines != null ? u.engines + ' enabled' : '–'}</dd>
        <dt>Last check-in</dt><dd>${s.lastSeen ? ago(s.lastSeen) : 'never'}${s.version ? ' · ' + esc(s.version) : ''}</dd>
        ${s.lastError ? `<dt>Last error</dt><dd class="sev-text crit">${esc(s.lastError)}</dd>` : ''}</dl>
      <div class="toolbar" style="margin:0"><a class="btn sm" href="#/servers/${encodeURIComponent(s.id)}">Details</a>${admin ? `<button class="btn sm ghost" data-edit="${esc(s.id)}">Edit</button>${s.role === 'central' ? '' : `<button class="btn sm ghost" data-rot="${esc(s.id)}">New join code</button><button class="btn sm ghost rmtxt" data-rm="${esc(s.id)}">Remove</button>`}` : ''}</div>
    </section>`;
  }

  V.servers = {
    title: 'MonCastle servers',
    crumb: () => (MC.route.tab ? 'server › utilisation, devices and sensors' : 'one console, any number of MonCastle servers'),
    async render(el, route) {
      if (route && route.tab) return detail(el, decodeURIComponent(route.tab));
      el.innerHTML = '<div class="notice">Loading servers…</div>';
      const admin = MC.user && MC.user.role === 'admin';
      const seq = MC.renderSeq;
      const draw = async () => {
        let r;
        try { r = await MC.api.infra(); } catch (e) { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; return; }
        if (seq !== MC.renderSeq) return;
        const sv = r.servers || [];
        const up = sv.filter((x) => x.state === 'Up').length, dev = sv.reduce((a, x) => a + (x.devices || 0), 0), sen = sv.reduce((a, x) => a + (x.sensors || 0), 0);
        const withU = sv.filter((x) => x.util);
        const busiest = withU.slice().sort((a, b) => (b.util.cpu || 0) - (a.util.cpu || 0))[0];
        el.innerHTML = `<div class="kpis">${MC.kpi('MonCastle servers', sv.length, up + ' checking in')}${MC.kpi('Devices', dev, 'spread over ' + sv.filter((x) => x.devices).length + ' servers')}${MC.kpi('Probe sensors', sen, '')}${MC.kpi('Average CPU', withU.length ? pct(withU.reduce((a, x) => a + (x.util.cpu || 0), 0) / withU.length) : '–', busiest ? 'busiest: ' + esc(busiest.name) : '')}${MC.kpi('Not checking in', sv.length - up, '', { alert: sv.some((x) => x.state === 'Down') })}</div>
          <div class="toolbar"><span class="muted" style="font-size:12.5px">Every device is monitored by one server. Choose it in the add-device wizard or the device settings, or move devices on a server's page.</span><span class="spacer"></span>${admin ? `<button class="btn primary" id="addSrv">${icon('plus')} Add MonCastle server</button>` : ''}</div>
          <div class="srvgrid">${sv.map((s) => card(s, admin)).join('')}</div>
          ${MC.panel('Load per server', 'devices and probe sensors each server monitors', '<div id="srvLoad"></div>')}
          ${MC.panel('CPU over 24 hours', 'every server, 5-minute samples', '<div id="srvCpu"></div>')}`;
        C.barList && ($('#srvLoad', el).innerHTML = C.barList(sv.map((s, i) => ({ label: s.name, value: s.devices || 0, text: (s.devices || 0) + ' dev · ' + (s.sensors || 0) + ' sens', color: C.SERIES[i % C.SERIES.length] })), { compact: true }));
        C.timeSeries($('#srvCpu', el), sv.filter((s) => (s.history || []).length > 1).slice(0, 8).map((s, i) => ({ name: s.name, points: s.history.map((h) => ({ t: Date.parse(h.at), v: h.cpu || 0 })), color: C.SERIES[i % C.SERIES.length] })), { height: 200, unit: '%', yMax: 100 });
        const byId = (id) => sv.find((x) => x.id === id);
        if (admin) {
          $('#addSrv', el).addEventListener('click', () => addDialog(draw));
          $$('[data-edit]', el).forEach((b) => b.addEventListener('click', () => editDialog(byId(b.dataset.edit), draw)));
          $$('[data-rot]', el).forEach((b) => b.addEventListener('click', () => { const s = byId(b.dataset.rot); confirmDialog('New join code for ' + s.name, 'The old code and secret stop working at once. ' + esc(s.name) + ' stops syncing until you run the new code on it.', 'Create new code', async () => { const r2 = await MC.api.infraAction({ action: 'rotate', id: s.id }); joinDialog(r2); draw(); }); }));
          $$('[data-rm]', el).forEach((b) => b.addEventListener('click', () => { const s = byId(b.dataset.rm); confirmDialog('Remove ' + s.name, 'Its secret is deleted and it can no longer sync. Move its devices to another server first.', 'Remove server', async () => { await MC.api.infraAction({ action: 'remove', id: s.id }); MC.toast(esc(s.name) + ' removed', 'ok'); draw(); }); }));
        }
      };
      await draw();
      clearInterval(V.servers._t);
      V.servers._t = setInterval(() => { if (seq !== MC.renderSeq) return clearInterval(V.servers._t); if (!document.querySelector('.modal')) draw(); }, 30000);
    },
  };

  async function detail(el, id) {
    el.innerHTML = '<div class="notice">Loading server…</div>';
    const admin = MC.user && MC.user.role === 'admin';
    let r, t;
    try { [r, t] = await Promise.all([MC.api.infra(), MC.api.monitor('tree')]); } catch (e) { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; return; }
    const s = (r.servers || []).find((x) => x.id === id);
    if (!s) { el.innerHTML = '<div class="notice err">No such MonCastle server. <a href="#/servers">All servers</a></div>'; return; }
    const others = r.servers.filter((x) => x.id !== id);
    const devs = t.devices.filter((d) => (d.server || 'srv:local') === id);
    const u = s.util || {};
    const ids = new Set(devs.map((d) => d.id));
    const c = t.sensors.filter((x) => ids.has(x.device)).reduce((a, x) => ((a[x.state] = (a[x.state] || 0) + 1), a), {});
    const states = C.statusStack ? `<div style="margin-top:14px"><div class="muted" style="font-size:12.5px;margin-bottom:6px">Sensor states on the devices this server monitors</div>${C.statusStack({ Critical: c.Down || 0, Warning: c.Warning || 0, OK: c.Up || 0, Unknown: (c.Unknown || 0) + (c.Paused || 0) }, {})}</div>` : '';
    el.innerHTML = `<div class="toolbar"><a class="btn sm ghost" href="#/servers">← All servers</a><span class="spacer"></span>${pill(ST[s.state] || 'Unknown', s.state)}</div>
      <div class="grid g2">
        ${MC.panel(s.name, esc(s.role === 'central' ? 'Central console' : 'Remote server') + (s.site ? ' · ' + esc(s.site) : ''), s.util ? `<div class="gauges">${C.gauge(u.cpu, { label: 'CPU', warn: 75, crit: 90 })}${C.gauge(u.mem, { label: 'Memory', warn: 80, crit: 92 })}${C.gauge(u.disk, { label: 'Disk', warn: 80, crit: 90 })}</div>` : '<div class="notice">No check-in yet.</div>') + states}
        ${MC.panel('General', '', `<dl class="kv"><dt>Host</dt><dd class="mono">${esc(s.host || '–')}</dd><dt>Operating system</dt><dd>${esc(u.os || '–')}</dd><dt>Hardware</dt><dd>${u.cores ? u.cores + ' cores · ' + fmt(u.memGB, 0) + ' GB RAM' : '–'}</dd><dt>Free disk</dt><dd>${u.diskFreeGB != null ? fmt(u.diskFreeGB, 0) + ' GB' : '–'}</dd><dt>MonCastle process</dt><dd>${u.rssMB ? u.rssMB + ' MB' : '–'}</dd><dt>Uptime</dt><dd>${u.uptimeH != null ? fmt(u.uptimeH, 0) + ' h' : '–'}</dd><dt>Engines</dt><dd>${u.engines != null ? u.engines + ' enabled' : '–'}</dd><dt>Version</dt><dd>${esc(s.version || '–')}</dd><dt>Joined</dt><dd>${s.created ? ago(s.created) : 'built in'}</dd><dt>Last check-in</dt><dd>${s.lastSeen ? ago(s.lastSeen) : 'never'}</dd>${s.lastError ? `<dt>Last error</dt><dd class="sev-text crit">${esc(s.lastError)}</dd>` : ''}</dl>`)}
      </div>
      ${MC.panel('Utilisation', 'last 24 hours, 5-minute samples', '<div id="sHist"></div>')}
      ${MC.panel('Devices monitored by ' + s.name, devs.length + ' devices · ' + (s.sensors || 0) + ' probe sensors', '<div id="sDev"></div>', { act: admin && others.length ? `<select class="input sm" id="mvTo" aria-label="Move to">${others.map((x) => `<option value="${esc(x.id)}">${esc(x.name)} · CPU ${pct(x.util && x.util.cpu)}</option>`).join('')}</select><button class="btn sm" id="mvGo">Move selected</button>` : '' })}`;
    const h = s.history || [];
    C.timeSeries($('#sHist', el), [
      { name: 'CPU', points: h.map((x) => ({ t: Date.parse(x.at), v: x.cpu || 0 })), color: '--s1' },
      { name: 'Memory', points: h.map((x) => ({ t: Date.parse(x.at), v: x.mem || 0 })), color: '--s2' },
      { name: 'Disk', points: h.filter((x) => x.disk != null).map((x) => ({ t: Date.parse(x.at), v: x.disk })), color: '--s3' },
    ], { height: 220, unit: '%', yMax: 100 });
    const sel = new Set();
    MC.table($('#sDev', el), devs, [
      ...(admin && others.length ? [{ key: '_sel', label: '', html: (d) => `<input type="checkbox" data-mv="${esc(d.id)}" aria-label="Select ${esc(d.name)}">` }] : []),
      { key: 'name', label: 'Device', html: (d) => `<a href="#/device/${encodeURIComponent(d.id)}">${esc(d.name)}</a>` },
      { key: 'host', label: 'Host', cls: 'mono' }, { key: 'kind', label: 'Type' },
      { key: 'sensors', label: 'Sensors', n: true },
      { key: 'state', label: 'State', html: (d) => pill(ST[d.state] || 'Unknown', d.state) },
    ], { name: 'server-devices', limit: 50, empty: 'No devices yet. Pick this server in the add-device wizard ("Monitored by"), or move devices here from another server.' });
    $('#sDev', el).addEventListener('change', (e) => { const c = e.target.closest('[data-mv]'); if (c) c.checked ? sel.add(c.dataset.mv) : sel.delete(c.dataset.mv); });
    const go = $('#mvGo', el);
    if (go) go.addEventListener('click', async () => {
      if (!sel.size) return MC.toast('Select the devices to move first', 'err');
      const to = $('#mvTo', el).value, name = (others.find((x) => x.id === to) || {}).name;
      try { for (const d of sel) await MC.api.monitor('setDevice', { id: d, server: to }); MC.toast(sel.size + ' devices moved to ' + esc(name), 'ok'); detail(el, id); } catch (e) { MC.toast(esc(e.message), 'err'); }
    });
  }
})(typeof self !== 'undefined' ? self : this);
