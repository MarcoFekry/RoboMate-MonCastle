/*
 * RoboMate MonCastle - credential kinds and how a device finds its credentials (browser: window.MCCredModel, server: require).
 * Like PRTG, a device uses the credential set on the device, else the one assigned to its group (or a parent group),
 * else the probe-wide default for that kind. Secrets are stored encrypted on the console and never sent to browsers.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCCredModel = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const F = (name, label, extra) => Object.assign({ name, label, type: 'string' }, extra || {});
  const KINDS = [
    { id: 'windows', name: 'Windows (WinRM / WMI)', icon: 'server', desc: 'Domain or local account for PowerShell remoting and WMI: inventory, performance, services, event logs, software and actions.',
      fields: [F('domain', 'Domain (empty for a local account)'), F('username', 'User name', { required: true }), F('password', 'Password', { secret: true, required: true }), F('transport', 'Method', { values: ['WinRM HTTP (5985)', 'WinRM HTTPS (5986)', 'WMI / DCOM (135)'], def: 'WinRM HTTP (5985)' }), F('auth', 'Authentication', { values: ['Kerberos', 'Negotiate', 'NTLM', 'CredSSP'], def: 'Negotiate' })] },
    { id: 'ssh', name: 'Linux / Unix (SSH)', icon: 'linux', desc: 'SSH account for Linux collectors and SSH sensors. Password or private key.',
      fields: [F('username', 'User name', { required: true }), F('method', 'Method', { values: ['Password', 'Private key'], def: 'Password' }), F('password', 'Password', { secret: true }), F('privateKey', 'Private key (PEM)', { secret: true, multiline: true }), F('passphrase', 'Key passphrase', { secret: true }), F('port', 'Port', { type: 'int', def: 22, min: 1, max: 65535 }), F('elevation', 'Elevation', { values: ['None', 'sudo', 'su'], def: 'None' })] },
    { id: 'snmpv2', name: 'SNMP v1 / v2c', icon: 'net', desc: 'Read community for switches, routers, firewalls, UPS, printers and appliances.',
      fields: [F('community', 'Read community', { secret: true, required: true }), F('version', 'Version', { values: ['v2c', 'v1'], def: 'v2c' }), F('port', 'Port', { type: 'int', def: 161, min: 1, max: 65535 })] },
    { id: 'snmpv3', name: 'SNMP v3', icon: 'net', desc: 'User-based security with authentication and encryption.',
      fields: [F('username', 'User name', { required: true }), F('level', 'Security level', { values: ['authPriv', 'authNoPriv', 'noAuthNoPriv'], def: 'authPriv' }), F('authProtocol', 'Authentication', { values: ['SHA', 'SHA-256', 'MD5'], def: 'SHA' }), F('authPassword', 'Authentication password', { secret: true }), F('privProtocol', 'Encryption', { values: ['AES', 'AES-256'], def: 'AES' }), F('privPassword', 'Encryption password', { secret: true }), F('context', 'Context name'), F('port', 'Port', { type: 'int', def: 161, min: 1, max: 65535 })] },
    { id: 'vmware', name: 'VMware vCenter / ESXi', icon: 'layers', desc: 'Read-only vCenter or ESXi account for the VMware collector.',
      fields: [F('username', 'User name', { required: true }), F('password', 'Password', { secret: true, required: true }), F('port', 'Port', { type: 'int', def: 443, min: 1, max: 65535 }), F('ignoreCert', 'Certificate', { values: ['Verify', 'Ignore (self-signed)'], def: 'Verify' })] },
    { id: 'http', name: 'Web / API (HTTP)', icon: 'cloud', desc: 'Basic authentication, bearer token or API key header for HTTP sensors.',
      fields: [F('method', 'Method', { values: ['Basic', 'Bearer token', 'API key header'], def: 'Basic' }), F('username', 'User name'), F('password', 'Password', { secret: true }), F('token', 'Token or key', { secret: true }), F('header', 'Header name (API key)', { def: 'X-API-Key' })] },
    { id: 'sql', name: 'SQL Server', icon: 'db', desc: 'SQL login for the SQL collector, or Windows (integrated) authentication.',
      fields: [F('method', 'Method', { values: ['Windows (integrated)', 'SQL login'], def: 'Windows (integrated)' }), F('username', 'SQL login'), F('password', 'Password', { secret: true }), F('port', 'Port', { type: 'int', def: 1433, min: 1, max: 65535 }), F('encrypt', 'Encryption', { values: ['Optional', 'Mandatory', 'Strict'], def: 'Optional' })] },
    { id: 'database', name: 'Database', icon: 'db', desc: 'Login for MySQL, MariaDB, PostgreSQL, Oracle, MongoDB, Redis, Elasticsearch/OpenSearch, Cassandra and the other database engines. Use a read-only monitoring account.',
      fields: [F('username', 'User name (empty for Redis password-only)'), F('password', 'Password or API key', { secret: true }), F('authDb', 'Authentication database or service name (MongoDB, Oracle)'), F('tls', 'TLS', { values: ['Prefer', 'Require', 'Off'], def: 'Prefer' }), F('ignoreCert', 'Certificate', { values: ['Verify', 'Ignore (self-signed)'], def: 'Verify' })] },
    { id: 'cloud', name: 'Cloud provider', icon: 'cloud', desc: 'Read-only identity for cloud storage: Azure service principal, AWS access key, Google Cloud service account, OCI API key or Huawei Cloud access key.',
      fields: [F('provider', 'Provider', { values: ['Azure', 'AWS', 'Google Cloud', 'Oracle Cloud', 'Huawei Cloud'], def: 'Azure', required: true }), F('tenant', 'Tenant ID / project ID / tenancy OCID'), F('identity', 'Client ID / access key ID / user OCID', { required: true }), F('secret', 'Client secret / secret access key', { secret: true }), F('key', 'Service-account JSON (Google) or API private key PEM (OCI)', { secret: true, multiline: true }), F('fingerprint', 'API key fingerprint (OCI)'), F('region', 'Region (empty = all regions)'), F('scope', 'Subscriptions, accounts or compartments (comma separated, empty = all)')] },
  ];
  const KIND = Object.fromEntries(KINDS.map((k) => [k.id, k]));
  // which kinds a device type can use, best first
  const FOR_DEVICE = {
    server: ['windows', 'snmpv2', 'snmpv3', 'http', 'sql', 'database'], workstation: ['windows', 'snmpv2'], linux: ['ssh', 'snmpv2', 'snmpv3', 'http', 'database'],
    network: ['snmpv2', 'snmpv3', 'ssh', 'http'], appliance: ['snmpv2', 'snmpv3', 'ssh', 'http'], printer: ['snmpv2', 'snmpv3', 'http'],
    firewall: ['snmpv3', 'snmpv2', 'ssh', 'http'], wireless: ['snmpv3', 'snmpv2', 'ssh', 'http'], loadbalancer: ['snmpv3', 'snmpv2', 'ssh', 'http'], fcswitch: ['snmpv3', 'snmpv2', 'ssh', 'http'],
    san: ['snmpv3', 'snmpv2', 'http', 'ssh'], nas: ['snmpv3', 'snmpv2', 'http', 'ssh'], backup: ['snmpv3', 'snmpv2', 'http', 'ssh'],
    ups: ['snmpv3', 'snmpv2', 'http'], pdu: ['snmpv3', 'snmpv2', 'http'], environment: ['snmpv3', 'snmpv2', 'http'], bmc: ['http', 'snmpv3', 'snmpv2', 'ssh'], camera: ['http', 'snmpv2', 'snmpv3'], voip: ['snmpv2', 'snmpv3', 'ssh', 'http'],
    web: ['http'], host: ['vmware', 'ssh'], vm: ['windows', 'ssh'], cluster: ['windows'], domain: ['windows'], datastore: ['vmware'], sql: ['sql', 'windows'], database: ['database', 'ssh', 'windows', 'snmpv2', 'snmpv3'], cloudstorage: ['cloud'],
  };
  const kindsFor = (deviceKind) => FOR_DEVICE[deviceKind] || ['windows', 'ssh', 'snmpv2', 'snmpv3', 'http'];
  const SNMP = ['snmpv3', 'snmpv2'];

  // creds: [{ id, kind, assign:{ all, groups:[], devices:[] } }]; device: { id, group, credentials:{ kind: credId } }
  // chain: [group, parent, …]. Returns { cred, from } or null. kind 'snmp' takes v3 before v2c at each level.
  function resolve(creds, device, chain, kind) {
    const kinds = kind === 'snmp' ? SNMP : [kind];
    const byId = (id) => creds.find((c) => c.id === id);
    for (const k of kinds) { const id = ((device || {}).credentials || {})[k]; if (id && byId(id)) return { cred: byId(id), from: 'device' }; }
    for (const k of kinds) { const c = creds.find((x) => x.kind === k && (x.assign.devices || []).includes(device.id)); if (c) return { cred: c, from: 'device' }; }
    for (const g of chain || []) for (const k of kinds) { const c = creds.find((x) => x.kind === k && (x.assign.groups || []).includes(g)); if (c) return { cred: c, from: 'group ' + g }; }
    for (const k of kinds) { const c = creds.find((x) => x.kind === k && x.assign.all); if (c) return { cred: c, from: 'probe default' }; }
    return null;
  }
  return { KINDS, KIND, kindsFor, resolve };
});
