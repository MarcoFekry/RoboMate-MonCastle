/*
 * RoboMate MonCastle - dashboards and reports.
 *   Dashboards: built-in ones for every area, plus dashboards people build from widgets (gauges, top-N bars, graphs,
 *   status, alarms, device tiles, dataset KPIs, charts and tables). Saved per user, optionally shared.
 *   Reports: pick a dataset or the sensors, choose columns, filters, grouping and a chart; save, export CSV or print.
 */
(function (root) {
  'use strict';
  const MC = root.MC, C = root.MCCharts, RB = root.MCRbac, S = root.MCSensors;
  const { esc, fmt, pill, icon, ago, $, $$ } = MC;
  const V = MC.views;
  const canShare = () => RB.atLeast(RB.norm(MC.user.role), 'contributor');
  const modal = (html, onReady) => {
    const m = document.createElement('div');
    m.className = 'modal'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true');
    m.innerHTML = `<div class="card">${html}</div>`;
    document.body.appendChild(m);
    const close = () => m.remove();
    $$('[data-x]', m).forEach((b) => b.addEventListener('click', close));
    m.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    const f = $('input,textarea,select', m); if (f) f.focus();
    if (onReady) onReady(m, close);
    return m;
  };
  const errBox = (m, e) => { $('[data-err]', m).innerHTML = `<div class="notice err" style="margin-top:10px">${esc(e.message)}</div>`; };

  // ------------------------------------------------------------------ dataset query engine (widgets and reports)
  const DS_NAMES = {
    'servers.compute': 'Servers: CPU, memory, disk I/O', 'servers.disks': 'Servers: volumes', 'servers.availability': 'Servers: availability', 'servers.services': 'Servers: services', 'servers.events': 'Servers: event log errors', 'servers.iis': 'IIS application pools', 'servers.activation': 'Windows activation',
    'inventory.hardware': 'Inventory: hardware', 'inventory.software': 'Inventory: software', 'inventory.roles': 'Inventory: roles', 'inventory.printers': 'Inventory: printers', 'inventory.workstations': 'Inventory: workstations',
    'ad.users': 'AD users', 'ad.computers': 'AD computers', 'ad.groups': 'AD group members', 'ad.health': 'AD domain controllers', 'ad.replication': 'AD replication', 'ad.gpo': 'Group Policy', 'ad.sites': 'AD sites and site links',
    'network.dhcp': 'DHCP scopes', 'network.discovery': 'Network discovery', 'printers.health': 'Printer health', 'dns.servers': 'DNS servers', 'fileserver.health': 'File servers',
    'virtualization.hyperv': 'Hyper-V', 'virtualization.vmware': 'VMware', 'virtualization.openshift': 'OpenShift Virtualization', 'virtualization.nutanix': 'Nutanix AHV', 'virtualization.clusters': 'Clusters', 'virtualization.clusterstorage': 'Cluster storage', 'sql.databases': 'SQL databases', 'linux.hosts': 'Linux hosts',
    'security.defender': 'Defender', 'security.patches': 'Windows updates', 'security.firewall': 'Firewall', 'security.localadmins': 'Local administrators', 'security.fileacl': 'Share permissions', 'audit.events': 'Audit events',
  };
  // MonCastle's own data as report sources: sensors with their metrics, the alarm log, engines, job runs, console audit
  const VDS = {};
  Object.assign(DS_NAMES, { 'mc.sensors': 'Sensors and their metrics', 'mc.alarms': 'Alarm history (state changes)', 'mc.engines': 'Monitoring engines', 'mc.jobruns': 'Actions and job runs', 'mc.audit': 'Console audit (who did what)', 'mc.devices': 'Monitored devices', 'virtualization.openshift': 'OpenShift Virtualization', 'virtualization.nutanix': 'Nutanix AHV', 'updates.status': 'OS updates', 'databases.health': 'Databases', 'cloud.storage': 'Cloud storage', 'servers.events': 'Servers: event log errors' });
  let vdsAt = 0;
  async function loadVirtual(force) {
    if (!force && Date.now() - vdsAt < 30000) return VDS;
    const safe = (p) => p.catch(() => null);
    const [srows, tree, log, eng, defs, audit] = await Promise.all([safe(sensorRows(null)), safe(MC.monTree()), safe(MC.monApi('log', { limit: 3000 })), safe(MC.api.engines()), safe(MC.api.jobdefs()), safe(MC.api.accessLog())]);
    VDS['mc.sensors'] = srows || [];
    if (tree) {
      const groups = new Map((tree.groups || []).map((g) => [g.id, g.name]));
      VDS['mc.devices'] = (tree.devices || []).map((d) => ({ Device: d.name, Host: d.host, Group: groups.get(d.group) || d.group, Kind: d.kind, State: d.state, Sensors: d.sensors, Down: d.down || 0, Warning: d.warning || 0, Paused: !!d.paused }));
    }
    VDS['mc.alarms'] = (log || []).map((e) => ({ Time: e.t, Device: e.deviceName || e.device, Sensor: e.sensorName, From: e.from, To: e.to, Message: e.message || '' }));
    VDS['mc.engines'] = ((eng && eng.engines) || []).map((e) => ({ Engine: e.title, Id: e.id, Category: e.category, Resource: e.resource, Every: e.every, State: e.state, LastStatus: e.lastStatus === 'ok' ? 'OK' : e.lastStatus === 'error' ? 'Critical' : e.lastStatus === 'warning' ? 'Warning' : e.lastStatus || 'Unknown', LastRun: e.lastRun, DurationSec: e.durationSec, NextRun: e.nextRun, RunAs: e.runAs, Message: e.message || '' }));
    VDS['mc.jobruns'] = [].concat(...(defs || []).map((d) => (d.history || []).map((h) => ({ Job: d.name, Action: d.title || d.script, Environment: d.resource || '', Risk: d.risk || '', At: h.at, By: h.by, Status: h.status === 'ok' ? 'OK' : h.status === 'failed' ? 'Critical' : h.status === 'partial' ? 'Warning' : h.status, Targets: h.targets, Succeeded: h.ok, Failed: h.failed, Finished: h.finished, Message: h.message || '' }))));
    VDS['mc.audit'] = (Array.isArray(audit) ? audit : (audit && (audit.entries || audit.log)) || []).map((a) => ({ Time: a.time, User: a.user, Event: a.event, IP: a.ip, Detail: a.detail }));
    vdsAt = Date.now();
    return VDS;
  }
  const dsName = (id) => (/^mc\.sensors:/.test(id) ? 'Sensors · ' + ((S.TYPE[id.split(':')[1]] || {}).name || id.split(':')[1]) : DS_NAMES[id] || id);
  const datasets = () => Object.keys(VDS).filter((k) => VDS[k].length).concat(Object.keys(MC.ds).filter((k) => (MC.ds[k].data || []).length).sort((a, b) => dsName(a).localeCompare(dsName(b))));
  const scalar = (v) => v == null || ['string', 'number', 'boolean'].includes(typeof v);
  function fieldsOf(rows) {
    const out = new Map();
    for (const r of rows.slice(0, 50)) for (const [k, v] of Object.entries(r)) {
      if (!scalar(v) && !Array.isArray(v)) continue;
      const t = typeof v === 'number' ? 'number' : typeof v === 'boolean' ? 'bool' : /^\d{4}-\d\d-\d\dT/.test(String(v)) ? 'date' : 'text';
      if (!out.has(k) || (out.get(k) === 'text' && v != null && t !== 'text')) out.set(k, v == null && out.has(k) ? out.get(k) : t);
    }
    return [...out].map(([name, type]) => ({ name, type }));
  }
  const OPS = [['=', 'is'], ['!=', 'is not'], ['>', 'greater than'], ['<', 'less than'], ['contains', 'contains'], ['true', 'is yes'], ['false', 'is no'], ['empty', 'is empty'], ['notempty', 'is not empty'], ['days<', 'within the last N days'], ['days>', 'older than N days']];
  const val = (r, f) => { const v = r[f]; return Array.isArray(v) ? v.join(', ') : v; };
  function match(r, f) {
    const v = val(r, f.field), x = f.value;
    switch (f.op) {
      case '=': return String(v ?? '').toLowerCase() === String(x ?? '').toLowerCase();
      case '!=': return String(v ?? '').toLowerCase() !== String(x ?? '').toLowerCase();
      case '>': return +v > +x;
      case '<': return +v < +x;
      case 'contains': return String(v ?? '').toLowerCase().includes(String(x ?? '').toLowerCase());
      case 'true': return v === true || v === 'true' || v === 1;
      case 'false': return !(v === true || v === 'true' || v === 1);
      case 'empty': return v == null || v === '' || (Array.isArray(r[f.field]) && !r[f.field].length);
      case 'notempty': return !(v == null || v === '' || (Array.isArray(r[f.field]) && !r[f.field].length));
      case 'days<': return v && Date.now() - Date.parse(v) < +x * 864e5;
      case 'days>': return !v || Date.now() - Date.parse(v) > +x * 864e5;
      default: return true;
    }
  }
  const AGG = { count: 'Count', sum: 'Sum', avg: 'Average', max: 'Maximum', min: 'Minimum' };
  function aggregate(rows, fn, field) {
    if (fn === 'count' || !field) return rows.length;
    const n = rows.filter((r) => r[field] != null && r[field] !== '').map((r) => +r[field]).filter((x) => !isNaN(x));
    if (!n.length) return null;
    return fn === 'sum' ? n.reduce((a, b) => a + b, 0) : fn === 'avg' ? n.reduce((a, b) => a + b, 0) / n.length : fn === 'max' ? Math.max(...n) : Math.min(...n);
  }
  // spec: { filters:[{field,op,value}], groupBy, agg:{fn,field}, sort, dir, limit }
  function query(rows, spec) {
    let out = rows.filter((r) => (spec.filters || []).every((f) => !f.field || match(r, f)));
    if (spec.groupBy) {
      const g = new Map();
      for (const r of out) { const k = String(val(r, spec.groupBy) ?? '(empty)'); (g.get(k) || g.set(k, []).get(k)).push(r); }
      const fn = (spec.agg || {}).fn || 'count', fld = (spec.agg || {}).field;
      out = [...g].map(([k, list]) => ({ [spec.groupBy]: k, [AGG[fn] + (fn === 'count' ? '' : ' ' + fld)]: aggregate(list, fn, fld), Rows: list.length }));
      const vk = Object.keys(out[0] || {})[1];
      out.sort((a, b) => (b[vk] ?? -Infinity) - (a[vk] ?? -Infinity));
    } else if (spec.sort) {
      const d = spec.dir === 'asc' ? 1 : -1;
      out = out.slice().sort((a, b) => { const x = a[spec.sort], y = b[spec.sort]; return (typeof x === 'number' && typeof y === 'number' ? x - y : String(x ?? '').localeCompare(String(y ?? ''))) * d; });
    }
    return spec.limit ? out.slice(0, +spec.limit) : out;
  }
  const rowsOf = (ds) => (/^mc\.sensors:/.test(ds) ? (VDS['mc.sensors'] || []).filter((r) => r.Type === ds.split(':')[1]) : VDS[ds] || (MC.ds[ds] || {}).data || []);
  // sensors as report rows: one row per sensor with its state, value, uptime and every channel
  async function sensorRows(type) {
    const [tree, chans] = await Promise.all([MC.monTree(true), MC.monApi('channels', type ? { type } : {})]);
    const byId = new Map(chans.map((c) => [c.id, c]));
    const groups = new Map((tree.groups || []).map((g) => [g.id, g.name]));
    const devs = new Map((tree.devices || []).map((d) => [d.id, d]));
    return tree.sensors.filter((s) => !type || s.type === type).map((s) => {
      const d = devs.get(s.device) || {};
      const row = { Device: d.name, Group: groups.get(d.group) || d.group, Sensor: s.name, Type: s.type, State: s.ack && s.state === 'Down' ? 'Down (ack)' : s.state, Value: s.value, 'Uptime %': s.uptime, Message: s.message, 'Last scan': s.lastScan, Since: s.since };
      for (const c of (byId.get(s.id) || {}).channels || []) if (c.value != null) row[c.name + (c.unit && c.unit !== '#' ? ' (' + c.unit + ')' : '')] = c.value;
      return row;
    });
  }

  // ------------------------------------------------------------------ widgets
  const WIDGETS = {
    status: { name: 'Sensor status', desc: 'Down, warning, up and paused sensors, optionally for one device group', params: ['group'] },
    gauges: { name: 'Gauges', desc: 'One gauge per device for a percentage sensor (CPU, memory, Linux…)', params: ['type', 'n'] },
    top: { name: 'Top-N bars', desc: 'Highest values of a sensor channel across devices', params: ['type', 'channel', 'n'] },
    volumes: { name: 'Fullest volumes', desc: 'Storage by volume across servers', params: ['n'] },
    graph: { name: 'Sensor graph', desc: 'History of one sensor (24 hours)', params: ['sensor'] },
    alarms: { name: 'Alarms', desc: 'Sensors that are down or in warning', params: ['n'] },
    tiles: { name: 'Device tiles', desc: 'Every device of a group as a coloured tile', params: ['group'] },
    kpi: { name: 'Number (KPI)', desc: 'Count, sum or average of a dataset, with filters', params: ['dataset', 'agg', 'filters'] },
    chart: { name: 'Chart', desc: 'A dataset grouped by a field, as bars, donut or columns', params: ['dataset', 'groupBy', 'agg', 'filters', 'chart', 'n'] },
    table: { name: 'Table', desc: 'Rows of a dataset with chosen columns, filters and sort', params: ['dataset', 'columns', 'filters', 'sort', 'n'] },
    report: { name: 'Saved report', desc: 'The chart and table of a saved report', params: ['report'] },
    metrics: { name: 'Sensor metrics', desc: 'Every sensor of one type with the channels you pick (values as of now)', params: ['type', 'channels', 'group', 'n'] },
    heading: { name: 'Heading', desc: 'A section title in a report', params: ['text'], layout: true },
    text: { name: 'Text', desc: 'A note, finding or recommendation', params: ['text'], layout: true },
  };
  const COLORS = ['--s1', '--s2', '--s3', '--s4'];
  const primaryOf = (s, name) => { const ch = (s.channels || []).filter((c) => c.value != null); return name ? ch.find((c) => c.name === name) : ch.find((c) => c.primary) || ch[0]; };
  const look = (s) => (s.ack && s.state === 'Down' ? 'Ack' : s.state);
  async function renderWidget(host, w, ctx) {
    const n = +w.n || 8;
    switch (w.type) {
      case 'status': {
        const devs = new Set(ctx.tree.devices.filter((d) => !w.group || MC.inGroup(d, w.group)).map((d) => d.id));
        const list = ctx.tree.sensors.filter((s) => devs.has(s.device));
        const c = list.reduce((a, s) => { a[s.state] = (a[s.state] || 0) + 1; if (s.ack && s.state === 'Down') a.Ack = (a.Ack || 0) + 1; return a; }, {});
        host.innerHTML = `<div class="wstat">${[['Down', (c.Down || 0) - (c.Ack || 0), '--crit'], ['Warning', c.Warning || 0, '--warn'], ['Up', c.Up || 0, '--ok'], ['Paused', c.Paused || 0, '--s1'], ['Unknown', c.Unknown || 0, '--muted']].map(([k, v, col]) => `<a href="#/sensors?state=${k}" class="${v ? '' : 'zero'}"><b style="color:var(${col})">${v}</b><small>${k}</small></a>`).join('')}</div>${C.statusStack({ Critical: (c.Down || 0) - (c.Ack || 0), Offline: c.Ack || 0, Warning: c.Warning || 0, OK: c.Up || 0, Unknown: (c.Unknown || 0) + (c.Paused || 0) }, { thin: true })}<div class="muted" style="font-size:12px;margin-top:6px">${list.length} sensors on ${devs.size} devices</div>`;
        return;
      }
      case 'gauges': case 'top': case 'volumes': {
        const list = await MC.monApi('channels', { type: w.type === 'volumes' ? 'wmi.disk' : w.sensorType || 'wmi.cpu' });
        if (w.type === 'gauges') {
          const pick = list.map((s) => ({ s, c: primaryOf(s, w.channel) })).map((x) => ({ s: x.s, c: x.c && x.c.unit === '%' ? x.c : (x.s.channels || []).find((c) => c.unit === '%') })).filter((x) => x.c && x.c.value != null).sort((a, b) => b.c.value - a.c.value).slice(0, n);
          host.innerHTML = pick.length ? `<div class="gauges wrap">${pick.map(({ s, c }) => `<a class="gauge-link" href="#/sensor/${encodeURIComponent(s.id)}">${C.gauge(c.value, { label: s.deviceName, warn: c.limits.warnHigh || 80, crit: c.limits.errHigh || 95 })}</a>`).join('')}</div>` : '<div class="muted">No percentage values for this sensor type yet.</div>';
        } else if (w.type === 'volumes') {
          host.innerHTML = MC.monVisuals(list, { withDevice: true, max: n }).volumes || '<div class="muted">No volume sensors yet.</div>';
        } else {
          const rows = list.map((s) => ({ s, c: primaryOf(s, w.channel) })).filter((x) => x.c && x.c.value != null).sort((a, b) => b.c.value - a.c.value).slice(0, n);
          const ST = { Down: 'Critical', Warning: 'Warning' };
          host.innerHTML = rows.length ? C.barList(rows.map(({ s, c }) => ({ label: s.deviceName, sub: s.name, value: c.value, text: c.text || fmt(c.value) + ' ' + (c.unit || ''), status: ST[c.state] || null, href: '#/sensor/' + encodeURIComponent(s.id) })), {}) : '<div class="muted">No values for this sensor type yet.</div>';
        }
        return;
      }
      case 'graph': {
        if (!w.sensor) { host.innerHTML = '<div class="muted">Pick a sensor in the widget settings.</div>'; return; }
        const d = await MC.monApi('sensor', { id: w.sensor });
        const h = d.history || {}, rows = (h.five && h.five.length > 3 ? h.five : h.live) || [];
        const series = (h.names || []).slice(0, 3).map((nm, i) => ({ name: nm, points: rows.filter((r) => r[i + 1] != null).map((r) => ({ t: r[0], v: +r[i + 1] })), color: COLORS[i] }));
        host.innerHTML = `<div class="muted" style="font-size:12px;margin-bottom:4px"><a href="#/sensor/${encodeURIComponent(d.id)}">${esc(d.deviceName)} · ${esc(d.name)}</a> ${pill(d.state)}</div><div data-g></div>`;
        const unit = ((d.channels || [])[0] || {}).unit;
        C.timeSeries($('[data-g]', host), series, { height: 150, unit: unit && unit !== '#' ? (unit === '%' ? '%' : ' ' + unit) : '' });
        return;
      }
      case 'alarms': {
        const devs = new Map(ctx.tree.devices.map((d) => [d.id, d.name]));
        const list = ctx.tree.sensors.filter((s) => s.state === 'Down' || s.state === 'Warning').sort((a, b) => (a.state === 'Down' ? 0 : 1) - (b.state === 'Down' ? 0 : 1) || String(b.since).localeCompare(String(a.since))).slice(0, n);
        host.innerHTML = list.length ? `<div class="walarms">${list.map((s) => `<a href="#/sensor/${encodeURIComponent(s.id)}" class="${look(s)}"><span class="sdot ${look(s)}"></span><b>${esc(devs.get(s.device) || '')}</b><span>${esc(s.name)}</span><small>${esc(s.message || '')} · ${ago(s.since)}</small></a>`).join('')}</div>` : `<div class="notice ok">${icon('check', 'sev-ico')} No alarms</div>`;
        return;
      }
      case 'tiles': {
        const devs = ctx.tree.devices.filter((d) => !w.group || MC.inGroup(d, w.group)).sort((a, b) => ['Down', 'Warning', 'Unknown', 'Up', 'Paused'].indexOf(a.state) - ['Down', 'Warning', 'Unknown', 'Up', 'Paused'].indexOf(b.state) || a.name.localeCompare(b.name));
        host.innerHTML = `<div class="dtiles">${devs.slice(0, 120).map((d) => `<a href="#/device/${encodeURIComponent(d.id)}" class="${d.paused ? 'Paused' : d.state}" title="${esc(d.name + ': ' + d.state + ' · ' + d.sensors + ' sensors')}">${esc(d.name)}</a>`).join('')}</div>`;
        return;
      }
      case 'kpi': {
        const rows = query(rowsOf(w.dataset), { filters: w.filters });
        const v = aggregate(rows, (w.agg || {}).fn || 'count', (w.agg || {}).field);
        const of = rowsOf(w.dataset).length;
        host.innerHTML = `<div class="wkpi"><b>${v == null ? '–' : fmt(v, (w.agg || {}).fn === 'avg' ? 1 : 0)}</b><small>${esc(w.unit || '')}${(w.agg || {}).fn === 'count' || !(w.agg || {}).fn ? ' of ' + of + ' rows' : ''} · ${esc(dsName(w.dataset))}</small></div>`;
        return;
      }
      case 'chart': {
        const rows = query(rowsOf(w.dataset), { filters: w.filters, groupBy: w.groupBy || fieldsOf(rowsOf(w.dataset))[0].name, agg: w.agg || { fn: 'count' } });
        drawChart(host, rows, w.chart || 'bar', n);
        return;
      }
      case 'table': {
        const rows = query(rowsOf(w.dataset), { filters: w.filters, sort: w.sort, dir: w.dir, limit: n });
        const cols = (w.columns && w.columns.length ? w.columns : fieldsOf(rows).slice(0, 5).map((f) => f.name));
        host.innerHTML = '';
        MC.table(host, rows, cols.map((c) => ({ key: c, label: c, val: (r) => val(r, c), html: (r) => cell(r[c]) })), { search: false, limit: n, name: 'widget-' + w.dataset });
        return;
      }
      case 'report': {
        const r = (ctx.reports || []).find((x) => x.id === w.report);
        if (!r) { host.innerHTML = '<div class="muted">This report was deleted or is not shared with you.</div>'; return; }
        const rows = await reportRows(r.spec);
        if (r.spec.chart && r.spec.chart !== 'none' && r.spec.groupBy) drawChart(host, rows, r.spec.chart, n);
        else { host.innerHTML = ''; MC.table(host, rows, Object.keys(rows[0] || {}).slice(0, 6).map((c) => ({ key: c, label: c, html: (x) => cell(x[c]) })), { search: false, limit: n, name: r.name }); }
        return;
      }
      case 'metrics': {
        const devs = new Set(ctx.tree.devices.filter((d) => !w.group || MC.inGroup(d, w.group)).map((d) => d.name));
        const rows = (await sensorRows(w.sensorType || 'wmi.cpu')).filter((r) => devs.has(r.Device));
        const chans = (w.channels && w.channels.length ? w.channels : chanNames(w.sensorType || 'wmi.cpu').slice(0, 3));
        const colOf = (r, c) => Object.keys(r).find((k) => k === c || k.startsWith(c + ' ('));
        const cols = ['Device', 'Sensor', 'State'].concat(chans.map((c) => (rows[0] && colOf(rows[0], c)) || c));
        host.innerHTML = '';
        MC.table(host, rows.slice(0, n), cols.map((c) => ({ key: c, label: c, n: typeof (rows[0] || {})[c] === 'number', val: (r) => r[c], html: (r) => cell(r[c]) })), { search: false, limit: n, name: 'metrics-' + (w.sensorType || '') });
        return;
      }
      case 'heading': host.innerHTML = ''; return;
      case 'text': host.innerHTML = `<div class="rtext">${esc(w.text || '').replace(/\n/g, '<br>')}</div>`; return;
      default: host.innerHTML = '<div class="muted">Unknown widget</div>';
    }
  }
  function cell(v) {
    if (v == null || v === '') return '<span class="muted">–</span>';
    if (typeof v === 'boolean') return v ? 'Yes' : 'No';
    if (typeof v === 'number') return fmt(v, Number.isInteger(v) ? 0 : 1);
    if (Array.isArray(v)) return esc(v.join(', '));
    if (/^\d{4}-\d\d-\d\dT/.test(v)) return `<span title="${esc(v)}">${ago(v)}</span>`;
    if (['OK', 'Warning', 'Critical', 'Down', 'Up', 'Unknown', 'Offline', 'Paused'].includes(v)) return pill(v === 'Down' ? 'Critical' : v === 'Up' ? 'OK' : v, v);
    return esc(v);
  }
  function drawChart(host, rows, kind, n) {
    const [gk, vk] = Object.keys(rows[0] || {});
    if (!gk) { host.innerHTML = '<div class="muted">No rows match.</div>'; return; }
    const items = rows.filter((r) => r[vk] != null).slice(0, n).map((r, i) => ({ label: String(r[gk]), value: +r[vk] || 0, i }));
    if (!items.length) { host.innerHTML = '<div class="muted">No values yet. They appear once the sensors have been scanned for a while.</div>'; return; }
    if (kind === 'donut') {
      const top = items.slice(0, 4);
      const rest = rows.slice(4).reduce((a, r) => a + (+r[vk] || 0), 0);
      C.donut(host, top.map((x, i) => ({ label: x.label, value: x.value, color: COLORS[i] })).concat(rest ? [{ label: 'Other', value: rest, color: '--muted' }] : []), { centerLabel: vk.toLowerCase() });
    } else if (kind === 'columns') {
      C.columns(host, items.map((x) => ({ label: x.label.length > 10 ? x.label.slice(0, 9) + '…' : x.label, title: x.label, values: { v: x.value } })), [{ key: 'v', name: vk, color: '--s1' }], { height: 170 });
    } else host.innerHTML = C.barList(items.map((x) => ({ label: x.label, value: x.value, text: fmt(x.value, Number.isInteger(x.value) ? 0 : 1) })), {});
  }

  // ------------------------------------------------------------------ built-in dashboards, one per area
  const W = (type, title, extra, w) => Object.assign({ type, title, w: w || 1 }, extra || {});
  const BUILTIN = [
    { id: 'b:noc', name: 'Operations (NOC)', area: 'All areas', widgets: [W('status', 'All sensors'), W('alarms', 'Current alarms', { n: 8 }, 2), W('gauges', 'Busiest CPUs', { sensorType: 'wmi.cpu', n: 8 }, 2), W('kpi', 'Servers pending reboot', { dataset: 'security.patches', filters: [{ field: 'PendingReboot', op: 'true' }] }), W('volumes', 'Fullest volumes', { n: 8 }, 2), W('top', 'Busiest network links', { sensorType: 'snmp.traffic', n: 8 })] },
    { id: 'b:servers', name: 'Servers', area: 'Compute, storage, services', widgets: [W('gauges', 'CPU load', { sensorType: 'wmi.cpu', n: 12 }, 3), W('gauges', 'Memory used', { sensorType: 'wmi.memory', n: 12 }, 3), W('volumes', 'Storage by volume', { n: 12 }, 2), W('top', 'Network traffic', { sensorType: 'wmi.network', n: 10 }), W('chart', 'Stopped automatic services', { dataset: 'servers.services', groupBy: 'ComputerName', filters: [{ field: 'Problem', op: 'notempty' }], chart: 'bar' }), W('chart', 'Event log errors (24 h)', { dataset: 'servers.events', groupBy: 'ComputerName', agg: { fn: 'sum', field: 'Errors' }, chart: 'bar' }), W('tiles', 'Servers', { group: 'g:srv' })] },
    { id: 'b:storage', name: 'Storage', area: 'Volumes, clusters, file servers', widgets: [W('volumes', 'Fullest volumes', { n: 14 }, 2), W('kpi', 'Volumes over 85% used', { dataset: 'servers.disks', filters: [{ field: 'UsedPct', op: '>', value: 85 }] }), W('chart', 'Free space per server (GB)', { dataset: 'servers.disks', groupBy: 'ComputerName', agg: { fn: 'sum', field: 'FreeGB' }, chart: 'columns', n: 12 }, 2), W('table', 'Cluster shared volumes', { dataset: 'virtualization.clusterstorage', columns: ['Cluster', 'Name', 'SizeGB', 'FreeGB', 'UsedPct', 'Status'], sort: 'UsedPct', n: 8 }), W('table', 'File servers', { dataset: 'fileserver.health', columns: ['ComputerName', 'Sessions', 'OpenFiles', 'LowestFreePct', 'ShadowCopyAgeHours'], n: 6 }, 3)] },
    { id: 'b:network', name: 'Network', area: 'Switches, firewalls, DHCP, DNS', widgets: [W('top', 'Busiest interfaces', { sensorType: 'snmp.traffic', n: 10 }, 2), W('status', 'Network devices', { group: 'g:net' }), W('tiles', 'Network devices', { group: 'g:net' }, 2), W('chart', 'DHCP scope use', { dataset: 'network.dhcp', groupBy: 'Name', agg: { fn: 'max', field: 'PercentInUse' }, chart: 'bar' }), W('top', 'Ping round trip', { sensorType: 'ping', n: 10 }), W('chart', 'Discovered device classes', { dataset: 'network.discovery', groupBy: 'DeviceClass', chart: 'donut' }), W('table', 'DNS servers', { dataset: 'dns.servers', columns: ['ComputerName', 'ServiceState', 'Zones', 'ResolveMs', 'FailedTests', 'Errors24h'], n: 6 })] },
    { id: 'b:ad', name: 'Active Directory', area: 'DCs, replication, accounts', widgets: [W('status', 'Domain controllers', { group: 'g:dc' }), W('kpi', 'Failing replication links', { dataset: 'ad.replication', filters: [{ field: 'Status', op: '=', value: 'Critical' }] }), W('kpi', 'Locked-out users', { dataset: 'ad.users', filters: [{ field: 'LockedOut', op: 'true' }] }), W('chart', 'Users by department', { dataset: 'ad.users', groupBy: 'Department', chart: 'bar', n: 8 }), W('chart', 'Computers by OS', { dataset: 'ad.computers', groupBy: 'OperatingSystem', chart: 'donut' }), W('kpi', 'Stale computer accounts', { dataset: 'ad.computers', filters: [{ field: 'Stale', op: 'true' }] }), W('table', 'Group Policy issues', { dataset: 'ad.gpo', columns: ['Name', 'Links', 'Versions', 'VersionMismatch', 'Empty'], filters: [{ field: 'Links', op: '<', value: 1 }], n: 6 }, 2), W('chart', 'Privileged group members', { dataset: 'ad.groups', groupBy: 'Group', filters: [{ field: 'Privileged', op: 'true' }], chart: 'bar' })] },
    { id: 'b:security', name: 'Security', area: 'Patching, Defender, firewall, audit', widgets: [W('kpi', 'Servers missing updates', { dataset: 'security.patches', filters: [{ field: 'PendingUpdates', op: '>', value: 0 }] }), W('kpi', 'Defender issues', { dataset: 'security.defender', filters: [{ field: 'Status', op: '!=', value: 'OK' }] }), W('kpi', 'Firewall profiles off', { dataset: 'security.firewall', filters: [{ field: 'Issues', op: 'notempty' }] }), W('chart', 'Days since last patch', { dataset: 'security.patches', groupBy: 'ComputerName', agg: { fn: 'max', field: 'DaysSincePatch' }, chart: 'bar', n: 10 }), W('chart', 'Audit events by type', { dataset: 'audit.events', groupBy: 'EventSet', chart: 'bar', n: 10 }), W('chart', 'Failed logons by source', { dataset: 'audit.events', groupBy: 'SourceIP', filters: [{ field: 'EventSet', op: '=', value: 'BadLogon' }], chart: 'bar', n: 8 })] },
    { id: 'b:virt', name: 'Virtualization', area: 'Hyper-V, VMware, clusters', widgets: [W('chart', 'VMware host CPU %', { dataset: 'virtualization.vmware', groupBy: 'Name', agg: { fn: 'max', field: 'CPUUsedPct' }, filters: [{ field: 'Kind', op: '=', value: 'Host' }], chart: 'bar' }), W('chart', 'VMware host memory %', { dataset: 'virtualization.vmware', groupBy: 'Name', agg: { fn: 'max', field: 'MemoryUsedPct' }, filters: [{ field: 'Kind', op: '=', value: 'Host' }], chart: 'bar' }), W('chart', 'Hyper-V VMs per host', { dataset: 'virtualization.hyperv', groupBy: 'Name', agg: { fn: 'sum', field: 'VMCount' }, filters: [{ field: 'Kind', op: '=', value: 'Host' }], chart: 'columns' }), W('table', 'Clusters', { dataset: 'virtualization.clusters', columns: ['Cluster', 'Nodes', 'NodesUp', 'Roles', 'Status'], n: 6 }, 3)] },
    { id: 'b:linux', name: 'Linux', area: 'SSH collector', widgets: [W('gauges', 'Linux CPU and memory', { sensorType: 'ssh.linux', n: 12 }, 3), W('chart', 'Security updates', { dataset: 'linux.hosts', groupBy: 'Name', agg: { fn: 'sum', field: 'securityUpdates' }, chart: 'bar' }), W('chart', 'Failed systemd units', { dataset: 'linux.hosts', groupBy: 'Name', agg: { fn: 'sum', field: 'failedUnits' }, chart: 'bar' }), W('tiles', 'Linux hosts', { group: 'g:lnx' })] },
    { id: 'b:workstations', name: 'Workstations', area: 'Fleet, OS, hardware', widgets: [W('kpi', 'Workstations online', { dataset: 'inventory.workstations', filters: [{ field: 'Online', op: 'true' }] }), W('kpi', 'Out of support OS', { dataset: 'inventory.workstations', filters: [{ field: 'OperatingSystem', op: 'contains', value: 'Windows 7' }] }), W('kpi', 'Without TPM', { dataset: 'inventory.workstations', filters: [{ field: 'TPMEnabled', op: 'false' }] }), W('chart', 'Operating systems', { dataset: 'inventory.workstations', groupBy: 'OperatingSystem', chart: 'donut' }), W('chart', 'Per site', { dataset: 'inventory.workstations', groupBy: 'ADSite', chart: 'bar' }), W('chart', 'Memory (GB)', { dataset: 'inventory.workstations', groupBy: 'RAMGB', chart: 'columns' })] },
    { id: 'b:printers', name: 'Printers and SQL', area: 'Print fleet and databases', widgets: [W('chart', 'Printer health', { dataset: 'printers.health', groupBy: 'Health', chart: 'donut' }), W('table', 'Stuck print jobs', { dataset: 'printers.health', columns: ['Printer', 'PrintServer', 'Jobs', 'StuckJobs', 'Health'], filters: [{ field: 'StuckJobs', op: '>', value: 0 }], n: 8 }, 2), W('chart', 'Largest databases (MB)', { dataset: 'sql.databases', groupBy: 'Database', agg: { fn: 'max', field: 'SizeMB' }, chart: 'bar', n: 8 }, 2), W('kpi', 'Databases without a recent full backup', { dataset: 'sql.databases', filters: [{ field: 'FullBackupAgeHours', op: '>', value: 26 }] })] },
  ];

  // ------------------------------------------------------------------ dashboards view
  const ui = { edit: false };
  V.dashboards = {
    title: 'Dashboards',
    crumb: () => 'built-in dashboards for every area, and your own',
    render(el, route) {
      el.innerHTML = '<div class="notice">Loading…</div>';
      Promise.all([MC.api.insights('dashboards').catch(() => []), MC.api.insights('reports').catch(() => []), MC.monTree(true), loadVirtual()]).then(([mine, reports, tree]) => {
        const all = BUILTIN.map((b) => Object.assign({ builtin: true, spec: { widgets: b.widgets } }, b)).concat(mine);
        const cur = all.find((d) => d.id === decodeURIComponent(route.tab || '')) || all[0];
        const ctx = { tree, reports, el, route };
        const editable = !cur.builtin && cur.editable;
        el.innerHTML = `
          <div class="dashbar">
            <select class="input" id="dSel" aria-label="Dashboard">${['Built-in', 'Mine and shared'].map((grp, gi) => `<optgroup label="${grp}">${all.filter((d) => !!d.builtin === !gi).map((d) => `<option value="${esc(d.id)}" ${d.id === cur.id ? 'selected' : ''}>${esc(d.name)}${d.shared && !d.builtin ? ' (shared)' : ''}</option>`).join('')}</optgroup>`).join('')}</select>
            <span class="muted hide-sm" style="font-size:12.5px">${esc(cur.builtin ? cur.area : (cur.owner === MC.user.name ? 'yours' : 'by ' + cur.owner) + (cur.shared ? ' · shared' : ' · private'))}</span>
            <span class="spacer"></span>
            ${editable ? `<button class="btn sm ${ui.edit ? 'on' : ''}" id="dEdit">${ui.edit ? 'Done' : 'Edit'}</button>` : ''}
            ${ui.edit && editable ? `<button class="btn sm primary" id="dAdd">Add widget</button><button class="btn sm" id="dProps">Name & sharing</button><button class="btn sm ghost" id="dDel">Delete</button>` : ''}
            <button class="btn sm" id="dCopy">${cur.builtin ? 'Customise a copy' : 'Duplicate'}</button>
            <button class="btn sm primary" id="dNew">New dashboard</button>
          </div>
          <div class="dgrid${ui.edit && editable ? ' editing' : ''}" id="dg">${(cur.spec.widgets || []).map((w, i) => `<section class="card widget w${Math.min(3, w.w || 1)}" data-i="${i}"><div class="panel-h"><h3>${esc(w.title || WIDGETS[w.type].name)}</h3>${ui.edit && editable ? `<div class="act"><button class="btn sm ghost" data-mv="-1" aria-label="Move left">←</button><button class="btn sm ghost" data-mv="1" aria-label="Move right">→</button><button class="btn sm ghost" data-sz aria-label="Change width">${w.w || 1}/3</button><button class="btn sm ghost" data-we>Edit</button><button class="btn sm ghost" data-wr aria-label="Remove widget">${icon('x', 'sev-ico')}</button></div>` : ''}</div><div class="wbody"><div class="muted">Loading…</div></div></section>`).join('') || '<div class="notice">This dashboard is empty. Choose Edit, then Add widget.</div>'}</div>`;
        $('#dSel', el).addEventListener('change', (e) => { ui.edit = false; MC.go('dashboards', e.target.value); });
        const drawAll = () => $$('.widget', el).forEach((sec) => { const w = cur.spec.widgets[+sec.dataset.i]; renderWidget($('.wbody', sec), w, ctx).catch((e) => { $('.wbody', sec).innerHTML = `<div class="muted">${esc(e.message)}</div>`; }); });
        drawAll();
        const save = async (msg) => { try { await MC.api.saveInsight('dashboards', { id: cur.id, name: cur.name, description: cur.description, shared: cur.shared, spec: cur.spec }); if (msg) MC.toast(msg, 'ok'); V.dashboards.render(el, route); } catch (e) { MC.toast(esc(e.message), 'err'); } };
        if ($('#dEdit', el)) $('#dEdit', el).addEventListener('click', () => { ui.edit = !ui.edit; V.dashboards.render(el, route); });
        $('#dNew', el).addEventListener('click', () => propsDialog({ name: '', shared: false, spec: { widgets: [W('status', 'All sensors'), W('alarms', 'Current alarms', { n: 6 }, 2)] } }, (d) => { ui.edit = true; MC.go('dashboards', d.id); }));
        $('#dCopy', el).addEventListener('click', () => propsDialog({ name: cur.name + (cur.builtin ? '' : ' (copy)'), shared: false, spec: JSON.parse(JSON.stringify(cur.spec)) }, (d) => { ui.edit = true; MC.go('dashboards', d.id); }));
        if ($('#dProps', el)) $('#dProps', el).addEventListener('click', () => propsDialog(cur, () => V.dashboards.render(el, route)));
        if ($('#dDel', el)) $('#dDel', el).addEventListener('click', () => modal(`<h3>Delete ${esc(cur.name)}?</h3><div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn danger" id="go">Delete</button></div>`, (m, close) => { $('#go', m).addEventListener('click', () => MC.api.removeInsight('dashboards', cur.id).then(() => { close(); ui.edit = false; MC.go('dashboards'); }).catch((e) => errBox(m, e))); }));
        if ($('#dAdd', el)) $('#dAdd', el).addEventListener('click', () => widgetDialog(null, ctx, (w) => { cur.spec.widgets.push(w); save('Widget added'); }));
        $$('.widget', el).forEach((sec) => {
          const i = +sec.dataset.i, list = cur.spec.widgets;
          $$('[data-mv]', sec).forEach((b) => b.addEventListener('click', () => { const j = i + +b.dataset.mv; if (j < 0 || j >= list.length) return; [list[i], list[j]] = [list[j], list[i]]; save(); }));
          const sz = $('[data-sz]', sec); if (sz) sz.addEventListener('click', () => { list[i].w = ((list[i].w || 1) % 3) + 1; save(); });
          const we = $('[data-we]', sec); if (we) we.addEventListener('click', () => widgetDialog(list[i], ctx, (w) => { list[i] = w; save('Widget saved'); }));
          const wr = $('[data-wr]', sec); if (wr) wr.addEventListener('click', () => { list.splice(i, 1); save('Widget removed'); });
        });
        clearInterval(V._dashTimer);
        const seq = MC.renderSeq;
        V._dashTimer = setInterval(async () => { if (!document.body.contains(el) || MC.renderSeq !== seq) return clearInterval(V._dashTimer); if ($('.modal') || ui.edit) return; ctx.tree = await MC.monTree(true); drawAll(); }, 30000);
      }).catch((e) => { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
    },
  };
  function propsDialog(d, done) {
    modal(`<h3>${d.id ? 'Name and sharing' : 'New dashboard'}</h3>
      <div class="field"><label for="pn">Name</label><input class="input" id="pn" value="${esc(d.name || '')}"></div>
      <div class="field"><label for="pd">Description</label><input class="input" id="pd" value="${esc(d.description || '')}"></div>
      <label class="check"><input type="checkbox" id="ps" ${d.shared ? 'checked' : ''} ${canShare() ? '' : 'disabled'}> Share with everyone who signs in${canShare() ? '' : ' (contributors and admins can share)'}</label>
      <div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Save</button></div>`, (m, close) => {
      $('#go', m).addEventListener('click', () => MC.api.saveInsight('dashboards', { id: d.id, name: $('#pn', m).value, description: $('#pd', m).value, shared: $('#ps', m).checked, spec: d.spec }).then((x) => { close(); MC.toast('Saved ' + esc(x.name), 'ok'); done(x); }).catch((e) => errBox(m, e)));
    });
  }

  // metrics of a sensor type: declared channels, else the channels its sensors report (collector sensors)
  const BASE_COLS = ['Device', 'Group', 'Sensor', 'Type', 'State', 'Value', 'Uptime %', 'Message', 'Last scan', 'Since'];
  function chanNames(type) {
    const decl = ((S.TYPE[type] || {}).channels || []).map((c) => c.name);
    if (decl.length) return decl;
    const seen = new Set();
    for (const r of (VDS['mc.sensors'] || []).filter((x) => x.Type === type).slice(0, 200)) for (const k of Object.keys(r)) if (!BASE_COLS.includes(k)) seen.add(k.replace(/ \([^)]*\)$/, ''));
    return [...seen];
  }
  // data sources grouped: MonCastle's own (sensors by type, alarms, engines, jobs, audit) and what the engines collect
  function dsOptions(cur) {
    const types = [...new Set((VDS['mc.sensors'] || []).map((r) => r.Type))].sort((a, b) => dsName('mc.sensors:' + a).localeCompare(dsName('mc.sensors:' + b)));
    const opt = (k) => `<option value="${esc(k)}" ${k === cur ? 'selected' : ''}>${esc(dsName(k))}</option>`;
    return `<optgroup label="MonCastle">${['mc.sensors', 'mc.devices', 'mc.alarms', 'mc.engines', 'mc.jobruns', 'mc.audit'].filter((k) => (VDS[k] || []).length).map(opt).join('')}</optgroup>
      <optgroup label="Sensors by type">${types.map((t) => opt('mc.sensors:' + t)).join('')}</optgroup>
      <optgroup label="Collected by the engines">${Object.keys(MC.ds).filter((k) => (MC.ds[k].data || []).length).sort((a, b) => dsName(a).localeCompare(dsName(b))).map(opt).join('')}</optgroup>`;
  }
  // widget editor: a type, then only the settings that type needs
  const TYPE_OPTS = () => S.TYPES.map((t) => `<option value="${t.id}">${esc(t.category + ' · ' + t.name)}</option>`).join('');
  function filterRows(fields, filters) {
    const row = (f) => `<div class="frow"><select class="input" data-ff aria-label="Field"><option value="">Field…</option>${fields.map((x) => `<option ${f.field === x.name ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select><select class="input" data-fo aria-label="Condition">${OPS.map(([k, l]) => `<option value="${k}" ${f.op === k ? 'selected' : ''}>${l}</option>`).join('')}</select><input class="input" data-fv value="${esc(f.value ?? '')}" aria-label="Value"><button type="button" class="btn sm ghost" data-frm aria-label="Remove filter">${icon('x', 'sev-ico')}</button></div>`;
    return `<div data-filters>${(filters || []).map(row).join('')}</div><button type="button" class="btn sm" data-fadd>Add filter</button>`;
  }
  function wireFilters(box, fields) {
    const wire = () => $$('[data-frm]', box).forEach((b) => (b.onclick = () => b.parentElement.remove()));
    wire();
    $('[data-fadd]', box).onclick = () => { $('[data-filters]', box).insertAdjacentHTML('beforeend', filterRows(fields, [{ field: '', op: '=', value: '' }]).replace(/<\/div><button[\s\S]*$/, '').replace(/^<div data-filters>/, '')); wire(); };
  }
  const readFilters = (box) => $$('.frow', box).map((r) => ({ field: $('[data-ff]', r).value, op: $('[data-fo]', r).value, value: $('[data-fv]', r).value })).filter((f) => f.field);
  function widgetDialog(w, ctx, done) {
    w = JSON.parse(JSON.stringify(w || { type: 'status', w: 1 }));
    modal(`<h3>${w.title ? 'Edit ' + (ctx.forReport ? 'item' : 'widget') : ctx.forReport ? 'Add a report item' : 'Add a widget'}</h3>
      <div class="field"><label for="wt">Widget</label><select class="input" id="wt">${Object.entries(WIDGETS).map(([k, x]) => `<option value="${k}" ${w.type === k ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select><span class="hint" id="wtd"></span></div>
      <div class="field"><label for="wn">Title</label><input class="input" id="wn" value="${esc(w.title || '')}"></div>
      <div id="wp"></div>
      <div class="field"><label for="ww">Width</label><select class="input" id="ww">${[1, 2, 3].map((n) => `<option value="${n}" ${(w.w || 1) === n ? 'selected' : ''}>${n} of 3 columns</option>`).join('')}</select></div>
      <div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">${ctx.forReport ? 'Save item' : 'Save widget'}</button></div>`, (m, close) => {
      m.querySelector('.card').classList.add('wide');
      const params = () => {
        const type = $('#wt', m).value, P = WIDGETS[type].params, ds = w.dataset && rowsOf(w.dataset).length ? w.dataset : datasets()[0];
        $('#wtd', m).textContent = WIDGETS[type].desc;
        const fields = fieldsOf(rowsOf(ds));
        const sensors = ctx.tree.sensors.slice().sort((a, b) => a.name.localeCompare(b.name));
        const devs = new Map(ctx.tree.devices.map((d) => [d.id, d.name]));
        $('#wp', m).innerHTML = [
          P.includes('group') ? `<div class="field"><label for="wg">Device group</label><select class="input" id="wg"><option value="">All device groups</option>${ctx.tree.groups.map((g) => `<option value="${esc(g.id)}" ${w.group === g.id ? 'selected' : ''}>${esc(g.name)}</option>`).join('')}</select></div>` : '',
          P.includes('type') ? `<div class="field"><label for="wy">Sensor type</label><select class="input" id="wy">${TYPE_OPTS()}</select></div>` : '',
          P.includes('channel') ? `<div class="field"><label for="wc">Metric (channel)</label><select class="input" id="wc"></select></div>` : '',
          P.includes('channels') ? `<fieldset><legend>Metrics (channels)</legend><div class="optgrid" id="wchs"></div></fieldset>` : '',
          P.includes('text') ? (type === 'heading' ? `<div class="field"><label for="wtx">Heading</label><input class="input" id="wtx" value="${esc(w.text || '')}" placeholder="Availability"></div>` : `<div class="field"><label for="wtx">Text</label><textarea class="input" id="wtx" rows="5" placeholder="Findings, actions taken, recommendations">${esc(w.text || '')}</textarea></div>`) : '',
          P.includes('sensor') ? `<div class="field"><label for="wsn">Sensor</label><select class="input" id="wsn">${sensors.map((s) => `<option value="${esc(s.id)}" ${w.sensor === s.id ? 'selected' : ''}>${esc((devs.get(s.device) || '') + ' · ' + s.name)}</option>`).join('')}</select></div>` : '',
          P.includes('dataset') ? `<div class="field"><label for="wd">Data</label><select class="input" id="wd">${dsOptions(ds)}</select></div>` : '',
          P.includes('groupBy') ? `<div class="field"><label for="wgb">Group by</label><select class="input" id="wgb">${fields.map((f) => `<option ${w.groupBy === f.name ? 'selected' : ''}>${esc(f.name)}</option>`).join('')}</select></div>` : '',
          P.includes('agg') ? `<div class="field"><label>Value</label><div class="toolbar" style="margin:0"><select class="input" id="waf">${Object.entries(AGG).map(([k, l]) => `<option value="${k}" ${((w.agg || {}).fn || 'count') === k ? 'selected' : ''}>${l}</option>`).join('')}</select><select class="input" id="wafd"><option value="">of field…</option>${fields.filter((f) => f.type === 'number').map((f) => `<option ${(w.agg || {}).field === f.name ? 'selected' : ''}>${esc(f.name)}</option>`).join('')}</select></div></div>` : '',
          P.includes('chart') ? `<div class="field"><label for="wch">Chart</label><select class="input" id="wch">${[['bar', 'Bars'], ['donut', 'Donut'], ['columns', 'Columns']].map(([k, l]) => `<option value="${k}" ${w.chart === k ? 'selected' : ''}>${l}</option>`).join('')}</select></div>` : '',
          P.includes('columns') ? `<fieldset><legend>Columns</legend><div class="optgrid">${fields.map((f) => `<label class="check"><input type="checkbox" data-col="${esc(f.name)}" ${(w.columns || fields.slice(0, 5).map((x) => x.name)).includes(f.name) ? 'checked' : ''}> ${esc(f.name)}</label>`).join('')}</div></fieldset>` : '',
          P.includes('sort') ? `<div class="field"><label for="wso">Sort by</label><div class="toolbar" style="margin:0"><select class="input" id="wso"><option value="">(none)</option>${fields.map((f) => `<option ${w.sort === f.name ? 'selected' : ''}>${esc(f.name)}</option>`).join('')}</select><select class="input" id="wdi"><option value="desc">Highest first</option><option value="asc" ${w.dir === 'asc' ? 'selected' : ''}>Lowest first</option></select></div></div>` : '',
          P.includes('filters') ? `<fieldset style="margin-top:8px"><legend>Filters</legend>${filterRows(fields, w.dataset === ds ? w.filters : [])}</fieldset>` : '',
          P.includes('report') ? `<div class="field"><label for="wre">Report</label><select class="input" id="wre">${(ctx.reports || []).map((r) => `<option value="${esc(r.id)}" ${w.report === r.id ? 'selected' : ''}>${esc(r.name)}</option>`).join('') || '<option value="">No saved reports yet</option>'}</select></div>` : '',
          P.includes('n') ? `<div class="field"><label for="wnn">How many</label><input class="input" id="wnn" type="number" min="1" max="50" value="${+w.n || 8}"></div>` : '',
        ].join('');
        if ($('#wy', m)) $('#wy', m).value = w.sensorType || (type === 'top' ? 'wmi.network' : 'wmi.cpu');
        // metrics follow the chosen sensor type
        const chanOpts = () => { const ch = chanNames($('#wy', m) ? $('#wy', m).value : w.sensorType);
          if ($('#wc', m)) $('#wc', m).innerHTML = '<option value="">Primary metric</option>' + ch.map((c) => `<option ${w.channel === c ? 'selected' : ''}>${esc(c)}</option>`).join('');
          if ($('#wchs', m)) $('#wchs', m).innerHTML = ch.map((c, i) => `<label class="check"><input type="checkbox" data-ch="${esc(c)}" ${(w.channels && w.channels.length ? w.channels.includes(c) : i < 3) ? 'checked' : ''}> ${esc(c)}</label>`).join('') || '<span class="muted">This sensor type has no metrics.</span>'; };
        chanOpts();
        if ($('#wy', m)) $('#wy', m).addEventListener('change', () => { w.channel = ''; w.channels = null; chanOpts(); });
        if ($('[data-fadd]', m)) wireFilters($('#wp', m), fields);
        if ($('#wd', m)) $('#wd', m).addEventListener('change', (e) => { w.dataset = e.target.value; w.filters = []; w.columns = null; params(); });
      };
      params();
      $('#wt', m).addEventListener('change', () => { w.type = $('#wt', m).value; params(); });
      $('#go', m).addEventListener('click', () => {
        const g = (id) => ($(id, m) ? $(id, m).value : undefined);
        const out = { type: $('#wt', m).value, title: $('#wn', m).value.trim() || ($('#wt', m).value === 'heading' ? ($('#wtx', m) || {}).value || 'Section' : WIDGETS[$('#wt', m).value].layout ? '' : WIDGETS[$('#wt', m).value].name), w: +$('#ww', m).value };
        if (g('#wg') !== undefined) out.group = g('#wg');
        if (g('#wy')) out.sensorType = g('#wy');
        if (g('#wc')) out.channel = g('#wc');
        if ($('#wchs', m)) out.channels = $$('[data-ch]:checked', m).map((c) => c.dataset.ch);
        if (g('#wtx') !== undefined) out.text = g('#wtx');
        if (g('#wsn')) out.sensor = g('#wsn');
        if (g('#wd')) out.dataset = g('#wd');
        if (g('#wgb')) out.groupBy = g('#wgb');
        if (g('#waf')) out.agg = { fn: g('#waf'), field: g('#wafd') || undefined };
        if (g('#wch')) out.chart = g('#wch');
        if ($('[data-col]', m)) out.columns = $$('[data-col]:checked', m).map((c) => c.dataset.col);
        if (g('#wso')) { out.sort = g('#wso'); out.dir = g('#wdi'); }
        if ($('[data-filters]', m)) out.filters = readFilters(m);
        if (g('#wre')) out.report = g('#wre');
        if (g('#wnn')) out.n = Math.max(1, Math.min(50, +g('#wnn')));
        if (out.agg && out.agg.fn !== 'count' && !out.agg.field) return errBox(m, new Error('Pick the field to ' + AGG[out.agg.fn].toLowerCase() + '.'));
        close(); done(out);
      });
    });
  }

  // ================================================================== REPORTS
  const TEMPLATES = [
    { id: 't:disk', name: 'Volumes low on space', spec: { source: 'servers.disks', columns: ['ComputerName', 'Volume', 'Label', 'SizeGB', 'FreeGB', 'UsedPct', 'Status'], filters: [{ field: 'UsedPct', op: '>', value: 80 }], sort: 'UsedPct', dir: 'desc', chart: 'none' } },
    { id: 't:avail', name: 'Sensor availability', spec: { source: 'sensors', columns: ['Device', 'Group', 'Sensor', 'State', 'Uptime %', 'Since'], filters: [], groupBy: 'Group', agg: { fn: 'avg', field: 'Uptime %' }, chart: 'bar' } },
    { id: 't:patch', name: 'Servers missing updates', spec: { source: 'security.patches', columns: ['ComputerName', 'OS', 'LastPatched', 'DaysSincePatch', 'PendingUpdates', 'PendingReboot', 'Status'], filters: [{ field: 'PendingUpdates', op: '>', value: 0 }], sort: 'DaysSincePatch', dir: 'desc', chart: 'none' } },
    { id: 't:stale', name: 'Stale AD users', spec: { source: 'ad.users', columns: ['SamAccountName', 'DisplayName', 'Department', 'LastLogonDate', 'PasswordAgeDays', 'Enabled'], filters: [{ field: 'Stale', op: 'true' }, { field: 'Enabled', op: 'true' }], groupBy: '', chart: 'none', sort: 'PasswordAgeDays' } },
    { id: 't:sw', name: 'Software by vendor', spec: { source: 'inventory.software', columns: ['ComputerName', 'Name', 'Version', 'Vendor'], filters: [], groupBy: 'Vendor', agg: { fn: 'count' }, chart: 'bar' } },
    { id: 't:ws', name: 'Workstations out of support', spec: { source: 'inventory.workstations', columns: ['Name', 'OperatingSystem', 'Model', 'ADSite', 'LoggedOnUser', 'LastSeen'], filters: [{ field: 'OperatingSystem', op: 'contains', value: 'Windows 10' }], groupBy: 'ADSite', agg: { fn: 'count' }, chart: 'columns' } },
    { id: 't:lock', name: 'Lockouts and failed logons (audit)', spec: { source: 'audit.events', columns: ['Time', 'EventSet', 'Target', 'Server', 'SourceIP', 'Workstation'], filters: [{ field: 'EventSet', op: 'contains', value: 'o' }, { field: 'Time', op: 'days<', value: 7 }], groupBy: 'EventSet', agg: { fn: 'count' }, chart: 'donut' } },
  ];
  async function reportRows(spec) {
    if (spec.source === 'sensors' || /^sensors:/.test(spec.source)) return query(await sensorRows(spec.source.split(':')[1] || null), spec);
    return query(rowsOf(spec.source), spec);
  }
  // ------------------------------------------------------------------ RoboMate reports: one per area, modern and printable
  const RM = [
    { id: 'rm:monitoring', name: 'Monitoring and availability', icon: 'activity', area: 'Monitoring', desc: 'Sensor states, open alarms, availability by group, capacity hot spots and the latest state changes.', items: [
      W('heading', 'Summary', { text: 'Summary' }, 3), W('status', 'All sensors'), W('kpi', 'Devices down', { dataset: 'mc.devices', filters: [{ field: 'State', op: '=', value: 'Down' }] }), W('kpi', 'Average sensor uptime', { dataset: 'mc.sensors', agg: { fn: 'avg', field: 'Uptime %' }, unit: '%' }),
      W('alarms', 'Open alarms', { n: 10 }, 2), W('chart', 'Availability by device group (%)', { dataset: 'mc.sensors', groupBy: 'Group', agg: { fn: 'avg', field: 'Uptime %' }, chart: 'bar', n: 10 }),
      W('heading', 'Capacity', { text: 'Capacity' }, 3), W('gauges', 'Busiest CPUs', { sensorType: 'wmi.cpu', n: 8 }, 2), W('chart', 'Sensors by state', { dataset: 'mc.sensors', groupBy: 'State', chart: 'donut' }), W('volumes', 'Fullest volumes', { n: 10 }, 2), W('top', 'Busiest network links', { sensorType: 'snmp.traffic', n: 8 }),
      W('heading', 'Changes', { text: 'State changes' }, 3), W('chart', 'Devices with the most outages', { dataset: 'mc.alarms', groupBy: 'Device', filters: [{ field: 'To', op: '=', value: 'Down' }], chart: 'bar', n: 10 }), W('table', 'Latest state changes', { dataset: 'mc.alarms', columns: ['Time', 'Device', 'Sensor', 'From', 'To', 'Message'], sort: 'Time', dir: 'desc', n: 15 }, 2)] },
    { id: 'rm:inventory', name: 'Inventory', icon: 'box', area: 'Inventory', desc: 'Servers, workstations, software, operating systems and update state across the estate.', items: [
      W('kpi', 'Servers', { dataset: 'inventory.hardware' }), W('kpi', 'Workstations', { dataset: 'inventory.workstations' }), W('kpi', 'Monitored devices', { dataset: 'mc.devices' }),
      W('heading', 'Servers', { text: 'Servers' }, 3), W('chart', 'Server operating systems', { dataset: 'inventory.hardware', groupBy: 'OperatingSystem', chart: 'donut' }), W('chart', 'Server hardware vendors', { dataset: 'inventory.hardware', groupBy: 'Manufacturer', chart: 'bar' }), W('chart', 'Monitored devices by kind', { dataset: 'mc.devices', groupBy: 'Kind', chart: 'bar' }),
      W('table', 'Server hardware', { dataset: 'inventory.hardware', columns: ['Name', 'Manufacturer', 'Model', 'SerialNumber', 'OperatingSystem', 'UptimeDays'], sort: 'Name', dir: 'asc', n: 20 }, 3),
      W('heading', 'Workstations', { text: 'Workstations' }, 3), W('chart', 'Workstation operating systems', { dataset: 'inventory.workstations', groupBy: 'OperatingSystem', chart: 'donut' }), W('chart', 'Workstations per site', { dataset: 'inventory.workstations', groupBy: 'ADSite', chart: 'bar' }), W('chart', 'Memory (GB)', { dataset: 'inventory.workstations', groupBy: 'RAMGB', chart: 'columns' }),
      W('heading', 'Software and updates', { text: 'Software and updates' }, 3), W('chart', 'Software by vendor', { dataset: 'inventory.software', groupBy: 'Vendor', chart: 'bar', n: 10 }), W('table', 'Systems behind on updates', { dataset: 'updates.status', columns: ['Name', 'OS', 'Version', 'PendingUpdates', 'DaysSinceUpdate', 'Status'], filters: [{ field: 'PendingUpdates', op: '>', value: 0 }], sort: 'DaysSinceUpdate', dir: 'desc', n: 12 }, 2)] },
    { id: 'rm:audit', name: 'Auditing and security', icon: 'audit', area: 'Auditing', desc: 'Failed logons, lockouts, privileged changes, risky permissions and what people did in the console.', items: [
      W('kpi', 'Failed logons (7 days)', { dataset: 'audit.events', filters: [{ field: 'EventSet', op: '=', value: 'BadLogon' }, { field: 'Time', op: 'days<', value: 7 }] }), W('kpi', 'Account lockouts (7 days)', { dataset: 'audit.events', filters: [{ field: 'EventSet', op: '=', value: 'Lockout' }, { field: 'Time', op: 'days<', value: 7 }] }), W('kpi', 'Privileged changes', { dataset: 'audit.events', filters: [{ field: 'Privileged', op: 'true' }] }),
      W('heading', 'Directory and servers', { text: 'Directory and servers' }, 3), W('chart', 'Audit events by type', { dataset: 'audit.events', groupBy: 'EventSet', chart: 'bar', n: 10 }), W('chart', 'Failed logons by source', { dataset: 'audit.events', groupBy: 'SourceIP', filters: [{ field: 'EventSet', op: '=', value: 'BadLogon' }], chart: 'bar', n: 8 }), W('chart', 'Events by server', { dataset: 'audit.events', groupBy: 'Server', chart: 'donut' }),
      W('table', 'Privileged changes', { dataset: 'audit.events', columns: ['Time', 'EventSet', 'Actor', 'Target', 'Group', 'Server'], filters: [{ field: 'Privileged', op: 'true' }], sort: 'Time', dir: 'desc', n: 12 }, 3),
      W('table', 'Risky share permissions', { dataset: 'security.fileacl', columns: ['ComputerName', 'Share', 'Identity', 'Rights', 'Type'], filters: [{ field: 'Risky', op: 'true' }], n: 10 }, 2), W('chart', 'Local administrators per server', { dataset: 'security.localadmins', groupBy: 'ComputerName', chart: 'bar', n: 10 }),
      W('heading', 'Console', { text: 'MonCastle console' }, 3), W('chart', 'Console activity by user', { dataset: 'mc.audit', groupBy: 'User', chart: 'bar' }), W('table', 'Latest console activity', { dataset: 'mc.audit', columns: ['Time', 'User', 'Event', 'IP', 'Detail'], sort: 'Time', dir: 'desc', n: 15 }, 2)] },
    { id: 'rm:actions', name: 'Actions and jobs', icon: 'jobs', area: 'Actions', desc: 'Scheduled and manual actions: what ran, where, by whom, and what failed.', items: [
      W('kpi', 'Job runs', { dataset: 'mc.jobruns' }), W('kpi', 'Failed runs', { dataset: 'mc.jobruns', filters: [{ field: 'Status', op: '=', value: 'Critical' }] }), W('kpi', 'Targets reached', { dataset: 'mc.jobruns', agg: { fn: 'sum', field: 'Targets' } }),
      W('chart', 'Runs by result', { dataset: 'mc.jobruns', groupBy: 'Status', chart: 'donut' }), W('chart', 'Runs by environment', { dataset: 'mc.jobruns', groupBy: 'Environment', chart: 'bar' }), W('chart', 'Runs by job', { dataset: 'mc.jobruns', groupBy: 'Job', chart: 'bar', n: 10 }),
      W('table', 'Latest runs', { dataset: 'mc.jobruns', columns: ['At', 'Job', 'Action', 'Environment', 'By', 'Status', 'Targets', 'Succeeded', 'Failed'], sort: 'At', dir: 'desc', n: 20 }, 3),
      W('table', 'Actions started from the console', { dataset: 'mc.audit', columns: ['Time', 'User', 'Detail'], filters: [{ field: 'Event', op: '=', value: 'run' }], sort: 'Time', dir: 'desc', n: 15 }, 3)] },
    { id: 'rm:engines', name: 'Monitoring engines', icon: 'bolt', area: 'Engines', desc: 'Every collector: schedule, state, last result and run time, so gaps in data are explained.', items: [
      W('kpi', 'Engines', { dataset: 'mc.engines' }), W('kpi', 'Last run failed', { dataset: 'mc.engines', filters: [{ field: 'LastStatus', op: '=', value: 'Critical' }] }), W('kpi', 'Turned off', { dataset: 'mc.engines', filters: [{ field: 'State', op: '=', value: 'Disabled' }] }), W('kpi', 'Not configured', { dataset: 'mc.engines', filters: [{ field: 'State', op: '=', value: 'Not configured' }] }),
      W('chart', 'Last result', { dataset: 'mc.engines', groupBy: 'LastStatus', chart: 'donut' }), W('chart', 'Engines by category', { dataset: 'mc.engines', groupBy: 'Category', chart: 'bar' }), W('chart', 'Slowest engines (seconds)', { dataset: 'mc.engines', groupBy: 'Engine', agg: { fn: 'max', field: 'DurationSec' }, chart: 'bar', n: 8 }),
      W('table', 'Engines that need attention', { dataset: 'mc.engines', columns: ['Engine', 'Category', 'State', 'LastStatus', 'LastRun', 'Message'], filters: [{ field: 'LastStatus', op: '!=', value: 'OK' }], n: 15 }, 3),
      W('table', 'All engines', { dataset: 'mc.engines', columns: ['Engine', 'Category', 'Every', 'State', 'LastStatus', 'LastRun', 'DurationSec', 'NextRun'], sort: 'Category', dir: 'asc', n: 60 }, 3)] },
  ];
  const tabsHtml = (cur) => MC.tabs('reports', [['', 'RoboMate reports'], ['mine', 'My reports'], ['explore', 'Data explorer']], cur);
  const rui = { edit: false };
  V.reports = {
    title: 'Reports',
    crumb: () => 'RoboMate reports for every area, your own multi-part reports, and a data explorer',
    render(el, route) {
      const tab = decodeURIComponent(route.tab || '');
      if (tab === 'explore') return explorer(el, route);
      if (/^t:/.test(tab)) return MC.go('reports', 'explore', { id: tab }); // links from 4.5
      el.innerHTML = '<div class="notice">Loading…</div>';
      Promise.all([MC.api.insights('reports').catch(() => []), MC.monTree(true), loadVirtual(true)]).then(([saved, tree]) => {
        const mine = saved.filter((x) => x.spec && x.spec.items);
        if (tab === 'mine' || tab === '') return gallery(el, tab, mine, saved);
        const builtIn = RM.find((x) => x.id === tab);
        const doc = builtIn ? Object.assign({ builtin: true, spec: { items: builtIn.items } }, builtIn) : saved.find((x) => x.id === tab);
        if (!doc) { el.innerHTML = tabsHtml('mine') + '<div class="notice warn">This report was deleted or is not shared with you.</div>'; return; }
        if (!doc.spec.items) return MC.go('reports', 'explore', { id: doc.id });
        reportDoc(el, route, doc, { tree, reports: saved, el, route });
      }).catch((e) => { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
    },
  };
  function gallery(el, tab, mine, saved) {
    const legacy = saved.filter((x) => !(x.spec && x.spec.items));
    const card = (r, href, sub) => `<a class="card rmcard" href="${href}"><span class="rmico">${icon(r.icon || 'report', '')}</span><b>${esc(r.name)}</b><span class="muted">${esc(sub)}</span></a>`;
    el.innerHTML = tabsHtml(tab) + (tab === '' ? `
      <div class="notice">Each RoboMate report covers one area of MonCastle with live data, prints cleanly and saves as PDF from the print dialog. Use <b>Customise a copy</b> on any of them to start your own.</div>
      <div class="rmgrid">${RM.map((r) => card(r, '#/reports/' + encodeURIComponent(r.id), r.desc)).join('')}</div>` : `
      ${MC.panel('My reports', 'multi-part reports built from sensors, metrics, alarms and collected data; yours and the ones shared with you', `<div class="toolbar" style="margin-bottom:10px"><button class="btn sm primary" id="rNew">${icon('plus', 'sev-ico')}New report</button></div><div class="rmgrid">${mine.map((r) => card({ name: r.name, icon: 'report' }, '#/reports/' + encodeURIComponent(r.id), (r.description || r.spec.items.length + ' items') + ' · ' + (r.owner === MC.user.name ? 'yours' : 'by ' + r.owner) + (r.shared ? ' · shared' : ''))).join('') || '<p class="muted" style="margin:0">No reports yet. Start one here, or open a RoboMate report and choose Customise a copy.</p>'}</div>`)}
      ${legacy.length ? MC.panel('Saved data explorer reports', 'single tables and charts', `<div class="rmgrid">${legacy.map((r) => card({ name: r.name, icon: 'grid' }, '#/reports/explore?id=' + encodeURIComponent(r.id), dsName(r.spec.source))).join('')}</div>`) : ''}`);
    if ($('#rNew', el)) $('#rNew', el).addEventListener('click', () => reportProps({ name: '', spec: { items: [W('heading', 'Overview', { text: 'Overview' }, 3), W('status', 'All sensors'), W('alarms', 'Open alarms', { n: 8 }, 2)] } }, (x) => { rui.edit = true; MC.go('reports', x.id); }));
  }
  function reportProps(d, done) {
    modal(`<h3>${d.id ? 'Name and sharing' : 'New report'}</h3>
      <div class="field"><label for="pn">Name</label><input class="input" id="pn" value="${esc(d.name || '')}" placeholder="Monthly service review"></div>
      <div class="field"><label for="pd">Description</label><input class="input" id="pd" value="${esc(d.description || '')}" placeholder="For the IT steering meeting"></div>
      <label class="check"><input type="checkbox" id="ps" ${d.shared ? 'checked' : ''} ${canShare() ? '' : 'disabled'}> Share with everyone who signs in${canShare() ? '' : ' (contributors and admins can share)'}</label>
      <div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Save</button></div>`, (m, close) => {
      $('#go', m).addEventListener('click', () => { if (!$('#pn', m).value.trim()) return errBox(m, new Error('Give the report a name.')); MC.api.saveInsight('reports', { id: d.id, name: $('#pn', m).value, description: $('#pd', m).value, shared: $('#ps', m).checked, spec: d.spec }).then((x) => { close(); MC.toast('Saved ' + esc(x.name), 'ok'); done(x); }).catch((e) => errBox(m, e)); });
    });
  }
  // a report document: RoboMate header, then its items in a 3-column grid; editable when it is yours
  function reportDoc(el, route, doc, ctx) {
    const editable = !doc.builtin && doc.editable !== false;
    const edit = editable && rui.edit;
    const items = doc.spec.items;
    const now = new Date();
    el.innerHTML = tabsHtml(doc.builtin ? '' : 'mine') + `
      <div class="dashbar no-print">
        <span class="muted" style="font-size:12.5px">${doc.builtin ? 'RoboMate report · ' + esc(doc.area) : esc((doc.owner === MC.user.name ? 'yours' : 'by ' + doc.owner) + (doc.shared ? ' · shared' : ' · private'))}</span><span class="spacer"></span>
        ${editable ? `<button class="btn sm ${edit ? 'on' : ''}" id="eEdit">${edit ? 'Done' : 'Edit'}</button>` : ''}
        ${edit ? `<button class="btn sm primary" id="eAdd">${icon('plus', 'sev-ico')}Add item</button><button class="btn sm" id="eProps">Name & sharing</button><button class="btn sm ghost" id="eDel">Delete</button>` : ''}
        <button class="btn sm" id="eCopy">${doc.builtin ? 'Customise a copy' : 'Duplicate'}</button>
        <button class="btn sm" id="eCsv">${icon('download', 'sev-ico')}Data (CSV)</button>
        <button class="btn sm primary" id="ePrint">Print / PDF</button>
      </div>
      <article class="rdoc">
        <header class="rdoc-head"><div><div class="rdoc-brand">RoboMate <span>MonCastle</span></div><h1>${esc(doc.name)}</h1><p>${esc(doc.desc || doc.description || '')}</p></div>
          <dl><div><dt>Generated</dt><dd>${esc(now.toLocaleString())}</dd></div><div><dt>By</dt><dd>${esc(MC.user.name)}</dd></div><div><dt>Console</dt><dd>${esc((MC.status && MC.status.consoleId) || location.host || 'MonCastle')}</dd></div></dl></header>
        <div class="dgrid rgrid${edit ? ' editing' : ''}">${items.map((w, i) => w.type === 'heading'
          ? `<h2 class="rsec w3" data-i="${i}">${esc(w.text || w.title)}${edit ? ctl() : ''}</h2>`
          : `<section class="card widget w${Math.min(3, w.w || 1)}${w.type === 'text' ? ' rnote' : ''}" data-i="${i}"><div class="panel-h">${w.title ? `<h3>${esc(w.title)}</h3>` : '<span></span>'}${edit ? ctl() : ''}</div><div class="wbody"><div class="muted">Loading…</div></div></section>`).join('') || '<div class="notice">This report is empty. Choose Add item.</div>'}</div>
        <footer class="rdoc-foot">RoboMate MonCastle · ${esc(doc.name)} · ${esc(now.toLocaleDateString())}</footer>
      </article>`;
    function ctl() { return `<div class="act no-print"><button class="btn sm ghost" data-mv="-1" aria-label="Move up">↑</button><button class="btn sm ghost" data-mv="1" aria-label="Move down">↓</button><button class="btn sm ghost" data-sz aria-label="Change width">width</button><button class="btn sm ghost" data-we>Edit</button><button class="btn sm ghost" data-wr aria-label="Remove item">${icon('x', 'sev-ico')}</button></div>`; }
    $$('.widget', el).forEach((sec) => { const w = items[+sec.dataset.i]; renderWidget($('.wbody', sec), w, ctx).catch((e) => { $('.wbody', sec).innerHTML = `<div class="muted">${esc(e.message)}</div>`; }); });
    const save = async (msg) => { try { await MC.api.saveInsight('reports', { id: doc.id, name: doc.name, description: doc.description, shared: doc.shared, spec: doc.spec }); if (msg) MC.toast(msg, 'ok'); V.reports.render(el, route); } catch (e) { MC.toast(esc(e.message), 'err'); } };
    if ($('#eEdit', el)) $('#eEdit', el).addEventListener('click', () => { rui.edit = !rui.edit; V.reports.render(el, route); });
    $('#eCopy', el).addEventListener('click', () => reportProps({ name: doc.name + (doc.builtin ? '' : ' (copy)'), description: doc.desc || doc.description || '', spec: JSON.parse(JSON.stringify(doc.spec)) }, (x) => { rui.edit = true; MC.go('reports', x.id); }));
    $('#ePrint', el).addEventListener('click', () => { document.body.classList.add('printing'); setTimeout(() => { root.print(); document.body.classList.remove('printing'); }, 50); });
    $('#eCsv', el).addEventListener('click', () => { // every data item of the report, one after the other
      const rows = [];
      for (const w of items) if (w.dataset) for (const r of query(rowsOf(w.dataset), { filters: w.filters, groupBy: w.type === 'chart' ? w.groupBy : '', agg: w.agg, sort: w.sort, dir: w.dir, limit: w.type === 'table' ? w.n : 0 })) rows.push(Object.assign({ Item: w.title }, r));
      const keys = [...new Set([].concat(...rows.map((r) => Object.keys(r))))];
      MC.downloadCsv((doc.name || 'report').replace(/\W+/g, '-').toLowerCase(), rows, keys.map((k) => ({ key: k, label: k, val: (x) => val(x, k) })));
    });
    if (!edit) return;
    const pick = (w) => widgetDialog(w, Object.assign({}, ctx, { forReport: true }), (out) => { if (w) items[items.indexOf(w)] = out; else items.push(out); save(w ? 'Item saved' : 'Item added'); });
    $('#eAdd', el).addEventListener('click', () => pick(null));
    $('#eProps', el).addEventListener('click', () => reportProps(doc, () => V.reports.render(el, route)));
    $('#eDel', el).addEventListener('click', () => modal(`<h3>Delete ${esc(doc.name)}?</h3><div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn danger" id="go">Delete</button></div>`, (m, close) => { $('#go', m).addEventListener('click', () => MC.api.removeInsight('reports', doc.id).then(() => { close(); rui.edit = false; MC.go('reports', 'mine'); }).catch((e) => errBox(m, e))); }));
    $$('[data-i]', el).forEach((sec) => {
      const i = +sec.dataset.i;
      $$('[data-mv]', sec).forEach((b) => b.addEventListener('click', () => { const j = i + +b.dataset.mv; if (j < 0 || j >= items.length) return; [items[i], items[j]] = [items[j], items[i]]; save(); }));
      const sz = $('[data-sz]', sec); if (sz) sz.addEventListener('click', () => { items[i].w = ((items[i].w || 1) % 3) + 1; save(); });
      const we = $('[data-we]', sec); if (we) we.addEventListener('click', () => pick(items[i]));
      const wr = $('[data-wr]', sec); if (wr) wr.addEventListener('click', () => { items.splice(i, 1); save('Item removed'); });
    });
  }
  // the 4.5 single-table builder, kept as the data explorer
  function explorer(el, route) {
      el.innerHTML = '<div class="notice">Loading…</div>';
      Promise.all([MC.api.insights('reports').catch(() => []), loadVirtual()]).then(async ([all0]) => {
        const saved = all0.filter((x) => !(x.spec && x.spec.items));
        const id = (route.q && route.q.id) || '';
        const base = saved.find((r) => r.id === id) || TEMPLATES.find((r) => r.id === id) || TEMPLATES[0];
        const r = { id: base.id && base.id.startsWith('t:') ? null : base.id, name: base.name, shared: !!base.shared, editable: base.editable !== false, spec: JSON.parse(JSON.stringify(base.spec)) };
        const sources = [['sensors', 'Sensors (all types)']].concat(['mc.devices', 'mc.alarms', 'mc.engines', 'mc.jobruns', 'mc.audit'].filter((k) => (VDS[k] || []).length).map((k) => [k, dsName(k)])).concat(S.TYPES.map((t) => ['sensors:' + t.id, 'Sensors · ' + t.name])).concat(datasets().map((k) => [k, dsName(k)]));
        const draw = async () => {
          const all = r.spec.source.startsWith('sensors') ? await sensorRows(r.spec.source.split(':')[1] || null) : rowsOf(r.spec.source);
          const fields = fieldsOf(all);
          if (!r.spec.columns || !r.spec.columns.length || !r.spec.columns.some((c) => fields.some((f) => f.name === c))) r.spec.columns = fields.slice(0, 6).map((f) => f.name);
          const rows = query(all, r.spec);
          const grouped = !!r.spec.groupBy;
          el.innerHTML = tabsHtml('explore') + `
            <div class="rlayout">
              <aside class="card panel-c rbuild no-print">
                <div class="field"><label for="rLoad">Open</label><select class="input" id="rLoad"><optgroup label="Templates">${TEMPLATES.map((x) => `<option value="${x.id}" ${x.id === id || (!id && x === TEMPLATES[0]) ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</optgroup>${saved.length ? `<optgroup label="Saved">${saved.map((x) => `<option value="${esc(x.id)}" ${x.id === id ? 'selected' : ''}>${esc(x.name)}${x.shared ? ' (shared)' : ''}</option>`).join('')}</optgroup>` : ''}</select></div>
                <div class="field"><label for="rSrc">Data</label><select class="input" id="rSrc">${sources.map(([k, l]) => `<option value="${esc(k)}" ${r.spec.source === k ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></div>
                <fieldset><legend>Filters</legend><div id="rF">${filterRows(fields, r.spec.filters)}</div></fieldset>
                <div class="field" style="margin-top:8px"><label for="rG">Group by</label><select class="input" id="rG"><option value="">(no grouping, list rows)</option>${fields.map((f) => `<option ${r.spec.groupBy === f.name ? 'selected' : ''}>${esc(f.name)}</option>`).join('')}</select></div>
                <div class="field" ${grouped ? '' : 'hidden'} id="rAggF"><label>Value per group</label><div class="toolbar" style="margin:0"><select class="input" id="rA">${Object.entries(AGG).map(([k, l]) => `<option value="${k}" ${((r.spec.agg || {}).fn || 'count') === k ? 'selected' : ''}>${l}</option>`).join('')}</select><select class="input" id="rAf"><option value="">field…</option>${fields.filter((f) => f.type === 'number').map((f) => `<option ${(r.spec.agg || {}).field === f.name ? 'selected' : ''}>${esc(f.name)}</option>`).join('')}</select></div></div>
                <div class="field" ${grouped ? '' : 'hidden'} id="rChF"><label for="rC">Chart</label><select class="input" id="rC">${[['none', 'No chart'], ['bar', 'Bars'], ['donut', 'Donut'], ['columns', 'Columns']].map(([k, l]) => `<option value="${k}" ${r.spec.chart === k ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
                <div class="field" ${grouped ? 'hidden' : ''} id="rSoF"><label for="rS">Sort by</label><div class="toolbar" style="margin:0"><select class="input" id="rS"><option value="">(none)</option>${fields.map((f) => `<option ${r.spec.sort === f.name ? 'selected' : ''}>${esc(f.name)}</option>`).join('')}</select><select class="input" id="rD"><option value="desc">Highest first</option><option value="asc" ${r.spec.dir === 'asc' ? 'selected' : ''}>Lowest first</option></select></div></div>
                <fieldset ${grouped ? 'hidden' : ''} id="rColF"><legend>Columns</legend><div class="optgrid one">${fields.map((f) => `<label class="check"><input type="checkbox" data-col="${esc(f.name)}" ${r.spec.columns.includes(f.name) ? 'checked' : ''}> ${esc(f.name)}</label>`).join('')}</div></fieldset>
                <div class="field" style="margin-top:8px"><label for="rL">Row limit</label><input class="input" id="rL" type="number" min="0" max="10000" value="${+r.spec.limit || 0}"><span class="hint">0 = all rows</span></div>
                <button class="btn primary block" id="rRun">Update report</button>
              </aside>
              <div class="grid" style="align-content:start">
                <section class="card panel-c"><div class="shead" style="gap:10px"><div style="flex:1;min-width:200px"><h2 style="margin:0;font-size:19px" id="rTitle">${esc(r.name)}</h2><div class="msg">${esc(sources.find(([k]) => k === r.spec.source) ? sources.find(([k]) => k === r.spec.source)[1] : r.spec.source)} · ${rows.length} ${grouped ? 'groups' : 'rows'} of ${all.length} · ${new Date().toLocaleString()}${(r.spec.filters || []).length ? ' · ' + r.spec.filters.map((f) => esc(f.field + ' ' + (OPS.find((o) => o[0] === f.op) || [, f.op])[1] + (['true', 'false', 'empty', 'notempty'].includes(f.op) ? '' : ' ' + f.value))).join(', ') : ''}</div></div>
                  <div class="actions-row no-print"><button class="btn sm primary" id="rSave">${r.id && r.editable ? 'Save' : 'Save as…'}</button>${r.id ? '<button class="btn sm" id="rSaveAs">Save as…</button>' : ''}<button class="btn sm" id="rCsv">${icon('download', 'sev-ico')}CSV</button><button class="btn sm" id="rPrint">Print / PDF</button>${r.id && r.editable ? '<button class="btn sm ghost" id="rDel">Delete</button>' : ''}</div></div></section>
                ${grouped && r.spec.chart !== 'none' ? MC.panel('Chart', '', '<div id="rChart"></div>') : ''}
                ${MC.panel(grouped ? 'Groups' : 'Rows', '', '<div id="rT"></div>')}
              </div>
            </div>`;
          wireFilters($('#rF', el), fields);
          if (grouped && r.spec.chart !== 'none') drawChart($('#rChart', el), rows, r.spec.chart, 15);
          const cols = grouped ? Object.keys(rows[0] || { [r.spec.groupBy]: 1 }) : r.spec.columns;
          MC.table($('#rT', el), rows, cols.map((c) => ({ key: c, label: c, n: rows.length && typeof rows[0][c] === 'number', val: (x) => val(x, c), html: (x) => cell(x[c]) })), { search: !grouped, limit: 100, name: (r.name || 'report').replace(/\W+/g, '-').toLowerCase() });
          const readSpec = () => {
            r.spec.filters = readFilters($('#rF', el));
            r.spec.groupBy = $('#rG', el).value;
            r.spec.agg = { fn: $('#rA', el).value, field: $('#rAf', el).value || undefined };
            r.spec.chart = $('#rC', el).value;
            r.spec.sort = $('#rS', el).value; r.spec.dir = $('#rD', el).value;
            r.spec.columns = $$('[data-col]:checked', el).map((c) => c.dataset.col);
            r.spec.limit = +$('#rL', el).value || 0;
            if (r.spec.agg.fn !== 'count' && !r.spec.agg.field) r.spec.agg = { fn: 'count' };
          };
          $('#rRun', el).addEventListener('click', () => { readSpec(); draw(); });
          $('#rG', el).addEventListener('change', () => { readSpec(); draw(); });
          $('#rSrc', el).addEventListener('change', (e) => { r.spec = { source: e.target.value, columns: [], filters: [], chart: 'none' }; draw(); });
          $('#rLoad', el).addEventListener('change', (e) => MC.go('reports', 'explore', { id: e.target.value }));
          $('#rCsv', el).addEventListener('click', () => MC.downloadCsv((r.name || 'report').replace(/\W+/g, '-').toLowerCase(), rows, cols.map((c) => ({ key: c, label: c, val: (x) => val(x, c) }))));
          $('#rPrint', el).addEventListener('click', () => { document.body.classList.add('printing'); setTimeout(() => { root.print(); document.body.classList.remove('printing'); }, 50); });
          const saveAs = () => modal(`<h3>Save report</h3><div class="field"><label for="rn">Name</label><input class="input" id="rn" value="${esc(r.name)}"></div><label class="check"><input type="checkbox" id="rsh" ${r.shared ? 'checked' : ''} ${canShare() ? '' : 'disabled'}> Share with everyone who signs in${canShare() ? '' : ' (contributors and admins can share)'}</label><div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Save</button></div>`, (m, close) => {
            $('#go', m).addEventListener('click', () => { readSpec(); MC.api.saveInsight('reports', { name: $('#rn', m).value, shared: $('#rsh', m).checked, spec: r.spec }).then((x) => { close(); MC.toast('Saved ' + esc(x.name), 'ok'); MC.go('reports', 'explore', { id: x.id }); }).catch((e) => errBox(m, e)); });
          });
          $('#rSave', el).addEventListener('click', () => { if (!(r.id && r.editable)) return saveAs(); readSpec(); MC.api.saveInsight('reports', { id: r.id, name: r.name, shared: r.shared, spec: r.spec }).then(() => { MC.toast('Saved', 'ok'); draw(); }).catch((e) => MC.toast(esc(e.message), 'err')); });
          if ($('#rSaveAs', el)) $('#rSaveAs', el).addEventListener('click', saveAs);
          if ($('#rDel', el)) $('#rDel', el).addEventListener('click', () => MC.api.removeInsight('reports', r.id).then(() => { MC.toast('Deleted', 'ok'); MC.go('reports', 'mine'); }).catch((e) => MC.toast(esc(e.message), 'err')));
        };
        await draw();
      }).catch((e) => { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
  }
  MC.reportQuery = query;
})(typeof self !== 'undefined' ? self : this);
