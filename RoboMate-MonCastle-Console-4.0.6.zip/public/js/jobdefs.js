/*
 * RoboMate MonCastle - scheduled jobs: an action or tool from the script catalog, run on a schedule against all
 * devices, device groups or chosen devices, with its own run-as credential. Shared by the browser
 * (window.MCJobDefs) and the server (server/lib/jobdefs.js), so both agree on validation, targets and next run.
 *
 * Schedule types: interval (every 15m / 4h / 2d), daily (at times), weekly (days + time), monthly (day of month + time),
 * once (date and time) and manual (only "Run now"). Optional start and end dates limit any of them.
 * Times are the MonCastle server's local time.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCJobDefs = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const TYPES = { interval: 'Every …', daily: 'Daily', weekly: 'Weekly', monthly: 'Monthly', once: 'Once', manual: 'Only when run by hand' };
  // the parameter that names the targets of a script, in the order index.js reads them
  const HOST_PARAMS = ['ComputerName', 'VMName', 'Target', 'HostName'];
  const toMs = (s) => { const m = /^(\d+)\s*([mhd])$/i.exec(String(s || '').trim()); return m ? +m[1] * { m: 6e4, h: 36e5, d: 864e5 }[m[2].toLowerCase()] : null; };
  const hm = (t) => { const m = /^([01]?\d|2[0-3]):([0-5]\d)$/.exec(String(t || '').trim()); return m ? [+m[1], +m[2]] : null; };
  const bad = (m) => Object.assign(new Error(m), { status: 400 });

  function hostParam(script) {
    const names = (script.parameters || []).map((p) => p.name);
    const n = HOST_PARAMS.find((x) => names.includes(x));
    if (!n) return null;
    const p = script.parameters.find((x) => x.name === n);
    return { name: n, multi: String(p.type || '').endsWith('[]') };
  }
  // device kinds a script can be aimed at (MonCastle-Targets); empty = any kind
  const kindsOf = (script) => (script.targets || []).map((k) => String(k).trim().toLowerCase()).filter(Boolean);

  // the devices a job runs on. chain(gid) = [gid, parent, grandparent ...], so a group includes its subgroups.
  function targetsOf(def, script, devices, chain) {
    const t = def.target || {};
    const kinds = kindsOf(script);
    const fits = (d) => !kinds.length || kinds.includes(d.kind);
    let list = [];
    if (t.mode === 'all') list = devices;
    else if (t.mode === 'groups') list = devices.filter((d) => (Array.isArray(d.groups) && d.groups.length ? d.groups : [d.group]).some((dg) => (chain ? chain(dg) : [dg]).some((g) => (t.groups || []).includes(g))));
    else if (t.mode === 'devices') list = devices.filter((d) => (t.devices || []).includes(d.id));
    return list.filter(fits).filter((d) => !d.paused || t.mode === 'devices');
  }

  // next run at or after `from` (ms); null when the schedule has none left
  function nextRun(def, from, lastRun) {
    const s = def.schedule || {};
    from = from == null ? Date.now() : from;
    const start = s.start ? Date.parse(s.start + 'T00:00:00') : null;
    const end = s.end ? Date.parse(s.end + 'T23:59:59') : null;
    if (start && from < start) from = start;
    const within = (t) => (t != null && (!end || t <= end) ? t : null);
    if (s.type === 'manual') return null;
    if (s.type === 'once') { const t = Date.parse(s.at); return Number.isFinite(t) && (!lastRun || t > Date.parse(lastRun)) ? within(t) : null; }
    if (s.type === 'interval') {
      const every = toMs(s.every);
      if (!every) return null;
      // the first run is one interval after the job is created, or on its start date
      const t = lastRun ? Math.max(Date.parse(lastRun) + every, from) : s.start ? from : from + every;
      return within(t);
    }
    const times = (s.times && s.times.length ? s.times : [s.time || '02:00']).map(hm).filter(Boolean).sort((a, b) => a[0] * 60 + a[1] - (b[0] * 60 + b[1]));
    if (!times.length) return null;
    const days = (s.days && s.days.length ? s.days : [1]).map(Number);
    const dom = Math.min(31, Math.max(1, +s.day || 1));
    const d0 = new Date(from);
    for (let i = 0; i < 400; i++) {
      const d = new Date(d0.getFullYear(), d0.getMonth(), d0.getDate() + i);
      const lastDom = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
      const ok = s.type === 'daily' || (s.type === 'weekly' && days.includes(d.getDay())) || (s.type === 'monthly' && d.getDate() === Math.min(dom, lastDom));
      if (!ok) continue;
      for (const [h, m] of times) {
        const t = new Date(d.getFullYear(), d.getMonth(), d.getDate(), h, m).getTime();
        // a run that started within the last minute already covers this slot
        if (t >= from && (!lastRun || t > Date.parse(lastRun) + 6e4)) return within(t);
      }
    }
    return null;
  }

  function describe(s) {
    s = s || {};
    const range = (s.start ? ' from ' + s.start : '') + (s.end ? ' until ' + s.end : '');
    const at = (s.times && s.times.length ? s.times : [s.time || '02:00']).join(', ');
    if (s.type === 'interval') return 'Every ' + String(s.every || '').replace(/m$/, ' min').replace(/h$/, ' h').replace(/d$/, ' days') + range;
    if (s.type === 'daily') return 'Daily at ' + at + range;
    if (s.type === 'weekly') return (s.days || [1]).map((d) => DAYS[d]).join(', ') + ' at ' + at + range;
    if (s.type === 'monthly') return 'Monthly on day ' + (s.day || 1) + ' at ' + at + range;
    if (s.type === 'once') return 'Once on ' + String(s.at || '').replace('T', ' ').slice(0, 16);
    return 'Only when run by hand';
  }

  // checks a job definition from the browser and returns the clean copy (params are checked again by scripts.run)
  function clean(b, script) {
    if (!script) throw bad('Choose an action or tool.');
    if (script.kind === 'collector') throw bad('Collectors run as monitoring engines; schedule them under Monitoring engines.');
    const name = String(b.name || '').trim();
    if (!name || name.length > 80) throw bad('Give the job a name (up to 80 characters).');
    const hp = hostParam(script);
    const t = b.target || {};
    const mode = hp ? (['all', 'groups', 'devices'].includes(t.mode) ? t.mode : null) : 'none';
    if (!mode) throw bad('Choose the devices: all, device groups or single devices.');
    if (mode === 'groups' && !(t.groups || []).length) throw bad('Choose at least one device group.');
    if (mode === 'devices' && !(t.devices || []).length) throw bad('Choose at least one device.');
    const s = b.schedule || {};
    const type = TYPES[s.type] ? s.type : null;
    if (!type) throw bad('Choose when the job runs.');
    const sched = { type };
    if (type === 'interval') { if (!toMs(s.every) || toMs(s.every) < 5 * 6e4) throw bad('Use an interval of at least 5 minutes, like 15m, 4h or 1d.'); sched.every = String(s.every).trim().toLowerCase(); }
    if (['daily', 'weekly', 'monthly'].includes(type)) {
      const times = [].concat(s.times || s.time || []).map(String).map((x) => x.trim()).filter(Boolean);
      if (!times.length || times.some((x) => !hm(x)) || times.length > 24) throw bad('Enter times as HH:MM, for example 02:00 or 08:00, 20:00.');
      sched.times = times;
    }
    if (type === 'weekly') { const d = [...new Set((s.days || []).map(Number).filter((x) => x >= 0 && x <= 6))]; if (!d.length) throw bad('Choose at least one weekday.'); sched.days = d.sort(); }
    if (type === 'monthly') { const d = +s.day; if (!(d >= 1 && d <= 31)) throw bad('Day of month is 1 to 31 (31 means the last day in shorter months).'); sched.day = d; }
    if (type === 'once') { if (!Number.isFinite(Date.parse(s.at))) throw bad('Choose the date and time to run once.'); sched.at = String(s.at).slice(0, 16); }
    for (const k of ['start', 'end']) if (s[k]) { if (!/^\d{4}-\d{2}-\d{2}$/.test(s[k])) throw bad('Dates are YYYY-MM-DD.'); sched[k] = s[k]; }
    if (sched.start && sched.end && sched.end < sched.start) throw bad('The end date is before the start date.');
    const params = Object.assign({}, b.params || {});
    if (hp) delete params[hp.name];
    return {
      name, script: script.id, params,
      target: { mode, groups: mode === 'groups' ? [...new Set(t.groups.map(String))] : [], devices: mode === 'devices' ? [...new Set(t.devices.map(String))].slice(0, 2000) : [] },
      credential: b.credential ? String(b.credential) : null,
      schedule: sched, enabled: b.enabled !== false, whatIf: !!b.whatIf,
      notify: { onFailure: !!(b.notify && b.notify.onFailure), to: b.notify && b.notify.to ? String(b.notify.to).trim().slice(0, 300) : '' },
      parallel: Math.min(50, Math.max(1, +b.parallel || 10)),
      description: String(b.description || '').slice(0, 300),
    };
  }

  // resource category of a script, for the Actions & jobs catalog
  // environments of the Actions & jobs catalog: the manifest's resource names grouped the way people look for them
  const ENV = { ActiveDirectory: 'Active Directory', 'Active Directory': 'Active Directory', Identity: 'Active Directory', Servers: 'Devices', Workstations: 'Devices', Devices: 'Devices', FileServers: 'Devices', Updates: 'Devices', Printers: 'Devices', Security: 'Devices', Network: 'Network', Linux: 'Linux', Storage: 'Storage', Virtualization: 'Virtualization', SQL: 'Databases', Databases: 'Databases', Cloud: 'Cloud', MonCastle: 'MonCastle' };
  const CATEGORY_ORDER = ['Active Directory', 'Devices', 'Network', 'Linux', 'Storage', 'Virtualization', 'Databases', 'Cloud', 'MonCastle', 'Other'];
  const categoryOf = (s) => ENV[s.resource] || s.resource || 'Other';

  return { DAYS, TYPES, HOST_PARAMS, CATEGORY_ORDER, toMs, hostParam, kindsOf, targetsOf, nextRun, describe, clean, categoryOf };
});
