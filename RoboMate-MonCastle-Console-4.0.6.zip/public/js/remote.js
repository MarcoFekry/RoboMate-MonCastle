/*
 * RoboMate MonCastle - remote scripting (browser: window.MCRemote, server: require).
 * Which language each onboarded device runs, how a request is checked, and the demo simulation. The console runs the
 * code with the act.remote.code library script: PowerShell over WinRM on Windows, Bash / Sh / Python over SSH on Linux
 * and appliances, typed CLI lines over SSH on network devices. Remote scripting is for administrators only, is audited
 * and needs a typed confirmation.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCRemote = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const LANGS = [
    { id: 'PowerShell', label: 'PowerShell', via: 'WinRM (5985/5986)', cred: 'windows', sample: '# runs on each selected Windows device\n$os = Get-CimInstance Win32_OperatingSystem\n"{0} up since {1:yyyy-MM-dd HH:mm}" -f $env:COMPUTERNAME, $os.LastBootUpTime\nGet-Service -Name W32Time, WinRM | Select-Object Name, Status | Format-Table -AutoSize' },
    { id: 'Bash', label: 'Bash', via: 'SSH (22)', cred: 'ssh', sample: '# runs on each selected Linux device\nhostname\nuptime -p\ndf -h / | tail -1' },
    { id: 'Sh', label: 'POSIX sh', via: 'SSH (22)', cred: 'ssh', sample: 'hostname\nuname -sr\nuptime' },
    { id: 'Python', label: 'Python 3', via: 'SSH (22), python3 on the device', cred: 'ssh', sample: 'import platform, socket\nprint(socket.gethostname(), platform.platform())' },
    { id: 'NetworkCli', label: 'Network CLI', via: 'SSH (22), one command per line', cred: 'ssh', sample: 'show version\nshow interfaces status' },
  ];
  const NET = ['network', 'firewall', 'wireless', 'loadbalancer', 'fcswitch', 'voip'];
  const isWin = (d) => ['server', 'workstation', 'domain'].includes(d.kind) && !/linux|unix|esxi/i.test(d.os || '');
  // languages a device can run, best first; [] = cannot run code (printers, sensors, cloud accounts ...)
  function languagesFor(d) {
    if (!d) return [];
    if (d.kind === 'linux' || /linux|ubuntu|debian|red hat|rhel|centos|suse|rocky|alma/i.test(d.os || '')) return ['Bash', 'Sh', 'Python'];
    if (isWin(d)) return ['PowerShell'];
    if (NET.includes(d.kind)) return ['NetworkCli', 'Sh'];
    if (['appliance', 'host', 'nas', 'san', 'storage', 'backup'].includes(d.kind)) return ['Sh', 'Bash', 'NetworkCli'];
    if (d.kind === 'vm') return /windows/i.test(d.os || '') ? ['PowerShell'] : ['Bash', 'Sh', 'Python'];
    return [];
  }
  const lang = (id) => LANGS.find((l) => l.id === id) || null;
  const MAX_CODE = 64 * 1024, MAX_DEVICES = 200;

  // returns an error message, or null when the request may run
  function check({ devices, language, code }) {
    if (!lang(language)) return 'Choose a language.';
    if (!String(code || '').trim()) return 'Write the code to run.';
    if (String(code).length > MAX_CODE) return 'The code is longer than 64 KB.';
    if (/\u0000/.test(code)) return 'The code contains a null character.';
    if (!devices || !devices.length) return 'Choose at least one device.';
    if (devices.length > MAX_DEVICES) return 'Choose at most ' + MAX_DEVICES + ' devices per run.';
    const bad = devices.filter((d) => !languagesFor(d).includes(language));
    if (bad.length) return bad.map((d) => d.name).slice(0, 5).join(', ') + (bad.length > 5 ? ' and ' + (bad.length - 5) + ' more' : '') + ' cannot run ' + lang(language).label + '.';
    return null;
  }
  // what the person types to confirm: the device name for one device, the number of devices otherwise
  const confirmWord = (devices) => (devices.length === 1 ? devices[0].name : String(devices.length));

  // ---- demo: believable output without touching anything
  function simulate(d, language, code, seed) {
    const lines = String(code || '').replace(/\r/g, '').split('\n').map((x) => x.trim()).filter((x) => x && !/^(#|\/\/)/.test(x));
    const h = (d.name || 'host').length + (seed || 0);
    if (!d.host && !d.name) return { Result: 'Unreachable', ExitCode: -1, Output: '', Error: 'No address' };
    if (/^(PRN|UPS|CAM)/i.test(d.name)) return { Result: 'Unreachable', ExitCode: -1, Output: '', Error: language === 'PowerShell' ? 'WinRM cannot reach ' + d.name + ' (port 5985 closed).' : 'ssh: connect to host ' + (d.host || d.name) + ' port 22: Connection timed out' };
    const out = [];
    for (const l of lines.slice(0, 40)) {
      const q = l.match(/^(?:Write-(?:Output|Host)\s+|echo\s+|print\()?["'](.*?)["']\)?$/i);
      if (q) out.push(q[1].replace(/\$env:COMPUTERNAME|\$\(hostname\)|\$HOSTNAME/gi, d.name));
      else if (/^hostname\b|\$env:COMPUTERNAME$/i.test(l)) out.push(d.name);
      else if (/LastBootUpTime|uptime/i.test(l)) out.push(language === 'PowerShell' ? d.name + ' up since 2026-10-' + String(10 + (h % 18)).padStart(2, '0') + ' 03:12' : 'up ' + (h % 40 + 2) + ' days, ' + (h % 23) + ' hours');
      else if (/Get-Service/i.test(l)) out.push('Name    Status\n----    ------\nW32Time Running\nWinRM   Running');
      else if (/^df\b/.test(l)) out.push('/dev/sda1        50G   ' + (12 + h % 30) + 'G   ' + (38 - h % 30) + 'G  ' + (24 + (h % 60)) + '% /');
      else if (/uname/.test(l)) out.push('Linux 5.15.0-' + (80 + h % 40) + '-generic');
      else if (/platform|gethostname/.test(l)) out.push(d.name.toLowerCase() + ' Linux-5.15.0-generic-x86_64-with-glibc2.35');
      else if (/^show version|^display version|get system status/i.test(l)) out.push((d.vendor || 'Cisco') + ' ' + (d.model || 'Catalyst 9300') + ', software version 17.9.' + (h % 5) + '\n' + d.name + ' uptime is ' + (h % 90 + 1) + ' days');
      else if (/^show interfaces/i.test(l)) out.push('Port    Status     Vlan  Speed\nGi1/0/1 connected  10    a-1000\nGi1/0/2 connected  20    a-1000\nGi1/0/3 notconnect 1     auto');
      else if (/^(Get-|Set-|Restart-|Stop-|Start-|New-|Remove-|Invoke-)/i.test(l)) out.push('(' + l.split(/\s/)[0] + ' finished)');
      else if (/^(sudo |systemctl|apt|yum|dnf|cat |ls|ps |free|ip )/.test(l)) out.push('(' + l.split(/\s/)[0] + ' finished)');
    }
    return { Result: 'Done', ExitCode: 0, Output: out.join('\n') || '(no output)', Error: null };
  }
  function demoResult(devices, language, code, whatIf) {
    const rows = devices.map((d, i) => Object.assign({ ComputerName: d.name, Language: language, Seconds: 1 + (i % 4) }, whatIf ? { Result: 'WhatIf', ExitCode: null, Output: 'Would run ' + String(code).split('\n').length + ' line(s) of ' + language + '.', Error: null } : simulate(d, language, code, i)));
    const bad = rows.filter((r) => r.Result !== 'Done' && r.Result !== 'WhatIf').length;
    return { moncastle: '4.0.0', dataset: 'action.remote.code', status: !bad ? 'ok' : bad < rows.length ? 'partial' : 'error', message: whatIf ? 'WhatIf: nothing ran on ' + rows.length + ' device(s).' : language + ' code ran on ' + (rows.length - bad) + ' of ' + rows.length + ' device(s) (demo: nothing was sent).', data: rows, count: rows.length, warnings: [] };
  }
  return { LANGS, lang, languagesFor, check, confirmWord, simulate, demoResult, MAX_CODE, MAX_DEVICES };
});
