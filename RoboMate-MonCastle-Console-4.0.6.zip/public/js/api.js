/*
 * RoboMate MonCastle - API client.
 * Talks to the console server (/api/*). When no server answers (static hosting, the hosted test page),
 * it falls back to an in-browser demo backend with the same response shapes, so every view works the same way.
 */
(function (root) {
  'use strict';
  const MASK = (last4) => '320RMC••••••••' + (last4 || '');
  // licence key <-> GitHub token: github_pat_X <-> 320RMCX (320RMC_X from earlier builds still read), gh<x>_X <-> 320RMC<x>_X
  const toToken = (k) => { k = String(k || '').trim(); const m = /^320RMC([pousr])_/.exec(k); if (m) return 'gh' + m[1] + '_' + k.slice(8); return /^320RMC/.test(k) ? 'github_pat_' + k.slice(6).replace(/^_/, '') : k; };
  const isKey = (k) => /^320RMC[A-Za-z0-9_]{20,}$/.test(String(k || '').trim());
  const KEY_ONLY = 'Enter the MonCastle licence key (serial): it starts with 320RMC. GitHub tokens are not accepted here.';
  const toKey = (t) => { t = String(t || '').trim(); if (/^github_pat_/.test(t)) return '320RMC' + t.slice(11); const m = /^gh([pousr])_/.exec(t); return m ? '320RMC' + m[1] + '_' + t.slice(4) : t; };
  async function fingerprint(t) {
    try { const h = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(toToken(t))); return Array.from(new Uint8Array(h)).map((b) => b.toString(16).padStart(2, '0')).join('').slice(0, 16); } catch (e) { return 'unavailable'; }
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // ------------------------------------------------------------------ live backend
  function live() {
    async function call(method, path, body) {
      const res = await fetch('api/' + path, {
        method,
        credentials: 'same-origin',
        headers: Object.assign({ Accept: 'application/json' }, body ? { 'Content-Type': 'application/json' } : {}, method !== 'GET' ? { 'X-MC-Request': '1' } : {}),
        body: body ? JSON.stringify(body) : undefined,
      });
      let json = null;
      try { json = await res.json(); } catch (e) { /* non-JSON */ }
      if (!res.ok) {
        const err = new Error((json && json.error) || res.status + ' ' + res.statusText);
        err.status = res.status;
        err.code = json && json.code;
        throw err;
      }
      return json;
    }
    return {
      mode: 'live',
      status: () => call('GET', 'status'),
      license: (token) => call('POST', 'license', { token }),
      removeLicense: () => call('DELETE', 'license'),
      setup: (username, password) => call('POST', 'setup', { username, password }),
      login: (username, password, remember) => call('POST', 'login', { username, password, remember: !!remember }),
      logout: () => call('POST', 'logout'),
      datasets: () => call('GET', 'datasets'),
      history: (hours) => call('GET', 'history?hours=' + (hours || 24)),
      scripts: () => call('GET', 'scripts'),
      syncScripts: () => call('POST', 'scripts/sync'),
      scriptSource: (p) => call('GET', 'scripts/source?path=' + encodeURIComponent(p)),
      remoteRun: (b) => call('POST', 'remote/run', b),
      inventoryCollect: (device) => call('POST', 'inventory/collect', { device }),
      remoteControl: (device, method, port) => call('POST', 'remote/control', { device, method, port }),
      auditCollect: (devices, opts) => call('POST', 'audit/collect', Object.assign({ devices }, opts || {})),
      run: (script, params, opt = {}) => call('POST', 'run', Object.assign({ script, params }, opt)),
      jobs: () => call('GET', 'jobs'),
      job: (id) => call('GET', 'jobs/' + encodeURIComponent(id)),
      accessLog: () => call('GET', 'access-log'),
      schedules: () => call('GET', 'schedules'),
      jobdefs: () => call('GET', 'jobdefs'),
      saveJobdef: (b) => call('POST', 'jobdefs', b),
      previewJobdef: (b) => call('POST', 'jobdefs/preview', b),
      jobdefAction: (id, action) => call('POST', 'jobdefs/' + encodeURIComponent(id) + '/' + action),
      removeJobdef: (id) => call('DELETE', 'jobdefs/' + encodeURIComponent(id)),
      setSchedule: (id, every, enabled) => call('POST', 'schedules', { id, every, enabled }),
      engines: (refresh) => call('GET', 'engines' + (refresh ? '?refresh=1' : '')),
      engine: (id) => call('GET', 'engines/' + encodeURIComponent(id)),
      retention: () => call('GET', 'retention'),
      osReleases: () => call('GET', 'osreleases'),
      refreshOsReleases: () => call('POST', 'osreleases/refresh'),
      retentionAction: (b) => call('POST', 'retention', b),
      archive: (q) => call('GET', 'archive?' + new URLSearchParams(q).toString()),
      archiveCsvUrl: (q) => 'api/archive?' + new URLSearchParams(Object.assign({}, q, { format: 'csv', limit: 20000 })).toString(),
      infra: () => call('GET', 'infra'),
      infraAction: (b) => call('POST', 'infra', b),
      engineAction: (action, id, every) => call('POST', 'engines', { action, id: id || 'All', every }),
      engineScope: (id) => call('GET', 'engines/scope?id=' + encodeURIComponent(id)),
      setEngineScope: (id, scope) => call('POST', 'engines/scope', { id, scope }),
      users: () => call('GET', 'users'),
      addUser: (u) => call('POST', 'users', u),
      removeUser: (name) => call('DELETE', 'users/' + encodeURIComponent(name)),
      updateUser: (name, body) => call('POST', 'users/' + encodeURIComponent(name), body),
      userGroups: () => call('GET', 'usergroups'),
      saveUserGroup: (g) => call('POST', 'usergroups', g),
      removeUserGroup: (id) => call('DELETE', 'usergroups/' + encodeURIComponent(id)),
      insights: (kind) => call('GET', kind),
      saveInsight: (kind, x) => call('POST', kind, x),
      removeInsight: (kind, id) => call('DELETE', kind + '/' + encodeURIComponent(id)),
      credentials: () => call('GET', 'credentials'),
      saveCredential: (c) => call('POST', 'credentials', c),
      removeCredential: (id) => call('DELETE', 'credentials/' + encodeURIComponent(id)),
      testCredential: (id, host) => call('POST', 'credentials/' + encodeURIComponent(id) + '/test', { host }),
      audit: (event, detail) => call('POST', 'access-log', { event, detail }).catch(() => null),
      override: (password) => call('POST', 'license/override', { password }),
      licenseKey: () => call('GET', 'license/key'),
      setOverridePassword: (current, password) => call('POST', 'license/override-password', { current, password }),
      registry: () => call('GET', 'license/registry'),
      issue: (body) => call('POST', 'license/issue', body),
      release: (outputDir) => call('GET', 'release' + (outputDir ? '?outputDir=' + encodeURIComponent(outputDir) : '')),
      publish: (body) => call('POST', 'release/publish', body),
      update: () => call('GET', 'update'),
      checkUpdate: () => call('POST', 'update/check'),
      installUpdate: (version) => call('POST', 'update/install', { version }),
      // PRTG-style monitoring: reads are GET, changes are POST, both on /api/monitor
      monitor: (op, body) => (MON_READ.includes(op)
        ? call('GET', 'monitor?' + new URLSearchParams(Object.assign({ op }, body || {})).toString())
        : call('POST', 'monitor', Object.assign({ op }, body || {}))),
    };
  }
  const MON_READ = ['tree', 'sensor', 'channels', 'types', 'log', 'groups', 'notifications', 'discovery', 'outbound', 'profiles'];

  // ------------------------------------------------------------------ demo backend (in the browser)
  function demo() {
    const D = root.MCDemo;
    const store = (() => {
      try { const s = root.sessionStorage; s.setItem('_mc', '1'); s.removeItem('_mc'); return s; } catch (e) { return null; }
    })();
    const get = (k, d) => { try { const v = store && store.getItem('mc.' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
    const set = (k, v) => { try { store && store.setItem('mc.' + k, JSON.stringify(v)); } catch (e) { /* private mode */ } };

    let ds = D.all();
    const history = D.computeHistory(24, 5);
    const manifest = root.MC_MANIFEST || { scripts: [], support: [] };
    const RB = root.MCRbac, CM = root.MCCredModel;
    const users = get('users2', [
      { name: 'admin', email: 'it.admin@moncastle.com', role: 'admin', restricted: false, created: new Date(Date.now() - 40 * 864e5).toISOString(), lastLogin: null },
      { name: 'noc.operator', email: 'noc@moncastle.com', role: 'contributor', restricted: false, created: new Date(Date.now() - 22 * 864e5).toISOString(), lastLogin: new Date(Date.now() - 3 * 36e5).toISOString() },
      { name: 'auditor', email: 'audit@moncastle.com', role: 'reader', restricted: false, created: new Date(Date.now() - 9 * 864e5).toISOString(), lastLogin: new Date(Date.now() - 26 * 36e5).toISOString() },
      { name: 'branch.helpdesk', email: 'helpdesk.alex@moncastle.com', role: 'reader', restricted: true, created: new Date(Date.now() - 5 * 864e5).toISOString(), lastLogin: new Date(Date.now() - 50 * 36e5).toISOString() },
    ]);
    const userGroups = get('usergroups', [
      { id: 'ug:noc', name: 'NOC engineers', description: 'Run the day-to-day monitoring', members: ['noc.operator'], grants: [{ scope: 'all', role: 'contributor' }] },
      { id: 'ug:net', name: 'Network team', description: 'Switches, firewalls, access points and printers only', members: ['branch.helpdesk'], grants: [{ scope: 'g:net', role: 'contributor' }, { scope: 'g:printers', role: 'contributor' }] },
      { id: 'ug:dba', name: 'Database administrators', description: '', members: ['noc.operator'], grants: [{ scope: 'g:sql', role: 'admin' }] },
      { id: 'ug:audit', name: 'Auditors', description: 'Read-only access for audits', members: ['auditor'], grants: [{ scope: 'all', role: 'reader' }] },
    ]);
    const saveUsers = () => { set('users2', users); set('usergroups', userGroups); };
    const day = (n) => new Date(Date.now() - n * 864e5).toISOString();
    // demo vault: only names, kinds and non-secret fields; secrets are never kept in the browser, only "set" flags
    const creds = get('creds', [
      { id: 'cr:win-default', name: 'CORP\\svc-moncastle', kind: 'windows', description: 'Monitoring service account (gMSA style), member of Remote Management Users', fields: { domain: 'CORP', username: 'svc-moncastle', transport: 'WinRM HTTP (5985)', auth: 'Kerberos' }, set: ['password'], assign: { all: true, groups: [], devices: [] }, minRole: 'contributor', userGroups: [], created: day(40), createdBy: 'admin', lastUsed: day(0.01), lastTest: { ok: true, host: 'DC01', at: day(2), message: 'Port 5985 answers.' } },
      { id: 'cr:win-dc', name: 'CORP\\svc-mc-dc', kind: 'windows', description: 'Domain controller monitoring (Event Log Readers, DNS admins)', fields: { domain: 'CORP', username: 'svc-mc-dc', transport: 'WinRM HTTPS (5986)', auth: 'Kerberos' }, set: ['password'], assign: { all: false, groups: ['g:dc', 'g:ad'], devices: [] }, minRole: 'admin', userGroups: [], created: day(38), createdBy: 'admin', lastUsed: day(0.02) },
      { id: 'cr:ssh', name: 'Linux monitoring (SSH key)', kind: 'ssh', description: '', fields: { username: 'moncastle', method: 'Private key', port: 22, elevation: 'sudo' }, set: ['privateKey'], assign: { all: false, groups: ['g:lnx'], devices: [] }, minRole: 'contributor', userGroups: [], created: day(30), createdBy: 'admin', lastUsed: day(0.05) },
      { id: 'cr:snmp3', name: 'Network SNMP v3', kind: 'snmpv3', description: 'Read-only view on all switches and firewalls', fields: { username: 'mc-ro', level: 'authPriv', authProtocol: 'SHA-256', privProtocol: 'AES', port: 161 }, set: ['authPassword', 'privPassword'], assign: { all: false, groups: ['g:net'], devices: [] }, minRole: 'contributor', userGroups: ['ug:net', 'ug:noc'], created: day(20), createdBy: 'admin', lastUsed: day(0.003), lastTest: { ok: true, host: '10.10.0.1', at: day(1), message: 'Signed in: CORE-SW-HQ01 (Cisco IOS XE 17.9)' } },
      { id: 'cr:snmp2', name: 'Printers SNMP v2c', kind: 'snmpv2', description: '', fields: { version: 'v2c', port: 161 }, set: ['community'], assign: { all: false, groups: ['g:printers'], devices: [] }, minRole: 'contributor', userGroups: [], created: day(20), createdBy: 'admin', lastUsed: day(0.004) },
      { id: 'cr:vmw', name: 'vCenter read-only', kind: 'vmware', description: '', fields: { username: 'mc-ro@vsphere.local', port: 443, ignoreCert: 'Verify' }, set: ['password'], assign: { all: false, groups: ['g:vmw'], devices: [] }, minRole: 'admin', userGroups: [], created: day(15), createdBy: 'admin', lastUsed: day(0.1) },
      { id: 'cr:sql', name: 'SQL monitor login', kind: 'sql', description: 'VIEW SERVER STATE only', fields: { method: 'SQL login', username: 'mc_monitor', port: 1433, encrypt: 'Mandatory' }, set: ['password'], assign: { all: false, groups: ['g:sql'], devices: [] }, minRole: 'contributor', userGroups: ['ug:dba'], created: day(12), createdBy: 'admin', lastUsed: day(0.2) },
      { id: 'cr:web', name: 'Intranet API key', kind: 'http', description: '', fields: { method: 'API key header', header: 'X-API-Key' }, set: ['token'], assign: { all: false, groups: ['g:web-checks'], devices: [] }, minRole: 'contributor', userGroups: [], created: day(4), createdBy: 'noc.operator', lastUsed: day(0.01) },
    ]);
    const saveCreds = () => set('creds', creds);
    const insights = get('insights', { dashboards: [], reports: [] });
    const withAccess = (u) => u && Object.assign({}, u, { access: (gid) => (u.override ? 'admin' : RB.access(u, gid, userGroups, monitorCore().chain)) });
    const credUsable = (c, u) => {
      if (!u) return false;
      const role = RB.norm(u.role);
      if (role === 'admin' || u.override) return true;
      if (c.private && c.createdBy !== u.name) return false;
      if ((c.userGroups || []).length) return userGroups.some((g) => c.userGroups.includes(g.id) && g.members.includes(u.name));
      const need = c.minRole || 'contributor', ua = withAccess(u);
      return RB.atLeast(role, need) || (c.assign.groups || []).some((g) => RB.atLeast(ua.access(g), need));
    };
    const credView = (c) => {
      const k = CM.KIND[c.kind] || { fields: [] }, admin = user && (user.role === 'admin' || user.override);
      const used = monitorCore().devices().filter((d) => Object.values(d.credentials || {}).includes(c.id)).map((d) => d.name);
      return { id: c.id, name: c.name, kind: c.kind, kindName: k.name, description: c.description || '', fields: Object.assign({}, c.fields), secretsSet: admin ? Object.fromEntries(k.fields.filter((f) => f.secret).map((f) => [f.name, (c.set || []).includes(f.name)])) : null,
        assign: c.assign, minRole: c.minRole, userGroups: c.userGroups || [], private: !!c.private, created: c.created, createdBy: c.createdBy, updated: c.updated || null, lastUsed: c.lastUsed || null, lastTest: c.lastTest || null, usedBy: used, editable: !!admin || c.createdBy === user.name };
    };
    const jobs = [];
    const log = seedLog();
    let license = get('license', null);
    let user = get('user', null);

    function seedLog() {
      const out = [];
      const ev = [['login', 'admin', 'Signed in'], ['view', 'noc.operator', 'Opened Monitoring / Compute'], ['run', 'noc.operator', 'mon.processes on SQL01'], ['credential', 'admin', 'Added snmpv3 credential Network SNMP v3, groups g:net'], ['login', 'auditor', 'Signed in'], ['view', 'auditor', 'Opened Audit'], ['license', 'system', 'Licence revalidated against RoboMate-MonCastle-Licenses'], ['sync', 'system', 'Scripts synced: 56 scripts, manifest ' + ((manifest.generated || '').slice(0, 10) || 'current')], ['login-failed', 'unknown', 'Bad password for "administrator"'], ['run', 'admin', 'act.service Start DFSR on DC02 (WhatIf)'], ['push', 'system', 'Access log batch pushed to RoboMate-MonCastle-Access']];
      for (let i = 0; i < 46; i++) {
        const e = ev[(i * 7) % ev.length];
        out.push({ time: new Date(Date.now() - i * 47 * 6e4 - 90e3).toISOString(), event: e[0], user: e[1], ip: e[1] === 'system' ? '127.0.0.1' : '10.10.' + (50 + (i % 4)) + '.' + (20 + (i % 30)), detail: e[2] });
      }
      return out;
    }
    const audit = (event, detail) => { log.unshift({ time: new Date().toISOString(), event, user: user ? user.name : 'anonymous', ip: '10.10.50.24', detail }); return Promise.resolve({ ok: true }); };
    const deny = (msg, status = 403) => { const e = new Error(msg); e.status = status; return Promise.reject(e); };
    const licenseView = () => license
      ? { state: 'valid', masked: MASK(license.last4), holder: license.holder, edition: license.edition, expires: license.expires, checkedAt: license.checkedAt, maxNodes: license.maxNodes, repo: 'MarcoFekry/RoboMate-MonCastle-Licenses', readOnly: false, source: 'demo' }
      : { state: 'missing', masked: null, readOnly: true };

    async function status() {
      await sleep(120);
      return {
        mode: 'demo', version: '4.7.4', consoleId: 'MC01-demo', product: 'RoboMate MonCastle',
        license: licenseView(), setupRequired: false, user: user ? Object.assign({}, user, { groups: userGroups.filter((g) => g.members.includes(user.name)).map((g) => ({ id: g.id, name: g.name, grants: g.grants })) }) : null, overrideConfigured: true, url: 'https://robomatemoncastle:5050',
        release: { version: release.current.version, released: release.current.released, update: release.lastCheck },
        protection: { encrypted: true, keyFrom: 'file', packaged: true, demo: true },
        repos: { scripts: 'MarcoFekry/RoboMate-MonCastle-Scripts', licenses: 'MarcoFekry/RoboMate-MonCastle-Licenses', access: 'MarcoFekry/RoboMate-MonCastle-Access', console: 'MarcoFekry/RoboMate-MonCastle-Console' },
        scripts: { source: 'github', count: manifest.scripts.length, synced: manifest.generated || null, ref: 'main' },
        accessLog: { pending: 3, lastPush: new Date(Date.now() - 4 * 6e4).toISOString(), target: 'access-logs/MC01-demo/' },
      };
    }

    async function licenseCheck(token) {
      await sleep(700);
      if (token && !isKey(token)) return deny(KEY_ONLY, 400);
      const t = toToken(token);
      license = { key: t ? toKey(t) : null, last4: t ? t.slice(-4) : '7Q2c', holder: 'MonCastle Demo Co.', edition: 'Enterprise (demo)', expires: new Date(Date.now() + 318 * 864e5).toISOString(), maxNodes: 1000, checkedAt: new Date().toISOString() };
      set('license', Object.assign({}, license, { key: null }));
      audit('license', 'Licence verified (' + MASK(license.last4) + ')');
      return licenseView();
    }

    async function login(name, password, remember) {
      await sleep(350);
      if (!license) return deny('This console has no valid licence. Activate one, or use the administrator override.', 402);
      const u = users.find((x) => x.name.toLowerCase() === String(name || '').toLowerCase());
      const ok = u && (password === 'MonCastle!demo');
      if (!ok) { audit('login-failed', 'Bad credentials for "' + name + '"'); return deny('Wrong user name or password. In the demo use admin / MonCastle!demo.', 401); }
      u.lastLogin = new Date().toISOString();
      user = { name: u.name, role: RB.norm(u.role), restricted: !!u.restricted };
      set('user', user);
      saveUsers();
      audit('login', 'Signed in');
      return { user };
    }

    async function run(script, params = {}, opt = {}) {
      if (!user) return deny('Sign in first.', 401);
      const s = manifest.scripts.find((x) => x.id === script);
      if (!s) return deny('Unknown script ' + script, 404);
      if (script === 'act.remote.code') return deny('Run code from Actions › Remote scripting.', 400);
      // effective role on the targets' device groups, like the server
      const ua = withAccess(user);
      const targets = [].concat(params.ComputerName || [], params.VMName || [], params.Target || []).map((n) => monitorCore().deviceByName(n)).filter(Boolean);
      const role = targets.length ? targets.map((d) => ua.access(d.group)).reduce((a, r) => (RB.RANK[r] < RB.RANK[a] ? r : a), 'admin') : user.restricted && user.role !== 'admin' ? 'reader' : RB.norm(user.role);
      if (role === 'none') return deny('You have no access to ' + targets.filter((d) => ua.access(d.group) === 'none').map((d) => d.name).join(', ') + '.');
      const need = RB.scriptRole(s);
      if (!RB.atLeast(user.override ? 'admin' : role, need)) return deny(need === 'admin' ? 'High-risk actions need an administrator.' : 'Your role (' + role + ') cannot run actions on these devices; it needs contributor.');
      if ((s.secrets || []).some((n) => !(opt.secrets || {})[n])) return deny('Missing secret value.', 400);
      const job = startJob(s, params, !!opt.whatIf, user.name);
      audit('run', script + ' ' + summarizeParams(job.params) + (job.whatIf ? ' (WhatIf)' : ''));
      return { job };
    }
    // one demo job: a simulated result after a second or two (run() and scheduled jobs)
    function startJob(s, params, whatIf, by, onDone) {
      const script = s.id;
      const job = { id: 'job-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), script, title: s.title, params: redact(s, params), whatIf, user: by, state: 'running', started: new Date().toISOString(), finished: null, result: null };
      jobs.unshift(job);
      const ms = 700 + Math.random() * 1600;
      setTimeout(() => {
        let result;
        if (s.kind === 'collector') {
          ds = D.all();
          result = ds[s.dataset] || { moncastle: '4.0.0', dataset: s.dataset, status: 'ok', message: 'Collector finished (demo).', data: [], count: 0, warnings: [] };
        } else {
          result = D.simulate(s.id, params);
        }
        if (job.whatIf && result && Array.isArray(result.data)) result = Object.assign({}, result, { message: 'WhatIf: nothing was changed. ' + (result.message || ''), data: result.data.map((r) => Object.assign({}, r, { Result: r.Result ? 'WhatIf - would run: ' + (params.Operation || params.State || params.Mode || s.title) : r.Result })) });
        job.result = result;
        job.state = result && result.status === 'error' ? 'failed' : 'done';
        job.finished = new Date().toISOString();
        if (onDone) onDone(job);
      }, ms);
      return job;
    }
    function redact(s, p) {
      const out = {};
      Object.keys(p || {}).forEach((k) => (out[k] = (s.secrets || []).includes(k) ? '••••••' : p[k]));
      return out;
    }
    function summarizeParams(p) { return Object.entries(p).map(([k, v]) => k + '=' + (Array.isArray(v) ? v.join(',') : v)).join(' ').slice(0, 140); }

    // licence registry and releases (demo copies of what the server reads from GitHub and the release folder)
    const registryData = {
      source: 'github', repo: 'MarcoFekry/RoboMate-MonCastle-Licenses', policy: { requireRegistration: true },
      licenses: [
        { id: 'MC-2026-0001', holder: 'MonCastle Demo Co.', fingerprint: '9f3c1a7be2d04c55', edition: 'Enterprise (demo)', expires: new Date(Date.now() + 318 * 864e5).toISOString().slice(0, 10), maxNodes: 1000, revoked: false, issued: '2026-01-12', current: true },
        { id: 'MC-2026-0002', holder: 'Branch IT - North', fingerprint: '41d07e9a1c3bb820', edition: 'Standard', expires: new Date(Date.now() + 41 * 864e5).toISOString().slice(0, 10), maxNodes: 250, revoked: false, issued: '2026-03-02' },
        { id: 'MC-2025-0014', holder: 'Former contractor', fingerprint: 'c2a95f30d8e61b47', edition: 'Standard', expires: '2026-06-30', maxNodes: 100, revoked: false, issued: '2025-07-01' },
        { id: 'MC-2025-0009', holder: 'Lab console', fingerprint: '07be4d2f9a6c1e35', edition: 'Standard', expires: null, maxNodes: 50, revoked: true, issued: '2025-04-18' },
      ],
    };
    registryData.licenses.forEach((l) => (l.state = l.revoked ? 'revoked' : l.expires && Date.parse(l.expires) < Date.now() ? 'expired' : 'active'));
    const release = {
      current: { product: 'RoboMate MonCastle Console', version: '4.7.4', released: '2026-11-01T00:00:00.000Z', notes: 'Monitoring engines are off until configured (per device, device type, group or the engine\'s own scope) with engine credentials per device or group; engine run details and a new My jobs view; monitoring profiles (sensors, options and actions) assigned to groups and devices; devices in several groups; Auto-discovery detects the device type and group; the software inventory engine covers Windows and Linux; the web server engine covers every common web, application and proxy server on Windows and Linux; the database engine covers 97 engines in 13 categories.' },
      latest: { version: '4.1.0', released: new Date(Date.now() - 2 * 864e5).toISOString(), notes: 'Licence administration, release publishing and in-console updates.\nPort 5050 and the robomatemoncastle host name.', size: 412318, zip: 'releases/RoboMate-MonCastle-Console-4.1.0.zip', sha256: '5d1f0c9e7a2b44e0f3c6a18d9b7e2c51a0f4d3b8c6e9a1d2f7b0c3e5a8d4f6b1' },
      published: [{ file: 'releases/RoboMate-MonCastle-Console-4.1.0.zip', version: '4.1.0', size: 412318, modified: new Date(Date.now() - 2 * 864e5).toISOString() }, { file: 'releases/RoboMate-MonCastle-Console-4.0.0.zip', version: '4.0.0', size: 398004, modified: '2026-10-23T00:00:00.000Z' }],
      lastCheck: null,
    };
    const semver = (v) => String(v).split('.').map((x) => parseInt(x, 10) || 0);
    const newer = (a, b) => { const x = semver(a), y = semver(b); for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] > y[i]; return false; };
    const needAdmin = () => (!user || user.role !== 'admin' ? deny('Administrators only.') : null);

    const schedules = manifest.scripts.filter((s) => s.kind === 'collector').map((s, i) => ({ id: s.id, every: s.schedule || '1h', enabled: true, lastRun: new Date(Date.now() - (i % 9 + 1) * 4 * 6e4).toISOString(), lastStatus: s.id === 'mon.vmware' ? 'warning' : 'ok', durationSec: 3 + (i * 7) % 40 }));

    // demo engines: installed as Windows scheduled tasks, like a real console host
    const toMs = (e) => { const m = /^(\d+)\s*([smhd])$/i.exec(String(e || '')); return m ? +m[1] * { s: 1e3, m: 6e4, h: 36e5, d: 864e5 }[m[2].toLowerCase()] : 0; };
    let enginesInstalled = true;
    // 4.7.4: no engine runs until it is configured. The demo company configured most of them; these are left for you to set up.
    const DEMO_UNSET = ['mon.linux.audit', 'mon.kubernetes', 'mon.intune', 'inv.intune.devices', 'mon.cloud.network', 'mon.openshift'];
    const eng = schedules.map((s, i) => {
      const m = manifest.scripts.find((x) => x.id === s.id) || {};
      return { id: s.id, title: m.title, category: m.category, resource: m.resource, schedule: m.schedule, every: s.every, runAs: 'SYSTEM', lastRun: s.lastRun, durationSec: s.durationSec,
        flag: /^lnx/.test(s.id) ? false : DEMO_UNSET.includes(s.id) ? null : true, run: i % 11 === 3 ? 'Running' : 'Ready',
        lastStatus: s.id === 'mon.vmware' ? 'warning' : /printers/.test(s.id) ? 'error' : 'ok',
        message: s.id === 'mon.vmware' ? '1 host in maintenance mode' : /printers/.test(s.id) ? 'PRN-HQ-03 did not answer (RPC server unavailable)' : null };
    });
    // demo engine targets (Monitoring engines > engine > Targets), kept in this browser
    const ES = root.MCEngineScope, scopes = get('engineScopes', {}) || {};
    const scopeFor = (meta) => (ES.familyOf(meta) ? ES.migrate(meta, scopes[meta.id] || (DEMO_UNSET.includes(meta.id) ? undefined : { added: true, useDefault: true })) : null);
    const engState = (e) => {
      const meta = manifest.scripts.find((x) => x.id === e.id) || { id: e.id };
      if (e.flag === false) return 'Disabled';
      return ES.configured(meta, scopeFor(meta), (monitorCore().targets()[e.id] || []).length, e.flag) ? e.run : 'Not configured';
    };
    const engineList = () => ({
      host: 'windows', canInstall: true, tasksInstalled: enginesInstalled ? eng.length : 0, taskPath: '\\RoboMate\\MonCastle\\Engines\\', error: null, checked: new Date().toISOString(),
      engines: eng.map((e) => { const state = engState(e); const nc = state === 'Not configured' && !e.ran; const x = Object.assign({}, e, nc ? { lastRun: null, lastStatus: null, message: null, durationSec: null } : {}, { state, configured: state !== 'Not configured', host: enginesInstalled ? 'task' : 'console', runAs: enginesInstalled ? e.runAs : 'console', nextRun: state === 'Disabled' || state === 'Not configured' ? null : new Date(Math.max(Date.now() + 6e4, Date.parse(e.lastRun) + toMs(e.every))).toISOString() }); delete x.run; delete x.flag; return x; }),
    });
    const scopeView = (id) => {
      const meta = manifest.scripts.find((x) => x.id === id); if (!meta) return deny('Unknown engine', 404);
      const fam = ES.familyOf(meta), sc = scopeFor(meta);
      let n = 0; if (sc) { try { n = ES.expand(sc.hosts).length; } catch (e) { n = 0; } const mc = monitorCore(); n += ES.addedDevices(meta, sc, mc.devices()).length; }
      const e = eng.find((x) => x.id === id);
      return { id, family: fam, scope: sc, describe: ES.describe(meta, sc), configured: e ? engState(e) !== 'Not configured' : false, preview: { assigned: (monitorCore().targets()[id] || []).length, scoped: n } };
    };
    const engineScope = async (id) => { await sleep(120); if (!user) return deny('Sign in first.', 401); return scopeView(id); };
    const setEngineScope = async (id, scope) => {
      const na = needAdmin(); if (na) return na;
      await sleep(300);
      const meta = manifest.scripts.find((x) => x.id === id); if (!meta) return deny('Unknown engine', 404);
      let sc; try { sc = ES.normalize(meta, scope); } catch (e) { return deny(e.message, 400); }
      scopes[id] = sc; set('engineScopes', scopes);
      audit('engine', 'Targets of ' + id + ': ' + ES.describe(meta, sc));
      return scopeView(id);
    };
    const engineAction = async (action, id, every) => {
      const na = needAdmin(); if (na) return na;
      await sleep(500);
      if (action === 'install' || action === 'uninstall') enginesInstalled = action === 'install';
      const list = !id || id === 'All' ? eng : eng.filter((e) => e.id === id);
      if (!list.length) return deny('Unknown engine ' + id, 404);
      if (action === 'interval' && !toMs(every)) return deny('Use an interval like 5m, 1h or 24h', 400);
      if (id && id !== 'All' && (action === 'start' || action === 'restart') && engState(list[0]) === 'Not configured') return deny((list[0].title || id) + ' is not configured yet: choose the devices, groups or hosts it reads on its Targets tab.', 409);
      for (const e of list) {
        if (action === 'enable') e.flag = true;
        if (action === 'disable') { e.flag = false; e.run = 'Ready'; }
        if (action === 'reset') e.flag = null;
        if (action === 'stop' && e.run === 'Running') e.run = 'Ready';
        if (action === 'interval') e.every = every;
        if ((action === 'start' || action === 'restart') && engState(e) === 'Ready') {
          e.run = 'Running';
          setTimeout(() => { if (e.run === 'Running') { e.run = 'Ready'; e.ran = true; e.lastRun = new Date().toISOString(); e.lastStatus = e.lastStatus === 'error' ? 'error' : 'ok'; } }, 2500 + Math.random() * 2500);
        }
      }
      audit('engine', action + ' ' + (!id || id === 'All' ? 'all engines' : id) + (action === 'interval' ? ' every ' + every : ''));
      return engineList();
    };

    // demo monitoring: the same core as the server, with the simulated probe
    let mon = null;
    const monSent = [];
    let monScan = null, smtpPassword = false;
    // scheduled jobs in the demo: the same rules as server/lib/jobdefs.js, runs simulated in the browser
    const JD = root.MCJobDefs;
    const jobDefs = get('jobdefs', null) || seedJobDefs();
    function seedJobDefs() {
      const t = (h) => new Date(Date.now() - h * 36e5).toISOString();
      const mk = (id, name, script, params, target, schedule, extra) => Object.assign({ id, name, script, params, target: Object.assign({ groups: [], devices: [] }, target), credential: null, schedule, enabled: true, whatIf: false, notify: { onFailure: true, to: 'it-ops@corp.moncastle.local' }, parallel: 10, description: '', created: t(400), createdBy: 'admin', cursor: new Date().toISOString(), lastRun: t(20), lastStatus: 'ok', history: [{ id: 'r-' + id, at: t(20), by: 'scheduler', status: 'ok', jobs: [], pending: 0, ok: 1, failed: 0, targets: 0, message: '', finished: t(19.9) }] }, extra || {});
      return [
        mk('jd-netbackup', 'Nightly switch and firewall config backup', 'act.net.config.backup', { KeepVersions: 30 }, { mode: 'groups', groups: ['g:net', 'g:fw'] }, { type: 'daily', times: ['01:30'] }),
        mk('jd-lnxpatch', 'Linux security updates (Saturday)', 'act.lnx.patch', { Scope: 'SecurityOnly', RebootIfRequired: true }, { mode: 'groups', groups: ['g:lnx'] }, { type: 'weekly', days: [6], times: ['02:00'] }),
        mk('jd-gpupdate', 'Group Policy refresh on domain controllers', 'act.gpupdate', { Target: 'Computer' }, { mode: 'groups', groups: ['g:dc'] }, { type: 'interval', every: '4h' }, { lastStatus: 'partial' }),
        mk('jd-stale', 'Stale AD accounts report', 'act.ad.stale', { Operation: 'Report', InactiveDays: 90 }, { mode: 'none' }, { type: 'monthly', day: 1, times: ['06:00'] }, { whatIf: true }),
        mk('jd-cleanup', 'Disk cleanup on all Windows servers', 'act.storage.diskcleanup', { OlderThanDays: 7 }, { mode: 'all' }, { type: 'weekly', days: [0], times: ['03:00'] }, { enabled: false, lastStatus: null, history: [], lastRun: null, cursor: null }),
      ];
    }
    const saveJobDefs = () => set('jobdefs', jobDefs);
    const jdScript = (id) => manifest.scripts.find((x) => x.id === id);
    const jdDue = (d) => JD.nextRun(d, d.cursor ? Date.parse(d.cursor) + 6e4 : Date.parse(d.created || new Date().toISOString()), d.cursor);
    const jdView = (d) => { const s = jdScript(d.script) || {}; const n = d.enabled ? jdDue(d) : null; return Object.assign({}, d, { title: s.title || d.script, risk: s.risk || null, resource: JD.categoryOf(s), kind: s.kind || null, when: JD.describe(d.schedule), nextRun: n ? new Date(n).toISOString() : null, missing: !s.id, running: (d.history || []).some((h) => h.status === 'running'), credentialName: d.credential ? (creds.find((c) => c.id === d.credential) || {}).name || '(deleted credential)' : null }); };
    function jdStart(d, by) {
      const s = jdScript(d.script);
      const run = { id: 'r-' + Date.now().toString(36), at: new Date().toISOString(), by, status: 'running', jobs: [], pending: 0, ok: 0, failed: 0, targets: 0, message: '' };
      d.history = [run].concat(d.history || []).slice(0, 50); d.lastRun = d.cursor = run.at;
      const hp = JD.hostParam(s);
      const devs = hp ? JD.targetsOf(d, s, monitorCore().devices(), monitorCore().chain) : [];
      if (hp && !devs.length) { run.status = d.lastStatus = 'skipped'; run.message = 'No devices match (' + (JD.kindsOf(s).join(', ') || 'any kind') + ').'; saveJobDefs(); return run; }
      run.targets = devs.length;
      const names = devs.map((x) => x.name);
      const batches = !hp ? [null] : hp.multi ? [names] : names;
      for (const b of batches.slice(0, 200)) {
        const params = Object.assign({}, d.params); if (hp) params[hp.name] = b;
        const job = startJob(s, params, d.whatIf, 'job: ' + d.name, (j) => { run.pending--; if (j.state === 'failed') run.failed++; else run.ok++; if (run.pending <= 0) { run.status = d.lastStatus = run.failed && !run.ok ? 'failed' : run.failed ? 'partial' : 'ok'; run.finished = new Date().toISOString(); } saveJobDefs(); });
        run.jobs.push(job.id); run.pending++;
      }
      audit('jobdef-run', d.name + ' (' + s.id + ') on ' + (hp ? run.targets + ' devices' : 'its configured scope') + (d.whatIf ? ' (WhatIf)' : '') + ' by ' + by);
      saveJobDefs();
      return run;
    }
    setInterval(() => { for (const d of jobDefs) { if (!d.enabled || (d.history || []).some((h) => h.status === 'running')) continue; const n = jdDue(d); if (n != null && n <= Date.now() && Date.now() - n < 864e5) jdStart(d, 'scheduler'); } }, 30000);
    const jobdefApi = {
      jobdefs: async () => { await sleep(100); if (!user) return deny('Sign in first.', 401); return jobDefs.map(jdView); },
      previewJobdef: async (b) => { const s = jdScript(b.script); if (!s) return deny('Choose an action or tool.', 400); const hp = JD.hostParam(s); return hp ? JD.targetsOf(b, s, monitorCore().devices(), monitorCore().chain).map((d) => ({ id: d.id, name: d.name, kind: d.kind, group: d.group })) : []; },
      saveJobdef: async (b) => {
        await sleep(200); const na = needAdmin(); if (na) return na;
        const s = jdScript(b.script);
        let c; try { c = JD.clean(b, s); } catch (e) { return deny(e.message, 400); }
        if (s.risk === 'high' && !c.whatIf && b.confirmHighRisk !== true) return deny('This is a high-risk action. Tick "Run without asking each time" to schedule it, or turn on WhatIf.', 400);
        if (c.credential) { const cr = creds.find((x) => x.id === c.credential); if (!cr) return deny('That credential no longer exists.', 400); if (s.credential && cr.kind !== s.credential) return deny(s.title + ' needs a ' + s.credential + ' credential; ' + cr.name + ' is ' + cr.kind + '.', 400); }
        const now = new Date().toISOString();
        let d = b.id ? jobDefs.find((x) => x.id === b.id) : null;
        if (d) { const moved = JSON.stringify(d.schedule) !== JSON.stringify(c.schedule); Object.assign(d, c, { updated: now, updatedBy: user.name }); if (moved) { d.cursor = null; d.created = now; } }
        else { d = Object.assign({ id: 'jd-' + Math.random().toString(36).slice(2, 12) }, c, { created: now, createdBy: user.name, history: [], lastRun: null, lastStatus: null }); jobDefs.push(d); }
        saveJobDefs();
        const v = jdView(d);
        audit('jobdef', (b.id ? 'Changed' : 'Created') + ' scheduled job ' + v.name + ' (' + v.script + ', ' + v.when + ', ' + v.target.mode + (v.credentialName ? ', run as ' + v.credentialName : '') + (v.whatIf ? ', WhatIf' : '') + ')');
        return v;
      },
      jobdefAction: async (id, action) => {
        await sleep(150); const na = needAdmin(); if (na) return na;
        const d = jobDefs.find((x) => x.id === id); if (!d) return deny('No such job.', 404);
        if (action === 'run') { if ((d.history || []).some((h) => h.status === 'running')) return deny('This job is already running.', 400); const r = jdStart(d, user.name); return { run: r, job: jdView(d) }; }
        d.enabled = action === 'enable'; saveJobDefs(); audit('jobdef', (d.enabled ? 'Turned on' : 'Paused') + ' scheduled job ' + d.name); return jdView(d);
      },
      removeJobdef: async (id) => { const na = needAdmin(); if (na) return na; const i = jobDefs.findIndex((x) => x.id === id); if (i < 0) return deny('No such job.', 404); const [d] = jobDefs.splice(i, 1); saveJobDefs(); audit('jobdef', 'Deleted scheduled job ' + d.name); return { ok: true }; },
    };
    // the browser demo also shows a rule for user groups (the server demo has no such groups)
    function demoMonConfig(S, MD) {
      const c = MD.config(S);
      c.notifications.rules.push({ id: 'r:demo3', name: 'Database and network teams', enabled: true, on: ['Down', 'Warning', 'Up'], delayMin: 0, groups: ['g:sql', 'g:net'], devices: [], sensors: [], types: [], template: 'tpl:short', targets: [{ kind: 'usergroup', id: 'ug:dba' }, { kind: 'usergroup', id: 'ug:net' }, { kind: 'user', name: 'admin' }] });
      return c;
    }
    function monitorCore() {
      if (mon) return mon;
      const S = root.MCSensors, MD = root.MCMonitorDemo;
      mon = root.MCMonitorCore.createCore({
        sensors: S, datasets: () => Object.assign({}, ds, { 'os.releases': osrDemo() }), config: demoMonConfig(S, MD), probeName: 'Local probe (MONCASTLE01)', runAll: true, alertSources: root.MCAlertSources, retention: () => retPolicy, servers: () => infraList().map((x) => ({ id: x.id, name: x.name, site: x.site, state: x.state, role: x.role, cpu: x.util && x.util.cpu, mem: x.util && x.util.mem, devices: x.devices, sensors: x.sensors })),
        probe: (s) => MD.probe(s, S), seed: (s, ch) => MD.seed(s, ch),
        scripts: () => manifest.scripts,
        notify: (rule, target, e) => { monSent.unshift({ t: new Date().toISOString(), rule: rule.name, target: (target.via ? target.via + ': ' : '') + (target.kind === 'email' ? target.to || '(no address)' : target.url.replace(/(\/\/[^/]+\/).+/, '$1…')), sensor: e.sensorName, device: e.deviceName, state: e.to, result: target.missing ? 'failed: ' + target.missing : 'sent (demo, nothing delivered)' }); if (monSent.length > 200) monSent.length = 200; },
        directory: () => ({ users: users.map((u) => ({ name: u.name, email: u.email || '' })), groups: userGroups.map((g) => ({ id: g.id, name: g.name, members: g.members.slice() })) }),
        mail: root.MCMail, outboundDefs: root.MCOutbound,
        outbound: (ob, e) => demoOutbound(ob, e),
        // onboarding collects the device's inventory (demo: rows like the collectors return, merged into the datasets)
        onDeviceAdded: (d) => { const plan = S.inventoryPlan(d); D.onboard(d, plan); ds = D.all(); return plan.map((x) => ({ script: x.script, label: x.label, dataset: x.dataset, state: 'done' })); },
      });
      for (const d of mon.config().devices || []) { D.onboard(d, S.inventoryPlan(d)); if (d.audit) D.auditOn(d); }
      ds = D.all();
      mon.refreshDerived(true);
      mon.runDue(100);
      setInterval(() => { mon.refreshDerived(); mon.runDue(24); }, 5000);
      return mon;
    }
    // demo MonCastle infrastructure: the central console and two remote servers with believable utilisation
    const infraSrv = get('infra', null) || [
      { id: 'srv:local', name: 'MONCASTLE01', role: 'central', site: 'Head office (Cairo)', host: 'moncastle01.corp.moncastle.local:5050', created: '2026-01-12T09:00:00Z', cores: 8, memGB: 32, base: 22 },
      { id: 'srv:moncastle-br01', name: 'MONCASTLE-BR01', role: 'remote', site: 'Branch (Alexandria)', host: 'moncastle-br01.corp.moncastle.local', created: '2026-03-02T10:30:00Z', cores: 4, memGB: 16, base: 14 },
      { id: 'srv:moncastle-dr01', name: 'MONCASTLE-DR01', role: 'remote', site: 'DR site (6th of October)', host: 'moncastle-dr01.corp.moncastle.local', created: '2026-05-18T08:15:00Z', cores: 4, memGB: 16, base: 9 },
    ];
    const saveInfra = () => set('infra', infraSrv);
    function utilAt(sv, t) {
      const h = (t / 36e5) % 24, day = Math.max(0, Math.sin(((h - 7) / 12) * Math.PI)), seed = sv.name.length * 13;
      const w = Math.sin(t / 9e5 + seed) * 0.5 + Math.sin(t / 2.3e6 + seed * 2) * 0.5;
      return { cpu: Math.round(Math.min(97, sv.base + day * sv.base * 1.2 + w * 6) * 10) / 10, mem: Math.round(Math.min(95, 38 + sv.base * 0.9 + day * 8 + w * 3) * 10) / 10, disk: Math.round((41 + sv.base * 0.6 + (t - Date.parse(sv.created)) / 864e5 * 0.01) * 10) / 10 };
    }
    function infraList() {
      const now = Date.now(), load = mon ? mon.serverLoad() : {};
      return infraSrv.map((sv) => {
        const u = utilAt(sv, now), ld = load[sv.id] || { devices: 0, sensors: 0, down: 0 };
        const history = []; for (let i = 287; i >= 0; i--) { const t = now - i * 3e5; history.push(Object.assign({ at: new Date(t).toISOString() }, utilAt(sv, t))); }
        const lastSeen = sv.role === 'central' ? new Date(now).toISOString() : new Date(now - ((now / 1000) % 30) * 1000).toISOString();
        return { id: sv.id, name: sv.name, role: sv.role, site: sv.site, host: sv.host, created: sv.created, lastSeen: sv.pending ? null : lastSeen, version: sv.pending ? null : '4.7.4', state: sv.pending ? 'Unknown' : 'Up',
          util: sv.pending ? null : Object.assign({ at: lastSeen, cores: sv.cores, memGB: sv.memGB, diskFreeGB: Math.round((100 - u.disk) * 2.4), uptimeH: Math.round((now - Date.parse(sv.created)) / 36e5 % 900), rssMB: 90 + sv.base * 4, engines: sv.role === 'central' ? 34 : 6, os: 'Windows Server 2022 Standard' }, u),
          history: sv.pending ? [] : history, devices: ld.devices, sensors: ld.sensors, down: ld.down, lastError: null };
      });
    }
    const infraAction = async (b) => {
      await sleep(300);
      const na = needAdmin(); if (na) return na;
      const sv = infraSrv.find((x) => x.id === b.id);
      if (b.action === 'add') {
        const name = String(b.name || '').trim().toUpperCase();
        if (!/^[\w.-]{1,63}$/.test(name)) return deny('Give the server its computer name (letters, digits, dot and dash)', 400);
        if (infraSrv.some((x) => x.name === name)) return deny(name + ' is already in the infrastructure', 400);
        const x = { id: 'srv:' + name.toLowerCase(), name, role: 'remote', site: String(b.site || '').slice(0, 60), host: String(b.host || ''), created: new Date().toISOString(), cores: 4, memGB: 16, base: 6, pending: true };
        infraSrv.push(x); saveInfra(); audit('infra', 'add MonCastle server ' + name);
        const rnd = Array.from({ length: 32 }, () => Math.floor(Math.random() * 256));
        return { server: infraList().find((y) => y.id === x.id), code: 'MCJ1.' + btoa(JSON.stringify({ url: 'https://moncastle01.corp.moncastle.local:5050', id: x.id, secret: btoa(String.fromCharCode(...rnd)), name, demo: true })).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '') };
      }
      if (!sv) return deny('No such server', 404);
      if (b.action === 'rotate') { if (sv.role === 'central') return deny('The central console has no join code', 400); sv.pending = true; saveInfra(); audit('infra', 'rotate MonCastle server ' + sv.name); return infraAction({ action: '_code', id: sv.id }); }
      if (b.action === '_code') return { server: infraList().find((y) => y.id === sv.id), code: 'MCJ1.' + btoa(JSON.stringify({ url: 'https://moncastle01.corp.moncastle.local:5050', id: sv.id, secret: btoa(String(Math.random())), name: sv.name, demo: true })).replace(/=+$/, '') };
      if (b.action === 'update') { if (b.site != null) sv.site = String(b.site).slice(0, 60); if (b.host != null && sv.role !== 'central') sv.host = String(b.host); saveInfra(); audit('infra', 'update MonCastle server ' + sv.name); return { server: infraList().find((y) => y.id === sv.id) }; }
      if (b.action === 'remove') {
        if (sv.role === 'central') return deny('The central console cannot be removed', 400);
        const ld = (mon ? mon.serverLoad() : {})[sv.id]; if (ld && ld.devices) return deny('Move its ' + ld.devices + ' devices to another server first', 409);
        infraSrv.splice(infraSrv.indexOf(sv), 1); saveInfra(); audit('infra', 'remove MonCastle server ' + sv.name); return { ok: true };
      }
      if (b.action === 'joined') { delete sv.pending; saveInfra(); return { server: infraList().find((y) => y.id === sv.id) }; }
      return deny('Unknown action', 400);
    };
    let osrChecked = new Date(Date.now() - 5 * 3600e3).toISOString();
    const osrDemo = () => root.MCOSReleases.merge({ checked: osrChecked, source: 'online (demo sample values)', families: Object.fromEntries(Object.entries(root.MCDemo.DEMO_LATEST).map(([k, v]) => [k, { latest: v, source: 'demo sample' }])) });
    // demo data retention: the policy is kept in the browser; archives are generated from the demo devices and sensors
    let retPolicy = get('retention', null) || { historyDays: 31, logDays: 180, accessLogDays: 90, archive: { enabled: true, path: '', keepMonths: 36, maxGB: 50, datasets: 'daily', runAt: '02:30', compress: true } };
    let retLast = get('retentionLast', null) || { at: new Date(Date.now() - 7.5 * 36e5).toISOString(), by: 'schedule', sensorRows: 18432, accessEntries: 2210, datasets: 41, months: 0, ms: 1840 };
    const hsh = (x) => { let h = 2166136261; for (let i = 0; i < x.length; i++) h = Math.imul(h ^ x.charCodeAt(i), 16777619); return h >>> 0; };
    const retMonths = () => { const out = []; const d = new Date(); d.setUTCDate(1); for (let i = 13; i >= 0; i--) { const x = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() - i, 1)); const m = x.toISOString().slice(0, 7); const f = 0.75 + (hsh(m) % 50) / 100; const kinds = [['sensors-5m', 61e6], ['sensors-1h', 6.2e6], ['alarms', 0.9e6], ['access', 2.4e6], ['engines', 0.6e6], ['datasets', 38e6]].map(([k, b]) => ({ kind: k, bytes: Math.round(b * f * (i === 0 ? new Date().getUTCDate() / 30 : 1)), batches: Math.round(b * f / 9000) })); out.push({ month: m, bytes: kinds.reduce((a, k) => a + k.bytes, 0), kinds }); } return out; };
    const retUsage = () => { const ms = retMonths(); const arch = ms.reduce((a, m) => a + m.bytes, 0); const live = [{ name: 'Collector data', bytes: 148e6 }, { name: 'Monitoring history', bytes: 212e6 }, { name: 'Logs', bytes: 31e6 }, { name: 'Engines', bytes: 4.2e6 }, { name: 'Scripts', bytes: 2.9e6 }, { name: 'Other', bytes: 1.1e6 }]; return { live, liveBytes: live.reduce((a, x) => a + x.bytes, 0), archiveBytes: arch, archivePath: retPolicy.archive.path || 'D:\\RoboMate-MonCastle\\data\\archive', free: 412e9, growthPerDay: Math.round(ms.slice(-4, -1).reduce((a, m) => a + m.bytes, 0) / 90), months: ms }; };
    function retRead(q) {
      const m = String(q.month || ''), kind = String(q.kind || ''), limit = Math.min(20000, +q.limit || 2000);
      if (!/^\d{4}-\d{2}$/.test(m)) throw Object.assign(new Error('Pick a month and a kind of data'), { status: 400 });
      const t0 = Date.parse(m + '-01T00:00:00Z'), t1 = Math.min(Date.now(), Date.UTC(+m.slice(0, 4), +m.slice(5, 7), 1)), text = String(q.q || '').toLowerCase();
      const from = q.from ? Date.parse(q.from) : 0, to = q.to ? Date.parse(q.to) : Infinity;
      const t = monitorCore().tree(), recs = [];
      const dn = new Map(t.devices.map((d) => [d.id, d.name])); for (const x of t.sensors) x.deviceName = x.deviceName || dn.get(x.device) || x.device;
      const hit = (o) => !text || JSON.stringify(o).toLowerCase().includes(text);
      let total = 0;
      const add = (r) => { if (!hit(r)) return; total++; if (recs.length < limit) recs.push(r); };
      if (kind.startsWith('sensors')) {
        const step = kind === 'sensors-5m' ? 3e5 : 36e5;
        const sens = t.sensors.filter((x) => x.primary && (!q.device || x.device === q.device) && (!q.sensor || x.id === q.sensor)).slice(0, q.sensor ? 1 : q.device ? 40 : 25);
        for (let ts = t0; ts < t1; ts += step) {
          if (ts < from || ts > to) continue;
          for (const x of sens) { const h = hsh(x.id), base = 10 + (h % 70), v = base + Math.sin(ts / 864e5 * 6.283 + h) * base * 0.25 + Math.sin(ts / 3.6e6 + h % 7) * 3; add({ t: new Date(ts).toISOString(), sensor: x.id, sensorName: x.name, device: x.device, deviceName: x.deviceName, [x.primary]: Math.round(Math.max(0, v) * 100) / 100, samples: step / 6e4 }); }
        }
      } else if (kind === 'alarms') {
        const sens = t.sensors.filter((x) => !q.device || x.device === q.device);
        for (let ts = t0 + 3.1e6; ts < t1; ts += 2.7e6 + (hsh(String(ts)) % 9) * 6e5) { if (ts < from || ts > to) continue; const x = sens[hsh(String(ts)) % sens.length]; if (!x) break; const down = hsh(x.id + ts) % 3 === 0; add({ t: new Date(ts).toISOString(), sensor: x.id, sensorName: x.name, device: x.device, deviceName: x.deviceName, from: down ? 'Up' : 'Warning', to: down ? 'Down' : 'Up', message: down ? 'No answer within the timeout' : 'OK' }); }
      } else if (kind === 'access') {
        const who = ['admin', 'noc.operator', 'auditor', 'branch.helpdesk'], ev = [['login', 'Signed in'], ['view', 'Opened Devices & sensors'], ['run', 'Ran mon.services on FS01'], ['monitor', 'Acknowledged Ping on PRN-LOBBY'], ['export', 'Exported report Weekly availability']];
        for (let ts = t0 + 9e5; ts < t1; ts += 2.2e6) { if (ts < from || ts > to) continue; const i = hsh(String(ts)); const e = ev[i % ev.length]; add({ time: new Date(ts).toISOString(), user: who[i % who.length], ip: '10.10.' + (i % 4) + '.' + (20 + (i % 60)), event: e[0], detail: e[1], console: 'MC01-demo' }); }
      } else if (kind === 'engines') {
        for (const s of manifest.scripts.filter((x) => x.kind === 'collector').slice(0, 30)) for (const r of root.MCEngineInfo.demoHistory(s.id, 864e5 / 4, null, 124, new Date(t1).toISOString())) { const ts = Date.parse(r.at); if (ts < t0 || ts < from || ts > to) continue; add(Object.assign({ engine: s.id }, r)); }
        recs.sort((a, b) => a.at.localeCompare(b.at));
      } else if (kind === 'datasets') {
        for (let ts = t0 + 9e6; ts < t1; ts += 864e5) { if (ts < from || ts > to) continue; for (const [k, d] of Object.entries(ds)) { if (q.dataset && k !== q.dataset) continue; if (q.dataset) { for (const row of (d.data || []).slice(0, 400)) add(Object.assign({ snapshot: new Date(ts).toISOString() }, row)); } else add({ at: new Date(ts).toISOString(), dataset: k, rows: (d.data || []).length, collected: new Date(ts - 36e5).toISOString() }); } }
      } else throw Object.assign(new Error('Pick a month and a kind of data'), { status: 400 });
      return { month: m, kind, total, records: recs, truncated: total > recs.length };
    }
    const outLog = [], demoInc = {};
    function demoOutbound(ob, e) {
      const k = ob.id + '|' + e.sensor; let result = 'sent (demo, nothing delivered)';
      if (ob.direction === 'incident') {
        if (e.to === 'Up') { if (!demoInc[k]) return; result = 'resolved ' + demoInc[k] + ' (demo)'; delete demoInc[k]; }
        else if (demoInc[k]) result = 'already open: ' + demoInc[k];
        else { demoInc[k] = { servicenow: 'INC00' + (41000 + outLog.length), jira: 'ITSM-' + (200 + outLog.length), pagerduty: 'moncastle:' + e.sensor, opsgenie: 'moncastle:' + e.sensor }[ob.kind]; result = 'opened ' + demoInc[k] + ' (demo, nothing delivered)'; }
      }
      outLog.unshift({ t: new Date().toISOString(), integration: ob.name, kind: ob.kind, direction: ob.direction, state: e.to, device: e.deviceName, sensor: e.sensorName, result });
      if (outLog.length > 200) outLog.length = 200;
      if (mon) mon.outboundMark(ob.id, { lastSent: new Date().toISOString(), lastResult: result });
    }
    const monHost = {
      notifications: () => { const n = monitorCore().notifications(); n.smtp = Object.assign({}, n.smtp, { passwordSet: smtpPassword || !!n.smtp.user }); n.sent = monSent; return n; },
      setNotifications: (b) => { if (b.smtp && b.smtp.password) smtpPassword = true; if (b.smtp && b.smtp.clearPassword) smtpPassword = false; monitorCore().setNotifications(b); return monHost.notifications(); },
      test: async (t, b) => {
        await sleep(700);
        if (t.kind === 'webhook' && !/^https?:\/\//.test(t.url || '')) throw Object.assign(new Error('Webhook URL must start with http:// or https://'), { status: 400 });
        let target = t;
        if (t.kind === 'user' || t.kind === 'usergroup') target = monitorCore().resolveTargets([t])[0];
        else if (t.kind === 'email' && !/\S+@\S+/.test(t.to || '')) throw Object.assign(new Error('Enter an e-mail address'), { status: 400 });
        if (target.missing) { monSent.unshift({ t: new Date().toISOString(), rule: 'Test', target: target.via, sensor: 'Test notification', device: 'MonCastle', state: 'Down', result: 'failed: ' + target.missing }); throw Object.assign(new Error('Test failed: ' + target.missing), { status: 400 }); }
        monSent.unshift({ t: new Date().toISOString(), rule: 'Test', target: (target.via ? target.via + ': ' : '') + (target.kind === 'email' ? target.to : String(target.url).replace(/(\/\/[^/]+\/).+/, '$1…')), sensor: 'Test notification', device: 'MonCastle', state: 'Down', result: 'sent (demo, nothing delivered)' });
        return { ok: true, demo: true };
      },
      // demo outgoing integrations: the browser never keeps secrets, it only remembers that one was given
      setOutbound: (b) => {
        const def = root.MCOutbound.TARGET[b.kind]; if (!def) throw Object.assign(new Error('Unknown integration type.'), { status: 400 });
        const old = b.id ? monitorCore().outbound().find((x) => x.id === b.id) : null;
        const given = root.MCOutbound.secretsOf(b.kind).filter((k) => b.secrets && String(b.secrets[k] || '').trim());
        const had = old && old.kind === b.kind && old.secretSet;
        if (!had && def.fields.some((f) => f.secret && f.required && !given.includes(f.id))) throw Object.assign(new Error(def.fields.filter((f) => f.secret && f.required).map((f) => f.label).join(', ') + ' is required.'), { status: 400 });
        const rec = monitorCore().setOutbound(Object.assign({}, b, { secrets: undefined }));
        monitorCore().outboundMark(rec.id, { secretSet: !!(had || given.length) });
        return monitorCore().outbound().find((x) => x.id === rec.id);
      },
      outboundLog: () => outLog.slice(),
      testOutbound: async (id) => { await sleep(600); const ob = monitorCore().outbound().find((x) => x.id === id); if (!ob) throw Object.assign(new Error('No such integration.'), { status: 404 }); const e = { t: new Date().toISOString(), sensor: 'test', sensorName: 'Test alarm', deviceName: 'MonCastle', from: 'Up', to: 'Down' }; demoOutbound(ob, e); if (ob.direction === 'incident') setTimeout(() => demoOutbound(ob, Object.assign({}, e, { from: 'Down', to: 'Up' })), 3000); return { ok: true, demo: true, result: outLog[0].result }; },
      scan: (range, by) => {
        const parts = String(range || '').split(/[,;\s]+/).filter(Boolean);
        if (!parts.length || parts.some((x) => !/^\d+\.\d+\.\d+\.(\d+\/\d+|\d+-\d+|\d+)$/.test(x))) throw Object.assign(new Error('Choose this machine\'s networks or enter a range like 10.10.0.0/24 or 10.10.0.1-254'), { status: 400 });
        range = parts.join(', ');
        const job = monScan = { range, by, state: 'running', started: new Date().toISOString(), total: 254 * parts.length, done: 0, found: [] };
        const t = setInterval(() => {
          job.done = Math.min(job.total, job.done + 37 * parts.length);
          if (job.done >= job.total) {
            clearInterval(t); job.state = 'done'; job.finished = new Date().toISOString();
            const base = parts[0].split('.').slice(0, 3).join('.');
            job.found = [['NAS-HQ01', 5000, 'nas', [80, 443, 445, 161], 'synology'], ['CAM-NVR01', 21, 'camera', [80, 443, 554], 'hikvision'], ['IPMI-HV01', 31, 'bmc', [443, 161], 'idrac'], ['UPS-BR02', 41, 'ups', [80, 161], 'apc-ups'], ['FW-BR02', 1, 'firewall', [443, 161, 22], 'fortigate'], ['PRN-LOBBY', 77, 'printer', [80, 9100, 161]], ['LNX-MON02', 88, 'linux', [22]]]
              .map(([n, i, kind, ports, profile]) => ({ name: n, host: base + '.' + (i % 254 || 9), kind, profile: profile || null, group: root.MCSensors.KIND_GROUP[kind] || 'g:net', source: 'Range scan ' + parts[0], detail: (profile ? root.MCSensors.PROFILE[profile].name + ' · ' : '') + n.toLowerCase() + '.corp.moncastle.local · ports ' + ports.join(', '), ports, monitored: false }));
            monitorCore().setScanResults(job.found);
          }
        }, 450);
        return job;
      },
      scanStatus: () => monScan,
      clearScan: () => { if (monScan && monScan.state === 'running') throw Object.assign(new Error('Wait for the running scan to finish, then clear the results'), { status: 400 }); monScan = null; },
      // the demo console server's own networks
      localNetworks: () => [{ iface: 'Ethernet0', address: '10.10.1.25', cidr: '10.10.1.0/24', prefix: 24, narrowed: false, addresses: 254 }, { iface: 'Ethernet1 (management VLAN)', address: '10.99.0.25', cidr: '10.99.0.0/24', prefix: 16, narrowed: true, addresses: 254 }],
      credentialOk: (id, u) => { const c = creds.find((x) => x.id === id); return !!c && credUsable(c, u); },
    };
    const monitor = async (op, body) => {
      await sleep(op === 'tree' ? 120 : 220);
      try {
        const r = await root.MCMonitorCore.handle(monitorCore(), monHost, op, body || {}, withAccess(user));
        if (root.MCMonitorCore.AUDIT[op]) audit('monitor', root.MCMonitorCore.auditText(op, body));
        return JSON.parse(JSON.stringify(r));
      } catch (e) { return deny(e.message, e.status || 400); }
    };

    const api = {
      mode: 'demo',
      monitor,
      status,
      license: licenseCheck,
      removeLicense: async () => { license = null; set('license', null); return licenseView(); },
      setup: async () => deny('The demo already has users.', 400),
      login,
      logout: async () => { audit('logout', 'Signed out'); user = null; set('user', null); return { ok: true }; },
      datasets: async () => { await sleep(150); return ds; },
      history: async () => history,
      scripts: async () => manifest,
      syncScripts: async () => { await sleep(900); audit('sync', 'Scripts synced from RoboMate-MonCastle-Scripts@main (demo)'); return { ok: true, scripts: manifest.scripts.length, changed: 0, verified: manifest.scripts.length + (manifest.support || []).length, ref: 'main', synced: new Date().toISOString() }; },
      run,
      scriptSource: async (p) => { await sleep(150); if (!user) return deny('Sign in first.', 401); const s = manifest.scripts.find((x) => x.path === p); return s ? { path: p, cache: 'memory', text: '# ' + s.title + '\n# ' + p + '\n# sha256 ' + s.sha256 + '\n#\n# In the demo the script text is not shipped. A live console reads it from GitHub into memory and shows it here.\n' + (s.synopsis ? '\n<#\n.SYNOPSIS\n    ' + s.synopsis + '\n#>\n' : '') + 'param(' + (s.parameters || []).map((x) => '\n    [' + (x.type || 'string') + ']$' + x.name).join(',') + '\n)\n' } : deny('Not in the script library', 404); },
      remoteControl: async (id, method, port) => {
        await sleep(200);
        if (!user) return deny('Sign in first.', 401);
        const d = monitorCore().device(id); if (!d) return deny('No such device', 404);
        if (!RB.atLeast(user.override ? 'admin' : withAccess(user).access(d.group), 'contributor')) return deny('Remote control needs the contributor role on this device.');
        if (root.MCSensors.accessOf(d) !== 'admin') return deny(d.name + ' has the access level ' + root.MCSensors.accessOf(d) + '. Remote control needs Administrator: change it in the device settings (Access).');
        const RC = root.MCRemoteControl, m = RC.METHODS[method]; if (!m) return deny('Choose RDP, SSH or the web interface.', 400);
        const c = root.MCCredModel.resolve(creds, d, [d.group], m.cred), f = (c && c.cred.fields) || {};
        const username = f.username ? (m.cred === 'windows' && f.domain ? f.domain + '\\' + f.username : f.username) : '';
        let sess; try { sess = RC.session(d, method, { port, username }); } catch (e) { return deny(e.message, 400); }
        audit('remote-control', m.label + ' to ' + d.name + ' (' + sess.host + ':' + sess.port + ')' + (username ? ' as ' + username : ''));
        return sess;
      },
      auditCollect: async (ids, opts) => {
        await sleep(500);
        if (!user) return deny('Sign in first.', 401);
        const mc = monitorCore(), devs = (ids || []).map((id) => mc.device(id)).filter(Boolean);
        if (!devs.length) return deny('Choose at least one device.', 400);
        for (const d of devs) if (!RB.atLeast(user.override ? 'admin' : withAccess(user).access(d.group), 'contributor')) return deny('You need the contributor role on ' + d.name + '.');
        devs.forEach((d) => D.auditOn(d)); ds = D.all();
        const sets = ((opts || {}).sets || []).join(', ') || 'all sets';
        audit('audit', 'Collect audit events from ' + devs.map((d) => d.host || d.name).join(', ') + ' (' + sets + ', ' + ((opts || {}).days || 1) + ' day(s))');
        return { devices: devs.map((d) => d.id), job: { id: 'demo-audit', state: 'done' } };
      },
      inventoryCollect: async (device) => {
        await sleep(300);
        if (!user) return deny('Sign in first.', 401);
        const mc = monitorCore(), d = mc.device(device);
        if (!d) return deny('No such device', 404);
        if (!RB.atLeast(user.override ? 'admin' : withAccess(user).access(d.group), 'contributor')) return deny('You need the contributor role on this device.');
        const plan = root.MCSensors.inventoryPlan(d); D.onboard(d, plan); ds = D.all();
        audit('inventory', 'Collect inventory for ' + d.name + ': ' + (plan.map((x) => x.script).join(', ') || 'nothing to collect'));
        return { device: d.id, jobs: plan.map((x) => ({ script: x.script, label: x.label, dataset: x.dataset, state: 'done' })) };
      },
      remoteRun: async (b) => {
        await sleep(200);
        if (!user) return deny('Sign in first.', 401);
        const R = root.MCRemote, mc = monitorCore();
        const devs = [].concat(b.devices || []).map((id) => mc.device(id)).filter(Boolean);
        const err = R.check({ devices: devs, language: b.language, code: b.code });
        if (err) return deny(err, 400);
        const low = devs.filter((d) => root.MCSensors.accessOf(d) !== 'admin');
        if (low.length) return deny(low.map((d) => d.name).join(', ') + ' has a lower access level than Administrator. Change it in the device settings (Access) to run code there.');
        const ua = withAccess(user);
        const role = user.override ? 'admin' : devs.map((d) => ua.access(d.group)).reduce((a, r) => (RB.RANK[r] < RB.RANK[a] ? r : a), 'admin');
        if (role !== 'admin') { audit('remote-code-denied', b.language + ' on ' + devs.map((d) => d.name).join(', ')); return deny('Remote scripting needs the administrator role on every selected device.'); }
        if (!b.whatIf && String(b.confirm || '').trim() !== R.confirmWord(devs)) return deny('Type ' + (devs.length === 1 ? 'the device name' : 'the number of devices') + ' exactly to confirm.', 400);
        const s = manifest.scripts.find((x) => x.id === 'act.remote.code') || { id: 'act.remote.code', title: 'Remote scripting', kind: 'action', secrets: ['Code'] };
        const code = String(b.code).replace(/\r/g, '');
        const job = { id: 'job-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), script: s.id, title: s.title, params: { ComputerName: devs.map((d) => d.name), Language: b.language, Code: '••••••' }, whatIf: !!b.whatIf, user: user.name, state: 'running', started: new Date().toISOString(), finished: null, result: null, code: code.slice(0, 8000), language: b.language, devices: devs.map((d) => d.id) };
        jobs.unshift(job);
        setTimeout(() => { job.result = R.demoResult(devs, b.language, code, !!b.whatIf); job.state = job.result.status === 'error' ? 'failed' : 'done'; job.finished = new Date().toISOString(); }, 900 + Math.random() * 1200);
        audit('remote-code', b.language + ' on ' + devs.length + ' device(s): ' + devs.map((d) => d.name).join(', ').slice(0, 200) + ' · ' + code.split('\n').length + ' lines' + (b.whatIf ? ' (WhatIf)' : ''));
        return { job };
      },
      jobs: async () => jobs.map((j) => Object.assign({}, j, { result: j.result ? { status: j.result.status, count: j.result.count, message: j.result.message } : null })),
      job: async (id) => { const j = jobs.find((x) => x.id === id); return j ? j : deny('No such job', 404); },
      accessLog: async () => ({ entries: log.slice(0, 400), pending: 3, lastPush: new Date(Date.now() - 4 * 6e4).toISOString(), target: 'MarcoFekry/RoboMate-MonCastle-Access/access-logs/MC01-demo/' }),
      schedules: async () => schedules,
      ...jobdefApi,
      setSchedule: async (id, every, enabled) => { const s = schedules.find((x) => x.id === id); if (s) { s.every = every; s.enabled = enabled; } audit('schedule', id + ' every ' + every + (enabled ? '' : ' (paused)')); return s; },
      // demo: the "online" answer is sample data shipped with the demo, so the page shows how a real check looks
      osReleases: async () => { await sleep(120); return osrDemo(); },
      refreshOsReleases: async () => { const na = needAdmin(); if (na) return na; await sleep(900); osrChecked = new Date().toISOString(); audit('osreleases', 'Checked the newest OS releases online (demo)'); return osrDemo(); },
      retention: async () => { await sleep(150); const na = needAdmin(); if (na) return na; return { policy: Object.assign({ archivePath: retUsage().archivePath }, retPolicy), lastRun: retLast, usage: retUsage() }; },
      retentionAction: async (b) => {
        await sleep(400); const na = needAdmin(); if (na) return na;
        if (b.action === 'run') { retLast = { at: new Date().toISOString(), by: user.name, sensorRows: 3000 + Math.round(Math.random() * 900), accessEntries: 120, datasets: Object.keys(ds).length, months: 0, ms: 960 }; set('retentionLast', retLast); audit('retention', 'Retention run: ' + retLast.sensorRows + ' rows archived'); return { lastRun: retLast, usage: retUsage(), policy: retPolicy }; }
        if (b.action === 'policy') {
          const p = JSON.parse(JSON.stringify(retPolicy)), x = b.policy || {}, a = x.archive || {};
          const n = (v, lo, hi, name) => { const k = +v; if (!(k >= lo && k <= hi)) throw Object.assign(new Error(name + ' must be ' + lo + ' to ' + hi), { status: 400 }); return Math.round(k); };
          try {
            if (x.historyDays != null) p.historyDays = n(x.historyDays, 1, 3650, 'Sensor history days');
            if (x.logDays != null) p.logDays = n(x.logDays, 7, 3650, 'Alarm log days');
            if (x.accessLogDays != null) p.accessLogDays = n(x.accessLogDays, 7, 3650, 'Access log days');
            if (a.keepMonths != null) p.archive.keepMonths = n(a.keepMonths, 1, 240, 'Keep archives (months)');
            if (a.maxGB != null) p.archive.maxGB = n(a.maxGB, 0, 100000, 'Archive size limit (GB)');
            if (a.runAt != null && !/^([01]\d|2[0-3]):[0-5]\d$/.test(a.runAt)) throw Object.assign(new Error('Run at HH:MM (24-hour)'), { status: 400 });
            if (a.path && !/^([A-Za-z]:\\|\\\\[^\\]+\\[^\\]+)/.test(a.path)) throw Object.assign(new Error('Archive folder: a full path such as D:\\MonCastle-Archive or \\\\server\\share\\MonCastle'), { status: 400 });
          } catch (e) { return deny(e.message, 400); }
          for (const k of ['enabled', 'compress', 'datasets', 'runAt', 'path']) if (a[k] != null) p.archive[k] = a[k];
          retPolicy = p; set('retention', p); audit('retention', 'Retention policy changed');
          return { policy: Object.assign({ archivePath: retUsage().archivePath }, p), lastRun: retLast, usage: retUsage() };
        }
        return deny('Unknown action', 400);
      },
      archive: async (q) => { await sleep(300); if (['access', 'engines', 'datasets'].includes(q.kind) || (user && user.restricted)) { const na = needAdmin(); if (na) return na; } try { const r = retRead(q); audit('archive', 'Opened archive ' + q.kind + ' ' + q.month); return r; } catch (e) { return deny(e.message, e.status || 400); } },
      archiveCsvUrl: null,
      infra: async () => { await sleep(120); monitorCore(); return { role: 'central', servers: infraList() }; },
      infraAction,
      engines: async () => { await sleep(120); return engineList(); },
      engine: async (id) => {
        await sleep(150);
        const EI = root.MCEngineInfo;
        const e = engineList().engines.find((x) => x.id === id);
        if (!e) return deny('Unknown engine ' + id, 404);
        const meta = manifest.scripts.find((x) => x.id === id) || {};
        const runs = e.lastRun ? EI.demoHistory(id, toMs(e.every) || 36e5, e.lastStatus, 40, e.lastRun) : [];
        if (runs[0] && e.message) runs[0].message = e.message;
        const d = meta.dataset ? ds[meta.dataset] : null;
        const t = monitorCore().tree();
        const sens = t.sensors.filter((x) => x.script === id);
        const devs = [...new Set(sens.map((x) => x.device))].map((x) => t.devices.find((y) => y.id === x)).filter(Boolean);
        const kinds = EI.permissions(meta, e).credentials;
        const cl = creds;
        return Object.assign({}, e, {
          meta: { id: meta.id, title: meta.title, synopsis: meta.synopsis, category: meta.category, resource: meta.resource, kind: meta.kind, dataset: meta.dataset, risk: meta.risk, schedule: meta.schedule, path: meta.path, sha256: meta.sha256, bytes: meta.bytes, replaces: meta.replaces || [], parameters: (meta.parameters || []).map((x) => ({ name: x.name, type: x.type, mandatory: !!x.mandatory })) },
          permissions: EI.permissions(meta, e), runs, usage: EI.usage(runs), taskPath: '\\RoboMate\\MonCastle\\Engines\\', consoleHost: 'windows',
          result: d && runs[0] ? { dataset: d.dataset, status: d.status, message: d.message, host: d.host, started: d.started, finished: d.finished, count: d.count, summary: d.summary, warnings: (d.warnings || []).slice(0, 20), runtime: { cpuSec: runs[0].cpuSec, peakMB: runs[0].peakMB, user: 'SYSTEM', pwsh: '7.4.6' }, columns: Object.keys((d.data || [])[0] || {}).slice(0, 12), sample: (d.data || []).slice(0, 8) } : null,
          sensors: { total: sens.length, devices: devs.length, byState: sens.reduce((a, x) => ((a[x.state] = (a[x.state] || 0) + 1), a), {}) },
          extraTargets: monitorCore().targets()[id] || [],
          credentialUse: devs.slice(0, 300).map((dv) => { for (const k of kinds) { const r = root.MCCredModel.resolve(cl, dv, [dv.group], k === 'snmpv2' || k === 'snmpv3' ? 'snmp' : k); if (r) return { device: dv.name, kind: r.cred.kind, credential: r.cred.name, from: r.from }; } return { device: dv.name, kind: kinds[0] || null, credential: null, from: 'engine account' }; }),
        });
      },
      engineAction, engineScope, setEngineScope,
      users: async () => users.map((u) => Object.assign({}, u, { groups: userGroups.filter((g) => g.members.includes(u.name)).map((g) => g.id) })),
      addUser: async (u) => {
        const na = needAdmin(); if (na) return na;
        if (!/^[A-Za-z0-9._-]{3,40}$/.test(u.username || '')) return deny('User names are 3-40 letters, digits, dot, dash or underscore.', 400);
        if (!u.password || u.password.length < 12) return deny('Passwords need at least 12 characters.', 400);
        if (users.some((x) => x.name.toLowerCase() === u.username.toLowerCase())) return deny('That user already exists.', 409);
        if (u.email && !/^[^\s@<>;,]+@[^\s@<>;,]+\.[^\s@<>;,]+$/.test(u.email)) return deny('That e-mail address does not look right.', 400);
        users.push({ name: u.username, email: String(u.email || '').trim(), role: RB.norm(u.role), restricted: !!u.restricted && u.role !== 'admin', created: new Date().toISOString(), lastLogin: null }); saveUsers();
        audit('user', 'Added ' + u.username + ' (' + RB.norm(u.role) + ')'); return api.users();
      },
      updateUser: async (name, b) => {
        const na = needAdmin(); if (na) return na;
        const u = users.find((x) => x.name === name); if (!u) return deny('No such user.', 404);
        if (b.role != null) { const r = RB.norm(b.role); if (u.role === 'admin' && r !== 'admin' && users.filter((x) => x.role === 'admin').length === 1) return deny('Keep at least one administrator.', 400); if (name === user.name && r !== 'admin') return deny('You cannot lower your own role.', 400); u.role = r; }
        if (b.restricted != null) u.restricted = !!b.restricted && u.role !== 'admin';
        if (b.password && b.password.length < 12) return deny('Passwords need at least 12 characters.', 400);
        if (b.email != null) { const em = String(b.email).trim(); if (em && !/^[^\s@<>;,]+@[^\s@<>;,]+\.[^\s@<>;,]+$/.test(em)) return deny('That e-mail address does not look right.', 400); u.email = em; }
        saveUsers(); audit('user', 'Changed ' + name + (b.role ? ' role ' + u.role : '') + (b.restricted != null ? (u.restricted ? ' restricted' : ' unrestricted') : '') + (b.email != null ? ' e-mail' : '') + (b.password ? ' password reset' : ''));
        return api.users();
      },
      removeUser: async (name) => { const na = needAdmin(); if (na) return na; if (name === user.name) return deny('You cannot remove yourself.', 400); const i = users.findIndex((x) => x.name === name); if (i >= 0) users.splice(i, 1); userGroups.forEach((g) => (g.members = g.members.filter((m) => m !== name))); saveUsers(); audit('user', 'Removed ' + name); return api.users(); },
      userGroups: async () => ({ groups: JSON.parse(JSON.stringify(userGroups)), matrix: RB.MATRIX, roles: RB.ROLES }),
      saveUserGroup: async (b) => {
        const na = needAdmin(); if (na) return na;
        const name = String(b.name || '').trim().slice(0, 60); if (!name) return deny('Give the group a name.', 400);
        const clean = { id: b.id || 'ug:' + Math.random().toString(36).slice(2, 9), name, description: String(b.description || '').slice(0, 200), members: [...new Set((b.members || []).filter((m) => users.some((u) => u.name === m)))], grants: (b.grants || []).filter((x) => x && x.scope).map((x) => ({ scope: String(x.scope), role: RB.norm(x.role) })) };
        const g = userGroups.find((x) => x.id === b.id); if (g) Object.assign(g, clean); else userGroups.push(clean);
        saveUsers(); audit('usergroup', (g ? 'Changed' : 'Added') + ' user group ' + name + ': ' + clean.members.length + ' members, ' + clean.grants.map((x) => x.role + ' on ' + x.scope).join(', '));
        return api.userGroups();
      },
      removeUserGroup: async (id) => { const na = needAdmin(); if (na) return na; const i = userGroups.findIndex((g) => g.id === id); if (i < 0) return deny('No such group.', 404); const [g] = userGroups.splice(i, 1); saveUsers(); audit('usergroup', 'Removed user group ' + g.name); return api.userGroups(); },
      insights: async (kind) => { await sleep(80); return (insights[kind] || []).filter((x) => x.shared || x.owner === user.name).map((x) => Object.assign({}, x, { editable: x.owner === user.name || user.role === 'admin' })); },
      saveInsight: async (kind, b) => {
        const list = insights[kind]; const name = String(b.name || '').trim().slice(0, 80); if (!name) return deny('Give it a name', 400);
        const old = b.id ? list.find((x) => x.id === b.id) : null;
        if (old && old.owner !== user.name && user.role !== 'admin') return deny('Only its owner or an administrator can change it.');
        if (b.shared && !RB.atLeast(RB.norm(user.role), 'contributor')) return deny('Readers keep dashboards and reports private; a contributor or admin can share them.');
        const x = Object.assign(old || { id: kind[0] + ':' + Math.random().toString(36).slice(2, 10), owner: user.name, created: new Date().toISOString() }, { name, description: b.description || '', shared: !!b.shared, spec: JSON.parse(JSON.stringify(b.spec || {})), updated: new Date().toISOString() });
        if (!old) list.push(x); set('insights', insights); audit(kind.slice(0, -1), (old ? 'Changed ' : 'Saved ') + kind.slice(0, -1) + ' ' + name + (x.shared ? ' (shared)' : ''));
        return Object.assign({}, x, { editable: true });
      },
      removeInsight: async (kind, id) => { const list = insights[kind]; const x = list.find((y) => y.id === id); if (!x) return deny('Not found', 404); if (x.owner !== user.name && user.role !== 'admin') return deny('Only its owner or an administrator can delete it.'); list.splice(list.indexOf(x), 1); set('insights', insights); audit(kind.slice(0, -1), 'Deleted ' + kind.slice(0, -1) + ' ' + x.name); return { ok: true }; },
      credentials: async () => { await sleep(120); return creds.filter((c) => credUsable(c, user)).map(credView); },
      saveCredential: async (b) => {
        if (!user) return deny('Sign in first.', 401);
        const admin = user.role === 'admin' || user.override, ua = withAccess(user);
        if (!RB.atLeast(user.role, 'contributor') && !userGroups.some((g) => g.members.includes(user.name) && g.grants.some((x) => RB.atLeast(x.role, 'contributor')))) return deny('Readers cannot save credentials.');
        const k = CM.KIND[b.kind]; if (!k) return deny('Unknown credential kind', 400);
        const name = String(b.name || '').trim().slice(0, 80); if (!name) return deny('Give the credential a name', 400);
        const old = b.id ? creds.find((x) => x.id === b.id) : null;
        if (b.id && !old) return deny('No such credential', 404);
        if (old && !admin && old.createdBy !== user.name) return deny('Only its creator or an administrator can change this credential.');
        if (!admin && (b.assign || {}).all) return deny('Only administrators can make a probe-wide default.');
        for (const g of (b.assign || {}).groups || []) if (!admin && !RB.atLeast(ua.access(g), 'contributor')) return deny('You cannot assign credentials to group ' + g + '.');
        if (creds.some((x) => x.name.toLowerCase() === name.toLowerCase() && x.id !== b.id && !x.private)) return deny('A credential called ' + name + ' already exists', 400);
        const fields = {}, setF = new Set(old ? old.set : []);
        for (const f of k.fields) {
          const v = (b.fields || {})[f.name];
          if (f.secret) { if (v && v !== '••••••') setF.add(f.name); if ((b.clear || []).includes(f.name)) setF.delete(f.name); continue; }
          const val = v == null || v === '' ? f.def : f.type === 'int' ? parseInt(v, 10) : String(v).trim();
          if (f.values && val != null && !f.values.includes(val)) return deny(f.label + ' must be one of ' + f.values.join(', '), 400);
          if (val != null) fields[f.name] = val;
        }
        for (const f of k.fields) if (f.required && !(f.secret ? setF.has(f.name) : fields[f.name])) return deny(f.label + ' is required', 400);
        if (b.kind === 'ssh' && !setF.has('password') && !setF.has('privateKey')) return deny('Give a password or a private key', 400);
        const c = Object.assign(old || { id: 'cr:' + Math.random().toString(36).slice(2, 10), created: new Date().toISOString(), createdBy: user.name }, { name, kind: b.kind, description: String(b.description || ''), fields, set: [...setF], assign: { all: !!(b.assign || {}).all, groups: (b.assign || {}).groups || [], devices: (b.assign || {}).devices || [] }, minRole: RB.ROLES.includes(b.minRole) ? b.minRole : 'contributor', userGroups: admin ? b.userGroups || [] : (b.userGroups || []).filter((id) => userGroups.some((g) => g.id === id && g.members.includes(user.name))), private: !!b.private, updated: new Date().toISOString() });
        if (!old) creds.push(c);
        saveCreds(); audit('credential', (old ? 'Changed' : 'Added') + ' ' + c.kind + ' credential ' + c.name + (c.private ? ' (private)' : '') + (c.assign.all ? ', probe default' : '') + (c.assign.groups.length ? ', groups ' + c.assign.groups.join(' ') : ''));
        return credView(c);
      },
      removeCredential: async (id) => {
        const c = creds.find((x) => x.id === id); if (!c) return deny('No such credential', 404);
        if (!(user.role === 'admin' || user.override) && c.createdBy !== user.name) return deny('Only its creator or an administrator can delete this credential.');
        const used = monitorCore().devices().filter((d) => Object.values(d.credentials || {}).includes(id));
        if (used.length) return deny(c.name + ' is still set on ' + used.map((d) => d.name).join(', ') + '. Change those devices first.', 409);
        creds.splice(creds.indexOf(c), 1); saveCreds(); audit('credential', 'Deleted credential ' + c.name); return { ok: true };
      },
      testCredential: async (id, host) => {
        const c = creds.find((x) => x.id === id); if (!c || !credUsable(c, user)) return deny('No such credential', 404);
        if (c.kind === 'cloud' && !String(host || '').trim()) host = 'provider';
        if (!/^(\w+:\/\/)?[A-Za-z0-9._:-]{1,253}$/.test(String(host || '').trim())) return deny('Give a host name or address to test against', 400);
        if (c.kind === 'database' && !/^\w+:\/\//.test(String(host).trim())) return deny('Give the engine and host to test against, e.g. postgres://db01 or redis://cache01:6379', 400);
        await sleep(900);
        const eng = (/^(\w+):\/\//.exec(String(host)) || [])[1];
        const msg = { windows: 'Port ' + (/5986/.test(c.fields.transport) ? 5986 : 5985) + ' answers. The engine signs in with this account on its next run.', ssh: 'Port 22 answers (SSH-2.0-OpenSSH_9.6). The engine signs in with this account on its next run.', snmpv3: 'Signed in: ' + String(host).toUpperCase() + ' (demo agent)', snmpv2: 'Signed in: ' + String(host).toUpperCase() + ' (demo agent)', vmware: 'Port 443 answers.', http: 'HTTP 200', sql: 'Port 1433 answers.',
          database: ({ postgres: 'PostgreSQL · TLS offered', mysql: 'MySQL 8.0.39', mariadb: 'MariaDB 10.11.8', mongodb: 'MongoDB 7.0+ · replica set rs-prod, primary', redis: 'Redis 7.2.5 · role master (signed in)', elastic: 'Elasticsearch cluster logs-prod · health yellow (signed in)', oracle: 'Oracle listener · port open', mssql: 'SQL Server 16.0.4135', cassandra: 'CQL 3.4.6' }[eng] || 'The service answers') + '.',
          cloud: (c.fields.provider || 'Azure') + ' sign-in endpoint answers on 443. The cloud storage engine signs in with this identity on its next run.' }[c.kind];
        c.lastTest = { ok: true, host: String(host).trim(), at: new Date().toISOString(), ms: 40 + Math.round(Math.random() * 80), message: msg + ' (demo)' }; saveCreds();
        audit('credential', 'Tested ' + c.name + ' against ' + host + ': ok');
        return c.lastTest;
      },
      audit,
      override: async (password) => {
        await sleep(400);
        if (password !== 'MonCastle!demo') { audit('override-failed', 'Wrong override password'); return deny('Wrong override password. In the demo it is MonCastle!demo.', 401); }
        user = { name: 'administrator', role: 'admin', override: true };
        set('user', user);
        audit('override', 'Signed in with the administrator override (licence ' + (license ? 'valid' : 'missing') + ')');
        return { user };
      },
      licenseKey: async () => needAdmin() || (audit('license-reveal', 'Licence key revealed'), { key: license && license.key ? license.key : '320RMC11DEMO0000000000000000_demoKeyForTheBrowserPreviewOnly' + (license ? license.last4 : '') }),
      setOverridePassword: async (current, password) => needAdmin() || (!password || password.length < 12 ? deny('The override password needs at least 12 characters.', 400) : (audit('override-password', 'Administrator override password changed'), { ok: true })),
      registry: async () => needAdmin() || (await sleep(300), JSON.parse(JSON.stringify(registryData))),
      issue: async (b) => {
        const d = needAdmin(); if (d) return d;
        if (!isKey(b.token)) return deny(KEY_ONLY, 400);
        const t = toToken(b.token);
        const fp = await fingerprint(t);
        const entry = { id: b.id || 'MC-' + new Date().getFullYear() + '-' + Math.random().toString(36).slice(2, 6).toUpperCase(), holder: b.holder || '', fingerprint: fp, edition: b.edition || 'Standard', expires: b.expires || null, maxNodes: b.maxNodes ? +b.maxNodes : null, revoked: false, issued: new Date().toISOString().slice(0, 10) };
        audit('license-issue', 'Prepared licence ' + entry.id + ' for ' + (entry.holder || 'unnamed') + ' (' + MASK(t.slice(-4)) + ')');
        return { key: toKey(t), masked: MASK(t.slice(-4)), fingerprint: fp, entry, verified: b.verify === false ? null : 'ok (demo)' };
      },
      release: async () => needAdmin() || { current: release.current, published: { outputDir: 'C:\\robomate\\RoboMate-MonCastle-Console', latest: Object.assign({ product: 'RoboMate MonCastle Console' }, release.latest), releases: release.published }, defaults: { sourceDir: 'D:\\RoboMate-MonCastle', outputDir: 'C:\\robomate\\RoboMate-MonCastle-Console', repo: 'MarcoFekry/RoboMate-MonCastle-Console' } },
      publish: async (b) => {
        const d = needAdmin(); if (d) return d;
        await sleep(1200);
        if (!/^\d+\.\d+\.\d+$/.test(b.version || '')) return deny('Use a version like 4.1.0.', 400);
        if (!newer(b.version, release.published[0].version)) return deny('Version ' + b.version + ' is not newer than the published ' + release.published[0].version + '.', 400);
        const out = b.outputDir || 'C:\\robomate\\RoboMate-MonCastle-Console';
        const name = 'RoboMate-MonCastle-Console-' + b.version + '.zip';
        const manifest2 = { product: 'RoboMate MonCastle Console', version: b.version, released: new Date().toISOString(), notes: b.notes || '', publishedBy: user.name, minNode: '18.17', zip: 'releases/' + name, sha256: Array.from({ length: 64 }, () => '0123456789abcdef'[Math.floor(Math.random() * 16)]).join(''), size: 415000 + Math.round(Math.random() * 9000), files: 46 };
        release.published.unshift({ file: 'releases/' + name, version: b.version, size: manifest2.size, modified: manifest2.released });
        audit('publish', 'Release ' + b.version + ' built in ' + out + ' (demo: nothing was written)');
        return { manifest: manifest2, outputDir: out, written: [out + '\\version.json', out + '\\CHANGELOG.md', out + '\\releases\\' + name], demo: true };
      },
      update: async () => ({ current: release.current, lastCheck: release.lastCheck, repo: 'MarcoFekry/RoboMate-MonCastle-Console' }),
      checkUpdate: async () => {
        await sleep(700);
        const l = release.latest;
        release.lastCheck = { checkedAt: new Date().toISOString(), current: release.current.version, latest: l.version, available: newer(l.version, release.current.version), notes: l.notes, released: l.released, size: l.size, zip: l.zip, sha256: l.sha256 };
        audit('update-check', release.lastCheck.available ? 'Update ' + l.version + ' available' : 'Up to date');
        return release.lastCheck;
      },
      installUpdate: async (v) => {
        const d = needAdmin(); if (d) return d;
        await sleep(1800);
        const from = release.current.version;
        release.current = { product: 'RoboMate MonCastle Console', version: v, released: release.latest.released, notes: release.latest.notes };
        release.lastCheck = Object.assign({}, release.lastCheck, { current: v, available: false });
        audit('update', 'Updated ' + from + ' -> ' + v + ' (demo: nothing was changed)');
        return { from, to: v, files: 46, backup: 'data\\backups\\console-' + from + '.zip', restarting: false, demo: true };
      },
    };
    return api;
  }

  // ------------------------------------------------------------------ pick a backend
  async function connect() {
    const forceDemo = /[?&]demo\b/.test(root.location ? root.location.search : '') || root.location.protocol === 'file:';
    if (!forceDemo) {
      try {
        const ctl = new AbortController();
        const t = setTimeout(() => ctl.abort(), 2500);
        const res = await fetch('api/status', { signal: ctl.signal, credentials: 'same-origin', headers: { Accept: 'application/json' } });
        clearTimeout(t);
        const type = res.headers.get('content-type') || '';
        if (res.ok && type.includes('application/json')) {
          const st = await res.json();
          if (st && st.product === 'RoboMate MonCastle') return st.mode === 'demo' ? Object.assign(live(), { mode: 'demo-server' }) : live();
        }
      } catch (e) { /* no server: fall through to the in-browser demo */ }
    }
    return demo();
  }

  root.MCApi = { connect, MASK, toKey, toToken };
})(typeof self !== 'undefined' ? self : this);
