/*
 * RoboMate MonCastle - troubleshooting tasks for anything MonCastle found: a Windows server, workstation or virtual
 * machine (networking and data), a Linux host, a network device, a storage array, and the virtual machine itself on
 * Hyper-V or VMware. Shared by the browser (window.MCTroubleshoot) and the server (tests), so both agree on which
 * script and parameters each task uses. The scripts themselves check the parameters again before they run.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCTroubleshoot = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  // what a resource is, from its device kind, guest OS or platform
  function osOf(t) {
    const s = String((t.os || '') + ' ' + (t.guestOS || '')).toLowerCase();
    if (/windows/.test(s)) return 'windows';
    if (/linux|rhel|red hat|ubuntu|debian|centos|suse|fedora|rocky|alma|oracle linux|amazon/.test(s)) return 'linux';
    if (['server', 'workstation', 'sql', 'domain'].includes(t.kind)) return 'windows';
    if (t.kind === 'linux') return 'linux';
    if (['network', 'firewall', 'wireless', 'loadbalancer'].includes(t.kind)) return 'network';
    if (['san', 'nas', 'storage', 'backup'].includes(t.kind)) return 'storage';
    return null;
  }
  const T = (label, script, params, note) => ({ label, script, params: params || {}, note: note || '' });

  // groups of tasks for one resource; `name` is how MonCastle reaches it (DNS name or IP)
  function tasksFor(t) {
    const n = t.name, os = osOf(t), out = [];
    const C = { ComputerName: n };
    const P = (o) => Object.assign({}, C, o);
    if (os === 'windows') {
      out.push({ group: 'Windows networking', icon: 'net', items: [
        T('View current IP configuration', 'act.win.netinfo', P({ Show: 'Addresses' }), 'addresses, gateway, DNS, adapter speed'),
        T('Routes', 'act.win.netinfo', P({ Show: 'Routes' })),
        T('Listening ports', 'act.win.netinfo', P({ Show: 'ListeningPorts' }), 'and the process behind each port'),
        T('Ping test from this device', 'act.win.nettest', P({ Test: 'Ping', Target: '8.8.8.8' })),
        T('Port test from this device', 'act.win.nettest', P({ Test: 'Port', Target: '', Port: 443, $ask: ['Target', 'Port'] }), 'type the host and port to test'),
        T('Route test (trace route)', 'act.win.nettest', P({ Test: 'TraceRoute', Target: '8.8.8.8' })),
        T('DNS lookup from this device', 'act.win.nettest', P({ Test: 'DnsLookup', Target: '', $ask: ['Target'] }), 'type the name to resolve'),
        T('Speed test', 'act.win.nettest', P({ Test: 'Speed' }), 'download speed as this device sees it'),
        T('Open a port', 'act.firewall.port', P({ Operation: 'Open', Port: 8080, Protocol: 'TCP' }), 'inbound allow rule, optional auto-close'),
        T('Close a port', 'act.firewall.port', P({ Operation: 'Close', Port: 8080, Protocol: 'TCP' })),
        T('Enable firewall', 'act.firewall', P({ State: 'Enable' })),
        T('Disable firewall', 'act.firewall', P({ State: 'Disable' }), 'turns itself back on after the minutes you set'),
        T('Established connections', 'mon.network.tcp', P()),
      ] });
      out.push({ group: 'Windows data and system', icon: 'server', items: [
        T('System information', 'inv.systeminfo', P()),
        T('Live performance', 'dev.live', P(), 'CPU, memory, disk and network for a few seconds'),
        T('Event log errors', 'dev.events', P({ LogName: 'System', Level: 'ErrorAndAbove', Hours: 24 })),
        T('Top processes', 'mon.processes', P()),
        T('Signed-in users', 'mon.sessions', P()),
        T('Largest files', 'mon.largefiles', P()),
        T('Disk cleanup', 'act.storage.diskcleanup', P(), 'run with WhatIf first to see what it frees'),
        T('Shadow copies', 'act.storage.vss', P({ Operation: 'List', Volume: 'C:' })),
        T('Defender quick scan', 'act.defender.scan', P({ ScanType: 'Quick' })),
        T('Restart a service', 'act.service', P({ Operation: 'Restart' })),
        T('Install updates', 'act.windowsupdate', P()),
        T('Restart', 'act.power', P({ Operation: 'Restart' })),
      ] });
    }
    if (os === 'linux') {
      out.push({ group: 'Linux networking', icon: 'net', items: [
        T('View current IP configuration', 'act.lnx.nettest', P({ Test: 'Addresses' }), 'addresses, routes, DNS servers'),
        T('Listening ports', 'act.lnx.nettest', P({ Test: 'ListeningPorts' })),
        T('Ping test from this host', 'act.lnx.nettest', P({ Test: 'Ping', Target: '8.8.8.8' })),
        T('Port test from this host', 'act.lnx.nettest', P({ Test: 'Port', Target: '', Port: 443, $ask: ['Target', 'Port'] }), 'type the host and port to test'),
        T('Route test (trace route)', 'act.lnx.nettest', P({ Test: 'TraceRoute', Target: '8.8.8.8' })),
        T('DNS lookup from this host', 'act.lnx.nettest', P({ Test: 'DnsLookup', Target: '', $ask: ['Target'] }), 'type the name to resolve'),
      ] });
      out.push({ group: 'Linux system', icon: 'linux', items: [
        T('Diagnostics', 'act.lnx.diag', P(), 'load, memory, fullest file systems, failed units, journal errors'),
        T('Service status or restart', 'act.lnx.service', P({ Operation: 'Status' })),
        T('Local user', 'act.lnx.user', P({ Operation: 'Status' })),
        T('Clean up disk space', 'act.lnx.cleanup', P()),
        T('Install updates', 'act.lnx.patch', P()),
        T('Reboot if required', 'act.lnx.reboot', P({ Operation: 'Reboot', OnlyIfRequired: true })),
      ] });
    }
    if (os === 'network') {
      out.push({ group: 'Network device', icon: 'net', items: [
        T('Version and uptime', 'act.net.show', P({ Show: 'Version' })),
        T('Interface status', 'act.net.show', P({ Show: 'Interfaces' })),
        T('Interface errors', 'act.net.show', P({ Show: 'InterfaceErrors' })),
        T('VLANs', 'act.net.show', P({ Show: 'Vlans' })),
        T('MAC address table', 'act.net.show', P({ Show: 'MacTable' })),
        T('ARP table', 'act.net.show', P({ Show: 'ArpTable' })),
        T('Routing table', 'act.net.show', P({ Show: 'Routes' })),
        T('Neighbours (CDP/LLDP)', 'act.net.show', P({ Show: 'Neighbors' })),
        T('Log', 'act.net.show', P({ Show: 'Log' })),
        T('Back up the configuration', 'act.net.config.backup', P()),
        T('Save the configuration', 'act.net.config.save', P()),
        T('Shut or enable a port', 'act.net.interface', P({ Operation: 'Bounce' })),
        T('Ping and port test from MonCastle', 'act.nettest', { Test: 'Port', Target: n, Port: 22 }),
      ] });
    }
    if (os === 'storage') {
      out.push({ group: 'Storage', icon: 'db', items: [
        T('Take a snapshot', 'act.storage.snapshot', P(), 'NetApp ONTAP or Pure FlashArray'),
        T('Port test from MonCastle', 'act.nettest', { Test: 'Port', Target: n, Port: 443, $ask: ['Port'] }),
        T('Trace route from MonCastle', 'act.nettest', { Test: 'TraceRoute', Target: n }),
      ] });
    }
    // the virtual machine on its platform
    if (t.platform === 'Hyper-V' && t.vmHost) {
      const V = (op) => ({ ComputerName: t.vmHost, VMName: [t.vmName || n], Operation: op });
      out.unshift({ group: 'Hyper-V virtual machine', icon: 'layers', items: [
        T('Start', 'act.hyperv.vm', V('Start')), T('Shut down', 'act.hyperv.vm', V('Shutdown')), T('Restart', 'act.hyperv.vm', V('Restart')),
        T('Turn off', 'act.hyperv.vm', V('TurnOff'), 'like pulling the plug'), T('Save state', 'act.hyperv.vm', V('Save')),
        T('Checkpoint', 'act.hyperv.vm', V('Checkpoint')), T('Remove old checkpoints', 'act.hyperv.vm', V('RemoveOldCheckpoints')),
      ] });
    }
    if (t.platform === 'VMware' && t.vcenter) {
      const V = (op) => ({ VCenter: t.vcenter, VMName: [t.vmName || n], Operation: op });
      out.unshift({ group: 'VMware virtual machine', icon: 'layers', items: [
        T('Status', 'act.vmware.vm', V('Status')), T('Start', 'act.vmware.vm', V('Start')), T('Shut down guest', 'act.vmware.vm', V('ShutdownGuest')),
        T('Restart guest', 'act.vmware.vm', V('RestartGuest')), T('Power off', 'act.vmware.vm', V('PowerOff')), T('Reset', 'act.vmware.vm', V('Reset')),
        T('Snapshot', 'act.vmware.vm', V('Snapshot')), T('Consolidate disks', 'act.vmware.vm', V('Consolidate')), T('Remove old MonCastle snapshots', 'act.vmware.vm', V('RemoveOldSnapshots')),
      ] });
    }
    if (!out.length) out.push({ group: 'Reachability', icon: 'net', items: [T('Port test from MonCastle', 'act.nettest', { Test: 'Port', Target: n, Port: 443, $ask: ['Port'] }), T('Trace route from MonCastle', 'act.nettest', { Test: 'TraceRoute', Target: n })] });
    return out;
  }
  return { osOf, tasksFor };
});
