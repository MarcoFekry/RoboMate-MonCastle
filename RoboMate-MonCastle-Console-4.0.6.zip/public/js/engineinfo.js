/*
 * RoboMate MonCastle - what each monitoring engine needs and how it behaves (browser: window.MCEngineInfo, server: require).
 * permissions(meta) lists the rights, ports, modules and credential kinds an engine uses, from its script's category and id.
 * usage(history) summarises the run history (duration, CPU time, peak memory, success rate) for the engine info page.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCEngineInfo = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const R = (need, why) => ({ need, why });
  const WINRM = { name: 'WinRM', port: '5985 (HTTP) / 5986 (HTTPS)', proto: 'TCP' };
  const WIN = [R('Local administrator on each target, or Remote Management Users plus WMI "Remote Enable" on root\\cimv2', 'reads CIM/WMI classes over PowerShell remoting')];

  // by script id first, then by resource
  const BY_ID = {
    'mon.compute': { rights: [WIN[0], R('Performance Monitor Users on each target', 'reads processor, memory, disk and network counters')] },
    'mon.events': { rights: [R('Event Log Readers on each target', 'reads the System and Application logs')] },
    'mon.services': { rights: [R('Read access to the Service Control Manager (default for administrators)', 'lists automatic services that are stopped')] },
    'sec.patches': { rights: [R('Local administrator on each target', 'reads the Windows Update history and the pending-reboot keys')] },
    'sec.defender': { rights: [R('Local administrator on each target', 'Get-MpComputerStatus needs administrator rights')] },
    'sec.firewall': { rights: [R('Local administrator on each target', 'reads the firewall profiles and the SMBv1 setting')] },
    'mon.ad.health': { rights: [R('Domain user (read) and local administrator on the domain controllers', 'dcdiag tests and service state on each DC')], modules: ['ActiveDirectory (RSAT)'], ports: [{ name: 'AD Web Services', port: '9389', proto: 'TCP' }, { name: 'LDAP', port: '389', proto: 'TCP' }] },
    'mon.ad.replication': { rights: [R('Domain user (read)', 'reads replication metadata with Get-ADReplicationPartnerMetadata and repadmin')], modules: ['ActiveDirectory (RSAT)'], ports: [{ name: 'AD Web Services', port: '9389', proto: 'TCP' }, { name: 'RPC', port: '135 + dynamic', proto: 'TCP' }] },
    'mon.ad.sites': { rights: [R('Domain user (read)', 'reads sites, subnets, site links and bridges from the Configuration partition')], modules: ['ActiveDirectory (RSAT)'], ports: [{ name: 'AD Web Services', port: '9389', proto: 'TCP' }] },
    'mon.ad.gpo': { rights: [R('Domain user (read GPOs) and read access to SYSVOL', 'compares AD and SYSVOL versions and links')], modules: ['GroupPolicy (RSAT)'], ports: [{ name: 'SMB', port: '445', proto: 'TCP' }, { name: 'LDAP', port: '389', proto: 'TCP' }] },
    'aud.events': { rights: [R('Event Log Readers on the domain controllers and file servers (Security log)', 'reads logon, lockout, group change and file audit events'), R('"Manage auditing and security log" is NOT needed when Event Log Readers is used', 'least privilege')] },
    'inv.ad.users': { rights: [R('Domain user (read)', 'reads user accounts and their attributes')], modules: ['ActiveDirectory (RSAT)'], ports: [{ name: 'AD Web Services', port: '9389', proto: 'TCP' }] },
    'inv.ad.computers': { rights: [R('Domain user (read)', 'reads computer accounts, OS and last logon')], modules: ['ActiveDirectory (RSAT)'], ports: [{ name: 'AD Web Services', port: '9389', proto: 'TCP' }] },
    'inv.ad.groups': { rights: [R('Domain user (read)', 'reads group membership, including privileged groups')], modules: ['ActiveDirectory (RSAT)'], ports: [{ name: 'AD Web Services', port: '9389', proto: 'TCP' }] },
    'mon.hyperv': { rights: [R('Hyper-V Administrators on each host', 'reads VMs, checkpoints and host memory')], modules: ['Hyper-V'] },
    'mon.vmware': { rights: [R('vCenter read-only role on the root object', 'reads hosts, datastores, VMs and snapshots')], modules: ['VMware.PowerCLI'], ports: [{ name: 'vCenter API', port: '443', proto: 'TCP' }], creds: ['vmware'], noWinrm: true },
    'mon.clusters': { rights: [R('Local administrator on the cluster nodes', 'reads nodes and roles')], modules: ['FailoverClusters (RSAT)'] },
    'mon.clusters.storage': { rights: [R('Local administrator on the cluster nodes', 'reads cluster shared volumes')], modules: ['FailoverClusters (RSAT)'] },
    'mon.dhcp': { rights: [R('DHCP Users on each DHCP server', 'reads scope statistics')], modules: ['DhcpServer (RSAT)'] },
    'mon.dns': { rights: [R('DnsAdmins (read) or local administrator on the DNS servers', 'reads zones and runs resolution tests')], modules: ['DnsServer (RSAT)'] },
    'mon.network.discovery': { rights: [R('No account: ICMP, TCP connect and SNMP read', 'sweeps the configured ranges')], ports: [{ name: 'ICMP echo', port: '-', proto: 'ICMP' }, { name: 'SNMP', port: '161', proto: 'UDP' }], creds: ['snmpv2', 'snmpv3'], noWinrm: true },
    'lnx.collect': { rights: [R('SSH account on each Linux host', 'reads CPU, memory, filesystems, load and failed units'), R('sudo without a password for: systemctl --failed, apt/dnf check-update', 'only for the update and unit checks')], ports: [{ name: 'SSH', port: '22', proto: 'TCP' }], creds: ['ssh'], noWinrm: true },
    'mon.sql.databases': { rights: [R('SQL login or Windows account with VIEW SERVER STATE and VIEW ANY DEFINITION', 'reads database state and sizes'), R('db_datareader on msdb', 'reads backup history')], modules: ['dbatools or SqlServer'], ports: [{ name: 'SQL Server', port: '1433 (or the instance port)', proto: 'TCP' }], creds: ['sql', 'windows'], noWinrm: true },
    'inv.sql': { rights: [R('SQL login or Windows account with VIEW SERVER STATE', 'reads instances, versions and databases')], modules: ['dbatools or SqlServer'], ports: [{ name: 'SQL Server', port: '1433', proto: 'TCP' }], creds: ['sql', 'windows'], noWinrm: true },
    'mon.printers': { rights: [R('Print Operators or local administrator on the print servers', 'reads printer and queue state')], modules: ['PrintManagement'] },
    'inv.printers': { rights: [R('Print Operators or local administrator on the print servers', 'lists printers, drivers and ports')], modules: ['PrintManagement'] },
    'mon.fileserver': { rights: [R('Local administrator on the file servers', 'Get-SmbSession and Get-SmbOpenFile need administrator rights'), R('FSRM read (local administrator)', 'quota usage')] },
    'eng.housekeeping': { rights: [R('Write access to the MonCastle data folder on this server', 'prunes old history, logs and inbox files')], noWinrm: true, local: true },
  };
  const BY_RESOURCE = {
    Servers: { rights: WIN }, Workstations: { rights: [R('Local administrator on the workstations, or domain user for the AD-only fields', 'reads hardware and OS over CIM')] },
    FileServers: { rights: [R('Local administrator on the file servers', 'reads shares and permissions')] },
  };

  function permissions(meta, engine) {
    meta = meta || {};
    const id = meta.id || '';
    const spec = Object.assign({}, BY_RESOURCE[meta.resource] || {}, BY_ID[id] || {});
    const rights = (spec.rights || [R('Read access to the systems this engine reads', 'collector')]).slice();
    const ports = (spec.ports || []).slice();
    if (!spec.noWinrm && !spec.local) ports.unshift(WINRM);
    const creds = spec.creds || (spec.local ? [] : ['windows']);
    const runAs = engine && engine.host === 'task' ? engine.runAs || 'SYSTEM' : 'the account that runs the MonCastle console';
    return {
      runAs,
      runAsNote: engine && engine.host === 'task'
        ? (/system/i.test(runAs) ? 'SYSTEM has no rights on other servers. The engine uses the device credentials from the vault (MC_CREDS) for remote targets; without one it can only read this server.' : 'The task runs as this account. Targets without a vault credential are read with this account.')
        : 'The console scheduler starts the engine. Targets without a vault credential are read with the console account.',
      rights, ports, modules: spec.modules || [], credentials: creds,
      console: [
        { role: 'Reader', can: 'See the engine, its results and this page' },
        { role: 'Contributor', can: 'Run on-demand scripts on device groups they contribute to' },
        { role: 'Administrator', can: 'Start, stop, enable, disable, change the interval, install as a task' },
      ],
      risk: meta.risk || 'low', secrets: meta.secrets || [],
    };
  }

  // the system an engine reads: what has to exist in the environment for it to return anything
  const SYSTEM_BY_ID = {
    'aud.events': 'Active Directory (domain controllers), plus NPS, file and print servers for their event sets',
    'inv.ad.users': 'Active Directory', 'inv.ad.computers': 'Active Directory', 'inv.ad.groups': 'Active Directory', 'inv.ad.deleted': 'Active Directory (Recycle Bin for full detail)', 'inv.ad.security': 'Active Directory',
    'mon.ad.health': 'Active Directory (domain controllers)', 'mon.ad.replication': 'Active Directory (two or more domain controllers)', 'mon.ad.sites': 'Active Directory (Sites and Services)', 'mon.ad.gpo': 'Active Directory (Group Policy and SYSVOL)',
    'mon.hyperv': 'Hyper-V hosts', 'mon.vmware': 'VMware vCenter or ESXi', 'mon.openshift': 'Red Hat OpenShift (cluster API)', 'mon.nutanix': 'Nutanix Prism Central or Prism Element',
    'mon.clusters': 'Windows failover clusters', 'mon.clusters.storage': 'Windows failover clusters with shared volumes',
    'mon.dhcp': 'Windows DHCP servers', 'mon.dns': 'Windows DNS servers', 'mon.network.discovery': 'IP networks (no system needed)',
    'mon.network.devices': 'Network devices with SNMP (switches, routers, firewalls, wireless, load balancers)', 'mon.storage.devices': 'Storage with SNMP (SAN, NAS, backup appliances)',
    'lnx.collect': 'Linux or Unix hosts (SSH)', 'mon.sql.databases': 'Microsoft SQL Server', 'inv.sql': 'Microsoft SQL Server', 'mon.databases': 'Database servers (SQL Server, Oracle, MySQL, PostgreSQL and more)',
    'mon.printers': 'Windows print servers', 'inv.printers': 'Windows print servers', 'mon.fileserver': 'Windows file servers', 'inv.fileshares': 'Windows file servers', 'mon.fileserver.acl': 'Windows file servers',
    'mon.iis': 'IIS web servers', 'inv.workstations': 'Windows workstations', 'mon.cloud.storage': 'Cloud storage accounts (Azure, AWS, Google, Oracle, Huawei)',
    'mon.os.updates': 'Windows and Linux hosts (compared with the vendors\' latest releases)', 'eng.housekeeping': 'This MonCastle server only',
    'mon.linux.filesystems': 'Linux or Unix hosts (SSH)', 'mon.linux.services': 'Linux hosts with systemd (SSH)', 'mon.linux.audit': 'Linux hosts (SSH, journal or auth log, auditd when present)',
    'mon.web.servers': 'Web servers and sites (HTTP/S)', 'mon.ssl.certificates': 'Any TLS endpoint (web, mail, LDAPS, RDP gateways, load balancers)',
    'mon.web.hosts': 'Windows (WinRM) and Linux (SSH) hosts that run web server software', 'mon.cloud.databases': 'Cloud database accounts (Azure, AWS, Google, Oracle, Huawei): SQL, open-source, document and key-value services',
    'act.cloud.db': 'A managed database in Azure, AWS, Google Cloud, Oracle Cloud or Huawei Cloud (Cloud credential with change rights)',
    'mon.temperature': 'Devices with temperature sensors (SNMP, Redfish BMC, Linux sysfs over SSH, Windows WMI)',
    'mon.kubernetes': 'Kubernetes clusters (API server with a bearer token): AKS, EKS, GKE, OKE, CCE, OpenShift, k3s', 'mon.containers': 'Docker or Podman hosts (SSH)',
    'inv.entra.users': 'Microsoft Entra ID (Graph API, app registration)', 'inv.entra.devices': 'Microsoft Entra ID (Graph API, app registration)', 'inv.entra.groups': 'Microsoft Entra ID (Graph API, app registration)', 'mon.entra.health': 'Microsoft Entra ID (Graph API; sign-ins need Entra ID P1, risk P2)',
    'inv.intune.devices': 'Microsoft Intune (Graph API, app registration)', 'mon.intune': 'Microsoft Intune (Graph API, app registration)',
    'mon.cloud.network': 'Cloud network accounts (Azure, AWS, Google, Oracle, Huawei): firewalls, WAF, VPN gateways, tunnels and clients',
  };
  const SYSTEM_BY_RESOURCE = { ActiveDirectory: 'Active Directory', Servers: 'Windows servers (WinRM)', Workstations: 'Windows workstations (WinRM)', FileServers: 'Windows file servers', Printers: 'Windows print servers', SQL: 'Microsoft SQL Server', Linux: 'Linux or Unix hosts (SSH)', Cloud: 'Cloud storage accounts', Virtualization: 'Virtualization platform', Databases: 'Database servers', Network: 'Network devices', Storage: 'Storage devices', Containers: 'Container platforms', EntraID: 'Microsoft Entra ID (Graph API)', Intune: 'Microsoft Intune (Graph API)', Web: 'Web servers and TLS endpoints', Hardware: 'Device hardware sensors', Updates: 'Windows and Linux hosts', MonCastle: 'This MonCastle server' };
  function system(meta) { meta = meta || {}; return SYSTEM_BY_ID[meta.id] || SYSTEM_BY_RESOURCE[meta.resource] || meta.resource || 'Not stated'; }

  const avg = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : null);
  const max = (a) => (a.length ? Math.max(...a) : null);
  function usage(history) {
    const h = (history || []).slice();
    const num = (k) => h.map((r) => r[k]).filter((v) => typeof v === 'number' && !Number.isNaN(v));
    const ok = h.filter((r) => r.status === 'ok').length;
    return { runs: h.length, okRate: h.length ? Math.round((ok / h.length) * 1000) / 10 : null, failed: h.filter((r) => r.status === 'error').length, warnings: h.filter((r) => r.status === 'warning').length, errors: h.reduce((a, r) => a + (r.errors || 0), 0), rows: h.reduce((a, r) => a + (r.count || 0), 0),
      avgSec: avg(num('durationSec')), maxSec: max(num('durationSec')), avgCpu: avg(num('cpuSec')), maxCpu: max(num('cpuSec')), avgMem: avg(num('peakMB')), maxMem: max(num('peakMB')), avgRows: avg(num('count')) };
  }

  // believable run history for the demo console
  const hash = (s) => { let x = 2166136261; for (let i = 0; i < s.length; i++) x = Math.imul(x ^ s.charCodeAt(i), 16777619); return x >>> 0; };
  function demoHistory(id, everyMs, lastStatus, n = 40, last) {
    const seed = hash(id), out = [], now = last ? Date.parse(last) : Date.now() - 0.2 * everyMs;
    const base = 4 + (seed % 50), mem = 90 + (seed % 160), rows = 20 + (seed % 400);
    for (let i = 0; i < n; i++) {
      const r = ((seed >> (i % 16)) % 100) / 100, j = Math.sin(seed + i * 7.1) * 0.5 + 0.5;
      const status = i === 0 && lastStatus ? lastStatus : j > 0.96 ? 'error' : j > 0.9 ? 'warning' : 'ok';
      const d = Math.round(base * (0.7 + j * 0.8) * 10) / 10;
      const nT = 3 + (seed % 9), nw = status === 'warning' ? 1 + (seed % 3) : 0;
      const hosts = ['SRV-APP-0' + (1 + (seed + i) % 9), 'SRV-FS-0' + (1 + (seed + i) % 4), 'LNX-WEB-0' + (1 + (seed + i) % 6)];
      const warnList = status === 'error' ? [hosts[0] + ': WinRM cannot connect (the WinRM client cannot complete the operation within the time specified)'] : Array.from({ length: nw }, (_, k) => [hosts[k % 3] + ': did not answer within 60 s; skipped', hosts[(k + 1) % 3] + ': access denied reading the counters, check the credential', hosts[(k + 2) % 3] + ': partial data (1 of 2 queries)'][k % 3]);
      const at = new Date(now - i * everyMs);
      out.push({ at: at.toISOString(), finished: new Date(at.getTime() + d * 1000).toISOString(), status, durationSec: d, cpuSec: Math.round(d * (0.25 + r * 0.3) * 10) / 10, peakMB: Math.round(mem * (0.85 + j * 0.3)), count: status === 'error' ? 0 : Math.round(rows * (0.9 + j * 0.2)), warnings: status === 'error' ? 1 : nw, errors: warnList.filter((w) => /cannot|denied|fail/i.test(w)).length + (status === 'error' ? 1 : 0), message: status === 'error' ? 'WinRM cannot reach 1 of ' + nT + ' targets' : status === 'warning' ? 'Partial: ' + nw + ' target' + (nw > 1 ? 's' : '') + ' did not answer' : '',
        trigger: i % 13 === 5 ? 'manual' : 'schedule', by: i % 13 === 5 ? 'admin' : 'scheduler', job: 'job-demo' + (seed % 9999).toString(36) + i,
        details: { warnings: warnList, summary: { targets: nT, read: status === 'error' ? nT - 1 : nT - nw, unreachable: status === 'error' ? 1 : nw, rows: status === 'error' ? 0 : Math.round(rows * (0.9 + j * 0.2)) } } });
    }
    return out;
  }

  return { permissions, usage, demoHistory, system };
});
