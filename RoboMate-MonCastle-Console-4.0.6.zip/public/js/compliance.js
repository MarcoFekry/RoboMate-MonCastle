/*
 * RoboMate MonCastle - compliance checks against common standards (browser: window.MCCompliance, server: require).
 *
 * One set of technical checks runs on what MonCastle already collects (collector data, sensors, credentials,
 * notification rules). Each standard maps its controls to those checks, so one evaluation answers all of them.
 * Controls that need a document, a process or an interview are listed as "manual": MonCastle shows them but does not
 * pretend to test them. References follow each standard's own numbering (CIS benchmark sections, not item numbers,
 * because item numbers change between benchmark versions).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCCompliance = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const up = (s) => String(s || '').split('.')[0].split('\\')[0].toUpperCase();
  const WIN = ['server', 'vm'];
  const NET = ['network', 'firewall', 'wireless', 'loadbalancer', 'fcswitch', 'san', 'nas', 'backup', 'ups', 'pdu', 'environment', 'bmc', 'appliance', 'storage', 'cloudstorage'];
  const R = (result, evidence) => ({ result, evidence });
  const PASS = (e) => R('pass', e), FAIL = (e) => R('fail', e), NA = (e) => R('na', e || 'not collected for this device');

  // ---------------------------------------------------------------- technical checks
  // run(dev, ctx) -> { result: pass|fail|na, evidence }
  const CHECKS = {
    'win.defender.realtime': { title: 'Anti-malware real-time protection on', kinds: WIN, run: (d, c) => { const r = c.row('security.defender', d); if (!r) return NA(); return r.RealTime && r.AntivirusEnabled !== false ? PASS('Defender real-time protection on (' + (r.Mode || 'Normal') + ' mode)') : FAIL('Real-time protection is off'); } },
    'win.defender.signatures': { title: 'Anti-malware signatures 3 days old or newer', kinds: WIN, run: (d, c) => { const r = c.row('security.defender', d); if (!r) return NA(); return r.SignatureAgeDays <= 3 ? PASS('Signatures ' + r.SignatureAgeDays + ' days old') : FAIL('Signatures ' + r.SignatureAgeDays + ' days old'); } },
    'win.defender.tamper': { title: 'Tamper protection on', kinds: WIN, run: (d, c) => { const r = c.row('security.defender', d); if (!r) return NA(); return r.Tamper ? PASS('Tamper protection on') : FAIL('Tamper protection off'); } },
    'win.patch.30d': { title: 'Operating system patched in the last 30 days', kinds: WIN, run: (d, c) => { const r = c.row('security.patches', d); if (!r) return NA(); return r.DaysSincePatch <= 30 ? PASS('Last patched ' + r.DaysSincePatch + ' days ago (' + (r.LastKB || '') + ')') : FAIL('Last patched ' + r.DaysSincePatch + ' days ago; ' + (r.PendingUpdates || 0) + ' updates pending'); } },
    'win.patch.reboot': { title: 'No reboot pending after updates', kinds: WIN, run: (d, c) => { const r = c.row('security.patches', d); if (!r) return NA(); return r.PendingReboot ? FAIL('A reboot is pending, so installed updates are not active yet') : PASS('No reboot pending'); } },
    'win.fw.profiles': { title: 'Host firewall on for domain, private and public profiles', kinds: WIN, run: (d, c) => { const r = c.row('security.firewall', d); if (!r) return NA(); const off = ['Domain', 'Private', 'Public'].filter((p) => !r[p]); return off.length ? FAIL('Off for: ' + off.join(', ')) : PASS('On for all three profiles'); } },
    'win.smb1.off': { title: 'SMBv1 disabled', kinds: WIN, run: (d, c) => { const r = c.row('security.firewall', d); if (!r) return NA(); return r.SMB1 ? FAIL('SMBv1 is enabled') : PASS('SMBv1 disabled'); } },
    'win.rdp.nla': { title: 'Remote Desktop requires Network Level Authentication', kinds: WIN, run: (d, c) => { const r = c.row('security.firewall', d); if (!r) return NA(); return !r.RDPEnabled ? PASS('Remote Desktop is off') : r.NLA ? PASS('RDP on with NLA') : FAIL('RDP on without NLA'); } },
    'win.localadmins.limit': { title: 'Local Administrators group kept small (4 or fewer members)', kinds: WIN, run: (d, c) => { const rows = c.rows('security.localadmins', d); if (!rows.length) return NA(); return rows.length <= 4 ? PASS(rows.length + ' members: ' + rows.map((x) => x.Member).join(', ')) : FAIL(rows.length + ' members: ' + rows.map((x) => x.Member).slice(0, 8).join(', ')); } },
    'win.activation': { title: 'Windows licensed and activated', kinds: WIN, run: (d, c) => { const r = c.row('servers.activation', d); if (!r) return NA(); return /licensed/i.test(r.Status) ? PASS(r.Status + ' (' + (r.Channel || '') + ')') : FAIL(r.Status); } },
    'win.os.supported': { title: 'Operating system still supported by the vendor', kinds: WIN, run: (d, c) => { const r = c.row('inventory.hardware', d) || c.row('security.patches', d); const os = r && (r.OperatingSystem || r.OS); if (!os) return NA(); return /2008|2012|Windows 7|Windows 8|XP/i.test(os) ? FAIL(os + ' is out of support') : PASS(os); } },
    'win.tpm': { title: 'TPM present and enabled (physical servers)', kinds: WIN, run: (d, c) => { const r = c.row('inventory.hardware', d); if (!r) return NA(); if (r.MachineType === 'Virtual') return NA('virtual machine'); return r.TPMEnabled ? PASS('TPM enabled') : FAIL('TPM missing or disabled'); } },
    'win.eventlog': { title: 'Event logs collected and reviewed', kinds: WIN, run: (d, c) => { const r = c.row('servers.events', d); if (!r) return c.has('servers.events') ? FAIL('Not in the event-log collection') : NA('event-log collector not running'); return PASS('Collected: ' + (r.Critical || 0) + ' critical, ' + (r.Errors || 0) + ' errors in ' + (r.Hours || 24) + ' h'); } },
    'win.share.acl': { title: 'No risky share permissions (Everyone / Authenticated Users with write)', kinds: WIN, run: (d, c) => { const rows = c.rows('security.fileacl', d); if (!rows.length) return NA('not a file server'); const bad = rows.filter((x) => x.Risky || x.OrphanedSid); return bad.length ? FAIL(bad.length + ' risky entries: ' + bad.slice(0, 3).map((x) => x.Share + ' ' + x.Identity).join('; ')) : PASS(rows.length + ' share permissions reviewed'); } },
    'sql.backup.full': { title: 'Databases have a full backup in the last 26 hours', kinds: ['server', 'sql', 'vm', 'cluster'], run: (d, c) => { const rows = c.rowsBy('sql.databases', 'Instance', d).filter((x) => x.Database !== 'tempdb'); if (!rows.length) return NA('no SQL Server here'); const bad = rows.filter((x) => x.FullBackupAgeHours == null || x.FullBackupAgeHours > 26); return bad.length ? FAIL(bad.length + ' of ' + rows.length + ' databases: ' + bad.slice(0, 4).map((x) => x.Database + (x.FullBackupAgeHours == null ? ' never' : ' ' + Math.round(x.FullBackupAgeHours) + ' h')).join(', ')) : PASS(rows.length + ' databases backed up'); } },
    'sql.backup.log': { title: 'Full-recovery databases have a log backup in the last 4 hours', kinds: ['server', 'sql', 'vm', 'cluster'], run: (d, c) => { const rows = c.rowsBy('sql.databases', 'Instance', d).filter((x) => x.RecoveryModel === 'Full'); if (!rows.length) return NA('no full-recovery databases'); const bad = rows.filter((x) => x.LogBackupAgeHours == null || x.LogBackupAgeHours > 4); return bad.length ? FAIL(bad.length + ' databases without a recent log backup') : PASS(rows.length + ' databases with log backups'); } },
    'lnx.secupdates': { title: 'No security updates waiting (Linux)', kinds: ['linux'], run: (d, c) => { const r = c.row('linux.hosts', d); if (!r) return NA(); return (r.securityUpdates || 0) === 0 ? PASS('No security updates pending') : FAIL(r.securityUpdates + ' security updates pending'); } },
    'lnx.failedunits': { title: 'No failed system services (Linux)', kinds: ['linux'], run: (d, c) => { const r = c.row('linux.hosts', d); if (!r) return NA(); const f = r.failedUnits || []; return f.length ? FAIL('Failed: ' + f.slice(0, 4).join(', ')) : PASS('No failed units'); } },
    'net.telnet.off': { title: 'No clear-text management (Telnet, port 23)', kinds: NET, run: (d) => { const p = d.ports || []; if (!p.length) return NA('no port scan for this device'); return p.includes(23) ? FAIL('Telnet (23) is open') : PASS('Telnet closed; open ports ' + p.join(', ')); } },
    'net.mgmt.https': { title: 'Web management only over HTTPS', kinds: NET.concat(['printer']), run: (d) => { const p = d.ports || []; if (!p.length) return NA('no port scan for this device'); return p.includes(80) && !p.includes(443) ? FAIL('Management on HTTP (80) only') : p.includes(80) ? FAIL('HTTP (80) open next to HTTPS; redirect or close it') : PASS(p.includes(443) ? 'HTTPS only' : 'No web management'); } },
    'net.snmpv3': { title: 'SNMPv3 (authenticated and encrypted) instead of v1/v2c', kinds: NET.concat(['printer']), run: (d, c) => { const id = (d.credentials || {}).snmp; const k = id ? c.credKind(id) : c.defaultSnmp; if (!k) return NA('no SNMP credential chosen'); return k === 'snmpv3' ? PASS('SNMPv3 credential') : FAIL('Uses ' + (k === 'snmpv2' ? 'SNMP v2c community' : k)); } },
    'db.backup': { title: 'Database engines have a backup in the last 26 hours', kinds: ['database', 'linux', 'server'], run: (d, c) => { const rows = c.rowsBy('databases.health', 'Host', d).filter((x) => x.LastBackupHours !== undefined && !['elastic', 'cassandra', 'redis'].includes(x.Engine) && !/replica|standby|secondary/i.test(x.Role || '')); if (!rows.length) return NA('no database instance with backup data'); const bad = rows.filter((x) => x.LastBackupHours == null || x.LastBackupHours > 26); return bad.length ? FAIL(bad.map((x) => x.Instance + (x.LastBackupHours == null ? ': no backup found' : ': ' + Math.round(x.LastBackupHours) + ' h ago')).join(', ')) : PASS(rows.map((x) => x.Instance + ' ' + Math.round(x.LastBackupHours) + ' h').join(', ')); } },
    'db.tls': { title: 'Database services offer TLS', kinds: ['database', 'linux', 'server'], run: (d, c) => { const ss = c.sensorsOf(d).filter((s) => s.type === 'db.service' && (s.channels || []).some((x) => x.name === 'TLS offered')); if (!ss.length) return NA('no database service sensor reporting TLS'); const bad = ss.filter((s) => (s.channels.find((x) => x.name === 'TLS offered') || {}).value === 0); return bad.length ? FAIL(bad.map((s) => s.name + ' accepts only unencrypted connections').join('; ')) : PASS(ss.length + ' database services offer TLS'); } },
    'db.replica.lag': { title: 'Database replicas are less than 2 minutes behind', kinds: ['database', 'linux', 'server'], run: (d, c) => { const rows = c.rowsBy('databases.health', 'Host', d).filter((x) => x.ReplicationLagSec != null); if (!rows.length) return NA('not a replica'); const bad = rows.filter((x) => x.ReplicationLagSec > 120); return bad.length ? FAIL(bad.map((x) => x.Instance + ' ' + x.ReplicationLagSec + ' s behind').join(', ')) : PASS(rows.map((x) => x.Instance + ' ' + x.ReplicationLagSec + ' s').join(', ')); } },
    'cloud.public.off': { title: 'No cloud bucket or container allows public access', kinds: ['cloudstorage'], run: (d, c) => { const rows = cloudRows(c, d); if (!rows.length) return NA('no bucket data'); const bad = rows.filter((x) => x.PublicAccess); return bad.length ? FAIL(bad.length + ' public: ' + bad.map((x) => x.Name).join(', ')) : PASS(rows.length + ' buckets, none public'); } },
    'cloud.encrypted': { title: 'Cloud buckets encrypt data at rest by default', kinds: ['cloudstorage'], run: (d, c) => { const rows = cloudRows(c, d); if (!rows.length) return NA('no bucket data'); const bad = rows.filter((x) => x.Encryption === 'None'); return bad.length ? FAIL(bad.map((x) => x.Name).join(', ') + ' without default encryption') : PASS(rows.length + ' buckets encrypted (' + [...new Set(rows.map((x) => x.Encryption))].join(', ') + ')'); } },
    'cloud.versioning': { title: 'Backup and archive buckets keep versions or are immutable', kinds: ['cloudstorage'], run: (d, c) => { const rows = cloudRows(c, d).filter((x) => /backup|veeam|rman|archive|replica|dump/i.test(x.Name)); if (!rows.length) return NA('no backup or archive bucket'); const bad = rows.filter((x) => x.Versioning !== 'Enabled' && !(x.ImmutableDays > 0)); return bad.length ? FAIL(bad.map((x) => x.Name).join(', ') + ' can be overwritten or deleted without a copy') : PASS(rows.length + ' backup buckets protected'); } },
    'tls.cert.valid': { title: 'TLS certificates valid for at least 14 more days', kinds: null, run: (d, c) => { const ss = c.sensorsOf(d).filter((s) => s.type === 'sslcert'); if (!ss.length) return NA('no certificate sensor'); const bad = ss.filter((s) => s.state === 'Down' || s.state === 'Warning'); return bad.length ? FAIL(bad.map((s) => s.name + ': ' + (s.value || s.state)).join('; ')) : PASS(ss.length + ' certificates valid (' + ss.map((s) => s.value).filter(Boolean).join(', ') + ')'); } },
    'web.https': { title: 'Web checks use HTTPS', kinds: ['web'], run: (d, c) => { const hs = c.sensorsOf(d).filter((s) => s.type === 'http'); if (!hs.length) return NA('no web sensor'); const plain = hs.filter((s) => /^http:/i.test((s.params || {}).url || '')); return plain.length ? FAIL(plain.length + ' pages on plain HTTP') : PASS(hs.length + ' pages on HTTPS'); } },
    'ad.privileged.small': { title: 'Privileged AD groups kept small (Domain Admins 5 or fewer)', kinds: ['domain'], run: (d, c) => { const rows = (c.ds['ad.groups'] || []).filter((x) => x.Group === 'Domain Admins'); if (!rows.length) return NA(); return rows.length <= 5 ? PASS(rows.length + ' Domain Admins') : FAIL(rows.length + ' Domain Admins: ' + rows.map((x) => x.Member).slice(0, 8).join(', ')); } },
    'ad.stale.users': { title: 'No enabled accounts unused for 90 days', kinds: ['domain'], run: (d, c) => { const rows = c.ds['ad.users'] || []; if (!rows.length) return NA(); const bad = rows.filter((x) => x.Enabled && x.Stale); return bad.length ? FAIL(bad.length + ' stale enabled accounts, e.g. ' + bad.slice(0, 4).map((x) => x.SamAccountName).join(', ')) : PASS('No stale enabled accounts'); } },
    'ad.pwd.expires': { title: 'User passwords expire (no "never expires" on people)', kinds: ['domain'], run: (d, c) => { const rows = (c.ds['ad.users'] || []).filter((x) => x.Enabled && !/^svc[-_.]/i.test(x.SamAccountName)); if (!rows.length) return NA(); const bad = rows.filter((x) => x.PasswordNeverExpires); return bad.length ? FAIL(bad.length + ' accounts never expire, e.g. ' + bad.slice(0, 4).map((x) => x.SamAccountName).join(', ')) : PASS('All user passwords expire'); } },
    'ad.privileged.stale': { title: 'No stale privileged accounts', kinds: ['domain'], run: (d, c) => { const rows = (c.ds['ad.users'] || []).filter((x) => x.Enabled && x.Privileged); if (!rows.length) return NA(); const bad = rows.filter((x) => x.Stale); return bad.length ? FAIL(bad.map((x) => x.SamAccountName).slice(0, 5).join(', ')) : PASS(rows.length + ' privileged accounts, all in use'); } },
    'ad.replication.ok': { title: 'Directory replication healthy', kinds: ['domain'], run: (d, c) => { const rows = c.ds['ad.replication'] || []; if (!rows.length) return NA(); const bad = rows.filter((x) => x.Status !== 'OK'); return bad.length ? FAIL(bad.length + ' links failing: ' + bad.slice(0, 3).map((x) => x.Server + '→' + x.Partner).join(', ')) : PASS(rows.length + ' replication links OK'); } },
    'ad.audit': { title: 'Security events audited and collected', kinds: ['domain'], run: (d, c) => { const rows = c.ds['audit.events'] || []; return rows.length ? PASS(rows.length + ' audit events collected') : c.has('audit.events') ? FAIL('No audit events collected') : NA('audit collector not running'); } },
    'ad.gpo.consistent': { title: 'Group Policy consistent between AD and SYSVOL', kinds: ['domain'], run: (d, c) => { const rows = c.ds['ad.gpo'] || []; if (!rows.length) return NA(); const bad = rows.filter((x) => x.VersionMismatch); return bad.length ? FAIL(bad.length + ' GPOs out of sync: ' + bad.slice(0, 3).map((x) => x.Name).join(', ')) : PASS(rows.length + ' GPOs consistent'); } },
    'mon.covered': { title: 'Monitored continuously (sensors reporting)', kinds: null, run: (d, c) => { const ss = c.sensorsOf(d); if (!ss.length) return FAIL('No sensors on this device'); const unk = ss.filter((s) => s.state === 'Unknown'); return unk.length === ss.length ? FAIL('No sensor has reported') : PASS(ss.length + ' sensors, ' + (ss.length - unk.length) + ' reporting'); } },
    'mon.available': { title: 'Available (no sensor down)', kinds: null, run: (d, c) => { const ss = c.sensorsOf(d); if (!ss.length) return NA('no sensors'); const down = ss.filter((s) => s.state === 'Down' && !s.related); return down.length ? FAIL(down.length + ' down: ' + down.slice(0, 3).map((s) => s.name).join(', ')) : PASS('All sensors up or in warning'); } },
    'mon.alerting': { title: 'Alerts reach someone (notification rules on)', kinds: null, run: (d, c) => (c.rules == null ? NA('notification rules not visible to this user') : c.rules > 0 ? PASS(c.rules + ' notification rules on') : FAIL('No notification rule is on')) },
  };

  // ---------------------------------------------------------------- standards
  const M = (ref, title, checks, manual) => ({ ref, title, checks: checks || [], manual: manual || null });
  const STANDARDS = [
    { id: 'cis-ws2022', name: 'CIS Microsoft Windows Server 2022 Benchmark (L1)', short: 'CIS Windows Server', scope: 'Windows servers', controls: [
      M('§1', 'Account policies: password and lockout', [], 'Read the Default Domain Policy and fine-grained password policies'),
      M('§2.2', 'User rights: limit administrative membership', ['win.localadmins.limit']),
      M('§9', 'Windows Defender Firewall on for all profiles', ['win.fw.profiles']),
      M('§17', 'Advanced audit policy and log collection', ['win.eventlog']),
      M('§18 MS Security Guide', 'SMBv1 client and server disabled', ['win.smb1.off']),
      M('§18 Remote Desktop', 'Require Network Level Authentication', ['win.rdp.nla']),
      M('§18 Microsoft Defender Antivirus', 'Real-time protection and tamper protection on', ['win.defender.realtime', 'win.defender.tamper']),
      M('§18 Microsoft Defender Antivirus', 'Signatures up to date', ['win.defender.signatures']),
      M('§18 Windows Update', 'Updates installed and active', ['win.patch.30d', 'win.patch.reboot']),
      M('§18 Device security', 'Trusted Platform Module available', ['win.tpm']),
    ] },
    { id: 'cis-v8', name: 'CIS Critical Security Controls v8 (IG1)', short: 'CIS Controls v8', scope: 'all devices', controls: [
      M('1.1', 'Detailed enterprise asset inventory', ['mon.covered']),
      M('3.10', 'Encrypt sensitive data in transit', ['tls.cert.valid', 'net.snmpv3', 'web.https', 'db.tls']),
      M('4.1', 'Secure configuration process', [], 'Documented baseline for each platform'),
      M('4.4 / 4.5', 'Firewall on servers and end-user devices', ['win.fw.profiles']),
      M('4.6', 'Securely manage enterprise assets and software', ['net.mgmt.https', 'net.telnet.off', 'win.rdp.nla']),
      M('4.8', 'Uninstall or disable unnecessary services', ['win.smb1.off', 'net.telnet.off']),
      M('5.3', 'Disable dormant accounts', ['ad.stale.users']),
      M('5.4', 'Restrict administrator privileges to dedicated accounts', ['ad.privileged.small', 'win.localadmins.limit']),
      M('7.3', 'Automated operating system patch management', ['win.patch.30d', 'lnx.secupdates']),
      M('8.2', 'Collect audit logs', ['win.eventlog', 'ad.audit']),
      M('10.1 / 10.2', 'Anti-malware deployed and signatures updated automatically', ['win.defender.realtime', 'win.defender.signatures']),
      M('11.2', 'Automated backups', ['sql.backup.full', 'db.backup', 'cloud.versioning']),
      M('14.1', 'Security awareness programme', [], 'Training records'),
    ] },
    { id: 'nist-800-53', name: 'NIST SP 800-53 Rev. 5 (moderate baseline, technical controls)', short: 'NIST 800-53', scope: 'all devices', controls: [
      M('AC-2(3)', 'Disable accounts after inactivity', ['ad.stale.users']),
      M('AC-6(5)', 'Privileged accounts restricted', ['ad.privileged.small', 'ad.privileged.stale', 'win.localadmins.limit']),
      M('AU-2 / AU-6', 'Event logging and audit review', ['win.eventlog', 'ad.audit']),
      M('CM-6', 'Configuration settings', ['win.smb1.off', 'win.rdp.nla', 'ad.gpo.consistent']),
      M('CM-7', 'Least functionality', ['win.smb1.off', 'net.telnet.off']),
      M('CM-8', 'System component inventory', ['mon.covered']),
      M('CP-9', 'System backup', ['sql.backup.full', 'sql.backup.log', 'db.backup', 'cloud.versioning']),
      M('IA-5', 'Authenticator management', ['ad.pwd.expires']),
      M('SC-7', 'Boundary protection', ['win.fw.profiles', 'cloud.public.off']),
      M('SC-8', 'Transmission confidentiality and integrity', ['tls.cert.valid', 'net.snmpv3', 'net.mgmt.https', 'web.https']),
      M('SI-2', 'Flaw remediation', ['win.patch.30d', 'win.patch.reboot', 'lnx.secupdates', 'win.os.supported']),
      M('SI-3', 'Malicious code protection', ['win.defender.realtime', 'win.defender.signatures', 'win.defender.tamper']),
      M('SI-4', 'System monitoring', ['mon.covered', 'mon.alerting']),
      M('PL-2', 'System security plans', [], 'Document per system'),
    ] },
    { id: 'iso-27001', name: 'ISO/IEC 27001:2022 Annex A (technological controls)', short: 'ISO 27001', scope: 'all devices', controls: [
      M('A.5.9', 'Inventory of information and other associated assets', ['mon.covered']),
      M('A.5.18', 'Access rights reviewed and removed', ['ad.stale.users', 'ad.privileged.stale']),
      M('A.8.2', 'Privileged access rights', ['ad.privileged.small', 'win.localadmins.limit']),
      M('A.8.5', 'Secure authentication', ['win.rdp.nla', 'ad.pwd.expires']),
      M('A.8.7', 'Protection against malware', ['win.defender.realtime', 'win.defender.signatures']),
      M('A.8.8', 'Management of technical vulnerabilities', ['win.patch.30d', 'lnx.secupdates', 'win.os.supported']),
      M('A.8.9', 'Configuration management', ['win.smb1.off', 'ad.gpo.consistent']),
      M('A.8.13', 'Information backup', ['sql.backup.full', 'db.backup', 'cloud.versioning']),
      M('A.8.15', 'Logging', ['win.eventlog', 'ad.audit']),
      M('A.8.16', 'Monitoring activities', ['mon.covered', 'mon.alerting']),
      M('A.8.20', 'Networks security', ['win.fw.profiles', 'net.telnet.off', 'net.mgmt.https']),
      M('A.8.24', 'Use of cryptography', ['tls.cert.valid', 'net.snmpv3', 'db.tls', 'cloud.encrypted']),
      M('A.5.1', 'Policies for information security', [], 'Approved policy set'),
    ] },
    { id: 'pci-dss-4', name: 'PCI DSS v4.0 (technical requirements)', short: 'PCI DSS 4.0', scope: 'cardholder-data environment', controls: [
      M('1.2 / 1.4', 'Network security controls configured', ['win.fw.profiles']),
      M('2.2.4', 'Only necessary services enabled', ['win.smb1.off', 'net.telnet.off']),
      M('2.2.7', 'Non-console administrative access encrypted', ['net.mgmt.https', 'win.rdp.nla', 'net.snmpv3']),
      M('4.2.1', 'Strong cryptography for data in transit', ['tls.cert.valid', 'web.https', 'db.tls']),
      M('5.2 / 5.3.1', 'Anti-malware deployed and kept current', ['win.defender.realtime', 'win.defender.signatures']),
      M('6.3.3', 'Security patches installed within one month', ['win.patch.30d', 'lnx.secupdates']),
      M('7.2', 'Access by least privilege', ['ad.privileged.small', 'win.localadmins.limit', 'cloud.public.off']),
      M('8.2.6', 'Inactive accounts removed within 90 days', ['ad.stale.users']),
      M('8.3.9', 'Passwords changed periodically', ['ad.pwd.expires']),
      M('10.2', 'Audit logs capture events', ['win.eventlog', 'ad.audit']),
      M('10.7', 'Failures of critical security controls detected', ['mon.covered', 'mon.alerting']),
      M('12.10', 'Incident response plan', [], 'Plan and test records'),
    ] },
    { id: 'hipaa', name: 'HIPAA Security Rule (45 CFR 164.308 / 164.312)', short: 'HIPAA', scope: 'systems with ePHI', controls: [
      M('164.308(a)(1)(ii)(D)', 'Information system activity review', ['win.eventlog', 'ad.audit']),
      M('164.308(a)(5)(ii)(B)', 'Protection from malicious software', ['win.defender.realtime', 'win.defender.signatures']),
      M('164.308(a)(7)(ii)(A)', 'Data backup plan', ['sql.backup.full', 'db.backup']),
      M('164.312(a)(1)', 'Access control', ['ad.privileged.small', 'ad.stale.users', 'cloud.public.off']),
      M('164.312(b)', 'Audit controls', ['win.eventlog', 'mon.covered']),
      M('164.312(d)', 'Person or entity authentication', ['win.rdp.nla', 'ad.pwd.expires']),
      M('164.312(e)(1)', 'Transmission security', ['tls.cert.valid', 'net.snmpv3', 'web.https']),
      M('164.308(a)(1)(ii)(A)', 'Risk analysis', [], 'Documented risk analysis'),
    ] },
    { id: 'soc2', name: 'SOC 2 Trust Services Criteria (Security, Availability)', short: 'SOC 2', scope: 'in-scope systems', controls: [
      M('CC6.1', 'Logical access security', ['ad.privileged.small', 'win.rdp.nla', 'cloud.public.off']),
      M('CC6.2', 'Access removed when no longer needed', ['ad.stale.users']),
      M('CC6.6', 'Boundary protection', ['win.fw.profiles', 'net.telnet.off']),
      M('CC6.7', 'Transmission of data restricted and protected', ['tls.cert.valid', 'net.snmpv3', 'db.tls']),
      M('CC6.8', 'Malicious software prevented or detected', ['win.defender.realtime']),
      M('CC7.1', 'Vulnerabilities detected and managed', ['win.patch.30d', 'lnx.secupdates']),
      M('CC7.2', 'System components monitored for anomalies', ['mon.covered', 'win.eventlog', 'mon.alerting']),
      M('A1.2', 'Backup and recovery infrastructure', ['sql.backup.full', 'db.backup', 'db.replica.lag', 'mon.available']),
    ] },
    { id: 'nist-csf-2', name: 'NIST Cybersecurity Framework 2.0', short: 'NIST CSF 2.0', scope: 'all devices', controls: [
      M('ID.AM-01/02', 'Hardware and software inventories', ['mon.covered']),
      M('PR.AA-05', 'Access permissions managed (least privilege)', ['ad.privileged.small', 'ad.stale.users']),
      M('PR.DS-02', 'Data in transit protected', ['tls.cert.valid', 'net.snmpv3', 'db.tls']),
      M('PR.DS-11', 'Backups created, protected and tested', ['sql.backup.full', 'db.backup', 'cloud.versioning']),
      M('PR.PS-02', 'Software maintained and replaced', ['win.patch.30d', 'win.os.supported', 'lnx.secupdates']),
      M('PR.PS-04', 'Log records generated', ['win.eventlog', 'ad.audit']),
      M('PR.IR-01', 'Networks protected from unauthorized access', ['win.fw.profiles', 'net.mgmt.https', 'cloud.public.off']),
      M('DE.CM-01/09', 'Networks and computing monitored', ['mon.covered', 'win.defender.realtime']),
      M('GV.PO-01', 'Cybersecurity policy established', [], 'Policy documents'),
    ] },
    { id: 'essential-eight', name: 'ACSC Essential Eight (Maturity Level 1)', short: 'Essential Eight', scope: 'Windows estate', controls: [
      M('Patch operating systems', 'OS patches within one month, supported versions only', ['win.patch.30d', 'win.os.supported']),
      M('Patch applications', 'Application and Linux package updates', ['lnx.secupdates']),
      M('Restrict administrative privileges', 'Privileged accounts limited and reviewed', ['ad.privileged.small', 'ad.privileged.stale', 'win.localadmins.limit']),
      M('Regular backups', 'Backups of important data', ['sql.backup.full', 'db.backup', 'cloud.versioning']),
      M('Multi-factor authentication', 'MFA for remote access and admins', [], 'Identity provider settings'),
      M('Application control', 'Only approved applications run', [], 'WDAC / AppLocker policy'),
      M('Configure Microsoft Office macros', 'Macros blocked from the internet', [], 'Office policy'),
      M('User application hardening', 'Browsers and PDF readers hardened', [], 'Browser policy'),
    ] },
    { id: 'cis-network', name: 'CIS network device benchmarks (Cisco IOS, FortiGate, Palo Alto: common controls)', short: 'CIS network devices', scope: 'network and storage devices', controls: [
      M('Management plane', 'No Telnet; SSH and HTTPS only', ['net.telnet.off', 'net.mgmt.https']),
      M('SNMP', 'SNMPv3 with authPriv; no v1/v2c communities', ['net.snmpv3']),
      M('Logging and monitoring', 'Device monitored and alerts routed', ['mon.covered', 'mon.alerting']),
      M('Availability', 'Device up', ['mon.available']),
      M('AAA', 'Central authentication (TACACS+/RADIUS)', [], 'Device configuration'),
    ] },
    { id: 'gdpr-32', name: 'GDPR Article 32 (security of processing, technical measures)', short: 'GDPR Art. 32', scope: 'systems with personal data', controls: [
      M('32(1)(a)', 'Encryption of personal data', ['tls.cert.valid', 'net.snmpv3', 'web.https', 'cloud.encrypted', 'db.tls']),
      M('32(1)(b)', 'Confidentiality, integrity, availability and resilience', ['win.fw.profiles', 'win.defender.realtime', 'mon.available']),
      M('32(1)(c)', 'Restore availability after an incident', ['sql.backup.full', 'db.backup', 'cloud.versioning']),
      M('32(1)(d)', 'Regular testing and evaluation', ['win.patch.30d', 'mon.covered']),
    ] },
  ];

  // ---------------------------------------------------------------- evaluation
  // input: { datasets, tree: { devices, sensors, groups }, credKinds: {id: kind}, rules: number|null }
  function context(input) {
    const ds = {}, idx = {};
    for (const [k, v] of Object.entries(input.datasets || {})) ds[k] = (v && v.data) || v || [];
    const keyOf = (r) => up(r.ComputerName || r.Name || r.Server || r.Instance || r.PrintServer || r.hostname);
    const index = (k, field) => { const key = k + '|' + (field || ''); if (idx[key]) return idx[key]; const m = new Map(); for (const r of ds[k] || []) { const n = field ? up(r[field]) : keyOf(r); if (!m.has(n)) m.set(n, []); m.get(n).push(r); } return (idx[key] = m); };
    const names = (d) => [up(d.name), up(d.host)].filter(Boolean);
    const sens = new Map();
    for (const s of (input.tree && input.tree.sensors) || []) { if (!sens.has(s.device)) sens.set(s.device, []); sens.get(s.device).push(s); }
    return {
      ds,
      has: (k) => !!(input.datasets || {})[k],
      rows: (k, d) => { const m = index(k); for (const n of names(d)) if (m.has(n)) return m.get(n); return []; },
      row: (k, d) => { const m = index(k); for (const n of names(d)) if (m.has(n)) return m.get(n)[0]; return null; },
      rowsBy: (k, field, d) => { const m = index(k, field); for (const n of names(d)) if (m.has(n)) return m.get(n); return []; },
      sensorsOf: (d) => sens.get(d.id) || [],
      credKind: (id) => (input.credKinds || {})[id] || null,
      defaultSnmp: input.defaultSnmp || null,
      rules: input.rules == null ? null : input.rules,
    };
  }
  const CLOUD_PFX = { Azure: 'AZ', AWS: 'AWS', 'Google Cloud': 'GCP', 'Oracle Cloud': 'OCI', 'Huawei Cloud': 'HWC' };
  function cloudRows(c, d) { return (c.ds['cloud.storage'] || []).filter((r) => r.Kind === 'Bucket' && up((CLOUD_PFX[r.Provider] || 'CLOUD') + '-' + r.Account) === up(d.name)); }
  const applies = (chk, d) => !chk.kinds || chk.kinds.includes(d.kind || 'server');

  function evaluate(input, opt = {}) {
    const c = context(input);
    const devices = ((input.tree && input.tree.devices) || []).filter((d) => !opt.devices || opt.devices.includes(d.id));
    const stds = STANDARDS.filter((s) => !opt.standards || opt.standards.includes(s.id));
    const used = [...new Set(stds.flatMap((s) => s.controls.flatMap((x) => x.checks)))];
    const per = new Map(); // device id -> { checkId: result }
    for (const d of devices) {
      const r = {};
      for (const id of used) { const chk = CHECKS[id]; if (!chk) continue; if (!applies(chk, d)) { r[id] = { result: 'na', evidence: 'does not apply to ' + (d.kind || 'this device') }; continue; } try { r[id] = chk.run(d, c); } catch (e) { r[id] = { result: 'na', evidence: 'check failed: ' + e.message }; } }
      per.set(d.id, r);
    }
    const out = stds.map((s) => {
      const controls = s.controls.map((ctl) => {
        if (!ctl.checks.length) return { ref: ctl.ref, title: ctl.title, status: 'manual', manual: ctl.manual, passed: 0, failed: 0, na: devices.length, devices: [] };
        const rows = devices.map((d) => {
          const rs = ctl.checks.map((id) => Object.assign({ check: id, title: CHECKS[id].title }, per.get(d.id)[id]));
          const app = rs.filter((x) => x.result !== 'na');
          return { device: d.id, name: d.name, group: d.group, kind: d.kind, result: !app.length ? 'na' : app.every((x) => x.result === 'pass') ? 'pass' : 'fail', checks: rs };
        });
        const passed = rows.filter((x) => x.result === 'pass').length, failed = rows.filter((x) => x.result === 'fail').length;
        return { ref: ctl.ref, title: ctl.title, checks: ctl.checks, status: !passed && !failed ? 'na' : !failed ? 'pass' : !passed ? 'fail' : 'partial', passed, failed, na: rows.length - passed - failed, devices: rows.filter((x) => x.result !== 'na') };
      });
      const auto = controls.filter((x) => x.status !== 'manual' && x.status !== 'na');
      const p = auto.reduce((a, x) => a + x.passed, 0), f = auto.reduce((a, x) => a + x.failed, 0);
      return { id: s.id, name: s.name, short: s.short, scope: s.scope, score: p + f ? Math.round((p / (p + f)) * 1000) / 10 : null, controls, passing: auto.filter((x) => x.status === 'pass').length, failing: auto.filter((x) => x.status === 'fail' || x.status === 'partial').length, manual: controls.filter((x) => x.status === 'manual').length, notApplicable: controls.filter((x) => x.status === 'na').length };
    });
    const devs = devices.map((d) => {
      const r = per.get(d.id), list = Object.entries(r).filter(([, v]) => v.result !== 'na');
      const p = list.filter(([, v]) => v.result === 'pass').length;
      return { id: d.id, name: d.name, group: d.group, kind: d.kind, score: list.length ? Math.round((p / list.length) * 1000) / 10 : null, passed: p, failed: list.length - p, results: Object.fromEntries(Object.entries(r).map(([k, v]) => [k, Object.assign({ title: CHECKS[k].title }, v)])) };
    }).filter((d) => d.score != null);
    return { at: new Date().toISOString(), standards: out, devices: devs, checks: used.map((id) => ({ id, title: CHECKS[id].title })) };
  }

  return { CHECKS, STANDARDS, evaluate };
});
