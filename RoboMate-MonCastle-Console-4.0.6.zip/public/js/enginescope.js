/*
 * RoboMate MonCastle - which machines a monitoring engine reads (browser: window.MCEngineScope, server: require).
 * Every engine that reads machines can take, besides its default scope:
 *   ad        more Active Directory scopes: Servers, Workstations, AllComputers, DomainControllers, Linux
 *   adGroups  AD groups whose computer members it reads (nested groups included)
 *   ous       OUs (distinguished names) whose enabled computers it reads
 *   hosts     workgroup or other non-domain machines: names, IP addresses, ranges (10.0.0.10-40) or small subnets (/22 at most),
 *             signed in with the vault credential in `credential`
 *   added     the devices added in the console (by hand, auto-discovery or import) of the kinds this engine reads,
 *             optionally only those in `addedGroups`
 *   devices   single devices (console ids) this engine reads, whatever their group
 *   credentials  engine credentials per device or group: [{ target: 'dev:<id>' | 'grp:<group id>', credential: <vault id> }];
 *             they win over the device's own credential for this engine only (device first, then the nearest group)
 *   useDefault  also read the engine's default scope (for example every AD server). Off by default since 4.7.4:
 *             an engine reads nothing and does not run until it is configured on a device, a group or all devices.
 * The console turns ad/adGroups/ous into MC_TARGET_SCOPE (resolved by Get-MCTarget) and hosts/added/devices into MC_EXTRA_TARGETS.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCEngineScope = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const WIN_KINDS = ['server', 'workstation', 'domain', 'vm'];
  const FAMILIES = {
    windows: { label: 'Windows machines', ad: ['Servers', 'Workstations', 'AllComputers', 'DomainControllers'], hosts: true, cred: 'windows', kinds: WIN_KINDS, note: 'Workgroup machines are read over WinRM with a local account: add them to WinRM TrustedHosts on the MonCastle server, or use HTTPS (5986).' },
    linux: { label: 'Linux and Unix hosts', ad: ['Linux'], hosts: true, cred: 'ssh', kinds: ['linux'], note: 'Read over SSH with the chosen SSH credential.' },
    network: { label: 'Network devices', ad: [], hosts: true, cred: 'snmpv2', kinds: ['network', 'firewall', 'wireless', 'loadbalancer', 'waf', 'vpn', 'voip', 'fcswitch'], note: 'Read over SNMP v1/v2c (UDP 161).' },
    storage: { label: 'Storage devices', ad: [], hosts: true, cred: 'snmpv2', kinds: ['san', 'nas', 'backup', 'storage', 'appliance'], note: 'Read over SNMP v1/v2c (UDP 161).' },
    web: { label: 'Web servers and TLS endpoints', ad: [], hosts: true, cred: 'http', kinds: ['server', 'linux', 'network', 'firewall', 'loadbalancer', 'appliance', 'waf', 'k8scluster'], note: 'Names or addresses, tried on HTTPS 443. Set full URLs in the engine parameters.' },
    webhost: { label: 'Windows and Linux web servers', ad: ['Servers'], hosts: true, cred: '', kinds: ['server', 'linux', 'web', 'container'], note: 'Windows hosts are read over WinRM, Linux hosts over SSH with their SSH credential.' },
    hardware: { label: 'Devices with temperature sensors', ad: ['Servers', 'Workstations'], hosts: true, cred: '', kinds: ['server', 'workstation', 'linux', 'network', 'firewall', 'wireless', 'loadbalancer', 'san', 'nas', 'backup', 'storage', 'appliance', 'printer', 'bmc', 'ups', 'host', 'k8snode'], note: 'SNMP devices use the SNMP credential, Linux hosts SSH, BMCs Redfish and Windows WMI.' },
    containers: { label: 'Docker and Podman hosts', ad: ['Linux'], hosts: true, cred: 'ssh', kinds: ['linux', 'container', 'host'], note: 'Read over SSH. The account needs to run docker or podman (docker group or sudo).' },
    k8s: { label: 'Kubernetes clusters', ad: [], hosts: true, cred: 'http', kinds: ['k8scluster', 'cluster'], note: 'API server address (https://host:6443). Use an http credential holding a read-only service account token.' },
    computers: { label: 'Windows and Linux computers', ad: ['Servers', 'Workstations', 'AllComputers', 'DomainControllers', 'Linux'], hosts: true, cred: '', kinds: WIN_KINDS.concat(['linux']), note: 'Windows machines are read over WinRM, Linux hosts over SSH with their SSH credential.' },
    database: { label: 'Database servers', ad: [], hosts: false, cred: 'database', kinds: ['database'], note: 'Database devices (engine and port from the device). Use a database credential, or sql for SQL Server.' },
    api: { label: 'Platform APIs', ad: [], hosts: true, cred: 'http', kinds: ['cluster', 'host', 'appliance'], note: 'Addresses of the platform API (cluster API, Prism, vCenter).' },
  };
  const BY_ID = { 'lnx.collect': 'linux', 'mon.network.devices': 'network', 'mon.storage.devices': 'storage', 'mon.openshift': 'api', 'mon.nutanix': 'api', 'mon.vmware': 'api', 'mon.linux.filesystems': 'linux', 'mon.linux.services': 'linux', 'mon.linux.audit': 'linux', 'mon.web.servers': 'web', 'mon.web.hosts': 'webhost', 'mon.ssl.certificates': 'web', 'mon.temperature': 'hardware', 'mon.containers': 'containers', 'mon.kubernetes': 'k8s', 'inv.software': 'computers', 'mon.databases': 'database' };
  const WIN_RESOURCES = ['Servers', 'Workstations', 'FileServers', 'Printers', 'SQL', 'Updates'];
  // the family of an engine, or null when it reads no machines (AD itself, cloud accounts, network sweeps, housekeeping)
  function familyOf(meta) {
    meta = meta || {};
    if (BY_ID[meta.id]) return BY_ID[meta.id];
    if (meta.id === 'aud.events') return 'windows';
    if (WIN_RESOURCES.includes(meta.resource) || ['mon.dhcp', 'mon.dns', 'mon.hyperv', 'mon.clusters', 'mon.clusters.storage'].includes(meta.id)) return 'windows';
    return null;
  }
  // what the engine reads when nobody changed it: nothing (4.7.4). An administrator configures it on devices, groups or all devices.
  function defaults() {
    return { ad: [], adGroups: [], ous: [], hosts: [], credential: '', added: false, addedGroups: [], devices: [], credentials: [], useDefault: false, replace: true };
  }
  // a scope saved by an older console: "replace" meant "skip the default scope", so the default scope stays on for those
  function migrate(meta, stored) {
    const s = Object.assign(defaults(meta), stored || {});
    if (stored && stored.useDefault === undefined) s.useDefault = !stored.replace;
    s.replace = !s.useDefault;
    return s;
  }
  const HOST_RE = /^[A-Za-z0-9][\w.-]{0,252}$/;
  const IP_RE = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
  const okIp = (m) => m && m.slice(1).every((x) => +x <= 255);
  const MAX = 1024;
  // one entry -> list of hosts; throws on a bad entry
  function expandOne(e) {
    e = String(e || '').trim();
    if (!e) return [];
    let m = /^(\d{1,3}\.\d{1,3}\.\d{1,3}\.)(\d{1,3})-(\d{1,3})$/.exec(e);
    if (m) { const a = +m[2], b = +m[3]; if (a > b || b > 255) throw new Error('Bad range ' + e); const out = []; for (let i = a; i <= b; i++) out.push(m[1] + i); return out; }
    m = /^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\/(\d{1,2})$/.exec(e);
    if (m) {
      const ip = IP_RE.exec(m[1]), bits = +m[2];
      if (!okIp(ip) || bits < 22 || bits > 32) throw new Error('Subnets from /22 to /32 only: ' + e);
      const n = ip.slice(1).reduce((a, x) => a * 256 + +x, 0), size = 2 ** (32 - bits), base = n - (n % size);
      const out = []; for (let i = size > 2 ? 1 : 0; i < (size > 2 ? size - 1 : size); i++) { const v = base + i; out.push([v >>> 24 & 255, v >>> 16 & 255, v >>> 8 & 255, v & 255].join('.')); }
      return out;
    }
    if (IP_RE.test(e)) { if (!okIp(IP_RE.exec(e))) throw new Error('Bad address ' + e); return [e]; }
    if (HOST_RE.test(e)) return [e];
    throw new Error('Not a host name, address, range or subnet: ' + e);
  }
  function expand(list) {
    const out = [];
    for (const e of list || []) { for (const h of expandOne(e)) { if (!out.includes(h)) out.push(h); if (out.length > MAX) throw new Error('At most ' + MAX + ' workgroup hosts per engine.'); } }
    return out;
  }
  const strs = (v, n, re) => [...new Set((Array.isArray(v) ? v : String(v || '').split(/[\n,;]+/)).map((x) => String(x).trim()).filter(Boolean))].slice(0, n).filter((x) => !re || re.test(x));
  const ID_RE = /^[\w:.-]{1,80}$/;
  // checks and cleans a scope sent by a browser; throws with a readable message
  function normalize(meta, s) {
    const f = familyOf(meta);
    if (!f) throw new Error('This engine reads no machines, so it has no targets to choose.');
    const F = FAMILIES[f];
    s = s || {};
    const useDefault = s.useDefault !== undefined ? !!s.useDefault : s.replace === undefined ? false : !s.replace;
    const out = {
      ad: strs(s.ad, 6).filter((x) => F.ad.includes(x)),
      adGroups: strs(s.adGroups, 50, /^[^<>"]{1,256}$/),
      ous: strs(s.ous, 50, /^(OU|CN|DC)=[^<>"]{1,1000}$/i),
      hosts: F.hosts ? strs(s.hosts, 300) : [],
      credential: String(s.credential || '').slice(0, 80),
      added: !!s.added,
      addedGroups: strs(s.addedGroups, 50, ID_RE),
      devices: strs(s.devices, 500, ID_RE),
      credentials: [],
      useDefault,
      replace: !useDefault,
    };
    const seen = new Set();
    for (const c of Array.isArray(s.credentials) ? s.credentials.slice(0, 200) : []) {
      const target = String((c || {}).target || ''), credential = String((c || {}).credential || '').slice(0, 80);
      if (!/^(dev|grp):[\w:.-]{1,80}$/.test(target) || !ID_RE.test(credential) || seen.has(target)) continue;
      seen.add(target); out.credentials.push({ target, credential });
    }
    if (!F.ad.length) { out.ad = []; out.adGroups = []; out.ous = []; }
    expand(out.hosts); // throws on a bad entry or too many
    return out;
  }
  const groupsOf = (d) => (Array.isArray(d.groups) && d.groups.length ? d.groups : [d.group]).filter(Boolean);
  // the devices added in the console that this engine reads: the ones chosen one by one, and with "all devices", every device of its kinds
  function addedDevices(meta, s, devices) {
    const f = familyOf(meta); if (!f || !s) return [];
    const kinds = FAMILIES[f].kinds;
    const one = new Set(s.devices || []);
    // network and storage engines read every device of their kinds, also the ones the network discovery engine found
    const any = f === 'network' || f === 'storage' || f === 'hardware' || f === 'database';
    return (devices || []).filter((d) => one.has(d.id) || (s.added && kinds.includes(d.kind) && (any || (!d.auto && d.origin !== 'engine')) && (!s.addedGroups || !s.addedGroups.length || groupsOf(d).some((g) => s.addedGroups.includes(g))) && (f !== 'windows' || !/linux|unix|esxi/i.test(d.os || ''))));
  }
  // the engine credential for one device: chosen for the device itself, else for the nearest of its groups (chain: group, parent, ...)
  function credentialFor(s, device, chain) {
    const list = (s && s.credentials) || [];
    if (!list.length || !device) return null;
    const d = list.find((c) => c.target === 'dev:' + device.id); if (d) return { credential: d.credential, from: 'engine · device' };
    for (const g of chain || []) { const c = list.find((x) => x.target === 'grp:' + g); if (c) return { credential: c.credential, from: 'engine · group ' + g }; }
    return null;
  }
  // has an administrator configured this engine? assigned: devices given to it by monitoring options; flag: the enable switch (true/false/unset)
  function configured(meta, s, assigned, flag) {
    meta = meta || {};
    if (flag === false) return false;
    if (meta.category === 'Engine') return true; // housekeeping of the console itself
    if (assigned > 0) return true;
    if (!familyOf(meta)) return flag === true;
    s = s || defaults(meta);
    return !!(s.useDefault || s.added || (s.devices || []).length || (s.hosts || []).length || (s.ad || []).length || (s.adGroups || []).length || (s.ous || []).length);
  }
  // short text for lists: "AD servers, 2 AD groups, 40 workgroup hosts, manually added devices"
  function describe(meta, s) {
    const f = familyOf(meta); if (!f) return 'reads no machines';
    s = s || defaults(meta);
    const parts = [];
    if (s.useDefault || (s.useDefault === undefined && !s.replace)) parts.push('default scope');
    if ((s.ad || []).length) parts.push('AD ' + s.ad.map((x) => ({ AllComputers: 'all computers', DomainControllers: 'domain controllers' })[x] || x.toLowerCase()).join(', '));
    if ((s.adGroups || []).length) parts.push(s.adGroups.length + ' AD group' + (s.adGroups.length > 1 ? 's' : ''));
    if ((s.ous || []).length) parts.push(s.ous.length + ' OU' + (s.ous.length > 1 ? 's' : ''));
    if ((s.hosts || []).length) { let n = 0; try { n = expand(s.hosts).length; } catch (e) { n = s.hosts.length; } parts.push(n + ' workgroup host' + (n > 1 ? 's' : '')); }
    if (s.added) parts.push(((s.addedGroups || []).length ? 'all devices in ' + s.addedGroups.length + ' group' + (s.addedGroups.length > 1 ? 's' : '') : 'all devices of its kinds'));
    if ((s.devices || []).length) parts.push(s.devices.length + ' device' + (s.devices.length > 1 ? 's' : ''));
    if ((s.credentials || []).length) parts.push(s.credentials.length + ' engine credential' + (s.credentials.length > 1 ? 's' : ''));
    return parts.join(' · ') || 'not configured';
  }
  return { FAMILIES, familyOf, defaults, migrate, normalize, expand, addedDevices, credentialFor, configured, describe };
});
