/*
 * RoboMate MonCastle - resource model.
 * Turns script datasets into one categorised resource map and a list of actionable insights.
 * Pure functions; shared by live and demo mode.
 */
(function (root) {
  'use strict';
  const RANK = { Offline: 4, Critical: 3, Warning: 2, OK: 1, Unknown: 0 };
  const worst = (...s) => s.filter(Boolean).reduce((a, b) => (RANK[b] > RANK[a] ? b : a), 'Unknown');
  const up = (s) => String(s || '').toUpperCase().split('.')[0];

  const CATEGORIES = [
    { id: 'identity', name: 'Identity', icon: 'id', hint: 'Domain controllers, CA, NPS' },
    { id: 'servers', name: 'Servers', icon: 'server', hint: 'Windows servers by role' },
    { id: 'virtualization', name: 'Virtualization', icon: 'layers', hint: 'Hyper-V, VMware, clusters, storage' },
    { id: 'databases', name: 'Databases', icon: 'db', hint: 'SQL Server instances' },
    { id: 'network', name: 'Network', icon: 'net', hint: 'Switches, firewalls, APs, appliances' },
    { id: 'linux', name: 'Linux', icon: 'linux', hint: 'Linux and Unix hosts' },
    { id: 'printers', name: 'Printers', icon: 'printer', hint: 'Print queues and devices' },
    { id: 'workstations', name: 'Workstations', icon: 'desktop', hint: 'Domain-joined endpoints' },
  ];

  const ROLE_GROUP = [
    ['DomainControllers', 'Domain controllers'], ['CertificateAuthority', 'Certificate authority'], ['NPS', 'NPS / RADIUS'],
    ['SQL', 'SQL servers'], ['HyperV', 'Hyper-V hosts'], ['FileServers', 'File servers'], ['PrintServers', 'Print servers'],
    ['IIS', 'Web / IIS'], ['RDS', 'Remote desktop'], ['WSUS', 'Infrastructure'], ['General', 'Application servers'],
  ];

  function data(ds, id) { return (ds[id] && ds[id].data) || []; }

  function build(ds, devices) {
    const resources = [];
    const byKey = new Map();
    const add = (r) => {
      r.issues = r.issues || [];
      r.status = r.status || 'Unknown';
      resources.push(r);
      byKey.set(r.kind + ':' + up(r.name), r);
      return r;
    };
    const issue = (r, sev, text, source) => {
      if (!r) return;
      r.issues.push({ sev, text, source });
      r.status = worst(r.status, sev);
    };

    // ---- Windows servers (roles + hardware + compute + availability)
    const roles = {};
    data(ds, 'inventory.roles').forEach((x) => (roles[up(x.ComputerName)] = x.Roles || []));
    const hw = {};
    data(ds, 'inventory.hardware').forEach((x) => (hw[up(x.Name)] = x));
    const comp = {};
    data(ds, 'servers.compute').forEach((x) => (comp[up(x.Name)] = x));
    const avail = {};
    data(ds, 'servers.availability').forEach((x) => (avail[up(x.Name)] = x));
    const names = new Set([...Object.keys(roles), ...Object.keys(hw), ...Object.keys(comp), ...Object.keys(avail)]);
    names.forEach((n) => {
      const rl = roles[n] || ['General'];
      const h = hw[n] || {}, c = comp[n] || {}, a = avail[n] || {};
      const dc = rl.includes('DomainControllers') || rl.includes('CertificateAuthority') || rl.includes('NPS');
      const group = (ROLE_GROUP.find(([k]) => rl.includes(k)) || [null, 'Application servers'])[1];
      const r = add({
        id: 'srv-' + n, kind: 'server', name: n, category: dc ? 'identity' : 'servers', group, roles: rl,
        site: h.ADSite || null, ip: (h.IPAddress && h.IPAddress[0]) || a.Address || null, os: h.OperatingSystem || null,
        machineType: h.MachineType || null, manufacturer: h.Manufacturer, model: h.Model, serial: h.SerialNumber,
        cores: h.CPUCores, ramGB: h.RAMGB, uptimeDays: a.UptimeDays,
        metrics: { cpu: c.CPU, mem: c.Memory, iops: (c.DiskReadIOPS || 0) + (c.DiskWriteIOPS || 0), latency: c.DiskLatencyMs, net: c.NetKBps, latencyMs: a.LatencyMs },
        topProcess: c.TopProcess, status: c.Status && c.Status !== 'Offline' ? c.Status : 'OK',
      });
      if (a.Status === 'Offline' || c.Online === false) { r.status = 'Offline'; r.issues.push({ sev: 'Critical', text: 'Not reachable (ping / WinRM)', source: 'availability' }); }
      if (c.CPU >= 90) issue(r, 'Critical', 'CPU at ' + c.CPU + '%' + (c.TopProcess ? ', top process ' + c.TopProcess : ''), 'compute');
      else if (c.CPU >= 75) issue(r, 'Warning', 'CPU at ' + c.CPU + '%', 'compute');
      if (c.Memory >= 92) issue(r, 'Critical', 'Memory at ' + c.Memory + '%', 'compute');
      else if (c.Memory >= 80) issue(r, 'Warning', 'Memory at ' + c.Memory + '%', 'compute');
      if (c.DiskLatencyMs >= 20) issue(r, 'Warning', 'Disk latency ' + c.DiskLatencyMs + ' ms', 'compute');
    });
    const srv = (n) => byKey.get('server:' + up(n));

    data(ds, 'servers.disks').forEach((d) => {
      const r = srv(d.ComputerName);
      if (!r) return;
      r.disks = r.disks || [];
      r.disks.push(d);
      r.metrics.disk = Math.max(r.metrics.disk || 0, d.UsedPct);
      if (d.Status !== 'OK') issue(r, d.Status, 'Volume ' + d.Volume + ' ' + d.UsedPct + '% used (' + d.FreeGB + ' GB free)', 'disks');
    });
    data(ds, 'servers.services').filter((s) => s.Problem).forEach((s) => issue(srv(s.ComputerName), 'Warning', 'Service stopped: ' + s.DisplayName, 'services'));
    data(ds, 'servers.iis').filter((p) => p.State !== 'Started').forEach((p) => issue(srv(p.ComputerName), 'Warning', 'IIS pool stopped: ' + p.Pool, 'iis'));
    data(ds, 'servers.activation').filter((p) => p.Status && p.Status !== 'Licensed' && p.Status !== 'Unreachable').forEach((p) => issue(srv(p.ComputerName), 'Warning', 'Windows activation: ' + p.Status, 'activation'));
    data(ds, 'security.defender').forEach((d) => {
      const r = srv(d.ComputerName);
      if (!r) return;
      r.defender = d;
      if (d.RealTime === false) issue(r, 'Critical', 'Defender real-time protection is off', 'defender');
      if (d.SignatureAgeDays > 3) issue(r, 'Warning', 'Defender signatures ' + d.SignatureAgeDays + ' days old', 'defender');
      (d.Detections || []).forEach((t) => issue(r, t.Severity === 'Severe' || t.Severity === 'High' ? 'Critical' : 'Warning', 'Threat ' + t.Threat + ' (' + t.Severity + ')', 'defender'));
    });
    data(ds, 'security.patches').forEach((p) => {
      const r = srv(p.ComputerName);
      if (!r || p.Status === 'Unreachable') return;
      r.patch = p;
      if (p.Status !== 'OK') issue(r, p.Status, 'Last patched ' + p.DaysSincePatch + ' days ago', 'patches');
      if (p.PendingReboot) r.issues.push({ sev: 'Info', text: 'Reboot pending to finish updates', source: 'patches' });
    });
    data(ds, 'security.firewall').forEach((f) => (f.Issues || []).forEach((t) => issue(srv(f.ComputerName), f.Status === 'Critical' && t !== 'RDP without NLA' ? 'Critical' : 'Warning', t, 'firewall')));
    data(ds, 'ad.health').forEach((dc) => {
      const r = srv(dc.Name);
      if (!r) return;
      r.dc = dc;
      (dc.Problems || []).forEach((p) => issue(r, dc.Status === 'Critical' ? 'Critical' : 'Warning', p, 'ad'));
      if (dc.TimeOffsetSec && Math.abs(dc.TimeOffsetSec) > 1) r.issues.push({ sev: 'Info', text: 'Clock offset ' + dc.TimeOffsetSec + ' s', source: 'ad' });
    });
    data(ds, 'ad.replication').filter((x) => x.Status === 'Critical').forEach((x) => issue(srv(x.Server), 'Critical', 'Replication from ' + x.Partner + ' failing for ' + Math.round(x.MinutesSinceSuccess / 60) + ' h (error ' + x.LastResult + ')', 'replication'));

    // ---- Hyper-V
    const hv = data(ds, 'virtualization.hyperv');
    hv.filter((x) => x.Kind === 'Host').forEach((h) => {
      const r = srv(h.Name);
      if (r) { r.hvHost = h; r.category = 'virtualization'; r.group = 'Hyper-V hosts'; }
    });
    hv.filter((x) => x.Kind === 'VM').forEach((v) => {
      const linked = srv(v.Name);
      const r = add({ id: 'hvvm-' + v.Name, kind: 'vm', platform: 'Hyper-V', name: v.Name, category: 'virtualization', group: 'Hyper-V VMs', host: v.Host, linked: linked ? linked.id : null,
        ip: (v.IPAddresses || [])[0], status: v.State === 'Running' ? 'OK' : 'Unknown', state: v.State, vm: v,
        metrics: { cpu: v.CPUUsage, memGB: v.MemoryAssignedGB } });
      if (v.CheckpointWarning) issue(r, v.OldestCheckpointDays > 30 ? 'Warning' : 'Warning', 'Checkpoint ' + v.OldestCheckpointDays + ' days old', 'hyperv');
      if (linked) linked.vm = { platform: 'Hyper-V', host: v.Host, id: r.id };
    });

    // ---- VMware
    const vmw = data(ds, 'virtualization.vmware');
    vmw.filter((x) => x.Kind === 'ESXi').forEach((e) => {
      const r = add({ id: 'esx-' + e.Name, kind: 'esxi', name: e.Name.split('.')[0], fqdn: e.Name, category: 'virtualization', group: 'VMware ESXi hosts', status: e.State === 'Connected' ? 'OK' : 'Critical', esx: e, model: e.Model, os: 'VMware ESXi ' + e.Version, metrics: { cpu: e.CPUUsedPct, mem: e.MemoryUsedPct } });
      if (e.CPUUsedPct >= 85) issue(r, 'Warning', 'Host CPU ' + e.CPUUsedPct + '%', 'vmware');
      if (e.MemoryUsedPct >= 80) issue(r, e.MemoryUsedPct >= 90 ? 'Critical' : 'Warning', 'Host memory ' + e.MemoryUsedPct + '%', 'vmware');
    });
    vmw.filter((x) => x.Kind === 'Datastore').forEach((d) => {
      const r = add({ id: 'ds-' + d.Name, kind: 'datastore', name: d.Name, category: 'virtualization', group: 'Datastores', status: 'OK', datastore: d, metrics: { disk: d.UsedPct } });
      if (d.Status !== 'OK') issue(r, d.Status, d.UsedPct + '% used, ' + d.FreeGB + ' GB free', 'vmware');
    });
    vmw.filter((x) => x.Kind === 'VM').forEach((v) => {
      const linked = srv(v.Name);
      const r = add({ id: 'vmw-' + v.Name, kind: 'vm', platform: 'VMware', name: v.Name, category: 'virtualization', group: 'VMware VMs', host: (v.Host || '').split('.')[0], linked: linked ? linked.id : null, ip: (v.IPAddress || [])[0], os: v.GuestOS, status: v.Power === 'PoweredOn' ? 'OK' : 'Unknown', state: v.Power, vm: v, metrics: {} });
      if (v.Power === 'PoweredOn' && v.ToolsStatus !== 'toolsOk') issue(r, 'Warning', 'VMware Tools: ' + v.ToolsStatus, 'vmware');
      if (v.OldestSnapshotDays > 7) issue(r, 'Warning', 'Snapshot ' + v.OldestSnapshotDays + ' days old', 'vmware');
      if (linked) linked.vm = { platform: 'VMware', host: r.host, id: r.id };
    });
    data(ds, 'virtualization.clusters').forEach((c) => {
      const r = add({ id: 'cl-' + c.Cluster, kind: 'cluster', name: c.Cluster, category: 'virtualization', group: 'Failover clusters', status: c.Status, cluster: c });
      (c.Problems || []).forEach((p) => r.issues.push({ sev: c.Status === 'Critical' ? 'Critical' : 'Warning', text: p, source: 'cluster' }));
    });
    data(ds, 'virtualization.clusterstorage').forEach((v) => {
      const cl = byKey.get('cluster:' + up(v.Cluster));
      if (!cl) return;
      cl.storage = cl.storage || [];
      cl.storage.push(v);
      if (v.Status !== 'OK') issue(cl, v.Status, v.Name + ' ' + v.UsedPct + '% used', 'clusterstorage');
    });

    // ---- SQL instances
    const inst = {};
    data(ds, 'sql.databases').forEach((d) => { (inst[d.Instance] = inst[d.Instance] || []).push(d); });
    Object.entries(inst).forEach(([name, dbs]) => {
      const r = add({ id: 'sql-' + name, kind: 'sql', name, category: 'databases', group: 'SQL instances', status: 'OK', databases: dbs, metrics: { sizeGB: Math.round(dbs.reduce((a, d) => a + d.SizeMB, 0) / 1024) } });
      dbs.filter((d) => d.Problems && d.Problems.length).forEach((d) => issue(r, 'Warning', d.Database + ': ' + d.Problems.join(', '), 'sql'));
    });

    // ---- Linux
    data(ds, 'linux.hosts').forEach((l) => {
      const r = add({ id: 'lnx-' + l.Name, kind: 'linux', name: l.Name, category: 'linux', group: /Oracle/.test(l.os || '') ? 'Oracle Linux' : /SUSE/.test(l.os || '') ? 'SUSE' : /Rocky|Red Hat|CentOS/.test(l.os || '') ? 'RHEL family' : 'Debian / Ubuntu', site: l.Site || null, ip: (l.ipAddresses || [])[0], os: l.os, status: l.Online === false ? 'Offline' : l.Status, linux: l, metrics: { cpu: l.cpuPct, mem: l.memUsedPct, disk: l.WorstDiskPct } });
      if (l.Online === false) { r.issues.push({ sev: 'Critical', text: 'SSH unreachable', source: 'linux' }); return; }
      if (l.cpuPct >= 75) r.issues.push({ sev: l.cpuPct >= 90 ? 'Critical' : 'Warning', text: 'CPU ' + l.cpuPct + '%', source: 'linux' });
      if (l.memUsedPct >= 80) r.issues.push({ sev: l.memUsedPct >= 92 ? 'Critical' : 'Warning', text: 'Memory ' + l.memUsedPct + '%', source: 'linux' });
      (l.disks || []).filter((d) => d.usedPct >= 80).forEach((d) => r.issues.push({ sev: d.usedPct >= 90 ? 'Critical' : 'Warning', text: d.mount + ' ' + d.usedPct + '% used', source: 'linux' }));
      if (l.failedUnits) r.issues.push({ sev: 'Warning', text: l.failedUnits + ' failed systemd unit(s)', source: 'linux' });
      if (l.securityUpdates > 5) r.issues.push({ sev: 'Warning', text: l.securityUpdates + ' security updates pending', source: 'linux' });
    });

    // ---- Printers
    const ph = {};
    data(ds, 'printers.health').forEach((p) => (ph[p.Printer] = p));
    data(ds, 'inventory.printers').forEach((p) => {
      const h = ph[p.Name] || {};
      const site = (p.Location || '').split(' / ')[0] || null;
      const r = add({ id: 'prt-' + p.Name, kind: 'printer', name: p.Name, category: 'printers', group: p.PrintServer, site, ip: p.IPAddress, model: p.Model || p.Driver, status: h.Health || 'OK', printer: p, health: h });
      if (h.Health && h.Health !== 'OK') r.issues.push({ sev: h.Health, text: 'Status ' + p.Status + (h.StuckJobs ? ', ' + h.StuckJobs + ' stuck jobs' : ''), source: 'printers' });
    });

    // ---- Network devices
    data(ds, 'network.discovery').forEach((d) => {
      const name = d.HostName ? d.HostName.split('.')[0].toUpperCase() : d.IPAddress;
      if (byKey.has('server:' + up(name))) return;
      const group = d.DeviceClass === 'Network device' ? (/^FW/.test(name) ? 'Firewalls' : /^AP/.test(name) ? 'Wireless APs' : /SW/.test(name) ? 'Switches' : 'Network devices') : d.DeviceClass;
      const r = add({ id: 'net-' + d.IPAddress, kind: 'network', name, category: 'network', group, site: d.Site || null, ip: d.IPAddress, mac: d.MAC, status: 'OK', net: d, metrics: { latencyMs: d.LatencyMs } });
      if (d.DeviceClass === 'Unknown') r.issues.push({ sev: 'Warning', text: 'Unidentified device on the network', source: 'discovery' }), (r.status = 'Warning');
    });

    // ---- Workstations
    data(ds, 'inventory.workstations').forEach((w) => {
      const r = add({ id: 'ws-' + w.Name, kind: 'workstation', name: w.Name, category: 'workstations', group: w.OperatingSystem || 'Workstations', site: w.ADSite, ip: (w.IPAddress || [])[0], os: w.OperatingSystem, manufacturer: w.Manufacturer, model: w.Model, cores: w.CPUCores, ramGB: w.RAMGB, status: 'OK', ws: w });
      if (/Windows 7|Windows 8/.test(w.OperatingSystem || '')) { r.issues.push({ sev: 'Critical', text: 'Unsupported operating system', source: 'inventory' }); r.status = 'Critical'; }
      if (w.TPMEnabled === false) { r.issues.push({ sev: 'Warning', text: 'TPM not enabled', source: 'inventory' }); r.status = worst(r.status, 'Warning'); }
    });

    // ---- devices onboarded for monitoring (added by hand, auto-discovery, import, or found by engines) that no collector
    // dataset describes yet: they are on the map too, with the state of their sensors
    const CAT = { server: 'servers', workstation: 'workstations', linux: 'linux', host: 'virtualization', cluster: 'virtualization', vm: 'virtualization', datastore: 'virtualization', esxi: 'virtualization', vcenter: 'virtualization', sql: 'databases', database: 'databases', printer: 'printers', domain: 'identity' };
    const ST = { Down: 'Critical', Warning: 'Warning', Up: 'OK', Paused: 'Unknown', Unknown: 'Unknown' };
    const known = new Set(resources.map((r) => up(r.name)));
    for (const d of devices || []) {
      if (!d || d.kind === 'external' || d.kind === 'probe') continue;
      const n = up(String(d.name).split('.')[0]);
      const ex = resources.find((r) => up(r.name) === n);
      if (ex) { ex.device = d.id; ex.origin = d.origin; continue; }
      if (known.has(n)) continue;
      known.add(n);
      const r = add({ id: 'dev-' + d.id, kind: d.kind, name: d.name, category: CAT[d.kind] || 'network', group: d.origin === 'engine' ? (d.kind || 'Devices') : 'Manually added', site: d.site || null, ip: d.host || null, os: d.os || null, model: d.model || null, device: d.id, origin: d.origin, manual: d.origin !== 'engine', status: ST[d.state] || 'Unknown', metrics: {} });
      if (d.state === 'Down') r.issues.push({ sev: 'Critical', text: (d.counts && d.counts.Down ? d.counts.Down + ' sensor(s) down' : 'Down'), source: 'monitoring' });
      else if (d.state === 'Warning') r.issues.push({ sev: 'Warning', text: (d.counts && d.counts.Warning ? d.counts.Warning + ' sensor(s) in warning' : 'Warning'), source: 'monitoring' });
    }

    resources.forEach((r) => {
      r.issues.sort((a, b) => (RANK[b.sev] || 0) - (RANK[a.sev] || 0));
      if (!r.site && r.linked) { const l = resources.find((x) => x.id === r.linked); if (l) r.site = l.site; }
    });
    return { resources, byId: new Map(resources.map((r) => [r.id, r])), categories: CATEGORIES, insights: insights(ds, resources) };
  }

  // ------------------------------------------------------------------ insights
  function insights(ds, resources) {
    const out = [];
    const push = (o) => out.push(Object.assign({ id: 'ins-' + out.length }, o));
    const srvOf = (n) => resources.find((r) => r.kind === 'server' && r.name === up(n));

    data(ds, 'servers.availability').filter((a) => a.Status === 'Offline').forEach((a) => push({ sev: 'Critical', area: 'Availability', title: a.Name + ' is offline', detail: 'No ping or WinRM response. Check the host, its VM state or network path.', targets: [a.Name], action: { script: 'act.nettest', params: { Test: 'Port', Target: a.Name, Port: 5985 }, label: 'Test WinRM port' } }));
    data(ds, 'ad.replication').filter((x) => x.Status === 'Critical').slice(0, 1).forEach((x) => push({ sev: 'Critical', area: 'Active Directory', title: 'AD replication ' + x.Partner + ' → ' + x.Server + ' failing', detail: 'Last success ' + Math.round(x.MinutesSinceSuccess / 60) + ' h ago, error ' + x.LastResult + ' (RPC server unavailable). ' + x.ConsecutiveFailures + ' consecutive failures.', targets: [x.Server, x.Partner], action: { script: 'mon.ad.replication', params: { Force: true }, label: 'Force sync and re-check' } }));
    data(ds, 'ad.health').filter((d) => d.ServicesDown && d.ServicesDown.length).forEach((d) => push({ sev: 'Warning', area: 'Active Directory', title: d.ServicesDown.join(', ') + ' stopped on ' + d.Name, detail: 'Domain controller service is not running. SYSVOL/GPO replication depends on DFSR.', targets: [d.Name], action: { script: 'act.service', params: { ComputerName: d.Name, ServiceName: d.ServicesDown[0], Operation: 'Start' }, label: 'Start ' + d.ServicesDown[0] } }));
    data(ds, 'servers.disks').filter((d) => d.Status === 'Critical').forEach((d) => push({ sev: 'Critical', area: 'Storage', title: d.ComputerName + ' ' + d.Volume + ' is ' + d.UsedPct + '% full', detail: d.FreeGB + ' GB free of ' + d.SizeGB + ' GB (' + d.Label + ').', targets: [d.ComputerName], action: { script: 'mon.largefiles', params: { ComputerName: d.ComputerName, MinSizeMB: 1024 }, label: 'Find large files' } }));
    data(ds, 'virtualization.clusterstorage').filter((d) => d.Status === 'Critical').forEach((d) => push({ sev: 'Critical', area: 'Storage', title: d.Cluster + ' ' + d.Name + ' is ' + d.UsedPct + '% used', detail: d.FreeGB + ' GB free on ' + d.Path + '. VMs on a full CSV pause.', targets: [d.Owner] }));
    data(ds, 'virtualization.vmware').filter((d) => d.Kind === 'Datastore' && d.Status === 'Critical').forEach((d) => push({ sev: 'Critical', area: 'Storage', title: 'Datastore ' + d.Name + ' is ' + d.UsedPct + '% used', detail: d.FreeGB + ' GB free of ' + d.CapacityGB + ' GB. Consolidate snapshots or Storage vMotion.', targets: [] }));
    data(ds, 'security.defender').filter((d) => (d.Detections || []).some((t) => t.Severity === 'Severe' || t.Severity === 'High')).forEach((d) => push({ sev: 'Critical', area: 'Security', title: 'Threat on ' + d.ComputerName + ': ' + d.Detections[0].Threat, detail: d.Detections[0].Resources.replace(/^file:_/, '') + ' via ' + (d.Detections[0].Process || 'unknown process') + '. Isolate while you investigate.', targets: [d.ComputerName], action: { script: 'act.isolate', params: { ComputerName: d.ComputerName, Mode: 'Isolate' }, label: 'Isolate ' + d.ComputerName } }));
    data(ds, 'security.defender').filter((d) => d.RealTime === false).forEach((d) => push({ sev: 'Critical', area: 'Security', title: 'Real-time protection off on ' + d.ComputerName, detail: 'Microsoft Defender is installed but not scanning in real time.', targets: [d.ComputerName] }));
    data(ds, 'security.firewall').filter((f) => (f.Issues || []).includes('Firewall profile disabled')).forEach((f) => push({ sev: 'Critical', area: 'Security', title: 'Windows Firewall disabled on ' + f.ComputerName, detail: 'All profiles are off. Re-enable unless a documented exception exists.', targets: [f.ComputerName], action: { script: 'act.firewall', params: { ComputerName: f.ComputerName, State: 'Enable' }, label: 'Enable firewall' } }));
    data(ds, 'security.firewall').filter((f) => f.SMB1).forEach((f) => push({ sev: 'Warning', area: 'Security', title: 'SMBv1 enabled on ' + f.ComputerName, detail: 'SMBv1 is deprecated and exploitable (EternalBlue family).', targets: [f.ComputerName] }));
    const noNla = data(ds, 'security.firewall').filter((f) => (f.Issues || []).includes('RDP without NLA'));
    if (noNla.length) push({ sev: 'Warning', area: 'Security', title: 'RDP without NLA on ' + noNla.map((f) => f.ComputerName).join(', '), detail: 'Network Level Authentication protects RDP from pre-auth attacks.', targets: noNla.map((f) => f.ComputerName), action: { script: 'act.rdp', params: { ComputerName: noNla.map((f) => f.ComputerName).join(','), State: 'Enable' }, label: 'Enforce NLA' } });
    const lock = (ds['audit.events'] && ds['audit.events'].data || []).filter((e) => e.EventSet === 'Lockout');
    const lockBy = lock.reduce((a, e) => ((a[e.Target] = (a[e.Target] || 0) + 1), a), {});
    Object.entries(lockBy).filter(([, n]) => n >= 3).forEach(([u, n]) => {
      const src = lock.find((e) => e.Target === u);
      push({ sev: 'Warning', area: 'Identity', title: u + ' locked out ' + n + ' times', detail: 'Source ' + (src && src.Workstation || 'unknown') + '. Usually a stale saved password (mapped drive, phone mail, service).', targets: src && src.Workstation ? [src.Workstation] : [], action: { script: 'aud.lockout', params: { UserName: u, Days: 1 }, label: 'Investigate lockouts' } });
    });
    (ds['audit.events'] && ds['audit.events'].data || []).filter((e) => e.Privileged && e.EventSet === 'GroupMemberAdded' && Date.now() - Date.parse(e.Time) < 2 * 864e5).forEach((e) => push({ sev: 'Critical', area: 'Identity', title: 'Added to ' + e.Group + ': ' + String(e.Target).replace(/^CN=([^,]+).*/, '$1'), detail: 'By ' + e.Actor + ' at ' + new Date(e.Time).toLocaleString() + '. Confirm this change was approved.', targets: [] }));
    data(ds, 'security.patches').filter((p) => p.Status === 'Critical').forEach((p) => push({ sev: 'Warning', area: 'Patching', title: p.ComputerName + ' not patched for ' + p.DaysSincePatch + ' days', detail: (p.PendingUpdates || 0) + ' updates pending. Last ' + p.LastKB + '.', targets: [p.ComputerName], action: { script: 'act.windowsupdate', params: { ComputerName: p.ComputerName, Mode: 'Scan', Category: 'Security' }, label: 'Scan for updates' } }));
    const reboot = data(ds, 'security.patches').filter((p) => p.PendingReboot);
    if (reboot.length) push({ sev: 'Info', area: 'Patching', title: reboot.length + ' servers waiting for a reboot', detail: reboot.map((p) => p.ComputerName).join(', ') + ' have installed updates that need a restart.', targets: reboot.map((p) => p.ComputerName), action: { script: 'act.power', params: { ComputerName: reboot[0].ComputerName, Operation: 'Restart', DelaySeconds: 300 }, label: 'Schedule restart' } });
    data(ds, 'network.dhcp').filter((s) => s.Status === 'Critical').forEach((s) => push({ sev: 'Critical', area: 'Network', title: 'DHCP scope ' + s.Name + ' ' + s.PercentInUse + '% used', detail: s.Free + ' addresses left in ' + s.ScopeId + ' on ' + s.Server + '. Shorten the lease or extend the range.', targets: [s.Server] }));
    data(ds, 'servers.compute').filter((c) => c.CPU >= 85).forEach((c) => push({ sev: c.CPU >= 90 ? 'Critical' : 'Warning', area: 'Performance', title: c.Name + ' CPU at ' + c.CPU + '%', detail: 'Top process ' + c.TopProcess + ', processor queue ' + c.CPUQueue + '.', targets: [c.Name], action: { script: 'mon.processes', params: { ComputerName: c.Name, SortBy: 'CPU', Top: 15 }, label: 'Show top processes' } }));
    data(ds, 'servers.services').filter((s) => s.Problem).forEach((s) => push({ sev: 'Warning', area: 'Services', title: s.DisplayName + ' stopped on ' + s.ComputerName, detail: 'Automatic service is not running.', targets: [s.ComputerName], action: { script: 'act.service', params: { ComputerName: s.ComputerName, ServiceName: s.Name, Operation: 'Start' }, label: 'Start service' } }));
    data(ds, 'virtualization.hyperv').filter((v) => v.Kind === 'VM' && v.OldestCheckpointDays > 30).forEach((v) => push({ sev: 'Warning', area: 'Virtualization', title: v.Name + ' has a ' + v.OldestCheckpointDays + '-day-old checkpoint', detail: 'Old AVHDX chains grow and slow the VM. Merge it after confirming it is not needed.', targets: [v.Host], action: { script: 'act.hyperv.vm', params: { ComputerName: v.Host, VMName: v.Name, Operation: 'RemoveOldCheckpoints', CheckpointOlderThanDays: 30 }, label: 'Remove old checkpoints' } }));
    data(ds, 'sql.databases').filter((d) => d.Problems && d.Problems.length).forEach((d) => push({ sev: 'Warning', area: 'Databases', title: d.Database + ' on ' + d.Instance + ': ' + d.Problems.join(', '), detail: d.FullBackupAgeHours == null ? 'No full backup on record.' : 'Last full backup ' + d.FullBackupAgeHours + ' h ago' + (d.LogBackupAgeHours != null ? ', log ' + d.LogBackupAgeHours + ' h ago' : '') + '.', targets: [] }));
    data(ds, 'linux.hosts').filter((l) => l.Status === 'Critical').forEach((l) => push({ sev: 'Critical', area: 'Linux', title: l.Name + ' ' + (l.cpuPct >= 90 ? 'CPU ' + l.cpuPct + '%' : l.WorstDiskPct >= 90 ? 'disk ' + l.WorstDiskPct + '% full' : 'memory ' + l.memUsedPct + '%'), detail: l.os + '. Top process ' + ((l.topProcesses || [])[0] || {}).cmd + '.', targets: [] }));
    data(ds, 'printers.health').filter((p) => p.Health === 'Critical').forEach((p) => push({ sev: 'Warning', area: 'Printers', title: p.Printer + ' ' + p.Status.toLowerCase(), detail: p.Location + (p.StuckJobs ? ', ' + p.StuckJobs + ' stuck jobs' : '') + '.', targets: [p.PrintServer] }));
    const unknown = data(ds, 'network.discovery').filter((d) => d.DeviceClass === 'Unknown');
    if (unknown.length) push({ sev: 'Warning', area: 'Network', title: unknown.length + ' unidentified devices on the network', detail: unknown.map((d) => d.IPAddress + (d.MAC ? ' (' + d.MAC + ')' : '')).join(', '), targets: [] });
    data(ds, 'servers.availability').filter((a) => a.UptimeDays > 60).forEach((a) => push({ sev: 'Info', area: 'Patching', title: a.Name + ' up for ' + Math.round(a.UptimeDays) + ' days', detail: 'Long uptime usually means updates are not being applied.', targets: [a.Name] }));
    const risky = data(ds, 'security.fileacl').filter((a) => a.Risky);
    if (risky.length) push({ sev: 'Warning', area: 'Security', title: risky.length + ' file shares writable by broad groups', detail: risky.map((r) => '\\\\' + r.ComputerName + '\\' + r.Share + ' (' + r.Identity + ')').join(', '), targets: [] });

    const order = { Critical: 0, Warning: 1, Info: 2 };
    return out.sort((a, b) => order[a.sev] - order[b.sev]);
  }

  function summarize(model) {
    const unique = model.resources.filter((r) => !r.linked);
    const counts = (list) => list.reduce((a, r) => ((a[r.status] = (a[r.status] || 0) + 1), a), {});
    const cats = model.categories.map((c) => {
      const list = unique.filter((r) => r.category === c.id);
      return Object.assign({}, c, { total: list.length, counts: counts(list) });
    });
    return { total: unique.length, counts: counts(unique), categories: cats };
  }

  root.MCModel = { build, summarize, worst, RANK, CATEGORIES };
})(typeof self !== 'undefined' ? self : this);
