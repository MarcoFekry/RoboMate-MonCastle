/*
 * RoboMate MonCastle - notification e-mail templates. Shared by the browser (window.MCMail, preview) and the server
 * (what is actually sent), so the preview is exactly the e-mail. One modern default template covers every alarm type
 * (Down, Warning, Unknown, Up, test, scheduled job notices); administrators can add their own templates with
 * {{placeholders}} and choose one per notification rule.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCMail = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  // colours stay readable on white and in clients that darken e-mails
  const STATE = {
    Down: { color: '#C62F2F', soft: '#FDECEC', label: 'Down', line: 'needs attention now' },
    Warning: { color: '#B7791F', soft: '#FFF6E0', label: 'Warning', line: 'is close to a threshold' },
    Unknown: { color: '#5F6F86', soft: '#EEF2F7', label: 'Unknown', line: 'stopped reporting' },
    Up: { color: '#0F8A5F', soft: '#E6F6EF', label: 'Recovered', line: 'is back to normal' },
    Paused: { color: '#5F6F86', soft: '#EEF2F7', label: 'Paused', line: 'was paused' },
  };
  const PLACEHOLDERS = [
    ['state', 'New state: Down, Warning, Unknown or Up'], ['previous', 'State before the change'], ['device', 'Device name'], ['sensor', 'Sensor name'],
    ['group', 'Device group'], ['message', 'What the sensor reported'], ['time', 'When it changed (local time of the console)'], ['rule', 'Notification rule name'],
    ['link', 'Address of the sensor in the console'], ['console', 'Console name'], ['stateColor', 'Colour of the state, for your own styling'],
  ];
  const DEFAULT_SUBJECT = '[MonCastle] {{state}}: {{device}} · {{sensor}}';

  function vars(e, ctx) {
    ctx = ctx || {};
    const st = STATE[e.to] || STATE.Unknown;
    let time = e.t;
    try { time = new Date(e.t).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' }); } catch (x) { /* keep ISO */ }
    return {
      state: e.to === 'Up' ? 'Up' : e.to, stateLabel: st.label, previous: e.from || '', device: e.deviceName || e.device || '', sensor: e.sensorName || e.sensor || '',
      group: e.groupName || '', message: e.message || '', time, rule: ctx.rule || '', link: ctx.link || '', console: ctx.console || 'RoboMate MonCastle', stateColor: st.color,
    };
  }
  const fill = (tpl, v, html) => String(tpl || '').replace(/\{\{\s*([a-zA-Z]+)\s*\}\}/g, (m, k) => (k in v ? (html ? esc(v[k]) : String(v[k])) : ''));
  const oneLine = (s) => String(s).replace(/[\r\n]+/g, ' ').slice(0, 250);

  function defaultHtml(v, e) {
    const st = STATE[e.to] || STATE.Unknown;
    const row = (k, val) => (val ? `<tr><td style="padding:9px 0;border-top:1px solid #E6ECF3;color:#5F6F86;font-size:13px;width:120px;vertical-align:top">${k}</td><td style="padding:9px 0;border-top:1px solid #E6ECF3;color:#13233A;font-size:14px;font-weight:600">${val}</td></tr>` : '');
    return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light only"><title>${esc(v.stateLabel)}: ${esc(v.device)}</title></head>
<body style="margin:0;padding:0;background:#EEF2F7;font-family:'Segoe UI',Roboto,Helvetica,Arial,sans-serif;-webkit-font-smoothing:antialiased">
<div style="display:none;max-height:0;overflow:hidden">${esc(v.sensor)} on ${esc(v.device)} ${esc(st.line)}. ${esc(v.message)}</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#EEF2F7"><tr><td align="center" style="padding:28px 12px">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#FFFFFF;border-radius:14px;overflow:hidden;box-shadow:0 2px 10px rgba(10,70,123,.08)">
<tr><td style="background:#0A467B;background-image:linear-gradient(135deg,#0A467B 0%,#1A84D2 55%,#12C08F 100%);padding:18px 26px">
  <span style="color:#FFFFFF;font-size:17px;font-weight:700;letter-spacing:.2px">RoboMate <span style="font-weight:400">MonCastle</span></span>
  <span style="float:right;color:#D7E9F8;font-size:12px;line-height:24px">${esc(v.console)}</span></td></tr>
<tr><td style="padding:24px 26px 6px">
  <span style="display:inline-block;background:${st.soft};color:${st.color};border:1px solid ${st.color};border-radius:999px;padding:3px 12px;font-size:12px;font-weight:700;letter-spacing:.4px;text-transform:uppercase">${esc(st.label)}</span>
  <h1 style="margin:14px 0 4px;font-size:21px;line-height:1.3;color:#13233A;font-weight:700">${esc(v.sensor)}</h1>
  <p style="margin:0;color:#3D4F66;font-size:14.5px;line-height:1.5">on <b>${esc(v.device)}</b> ${esc(st.line)}${v.previous ? ` <span style="color:#7C8CA3">(was ${esc(v.previous)})</span>` : ''}.</p></td></tr>
${v.message ? `<tr><td style="padding:14px 26px 0"><div style="background:${st.soft};border-left:4px solid ${st.color};border-radius:8px;padding:12px 14px;color:#13233A;font-size:14px;line-height:1.5">${esc(v.message)}</div></td></tr>` : ''}
<tr><td style="padding:16px 26px 4px"><table role="presentation" width="100%" cellpadding="0" cellspacing="0">${row('Device', esc(v.device))}${row('Sensor', esc(v.sensor))}${row('Group', esc(v.group))}${row('When', esc(v.time))}${row('Rule', esc(v.rule))}</table></td></tr>
${v.link ? `<tr><td style="padding:18px 26px 26px"><a href="${esc(v.link)}" style="display:inline-block;background:#1673BF;color:#FFFFFF;text-decoration:none;font-weight:600;font-size:14px;padding:11px 20px;border-radius:9px">Open in MonCastle</a>
  <span style="color:#7C8CA3;font-size:12.5px;padding-left:10px">Acknowledge it there to stop repeats.</span></td></tr>` : '<tr><td style="padding:0 0 22px"></td></tr>'}
<tr><td style="background:#F6F8FB;padding:14px 26px;color:#7C8CA3;font-size:12px;line-height:1.5">Sent by RoboMate MonCastle because the rule <b>${esc(v.rule || 'notification')}</b> matched this change. Administrators change who receives these under Configure &gt; Notifications.</td></tr>
</table></td></tr></table></body></html>`;
  }

  function text(v) {
    return `${v.stateLabel.toUpperCase()}: ${v.sensor} on ${v.device}\n\n${v.message ? v.message + '\n\n' : ''}Device: ${v.device}\nSensor: ${v.sensor}\n${v.group ? 'Group: ' + v.group + '\n' : ''}When: ${v.time}\nPrevious state: ${v.previous}\n${v.rule ? 'Rule: ' + v.rule + '\n' : ''}${v.link ? '\nOpen in MonCastle: ' + v.link + '\n' : ''}\n-- RoboMate MonCastle`;
  }

  // tpl = null/undefined for the default, or { subject, html } of a custom template
  function render(e, ctx, tpl) {
    const v = vars(e, ctx);
    if (tpl && tpl.html) {
      const html = fill(tpl.html, v, true);
      const plain = html.replace(/<style[\s\S]*?<\/style>/gi, '').replace(/<br\s*\/?>|<\/p>|<\/tr>|<\/h\d>/gi, '\n').replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&').replace(/\n\s*\n\s*\n+/g, '\n\n').trim();
      return { subject: oneLine(fill(tpl.subject || DEFAULT_SUBJECT, v, false)), html, text: plain };
    }
    return { subject: oneLine(fill((tpl && tpl.subject) || DEFAULT_SUBJECT, v, false)), html: defaultHtml(v, e), text: text(v) };
  }

  const STARTER = `<div style="font-family:Segoe UI,Arial,sans-serif;max-width:560px;margin:auto;border:1px solid #dde3ea;border-radius:10px;overflow:hidden">
  <div style="background:{{stateColor}};color:#fff;padding:14px 18px;font-weight:700">{{state}}: {{device}}</div>
  <div style="padding:16px 18px;color:#13233A">
    <p style="margin:0 0 8px"><b>{{sensor}}</b> changed from {{previous}} to {{state}} at {{time}}.</p>
    <p style="margin:0 0 14px;color:#3D4F66">{{message}}</p>
    <a href="{{link}}" style="color:#1673BF">Open in MonCastle</a>
  </div>
</div>`;

  // a believable sample for previews
  const SAMPLE = { t: new Date().toISOString(), sensor: 's:demo', sensorName: 'Disk free C:', device: 'd:fs01', deviceName: 'FS01', groupName: 'File servers', from: 'Up', to: 'Down', message: 'Free space 4.1% (below the 5% limit)' };
  const clean = (t) => ({ id: String(t.id || ''), name: String(t.name || 'Template').slice(0, 80), subject: oneLine(t.subject || DEFAULT_SUBJECT), html: String(t.html || '').slice(0, 60000) });

  return { render, vars, PLACEHOLDERS, DEFAULT_SUBJECT, STARTER, SAMPLE, STATE, clean };
});
