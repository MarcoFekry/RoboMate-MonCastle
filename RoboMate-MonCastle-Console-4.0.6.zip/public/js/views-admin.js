/*
 * RoboMate MonCastle - access control views: users and roles, user groups with permissions on device groups,
 * the permission matrix, effective access, and the credential vault (saved device credentials and assignments).
 */
(function (root) {
  'use strict';
  const MC = root.MC, C = root.MCCharts, RB = root.MCRbac, CM = root.MCCredModel;
  const { esc, pill, icon, ago, dt, $, $$ } = MC;
  const V = MC.views;
  const isAdmin = () => MC.user.role === 'admin' || !!MC.user.override;
  const ROLE_TEXT = { reader: 'Reader', contributor: 'Contributor', admin: 'Administrator', none: 'No access' };
  const rolePill = (r) => `<span class="pill role ${esc(r)}">${esc(ROLE_TEXT[r] || r)}</span>`;
  const modal = (html, onReady) => {
    const m = document.createElement('div');
    m.className = 'modal'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true');
    m.innerHTML = `<div class="card">${html}</div>`;
    document.body.appendChild(m);
    const close = () => m.remove();
    $$('[data-x]', m).forEach((b) => b.addEventListener('click', close));
    m.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    const f = $('input,textarea,select', m); if (f) f.focus();
    if (onReady) onReady(m, close);
    return m;
  };
  const errBox = (m, e) => { $('[data-err]', m).innerHTML = `<div class="notice err" style="margin-top:10px">${esc(e.message)}</div>`; };
  const chainOf = (groups, gid) => { const out = [gid]; let g = groups.find((x) => x.id === gid); while (g && g.parent && g.parent !== 'probe' && out.length < 10) { out.push(g.parent); g = groups.find((x) => x.id === g.parent); } return out; };
  const scopeName = (tree, s) => (s === 'all' ? 'All device groups' : ((tree.groups || []).find((g) => g.id === s) || {}).name || s);

  // ================================================================== USERS & PERMISSIONS
  V.users = {
    title: 'Users & permissions',
    crumb: () => 'reader · contributor · admin, user groups and permissions on device groups',
    render(el, route) {
      const tab = route.tab || 'users';
      el.innerHTML = MC.tabs('users', [['users', 'Users'], ['groups', 'User groups'], ['matrix', 'Permission matrix'], ['effective', 'Effective access']], tab) + '<div id="tab" class="grid"><div class="notice">Loading…</div></div>';
      const t = $('#tab', el);
      Promise.all([isAdmin() ? MC.api.users() : Promise.resolve([{ name: MC.user.name, role: MC.user.role, restricted: MC.user.restricted, groups: (MC.user.groups || []).map((g) => g.id) }]), isAdmin() ? MC.api.userGroups() : Promise.resolve({ groups: (MC.user.groups || []).map((g) => Object.assign({ members: [MC.user.name], description: '' }, g)), matrix: RB.MATRIX, roles: RB.ROLES }), MC.monTree()])
        .then(([users, ug, tree]) => ({ users: users.slice ? users.slice() : [], groups: ug.groups, matrix: ug.matrix || RB.MATRIX, tree }))
        .then((ctx) => ({ users: usersTab, groups: groupsTab, matrix: matrixTab, effective: effectiveTab }[tab] || usersTab)(t, ctx, () => V.users.render(el, route)))
        .catch((e) => { t.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
    },
  };

  function usersTab(el, ctx, reload) {
    const { users, groups } = ctx;
    const by = (r) => users.filter((u) => RB.norm(u.role) === r).length;
    el.innerHTML = `
      <div class="kpis">${MC.kpi('Users', users.length, users.filter((u) => u.lastLogin).length + ' have signed in')}${MC.kpi('Administrators', by('admin'), '')}${MC.kpi('Contributors', by('contributor'), '')}${MC.kpi('Readers', by('reader'), '')}${MC.kpi('Restricted', users.filter((u) => u.restricted).length, 'see only granted device groups')}${MC.kpi('User groups', groups.length, '')}</div>
      ${MC.panel('Users', isAdmin() ? 'change a role inline; restricted users see only the device groups their user groups grant' : 'your account', '<div id="uT"></div>', { act: isAdmin() ? `<button class="btn sm primary" id="addU">${icon('users', 'sev-ico')}Add user</button>` : '' })}`;
    MC.table($('#uT', el), users, [
      { key: 'name', label: 'User', html: (u) => `<b>${esc(u.name)}</b>${u.name === MC.user.name ? ' <span class="tag">you</span>' : ''}` },
      { key: 'role', label: 'Console role', val: (u) => RB.norm(u.role), html: (u) => (isAdmin() && u.name !== MC.user.name ? `<select class="input sm" data-role="${esc(u.name)}" aria-label="Role of ${esc(u.name)}">${RB.ROLES.map((r) => `<option value="${r}" ${RB.norm(u.role) === r ? 'selected' : ''}>${ROLE_TEXT[r]}</option>`).join('')}</select>` : rolePill(RB.norm(u.role))) },
      { key: 'email', label: 'E-mail', val: (u) => u.email || '', html: (u) => (isAdmin() ? `<button class="btn sm ghost" data-mail="${esc(u.name)}" title="Used for notifications">${u.email ? esc(u.email) : '<span class="muted">add address</span>'}</button>` : esc(u.email || '')) },
      { key: 'restricted', label: 'Scope', val: (u) => (u.restricted ? 'Restricted' : 'All device groups'), html: (u) => (isAdmin() && RB.norm(u.role) !== 'admin' ? `<label class="check"><input type="checkbox" data-restr="${esc(u.name)}" ${u.restricted ? 'checked' : ''}> Restricted</label>` : u.restricted ? pill('Warning', 'Restricted') : '<span class="muted">All device groups</span>') },
      { key: 'groups', label: 'User groups', val: (u) => (u.groups || []).map((id) => (groups.find((g) => g.id === id) || {}).name || id).join(', '), html: (u) => (u.groups || []).map((id) => `<span class="tag">${esc((groups.find((g) => g.id === id) || {}).name || id)}</span>`).join(' ') || '<span class="muted">none</span>' },
      { key: 'created', label: 'Created', html: (u) => dt(u.created), val: (u) => u.created },
      { key: 'lastLogin', label: 'Last sign-in', html: (u) => ago(u.lastLogin), val: (u) => u.lastLogin },
      { key: 'act', label: '', noCsv: true, html: (u) => (isAdmin() ? `<div class="actions-row" style="flex-wrap:nowrap"><button class="btn sm ghost" data-eff="${esc(u.name)}">Access</button><button class="btn sm ghost" data-pw="${esc(u.name)}">Reset password</button>${u.name !== MC.user.name ? `<button class="btn sm ghost" data-del="${esc(u.name)}">Remove</button>` : ''}</div>` : '') },
    ], { sort: 'role', name: 'users' });
    const upd = (name, body, msg) => MC.api.updateUser(name, body).then(() => { MC.toast(msg, 'ok'); reload(); }).catch((e) => { MC.toast(esc(e.message), 'err'); reload(); });
    $$('[data-role]', el).forEach((s) => s.addEventListener('change', () => upd(s.dataset.role, { role: s.value }, esc(s.dataset.role) + ' is now ' + ROLE_TEXT[s.value])));
    $$('[data-restr]', el).forEach((c) => c.addEventListener('change', () => upd(c.dataset.restr, { restricted: c.checked }, esc(c.dataset.restr) + (c.checked ? ' now sees only granted device groups' : ' sees all device groups'))));
    $$('[data-eff]', el).forEach((b) => b.addEventListener('click', () => MC.go('users', 'effective', { user: b.dataset.eff })));
    $$('[data-del]', el).forEach((b) => b.addEventListener('click', () => modal(`<h3>Remove ${esc(b.dataset.del)}?</h3><p class="muted">The account is deleted, its sessions end and it leaves every user group.</p><div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn danger" id="go">Remove user</button></div>`, (m, close) => {
      $('#go', m).addEventListener('click', () => MC.api.removeUser(b.dataset.del).then(() => { close(); MC.toast('Removed ' + esc(b.dataset.del), 'ok'); reload(); }).catch((e) => errBox(m, e)));
    })));
    $$('[data-mail]', el).forEach((b) => b.addEventListener('click', () => { const u = users.find((x) => x.name === b.dataset.mail) || {}; modal(`<h3>E-mail address of ${esc(u.name)}</h3><div class="field"><label for="em">E-mail</label><input class="input" id="em" type="email" value="${esc(u.email || '')}" placeholder="name@company.com"><span class="hint">Notification rules that send to this user, or to a user group they are in, use this address. Leave empty to remove it.</span></div><div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Save</button></div>`, (m, close) => {
      $('#go', m).addEventListener('click', () => MC.api.updateUser(u.name, { email: $('#em', m).value.trim() }).then(() => { close(); MC.toast('Saved', 'ok'); reload(); }).catch((e) => errBox(m, e)));
    }); }));
    $$('[data-pw]', el).forEach((b) => b.addEventListener('click', () => modal(`<h3>Reset the password of ${esc(b.dataset.pw)}</h3><div class="field"><label for="np">New password</label><input class="input" id="np" type="password" minlength="12" autocomplete="new-password"><span class="hint">At least 12 characters. Their other sessions are signed out.</span></div><div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Set password</button></div>`, (m, close) => {
      $('#go', m).addEventListener('click', () => MC.api.updateUser(b.dataset.pw, { password: $('#np', m).value }).then(() => { close(); MC.toast('Password changed', 'ok'); }).catch((e) => errBox(m, e)));
    })));
    if ($('#addU', el)) $('#addU', el).addEventListener('click', () => modal(`<h3>Add a user</h3>
      <div class="field"><label for="nu">User name</label><input class="input" id="nu" pattern="[A-Za-z0-9._-]{3,40}" autocomplete="off"></div>
      <div class="field"><label for="ne">E-mail (for notifications)</label><input class="input" id="ne" type="email" autocomplete="off" placeholder="name@company.com"></div>
      <div class="field"><label for="np">Password</label><input class="input" id="np" type="password" minlength="12" autocomplete="new-password"><span class="hint">At least 12 characters.</span></div>
      <div class="field"><label for="nr">Console role</label><select class="input" id="nr">${RB.ROLES.map((r) => `<option value="${r}">${ROLE_TEXT[r]}</option>`).join('')}</select></div>
      <label class="check"><input type="checkbox" id="nx"> Restricted: only the device groups granted by the user groups below</label>
      ${groups.length ? `<fieldset style="margin-top:8px"><legend>User groups</legend>${groups.map((g) => `<label class="check"><input type="checkbox" data-g="${esc(g.id)}"> ${esc(g.name)} <span class="muted" style="font-size:12px">${g.grants.map((x) => ROLE_TEXT[x.role] + ' on ' + esc(scopeName(ctx.tree, x.scope))).join(', ')}</span></label>`).join('')}</fieldset>` : ''}
      <div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Add user</button></div>`, (m, close) => {
      $('#go', m).addEventListener('click', async () => {
        try {
          const name = $('#nu', m).value.trim();
          await MC.api.addUser({ username: name, email: $('#ne', m).value.trim(), password: $('#np', m).value, role: $('#nr', m).value, restricted: $('#nx', m).checked });
          for (const c of $$('[data-g]:checked', m)) { const g = groups.find((x) => x.id === c.dataset.g); await MC.api.saveUserGroup(Object.assign({}, g, { members: g.members.concat(name) })); }
          close(); MC.toast('Added ' + esc(name), 'ok'); reload();
        } catch (e) { errBox(m, e); }
      });
    }));
  }

  function groupsTab(el, ctx, reload) {
    const { groups, users, tree } = ctx;
    el.innerHTML = `
      ${MC.panel('User groups', 'members get the role of each grant on that device group and its sub-groups; the highest grant wins, a console admin is always admin', `<div class="ugrid">${groups.map((g) => `
        <div class="card ug"><div style="display:flex;gap:8px;align-items:center"><b>${esc(g.name)}</b><span class="muted" style="font-size:12px">${g.members.length} member${g.members.length === 1 ? '' : 's'}</span>${isAdmin() ? `<span style="margin-left:auto"></span><button class="btn sm ghost" data-edit="${esc(g.id)}">Edit</button>` : ''}</div>
        ${g.description ? `<div class="muted" style="font-size:12.5px">${esc(g.description)}</div>` : ''}
        <div>${g.grants.map((x) => `<div class="grant">${rolePill(x.role)}<span>on ${esc(scopeName(tree, x.scope))}</span></div>`).join('') || '<span class="muted">No permissions yet</span>'}</div>
        <div class="members">${g.members.map((m) => `<span class="tag">${esc(m)}</span>`).join(' ') || '<span class="muted">No members</span>'}</div></div>`).join('') || '<div class="muted">No user groups yet.</div>'}</div>`, { act: isAdmin() ? `<button class="btn sm primary" data-edit="">Add user group</button>` : '' })}`;
    $$('[data-edit]', el).forEach((b) => b.addEventListener('click', () => groupDialog(groups.find((g) => g.id === b.dataset.edit), users, tree, reload)));
  }
  function groupDialog(g, users, tree, reload) {
    g = g || { name: '', description: '', members: [], grants: [{ scope: 'all', role: 'reader' }] };
    const scopes = [['all', 'All device groups']].concat((tree.groups || []).slice().sort((a, b) => a.name.localeCompare(b.name)).map((x) => [x.id, x.name]));
    const grantRow = (x) => `<div class="grantrow"><select class="input" data-sc aria-label="Device group">${scopes.map(([id, n]) => `<option value="${esc(id)}" ${x.scope === id ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select><select class="input" data-ro aria-label="Role">${RB.ROLES.map((r) => `<option value="${r}" ${x.role === r ? 'selected' : ''}>${ROLE_TEXT[r]}</option>`).join('')}</select><button type="button" class="btn sm ghost" data-rm aria-label="Remove permission">${icon('x', 'sev-ico')}</button></div>`;
    modal(`<h3>${g.id ? 'Edit ' + esc(g.name) : 'Add a user group'}</h3>
      <div class="field"><label for="gn">Name</label><input class="input" id="gn" value="${esc(g.name)}"></div>
      <div class="field"><label for="gd">Description</label><input class="input" id="gd" value="${esc(g.description || '')}"></div>
      <fieldset><legend>Permissions on device groups</legend><div id="grs">${g.grants.map(grantRow).join('')}</div><button type="button" class="btn sm" id="addG">Add permission</button></fieldset>
      <fieldset style="margin-top:10px"><legend>Members</legend><div class="optgrid">${users.map((u) => `<label class="check"><input type="checkbox" data-mem="${esc(u.name)}" ${g.members.includes(u.name) ? 'checked' : ''}> ${esc(u.name)} <span class="muted" style="font-size:12px">${ROLE_TEXT[RB.norm(u.role)]}${u.restricted ? ', restricted' : ''}</span></label>`).join('')}</div></fieldset>
      <div data-err></div><div class="foot">${g.id ? '<button class="btn danger" id="del" style="margin-right:auto">Delete group</button>' : ''}<button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Save</button></div>`, (m, close) => {
      m.querySelector('.card').classList.add('wide');
      const wireRm = () => $$('[data-rm]', m).forEach((b) => (b.onclick = () => b.parentElement.remove()));
      wireRm();
      $('#addG', m).addEventListener('click', () => { $('#grs', m).insertAdjacentHTML('beforeend', grantRow({ scope: 'all', role: 'reader' })); wireRm(); });
      $('#go', m).addEventListener('click', () => MC.api.saveUserGroup({ id: g.id, name: $('#gn', m).value, description: $('#gd', m).value, members: $$('[data-mem]:checked', m).map((c) => c.dataset.mem), grants: $$('.grantrow', m).map((r) => ({ scope: $('[data-sc]', r).value, role: $('[data-ro]', r).value })) }).then(() => { close(); MC.toast('Saved user group', 'ok'); reload(); }).catch((e) => errBox(m, e)));
      if ($('#del', m)) $('#del', m).addEventListener('click', () => MC.api.removeUserGroup(g.id).then(() => { close(); MC.toast('Deleted ' + esc(g.name), 'ok'); reload(); }).catch((e) => errBox(m, e)));
    });
  }

  function matrixTab(el, ctx) {
    const tick = (need, r) => (RB.atLeast(r, need) ? `<td class="OK" aria-label="yes">✓</td>` : '<td class="muted" aria-label="no">·</td>');
    el.innerHTML = MC.panel('What each role can do', 'console roles; user groups grant the same roles on chosen device groups', `<div style="overflow-x:auto"><table class="repl matrix"><thead><tr><th></th>${RB.ROLES.map((r) => `<th scope="col">${ROLE_TEXT[r]}</th>`).join('')}</tr></thead><tbody>${ctx.matrix.map(([what, need]) => `<tr><th scope="row" style="text-align:left;font-weight:500">${esc(what)}</th>${RB.ROLES.map((r) => tick(need, r)).join('')}</tr>`).join('')}</tbody></table></div>
      <p class="muted" style="font-size:12.5px;margin-top:10px">A user's role on a device is the highest of: their console role (unless they are restricted) and every grant of their user groups on the device's group or a parent group. Actions run against several devices need the role on all of them. Readers never see credential secrets; nobody does.</p>`);
  }

  function effectiveTab(el, ctx) {
    const { users, groups, tree } = ctx;
    const pick = (MC.route.q && MC.route.q.user) || (isAdmin() ? users[0].name : MC.user.name);
    const u = users.find((x) => x.name === pick) || users[0];
    const chain = (gid) => chainOf(tree.groups || [], gid);
    const rows = (tree.groups || []).map((g) => ({ id: g.id, name: g.name, devices: g.devices, role: RB.access(u, g.id, groups, chain), via: groups.filter((x) => x.members.includes(u.name) && x.grants.some((gr) => gr.scope === 'all' || chain(g.id).includes(gr.scope))).map((x) => x.name) }));
    const counts = rows.reduce((a, r) => ((a[r.role] = (a[r.role] || 0) + r.devices), a), {});
    el.innerHTML = `
      <div class="toolbar">${isAdmin() ? `<label for="effU" class="muted">User</label><select class="input" id="effU" style="max-width:260px">${users.map((x) => `<option ${x.name === u.name ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select>` : ''}<span class="muted" style="font-size:12.5px">${esc(u.name)}: console role ${ROLE_TEXT[RB.norm(u.role)]}${u.restricted ? ', restricted' : ''}</span></div>
      <div class="kpis">${['admin', 'contributor', 'reader', 'none'].map((r) => MC.kpi(ROLE_TEXT[r], counts[r] || 0, 'devices')).join('')}</div>
      <div class="grid g-1-2">
        ${MC.panel('Devices by role', '', C.barList(['admin', 'contributor', 'reader', 'none'].map((r, i) => ({ label: ROLE_TEXT[r], value: counts[r] || 0, text: (counts[r] || 0) + ' devices', color: ['--s4', '--s1', '--s2', '--muted'][i] })), {}))}
        ${MC.panel('Role per device group', '', '<div id="effT"></div>')}
      </div>`;
    MC.table($('#effT', el), rows, [{ key: 'name', label: 'Device group' }, { key: 'devices', label: 'Devices', n: true }, { key: 'role', label: 'Role', val: (r) => RB.RANK[r.role], html: (r) => rolePill(r.role) }, { key: 'via', label: 'From', val: (r) => r.via.join(', '), html: (r) => (r.via.length ? r.via.map((v) => `<span class="tag">${esc(v)}</span>`).join(' ') : `<span class="muted">${u.restricted ? 'nothing granted' : 'console role'}</span>`) }], { sort: 'role', name: 'effective-access-' + u.name });
    if ($('#effU', el)) $('#effU', el).addEventListener('change', (e) => MC.go('users', 'effective', { user: e.target.value }));
  }

  // ================================================================== CREDENTIALS
  V.credentials = {
    title: 'Credentials',
    crumb: () => 'saved device credentials, assignments and who may use them',
    render(el) {
      el.innerHTML = '<div class="notice">Loading…</div>';
      Promise.all([MC.api.credentials(), MC.monTree(), isAdmin() ? MC.api.userGroups().then((x) => x.groups) : Promise.resolve(MC.user.groups || [])])
        .then(([creds, tree, ugroups]) => drawCreds(el, creds, tree, ugroups))
        .catch((e) => { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
    },
  };
  function drawCreds(el, creds, tree, ugroups) {
    const reload = () => V.credentials.render(el);
    const canAdd = RB.atLeast(RB.norm(MC.user.role), 'contributor') || (MC.user.groups || []).some((g) => g.grants.some((x) => x.role !== 'reader'));
    const byKind = CM.KINDS.map((k, i) => ({ k, n: creds.filter((c) => c.kind === k.id).length, color: ['--s1', '--s2', '--s3', '--s4', '--s1', '--s2', '--s3'][i] })).filter((x) => x.n);
    const failing = creds.filter((c) => c.lastTest && !c.lastTest.ok);
    const assignText = (c) => [c.assign.all ? 'Probe default' : null, ...c.assign.groups.map((g) => scopeName(tree, g)), c.assign.devices.length ? c.assign.devices.length + ' devices' : null].filter(Boolean);
    el.innerHTML = `
      <div class="kpis">${MC.kpi('Saved credentials', creds.length, byKind.length + ' kinds')}${MC.kpi('Probe defaults', creds.filter((c) => c.assign.all).length, 'used when nothing closer is set')}${MC.kpi('Set on devices', creds.reduce((a, c) => a + c.usedBy.length, 0), 'device-level assignments')}${MC.kpi('Never tested', creds.filter((c) => !c.lastTest).length, '')}${MC.kpi('Last test failed', failing.length, failing.map((c) => c.name).join(', '), { alert: failing.length > 0 })}</div>
      <div class="grid g-1-2">
        ${MC.panel('By method', '', '<div id="crD"></div>')}
        ${MC.panel('Which credential does a device use?', 'device first, then its group and parent groups, then the probe default', `<div class="toolbar"><select class="input" id="crDev" style="max-width:320px" aria-label="Device"><option value="">Pick a device…</option>${(tree.devices || []).slice().sort((a, b) => a.name.localeCompare(b.name)).map((d) => `<option value="${esc(d.id)}">${esc(d.name)}</option>`).join('')}</select></div><div id="crRes" class="muted" style="font-size:13px">Shows the credential per method and where it comes from.</div>`)}
      </div>
      ${MC.panel('Credentials', 'secrets are stored encrypted on the console and never sent to a browser', '<div id="crT"></div>', { act: canAdd ? `<button class="btn sm primary" id="addC">${icon('lock', 'sev-ico')}Add credential</button>` : '' })}`;
    C.donut($('#crD', el), byKind.map((x) => ({ label: x.k.name, value: x.n, color: x.color })), { centerLabel: 'credentials' });
    MC.table($('#crT', el), creds, [
      { key: 'name', label: 'Name', html: (c) => `<b>${esc(c.name)}</b>${c.private ? ' <span class="tag">private</span>' : ''}${c.description ? `<br><span class="muted" style="font-size:12px">${esc(c.description)}</span>` : ''}` },
      { key: 'kind', label: 'Method', val: (c) => c.kindName, html: (c) => `<span class="tag">${esc(c.kindName)}</span><br><span class="muted mono" style="font-size:11.5px">${esc([c.fields.domain, c.fields.username].filter(Boolean).join('\\') || c.fields.version || c.fields.method || '')}</span>` },
      { key: 'assign', label: 'Assigned to', val: (c) => assignText(c).join(', '), html: (c) => assignText(c).map((a) => `<span class="tag ${a === 'Probe default' ? 'collector' : ''}">${esc(a)}</span>`).join(' ') || '<span class="muted">picked per device</span>' },
      { key: 'usedBy', label: 'Set on devices', val: (c) => c.usedBy.length, html: (c) => (c.usedBy.length ? `<span title="${esc(c.usedBy.join(', '))}">${c.usedBy.length}</span>` : '<span class="muted">0</span>') },
      { key: 'minRole', label: 'Who may use it', val: (c) => (c.userGroups.length ? c.userGroups.join(',') : c.minRole), html: (c) => (c.userGroups.length ? c.userGroups.map((id) => `<span class="tag">${esc((ugroups.find((g) => g.id === id) || {}).name || id)}</span>`).join(' ') : rolePill(c.minRole) + ' <span class="muted" style="font-size:12px">and up</span>') },
      { key: 'lastUsed', label: 'Last used', html: (c) => ago(c.lastUsed), val: (c) => c.lastUsed },
      { key: 'lastTest', label: 'Last test', val: (c) => (c.lastTest ? (c.lastTest.ok ? 'ok' : 'failed') : ''), html: (c) => (c.lastTest ? `<span title="${esc(c.lastTest.host + ': ' + c.lastTest.message)}">${pill(c.lastTest.ok ? 'OK' : 'Critical', c.lastTest.ok ? 'OK' : 'Failed')} <span class="muted" style="font-size:12px">${ago(c.lastTest.at)}</span></span>` : '<span class="muted">never</span>') },
      { key: 'act', label: '', noCsv: true, html: (c) => `<div class="actions-row" style="flex-wrap:nowrap"><button class="btn sm ghost" data-test="${esc(c.id)}">Test</button>${c.editable ? `<button class="btn sm ghost" data-ed="${esc(c.id)}">Edit</button><button class="btn sm ghost" data-rm="${esc(c.id)}">Delete</button>` : ''}</div>` },
    ], { sort: 'kind', dir: 1, name: 'credentials' });
    $('#crDev', el).addEventListener('change', (e) => {
      const d = (tree.devices || []).find((x) => x.id === e.target.value);
      if (!d) return;
      const chain = chainOf(tree.groups || [], d.group);
      $('#crRes', el).innerHTML = `<table class="tbl"><tbody>${CM.kindsFor(d.kind).map((k) => { const r = CM.resolve(creds, d, chain, k); return `<tr><td>${esc(CM.KIND[k].name)}</td><td>${r ? '<b>' + esc(r.cred.name) + '</b>' : '<span class="muted">none, the engine account is used</span>'}</td><td class="muted">${r ? esc(r.from === 'device' ? 'set on the device' : r.from.replace(/^group (.+)$/, (x, g) => 'from group ' + scopeName(tree, g))) : ''}</td></tr>`; }).join('')}</tbody></table>`;
    });
    if ($('#addC', el)) $('#addC', el).addEventListener('click', () => credDialog(null, tree, ugroups, reload));
    $$('[data-ed]', el).forEach((b) => b.addEventListener('click', () => credDialog(creds.find((c) => c.id === b.dataset.ed), tree, ugroups, reload)));
    $$('[data-rm]', el).forEach((b) => b.addEventListener('click', () => { const c = creds.find((x) => x.id === b.dataset.rm); modal(`<h3>Delete ${esc(c.name)}?</h3><p class="muted">Devices that inherit it fall back to the next credential in line. A credential still set on a device cannot be deleted.</p><div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn danger" id="go">Delete</button></div>`, (m, close) => {
      $('#go', m).addEventListener('click', () => MC.api.removeCredential(c.id).then(() => { close(); MC.toast('Deleted ' + esc(c.name), 'ok'); reload(); }).catch((e) => errBox(m, e)));
    }); }));
    $$('[data-test]', el).forEach((b) => b.addEventListener('click', () => { const c = creds.find((x) => x.id === b.dataset.test); const first = (tree.devices || []).find((d) => c.usedBy.includes(d.name) || c.assign.groups.includes(d.group)); const dbEng = (d) => (d && (d.engine || String(d.profile || '').replace(/^db-/, ''))) || 'postgres'; modal(`<h3>Test ${esc(c.name)}</h3><p class="muted">${c.kind.startsWith('snmp') ? 'Signs in with SNMP and reads the system name.' : c.kind === 'http' ? 'Requests the URL with this authentication.' : c.kind === 'database' ? 'Speaks the database protocol: engine://host[:port], for example postgres://db01, redis://cache01 or elastic://logs01:9200. Redis and the HTTP engines really sign in.' : c.kind === 'cloud' ? 'Checks that the provider sign-in endpoint answers; the cloud storage engine signs in on its next run. The host can stay empty.' : 'Checks that the service answers on the device; the engine signs in on its next run.'}</p><div class="field"><label for="th">Host, IP${c.kind === 'http' ? ' or URL' : ''}</label><input class="input mono" id="th" value="${esc(c.kind === 'database' ? dbEng(first) + '://' + (first ? first.host || first.name : '') : c.kind === 'cloud' ? '' : first ? first.host || first.name : '')}"></div><div id="tr"></div><div data-err></div><div class="foot"><button class="btn" data-x>Close</button><button class="btn primary" id="go">Test</button></div>`, (m) => {
      $('#go', m).addEventListener('click', async () => { $('#tr', m).innerHTML = '<div class="notice">Testing…</div>'; try { const r = await MC.api.testCredential(c.id, $('#th', m).value.trim()); $('#tr', m).innerHTML = `<div class="notice ${r.ok ? 'ok' : 'err'}">${r.ok ? '✓' : '✕'} ${esc(r.message)} <span class="muted">(${r.ms} ms)</span></div>`; } catch (e) { $('#tr', m).innerHTML = ''; errBox(m, e); } });
    }); }));
  }
  function credDialog(c, tree, ugroups, reload) {
    const kind0 = c ? c.kind : 'windows';
    const groups = (tree.groups || []).slice().sort((a, b) => a.name.localeCompare(b.name));
    const field = (f) => {
      const id = 'f-' + f.name, v = c ? c.fields[f.name] : null, isSet = c && c.secretsSet && c.secretsSet[f.name];
      const lbl = `<label for="${id}">${esc(f.label)}${f.required ? ' *' : ''}${f.secret && c ? ` <span class="muted" style="font-weight:400">(${isSet ? 'set; leave empty to keep' : c.secretsSet ? 'not set' : 'leave empty to keep'})</span>` : ''}</label>`;
      if (f.values) return `<div class="field">${lbl}<select class="input" id="${id}" data-f="${f.name}">${f.values.map((x) => `<option ${(v || f.def) === x ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select></div>`;
      if (f.multiline) return `<div class="field">${lbl}<textarea class="input mono" id="${id}" data-f="${f.name}" rows="4" spellcheck="false" autocomplete="off"></textarea></div>`;
      return `<div class="field">${lbl}<input class="input" id="${id}" data-f="${f.name}" ${f.secret ? 'type="password" autocomplete="new-password"' : f.type === 'int' ? 'type="number"' : 'autocomplete="off"'} value="${f.secret ? '' : esc(v != null ? v : f.def != null ? f.def : '')}"></div>`;
    };
    modal(`<h3>${c ? 'Edit ' + esc(c.name) : 'Add a credential'}</h3>
      <div class="grid g2" style="gap:0 14px">
        <div>
          <div class="field"><label for="ck">Method</label><select class="input" id="ck" ${c ? 'disabled' : ''}>${CM.KINDS.map((k) => `<option value="${k.id}" ${k.id === kind0 ? 'selected' : ''}>${esc(k.name)}</option>`).join('')}</select><span class="hint" id="ckd"></span></div>
          <div class="field"><label for="cn">Name</label><input class="input" id="cn" value="${esc(c ? c.name : '')}" placeholder="CORP\\svc-moncastle"></div>
          <div class="field"><label for="cd">Description</label><input class="input" id="cd" value="${esc(c ? c.description : '')}"></div>
          <div id="cf"></div>
        </div>
        <div>
          <fieldset><legend>Assign to</legend>
            ${isAdmin() ? `<label class="check"><input type="checkbox" id="ca" ${c && c.assign.all ? 'checked' : ''}> Probe default: every device without a closer credential of this method</label>` : ''}
            <div class="optgrid one">${groups.filter((g) => isAdmin() || RB.atLeast(g.access || 'none', 'contributor')).map((g) => `<label class="check"><input type="checkbox" data-ag="${esc(g.id)}" ${c && c.assign.groups.includes(g.id) ? 'checked' : ''}> ${esc(g.name)} <span class="muted" style="font-size:12px">${g.devices} devices</span></label>`).join('')}</div>
          </fieldset>
          <fieldset style="margin-top:10px"><legend>Who may use it on devices</legend>
            <div class="field"><label for="cr">Minimum role</label><select class="input" id="cr">${RB.ROLES.map((r) => `<option value="${r}" ${(c ? c.minRole : 'contributor') === r ? 'selected' : ''}>${ROLE_TEXT[r]} and up</option>`).join('')}</select></div>
            ${ugroups.length ? `<div class="muted" style="font-size:12px;margin-bottom:4px">Or only members of these user groups:</div>${ugroups.map((g) => `<label class="check"><input type="checkbox" data-ug="${esc(g.id)}" ${c && c.userGroups.includes(g.id) ? 'checked' : ''}> ${esc(g.name)}</label>`).join('')}` : ''}
            <label class="check" style="margin-top:6px"><input type="checkbox" id="cp" ${c && c.private ? 'checked' : ''}> Private: only I ${isAdmin() ? '' : 'and administrators '}can pick it</label>
          </fieldset>
        </div>
      </div>
      <div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">${c ? 'Save' : 'Add credential'}</button></div>`, (m, close) => {
      m.querySelector('.card').classList.add('wide');
      const drawFields = () => { const k = CM.KIND[$('#ck', m).value]; $('#cf', m).innerHTML = k.fields.map(field).join(''); $('#ckd', m).textContent = k.desc; };
      drawFields();
      $('#ck', m).addEventListener('change', drawFields);
      $('#go', m).addEventListener('click', async () => {
        const fields = Object.fromEntries($$('[data-f]', m).map((i) => [i.dataset.f, i.value]));
        try {
          await MC.api.saveCredential({ id: c ? c.id : undefined, kind: $('#ck', m).value, name: $('#cn', m).value, description: $('#cd', m).value, fields, assign: { all: !!($('#ca', m) && $('#ca', m).checked), groups: $$('[data-ag]:checked', m).map((x) => x.dataset.ag), devices: c ? c.assign.devices : [] }, minRole: $('#cr', m).value, userGroups: $$('[data-ug]:checked', m).map((x) => x.dataset.ug), private: $('#cp', m).checked });
          close(); MC.toast(c ? 'Saved' : 'Added credential', 'ok'); reload();
        } catch (e) { errBox(m, e); }
      });
    });
  }
})(typeof self !== 'undefined' ? self : this);
