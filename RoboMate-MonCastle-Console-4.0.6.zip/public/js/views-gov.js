/*
 * RoboMate MonCastle - governance and admin views: inventory, audit, security, actions & jobs,
 * script library, licence & access log, settings.
 */
(function (root) {
  'use strict';
  const MC = root.MC, C = root.MCCharts;
  const { esc, fmt, pill, icon, sevIcon, ago, dt, minibar, $, $$ } = MC;
  const V = MC.views;
  const sum = (a) => a.reduce((x, y) => x + (y || 0), 0);
  const pct = (a, b) => (b ? Math.round((a / b) * 100) : 0);
  const countBy = (list, f) => Object.entries(list.reduce((a, x) => { const k = f(x) || 'Unknown'; a[k] = (a[k] || 0) + 1; return a; }, {})).sort((a, b) => b[1] - a[1]);
  const donutItems = (entries, n = 4) => entries.slice(0, n).map(([k, v], i) => ({ label: k, value: v, color: C.SERIES[i] })).concat(entries.length > n ? [{ label: 'Other', value: sum(entries.slice(n).map((x) => x[1])), color: '--muted' }] : []);
  const host = (n) => `<a href="#" data-host="${esc(n)}">${esc(n)}</a>`;

  // ================================================================== INVENTORY
  // Every monitored resource, whatever its kind, joined with what the collectors know about it.
  const INV_CAT = { server: 'Windows servers', workstation: 'Workstations', linux: 'Linux', network: 'Network', firewall: 'Network', wireless: 'Network', loadbalancer: 'Network', camera: 'Network', voip: 'Network', appliance: 'Network',
    san: 'Storage', nas: 'Storage', fcswitch: 'Storage', backup: 'Storage', ups: 'Power & hardware', pdu: 'Power & hardware', environment: 'Power & hardware', bmc: 'Power & hardware',
    host: 'Virtualization', esxi: 'Virtualization', vcenter: 'Virtualization', cluster: 'Virtualization', vm: 'Virtualization', datastore: 'Virtualization', domain: 'Active Directory', sql: 'Databases', database: 'Databases', cloudstorage: 'Cloud storage', printer: 'Printers', web: 'Websites & services' };
  const INV_TAB = { network: 'Network', linux: 'Linux', storage: 'Storage', databases: 'Databases', cloud: 'Cloud storage', power: 'Power & hardware', virtualization: 'Virtualization' };
  function resources(t) {
    const S = root.MCSensors;
    const by = (ds, k) => new Map(MC.data(ds).map((r) => [String(r[k] || '').toLowerCase(), r]));
    const hw = by('inventory.hardware', 'Name'), ws = by('inventory.workstations', 'Name'), lx = by('linux.hosts', 'Name'), db = by('databases.health', 'Host');
    const disc = by('network.discovery', 'IPAddress'), esx = new Map(MC.data('virtualization.vmware').filter((r) => r.Kind === 'ESXi').map((r) => [String(r.Name).split('.')[0].toLowerCase(), r]));
    const cloud = new Map(MC.data('cloud.storage').filter((r) => r.Kind === 'Account').map((r) => [String(r.Endpoint).toLowerCase(), r]));
    const kindName = Object.assign({ esxi: 'VMware ESXi host', vcenter: 'VMware vCenter', vm: 'Virtual machine', datastore: 'Datastore', domain: 'AD domain' }, Object.fromEntries(S.CLASSES.map(([k, l]) => [k, l])));
    const gname = Object.fromEntries(t.groups.map((g) => [g.id, g.name]));
    return t.devices.map((d) => {
      const n = String(d.name).toLowerCase(), prof = d.profile && S.PROFILE[d.profile];
      const r = { id: d.id, Name: d.name, Category: INV_CAT[d.kind] || 'Other', Type: kindName[d.kind] || d.kind, Address: d.host || '', Vendor: prof ? prof.vendor : '', Model: prof ? prof.name : d.model || '', OS: d.os || '', Serial: '', Group: gname[d.group] || d.group, Site: d.site || '', State: d.state, Sensors: d.sensors };
      const h = hw.get(n) || ws.get(n);
      if (h) Object.assign(r, { Vendor: h.Manufacturer || r.Vendor, Model: h.Model || r.Model, OS: h.OperatingSystem ? h.OperatingSystem + (h.OSBuild ? ' (' + h.OSBuild + ')' : '') : r.OS, Serial: h.SerialNumber || '', Site: h.ADSite || r.Site });
      const l = lx.get(n);
      if (l) Object.assign(r, { Vendor: l.vendor || r.Vendor, Model: l.model || r.Model, OS: l.os ? l.os + (l.kernel ? ' · ' + l.kernel : '') : r.OS, Serial: l.serial || '' });
      const b = db.get(n);
      if (b) Object.assign(r, { Vendor: (S.DB_ENGINE[b.Engine] || {}).vendor || r.Vendor, OS: b.Version || r.OS, Model: r.Model || b.Role || '' });
      const e = esx.get(n.split('.')[0]);
      if (e && (d.kind === 'host' || d.kind === 'esxi')) Object.assign(r, { Model: e.Model || r.Model, OS: 'ESXi ' + e.Version });
      const c = cloud.get(String(d.host || '').toLowerCase());
      if (c) Object.assign(r, { Vendor: c.Provider, Model: c.Buckets + ' buckets · ' + c.Region, OS: '' });
      const x = disc.get(String(d.host || '').toLowerCase());
      if (x) r.MAC = x.MAC;
      return r;
    });
  }
  async function inventoryAll(t, el, only) {
    let tr;
    try { tr = await MC.api.monitor('tree'); } catch (e) { t.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; return; }
    if (!el.isConnected) return;
    let rows = resources(tr);
    if (only) rows = rows.filter((r) => r.Category === only);
    const cats = countBy(rows, (r) => r.Category), vend = countBy(rows.filter((r) => r.Vendor), (r) => r.Vendor);
    const bad = rows.filter((r) => r.State === 'Down').length, warn = rows.filter((r) => r.State === 'Warning').length;
    t.innerHTML = `<div class="kpis">${MC.kpi(only || 'Resources', rows.length, only ? '' : cats.length + ' categories')}${MC.kpi('Vendors', vend.length, vend[0] ? 'most: ' + vend[0][0] : '')}${MC.kpi('With problems', bad + warn, bad + ' down · ' + warn + ' warning', { alert: bad > 0 })}${MC.kpi('Without details', rows.filter((r) => !r.Model && !r.OS).length, 'no collector data yet')}</div>
      <div class="grid g3">${MC.panel(only ? 'Types' : 'Categories', '', '<div id="d1"></div>')}${MC.panel('Vendors', '', C.barList(vend.slice(0, 8).map(([k, n]) => ({ label: k, value: n, text: n, color: '--s1' })), { compact: true }))}${MC.panel('State', '', C.barList(countBy(rows, (r) => r.State).map(([k, n]) => ({ label: k, value: n, text: n, color: { Up: '--ok', Down: '--crit', Warning: '--warn' }[k] || '--muted' })), { compact: true }))}</div>
      ${MC.panel(only ? only + ' inventory' : 'All resources', 'every monitored device: Windows, Linux, network, storage, power, virtualization, databases, cloud and printers', '<div id="t1"></div>')}`;
    C.donut($('#d1', t), donutItems(only ? countBy(rows, (r) => r.Type) : cats, 6), { centerLabel: 'resources' });
    MC.table($('#t1', t), rows, [{ key: 'Name', label: 'Name', html: (r) => `<a href="#/device/${encodeURIComponent(r.id)}">${esc(r.Name)}</a>` }, { key: 'Category', label: 'Category' }, { key: 'Type', label: 'Type' }, { key: 'Address', label: 'IP / DNS name', cls: 'mono' }, { key: 'Vendor', label: 'Vendor' }, { key: 'Model', label: 'Model' }, { key: 'OS', label: 'OS / firmware / version' }, { key: 'Serial', label: 'Serial', cls: 'mono' }, { key: 'Group', label: 'Group' }, { key: 'State', label: 'State', html: (r) => pill(r.State) }], { name: 'inventory-' + (only || 'all').toLowerCase().replace(/\W+/g, '-') });
  }

  V.inventory = {
    title: 'Inventory',
    crumb: () => 'every monitored resource · ' + MC.data('inventory.hardware').length + ' servers · ' + MC.data('inventory.workstations').length + ' workstations · ' + MC.data('inventory.software').length + ' software installs',
    render(el, route) {
      const tab = route.tab || 'all';
      el.innerHTML = MC.tabs('inventory', [['all', 'All resources'], ['servers', 'Servers'], ['workstations', 'Workstations'], ['linux', 'Linux'], ['network', 'Network'], ['storage', 'Storage'], ['power', 'Power & hardware'], ['virtualization', 'Virtualization'], ['databases', 'Databases'], ['cloud', 'Cloud'], ['software', 'Software'], ['printers', 'Printers']], tab) + '<div id="tab" class="grid"></div>';
      const t = $('#tab', el);
      if (tab === 'all' || INV_TAB[tab]) { t.innerHTML = '<div class="muted">Loading…</div>'; inventoryAll(t, el, INV_TAB[tab]); return; }
      if (tab === 'servers') {
        const hw = MC.data('inventory.hardware');
        t.innerHTML = `<div class="kpis">${MC.kpi('Servers', hw.length, hw.filter((h) => h.MachineType === 'Virtual').length + ' virtual · ' + hw.filter((h) => h.MachineType === 'Physical').length + ' physical')}${MC.kpi('CPU cores', fmt(sum(hw.map((h) => h.CPUCores)), 0), fmt(sum(hw.map((h) => h.CPULogical)), 0) + ' logical')}${MC.kpi('Memory', fmt(sum(hw.map((h) => h.RAMGB)) / 1024) + ' TB', '')}${MC.kpi('TPM enabled', pct(hw.filter((h) => h.TPMEnabled).length, hw.length) + '%', '')}</div>
          <div class="grid g3">${MC.panel('Operating systems', '', '<div id="d1"></div>')}${MC.panel('Manufacturers', '', '<div id="d2"></div>')}${MC.panel('By site', '', C.barList(countBy(hw, (h) => h.ADSite).map(([k, n]) => ({ label: k, value: n, text: n, color: '--s1' })), { compact: true }))}</div>
          ${MC.panel('Server hardware', 'replaces 11 legacy hardware scripts', '<div id="t1"></div>', { act: `<button class="btn sm" ${MC.runAttr('inv.hardware', {})}>Collect now…</button>` })}`;
        C.donut($('#d1'), donutItems(countBy(hw, (h) => (h.OperatingSystem || '').replace('Microsoft Windows Server ', 'WS '))), { centerLabel: 'servers' });
        C.donut($('#d2'), donutItems(countBy(hw, (h) => h.Manufacturer)), { centerLabel: 'servers' });
        MC.table($('#t1'), hw, [{ key: 'Name', label: 'Server', html: (r) => host(r.Name) }, { key: 'OperatingSystem', label: 'OS' }, { key: 'OSBuild', label: 'Build' }, { key: 'Manufacturer', label: 'Vendor' }, { key: 'Model', label: 'Model' }, { key: 'SerialNumber', label: 'Serial', cls: 'mono' }, { key: 'CPUCores', label: 'Cores', n: true }, { key: 'RAMGB', label: 'RAM GB', n: true }, { key: 'MachineType', label: 'Type' }, { key: 'ADSite', label: 'Site' }, { key: 'IPAddress', label: 'IP', cls: 'mono' }, { key: 'Roles', label: 'Roles' }], { sort: 'Name', dir: 1, name: 'server-inventory' });
      } else if (tab === 'workstations') {
        const ws = MC.data('inventory.workstations');
        t.innerHTML = `<div class="kpis">${MC.kpi('Workstations', ws.length, ws.filter((w) => w.Online).length + ' online now')}${MC.kpi('Windows 11', pct(ws.filter((w) => /11/.test(w.OperatingSystem)).length, ws.length) + '%', '')}${MC.kpi('Unsupported OS', ws.filter((w) => /Windows (7|8)/.test(w.OperatingSystem)).length, '', { alert: ws.some((w) => /Windows (7|8)/.test(w.OperatingSystem)) })}${MC.kpi('TPM off', ws.filter((w) => !w.TPMEnabled).length, 'blocks BitLocker / Win 11')}${MC.kpi('Under 8 GB RAM', ws.filter((w) => w.RAMGB < 8).length, 'refresh candidates')}</div>
          <div class="grid g3">${MC.panel('Operating systems', '', '<div id="d1"></div>')}${MC.panel('Models', '', C.barList(countBy(ws, (w) => w.Model).slice(0, 8).map(([k, n]) => ({ label: k, value: n, text: n, color: '--s1' })), { compact: true }))}${MC.panel('By site', '', C.barList(countBy(ws, (w) => w.ADSite).map(([k, n]) => ({ label: k, value: n, text: n, color: '--s2' })), { compact: true }))}</div>
          ${MC.panel('Workstations', '', '<div id="t1"></div>', { act: `<button class="btn sm" ${MC.runAttr('inv.workstations', {})}>Collect now…</button>` })}`;
        C.donut($('#d1'), donutItems(countBy(ws, (w) => w.OperatingSystem)), { centerLabel: 'devices' });
        MC.table($('#t1'), ws, [{ key: 'Name', label: 'Name', html: (r) => `<a href="#" data-res="ws-${esc(r.Name)}">${esc(r.Name)}</a>` }, { key: 'OperatingSystem', label: 'OS' }, { key: 'Manufacturer', label: 'Vendor' }, { key: 'Model', label: 'Model' }, { key: 'CPUCores', label: 'Cores', n: true }, { key: 'RAMGB', label: 'RAM', n: true }, { key: 'TPMEnabled', label: 'TPM', html: (r) => (r.TPMEnabled ? 'Yes' : pill('Warning', 'No')) }, { key: 'LoggedOnUser', label: 'User' }, { key: 'ADSite', label: 'Site' }, { key: 'LastSeen', label: 'Last seen', html: (r) => ago(r.LastSeen) }], { name: 'workstations', q: route.q.q });
      } else if (tab === 'software') {
        const all = MC.data('inventory.software'), sum = (MC.ds['inventory.software'] || {}).summary || {};
        const plat = route.q && route.q.platform ? route.q.platform : 'all';
        const sw = plat === 'all' ? all : all.filter((s) => (s.Platform || 'Windows') === plat);
        const top = countBy(sw, (s) => s.Name);
        const machines = new Set(sw.map((s) => s.ComputerName));
        const versions = Object.entries(sw.reduce((a, s) => { (a[s.Name] = a[s.Name] || new Set()).add(s.Version); return a; }, {})).filter(([, v]) => v.size > 1).length;
        const unreach = (sum.unreachable || []).length;
        const chip = (id, label) => `<button class="btn sm ${plat === id ? 'primary' : 'ghost'}" data-href="#/inventory/software${id === 'all' ? '' : '?platform=' + id}">${esc(label)}</button>`;
        t.innerHTML = `<div class="actions-row" style="margin-bottom:10px">${chip('all', 'All')}${chip('Windows', 'Windows')}${chip('Linux', 'Linux')}<span style="flex:1"></span><button class="btn sm" ${MC.runAttr('inv.software', {})}>Collect now…</button></div>
          <div class="kpis">${MC.kpi('Installs', sw.length, 'registry, Microsoft Store and Linux packages')}${MC.kpi('Computers', machines.size, unreach ? unreach + ' could not be read' : 'servers, workstations and Linux', { alert: unreach > 0 })}${MC.kpi('Distinct products', top.length, '')}${MC.kpi('Version drift', versions, 'products with more than one version')}</div>
          <div class="grid g-1-2">${MC.panel('Most installed', '', C.barList(top.slice(0, 12).map(([k, n]) => ({ label: k, value: n, text: n, color: '--s1' })), { compact: true }))}${MC.panel('Installed software', 'Software inventory engine (inv.software): Windows from the uninstall registry keys (not Win32_Product, which can trigger repairs), Linux from dpkg, rpm, apk, pacman, snap and flatpak', '<div id="t1"></div>')}</div>`;
        MC.table($('#t1'), sw, [{ key: 'ComputerName', label: 'Computer', html: (r) => host(r.ComputerName) }, { key: 'Platform', label: 'Platform' }, { key: 'Name', label: 'Product' }, { key: 'Version', label: 'Version', cls: 'mono' }, { key: 'Vendor', label: 'Vendor' }, { key: 'Source', label: 'Source' }, { key: 'Architecture', label: 'Arch' },
          { key: 'act', label: '', noCsv: true, html: (r) => ((r.Platform || 'Windows') === 'Windows' && /^Registry/.test(r.Source || 'Registry') ? `<button class="btn sm ghost" ${MC.runAttr('act.software.remove', { ComputerName: r.ComputerName, Package: r.Name })}>Uninstall…</button>` : '') }], { name: 'software', q: route.q && route.q.q });
      } else {
        const p = MC.data('inventory.printers');
        t.innerHTML = `<div class="kpis">${MC.kpi('Printers', p.length, '')}${MC.kpi('Shared', p.filter((x) => x.Shared).length, '')}${MC.kpi('Published in AD', p.filter((x) => x.Published).length, '')}${MC.kpi('Drivers', countBy(p, (x) => x.Driver).length, 'distinct')}</div>
          <div class="grid g-1-2">${MC.panel('Drivers', '', C.barList(countBy(p, (x) => x.Driver).map(([k, n]) => ({ label: k, value: n, text: n, color: '--s1' })), { compact: true }))}${MC.panel('Printers', '', '<div id="t1"></div>')}</div>`;
        MC.table($('#t1'), p, [{ key: 'Name', label: 'Printer', html: (r) => `<a href="#" data-res="prt-${esc(r.Name)}">${esc(r.Name)}</a>` }, { key: 'PrintServer', label: 'Server' }, { key: 'ShareName', label: 'Share' }, { key: 'Model', label: 'Model' }, { key: 'IPAddress', label: 'IP', cls: 'mono' }, { key: 'Location', label: 'Location' }, { key: 'Status', label: 'Status' }], { name: 'printers' });
      }
    },
  };

  // ================================================================== UPDATES (Windows and Linux, against the newest release online)
  V.osupdates = {
    title: 'OS updates',
    crumb: () => 'Windows builds and Linux releases compared with the newest release online · pending and security updates · support end',
    async render(el, route) {
      const OSR = root.MCOSReleases;
      const tab = route.tab || 'all';
      el.innerHTML = '<div class="muted">Loading…</div>';
      let cat;
      try { cat = await MC.api.osReleases(); } catch (e) { cat = OSR.merge(null); cat.error = e.message; }
      if (!el.isConnected) return;
      const all = OSR.assessAll(MC.data('updates.status'), cat);
      const out = all.filter((r) => r.Supported === false), behind = all.filter((r) => r.Behind), sec = all.filter((r) => r.PendingSecurity > 0), reboot = all.filter((r) => r.RebootPending);
      const ok = all.filter((r) => r.UpdateState === 'OK');
      const list = { windows: all.filter((r) => r.Platform === 'Windows'), linux: all.filter((r) => r.Platform === 'Linux'), behind, unsupported: out, security: sec }[tab] || all;
      const byRel = {};
      for (const r of all) { const k = r.Family || 'other:' + (r.OS || '?'); (byRel[k] = byRel[k] || { rel: r.Release || r.OS, fam: r.Family, n: 0, behind: 0, cur: [] }); byRel[k].n++; if (r.Behind) byRel[k].behind++; byRel[k].cur.push(r.Current); }
      const famRows = Object.values(byRel).map((x) => { const c = x.fam ? cat.families[x.fam] : null; const left = c && c.ends ? Math.floor((Date.parse(c.ends) - Date.now()) / 864e5) : null; return { Release: x.rel, Platform: c ? c.platform : '', Machines: x.n, Newest: (c && c.latest) || '', From: c && c.latest ? c.source || 'online' : 'newest in your fleet', Behind: x.behind, SupportEnds: c ? c.ends : '', DaysLeft: left }; }).sort((a, b) => (a.DaysLeft == null ? 1e9 : a.DaysLeft) - (b.DaysLeft == null ? 1e9 : b.DaysLeft));
      const admin = MC.user && MC.user.role === 'admin';
      el.innerHTML = `<div class="kpis">${MC.kpi('Machines', all.length, list.length !== all.length ? list.length + ' shown' : all.filter((r) => r.Platform === 'Windows').length + ' Windows · ' + all.filter((r) => r.Platform === 'Linux').length + ' Linux')}${MC.kpi('Up to date', pct(ok.length, all.length) + '%', ok.length + ' machines')}${MC.kpi('Behind the newest release', behind.length, 'newer build or point release available', { alert: behind.length > 0, href: '#/osupdates/behind' })}${MC.kpi('Security updates waiting', sec.length, sum(sec.map((r) => r.PendingSecurity)) + ' updates', { alert: sec.length > 0, href: '#/osupdates/security' })}${MC.kpi('Out of support', out.length, 'no security fixes any more', { alert: out.length > 0, href: '#/osupdates/unsupported' })}${MC.kpi('Restart pending', reboot.length, '')}</div>
        <div class="grid g3">${MC.panel('Update state', '', '<div id="u1"></div>')}${MC.panel('Behind the newest release', 'machines per release', C.barList(famRows.filter((x) => x.Behind).sort((a, b) => b.Behind - a.Behind).slice(0, 8).map((x) => ({ label: x.Release, value: x.Behind, text: x.Behind + ' of ' + x.Machines, color: '--warn' })), { compact: true }) || '<p class="muted">Every machine runs the newest known build.</p>')}${MC.panel('Support ends', 'nearest first', C.barList(famRows.filter((x) => x.DaysLeft != null).slice(0, 8).map((x) => ({ label: x.Release, value: Math.max(1, 3650 - Math.max(0, x.DaysLeft)), text: x.DaysLeft < 0 ? 'ended' : x.DaysLeft < 730 ? Math.round(x.DaysLeft / 30.4) + ' mo' : Math.round(x.DaysLeft / 365) + ' yr', color: x.DaysLeft < 0 ? '--crit' : x.DaysLeft < 180 ? '--warn' : '--ok' })), { compact: true }))}</div>
        ${MC.panel('Releases and the newest updates', cat.checked ? 'checked ' + ago(cat.checked) + ' · ' + cat.source : 'not checked online yet: machines are compared with the newest build in your fleet', '<div id="u2"></div>', { act: (admin ? '<button class="btn sm" id="uChk">' + icon('refresh', 'sev-ico') + 'Check online now</button>' : '') })}
        ${cat.error ? `<div class="notice warn">The last online check had problems: ${esc(cat.error)}. The last good answer and the built-in release list are used.</div>` : ''}
        ${MC.tabs('osupdates', [['all', 'All machines'], ['windows', 'Windows'], ['linux', 'Linux'], ['behind', 'Behind', behind.length ? { s: 'Warning', n: behind.length } : null], ['security', 'Security updates', sec.length ? { s: 'Critical', n: sec.length } : null], ['unsupported', 'Out of support', out.length ? { s: 'Critical', n: out.length } : null]], tab)}
        ${MC.panel('Machines', 'from the OS updates collector (Windows over WinRM, Linux over SSH)', '<div id="u3"></div>', { act: `<button class="btn sm" ${MC.runAttr('mon.os.updates', {})}>Collect now…</button>` })}`;
      C.donut($('#u1', el), [{ label: 'Up to date', value: ok.length, color: '--ok' }, { label: 'Warning', value: all.filter((r) => r.UpdateState === 'Warning').length, color: '--warn' }, { label: 'Critical', value: all.filter((r) => r.UpdateState === 'Critical').length, color: '--crit' }, { label: 'Unknown', value: all.filter((r) => r.UpdateState === 'Unknown').length, color: '--muted' }], { centerLabel: 'machines' });
      MC.table($('#u2', el), famRows, [{ key: 'Release', label: 'Release' }, { key: 'Platform', label: 'Platform' }, { key: 'Machines', label: 'Machines', n: true }, { key: 'Newest', label: 'Newest build / release', cls: 'mono' }, { key: 'From', label: 'Source' }, { key: 'Behind', label: 'Behind', n: true }, { key: 'SupportEnds', label: 'Support ends', html: (r) => r.SupportEnds ? `${esc(r.SupportEnds)} ${r.DaysLeft < 0 ? pill('Critical', 'ended') : r.DaysLeft < 180 ? pill('Warning', r.DaysLeft + ' days') : ''}` : '' }], { name: 'os-releases', search: false });
      MC.table($('#u3', el), list, [{ key: 'Name', label: 'Machine', html: (r) => host(r.Name) }, { key: 'Platform', label: 'Platform' }, { key: 'Release', label: 'Release', html: (r) => `<span style="white-space:nowrap">${esc(r.Release || '')}</span>` }, { key: 'Current', label: 'Build / release', cls: 'mono' }, { key: 'Latest', label: 'Newest', cls: 'mono', html: (r) => r.Latest ? (r.Behind ? `<b>${esc(r.Latest)}</b>` : esc(r.Latest)) : '' }, { key: 'PendingUpdates', label: 'Pending', n: true }, { key: 'PendingSecurity', label: 'Security', n: true }, { key: 'DaysSinceUpdate', label: 'Days since update', n: true }, { key: 'RebootPending', label: 'Restart', html: (r) => (r.RebootPending ? pill('Warning', 'pending') : '') }, { key: 'SupportEnds', label: 'Support ends' }, { key: 'UpdateState', label: 'State', html: (r) => pill(r.UpdateState) }, { key: 'UpdateProblems', label: 'Findings', html: (r) => `<div class="muted" style="font-size:12px;min-width:300px">${esc((r.UpdateProblems || []).join('; '))}</div>` }], { name: 'os-updates-' + tab });
      if ($('#uChk', el)) $('#uChk', el).addEventListener('click', async (e) => { e.target.disabled = true; try { const c = await MC.api.refreshOsReleases(); MC.toast(c.error ? 'Checked, with problems: ' + esc(c.error.slice(0, 120)) : 'Newest releases checked online', c.error ? 'warn' : 'ok'); V.osupdates.render(el, route); } catch (x) { MC.toast(esc(x.message), 'err'); e.target.disabled = false; } });
    },
  };

  // ================================================================== AUDIT
  V.audit = {
    title: 'Audit',
    crumb: () => 'Security event log collected from domain controllers, NPS, file and print servers, and the devices you add',
    render(el, route) {
      const hours = +(route.q.h || 24);
      const set = route.q.set || '';
      const src = route.q.src || '';
      // devices added by hand that can be audit sources: Windows (event logs read over WinRM by the audit collector)
      const short = (n) => String(n || '').split('.')[0].toUpperCase();
      const mine = (MC.devices || []).filter((d) => d.origin !== 'engine' && d.origin !== 'integration' && root.MCRemote && root.MCRemote.languagesFor(d).includes('PowerShell'));
      const mineNames = new Set(mine.flatMap((d) => [short(d.name), short(d.host)]).filter(Boolean));
      const all = MC.data('audit.events').filter((e) => !src || (src === 'manual') === mineNames.has(short(e.Server)));
      const ev = all.filter((e) => Date.now() - Date.parse(e.Time) < hours * 36e5);
      const list = set ? ev.filter((e) => e.EventSet === set) : ev;
      const sets = countBy(ev, (e) => e.EventSet);
      const fails = ev.filter((e) => e.EventSet === 'BadLogon' || e.EventSet === 'KerberosPreAuthFailed');
      el.innerHTML = `
        <div class="toolbar"><div class="seg" id="hrs">${[[24, '24 hours'], [72, '3 days'], [168, '7 days']].map(([h, t]) => `<button data-h="${h}" class="${h === hours ? 'on' : ''}">${t}</button>`).join('')}</div>
          <div class="seg" id="audSrc" aria-label="Source">${[['', 'All sources'], ['engine', 'Found by engines'], ['manual', 'Manually added']].map(([k, t]) => `<button data-v="${k}" class="${k === src ? 'on' : ''}">${t}</button>`).join('')}</div>
          <select class="input" id="setSel" aria-label="Event set"><option value="">All event sets (${ev.length})</option>${sets.map(([k, n]) => `<option value="${esc(k)}" ${k === set ? 'selected' : ''}>${esc(k)} (${n})</option>`).join('')}</select>
          <span style="flex:1"></span><button class="btn sm" ${MC.runAttr('aud.lockout', { Days: 1 })}>Lockout investigation…</button><button class="btn sm" ${MC.runAttr('aud.events', { Hours: 1 })}>Collect now…</button></div>
        <div class="kpis">${MC.kpi('Events', fmt(list.length, 0), set || 'all sets')}${MC.kpi('Failed sign-ins', fails.length, new Set(fails.map((e) => e.Target)).size + ' accounts', { alert: fails.length > 50 })}${MC.kpi('Lockouts', ev.filter((e) => e.EventSet === 'Lockout').length, new Set(ev.filter((e) => e.EventSet === 'Lockout').map((e) => e.Target)).size + ' accounts')}${MC.kpi('Privileged changes', ev.filter((e) => e.Privileged).length, 'admin groups', { alert: ev.some((e) => e.Privileged) })}${MC.kpi('Critical', ev.filter((e) => e.Severity === 'Critical').length, '')}</div>
        ${MC.panel('Manually added audit sources', mine.length ? mine.filter((d) => d.audit).length + ' of ' + mine.length + ' Windows devices added by hand are audited · the engines audit the domain controllers, NPS, file and print servers they find' : 'Windows devices you add by hand can be audited here', '<div id="audMine"></div>', { act: mine.length ? '<a class="btn sm ghost" href="#/audit?h=' + hours + '&src=manual">Show their events</a>' : '' })}
        ${MC.panel('Activity over time', 'click a column to filter the table', '<div id="cols"></div>')}
        <div class="grid g3">
          ${MC.panel('Failed sign-ins by account', '', C.barList(countBy(fails, (e) => e.Target).slice(0, 8).map(([k, n]) => ({ label: k, value: n, text: n, color: '--s3' })), { compact: true }))}
          ${MC.panel('Failed sign-ins by source', 'workstation or IP', C.barList(countBy(fails, (e) => e.Workstation || e.SourceIP).slice(0, 8).map(([k, n]) => ({ label: k, value: n, text: n, color: '--s3' })), { compact: true }))}
          ${MC.panel('Event sets', '', C.barList(sets.slice(0, 8).map(([k, n]) => ({ label: k, value: n, text: n, color: '--s1', href: '#/audit?h=' + hours + '&set=' + k })), { compact: true }))}
        </div>
        ${MC.panel('Events', 'replaces 21 legacy audit scripts; fields read by name from the event XML', '<div id="et"></div>')}`;
      $$('#hrs button', el).forEach((b) => b.addEventListener('click', () => MC.go('audit', null, { h: b.dataset.h, set, src })));
      $('#setSel').addEventListener('change', (e) => MC.go('audit', null, { h: hours, set: e.target.value, src }));
      $$('#audSrc button', el).forEach((b) => b.addEventListener('click', () => MC.go('audit', null, { h: hours, set, src: b.dataset.v })));
      auditSources($('#audMine', el), mine, short);
      let tbl;
      MC.auditColumns($('#cols'), list, hours, (b) => tbl.setRows(list.filter((e) => { const t = Date.parse(e.Time); return t >= b.start && t < b.end; })));
      tbl = MC.table($('#et'), list, [
        { key: 'Time', label: 'Time', html: (r) => dt(r.Time), val: (r) => r.Time },
        { key: 'Severity', label: 'Sev', html: (r) => pill(r.Severity === 'Info' ? 'Info' : r.Severity, r.Severity) },
        { key: 'Title', label: 'Event' }, { key: 'EventId', label: 'ID', n: true },
        { key: 'Target', label: 'Target', html: (r) => esc(String(r.Target || '').replace(/^CN=([^,]+).*/, '$1')) },
        { key: 'Actor', label: 'By' }, { key: 'Group', label: 'Group' }, { key: 'Workstation', label: 'Source', val: (r) => r.Workstation || r.SourceIP }, { key: 'Server', label: 'Server' }, { key: 'Reason', label: 'Detail', val: (r) => r.Reason || r.Value || r.Attribute },
      ], { sort: 'Time', name: 'audit-events' });
    },
  };

  // Manually added audit sources: Windows devices onboarded by hand whose event logs the audit collector reads. "Audited" keeps
  // them in the collector's schedule (with the engines' targets); "Collect now" reads them once and merges their rows.
  const AUD_SETS = [['', 'All event sets'], ['BadLogon', 'Failed logons'], ['RemoteLogon', 'Remote desktop logons'], ['ShutdownRestart', 'Shutdown / restart'], ['FileAccess', 'File share access'], ['FileModify', 'File writes'], ['FileDelete', 'File deletes'], ['FilePermission', 'Permission changes'], ['PrintJob', 'Print jobs']];
  function auditSources(box, mine, short) {
    if (!box) return;
    if (!mine.length) { box.innerHTML = `<div class="empty muted">No Windows devices were added by hand yet. <a href="#/monitoring">Add a device</a> (server or workstation) and it can be audited here.</div>`; return; }
    const counts = MC.data('audit.events').reduce((a, e) => { const k = short(e.Server); a[k] = a[k] || { n: 0, last: null }; a[k].n++; if (!a[k].last || e.Time > a[k].last) a[k].last = e.Time; return a; }, {});
    const stat = (d) => counts[short(d.name)] || counts[short(d.host)] || { n: 0, last: null };
    box.innerHTML = `<div class="toolbar" style="margin-bottom:8px">
        <select class="input" id="audSets" aria-label="Event sets to collect">${AUD_SETS.map(([k, t]) => `<option value="${k}">${t}</option>`).join('')}</select>
        <select class="input" id="audDays" aria-label="Period">${[[1, 'Last day'], [3, 'Last 3 days'], [7, 'Last 7 days']].map(([k, t]) => `<option value="${k}">${t}</option>`).join('')}</select>
        <span style="flex:1"></span><span class="muted" id="audSel">0 selected</span><button class="btn sm primary" id="audGo" disabled>Collect now</button></div><div id="audT"></div>`;
    const sel = new Set();
    const upd = () => { $('#audSel', box).textContent = sel.size + ' selected'; $('#audGo', box).disabled = !sel.size; };
    MC.table($('#audT', box), mine, [
      { key: 'pick', label: '', noCsv: true, html: (d) => `<input type="checkbox" data-pick="${esc(d.id)}" aria-label="Select ${esc(d.name)}">` },
      { key: 'name', label: 'Device', html: (d) => `<a href="#/device/${encodeURIComponent(d.id)}">${esc(d.name)}</a>` },
      { key: 'host', label: 'Address', html: (d) => `<span class="mono">${esc(d.host || '')}</span>` },
      { key: 'kind', label: 'Kind' },
      { key: 'origin', label: 'Added', html: (d) => esc(({ manual: 'by hand', discovery: 'auto-discovery', import: 'import' })[d.origin] || d.origin), val: (d) => ({ manual: 'by hand', discovery: 'auto-discovery', import: 'import' })[d.origin] || d.origin },
      { key: 'events', label: 'Events', n: true, html: (d) => fmt(stat(d).n, 0), val: (d) => stat(d).n },
      { key: 'last', label: 'Latest event', html: (d) => (stat(d).last ? ago(stat(d).last) : '<span class="muted">none yet</span>'), val: (d) => stat(d).last || '' },
      { key: 'audit', label: 'Audited on schedule', html: (d) => `<label style="display:inline-flex;gap:6px;align-items:center"><input type="checkbox" data-aud="${esc(d.id)}" ${d.audit ? 'checked' : ''}> ${d.audit ? 'Yes' : 'No'}</label>`, val: (d) => (d.audit ? 'Yes' : 'No') },
    ], { sort: 'name', name: 'audit-sources' });
    box.addEventListener('change', async (e) => {
      const p = e.target.closest('[data-pick]'), a = e.target.closest('[data-aud]');
      if (p) { if (p.checked) sel.add(p.dataset.pick); else sel.delete(p.dataset.pick); upd(); }
      if (a) {
        const d = mine.find((x) => x.id === a.dataset.aud), on = a.checked;
        try {
          await MC.api.monitor('setDevice', { id: d.id, audit: on });
          d.audit = on;
          if (on) await MC.api.auditCollect([d.id], { days: 1 });
          MC.toast(on ? d.name + ' is audited: events collected now and on the audit schedule' : d.name + ' is no longer audited (its collected events stay)', 'ok');
          await MC.refreshDatasets(0); MC.render();
        } catch (err) { a.checked = !on; MC.toast(esc(err.message), 'err'); }
      }
    });
    $('#audGo', box).addEventListener('click', async () => {
      const b = $('#audGo', box); b.disabled = true; b.textContent = 'Collecting…';
      const sets = $('#audSets', box).value;
      try {
        const r = await MC.api.auditCollect([...sel], { sets: sets ? [sets] : [], days: +$('#audDays', box).value });
        MC.toast(r.job && r.job.state === 'done' ? 'Audit events collected from ' + r.devices.length + ' device(s)' : 'Audit collection started for ' + r.devices.length + ' device(s); their events join the table when it finishes', 'ok');
        await MC.refreshDatasets(r.job && r.job.state === 'done' ? 0 : 6000); if (/^#\/audit/.test(location.hash)) MC.render();
      } catch (err) { MC.toast(esc(err.message), 'err'); b.disabled = false; b.textContent = 'Collect now'; }
    });
  }

  // ================================================================== SECURITY
  V.security = {
    title: 'Security',
    crumb: () => 'Defender, patching, exposure, local admins and file share permissions',
    render(el, route) {
      const tab = route.tab || 'posture';
      el.innerHTML = MC.tabs('security', [['posture', 'Posture'], ['defender', 'Defender'], ['patches', 'Patching'], ['exposure', 'Exposure'], ['admins', 'Local admins'], ['fileacl', 'File shares'], ['vuln', 'Vulnerability scan']], tab) + '<div id="tab" class="grid"></div>';
      (SEC[tab] || SEC.posture)($('#tab', el), route);
    },
  };
  const SEC = {};
  SEC.posture = (el) => {
    const def = MC.data('security.defender'), pat = MC.data('security.patches').filter((p) => p.Status !== 'Unreachable'), fw = MC.data('security.firewall');
    const ins = MC.model.insights.filter((i) => i.area === 'Security' || i.area === 'Patching' || i.area === 'Identity');
    el.innerHTML = `<div class="kpis">${MC.kpi('Defender healthy', pct(def.filter((d) => d.Status === 'OK').length, def.length) + '%', def.filter((d) => (d.Detections || []).length).length + ' with detections', { alert: def.some((d) => d.Status === 'Critical'), href: '#/security/defender' })}${MC.kpi('Patched in 35 days', pct(pat.filter((p) => p.DaysSincePatch <= 35).length, pat.length) + '%', pat.filter((p) => p.PendingReboot).length + ' reboots pending', { href: '#/security/patches' })}${MC.kpi('Firewall off', fw.filter((f) => !(f.Domain && f.Private && f.Public)).length, 'servers with a profile disabled', { alert: fw.some((f) => !f.Domain), href: '#/security/exposure' })}${MC.kpi('SMBv1 enabled', fw.filter((f) => f.SMB1).length, '', { alert: fw.some((f) => f.SMB1) })}${MC.kpi('RDP without NLA', fw.filter((f) => f.RDPEnabled && !f.NLA).length, '')}${MC.kpi('Risky share ACLs', MC.data('security.fileacl').filter((a) => a.Risky).length, '', { href: '#/security/fileacl' })}</div>
      <div class="grid g-2-1">${MC.panel('Security findings', ins.length + ' open', `<div class="insights">${ins.map(MC.insightRow).join('') || '<div class="muted">No findings.</div>'}</div>`)}
      <div class="grid">${MC.panel('Days since last patch', 'servers', '<div id="patCols"></div>')}${MC.panel('Defender signature age', '', '<div id="sigD"></div>')}</div></div>`;
    const bands = [[0, 15, '0–14'], [15, 35, '15–34'], [35, 60, '35–59'], [60, 1e9, '60+']];
    C.columns($('#patCols'), bands.map(([a, b, l]) => ({ label: l, title: l + ' days', values: { v: pat.filter((p) => p.DaysSincePatch >= a && p.DaysSincePatch < b).length } })), [{ key: 'v', name: 'Servers', color: '--s1' }], { height: 150 });
    C.donut($('#sigD'), [{ label: 'Today', value: def.filter((d) => d.SignatureAgeDays === 0).length, color: '--ok' }, { label: '1–3 days', value: def.filter((d) => d.SignatureAgeDays > 0 && d.SignatureAgeDays <= 3).length, color: '--s1' }, { label: 'Older', value: def.filter((d) => d.SignatureAgeDays > 3).length, color: '--warn' }], { centerLabel: 'servers', size: 120 });
  };
  SEC.defender = (el) => {
    const def = MC.data('security.defender');
    const det = def.flatMap((d) => (d.Detections || []).map((x) => Object.assign({ ComputerName: d.ComputerName }, x)));
    el.innerHTML = `${MC.panel('Detections', det.length + ' threats', '<div id="dt1"></div>')}${MC.panel('Protection status', '', '<div id="dt2"></div>', { act: `<button class="btn sm" ${MC.runAttr('sec.defender', {})}>Collect now…</button>` })}`;
    MC.table($('#dt1'), det, [{ key: 'Detected', label: 'When', html: (r) => dt(r.Detected) }, { key: 'ComputerName', label: 'Server', html: (r) => host(r.ComputerName) }, { key: 'Threat', label: 'Threat' }, { key: 'Severity', label: 'Severity', html: (r) => pill(r.Severity === 'High' || r.Severity === 'Severe' ? 'Critical' : 'Warning', r.Severity) }, { key: 'Resources', label: 'Path', html: (r) => `<span class="mono">${esc(String(r.Resources).replace(/^file:_/, ''))}</span>` }, { key: 'User', label: 'User' }, { key: 'act', label: '', noCsv: true, html: (r) => `<button class="btn sm danger" ${MC.runAttr('act.isolate', { ComputerName: r.ComputerName, Mode: 'Isolate' })}>Isolate…</button>` }], { search: false, empty: 'No detections.' });
    MC.table($('#dt2'), def, [{ key: 'ComputerName', label: 'Server', html: (r) => host(r.ComputerName) }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }, { key: 'RealTime', label: 'Real-time', html: (r) => (r.RealTime ? 'On' : pill('Critical', 'Off')) }, { key: 'Tamper', label: 'Tamper', html: (r) => (r.Tamper ? 'On' : 'Off') }, { key: 'SignatureAgeDays', label: 'Sig age d', n: true }, { key: 'LastQuickScan', label: 'Quick scan', html: (r) => ago(r.LastQuickScan) }, { key: 'LastFullScan', label: 'Full scan', html: (r) => ago(r.LastFullScan) }, { key: 'EngineVersion', label: 'Engine', cls: 'mono' }], { sort: 'Status', dir: -1, name: 'defender' });
  };
  SEC.patches = (el) => {
    const p = MC.data('security.patches');
    el.innerHTML = `${MC.panel('Patch age', 'oldest first', C.barList(p.filter((x) => x.Status !== 'Unreachable').sort((a, b) => b.DaysSincePatch - a.DaysSincePatch).slice(0, 12).map((x) => ({ label: x.ComputerName, sub: x.LastKB, value: x.DaysSincePatch, text: x.DaysSincePatch + ' d', status: x.Status !== 'OK' ? x.Status : null, color: '--s1' })), {}))}${MC.panel('Servers', '', '<div id="pt"></div>')}`;
    MC.table($('#pt'), p, [{ key: 'ComputerName', label: 'Server', html: (r) => host(r.ComputerName) }, { key: 'OS', label: 'OS' }, { key: 'LastPatched', label: 'Last patched', html: (r) => dt(r.LastPatched) }, { key: 'DaysSincePatch', label: 'Days', n: true }, { key: 'LastKB', label: 'Last KB', cls: 'mono' }, { key: 'PendingUpdates', label: 'Pending', n: true }, { key: 'PendingReboot', label: 'Reboot', html: (r) => (r.PendingReboot ? pill('Info', 'pending') : '') }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status === 'Unreachable' ? 'Unknown' : r.Status, r.Status) }, { key: 'act', label: '', noCsv: true, html: (r) => `<button class="btn sm ghost" ${MC.runAttr('act.windowsupdate', { ComputerName: r.ComputerName, Mode: 'Scan' })}>Updates…</button>` }], { sort: 'DaysSincePatch', name: 'patches' });
  };
  SEC.exposure = (el) => {
    const fw = MC.data('security.firewall');
    const yes = (v, bad) => (v ? (bad ? pill('Warning', 'Yes') : 'Yes') : bad ? 'No' : pill('Critical', 'No'));
    el.innerHTML = MC.panel('Firewall, RDP and SMB exposure', '', '<div id="ft"></div>', { act: `<button class="btn sm" ${MC.runAttr('sec.firewall', {})}>Collect now…</button>` });
    MC.table($('#ft'), fw, [{ key: 'ComputerName', label: 'Server', html: (r) => host(r.ComputerName) }, { key: 'Domain', label: 'Domain FW', html: (r) => yes(r.Domain) }, { key: 'Private', label: 'Private FW', html: (r) => yes(r.Private) }, { key: 'Public', label: 'Public FW', html: (r) => yes(r.Public) }, { key: 'RDPEnabled', label: 'RDP', html: (r) => (r.RDPEnabled ? 'On' : 'Off') }, { key: 'NLA', label: 'NLA', html: (r) => (!r.RDPEnabled ? '–' : yes(r.NLA)) }, { key: 'SMB1', label: 'SMBv1', html: (r) => yes(r.SMB1, true) }, { key: 'Issues', label: 'Issues' }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }, { key: 'act', label: '', noCsv: true, html: (r) => (!(r.Domain && r.Private && r.Public) ? `<button class="btn sm" ${MC.runAttr('act.firewall', { ComputerName: r.ComputerName, State: 'Enable' })}>Enable FW…</button>` : r.RDPEnabled && !r.NLA ? `<button class="btn sm" ${MC.runAttr('act.rdp', { ComputerName: r.ComputerName, State: 'Enable' })}>Enforce NLA…</button>` : '') }], { sort: 'Status', dir: -1, name: 'exposure' });
  };
  SEC.admins = (el) => {
    const a = MC.data('security.localadmins');
    const std = /\\(Administrator|Domain Admins|Enterprise Admins)$/i;
    el.innerHTML = `<div class="grid g-1-2">${MC.panel('Most common members', '', C.barList(countBy(a, (x) => x.Member).slice(0, 10).map(([k, n]) => ({ label: k, value: n, text: n, color: std.test(k) ? '--s1' : '--s3' })), { compact: true }))}${MC.panel('Local Administrators group', 'non-standard members highlighted', '<div id="lat"></div>')}</div>`;
    MC.table($('#lat'), a, [{ key: 'ComputerName', label: 'Server', html: (r) => host(r.ComputerName) }, { key: 'Member', label: 'Member', html: (r) => (std.test(r.Member) ? esc(r.Member) : `<b style="color:var(--warn-ink)">${esc(r.Member)}</b>`) }, { key: 'Class', label: 'Class' }, { key: 'Source', label: 'Source' }, { key: 'act', label: '', noCsv: true, html: (r) => (/\\Administrator$/i.test(r.Member) && r.Source === 'Local' ? `<button class="btn sm ghost" ${MC.runAttr('act.localadmin.reset', { ComputerName: r.ComputerName })}>Reset password…</button>` : '') }], { name: 'local-admins' });
  };
  SEC.fileacl = (el) => {
    const a = MC.data('security.fileacl');
    el.innerHTML = MC.panel('Share permissions', a.filter((x) => x.Risky).length + ' risky entries · ' + a.filter((x) => x.OrphanedSid).length + ' orphaned SIDs', '<div id="fat"></div>', { act: `<button class="btn sm" ${MC.runAttr('mon.fileserver.acl', {})}>Collect now…</button>` });
    MC.table($('#fat'), a, [{ key: 'ComputerName', label: 'Server', html: (r) => host(r.ComputerName) }, { key: 'Share', label: 'Share' }, { key: 'Path', label: 'Path', cls: 'mono' }, { key: 'Identity', label: 'Identity' }, { key: 'Rights', label: 'Rights' }, { key: 'Type', label: 'Type' }, { key: 'InheritanceBroken', label: 'Inheritance', html: (r) => (r.InheritanceBroken ? 'Broken' : 'Inherited') }, { key: 'Risky', label: 'Risk', html: (r) => (r.Risky ? pill('Warning', 'Broad write') : r.OrphanedSid ? pill('Info', 'Orphaned SID') : '') }], { sort: 'Risky', name: 'file-acl' });
  };
  SEC.vuln = (el) => {
    const s = MC.script('sec.vulnscan');
    el.innerHTML = MC.panel('Vulnerability scan', 'native scanner built into MonCastle: no extra software to install', `<p class="muted" style="margin-top:0">${esc(s ? s.synopsis : '')} Each finding has a severity, the evidence and how to fix it: cleartext and exposed services, outdated server versions, TLS 1.0/1.1, expired or self-signed certificates, SMBv1 and missing HTTP security headers. Scanning is on demand only, because a scan can trip IDS alerts.</p><button class="btn primary" ${MC.runAttr('sec.vulnscan', {})}>${icon('play', 'sev-ico')}Start a scan…</button>`);
  };

  // Actions & jobs: views-jobs.js

  // Script library: now Actions › Remote scripting (views-remote.js)


  // ================================================================== MONITORING ENGINES
  // One engine per collector: on Windows each one is a scheduled task under
  // \RoboMate\MonCastle\Engines\ that keeps running when the console is closed; otherwise the console scheduler runs it.
  // the system an engine needs (AD users -> Active Directory), from its script's id and resource
  const engineSystem = (id, meta) => (root.MCEngineInfo ? root.MCEngineInfo.system(meta && meta.id ? meta : ((MC.manifest || {}).scripts || []).find((x) => x.id === id) || { id }) : '');
  const ENGINE_STATE = { Ready: ['OK', 'Ready'], Running: ['Running', 'Running'], Disabled: ['Disabled', 'Disabled'], 'Not configured': ['Unknown', 'Not configured'] };
  const engOff = (e) => e.state === 'Disabled' || e.state === 'Not configured';
  const engFam = (id) => (root.MCEngineScope ? root.MCEngineScope.familyOf(((MC.manifest || {}).scripts || []).find((x) => x.id === id) || { id }) : null);
  const enginePill = (st) => { const [c, t] = ENGINE_STATE[st] || ['Unknown', st || 'Unknown']; return pill(c, t); };
  const engineResult = (r) => (r.lastStatus ? `<span title="${esc(r.message || '')}">${pill(r.lastStatus === 'ok' ? 'OK' : r.lastStatus === 'warning' ? 'Warning' : r.lastStatus === 'skipped' ? 'Unknown' : 'Critical', r.lastStatus === 'ok' ? 'OK' : r.lastStatus)}</span>` : '<span class="muted">Not run yet</span>');
  const until = (t) => { if (!t) return '–'; const m = Math.round((Date.parse(t) - Date.now()) / 6e4); return m <= 0 ? 'due now' : m < 60 ? 'in ' + m + ' min' : m < 1440 ? 'in ' + Math.round(m / 60) + ' h' : 'in ' + Math.round(m / 1440) + ' d'; };
  V.engines = {
    title: 'Monitoring engines',
    crumb: () => (MC.route.tab ? 'engine › general, permissions, utilization and results' : 'collectors that keep the console data fresh'),
    render(el, route) {
      clearInterval(V.engines._t);
      if (route && route.tab) return engineInfo(el, decodeURIComponent(route.tab), (route.q || {}).view || 'general');
      el.innerHTML = '<div class="notice">Loading engines…</div>';
      const admin = MC.user.role === 'admin';
      const act = async (action, id, every, okMsg) => {
        if (!admin) return MC.toast('Only administrators can control engines.', 'err');
        try { const r = await MC.api.engineAction(action, id, every); draw(r); MC.toast(okMsg, 'ok'); } catch (e) { MC.toast(esc(e.message), 'err'); }
      };
      const confirmAct = (title, text, label, danger, run) => modal(`<h3>${esc(title)}</h3><p class="muted">${text}</p><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn ${danger ? 'danger' : 'primary'}" id="go">${esc(label)}</button></div>`, (m, close) => {
        $('#go', m).addEventListener('click', async () => { $('#go', m).disabled = true; await run(); close(); });
      });
      const draw = (d) => {
        if (!document.body.contains(el)) return clearInterval(V.engines._t);
        const list = d.engines || [];
        const by = (st) => list.filter((e) => e.state === st).length;
        const running = by('Running'), disabled = by('Disabled'), notConf = by('Not configured'), enabled = list.length - disabled - notConf;
        const failing = list.filter((e) => !engOff(e) && e.lastStatus === 'error');
        const warn = list.filter((e) => !engOff(e) && e.lastStatus === 'warning');
        const tasks = d.host === 'windows' && d.tasksInstalled;
        const where = tasks ? `Windows Task Scheduler · <span class="mono">${esc(d.taskPath)}</span>` : 'Console scheduler (runs while the console is open)';
        const cats = countBy(list, (e) => e.category).map(([cat]) => {
          const g = list.filter((e) => (e.category || 'Unknown') === cat);
          const counts = { OK: g.filter((e) => !engOff(e) && (e.lastStatus === 'ok' || !e.lastStatus)).length, Warning: g.filter((e) => !engOff(e) && e.lastStatus === 'warning').length, Critical: g.filter((e) => !engOff(e) && (e.lastStatus === 'error' || e.lastStatus === 'skipped')).length, Unknown: g.filter(engOff).length };
          return `<div class="cat-row" style="cursor:default">${icon('activity')}<div><b>${esc(cat)}</b><small>${g.length - counts.Unknown} of ${g.length} enabled</small></div>${C.statusStack(counts)}<span class="n">${g.length}</span></div>`;
        }).join('');
        el.innerHTML = `
          <div class="kpis">${MC.kpi('Engines', list.length, tasks ? 'Windows Task Scheduler' : 'console scheduler')}${MC.kpi('Active', enabled, pct(enabled, list.length) + '% of engines')}${MC.kpi('Running now', running, running ? 'collecting' : 'idle between runs')}${MC.kpi('Not configured', notConf, notConf ? 'no targets chosen: they do not run' : 'none')}${MC.kpi('Disabled', disabled, disabled ? 'turned off' : 'none')}${MC.kpi('Need attention', failing.length + warn.length, failing.length + ' failed · ' + warn.length + ' warnings', { alert: failing.length > 0 })}</div>
          ${notConf ? `<div class="notice">${icon('info', 'sev-ico')} <b>No engine runs until it is configured.</b> Open an engine and choose what it reads on its <b>Targets</b> tab: single devices, groups, all devices of its type, or workgroup hosts, with the credential to use. Adding a monitoring option or sensor on a device configures its engine for that device. Engines that read no machines (Active Directory, Entra ID, cloud, discovery) start when you enable them.</div>` : ''}
          ${d.error ? `<div class="notice err">${icon('alert', 'sev-ico')} ${esc(d.error)}</div>` : ''}
          ${d.host === 'windows' && !d.tasksInstalled ? `<div class="notice">${icon('info', 'sev-ico')} <b>Engines run inside the console.</b> Install them as Windows scheduled tasks so monitoring keeps running when the console or the launcher is closed.${admin ? ' <button class="btn sm primary" id="engInst" style="margin-left:8px">Install engines</button>' : ''}</div>` : ''}
          ${d.host !== 'windows' && MC.api.mode === 'live' ? `<div class="notice">${icon('info', 'sev-ico')} This console host is not Windows, so the console scheduler runs every engine.</div>` : ''}
          <div class="grid g-1-2">
            ${MC.panel('Engine states', 'now', '<div id="engDonut"></div>')}
            ${MC.panel('By category', 'last result of each active engine; gray is disabled or not configured', `<div class="cat-matrix">${cats}</div>`)}
          </div>
          ${MC.panel('Engines', where, '<div id="engT"></div>', { act: admin ? `<button class="btn sm" id="engRef">${icon('refresh', 'sev-ico')}Refresh</button><button class="btn sm" data-all="enable">Enable all</button><button class="btn sm" data-all="disable">Disable all</button><button class="btn sm" data-all="stop">Stop all</button><button class="btn sm" data-all="restart">Restart all</button>${d.canInstall ? (d.tasksInstalled ? '<button class="btn sm ghost" id="engUn">Remove tasks</button><button class="btn sm ghost" id="engInst2">Update tasks</button>' : '') : ''}` : `<button class="btn sm" id="engRef">${icon('refresh', 'sev-ico')}Refresh</button>` })}`;
        C.donut($('#engDonut'), [{ label: 'Ready', value: list.length - running - disabled - notConf, color: '--ok' }, { label: 'Running', value: running, color: '--s1' }, { label: 'Not configured', value: notConf, color: '--s4' }, { label: 'Disabled', value: disabled, color: '--muted' }], { centerLabel: 'engines', label: 'Engine states', legend: true });
        MC.table($('#engT'), list, [
          { key: 'title', label: 'Engine', html: (r) => `<a href="#/engines/${encodeURIComponent(r.id)}"><b>${esc(r.title || r.id)}</b></a><br><span class="mono muted" style="font-size:11.5px">${esc(r.id)}</span>` },
          { key: 'needs', label: 'Needs', html: (r) => `<span class="eng-needs">${esc(engineSystem(r.id))}</span>`, val: (r) => engineSystem(r.id) },
          { key: 'category', label: 'Category' },
          { key: 'state', label: 'State', html: (r) => enginePill(r.state) },
          { key: 'every', label: 'Every', cls: 'mono' },
          { key: 'lastRun', label: 'Last run', html: (r) => ago(r.lastRun) },
          { key: 'lastStatus', label: 'Last result', html: engineResult },
          { key: 'nextRun', label: 'Next run', html: (r) => (engOff(r) ? '–' : until(r.nextRun)) },
          { key: 'durationSec', label: 'Took s', n: true },
          { key: 'host', label: 'Runs in', html: (r) => (r.host === 'task' ? 'Task Scheduler' + (r.runAs ? ` <span class="muted">(${esc(r.runAs)})</span>` : '') : 'Console') },
          { key: 'act', label: '', noCsv: true, html: (r) => (admin ? r.state === 'Not configured' ? `<div class="actions-row" style="flex-wrap:nowrap">${engFam(r.id) ? `<a class="btn sm primary" href="#/engines/${encodeURIComponent(r.id)}?view=targets">Configure…</a>` : `<button class="btn sm primary" data-e="enable" data-id="${esc(r.id)}">Enable</button>`}<button class="btn sm ghost" data-e="interval" data-id="${esc(r.id)}" data-ev="${esc(r.every)}">Interval…</button></div>` : `<div class="actions-row" style="flex-wrap:nowrap">${r.state === 'Running' ? `<button class="btn sm" data-e="stop" data-id="${esc(r.id)}">Stop</button>` : `<button class="btn sm" data-e="start" data-id="${esc(r.id)}" ${r.state === 'Disabled' ? 'disabled' : ''}>Start</button>`}<button class="btn sm ghost" data-e="restart" data-id="${esc(r.id)}" ${r.state === 'Disabled' ? 'disabled' : ''}>Restart</button>${r.state === 'Disabled' ? `<button class="btn sm ghost" data-e="enable" data-id="${esc(r.id)}">Enable</button>` : `<button class="btn sm ghost" data-e="disable" data-id="${esc(r.id)}">Disable</button>`}<button class="btn sm ghost" data-e="interval" data-id="${esc(r.id)}" data-ev="${esc(r.every)}">Interval…</button></div>` : '') },
        ], { sort: 'category', dir: 1, name: 'monitoring-engines', limit: 100, after: (w) => $$('[data-e]', w).forEach((b) => b.addEventListener('click', () => {
          const id = b.dataset.id, op = b.dataset.e, e = list.find((x) => x.id === id) || {};
          const name = e.title || id;
          if (op === 'interval') {
            return modal(`<h3>Interval for ${esc(name)}</h3><p class="muted">How often the engine runs, for example 5m, 1h or 24h. The script's default is ${esc(e.schedule || '1h')}.</p><div class="field"><label for="ev">Run every</label><input class="input mono" id="ev" value="${esc(b.dataset.ev)}"></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Save</button></div>`, (m, close) => {
              $('#go', m).addEventListener('click', async () => { await act('interval', id, $('#ev', m).value.trim(), name + ' now runs every ' + $('#ev', m).value.trim()); close(); });
            });
          }
          if (op === 'disable') return confirmAct('Disable ' + name + '?', 'The engine stops collecting until it is enabled again. A run in progress is stopped.', 'Disable', true, () => act('disable', id, null, name + ' disabled'));
          act(op, id, null, name + ' ' + { start: 'started', stop: 'stopped', restart: 'restarted', enable: 'enabled' }[op]);
        })) });
        $('#engRef').addEventListener('click', async () => draw(await MC.api.engines(true)));
        const ALL = { enable: ['Enable all engines?', 'Every configured engine starts collecting again on its own interval, and engines that read no machines (Active Directory, Entra ID, cloud, discovery) start too. Engines without targets stay not configured.', false], disable: ['Disable all engines?', 'Monitoring stops for every engine until you enable them again. Running engines are stopped.', true], stop: ['Stop all running engines?', 'Runs in progress are stopped. The engines stay enabled and run again at their next time.', true], restart: ['Restart all engines?', 'Every enabled engine is stopped if running and started again now. This puts load on the monitored servers for a few minutes.', false] };
        $$('[data-all]', el).forEach((b) => b.addEventListener('click', () => { const [t, x, danger] = ALL[b.dataset.all]; confirmAct(t, x, b.textContent, danger, () => act(b.dataset.all, 'All', null, b.textContent + ': done')); }));
        const install = () => confirmAct('Install the engines as scheduled tasks?', `Creates one Windows scheduled task per engine under <span class="mono">${esc(d.taskPath)}</span>, running as SYSTEM with PowerShell 7. Engines keep their intervals and on/off state. To run them as another account, use the launcher.`, 'Install', false, () => act('install', 'All', null, 'Engines installed as scheduled tasks'));
        ['#engInst', '#engInst2'].forEach((q) => { if ($(q)) $(q).addEventListener('click', install); });
        if ($('#engUn')) $('#engUn').addEventListener('click', () => confirmAct('Remove the engine tasks?', 'The scheduled tasks are deleted. The console scheduler takes over the engines while the console is running.', 'Remove tasks', true, () => act('uninstall', 'All', null, 'Engine tasks removed')));
      };
      MC.api.engines().then((d) => {
        draw(d);
        clearInterval(V.engines._t);
        const seq = MC.renderSeq;
        V.engines._t = setInterval(async () => { if (!document.body.contains(el) || MC.renderSeq !== seq || !$('#engT')) return clearInterval(V.engines._t); if (document.querySelector('.modal')) return; try { draw(await MC.api.engines()); } catch (e) { /* keep the last view */ } }, 10000);
      }).catch((e) => { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
    },
  };

  // ------------------------------------------------------------------ one engine: general info, permissions, utilization, results
  // which machines an engine reads (enginescope.js): single devices, groups, all devices of its kinds, AD scopes, workgroup hosts,
  // and the engine credential per device or group. Since 4.7.4 an engine reads nothing until something is chosen here.
  async function engineTargets(box, e, m, fam) {
    const ES = root.MCEngineScope, F = ES.FAMILIES[fam], admin = MC.user.role === 'admin';
    box.innerHTML = '<div class="muted">Loading…</div>';
    let r, creds = [], tree = { groups: [], devices: [] };
    try { [r, creds, tree] = await Promise.all([MC.api.engineScope(e.id), MC.api.credentials().catch(() => []), MC.api.monitor('tree').catch(() => ({ groups: [], devices: [] }))]); }
    catch (x) { box.innerHTML = `<div class="notice err">${esc(x.message)}</div>`; return; }
    if (!box.isConnected) return;
    const sc = r.scope, dis = admin ? '' : 'disabled';
    const lines = (a) => esc((a || []).join('\n'));
    const credKinds = [...new Set([F.cred].concat((e.permissions || {}).credentials || []).filter(Boolean))];
    const usable = creds.filter((c) => !credKinds.length || credKinds.includes(c.kind) || (credKinds.includes('snmpv2') && c.kind === 'snmpv3'));
    const mine = creds.filter((c) => c.kind === F.cred);
    const groups = tree.groups || [], devs = (tree.devices || []).slice().sort((a, b) => String(a.name).localeCompare(String(b.name)));
    const fit = devs.filter((d) => F.kinds.includes(d.kind) || sc.devices.includes(d.id));
    const credRows = sc.credentials.slice();
    const targetOpts = (sel) => `<optgroup label="Groups">${groups.map((g) => `<option value="grp:${esc(g.id)}" ${sel === 'grp:' + g.id ? 'selected' : ''}>${esc(g.name)}</option>`).join('')}</optgroup><optgroup label="Devices">${fit.map((d) => `<option value="dev:${esc(d.id)}" ${sel === 'dev:' + d.id ? 'selected' : ''}>${esc(d.name)}</option>`).join('')}</optgroup>`;
    const credOpts = (sel) => usable.map((c) => `<option value="${esc(c.id)}" ${sel === c.id ? 'selected' : ''}>${esc(c.name)} (${esc(c.kind)})</option>`).join('');
    const credRow = (c, i) => `<div class="actions-row" data-cr="${i}" style="flex-wrap:nowrap"><select class="input" data-ct ${dis} aria-label="Device or group">${targetOpts(c.target)}</select><select class="input" data-cc ${dis} aria-label="Credential">${credOpts(c.credential)}</select>${admin ? `<button class="btn sm ghost" type="button" data-cdel="${i}" aria-label="Remove">Remove</button>` : ''}</div>`;
    box.innerHTML = `${r.configured === false ? `<div class="notice">${icon('alert', 'sev-ico')} <b>Not configured.</b> This engine does not run until you choose what it reads below: single devices, all devices of its type (optionally in some groups)${F.ad.length ? ', Active Directory scopes' : ''}${F.hosts ? ', workgroup hosts' : ''}, or its default scope. Adding a monitoring option or sensor for this engine on a device page also configures it for that device.</div>` : ''}
      ${MC.panel('Targets', 'what ' + esc(e.title || e.id) + ' reads: ' + esc(r.describe), `
      <p class="muted" style="margin-top:0">${esc(F.label)}. ${esc(F.note)} Now: ${r.preview.assigned} device(s) from monitoring options and sensors${r.preview.scoped ? ' and ' + r.preview.scoped + ' from the targets below' : ''}.</p>
      <form id="etF" class="grid" style="gap:14px">
        <fieldset class="field"><legend>Devices in the console</legend>
          <label class="check"><input type="checkbox" id="etA" ${sc.added ? 'checked' : ''} ${dis}> All devices of its type (${esc(F.kinds.slice(0, 6).join(', '))}${F.kinds.length > 6 ? '…' : ''}) added by hand, from auto-discovery or an import${fam === 'network' || fam === 'storage' ? ', and the ones the network discovery engine found' : ''}</label>
          <div class="grid g2" style="margin-top:6px">
            <div class="field"><label for="etAG">…only in these groups <span class="muted">(none = every group; a device in several groups counts in each)</span></label><select class="input" id="etAG" multiple size="5" ${dis}>${groups.map((g) => `<option value="${esc(g.id)}" ${sc.addedGroups.includes(g.id) ? 'selected' : ''}>${esc(g.name)}</option>`).join('')}</select></div>
            <div class="field"><label for="etD">Single devices <span class="muted">(${fit.length} of this type; Ctrl+click to choose several)</span></label><input class="input" id="etDq" placeholder="Filter devices" ${dis} style="margin-bottom:4px" aria-label="Filter devices"><select class="input" id="etD" multiple size="5" ${dis}>${fit.map((d) => `<option value="${esc(d.id)}" ${sc.devices.includes(d.id) ? 'selected' : ''}>${esc(d.name)}${d.host && d.host !== d.name ? ' · ' + esc(d.host) : ''} (${esc(d.kind)})</option>`).join('')}</select></div>
          </div></fieldset>
        ${F.ad.length ? `<fieldset class="field"><legend>Active Directory</legend><div class="actions-row">${F.ad.map((a) => `<label class="check"><input type="checkbox" name="ad" value="${a}" ${sc.ad.includes(a) ? 'checked' : ''} ${dis}> ${esc({ Servers: 'Servers', Workstations: 'Workstations', AllComputers: 'All computers', DomainControllers: 'Domain controllers', Linux: 'Linux computers' }[a] || a)}</label>`).join('')}</div>
        <div class="grid g2" style="margin-top:6px"><div class="field"><label for="etG">AD groups of computers <span class="muted">(one per line, nested groups included)</span></label><textarea class="input mono" id="etG" rows="3" ${dis} placeholder="GRP-Finance-PCs">${lines(sc.adGroups)}</textarea></div>
        <div class="field"><label for="etO">Organizational units <span class="muted">(distinguished names)</span></label><textarea class="input mono" id="etO" rows="3" ${dis} placeholder="OU=Workstations,OU=HQ,DC=corp,DC=example,DC=com">${lines(sc.ous)}</textarea></div></div></fieldset>` : ''}
        ${F.hosts ? `<div class="grid g2"><div class="field"><label for="etH">${fam === 'windows' ? 'Workgroup computers' : fam === 'api' ? 'API addresses' : 'More hosts'} <span class="muted">(names, IPs, ranges like 10.0.5.10-40, or subnets up to /22)</span></label><textarea class="input mono" id="etH" rows="3" ${dis} placeholder="10.20.0.0/24&#10;10.20.1.10-40&#10;KIOSK-01">${lines(sc.hosts)}</textarea></div>
        <div class="field"><label for="etC">Credential for these hosts</label><select class="input" id="etC" ${dis}><option value="">Each host's own, else the default ${esc(F.cred || 'matching')} credential</option>${(F.cred ? mine : usable).map((c) => `<option value="${esc(c.id)}" ${sc.credential === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select><span class="hint">${(F.cred ? mine : usable).length ? '' : 'No ' + esc(F.cred || '') + ' credential yet: add one under <a href="#/credentials">Configure › Credentials</a>.'}</span></div></div>` : ''}
        <fieldset class="field"><legend>Engine credentials per device or group</legend>
          <p class="muted" style="margin:0 0 6px;font-size:12.5px">For this engine only. Order used on each device: the engine credential for the device, then for its nearest group (the group, then its parents), then the device's own credential, its vault assignment, its group's assignment, then the probe default.</p>
          <div id="etCR" class="grid" style="gap:6px">${credRows.map(credRow).join('') || '<div class="muted" data-none>None: devices use their own credentials.</div>'}</div>
          ${admin ? `<div class="actions-row" style="margin-top:6px"><button class="btn sm" type="button" id="etCRadd" ${usable.length ? '' : 'disabled'}>Add engine credential</button>${usable.length ? '' : '<span class="muted">Add a credential under <a href="#/credentials">Configure › Credentials</a> first.</span>'}</div>` : ''}
        </fieldset>
        <label class="check"><input type="checkbox" id="etU" ${sc.useDefault ? 'checked' : ''} ${dis}> Also read the engine's default scope: ${esc(engineSystem(e.id, m))} <span class="muted">(off by default)</span></label>
        <div data-err></div>
        ${admin ? '<div class="actions-row"><button class="btn primary" type="submit">Save targets</button><span class="muted">The next run uses them.</span></div>' : '<p class="muted">Only administrators change engine targets.</p>'}
      </form>`)}`;
    const f = $('#etF', box);
    if ($('#etDq', box)) $('#etDq', box).addEventListener('input', (ev) => { const q = ev.target.value.toLowerCase(); [...$('#etD', box).options].forEach((o) => { o.hidden = !!q && !o.textContent.toLowerCase().includes(q); }); });
    const readRows = () => $$('[data-cr]', box).map((x) => ({ target: $('[data-ct]', x).value, credential: $('[data-cc]', x).value })).filter((x) => x.target && x.credential);
    const wireRows = () => $$('[data-cdel]', box).forEach((b) => b.addEventListener('click', () => { const rows = readRows(); rows.splice(+b.dataset.cdel, 1); $('#etCR', box).innerHTML = rows.map(credRow).join('') || '<div class="muted">None: devices use their own credentials.</div>'; wireRows(); }));
    wireRows();
    if ($('#etCRadd', box)) $('#etCRadd', box).addEventListener('click', () => { const rows = readRows(); rows.push({ target: groups[0] ? 'grp:' + groups[0].id : '', credential: (usable[0] || {}).id }); $('#etCR', box).innerHTML = rows.map(credRow).join(''); wireRows(); });
    if (admin) f.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const split = (id) => ($(id, box) ? $(id, box).value.split(/\n+/).map((x) => x.trim()).filter(Boolean) : []);
      const scope = { ad: $$('input[name=ad]:checked', box).map((x) => x.value), adGroups: split('#etG'), ous: split('#etO'), hosts: split('#etH'), credential: $('#etC', box) ? $('#etC', box).value : '', added: $('#etA', box).checked, addedGroups: [...$('#etAG', box).selectedOptions].map((o) => o.value), devices: [...$('#etD', box).selectedOptions].map((o) => o.value), credentials: readRows(), useDefault: $('#etU', box).checked };
      try { const x = await MC.api.setEngineScope(e.id, scope); MC.toast('Targets saved: ' + esc(x.describe) + (x.configured === false ? '. The engine is still not configured.' : ''), 'ok'); engineTargets(box, e, m, fam); }
      catch (err) { $('[data-err]', box).innerHTML = `<div class="notice err">${esc(err.message)}</div>`; }
    });
  }
  // one run of an engine: when, who started it, what it collected, its errors and warnings (Run history > Details, General > Last run)
  const runPill = (x) => pill(x.status === 'ok' ? 'OK' : x.status === 'warning' ? 'Warning' : x.status === 'skipped' ? 'Unknown' : 'Critical', x.status || '–');
  function runEvents(x, secs) {
    const d = x.details || {}, sum = d.summary && typeof d.summary === 'object' ? Object.entries(d.summary) : [];
    const w = d.warnings || [];
    return `<dl class="kv"><dt>Result</dt><dd>${runPill(x)}</dd><dt>Started</dt><dd>${dt(x.at)}</dd><dt>Finished</dt><dd>${x.finished ? dt(x.finished) : '–'}</dd><dt>Took</dt><dd>${secs(x.durationSec)}</dd><dt>Started by</dt><dd>${x.trigger === 'manual' ? 'Run now · ' + esc(x.by || 'administrator') : x.trigger === 'schedule' ? 'Schedule' : esc(x.by || x.host || '–')}</dd><dt>Rows collected</dt><dd>${x.count == null ? '–' : fmt(x.count, 0)}</dd><dt>Errors</dt><dd>${x.errors ? `<b style="color:var(--crit-ink)">${x.errors}</b>` : '0'}</dd><dt>Warnings</dt><dd>${x.warnings || 0}</dd>${x.cpuSec != null ? `<dt>CPU · memory</dt><dd>${fmt(x.cpuSec, 1)} s · ${x.peakMB == null ? '–' : fmt(x.peakMB, 0) + ' MB'}</dd>` : ''}${x.server ? `<dt>Collected on</dt><dd>${esc(x.server)}</dd>` : ''}${x.job ? `<dt>Job</dt><dd class="mono">${MC.api.mode === 'live' ? `<a href="#/actions/myjobs?job=${encodeURIComponent(x.job)}">${esc(x.job)}</a>` : esc(x.job)}</dd>` : ''}${sum.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v == null ? '–' : String(v))}</dd>`).join('')}</dl>
      ${x.message || x.error ? `<div class="msg" style="margin-top:8px">${esc(x.error || x.message)}</div>` : ''}
      ${w.length ? `<h4 style="margin:12px 0 6px">Errors and warnings</h4><ul class="plain">${w.map((t) => `<li style="font-size:12.5px">${/fail|error|denied|unreachable|cannot|could not|refused|timed? ?out/i.test(t) ? icon('alert', 'sev-ico') : icon('info', 'sev-ico')} ${esc(t)}</li>`).join('')}</ul>${x.warnings > w.length ? `<p class="muted" style="font-size:12px">and ${x.warnings - w.length} more</p>` : ''}` : x.status === 'ok' ? '<div class="notice ok" style="margin-top:8px">No errors or warnings.</div>' : ''}`;
  }
  function engineInfo(el, id, view) {
    el.innerHTML = '<div class="notice">Loading the engine…</div>';
    const admin = MC.user.role === 'admin';
    const secs = (v) => (v == null ? '–' : v >= 90 ? fmt(v / 60, 1) + ' min' : fmt(v, 1) + ' s');
    const draw = (e) => {
      $('#pageTitle').textContent = e.title || e.id;
      const u = e.usage || {}, m = e.meta || {}, p = e.permissions || {}, r = e.result, sn = e.sensors || { total: 0, byState: {} };
      const runs = e.runs || [];
      const fam = root.MCEngineScope ? root.MCEngineScope.familyOf(Object.assign({ id: e.id }, m)) : null;
      const tabs = [['general', 'General'], ...(fam ? [['targets', 'Targets']] : []), ['permissions', 'Permissions'], ['utilization', 'Utilization'], ['results', 'Results'], ['runs', 'Run history', runs.length ? { s: u.failed ? 'Critical' : u.warnings ? 'Warning' : 'OK', n: runs.length } : null]];
      el.innerHTML = `
        <section class="card panel-c"><div class="shead"><div style="flex:1;min-width:240px">
          <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">${enginePill(e.state)}${engineResult(e)}<span class="tag collector">engine</span><span class="mono muted" style="font-size:12px">${esc(e.id)}</span></div>
          <p style="margin:8px 0 0">${esc(m.synopsis || '')}</p>
          ${e.message ? `<div class="msg" style="margin-top:6px">${esc(e.message)}</div>` : ''}
        </div><div class="actions-row" style="align-self:flex-start"><a class="btn sm ghost" href="#/engines">All engines</a>${admin ? e.state === 'Not configured' ? (fam ? `<a class="btn sm primary" href="#/engines/${encodeURIComponent(e.id)}?view=targets">Configure targets</a>` : '<button class="btn sm primary" data-ea="enable">Enable</button>') : `${e.state === 'Running' ? '<button class="btn sm" data-ea="stop">Stop</button>' : `<button class="btn sm primary" data-ea="start" ${e.state === 'Disabled' ? 'disabled' : ''}>Run now</button>`}${e.state === 'Disabled' ? '<button class="btn sm" data-ea="enable">Enable</button>' : '<button class="btn sm" data-ea="disable">Disable</button>'}` : ''}</div></div></section>
        <div class="kpis">${MC.kpi('Runs every', esc(e.every || '–'), 'default ' + esc(m.schedule || '–'))}${MC.kpi('Last run', ago(e.lastRun), e.lastRun ? dt(e.lastRun) : 'not run yet')}${MC.kpi('Next run', engOff(e) ? '–' : until(e.nextRun), e.state === 'Disabled' ? 'disabled' : e.state === 'Not configured' ? 'not configured' : '')}${MC.kpi('Success rate', u.okRate == null ? '–' : fmt(u.okRate, 1) + '%', u.runs + ' runs · ' + u.failed + ' failed', { alert: u.failed > 0 })}${MC.kpi('Average run', secs(u.avgSec), 'longest ' + secs(u.maxSec))}${MC.kpi('Sensors fed', sn.total, sn.devices + ' devices' + (sn.byState.Down ? ' · ' + sn.byState.Down + ' down' : ''), { href: '#/sensors?q=' + encodeURIComponent(e.title || '') })}</div>
        <div class="tabs" role="tablist">${tabs.map(([k, t, b]) => `<button role="tab" aria-selected="${k === view}" class="${k === view ? 'on' : ''}" data-href="#/engines/${encodeURIComponent(e.id)}?view=${k}">${esc(t)}${b ? ` <span class="pill ${b.s}" style="margin-left:4px">${b.n}</span>` : ''}</button>`).join('')}</div>
        <div id="eiBody" class="grid"></div>`;
      const b = $('#eiBody', el);
      if (view === 'general') {
        b.innerHTML = `<div class="grid g2">
          ${MC.panel('General', '', `<dl class="kv"><dt>Engine</dt><dd>${esc(e.title || e.id)}</dd><dt>ID</dt><dd class="mono">${esc(e.id)}</dd><dt>Needs</dt><dd><b>${esc(engineSystem(e.id, m))}</b></dd><dt>Category</dt><dd>${esc(m.category || '–')} · ${esc(m.resource || '')}</dd><dt>Dataset</dt><dd class="mono">${esc(m.dataset || '–')}</dd><dt>State</dt><dd>${enginePill(e.state)}</dd><dt>Runs in</dt><dd>${e.host === 'task' ? 'Windows Task Scheduler · <span class="mono">' + esc((e.taskPath || '') + 'MC_' + e.id) + '</span>' : 'Console scheduler'}</dd><dt>Runs as</dt><dd>${esc(p.runAs || '–')}</dd>${e.server ? `<dt>MonCastle server</dt><dd>${esc(e.serverName || e.server)}</dd>` : ''}<dt>Interval</dt><dd class="mono">${esc(e.every || '–')} (default ${esc(m.schedule || '–')})</dd><dt>Risk</dt><dd>${esc(m.risk || 'low')}</dd></dl>`)}
          ${MC.panel('Script', 'from the scripts repository', `<dl class="kv"><dt>Path</dt><dd class="mono" style="overflow-wrap:anywhere">${esc(m.path || '–')}</dd><dt>Size</dt><dd>${m.bytes ? fmt(m.bytes / 1024, 1) + ' KB' : '–'}</dd><dt>SHA-256</dt><dd class="mono" style="overflow-wrap:anywhere;font-size:11.5px">${esc(m.sha256 || '–')}</dd><dt>Parameters</dt><dd>${(m.parameters || []).length ? m.parameters.map((x) => `<span class="mono">${esc(x.name)}</span>${x.mandatory ? '*' : ''}`).join(', ') : 'none'}</dd><dt>Replaces</dt><dd style="font-size:12.5px">${(m.replaces || []).length ? m.replaces.map(esc).join('<br>') : '–'}</dd></dl>`)}
        </div>
        <div class="grid g2">
          ${MC.panel('Devices it reads', sn.total + ' sensors on ' + sn.devices + ' devices', `<div>${C.statusStack({ OK: sn.byState.Up || 0, Warning: sn.byState.Warning || 0, Critical: sn.byState.Down || 0, Unknown: (sn.byState.Unknown || 0) + (sn.byState.Paused || 0) })}</div>${(e.extraTargets || []).length ? `<p class="muted" style="font-size:12.5px;margin:10px 0 0">Added by monitoring options: ${e.extraTargets.map(esc).join(', ')}</p>` : ''}`)}
          ${MC.panel('Last run', runs[0] ? ago(runs[0].at) + (runs[0].trigger ? ' · ' + (runs[0].trigger === 'manual' ? 'run now' : 'scheduled') : '') : 'not run yet', runs[0] ? runEvents(runs[0], secs) : `<div class="empty">${e.state === 'Not configured' ? 'Not configured: the engine has not run.' : 'No run recorded yet.'}</div>`)}
          ${MC.panel('Last result', r ? ago(r.finished) : 'no data yet', r ? `<dl class="kv"><dt>Status</dt><dd>${pill(r.status === 'ok' ? 'OK' : r.status === 'partial' ? 'Warning' : 'Critical', r.status)}</dd><dt>Rows</dt><dd>${fmt(r.count, 0)}</dd><dt>Collected on</dt><dd>${esc(r.host || '–')}</dd><dt>Took</dt><dd>${r.started && r.finished ? secs((Date.parse(r.finished) - Date.parse(r.started)) / 1000) : '–'}</dd>${(r.warnings || []).length ? `<dt>Warnings</dt><dd>${r.warnings.length}</dd>` : ''}</dl>` : '<div class="empty">The engine has not delivered a result yet.</div>')}
        </div>`;
      } else if (view === 'targets' && fam) {
        engineTargets(b, e, m, fam);
      } else if (view === 'permissions') {
        const cu = e.credentialUse || [];
        b.innerHTML = `
          <div class="notice">${icon('info', 'sev-ico')} Runs as <b>${esc(p.runAs || '–')}</b>. ${esc(p.runAsNote || '')}</div>
          <div class="grid g2">
            ${MC.panel('Rights on the systems it reads', 'least privilege', `<ul class="plain">${(p.rights || []).map((x) => `<li><b>${esc(x.need)}</b><br><span class="muted" style="font-size:12.5px">${esc(x.why)}</span></li>`).join('')}</ul>`)}
            ${MC.panel('Network and modules', 'from the MonCastle server to the targets', `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Protocol</th><th>Port</th></tr></thead><tbody>${(p.ports || []).map((x) => `<tr><td>${esc(x.name)}</td><td class="mono">${esc(x.proto + ' ' + x.port)}</td></tr>`).join('') || '<tr><td colspan="2" class="muted">Local only</td></tr>'}</tbody></table></div>${(p.modules || []).length ? `<p style="margin:10px 0 0;font-size:13px">PowerShell modules on the MonCastle server: ${p.modules.map((x) => `<span class="mono">${esc(x)}</span>`).join(', ')}</p>` : ''}`)}
          </div>
          <div class="grid g2">
            ${MC.panel('Credentials it uses', (p.credentials || []).length ? 'kinds: ' + p.credentials.join(', ') : 'none', `<div id="eiCred"></div>`)}
            ${MC.panel('Who can do what in the console', 'roles', `<dl class="kv">${(p.console || []).map((x) => `<dt>${esc(x.role)}</dt><dd>${esc(x.can)}</dd>`).join('')}</dl>${(p.secrets || []).length ? `<p class="muted" style="font-size:12.5px">Secrets this script asks for at run time: ${p.secrets.map(esc).join(', ')}</p>` : ''}`)}
          </div>`;
        MC.table($('#eiCred', b), cu, [
          { key: 'device', label: 'Device' },
          { key: 'credential', label: 'Credential', html: (x) => (x.credential ? esc(x.credential) : `<span class="muted">${esc(p.runAs || 'engine account')}</span>`) },
          { key: 'kind', label: 'Kind', cls: 'mono' },
          { key: 'from', label: 'From' },
        ], { name: 'engine-credentials', limit: 25, empty: 'No devices yet. Credentials resolve per device: device, assignment, group, then the probe default.' });
      } else if (view === 'utilization') {
        b.innerHTML = `<div class="kpis">${MC.kpi('CPU per run', u.avgCpu == null ? '–' : fmt(u.avgCpu, 1) + ' s', 'max ' + (u.maxCpu == null ? '–' : fmt(u.maxCpu, 1) + ' s'))}${MC.kpi('Peak memory', u.avgMem == null ? '–' : fmt(u.avgMem, 0) + ' MB', 'max ' + (u.maxMem == null ? '–' : fmt(u.maxMem, 0) + ' MB'))}${MC.kpi('Run time', secs(u.avgSec), 'max ' + secs(u.maxSec))}${MC.kpi('Rows per run', u.avgRows == null ? '–' : fmt(u.avgRows, 0), '')}${MC.kpi('Busy share', u.avgSec && e.every ? fmt(Math.min(100, (u.avgSec * 1000 / (toMsLocal(e.every) || 36e5)) * 100), 2) + '%' : '–', 'of the interval spent running')}</div>
          ${MC.panel('Run time', 'seconds per run, oldest to newest', '<div id="eiDur"></div>')}
          <div class="grid g2">${MC.panel('CPU time', 'seconds of processor time per run on the MonCastle server', '<div id="eiCpu"></div>')}${MC.panel('Peak memory', 'MB per run', '<div id="eiMem"></div>')}</div>
          <p class="muted" style="font-size:12.5px">CPU time and memory are measured by the engine process itself (PowerShell) and reported with every result. Older runs without these values are left out of the charts.</p>`;
        const pts = (k) => runs.slice().reverse().filter((x) => typeof x[k] === 'number').map((x) => ({ t: Date.parse(x.at), v: x[k] }));
        C.timeSeries($('#eiDur', b), [{ name: 'Run time', points: pts('durationSec'), color: '--s1' }], { height: 170, unit: ' s', label: 'Run time' });
        C.timeSeries($('#eiCpu', b), [{ name: 'CPU', points: pts('cpuSec'), color: '--s2' }], { height: 150, unit: ' s', label: 'CPU time' });
        C.timeSeries($('#eiMem', b), [{ name: 'Memory', points: pts('peakMB'), color: '--s3' }], { height: 150, unit: ' MB', label: 'Peak memory' });
      } else if (view === 'results') {
        if (!r) { b.innerHTML = '<div class="card panel-c empty">The engine has not delivered a result yet.</div>'; }
        else {
          const sum = r.summary && typeof r.summary === 'object' ? Object.entries(r.summary).filter(([, v]) => v == null || typeof v !== 'object') : [];
          b.innerHTML = `<div class="grid g2">${MC.panel('Summary', esc(r.dataset) + ' · ' + ago(r.finished), sum.length ? `<dl class="kv">${sum.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v == null ? '–' : String(v))}</dd>`).join('')}</dl>` : '<div class="muted">No summary.</div>')}
            ${MC.panel('Warnings', (r.warnings || []).length + ' in the last run', (r.warnings || []).length ? `<ul class="plain">${r.warnings.map((w) => `<li style="font-size:12.5px">${esc(typeof w === 'string' ? w : JSON.stringify(w))}</li>`).join('')}</ul>` : '<div class="notice ok">No warnings.</div>')}</div>
            ${MC.panel('Sample rows', 'first ' + (r.sample || []).length + ' of ' + fmt(r.count, 0), '<div id="eiRows"></div>')}`;
          MC.table($('#eiRows', b), r.sample || [], (r.columns || []).map((c) => ({ key: c, label: c, html: (x) => esc(x[c] == null ? '' : typeof x[c] === 'object' ? JSON.stringify(x[c]).slice(0, 80) : String(x[c])) })), { name: 'engine-sample', limit: 8 });
        }
      } else {
        const errs = runs.reduce((a2, x) => a2 + (x.errors || 0), 0), rows = runs.reduce((a2, x) => a2 + (x.count || 0), 0);
        b.innerHTML = `<div class="kpis">${MC.kpi('Runs', runs.length, u.failed + ' failed · ' + u.warnings + ' with warnings', { alert: u.failed > 0 })}${MC.kpi('Rows collected', fmt(rows, 0), 'in these runs')}${MC.kpi('Errors', errs, errs ? 'targets that failed or refused access' : 'none', { alert: errs > 0 })}${MC.kpi('Last run', runs[0] ? ago(runs[0].at) : '–', runs[0] ? (runs[0].trigger === 'manual' ? 'run now by ' + (runs[0].by || 'admin') : 'scheduled') : '')}</div>` + MC.panel('Run history', runs.length + ' runs · choose a run for its events', '<div id="eiRuns"></div>');
        MC.table($('#eiRuns', b), runs, [
          { key: 'at', label: 'Started', html: (x) => dt(x.at), val: (x) => -Date.parse(x.at) },
          { key: 'status', label: 'Result', html: (x) => runPill(x) },
          { key: 'trigger', label: 'Started by', html: (x) => (x.trigger === 'manual' ? 'Run now · ' + esc(x.by || '') : x.trigger === 'schedule' ? 'Schedule' : '–') },
          { key: 'errors', label: 'Errors', n: true },
          { key: 'durationSec', label: 'Took s', n: true },
          { key: 'cpuSec', label: 'CPU s', n: true },
          { key: 'peakMB', label: 'Peak MB', n: true },
          { key: 'count', label: 'Rows', n: true },
          { key: 'warnings', label: 'Warnings', n: true },
          { key: 'message', label: 'Message', html: (x) => `<span style="font-size:12.5px">${esc(x.message || '')}</span>` },
          { key: 'det', label: '', noCsv: true, html: (x) => `<button class="btn sm ghost" data-run-i="${runs.indexOf(x)}">Details</button>` },
        ], { sort: 'at', dir: 1, name: 'engine-runs-' + e.id, limit: 60, after: (w) => $$('[data-run-i]', w).forEach((bt) => bt.addEventListener('click', () => {
          const x = runs[+bt.dataset.runI];
          modal(`<h3>${esc(e.title || e.id)} · run of ${dt(x.at)}</h3>${runEvents(x, secs)}<div class="foot"><button class="btn" data-x>Close</button></div>`);
        })) });
      }
      $$('[data-ea]', el).forEach((x) => x.addEventListener('click', async () => { try { await MC.api.engineAction(x.dataset.ea, e.id); MC.toast(esc(e.title || e.id) + ': ' + x.textContent, 'ok'); setTimeout(load, 600); } catch (err) { MC.toast(esc(err.message), 'err'); } }));
    };
    const load = () => MC.api.engine(id).then(draw).catch((x) => { el.innerHTML = `<div class="notice err">${esc(x.message)}</div>`; });
    load();
    const seq = MC.renderSeq;
    V.engines._t = setInterval(() => { if (MC.renderSeq !== seq) return clearInterval(V.engines._t); if (document.querySelector('.modal') || view === 'runs') return; load(); }, 20000);
  }
  const toMsLocal = (e) => { const m2 = /^(\d+)\s*([smhd])$/i.exec(String(e || '')); return m2 ? +m2[1] * { s: 1e3, m: 6e4, h: 36e5, d: 864e5 }[m2[2].toLowerCase()] : 0; };

  // ================================================================== LICENCES & ACCESS
  const licState = (l) => pill(l.state === 'valid' || l.state === 'active' ? 'OK' : l.state === 'grace' ? 'Warning' : 'Critical', l.state || 'missing');
  function modal(html, onReady) {
    const m = document.createElement('div');
    m.className = 'modal';
    m.setAttribute('role', 'dialog');
    m.setAttribute('aria-modal', 'true');
    m.innerHTML = `<div class="card">${html}</div>`;
    document.body.appendChild(m);
    const close = () => m.remove();
    $$('[data-x]', m).forEach((b) => b.addEventListener('click', close));
    m.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    const f = $('input,textarea,select', m); if (f) f.focus();
    if (onReady) onReady(m, close);
    return m;
  }
  function downloadText(name, text, type) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: type || 'application/json' }));
    a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  async function copy(text, label) {
    try { await navigator.clipboard.writeText(text); MC.toast((label || 'Copied') + ' to the clipboard', 'ok'); } catch (e) { MC.toast('Copy failed; select the text and copy it manually.', 'err'); }
  }

  V.access = {
    title: 'Licences & access',
    crumb: () => 'Licence keys from RoboMate-MonCastle-Licenses · access log to RoboMate-MonCastle-Access',
    render(el, route) {
      const admin = MC.user.role === 'admin';
      const tab = route.tab || 'licence';
      const tabs = [['licence', 'This console'], ...(admin ? [['registry', 'Licence administration'], ['override', 'Administrator override']] : []), ['log', 'Access log']];
      el.innerHTML = MC.tabs('access', tabs, tab) + '<div id="tab" class="grid"></div>';
      const t = $('#tab', el);
      if (tab === 'registry' && admin) return licRegistry(t);
      if (tab === 'override' && admin) return licOverride(t);
      if (tab === 'log') return accessLog(t);
      return licThis(t, admin);
    },
  };

  function licThis(el, admin) {
    const l = MC.status.license || {};
    el.innerHTML = `<div class="grid g2">
      ${MC.panel('Licence', '', `${MC.user.override ? '<div class="notice err" style="margin-bottom:12px">You are signed in with the administrator override. Activate a valid licence key to restore normal access.</div>' : ''}
        <dl class="kv"><dt>State</dt><dd>${licState(l)}</dd><dt>Licence key</dt><dd><span class="mono" id="keyTxt" style="letter-spacing:.04em;overflow-wrap:anywhere">${esc(l.masked || 'none')}</span>${admin && l.masked ? ' <button class="btn sm ghost" id="reveal">Reveal</button>' : ''}</dd><dt>Holder</dt><dd>${esc(l.holder || '–')}</dd><dt>Edition</dt><dd>${esc(l.edition || '–')}</dd><dt>Expires</dt><dd>${l.expires ? dt(l.expires) + ' (' + ago(l.expires) + ')' : 'no expiry set'}</dd><dt>Node limit</dt><dd>${esc(l.maxNodes || 'unlimited')}</dd><dt>Last check</dt><dd>${ago(l.checkedAt)}</dd><dt>Verified against</dt><dd class="mono">${esc(l.repo || (MC.status.repos || {}).licenses || '')}</dd>${l.reason ? `<dt>Note</dt><dd>${esc(l.reason)}</dd>` : ''}</dl>
        <p class="muted" style="font-size:12.5px">Only MonCastle serials (320RMC…) are accepted. The key is stored encrypted on the console server, re-checked every 6 hours, and never written to logs. If GitHub cannot be reached the console keeps working for 72 hours, then becomes read-only. Nothing is ever deleted.</p>`, { act: admin ? '<button class="btn sm" id="replLic">Replace licence…</button>' : '' })}
      ${MC.panel('Repositories', 'what this licence key gives access to', `<dl class="kv"><dt>Licences</dt><dd class="mono">${esc((MC.status.repos || {}).licenses || '')}</dd><dt>Scripts</dt><dd class="mono">${esc((MC.status.repos || {}).scripts || '')}</dd><dt>Console updates</dt><dd class="mono">${esc((MC.status.repos || {}).console || '')}</dd><dt>Access logs</dt><dd class="mono">${esc((MC.status.repos || {}).access || '')}</dd><dt>Log path</dt><dd class="mono">access-logs/${esc(MC.status.consoleId || '')}/YYYY/MM/YYYY-MM-DD.jsonl</dd><dt>Last log push</dt><dd>${ago((MC.status.accessLog || {}).lastPush)}${(MC.status.accessLog || {}).pending != null ? ' · ' + MC.status.accessLog.pending + ' events waiting' : ''}</dd></dl>`)}
    </div>`;
    if ($('#reveal')) $('#reveal').addEventListener('click', async (e) => {
      const b = e.target;
      if (b.dataset.shown) { $('#keyTxt').textContent = l.masked; b.textContent = 'Reveal'; delete b.dataset.shown; return; }
      try {
        const r = await MC.api.licenseKey();
        $('#keyTxt').textContent = r.key || l.masked;
        b.textContent = 'Hide'; b.dataset.shown = '1';
        const c = document.createElement('button'); c.className = 'btn sm ghost'; c.textContent = 'Copy'; c.addEventListener('click', () => copy(r.key, 'Licence key copied')); b.after(c);
        setTimeout(() => { if (b.dataset.shown) b.click(); c.remove(); }, 30000);
      } catch (x) { MC.toast(esc(x.message), 'err'); }
    });
    if ($('#replLic')) $('#replLic').addEventListener('click', () => modal(`<h3>Replace licence</h3><p class="muted">Paste the new licence key (320RMC…). The old one is discarded once the new one verifies.</p><div class="field"><label for="nt">Licence key</label><input class="input mono" id="nt" type="password" autocomplete="off" placeholder="320RMC…"></div><div id="ne"></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="nv">Verify</button></div>`, (m, close) => {
      $('#nv', m).addEventListener('click', async () => {
        try { await MC.api.license($('#nt', m).value.trim()); MC.status = await MC.api.status(); if (MC.user.override) MC.toast('Licence verified. Sign in with a console account to leave override mode.', 'ok'); close(); MC.toast('Licence verified', 'ok'); MC.render(); } catch (e) { $('#ne', m).innerHTML = `<div class="notice err">${esc(e.message)}</div>`; }
      });
    }));
  }

  function licRegistry(el) {
    el.innerHTML = '<div class="card panel-c muted">Reading licenses.json…</div>';
    MC.api.registry().then((reg) => {
      const list = reg.licenses || [];
      const draw = () => {
        const active = list.filter((l) => l.state === 'active').length;
        const soon = list.filter((l) => l.state === 'active' && l.expires && Date.parse(l.expires) - Date.now() < 45 * 864e5).length;
        el.innerHTML = `
          <div class="kpis">${MC.kpi('Licences', list.length, esc(reg.repo))}${MC.kpi('Active', active, '')}${MC.kpi('Expiring in 45 days', soon, '', { alert: soon > 0 })}${MC.kpi('Revoked or expired', list.length - active, '')}${MC.kpi('Registration', reg.policy && reg.policy.requireRegistration ? 'Required' : 'Optional', reg.policy && reg.policy.requireRegistration ? 'only listed keys work' : 'any key with repo access works')}</div>
          <div class="grid g-1-2">
            ${MC.panel('Issue a licence key', 'registers a 320RMC key in licenses.json', `<form id="issueForm" class="grid" style="gap:0" autocomplete="off">
              <div class="field"><label for="iTok">Licence key</label><input class="input mono" id="iTok" type="password" placeholder="320RMC…" required><span class="hint">Only MonCastle serials (320RMC…) are accepted. The key needs Contents: Read on the Licenses, Scripts and Console repos (plus Read and write on Access). It is used once here and not stored.</span></div>
              <div class="field"><label for="iHolder">Holder</label><input class="input" id="iHolder" placeholder="Customer or team" required></div>
              <div class="grid g2" style="gap:10px"><div class="field"><label for="iEd">Edition</label><select class="input" id="iEd"><option>Standard</option><option>Enterprise</option><option>Trial</option></select></div><div class="field"><label for="iExp">Expires</label><input class="input" id="iExp" type="date"></div></div>
              <div class="grid g2" style="gap:10px"><div class="field"><label for="iNodes">Node limit</label><input class="input" id="iNodes" type="number" min="1" placeholder="unlimited"></div><div class="field"><label for="iId">Licence ID</label><input class="input" id="iId" placeholder="auto"></div></div>
              <label class="check" style="margin-bottom:12px"><input type="checkbox" id="iVerify" checked> Check the token against GitHub first</label>
              <div id="iErr"></div>
              <button class="btn primary" type="submit">${icon('key', 'sev-ico')}Create key and entry</button></form><div id="iOut"></div>`)}
            ${MC.panel('Registered licences', reg.source === 'missing' ? 'licenses.json does not exist yet; issue a key to start one' : 'from licenses.json', '<div id="regT"></div>', { act: '<button class="btn sm" id="dlReg">Download licenses.json</button>' })}
          </div>
          <div class="notice">Changes here are prepared locally. Download licenses.json and upload it to <span class="mono">${esc(reg.repo)}</span> to apply them. Consoles pick up the change at their next licence check (within 6 hours). To cut access immediately, also remove the token's access to the repository on GitHub.</div>`;
        MC.table($('#regT'), list, [
          { key: 'id', label: 'ID', cls: 'mono' }, { key: 'holder', label: 'Holder' }, { key: 'edition', label: 'Edition' },
          { key: 'expires', label: 'Expires', html: (r) => (r.expires ? esc(r.expires) + ' <span class="muted">(' + ago(r.expires) + ')</span>' : 'never') },
          { key: 'maxNodes', label: 'Nodes', n: true }, { key: 'fingerprint', label: 'Fingerprint', cls: 'mono' },
          { key: 'state', label: 'State', html: (r) => licState(r) + (r.current ? ' <span class="pill Info">this console</span>' : '') },
          { key: 'act', label: '', noCsv: true, html: (r) => `<button class="btn sm ghost" data-rev="${esc(r.id)}">${r.revoked ? 'Restore' : 'Revoke'}</button><button class="btn sm ghost" data-ext="${esc(r.id)}">Extend</button>` },
        ], { search: list.length > 8, sort: 'state', dir: 1, name: 'licences', after: (w) => {
          $$('[data-rev]', w).forEach((b) => b.addEventListener('click', () => { const l = list.find((x) => x.id === b.dataset.rev); l.revoked = !l.revoked; l.state = l.revoked ? 'revoked' : l.expires && Date.parse(l.expires) < Date.now() ? 'expired' : 'active'; draw(); MC.toast(`${esc(l.id)} ${l.revoked ? 'revoked' : 'restored'}. Download and upload licenses.json to apply.`); }));
          $$('[data-ext]', w).forEach((b) => b.addEventListener('click', () => { const l = list.find((x) => x.id === b.dataset.ext); const base = l.expires && Date.parse(l.expires) > Date.now() ? new Date(l.expires) : new Date(); base.setFullYear(base.getFullYear() + 1); l.expires = base.toISOString().slice(0, 10); if (!l.revoked) l.state = 'active'; draw(); MC.toast(`${esc(l.id)} now expires ${l.expires}. Download and upload licenses.json to apply.`); }));
        } });
        $('#dlReg').addEventListener('click', () => {
          const clean = list.map(({ current, state, ...rest }) => rest);
          downloadText('licenses.json', JSON.stringify({ policy: reg.policy || {}, licenses: clean }, null, 2) + '\n');
          MC.api.audit('license-registry', 'licenses.json exported (' + clean.length + ' entries)');
        });
        $('#issueForm').addEventListener('submit', async (e) => {
          e.preventDefault();
          const btn = $('#issueForm button[type=submit]'); btn.disabled = true;
          try {
            const r = await MC.api.issue({ token: $('#iTok').value.trim(), holder: $('#iHolder').value.trim(), edition: $('#iEd').value, expires: $('#iExp').value || null, maxNodes: $('#iNodes').value || null, id: $('#iId').value.trim() || null, verify: $('#iVerify').checked });
            $('#iTok').value = '';
            $('#iErr').innerHTML = '';
            $('#iOut').innerHTML = `<div class="notice" style="margin-top:12px"><b>Licence key for ${esc(r.entry.holder || r.entry.id)}</b><div class="code" style="margin:8px 0;max-height:none" id="newKey">${esc(r.masked)}</div><div class="actions-row"><button class="btn sm" id="showKey">Show</button><button class="btn sm" id="copyKey">Copy key</button><button class="btn sm primary" id="addEntry">Add to registry</button></div><p class="muted" style="font-size:12px;margin:8px 0 0">Fingerprint <span class="mono">${esc(r.fingerprint)}</span>${r.verified ? ' · GitHub check: ' + esc(r.verified) : ''}. Send the key to the holder over a private channel; it is not kept here once you leave this page.</p></div>`;
            let shown = false;
            $('#showKey').addEventListener('click', (ev) => { shown = !shown; $('#newKey').textContent = shown ? r.key : r.masked; ev.target.textContent = shown ? 'Hide' : 'Show'; });
            $('#copyKey').addEventListener('click', () => copy(r.key, 'Licence key copied'));
            $('#addEntry').addEventListener('click', () => { if (list.some((x) => x.fingerprint === r.entry.fingerprint)) return MC.toast('That key is already registered.', 'err'); list.unshift(Object.assign({}, r.entry, { state: 'active' })); draw(); MC.toast('Entry added. Download licenses.json and upload it to apply.', 'ok'); });
          } catch (x) { $('#iErr').innerHTML = `<div class="notice err" style="margin-bottom:10px">${esc(x.message)}</div>`; }
          btn.disabled = false;
        });
      };
      draw();
    }).catch((e) => { el.innerHTML = `<div class="card panel-c notice err">Could not read the licence registry: ${esc(e.message)}</div>`; });
  }

  function licOverride(el) {
    el.innerHTML = `<div class="grid g2">
      ${MC.panel('Administrator override', '', `<p style="margin-top:0">Without a valid licence the console does not open. The override password is the only way in, for an administrator to activate a new licence or recover from an expired one. Every use is written to the access log.</p>
        <dl class="kv"><dt>Status</dt><dd>${MC.status.overrideConfigured === false ? pill('Warning', 'Not set') : pill('OK', 'Set')}</dd><dt>Storage</dt><dd>Salted scrypt hash in <span class="mono">data\\secrets\\override.json</span>. The password itself is never stored.</dd><dt>From the server</dt><dd><span class="mono">launcher\\Set-MonCastleAdminPassword.ps1</span></dd></dl>`)}
      ${MC.panel('Change the override password', '', `<form id="ovrChg" autocomplete="off">${MC.user.override ? '' : '<div class="field"><label for="oc">Current override password</label><input class="input" id="oc" type="password" autocomplete="off"></div>'}<div class="field"><label for="on">New password</label><input class="input" id="on" type="password" minlength="12" autocomplete="new-password" required><span class="hint">At least 12 characters.</span></div><div class="field"><label for="on2">Repeat</label><input class="input" id="on2" type="password" autocomplete="new-password" required></div><div id="ovErr"></div><button class="btn primary" type="submit">Change password</button></form>`)}
    </div>`;
    $('#ovrChg').addEventListener('submit', async (e) => {
      e.preventDefault();
      if ($('#on').value !== $('#on2').value) { $('#ovErr').innerHTML = '<div class="notice err" style="margin-bottom:10px">The new passwords do not match.</div>'; return; }
      try { await MC.api.setOverridePassword($('#oc') ? $('#oc').value : undefined, $('#on').value); e.target.reset(); $('#ovErr').innerHTML = ''; MC.toast('Override password changed', 'ok'); } catch (x) { $('#ovErr').innerHTML = `<div class="notice err" style="margin-bottom:10px">${esc(x.message)}</div>`; }
    });
  }

  function accessLog(el) {
    el.innerHTML = MC.panel('Access log', 'sign-ins, overrides, views, runs, licence, release and update events', '<div id="alt"></div>');
    MC.api.accessLog().then((r) => {
      MC.table($('#alt'), r.entries || [], [{ key: 'time', label: 'Time', html: (x) => dt(x.time), val: (x) => x.time }, { key: 'event', label: 'Event', html: (x) => pill(/failed|override/.test(x.event) ? 'Warning' : x.event === 'run' ? 'Info' : 'OK', x.event) }, { key: 'user', label: 'User' }, { key: 'ip', label: 'IP', cls: 'mono' }, { key: 'detail', label: 'Detail' }], { sort: 'time', name: 'access-log' });
    }).catch((e) => { $('#alt').innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
  }

  // ================================================================== UPDATES & RELEASES
  V.updates = {
    title: 'Updates & releases',
    crumb: () => 'Console packages from ' + ((MC.status.repos || {}).console || 'RoboMate-MonCastle-Console'),
    render(el) {
      const admin = MC.user.role === 'admin';
      el.innerHTML = `<div class="grid g2">
        ${MC.panel('This console', '', '<div id="upd">Loading…</div>', { act: '<button class="btn sm" id="chk">' + icon('refresh', 'sev-ico') + 'Check now</button>' })}
        ${admin ? MC.panel('Publish a release', 'builds the package for RoboMate-MonCastle-Console', '<div id="pub">Loading…</div>') : MC.panel('Publishing', '', '<p class="muted">Only administrators publish releases.</p>')}
      </div>${admin ? MC.panel('Release folder', 'what is ready to upload', '<div id="rel"></div>') : ''}`;
      const showUpdate = (cur, chk) => {
        const avail = chk && chk.available;
        $('#upd').innerHTML = `<dl class="kv"><dt>Installed</dt><dd><b>${esc(cur.version)}</b>${cur.released ? ' · released ' + dt(cur.released) : ''}</dd><dt>Update source</dt><dd class="mono">${esc((MC.status.repos || {}).console || '')}</dd><dt>Last check</dt><dd>${chk ? ago(chk.checkedAt) : 'not yet'}</dd><dt>Latest</dt><dd>${chk ? esc(chk.latest) + ' ' + (avail ? pill('Info', 'update available') : pill('OK', 'up to date')) : '–'}</dd></dl>
          ${avail ? `<div class="notice" style="margin-top:12px"><b>Version ${esc(chk.latest)}</b>${chk.released ? ' · ' + dt(chk.released) : ''}${chk.size ? ' · ' + fmt(chk.size / 1048576) + ' MB' : ''}<div style="white-space:pre-wrap;margin-top:6px">${esc(chk.notes || '')}</div></div>
            ${admin ? `<div class="actions-row" style="margin-top:12px"><button class="btn primary" id="inst">${icon('download', 'sev-ico')}Install ${esc(chk.latest)}</button></div><p class="muted" style="font-size:12px">The package is downloaded with this console's licence, checked against the SHA-256 in version.json, and the current version is backed up first. Your data folder and config file are not touched. The console restarts by itself.</p>` : '<p class="muted">Ask an administrator to install it.</p>'}` : ''}`;
        if ($('#inst')) $('#inst').addEventListener('click', () => modal(`<h3>Install ${esc(chk.latest)}?</h3><p class="muted">The console restarts when the files are in place. Running jobs are interrupted.</p><div class="field"><label for="cv">Type the version to confirm</label><input class="input mono" id="cv" placeholder="${esc(chk.latest)}"></div><div id="ie"></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Install</button></div>`, (m, close) => {
          $('#go', m).addEventListener('click', async () => {
            if ($('#cv', m).value.trim() !== chk.latest) { $('#ie', m).innerHTML = '<div class="notice err">Type ' + esc(chk.latest) + ' to confirm.</div>'; return; }
            $('#go', m).disabled = true; $('#go', m).textContent = 'Installing…';
            try {
              const r = await MC.api.installUpdate(chk.latest);
              close();
              MC.toast(`Updated ${esc(r.from)} → ${esc(r.to)} (${r.files} files). ${r.restarting ? 'Restarting; the page reloads in a few seconds.' : ''}`, 'ok');
              if (r.restarting) setTimeout(() => location.reload(), 8000); else { MC.status = await MC.api.status(); MC.render(); }
            } catch (x) { $('#ie', m).innerHTML = `<div class="notice err">${esc(x.message)}</div>`; $('#go', m).disabled = false; $('#go', m).textContent = 'Install'; }
          });
        }));
      };
      MC.api.update().then((u) => showUpdate(u.current, u.lastCheck)).catch((e) => { $('#upd').innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
      $('#chk').addEventListener('click', async (e) => {
        e.target.disabled = true;
        try { const c = await MC.api.checkUpdate(); const u = await MC.api.update(); showUpdate(u.current, c); } catch (x) { MC.toast('Update check failed: ' + esc(x.message), 'err'); }
        e.target.disabled = false;
      });
      if (!admin) return;
      MC.api.release().then((r) => {
        const last = (r.published.releases[0] || {}).version || r.current.version;
        const p = String(last).split('.').map((x) => parseInt(x, 10) || 0);
        const next = p[0] + '.' + p[1] + '.' + (p[2] + 1);
        $('#pub').innerHTML = `<form id="pubForm" autocomplete="off">
          <div class="field"><label for="pSrc">Source folder (release version of the app)</label><input class="input mono" id="pSrc" value="${esc(r.defaults.sourceDir || '')}" required></div>
          <div class="field"><label for="pOut">Output folder (local copy of the Console repo)</label><input class="input mono" id="pOut" value="${esc(r.defaults.outputDir || '')}" required></div>
          <div class="grid g2" style="gap:10px"><div class="field"><label for="pVer">New version</label><input class="input mono" id="pVer" value="${esc(next)}" pattern="\\d+\\.\\d+\\.\\d+" required><span class="hint">Published now: ${esc(last)}</span></div><div class="field"><label>Excluded</label><span class="hint" style="padding-top:8px">data, backups, node_modules, .git, dist, logs and config\\moncastle.config.json</span></div></div>
          <div class="field"><label for="pNotes">Release notes</label><textarea class="input" id="pNotes" rows="4" placeholder="What changed, shown to consoles before they update"></textarea></div>
          <div id="pErr"></div>
          <button class="btn primary" type="submit">${icon('box', 'sev-ico')}Build release package</button></form><div id="pOutRes"></div>`;
        const drawRel = (pub) => {
          $('#rel').innerHTML = `<dl class="kv" style="margin-bottom:10px"><dt>Folder</dt><dd class="mono">${esc(pub.outputDir)}</dd><dt>version.json</dt><dd>${pub.latest ? esc(pub.latest.version) + ' · ' + dt(pub.latest.released) + ' · <span class="mono">' + esc((pub.latest.sha256 || '').slice(0, 16)) + '…</span>' : 'not written yet'}</dd><dt>Upload to</dt><dd class="mono">${esc(r.defaults.repo)}</dd></dl><div id="relT"></div>`;
          MC.table($('#relT'), pub.releases, [{ key: 'file', label: 'Package', cls: 'mono' }, { key: 'version', label: 'Version' }, { key: 'size', label: 'MB', n: true, html: (x) => fmt(x.size / 1048576, 2) }, { key: 'modified', label: 'Built', html: (x) => dt(x.modified) }], { search: false, empty: 'No packages in the release folder yet.' });
        };
        drawRel(r.published);
        $('#pubForm').addEventListener('submit', async (e) => {
          e.preventDefault();
          const btn = $('#pubForm button[type=submit]'); btn.disabled = true; btn.textContent = 'Building…';
          try {
            const res = await MC.api.publish({ sourceDir: $('#pSrc').value.trim(), outputDir: $('#pOut').value.trim(), version: $('#pVer').value.trim(), notes: $('#pNotes').value });
            $('#pErr').innerHTML = '';
            $('#pOutRes').innerHTML = `<div class="notice" style="margin-top:12px"><b>Release ${esc(res.manifest.version)} is ready${res.demo ? ' (demo: nothing was written)' : ''}</b>
              <div class="code" style="margin:8px 0">${res.written.map(esc).join('\n')}</div>
              <ol style="margin:6px 0 0;padding-left:18px;font-size:13px"><li>Open <span class="mono">${esc(r.defaults.repo)}</span> on GitHub.</li><li>Upload <span class="mono">version.json</span>, <span class="mono">CHANGELOG.md</span> and <span class="mono">${esc(res.manifest.zip)}</span> from <span class="mono">${esc(res.outputDir)}</span>, keeping the folder layout.</li><li>Consoles see ${esc(res.manifest.version)} at their next update check (every 12 hours, or Check now).</li></ol>
              <p class="muted" style="font-size:12px;margin:8px 0 0">${res.manifest.files} files · ${fmt(res.manifest.size / 1048576, 2)} MB · SHA-256 <span class="mono">${esc(res.manifest.sha256)}</span></p></div>`;
            const again = await MC.api.release($('#pOut').value.trim());
            drawRel(again.published);
          } catch (x) { $('#pErr').innerHTML = `<div class="notice err" style="margin-bottom:10px">${esc(x.message)}</div>`; }
          btn.disabled = false; btn.innerHTML = icon('box', 'sev-ico') + 'Build release package';
        });
      }).catch((e) => { $('#pub').innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
    },
  };

  // ================================================================== SETTINGS
  V.settings = {
    title: 'Settings',
    crumb: () => 'Appearance, data protection and about',
    render(el) {
      const theme = MC.currentTheme();
      el.innerHTML = `<div class="grid g2">
        ${MC.panel('Appearance', '', `<div class="field"><label>Theme</label><div class="seg" id="thm">${[['auto', 'Match system'], ['light', 'Light'], ['dark', 'Dark']].map(([k, t]) => `<button data-t="${k}" class="${theme === k ? 'on' : ''}">${t}</button>`).join('')}</div></div>`)}
        ${MC.panel('About', '', `<dl class="kv"><dt>Product</dt><dd>RoboMate MonCastle ${esc(MC.status.version || '')}</dd><dt>Console ID</dt><dd class="mono">${esc(MC.status.consoleId || '')}</dd><dt>Mode</dt><dd>${MC.api.mode === 'live' ? 'Live, connected to the console server' : 'Demo, generated data'}</dd><dt>Roles</dt><dd><b>reader</b> looks and runs read-only tools · <b>contributor</b> also changes devices and sensors and runs low and medium risk actions · <b>admin</b> runs everything and manages users, credentials, licences and updates. <a href="#/users">Users & permissions</a></dd></dl>`)}
      </div>
      ${(() => { const p = MC.status.protection || {}; return MC.panel('Data protection', 'how MonCastle keeps its files', `<dl class="kv"><dt>Data folder</dt><dd>${p.encrypted ? pill('OK', 'Encrypted') + ' AES-256-GCM, every file the console writes' : pill('Warning', 'Not encrypted') + ' set "encryptData": true in the configuration'}</dd><dt>Key</dt><dd>${p.keyFrom === 'environment' ? 'From MC_MASTER_KEY (not stored on disk)' : 'data\\secrets\\master.key, readable only by the service account and administrators'}</dd><dt>Application files</dt><dd>${p.packaged ? pill('OK', 'Packed') + ' encrypted app.mcpak, checked at every start, run from memory' : pill('Unknown', 'Source tree') + ' development layout (Visual Studio). The user package packs them.'}</dd></dl>
        <p class="muted" style="font-size:12.5px;margin:8px 0 0">The data is opened only by the running console, so reports, exports and archives come from here. Encryption protects copies, backups and a stolen disk; an administrator of this server who can read the key, or the running process, can still reach the data. Keep the key out of backups by setting MC_MASTER_KEY for the service, and limit the MonCastle folder to the service account.</p>`); })()}`;
      $$('#thm button', el).forEach((b) => b.addEventListener('click', () => { MC.applyTheme(b.dataset.t); MC.render(); }));
    },
  };
})(typeof self !== 'undefined' ? self : this);
