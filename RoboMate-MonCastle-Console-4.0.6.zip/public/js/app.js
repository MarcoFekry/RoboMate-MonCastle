/*
 * RoboMate MonCastle - console shell.
 * Launcher (licence -> sign in -> launch), navigation rail, routing, search, drawer, run dialog, jobs, toasts.
 * Views live in views-*.js and register themselves on MC.views.
 */
(function (root) {
  'use strict';
  const C = root.MCCharts, M = root.MCModel;
  const esc = C.esc, fmt = C.fmt;
  const $ = (sel, el) => (el || document).querySelector(sel);
  const $$ = (sel, el) => Array.from((el || document).querySelectorAll(sel));

  // ------------------------------------------------------------------ icons (24px stroke)
  const P = {
    overview: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
    map: '<circle cx="5" cy="6" r="2"/><circle cx="19" cy="6" r="2"/><circle cx="12" cy="18" r="2"/><circle cx="12" cy="10" r="2"/><path d="M7 6h10M6.5 7.5 10.5 9M17.5 7.5 13.5 9M12 12v4"/>',
    activity: '<path d="M3 12h4l3-8 4 16 3-8h4"/>',
    layers: '<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 13 9 5 9-5"/>',
    id: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="11" r="2.5"/><path d="M5.5 16.5c.8-1.6 2-2.4 3.5-2.4s2.7.8 3.5 2.4M15 10h3M15 13h3"/>',
    net: '<rect x="9" y="3" width="6" height="5" rx="1"/><rect x="2" y="16" width="6" height="5" rx="1"/><rect x="16" y="16" width="6" height="5" rx="1"/><path d="M12 8v4M5 16v-2h14v2"/>',
    linux: '<path d="M12 3c-2.5 0-3.5 2.2-3.5 4.5 0 1.6-.5 2.6-1.6 4.2C5.6 13.6 5 15.5 5 17c0 2 1.5 4 7 4s7-2 7-4c0-1.5-.6-3.4-1.9-5.3-1.1-1.6-1.6-2.6-1.6-4.2C15.5 5.2 14.5 3 12 3Z"/><circle cx="10.5" cy="8" r=".6"/><circle cx="13.5" cy="8" r=".6"/><path d="M11 10.5h2"/>',
    box: '<path d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3Z"/><path d="m4 7.5 8 4.5 8-4.5M12 12v9"/>',
    audit: '<path d="M8 3h8l4 4v14H4V3h4Z"/><path d="M8 11h8M8 15h8M8 7h4"/>',
    shield: '<path d="M12 3 4 6v6c0 4.5 3.4 8.2 8 9 4.6-.8 8-4.5 8-9V6l-8-3Z"/><path d="m9 12 2 2 4-4"/>',
    bolt: '<path d="M13 3 5 14h6l-1 7 8-11h-6l1-7Z"/>',
    code: '<path d="m8 8-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M17 6l3 3M14 9l2 2"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M2 12h3M19 12h3M4.9 19.1 7 17M17 7l2.1-2.1"/>',
    server: '<rect x="3" y="4" width="18" height="7" rx="1.5"/><rect x="3" y="13" width="18" height="7" rx="1.5"/><path d="M7 7.5h.01M7 16.5h.01M11 7.5h6M11 16.5h6"/>',
    db: '<ellipse cx="12" cy="5.5" rx="7" ry="2.5"/><path d="M5 5.5v13c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5v-13M5 12c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5"/>',
    printer: '<path d="M7 9V3h10v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M7 14h10v7H7z"/>',
    desktop: '<rect x="3" y="4" width="18" height="12" rx="1.5"/><path d="M8 20h8M12 16v4"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5Z"/>',
    logout: '<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h11"/>',
    refresh: '<path d="M20 11a8 8 0 0 0-14.8-4M4 4v4h4M4 13a8 8 0 0 0 14.8 4M20 20v-4h-4"/>',
    x: '<path d="M6 6l12 12M18 6 6 18"/>',
    alert: '<path d="M12 3 2 20h20L12 3Z"/><path d="M12 10v4M12 17h.01"/>',
    crit: '<circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 16.5h.01"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5h.01"/>',
    check: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
    play: '<path d="M7 4v16l13-8L7 4Z"/>',
    download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
    jobs: '<path d="M4 6h16M4 12h10M4 18h7"/><circle cx="18" cy="17" r="3"/>',
    tree: '<rect x="9" y="3" width="6" height="4" rx="1"/><rect x="3" y="17" width="6" height="4" rx="1"/><rect x="15" y="17" width="6" height="4" rx="1"/><rect x="9" y="10" width="6" height="4" rx="1"/><path d="M12 7v3M12 14v1.5M6 17v-1.5h12V17"/>',
    bell: '<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15L6 16Z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
    plug: '<path d="M9 3v5M15 3v5M6 8h12v3a6 6 0 0 1-12 0V8Z"/><path d="M12 17v4"/>',
    archive: '<rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V9M10 13h4"/>',
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>',
    servers: '<rect x="3" y="3" width="18" height="5" rx="1.2"/><rect x="3" y="10" width="18" height="5" rx="1.2"/><path d="M7 5.5h.01M7 12.5h.01M12 15v3M6 21h12M12 18v3"/>',
    radar: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><path d="M12 12 18 6"/><circle cx="12" cy="12" r="1"/>',
    send: '<path d="M21 3 3 10.5l7 2.5 2.5 7L21 3Z"/><path d="m10 13 4-4"/>',
    cloud: '<path d="M7 18a4 4 0 0 1-.6-8A6 6 0 0 1 18 9a4.5 4.5 0 0 1-.5 9H7Z"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.4 3.3-5.5 6.5-5.5s5.7 2.1 6.5 5.5"/><path d="M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14.8c1.8.8 3 2.6 3.5 5.2"/>',
    lock: '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/>',
    sliders: '<path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/>',
    gauge: '<path d="M3.5 17a9 9 0 1 1 17 0"/><path d="m12 13 4-5"/><circle cx="12" cy="13" r="1.3"/>',
    report: '<path d="M6 3h9l4 4v14H6V3Z"/><path d="M9 17v-3M12 17v-6M15 17v-4"/>',
  };
  const icon = (name, cls) => `<svg class="${cls || ''}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[name] || P.info}</svg>`;
  const CAT_ICON = { identity: 'id', servers: 'server', virtualization: 'layers', databases: 'db', network: 'net', linux: 'linux', printers: 'printer', workstations: 'desktop' };
  const SEV_ICON = { Critical: 'crit', Offline: 'crit', Warning: 'alert', Info: 'info', OK: 'check' };
  const sevIcon = (s) => `<span style="color:var(${C.STATUS[s] || '--muted'})">${icon(SEV_ICON[s] || 'info', 'sev-ico')}</span>`;
  const pill = (s, text) => `<span class="pill ${esc(s || 'Unknown')}">${esc(text || s || 'Unknown')}</span>`;
  const ago = (t) => {
    if (!t) return '–';
    const s = (Date.now() - Date.parse(t)) / 1000;
    if (s < 0) return 'in ' + (s > -3600 ? Math.round(-s / 60) + 'm' : s > -86400 ? Math.round(-s / 3600) + 'h' : Math.round(-s / 86400) + 'd');
    if (s < 60) return Math.round(s) + 's ago';
    if (s < 3600) return Math.round(s / 60) + 'm ago';
    if (s < 86400) return Math.round(s / 3600) + 'h ago';
    return Math.round(s / 86400) + 'd ago';
  };
  const dt = (t) => (t ? new Date(t).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '–');
  const minibar = (v, warn = 75, crit = 90) => {
    if (v == null || isNaN(v)) return '<span class="muted">–</span>';
    const c = v >= crit ? '--crit' : v >= warn ? '--warn' : '--s1';
    return `<span class="minibar"><i><b style="width:${Math.min(100, v)}%;background:var(${c})"></b></i><span>${fmt(v, 0)}%</span></span>`;
  };

  // ------------------------------------------------------------------ app state
  const MC = {
    api: null, status: null, ds: {}, model: null, summary: null, manifest: { scripts: [] }, history: null,
    route: { page: 'overview', tab: null, q: {} }, views: {}, jobs: [], user: null,
    $, $$, icon, pill, sevIcon, esc, fmt, ago, dt, minibar, CAT_ICON,
    // datasets read while a page renders are noted, so the page can say which engine to turn on when one is empty
    data: (id) => { if (MC._reads) MC._reads.add(id); return (MC.ds[id] && MC.ds[id].data) || []; },
    script: (id) => MC.manifest.scripts.find((s) => s.id === id),
  };
  root.MC = MC;

  // ------------------------------------------------------------------ theme
  const THEME_KEY = 'mc.theme';
  function applyTheme(t) {
    const html = document.documentElement;
    if (t === 'light' || t === 'dark') html.setAttribute('data-theme', t); else html.removeAttribute('data-theme');
    try { localStorage.setItem(THEME_KEY, t); } catch (e) { /* storage blocked */ }
  }
  function currentTheme() { try { return localStorage.getItem(THEME_KEY) || 'auto'; } catch (e) { return 'auto'; } }
  function isDark() {
    const t = document.documentElement.getAttribute('data-theme');
    return t ? t === 'dark' : root.matchMedia && root.matchMedia('(prefers-color-scheme: dark)').matches;
  }
  MC.applyTheme = applyTheme; MC.currentTheme = currentTheme;

  // ------------------------------------------------------------------ toasts
  function toast(msg, kind, ms) {
    let box = $('.toast');
    if (!box) { box = document.createElement('div'); box.className = 'toast'; box.setAttribute('role', 'status'); document.body.appendChild(box); }
    const d = document.createElement('div');
    d.className = kind || '';
    d.innerHTML = msg;
    box.appendChild(d);
    setTimeout(() => d.remove(), ms || (kind === 'err' ? 7000 : 4200));
  }
  MC.toast = toast;

  // ------------------------------------------------------------------ boot
  async function boot() {
    if (MC._booted) return;
    MC._booted = true;
    applyTheme(currentTheme());
    MC.api = await root.MCApi.connect();
    MC.status = await MC.api.status();
    MC.user = MC.status.user;
    try { MC.manifest = await MC.api.scripts(); } catch (e) { MC.manifest = root.MC_MANIFEST || { scripts: [] }; }
    const lic = MC.status.license || {};
    if ((lic.state === 'valid' || lic.state === 'grace' || (MC.user && MC.user.override)) && MC.user) { await loadData(); return launch(true); }
    renderLauncher();
  }

  async function loadData() {
    MC.ds = await MC.api.datasets();
    try { MC.devices = ((await MC.api.monitor('tree')) || {}).devices || []; } catch (e) { MC.devices = MC.devices || []; }
    MC.model = M.build(MC.ds, MC.devices);
    MC.summary = M.summarize(MC.model);
    try { MC.history = await MC.api.history(24); } catch (e) { MC.history = {}; }
  }
  MC.reload = async function () {
    await loadData();
    renderRail();
    render();
    toast('Data refreshed · ' + new Date().toLocaleTimeString(), 'ok');
  };

  // ------------------------------------------------------------------ launcher
  function coverage() {
    const sc = MC.manifest.scripts || [];
    return [
      [sc.length || 56, 'scripts'],
      [sc.filter((s) => s.kind === 'collector').length || 34, 'collectors'],
      [sc.filter((s) => s.kind === 'action').length || 13, 'actions'],
      [8, 'resource areas'],
    ];
  }
  // the browser's password manager: offer to save the sign-in (Chrome, Edge; Firefox and Safari offer it from the form),
  // and sign in again without typing when the user let the browser do that (mediation 'silent')
  function saveCredential(id, password) {
    try { if (root.PasswordCredential && navigator.credentials && id && password) navigator.credentials.store(new root.PasswordCredential({ id, password, name: id + ' · RoboMate MonCastle' })).catch(() => {}); } catch (e) { /* not supported */ }
  }
  async function savedCredential() {
    try { if (!root.PasswordCredential || !navigator.credentials) return null; return await navigator.credentials.get({ password: true, mediation: 'silent' }); } catch (e) { return null; }
  }
  MC.forgetAutoSignIn = () => { try { if (navigator.credentials && navigator.credentials.preventSilentAccess) navigator.credentials.preventSilentAccess(); } catch (e) { /* not supported */ } };

  function renderLauncher(step) {
    const lic = MC.status.license || {};
    const needLic = !(lic.state === 'valid' || lic.state === 'grace') && !(MC.user && MC.user.override);
    step = step || (needLic ? 'license' : MC.status.setupRequired ? 'setup' : !MC.user ? 'login' : 'launch');
    const idx = { license: 0, setup: 1, login: 1, launch: 2 }[step];
    const demo = MC.api.mode !== 'live';
    document.title = 'RoboMate MonCastle';
    $('#app').innerHTML = `
    <div class="launcher">
      <section class="brandside">
        <div>
          <div class="brandmark"><img src="img/moncastle-logo.svg" alt=""><div class="wm"><small>RoboMate</small><b>MonCastle</b></div></div>
          <div style="margin-top:56px">
            <h1>Every server, service and signal in one console.</h1>
            <p class="lede">Inventory, monitoring, audit and remediation for Active Directory, Windows servers and workstations, Hyper-V and VMware, SQL, printers, network devices and Linux. Scripts are pulled from your verified repository and run on demand or on schedule.</p>
            <div class="coverage">${coverage().map(([n, l]) => `<div><b>${n}</b><span>${l}</span></div>`).join('')}</div>
          </div>
        </div>
        <div class="poweredby"><img src="img/robomate-emblem.png" alt="">Part of the RoboMate family · v${esc(MC.status.version || '4.0.0')}${demo ? ' · demo environment' : ''}</div>
      </section>
      <section class="panel">
        <div class="gate">
          <div class="steps" aria-hidden="true">${[0, 1, 2].map((i) => `<span class="${i <= idx ? 'on' : ''}"></span>`).join('')}</div>
          <div id="gate"></div>
        </div>
      </section>
    </div>`;
    const g = $('#gate');
    if (step === 'license') {
      g.innerHTML = `
        <h2>Activate your licence</h2>
        <p class="sub">Enter your MonCastle licence key. Only keys that start with <span class="mono">320RMC</span> are accepted. The key is verified against <span class="mono">RoboMate-MonCastle-Licenses</span>, stored encrypted on the console server and only ever shown masked.</p>
        <form class="card" id="licForm" autocomplete="off">
          <div class="field"><label for="tok">Licence key</label>
            <input class="input mono" id="tok" type="password" spellcheck="false" autocomplete="off" placeholder="320RMC…">
            <span class="hint">It is checked against the licence repository and re-checked every 6 hours, with a 72-hour offline grace period. It is shown masked as 320RMC••••••••abcd.</span></div>
          <div id="licErr"></div>
          <button class="btn primary block" type="submit">${icon('key')}Verify licence</button>
          ${demo ? '<button class="btn ghost block" type="button" id="demoLic" style="margin-top:8px">Use the demo licence</button>' : ''}
        </form>
        <p style="margin:14px 0 0;font-size:13px"><a href="#" id="ovrLink">Administrator override</a> <span class="muted">opens the console without a licence, for administrators only.</span></p>
        <form class="card" id="ovrForm" hidden style="margin-top:10px;padding:18px" autocomplete="off">
          <div class="field"><label for="ovp">Override password</label><input class="input" id="ovp" type="password" autocomplete="off" ${demo ? 'placeholder="Demo: MonCastle!demo"' : ''}><span class="hint">${MC.status.overrideConfigured === false ? 'No override password is set on this console. Run launcher\\Set-MonCastleAdminPassword.ps1 on the server.' : 'Every use is written to the access log.'}</span></div>
          <div id="ovrErr"></div>
          <button class="btn danger block" type="submit">Open with override</button>
        </form>
        ${demo ? '<p class="sub" style="margin-top:14px;font-size:12.5px">Demo environment: licence checks are simulated and nothing leaves your browser. The console server performs the real check.</p>' : ''}`;
      const go = async (tok) => {
        const btn = $('#licForm button[type=submit]');
        btn.disabled = true; btn.innerHTML = 'Checking licence…';
        try {
          MC.status.license = await MC.api.license(tok);
          MC.status = await MC.api.status();
          renderLauncher();
        } catch (e) {
          $('#licErr').innerHTML = `<div class="notice err" style="margin-bottom:12px">${esc(e.message)}</div>`;
          btn.disabled = false; btn.innerHTML = icon('key') + 'Verify licence';
        }
      };
      $('#licForm').addEventListener('submit', (e) => { e.preventDefault(); const v = $('#tok').value.trim(); if (!v) { $('#licErr').innerHTML = '<div class="notice err" style="margin-bottom:12px">Paste the licence token first.</div>'; return; } go(v); });
      if ($('#demoLic')) $('#demoLic').addEventListener('click', () => go(''));
      $('#ovrLink').addEventListener('click', (e) => { e.preventDefault(); $('#ovrForm').hidden = !$('#ovrForm').hidden; if (!$('#ovrForm').hidden) $('#ovp').focus(); });
      $('#ovrForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = $('#ovrForm button'); btn.disabled = true;
        try {
          const r = await MC.api.override($('#ovp').value);
          MC.status = await MC.api.status();
          MC.user = (MC.status && MC.status.user) || r.user;
          await loadData();
          renderLauncher('launch');
        } catch (err) { $('#ovrErr').innerHTML = `<div class="notice err" style="margin-bottom:12px">${esc(err.message)}</div>`; btn.disabled = false; }
      });
      setTimeout(() => $('#tok') && $('#tok').focus(), 50);
    } else if (step === 'setup' || step === 'login') {
      const setup = step === 'setup';
      g.innerHTML = `
        ${licChip()}
        <h2>${setup ? 'Create the first administrator' : 'Sign in'}</h2>
        <p class="sub">${setup ? 'This account manages users, licence and high-risk actions. Use a long passphrase.' : 'Use your MonCastle console account.'}</p>
        <form class="card" id="loginForm" method="post" action="#" autocomplete="on">
          <div class="field"><label for="u">User name</label><input class="input" id="u" name="username" autocomplete="username" value="${demo ? 'admin' : ''}" required></div>
          <div class="field"><label for="p">Password</label><input class="input" id="p" name="password" type="password" autocomplete="${setup ? 'new-password' : 'current-password'}" ${demo ? 'value="MonCastle!demo"' : ''} required minlength="${setup ? 12 : 1}">${setup ? '<span class="hint">At least 12 characters.</span>' : ''}</div>
          ${setup ? '' : '<label class="check" style="margin:0 0 12px"><input type="checkbox" id="remember" name="remember"> Keep me signed in on this computer for 30 days</label>'}
          <div id="loginErr"></div>
          <button class="btn primary block" type="submit">${setup ? 'Create administrator' : 'Sign in'}</button>
        </form>
        ${demo ? '<p class="sub" style="margin-top:14px;font-size:12.5px">Demo accounts: <span class="mono">admin</span> (admin), <span class="mono">noc.operator</span> (contributor), <span class="mono">auditor</span> (reader) and <span class="mono">branch.helpdesk</span> (restricted to network devices and printers), all with password <span class="mono">MonCastle!demo</span>.</p>' : ''}`;
      $('#loginForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = $('#loginForm button');
        btn.disabled = true;
        try {
          const r = setup ? await MC.api.setup($('#u').value.trim(), $('#p').value) : await MC.api.login($('#u').value.trim(), $('#p').value, ($('#remember') || {}).checked);
          saveCredential($('#u').value.trim(), $('#p').value);
          MC.status = await MC.api.status();
          MC.user = (MC.status && MC.status.user) || r.user;
          await loadData();
          renderLauncher('launch');
        } catch (err) {
          if (err.status === 402) { MC.status = await MC.api.status(); return renderLauncher('license'); }
          $('#loginErr').innerHTML = `<div class="notice err" style="margin-bottom:12px">${esc(err.message)}</div>`;
          btn.disabled = false;
        }
      });
      // saved sign-in: the browser hands it over without asking only when the user allowed automatic sign-in
      if (!setup && !demo) savedCredential().then((c) => { const f = $('#loginForm'); if (c && c.password && f && !$('#u').value) { $('#u').value = c.id; $('#p').value = c.password; f.requestSubmit(); } });
    } else {
      const s = MC.summary;
      const crit = (s.counts.Critical || 0) + (s.counts.Offline || 0);
      const mods = [
        ['overview', 'overview', 'Overview', s.total + ' resources · ' + crit + ' critical'],
        ['map', 'map', 'Resource map', s.categories.filter((c) => c.total).length + ' categories'],
        ['monitoring', 'activity', 'Monitoring', MC.data('servers.compute').length + ' servers live'],
        ['security', 'shield', 'Security', MC.model.insights.filter((i) => i.area === 'Security').length + ' findings'],
        ['audit', 'audit', 'Audit', MC.data('audit.events').length + ' events'],
        ['actions', 'bolt', 'Actions', (MC.manifest.scripts || []).filter((x) => x.kind !== 'collector').length + ' runnable'],
      ];
      g.innerHTML = `
        ${licChip()}
        <h2>Welcome, ${esc(MC.user.name)}</h2>
        <p class="sub">Signed in as ${esc(MC.user.role)}. ${crit ? `<b style="color:var(--crit-ink)">${crit} resources need attention.</b>` : 'Everything is healthy.'} Pick where to start.</p>
        <div class="modules">${mods.map(([r, ic, t, sub]) => `<button class="module" data-go="${r}">${icon(ic, 'ic')}<b>${t}</b><small>${esc(sub)}</small></button>`).join('')}</div>
        <button class="btn primary block" data-go="overview">${icon('play')}Open console</button>
        <div style="display:flex;justify-content:space-between;margin-top:12px;font-size:12.5px" class="muted"><span>${esc(MC.status.scripts ? MC.status.scripts.count + ' scripts from ' + (MC.status.repos ? MC.status.repos.scripts : 'GitHub') : '')}</span><a href="#" id="signout">Sign out</a></div>`;
      $$('[data-go]', g).forEach((b) => b.addEventListener('click', () => { location.hash = '#/' + b.dataset.go; launch(); }));
      $('#signout').addEventListener('click', async (e) => { e.preventDefault(); MC.forgetAutoSignIn(); await MC.api.logout(); MC.user = null; renderLauncher('login'); });
    }
  }
  function licChip() {
    const l = MC.status.license || {};
    if (MC.user && MC.user.override && !(l.state === 'valid' || l.state === 'grace')) return `<div class="lic-chip">${icon('alert', 'sev-ico')}<span>No valid licence</span><span style="margin-left:auto">${pill('Critical', 'Administrator override')}</span></div>`;
    return `<div class="lic-chip">${icon('key', 'sev-ico')}<span>Licence</span><span class="k">${esc(l.masked || '')}</span><span style="margin-left:auto">${pill(l.state === 'valid' ? 'OK' : 'Warning', l.state === 'valid' ? (l.edition || 'Valid') : 'Offline grace')}</span></div>`;
  }

  // ------------------------------------------------------------------ shell
  // Insight (dashboards, reports) > Configure (what is monitored and who hears about it) > Monitoring (every monitored
  // resource, each page split into devices found by engines and devices you added) > Inventory > Actions > Administrate.
  // Entries may point at a tab (page/tab).
  const NAV = [
    ['Insight', [['dashboards', 'gauge', 'Dashboards'], ['reports', 'report', 'Reports']]],
    ['Configure', [['overview', 'overview', 'Overview'], ['sensors', 'tree', 'Devices & sensors'], ['discovery', 'radar', 'Auto-discovery'], ['profiles', 'sliders', 'Monitoring profiles'], ['connectors', 'plug', 'Sensor types'], ['notifications', 'send', 'Notifications'], ['integrations', 'download', 'Alert integrations'], ['credentials', 'lock', 'Credentials']]],
    ['Monitoring', [['alarms', 'bell', 'Alarms'], ['monitoring', 'server', 'Windows servers'], ['identity', 'id', 'Active Directory'], ['entra', 'cloud', 'Entra ID & Intune'], ['virtualization', 'layers', 'Virtualization'], ['virtualization/vms', 'desktop', 'Virtual machines'], ['network', 'net', 'Network'], ['linux', 'linux', 'Linux'], ['monitoring/storage', 'db', 'Storage'], ['databases', 'db', 'Databases'], ['containers', 'box', 'Containers & Kubernetes'], ['web', 'cloud', 'Web servers'], ['security', 'shield', 'Security']]],
    ['Inventory', [['inventory', 'box', 'Inventory'], ['map', 'map', 'Resource map'], ['osupdates', 'download', 'OS updates'], ['compliance', 'check', 'Compliance'], ['audit', 'audit', 'Audit']]],
    ['Actions', [['groups', 'grid', 'Groups'], ['actions', 'bolt', 'Actions & jobs'], ['actions/myjobs', 'jobs', 'My jobs'], ['engines', 'play', 'Monitoring engines'], ['remote', 'code', 'Remote scripting']]],
    ['Administrate', [['users', 'users', 'Users & permissions'], ['retention', 'archive', 'Data retention'], ['servers', 'servers', 'MonCastle servers'], ['access', 'key', 'Licences & access'], ['updates', 'cloud', 'Updates & releases'], ['settings', 'settings', 'Settings']]],
  ];
  // pages without their own menu entry light up the entry they now live under
  const NAV_ALIAS = { library: 'remote', 'services/dns': 'identity/dns', 'services/dhcp': 'identity/dhcp', 'services/files': 'identity/files', 'services': 'identity', 'monitoring/sql': 'identity/databases', 'monitoring/printers': 'identity/printers', device: 'sensors', sensor: 'sensors' };
  const AREA_PAGE = { Availability: 'monitoring', Storage: 'monitoring', Performance: 'monitoring', Services: 'monitoring', 'Active Directory': 'identity', Identity: 'identity', Security: 'security', Patching: 'security', Network: 'network', Virtualization: 'virtualization', Databases: 'databases', Linux: 'linux', Printers: 'monitoring', Containers: 'containers', EntraID: 'entra', Intune: 'entra', 'Entra ID & Intune': 'entra', 'Cloud network': 'network', Web: 'web', Hardware: 'monitoring' };
  MC.AREA_PAGE = AREA_PAGE;

  function launch() {
    MC.api.audit && MC.api.audit('view', 'Console opened');
    $('#app').innerHTML = `
    <div class="shell">
      <nav class="rail" id="rail" aria-label="Main"></nav>
      <div class="main">
        <header class="topbar">
          <button class="iconbtn menu" id="menuBtn" aria-label="Menu">${icon('menu')}</button>
          <div><h1 id="pageTitle">Overview</h1><div class="crumb hide-sm" id="crumb"></div></div>
          <div class="spacer"></div>
          <div class="search"><span>${icon('search')}</span><input class="input" id="q" placeholder="Search servers, IPs, users, scripts…" autocomplete="off" aria-label="Search"><div class="results card" id="qres" hidden></div></div>
          ${MC.user.override ? `<span class="chip" style="background:color-mix(in srgb,var(--crit) 18%,var(--surface))" title="Signed in with the administrator override">Override</span>` : ''}
          <span class="chip ${MC.api.mode === 'live' ? 'live' : 'demo'} hide-sm" title="${MC.api.mode === 'live' ? 'Connected to the console server' : 'Demo data generated in the browser'}">${MC.api.mode === 'live' ? 'Live' : 'Demo data'}</span>
          <button class="iconbtn" id="refreshBtn" title="Refresh data" aria-label="Refresh data">${icon('refresh')}</button>
          <button class="iconbtn" id="themeBtn" title="Toggle theme" aria-label="Toggle theme">${icon(isDark() ? 'sun' : 'moon')}</button>
          <button class="iconbtn" id="outBtn" title="Sign out ${esc(MC.user.name)}" aria-label="Sign out">${icon('logout')}</button>
        </header>
        <main class="content" id="view"></main>
      </div>
    </div>`;
    renderRail();
    // the browser tab always reads "<page> - RoboMate MonCastle", also when a view renames itself
    const pt = $('#pageTitle');
    new MutationObserver(() => { document.title = pt.textContent.trim() + ' - RoboMate MonCastle'; }).observe(pt, { childList: true, characterData: true, subtree: true });
    $('#menuBtn').addEventListener('click', () => $('#rail').classList.toggle('open'));
    $('#refreshBtn').addEventListener('click', () => MC.reload());
    $('#themeBtn').addEventListener('click', () => { applyTheme(isDark() ? 'light' : 'dark'); $('#themeBtn').innerHTML = icon(isDark() ? 'sun' : 'moon'); render(); });
    $('#outBtn').addEventListener('click', async () => { MC.forgetAutoSignIn(); await MC.api.logout(); MC.user = null; location.hash = ''; renderLauncher('login'); });
    setupSearch();
    // dialogs belong to the page they were opened on
    root.onhashchange = () => { parseRoute(); $('#rail').classList.remove('open'); $$('.modal').forEach((x) => x.remove()); render(); };
    document.addEventListener('keydown', (e) => { if (e.key !== 'Escape' || (e.target.closest && e.target.closest('.modal'))) return; const ms = $$('.modal'); const top = ms[ms.length - 1]; if (top) { const x = $('[data-x]', top); if (x) x.click(); else top.remove(); } });
    if (!location.hash) location.hash = '#/overview';
    parseRoute();
    render();
    startJobPoller();
  }

  function renderRail() {
    const rail = $('#rail');
    if (!rail) return;
    const ins = MC.model.insights;
    const cnt = (page) => {
      const list = ins.filter((i) => (AREA_PAGE[i.area] || 'overview') === page);
      const c = list.filter((i) => i.sev === 'Critical').length, w = list.filter((i) => i.sev === 'Warning').length;
      return c ? `<span class="cnt">${c}</span>` : w ? `<span class="cnt w">${w}</span>` : '';
    };
    const lic = MC.status.license || {};
    rail.innerHTML = `
      <div class="brandmark"><img src="img/moncastle-logo.svg" alt=""><div class="wm"><small>RoboMate</small><b>MonCastle</b></div></div>
      ${NAV.map(([g, items]) => `<div class="nav-group">${g}</div><div class="nav">${items.map(([r, ic, t]) => `<a href="#/${r}" data-r="${r}">${icon(ic)}<span>${t}</span>${cnt(r)}</a>`).join('')}</div>`).join('')}
      <div class="foot"><div>${esc(MC.user.name)} · ${esc(root.MCRbac ? root.MCRbac.norm(MC.user.role) : MC.user.role)}${MC.user.restricted ? ' (restricted)' : ''}</div><div class="lic" title="Licence token (masked)">${esc(lic.masked || '')}</div><div>${esc(lic.edition || '')}</div></div>`;
    markNav();
  }
  function markNav() {
    const raw = MC.route.page + (MC.route.tab ? '/' + MC.route.tab : '');
    const alias = NAV_ALIAS[raw] || NAV_ALIAS[MC.route.page] || raw;
    const [page, tab] = alias.split('/');
    const links = $$('.nav a'), full = page + '/' + (tab || '');
    // the entry for this exact tab, else the page's own entry, else the page's first tab entry
    const hit = links.find((a) => a.dataset.r === full) || links.find((a) => a.dataset.r === page) || links.find((a) => a.dataset.r.split('/')[0] === page);
    links.forEach((a) => a.classList.toggle('on', a === hit));
  }

  function parseRoute() {
    const h = location.hash.replace(/^#\/?/, '');
    const [path, qs] = h.split('?');
    const parts = path.split('/').filter(Boolean);
    const q = {};
    (qs || '').split('&').filter(Boolean).forEach((kv) => { const [k, v] = kv.split('='); q[decodeURIComponent(k)] = decodeURIComponent(v || ''); });
    MC.route = { page: parts[0] || 'overview', tab: parts[1] || null, q };
  }
  MC.go = (page, tab, q) => {
    const qs = q ? '?' + Object.entries(q).filter(([, v]) => v != null && v !== '').map(([k, v]) => encodeURIComponent(k) + '=' + encodeURIComponent(v)).join('&') : '';
    location.hash = '#/' + page + (tab ? '/' + tab : '') + (qs.length > 1 ? qs : '');
  };

  function render() {
    const v = MC.views[MC.route.page] || MC.views.overview;
    const el = $('#view');
    if (!el) return;
    C.hideTip();
    MC.renderSeq = (MC.renderSeq || 0) + 1;
    el.innerHTML = '';
    $('#pageTitle').textContent = v.title;
    $('#crumb').textContent = v.crumb ? v.crumb() : '';
    document.title = v.title + ' - RoboMate MonCastle';
    markNav();
    MC._reads = new Set();
    // Monitoring pages: Overview | Found by engines | Manually added, above the page
    // every render gets a fresh container, so timers and late answers of the previous page (which check that their
    // container is still in the document) stop instead of drawing over this page
    let mode = '';
    if (MC.sourceView && MC.views[MC.route.page] && MC.sourceView.key(MC.route)) mode = MC.sourceView.bar(el, MC.route);
    const body = document.createElement('div'); body.className = 'view-body'; el.appendChild(body);
    try { if (mode) MC.sourceView.list(body, MC.route, mode); else { v.render(body, MC.route); if (MC.sourceView) MC.sourceView.combined(body, MC.route); } } catch (e) { console.error(e); body.innerHTML = `<div class="card panel-c notice err">This view failed to render: ${esc(e.message)}</div>`; }
    const reads = MC._reads; MC._reads = null;
    if (!mode) engineNotice(body, reads, MC.renderSeq);
    el.scrollTop = 0;
    window.scrollTo(0, 0);
    wireLinks(el);
  }
  MC.render = render;
  // re-read the datasets after a short wait (inventory of a device that was just onboarded)
  MC.refreshDatasets = (ms) => new Promise((done) => setTimeout(async () => { try { MC.ds = await MC.api.datasets(); try { MC.devices = (await MC.api.monitor('tree')).devices || []; } catch (e) { /* keep */ } MC.model = M.build(MC.ds, MC.devices); MC.summary = M.summarize(MC.model); } catch (e) { /* keep the old ones */ } done(); }, ms || 0));

  // Pages built from engine data: when a dataset the page uses is empty, say which monitoring engine collects it and
  // offer to turn it on (administrators) or open Monitoring engines.
  let engCache = null;
  async function engineNotice(el, reads, seq) {
    const empty = [...(reads || [])].filter((id) => !(MC.ds[id] && (MC.ds[id].data || []).length));
    if (!empty.length) return;
    const byDs = new Map();
    for (const id of empty) { const s = (MC.manifest.scripts || []).filter((x) => x.kind === 'collector' && x.dataset === id); if (s.length) byDs.set(id, s); }
    if (!byDs.size) return;
    let list = [];
    try { if (!engCache || Date.now() - engCache.at > 30000) engCache = { at: Date.now(), r: await MC.api.engines() }; list = engCache.r.engines || []; } catch (e) { /* no access to engines: still name them */ }
    if (seq !== MC.renderSeq || !document.body.contains(el)) return;
    const admin = MC.user && (MC.user.role === 'admin' || MC.user.override);
    const engs = [...new Map([...byDs.values()].flat().map((s) => [s.id, s])).values()];
    const rows = engs.map((s) => {
      const e = list.find((x) => x.id === s.id) || {};
      const nc = e.state === 'Not configured', fam = root.MCEngineScope ? root.MCEngineScope.familyOf(s) : null;
      if (nc && fam) return `<li><b>${esc(s.title || s.id)}</b> <span class="mono muted">${esc(s.id)}</span> is not configured: choose the devices or groups it reads${admin ? ` <a class="btn sm primary" href="#/engines/${encodeURIComponent(s.id)}?view=targets">Configure targets</a>` : ''}</li>`;
      const off = e.state === 'Disabled' || nc || !e.state;
      const why = nc ? 'is not configured' : off ? 'is turned off' : e.state === 'Running' ? 'is collecting now' : e.lastStatus === 'error' ? 'failed on its last run' + (e.message ? ': ' + e.message : '') : e.lastRun ? 'has reported no rows yet' : 'has not run yet';
      return `<li><b>${esc(s.title || s.id)}</b> <span class="mono muted">${esc(s.id)}</span> ${esc(why)}${admin ? (off ? ` <button class="btn sm primary" data-eng-on="${esc(s.id)}">Turn on and run</button>` : e.state !== 'Running' ? ` <button class="btn sm" data-eng-run="${esc(s.id)}">Run now</button>` : '') : ''}</li>`;
    });
    const box = document.createElement('div');
    box.className = 'notice engine-need';
    box.setAttribute('role', 'status');
    box.innerHTML = `${icon('info', 'sev-ico')}<div><b>${engs.length > 1 ? 'Turn on these monitoring engines' : 'Turn on the monitoring engine'} to discover the data for this page.</b> ${empty.length > 1 ? 'Some sections' : 'A section'} of this page ${empty.length > 1 ? 'are' : 'is'} empty because ${engs.length > 1 ? 'these engines have' : 'this engine has'} not collected anything yet:<ul>${rows.slice(0, 6).join('')}${rows.length > 6 ? `<li class="muted">and ${rows.length - 6} more</li>` : ''}</ul>${admin ? '' : 'Ask an administrator to turn it on. '}<a href="#/engines">Open Monitoring engines</a></div>`;
    el.prepend(box);
    const act = async (id, on) => {
      try {
        if (on) await MC.api.engineAction('enable', id);
        await MC.api.engineAction('start', id);
        engCache = null;
        toast(esc((MC.script(id) || {}).title || id) + ' is running. The page fills in when it reports.', 'ok');
        box.remove();
      } catch (e) { toast(esc(e.message), 'err'); }
    };
    $$('[data-eng-on]', box).forEach((b) => b.addEventListener('click', () => act(b.dataset.engOn, true)));
    $$('[data-eng-run]', box).forEach((b) => b.addEventListener('click', () => act(b.dataset.engRun, false)));
  }

  // links inside views: data-res opens the drawer, data-run opens the run dialog, data-href navigates
  function wireLinks(el) {
    if (el._wired) return;
    el._wired = true;
    el.addEventListener('click', (e) => {
      const t = e.target.closest('[data-res],[data-run],[data-href],[data-host]');
      if (!t || !el.contains(t)) return;
      if (t.dataset.res) { e.preventDefault(); openResource(t.dataset.res); }
      else if (t.dataset.host) { e.preventDefault(); openHost(t.dataset.host); }
      else if (t.dataset.run) { e.preventDefault(); runDialog(t.dataset.run, t.dataset.params ? JSON.parse(t.dataset.params) : {}); }
      else if (t.dataset.href) { e.preventDefault(); location.hash = t.dataset.href; }
    });
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.matches('[data-res],[data-href],[data-host]')) e.target.click(); });
  }
  MC.wireLinks = wireLinks;
  // find a resource by host name and open it
  function openHost(name) {
    const n = String(name || '').toUpperCase().split('.')[0];
    const r = MC.model.resources.find((x) => !x.linked && x.name.toUpperCase() === n) || MC.model.resources.find((x) => x.name.toUpperCase() === n);
    if (r) openResource(r.id); else toast('No resource called ' + esc(name), 'err');
  }
  MC.openHost = openHost;
  MC.runAttr = (id, params) => `data-run="${esc(id)}" data-params="${esc(JSON.stringify(params || {}))}"`;

  // ------------------------------------------------------------------ search
  function setupSearch() {
    const q = $('#q'), box = $('#qres');
    let items = [], sel = 0;
    const extra = [['identity/dns', 'DNS servers'], ['identity/dhcp', 'DHCP scopes'], ['identity/files', 'File servers'], ['identity/dfs', 'DFS servers'], ['identity/printers', 'Print servers'], ['identity/ca', 'Certificate Authority'], ['identity/iis', 'IIS servers'], ['identity/databases', 'SQL Server and databases'], ['identity/roles', 'AD-integrated servers'], ['identity/users', 'AD users'], ['identity/computers', 'AD computers'], ['identity/gpo', 'Group Policy']].map(([r, t]) => ['', [[r, '', t]]]);
    const pages = NAV.concat(extra).flatMap(([sec, it]) => it.map((x) => x.concat(sec))).map(([r, ic, t, sec]) => ({ type: 'Page', label: t, sub: sec || 'Monitoring › Active Directory', go: () => MC.go(...r.split('/')) }));
    function update() {
      const s = q.value.trim().toLowerCase();
      if (s.length < 2) { box.hidden = true; return; }
      const res = MC.model.resources.filter((r) => !r.linked && (r.name.toLowerCase().includes(s) || (r.ip || '').startsWith(s) || (r.os || '').toLowerCase().includes(s) || (r.model || '').toLowerCase().includes(s))).slice(0, 8)
        .map((r) => ({ type: r.kind, label: r.name, sub: [r.ip, r.group].filter(Boolean).join(' · '), status: r.status, go: () => openResource(r.id) }));
      const users = MC.data('ad.users').filter((u) => u.SamAccountName.toLowerCase().includes(s) || (u.DisplayName || '').toLowerCase().includes(s)).slice(0, 4)
        .map((u) => ({ type: 'user', label: u.DisplayName + ' (' + u.SamAccountName + ')', sub: u.Department + (u.LockedOut ? ' · locked out' : ''), status: u.LockedOut ? 'Warning' : u.Enabled ? 'OK' : 'Unknown', go: () => MC.go('identity', 'users', { q: u.SamAccountName }) }));
      const scripts = (MC.manifest.scripts || []).filter((x) => x.title.toLowerCase().includes(s) || x.id.includes(s)).slice(0, 4)
        .map((x) => ({ type: x.kind, label: x.title, sub: x.id, go: () => (x.kind === 'collector' ? MC.go('remote', 'library', { q: x.id }) : runDialog(x.id, {})) }));
      items = [...res, ...users, ...scripts, ...pages.filter((p) => p.label.toLowerCase().includes(s))];
      sel = 0;
      box.hidden = false;
      box.innerHTML = items.length ? items.map((it, i) => `<button data-i="${i}" class="${i === sel ? 'on' : ''}">${it.status ? `<span class="tree"><span class="dot" style="display:inline-block;background:var(${C.STATUS[it.status] || '--muted'})"></span></span>` : ''}<span style="min-width:0;flex:1"><b style="font-weight:600">${esc(it.label)}</b> <span class="muted" style="font-size:12px">${esc(it.sub)}</span></span><span class="muted" style="font-size:11px">${esc(it.type)}</span></button>`).join('') : '<div class="empty">No matches</div>';
    }
    function pick(i) { const it = items[i]; if (!it) return; box.hidden = true; q.value = ''; q.blur(); it.go(); }
    q.addEventListener('input', update);
    q.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); sel = (sel + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % Math.max(1, items.length); $$('button', box).forEach((b, i) => b.classList.toggle('on', i === sel)); }
      else if (e.key === 'Enter') { e.preventDefault(); pick(sel); }
      else if (e.key === 'Escape') { box.hidden = true; q.blur(); }
    });
    box.addEventListener('mousedown', (e) => { const b = e.target.closest('button'); if (b) { e.preventDefault(); pick(+b.dataset.i); } });
    q.addEventListener('blur', () => setTimeout(() => (box.hidden = true), 120));
    document.addEventListener('keydown', (e) => { if (e.key === '/' && !e.target.matches('input,textarea,select')) { e.preventDefault(); q.focus(); } });
  }

  // ------------------------------------------------------------------ generic sortable table
  // cols: [{ key, label, n (numeric), html(row) -> string, val(row) -> sortable value, cls }]
  function table(container, rows, cols, opt = {}) {
    const state = { sort: opt.sort || null, dir: opt.dir || -1, limit: opt.limit || 100, q: '' };
    const wrap = document.createElement('div');
    container.appendChild(wrap);
    const val = (c, r) => (c.val ? c.val(r) : r[c.key]);
    function draw() {
      let list = rows;
      if (state.q) { const s = state.q.toLowerCase(); list = rows.filter((r) => cols.some((c) => String(val(c, r) == null ? '' : val(c, r)).toLowerCase().includes(s))); }
      if (state.sort) {
        const c = cols.find((x) => x.key === state.sort);
        if (c) list = list.slice().sort((a, b) => { const x = val(c, a), y = val(c, b); if (x == null) return 1; if (y == null) return -1; return (typeof x === 'number' && typeof y === 'number' ? x - y : String(x).localeCompare(String(y), undefined, { numeric: true })) * state.dir; });
      }
      const shown = list.slice(0, state.limit);
      wrap.innerHTML = `${opt.search !== false ? `<div class="toolbar" style="margin-bottom:8px"><input class="input" type="search" placeholder="Filter ${rows.length} rows" value="${esc(state.q)}" aria-label="Filter table">${opt.tools || ''}<span class="spacer" style="flex:1"></span><button class="btn sm" data-csv>${icon('download', 'sev-ico')}CSV</button></div>` : ''}
        <div class="tbl-wrap" style="${opt.maxHeight ? 'max-height:' + opt.maxHeight + 'px;overflow-y:auto' : ''}"><table class="tbl"><thead><tr>${cols.map((c) => `<th data-k="${esc(c.key)}" class="${state.sort === c.key ? 'sorted' + (state.dir > 0 ? ' asc' : '') : ''}" style="${c.n ? 'text-align:right' : ''}" scope="col">${esc(c.label)}</th>`).join('')}</tr></thead>
        <tbody>${shown.map((r) => `<tr${opt.rowAttr ? ' ' + opt.rowAttr(r) : ''}>${cols.map((c) => `<td class="${c.n ? 'n' : ''} ${c.cls || ''}">${c.html ? c.html(r) : esc(r[c.key] == null ? '–' : Array.isArray(r[c.key]) ? r[c.key].join(', ') : r[c.key])}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${cols.length}" class="empty">${esc(opt.empty || 'Nothing to show')}</td></tr>`}</tbody></table></div>
        <div class="tbl-foot"><span>${shown.length} of ${list.length}${list.length !== rows.length ? ' (filtered from ' + rows.length + ')' : ''}</span>${list.length > shown.length ? '<button class="btn sm" data-more>Show more</button>' : ''}</div>`;
      $$('th', wrap).forEach((th) => th.addEventListener('click', () => { if (state.sort === th.dataset.k) state.dir *= -1; else { state.sort = th.dataset.k; state.dir = cols.find((c) => c.key === th.dataset.k).n ? -1 : 1; } draw(); }));
      const inp = $('input[type=search]', wrap);
      if (inp) inp.addEventListener('input', () => { state.q = inp.value; const pos = inp.selectionStart; draw(); const n = $('input[type=search]', wrap); n.focus(); n.setSelectionRange(pos, pos); });
      const more = $('[data-more]', wrap);
      if (more) more.addEventListener('click', () => { state.limit += 200; draw(); });
      const csv = $('[data-csv]', wrap);
      if (csv) csv.addEventListener('click', () => downloadCsv(opt.name || 'moncastle-export', list, cols));
      if (opt.after) opt.after(wrap);
    }
    if (opt.q) state.q = opt.q;
    draw();
    return { redraw: draw, setRows: (r) => { rows = r; draw(); } };
  }
  function downloadCsv(name, rows, cols) {
    const cell = (v) => { const s = v == null ? '' : Array.isArray(v) ? v.join('; ') : typeof v === 'object' ? JSON.stringify(v) : String(v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
    const keys = cols ? cols.filter((c) => c.key && !c.noCsv) : Object.keys(rows[0] || {}).map((k) => ({ key: k, label: k }));
    const text = [keys.map((c) => cell(c.label)).join(',')].concat(rows.map((r) => keys.map((c) => cell(c.csv ? c.csv(r) : c.val ? c.val(r) : r[c.key])).join(','))).join('\r\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + text], { type: 'text/csv' }));
    a.download = name + '-' + new Date().toISOString().slice(0, 10) + '.csv';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  MC.table = table; MC.downloadCsv = downloadCsv;
  // 4.7.4: a device can sit in several groups (primary group plus extra groups)
  MC.inGroup = (d, gid) => (Array.isArray(d.groups) && d.groups.length ? d.groups : [d.group]).includes(gid);

  // auto columns for script output
  function autoTable(container, rows, opt = {}) {
    if (!rows || !rows.length) { container.innerHTML += '<div class="empty">The script returned no rows.</div>'; return; }
    const keys = Object.keys(rows[0]).filter((k) => !/^(PSComputerName|RunspaceId|PSShowComputerName)$/.test(k)).slice(0, opt.max || 9);
    table(container, rows, keys.map((k) => ({
      key: k, label: k, n: typeof rows[0][k] === 'number',
      html: (r) => { const v = r[k]; if (k === 'Status' || k === 'Health') return pill(v === 'Online' || v === 'Running' ? 'OK' : v, v); if (v && typeof v === 'object') return `<span class="mono">${esc(JSON.stringify(v).slice(0, 120))}</span>`; return esc(v == null ? '–' : typeof v === 'number' ? fmt(v) : v); },
    })), { name: opt.name, limit: 50 });
  }
  MC.autoTable = autoTable;

  // ------------------------------------------------------------------ drawer
  function openDrawer(html, onReady) {
    closeDrawer();
    const scrim = document.createElement('div');
    scrim.className = 'scrim';
    const d = document.createElement('aside');
    d.className = 'drawer';
    d.setAttribute('role', 'dialog');
    d.setAttribute('aria-modal', 'true');
    d.innerHTML = html;
    document.body.append(scrim, d);
    scrim.addEventListener('click', closeDrawer);
    d.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeDrawer(); });
    $$('[data-close]', d).forEach((b) => b.addEventListener('click', closeDrawer));
    wireLinks(d);
    if (onReady) onReady(d);
    const f = $('[data-close]', d); if (f) f.focus();
  }
  function closeDrawer() { C.hideTip(); $$('.drawer,.scrim').forEach((n) => n.remove()); }
  MC.openDrawer = openDrawer; MC.closeDrawer = closeDrawer;
  // Troubleshoot: the tasks that fit one resource (Windows networking and data, Linux, network device, storage, and the
  // VM on Hyper-V or VMware), each opening the normal run dialog with the resource filled in
  MC.troubleshoot = function (t) {
    const have = new Set((MC.manifest.scripts || []).map((s) => s.id));
    const groups = root.MCTroubleshoot.tasksFor(t).map((g) => Object.assign({}, g, { items: g.items.filter((i) => have.has(i.script)) })).filter((g) => g.items.length);
    const os = root.MCTroubleshoot.osOf(t);
    openDrawer(`<header><div class="row1">${icon("bolt", "sev-ico")}<h2>Troubleshoot ${esc(t.label || t.name)}</h2><button class="iconbtn" data-close style="margin-left:auto" aria-label="Close">${icon('x')}</button></div>
      <div class="meta">${esc([t.platform, t.kind, t.guestOS || t.os, t.name !== (t.label || t.name) ? t.name : ''].filter(Boolean).join(' · '))}${os ? '' : ' · operating system unknown, so only reachability tests are offered'}</div></header>
      <div class="drawer-body ts-body">${groups.map((g) => `<section class="ts-group"><h4>${icon(g.icon || 'bolt', 'sev-ico')}${esc(g.group)}</h4><div class="ts-items">${g.items.map((i) => { const s = MC.script(i.script) || {}; return `<button class="ts-item" ${MC.runAttr(i.script, i.params)}><span class="risk-tag ${esc(s.risk || 'low')}">${esc(s.kind === 'action' ? s.risk || 'low' : 'read')}</span><b>${esc(i.label)}</b>${i.note ? `<small>${esc(i.note)}</small>` : ''}</button>`; }).join('')}</div></section>`).join('')}
      <p class="muted" style="font-size:12px">Each task opens its run dialog so you can check the values first. Changes respect your role and the run-as credential of the device.</p></div>`);
  };
  function openResource(id) { if (MC.views._resource) MC.views._resource(id); }
  MC.openResource = openResource;

  // ------------------------------------------------------------------ run dialog (manifest-driven form)
  function inputFor(p, value, isSecret) {
    const id = 'p_' + p.name;
    const v = value != null ? value : p.default != null ? p.default : '';
    const t = (p.type || 'string').toLowerCase();
    let ctl;
    if (isSecret) ctl = `<input class="input mono" id="${id}" type="password" autocomplete="new-password" placeholder="Never shown or logged">`;
    else if (p.values && p.values.length) ctl = `<select class="input" id="${id}">${p.mandatory ? '' : '<option value="">(default)</option>'}${p.values.map((x) => `<option ${String(v) === x ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select>`;
    else if (t === 'switch' || t === 'bool' || t === 'boolean') ctl = `<label class="check"><input type="checkbox" id="${id}" ${v === true || v === 'true' ? 'checked' : ''}> ${esc(p.name)}</label>`;
    else if (/int|double|decimal|long|single/.test(t) && !t.endsWith('[]')) ctl = `<input class="input" id="${id}" type="number" value="${esc(v)}" ${p.min != null ? 'min="' + p.min + '"' : ''} ${p.max != null ? 'max="' + p.max + '"' : ''}>`;
    else if (t.endsWith('[]')) ctl = `<textarea class="input mono" id="${id}" rows="2" placeholder="One per line or comma separated">${esc(Array.isArray(v) ? v.join(', ') : v)}</textarea>`;
    else ctl = `<input class="input" id="${id}" value="${esc(v)}" ${p.maxLength ? 'maxlength="' + p.maxLength + '"' : ''}>`;
    const hint = [p.mandatory ? 'Required' : 'Optional', p.type, p.min != null || p.max != null ? 'range ' + (p.min != null ? p.min : '') + '–' + (p.max != null ? p.max : '') : '', isSecret ? 'secret' : ''].filter(Boolean).join(' · ');
    return `<div class="field">${t === 'switch' || t === 'bool' ? '' : `<label for="${id}">${esc(p.name)}</label>`}${ctl}<span class="hint">${esc(hint)}</span></div>`;
  }
  function readParams(s, card) {
    const out = {}, errors = [];
    (s.parameters || []).forEach((p) => {
      const el = $('#p_' + p.name, card);
      if (!el) return;
      const t = (p.type || 'string').toLowerCase();
      let v;
      if (el.type === 'checkbox') { if (el.checked) v = true; }
      else {
        const raw = el.value.trim();
        if (raw === '') v = undefined;
        else if (t.endsWith('[]')) v = raw.split(/[\n,;]+/).map((x) => x.trim()).filter(Boolean);
        else if (/int|double|decimal|long|single/.test(t)) { v = Number(raw); if (isNaN(v)) errors.push(p.name + ' must be a number'); else if ((p.min != null && v < p.min) || (p.max != null && v > p.max)) errors.push(p.name + ' must be between ' + p.min + ' and ' + p.max); }
        else v = raw;
        if (typeof v === 'string' && p.pattern) { try { if (!new RegExp(p.pattern).test(v)) errors.push(p.name + ' has an invalid format'); } catch (e) { /* server validates too */ } }
      }
      if (p.mandatory && (v === undefined || (Array.isArray(v) && !v.length))) errors.push(p.name + ' is required');
      if (v !== undefined) out[p.name] = v;
    });
    return { params: out, errors };
  }
  function targetOf(params) {
    const t = params.VMName || params.ComputerName || params.Target || params.UserName;
    return Array.isArray(t) ? t.join(', ') : t || '';
  }

  function runDialog(id, prefill = {}) {
    const s = MC.script(id);
    if (!s) return toast('Script ' + esc(id) + ' is not in the script library.', 'err');
    const role = MC.user.role;
    const blocked = (s.kind === 'action' && root.MCRbac.norm(role) === 'reader' && !(MC.user.groups || []).some((g) => g.grants.some((x) => x.role !== 'reader'))) ? 'Your role (reader) can look but not run actions.' : (s.risk === 'high' && role !== 'admin' && !(MC.user.groups || []).some((g) => g.grants.some((x) => x.role === 'admin'))) ? 'High-risk actions need an administrator.' : (MC.status.license && MC.status.license.readOnly) ? 'The licence is not valid, so the console is read-only.' : '';
    const m = document.createElement('div');
    m.className = 'modal';
    m.setAttribute('role', 'dialog');
    m.setAttribute('aria-modal', 'true');
    const riskText = { high: 'High risk. This changes production systems and can interrupt service. You will be asked to type the target name.', medium: 'Changes the target. Run with WhatIf first if you are unsure.', low: 'Read-only. Collects data and changes nothing.' }[s.risk] || '';
    m.innerHTML = `<div class="card">
      <div style="display:flex;gap:8px;align-items:center"><span class="risk-tag ${esc(s.risk)}">${esc(s.risk)} risk</span><span class="muted" style="font-size:12px">${esc(s.kind)} · ${esc(s.resource || '')} · <span class="mono">${esc(s.id)}</span></span><button class="iconbtn" data-x style="margin-left:auto" aria-label="Close">${icon('x')}</button></div>
      <h3 style="margin-top:10px">${esc(s.title)}</h3>
      <p class="muted" style="margin:0">${esc(s.synopsis || '')}</p>
      <div class="risk ${esc(s.risk)}">${icon(s.risk === 'high' ? 'alert' : s.risk === 'medium' ? 'info' : 'check', 'sev-ico')}<span>${esc(riskText)}</span></div>
      ${blocked ? `<div class="notice err">${esc(blocked)}</div>` : ''}
      <form id="runForm" autocomplete="off" novalidate>
        ${(s.parameters || []).map((p) => inputFor(p, prefill[p.name], false)).join('')}
        ${(s.secrets || []).map((n) => inputFor({ name: n, type: 'string', mandatory: true }, null, true).replace('id="p_' + n + '"', 'id="sec_' + n + '"').replace('for="p_' + n + '"', 'for="sec_' + n + '"')).join('')}
        ${!(s.parameters || []).length && !(s.secrets || []).length ? '<p class="muted">This script takes no parameters.</p>' : ''}
        ${s.supportsWhatIf ? `<label class="check"><input type="checkbox" id="whatIf" ${s.risk === 'high' ? 'checked' : ''}> Preview only (WhatIf): report what would change without changing it</label>` : ''}
        ${s.risk === 'high' ? '<div class="field" style="margin-top:12px"><label for="confirmTxt">Type the target to confirm</label><input class="input mono" id="confirmTxt" placeholder=""><span class="hint" id="confirmHint"></span></div>' : ''}
        <div id="runErr"></div>
        <div class="foot"><button type="button" class="btn" data-x>Cancel</button><button type="submit" class="btn ${s.risk === 'high' ? 'danger' : 'primary'}" ${blocked ? 'disabled' : ''}>${icon('play', 'sev-ico')}${s.kind === 'action' ? 'Run action' : 'Run'}</button></div>
      </form>
      <div id="runOut"></div>
    </div>`;
    document.body.appendChild(m);
    const close = () => { m.remove(); };
    $$('[data-x]', m).forEach((b) => b.addEventListener('click', close));
    m.addEventListener('click', (e) => { if (e.target === m) close(); });
    m.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    // fields the caller wants the user to fill in (troubleshooting port and DNS tests): required, highlighted, focused
    const ask = (Array.isArray(prefill.$ask) ? prefill.$ask : []).filter((n) => $('#p_' + n, m));
    ask.forEach((n) => {
      const el = $('#p_' + n, m), f = el.closest('.field');
      el.required = true; f.classList.add('ask');
      if (n === 'Target' && !el.placeholder) el.placeholder = 'Host name or IP address, e.g. dc01.corp.local or 10.0.0.5';
      const h = $('.hint', f); if (h) h.textContent = 'Required for this test';
      el.addEventListener('input', () => f.classList.remove('invalid'));
    });
    const askFirst = ask.find((n) => !$('#p_' + n, m).value) || ask[0];
    const first = askFirst ? $('#p_' + askFirst, m) : $('input,select,textarea', m); if (first) first.focus();
    const upd = () => { const h = $('#confirmHint', m); if (h) { const t = targetOf(readParams(s, m).params); h.textContent = t ? 'Type exactly: ' + t : 'Fill in the target first'; } };
    m.addEventListener('input', upd); upd();
    $('#runForm', m).addEventListener('submit', async (e) => {
      e.preventDefault();
      const { params, errors } = readParams(s, m);
      const err = $('#runErr', m);
      if (s.risk === 'high' && !($('#whatIf', m) || {}).checked) { const t = targetOf(params); if (!t || $('#confirmTxt', m).value.trim() !== t) errors.push('Type the target name exactly to confirm (' + (t || 'no target') + ').'); }
      (s.secrets || []).forEach((n) => { const el = $('#sec_' + n, m); if (el && !el.value) errors.push(n + ' is required'); });
      ask.forEach((n) => { if (params[n] === undefined || params[n] === '') { $('#p_' + n, m).closest('.field').classList.add('invalid'); if (!errors.includes(n + ' is required')) errors.push(n + ' is required for this test'); } });
      if (errors.length) { err.innerHTML = `<div class="notice err" style="margin-top:10px">${errors.map(esc).join('<br>')}</div>`; return; }
      err.innerHTML = '';
      const btn = $('button[type=submit]', m);
      btn.disabled = true; btn.textContent = 'Starting…';
      try {
        const whatIf = !!($('#whatIf', m) || {}).checked;
        const secrets = {};
        (s.secrets || []).forEach((n) => { const el = $('#sec_' + n, m); if (el && el.value) secrets[n] = el.value; });
        const r = await MC.api.run(s.id, params, { whatIf, secrets, confirm: s.risk === 'high' && !whatIf ? $('#confirmTxt', m).value.trim() : undefined });
        (s.secrets || []).forEach((n) => { const el = $('#sec_' + n, m); if (el) el.value = ''; });
        MC.jobs.unshift(r.job);
        toast(`${icon('play', 'sev-ico')} Started <b>${esc(s.title)}</b>${targetOf(params) ? ' on ' + esc(targetOf(params)) : ''}`);
        $('#runForm', m).hidden = true;
        $('#runOut', m).innerHTML = '<div class="notice" style="margin-top:12px">Running… output appears here when the job finishes. You can close this window; the job keeps running under Actions & jobs.</div>';
        watchJob(r.job.id, (job) => { if (document.body.contains(m)) showJobResult($('#runOut', m), job); });
      } catch (ex) {
        err.innerHTML = `<div class="notice err" style="margin-top:10px">${esc(ex.message)}</div>`;
        btn.disabled = false; btn.innerHTML = icon('play', 'sev-ico') + 'Run';
      }
    });
  }
  MC.runDialog = runDialog; MC.inputFor = inputFor; MC.readParams = readParams;

  function showJobResult(el, job) {
    const r = job.result || {};
    const st = job.state === 'failed' || r.status === 'error' ? 'Critical' : r.status === 'warning' || (r.warnings || []).length ? 'Warning' : 'OK';
    el.innerHTML = `<div style="display:flex;gap:8px;align-items:center;margin:14px 0 8px">${pill(st, job.state === 'failed' ? 'Failed' : 'Completed')}<span class="muted" style="font-size:12px">${esc(r.count != null ? r.count + ' rows' : '')} · ${esc(r.host || '')} · ${dt(job.finished)}${job.whatIf ? ' · WhatIf' : ''}</span></div>
      ${r.message ? `<div class="notice" style="margin-bottom:8px">${esc(r.message)}</div>` : ''}
      ${(r.warnings || []).length ? `<div class="notice err" style="margin-bottom:8px">${r.warnings.map(esc).join('<br>')}</div>` : ''}
      <div data-out></div>`;
    autoTable($('[data-out]', el), r.data || [], { name: job.script });
  }
  MC.showJobResult = showJobResult;

  const watchers = {};
  function watchJob(id, cb) { watchers[id] = cb; }
  function startJobPoller() {
    if (MC._poller) return;
    MC._poller = setInterval(async () => {
      const ids = Object.keys(watchers);
      if (!ids.length) return;
      for (const id of ids) {
        try {
          const j = await MC.api.job(id);
          if (j.state !== 'running' && j.state !== 'queued') {
            const cb = watchers[id]; delete watchers[id];
            const i = MC.jobs.findIndex((x) => x.id === id); if (i >= 0) MC.jobs[i] = j;
            toast(`${j.state === 'failed' ? 'Failed' : 'Finished'}: <b>${esc(j.title || j.script)}</b>`, j.state === 'failed' ? 'err' : 'ok');
            cb && cb(j);
            if (MC.route.page === 'actions' && MC.views.actions.onJobs) MC.views.actions.onJobs();
            const s = MC.script(j.script);
            if (s && s.kind === 'collector' && j.result && j.result.dataset) { MC.ds[j.result.dataset] = j.result; MC.model = M.build(MC.ds, MC.devices); MC.summary = M.summarize(MC.model); }
          }
        } catch (e) { delete watchers[id]; }
      }
    }, 900);
  }
  MC.watchJob = watchJob;

  // ------------------------------------------------------------------ small shared builders for views
  MC.kpi = (label, value, sub, opt = {}) => `<div class="kpi${opt.alert ? ' alert' : ''}"${opt.href ? ` data-href="${esc(opt.href)}" style="cursor:pointer"` : ''}><label>${esc(label)}</label><b>${value}</b>${sub ? `<small>${sub}</small>` : ''}${opt.spark ? '<div data-spark></div>' : ''}</div>`;
  MC.panel = (title, sub, body, opt = {}) => `<section class="card panel-c"${opt.id ? ` id="${opt.id}"` : ''}><div class="panel-h"><h3>${esc(title)}</h3>${sub ? `<span class="sub">${sub}</span>` : ''}${opt.act ? `<div class="act">${opt.act}</div>` : ''}</div>${body}</section>`;
  MC.tabs = (page, tabs, cur) => `<div class="tabs" role="tablist">${tabs.map(([id, t, badge]) => `<button role="tab" aria-selected="${id === cur}" class="${id === cur ? 'on' : ''}" data-href="#/${page}/${id}">${esc(t)}${badge ? ` <span class="pill ${badge.s}" style="margin-left:4px">${badge.n}</span>` : ''}</button>`).join('')}</div>`;
  MC.insightRow = (i) => `<div class="insight ${esc(i.sev)}">${sevIcon(i.sev)}<div style="min-width:0"><span class="area">${esc(i.area)}</span><b>${esc(i.title)}</b><p>${esc(i.detail)}</p></div><div class="actions-row" style="flex-direction:column;align-items:flex-end">${i.action ? `<button class="btn sm" ${MC.runAttr(i.action.script, i.action.params)}>${icon('bolt', 'sev-ico')}${esc(i.action.label)}</button>` : ''}${(i.targets || [])[0] ? `<button class="btn sm ghost" data-host="${esc(i.targets[0])}">Open ${esc(i.targets[0])}</button>` : ''}</div></div>`;

  root.addEventListener('DOMContentLoaded', () => boot().catch((e) => { console.error(e); document.getElementById('app').innerHTML = `<div style="padding:40px" class="notice err">MonCastle could not start: ${esc(e.message)}</div>`; }));
})(typeof self !== 'undefined' ? self : this);
