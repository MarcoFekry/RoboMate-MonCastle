/*
 * RoboMate MonCastle - operating system releases: which release each Windows and Linux machine runs, the newest
 * update for that release, and when its support ends. Shared by the browser (window.MCOSReleases) and the server.
 *
 * The built-in list knows each release's build and support dates. The newest build or point release comes from the
 * internet (server/lib/osreleases.js: Microsoft's Windows release information pages and endoflife.date) and is
 * merged in with merge(). Without an online check, machines are compared with the newest build seen in the fleet.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCOSReleases = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  // id, name, platform, how to recognise it, Windows build, support end (mainstream / security), online sources
  const F = (id, name, platform, test, extra) => Object.assign({ id, name, platform, test }, extra);
  const W = (re) => (r) => re.test(String(r.OS || ''));
  const L = (distro, ver) => (r) => String(r.Distro || '').toLowerCase() === distro && (String(r.Version || '') === ver || String(r.Version || '').startsWith(ver + '.'));
  const FAMILIES = [
    F('ws2008r2', 'Windows Server 2008 R2', 'Windows', W(/Server 2008/i), { build: '7601', ends: '2020-01-14' }),
    F('ws2012', 'Windows Server 2012', 'Windows', W(/Server 2012(?! R2)/i), { build: '9200', ends: '2023-10-10' }),
    F('win7', 'Windows 7', 'Windows', W(/Windows 7/i), { build: '7601', ends: '2020-01-14' }),
    F('win81', 'Windows 8.1', 'Windows', W(/Windows 8/i), { build: '9600', ends: '2023-01-10' }),
    F('ws2012r2', 'Windows Server 2012 R2', 'Windows', W(/Server 2012 R2/i), { build: '9600', ends: '2023-10-10', eol: ['windows-server', '2012-r2'] }),
    F('ws2016', 'Windows Server 2016', 'Windows', W(/Server 2016/i), { build: '14393', ends: '2027-01-12', eol: ['windows-server', '2016'], ms: 'server' }),
    F('ws2019', 'Windows Server 2019', 'Windows', W(/Server 2019/i), { build: '17763', ends: '2029-01-09', eol: ['windows-server', '2019'], ms: 'server' }),
    F('ws2022', 'Windows Server 2022', 'Windows', W(/Server 2022/i), { build: '20348', ends: '2031-10-14', eol: ['windows-server', '2022'], ms: 'server' }),
    F('ws2025', 'Windows Server 2025', 'Windows', W(/Server 2025/i), { build: '26100', ends: '2034-10-10', eol: ['windows-server', '2025'], ms: 'server' }),
    F('win10-22h2', 'Windows 10 22H2', 'Windows', (r) => /Windows 10/i.test(r.OS) && String(r.Build || '').startsWith('19045'), { build: '19045', ends: '2025-10-14', note: 'Extended Security Updates only', ms: 'win10' }),
    F('win11-22h2', 'Windows 11 22H2', 'Windows', (r) => /Windows 11/i.test(r.OS) && String(r.Build || '').startsWith('22621'), { build: '22621', ends: '2025-10-14', ms: 'win11' }),
    F('win11-23h2', 'Windows 11 23H2', 'Windows', (r) => /Windows 11/i.test(r.OS) && String(r.Build || '').startsWith('22631'), { build: '22631', ends: '2026-11-10', note: 'Enterprise and Education; Home and Pro ended 2025-11-11', ms: 'win11' }),
    F('win11-24h2', 'Windows 11 24H2', 'Windows', (r) => /Windows 11/i.test(r.OS) && String(r.Build || '').startsWith('26100'), { build: '26100', ends: '2027-10-12', note: 'Enterprise and Education; Home and Pro end 2026-10-13', ms: 'win11' }),
    F('win11-25h2', 'Windows 11 25H2', 'Windows', (r) => /Windows 11/i.test(r.OS) && String(r.Build || '').startsWith('26200'), { build: '26200', ends: '2028-10-10', note: 'Enterprise and Education', ms: 'win11' }),
    F('ubuntu-20.04', 'Ubuntu 20.04 LTS', 'Linux', L('ubuntu', '20.04'), { ends: '2025-05-31', note: 'Ubuntu Pro (ESM) until 2030', latest: '20.04.6', eol: ['ubuntu', '20.04'] }),
    F('ubuntu-22.04', 'Ubuntu 22.04 LTS', 'Linux', L('ubuntu', '22.04'), { ends: '2027-06-01', latest: '22.04.5', eol: ['ubuntu', '22.04'] }),
    F('ubuntu-24.04', 'Ubuntu 24.04 LTS', 'Linux', L('ubuntu', '24.04'), { ends: '2029-05-31', eol: ['ubuntu', '24.04'] }),
    F('debian-11', 'Debian 11', 'Linux', L('debian', '11'), { ends: '2026-08-31', note: 'LTS', eol: ['debian', '11'] }),
    F('debian-12', 'Debian 12', 'Linux', L('debian', '12'), { ends: '2028-06-30', note: 'LTS after 2026-06-10', eol: ['debian', '12'] }),
    F('debian-13', 'Debian 13', 'Linux', L('debian', '13'), { ends: '2030-06-30', eol: ['debian', '13'] }),
    F('rhel-7', 'Red Hat Enterprise Linux 7', 'Linux', L('rhel', '7'), { ends: '2024-06-30', note: 'Extended Life Cycle Support only', latest: '7.9', eol: ['rhel', '7'] }),
    F('rhel-8', 'Red Hat Enterprise Linux 8', 'Linux', L('rhel', '8'), { ends: '2029-05-31', latest: '8.10', eol: ['rhel', '8'] }),
    F('rhel-9', 'Red Hat Enterprise Linux 9', 'Linux', L('rhel', '9'), { ends: '2032-05-31', eol: ['rhel', '9'] }),
    F('rhel-10', 'Red Hat Enterprise Linux 10', 'Linux', L('rhel', '10'), { ends: '2035-05-31', eol: ['rhel', '10'] }),
    F('rocky-8', 'Rocky Linux 8', 'Linux', L('rocky', '8'), { ends: '2029-05-31', latest: '8.10', eol: ['rocky-linux', '8'] }),
    F('rocky-9', 'Rocky Linux 9', 'Linux', L('rocky', '9'), { ends: '2032-05-31', eol: ['rocky-linux', '9'] }),
    F('alma-8', 'AlmaLinux 8', 'Linux', L('almalinux', '8'), { ends: '2029-03-01', latest: '8.10', eol: ['almalinux', '8'] }),
    F('alma-9', 'AlmaLinux 9', 'Linux', L('almalinux', '9'), { ends: '2032-05-31', eol: ['almalinux', '9'] }),
    F('ol-8', 'Oracle Linux 8', 'Linux', L('ol', '8'), { ends: '2029-07-31', eol: ['oracle-linux', '8'] }),
    F('ol-9', 'Oracle Linux 9', 'Linux', L('ol', '9'), { ends: '2032-06-30', eol: ['oracle-linux', '9'] }),
    F('sles-12', 'SUSE Linux Enterprise Server 12', 'Linux', L('sles', '12'), { ends: '2024-10-31', note: 'LTSS only', eol: ['sles', '12.5'] }),
    F('sles-15', 'SUSE Linux Enterprise Server 15', 'Linux', L('sles', '15'), { ends: '2031-07-31', eol: ['sles', '15'] }),
    F('centos-7', 'CentOS 7', 'Linux', L('centos', '7'), { ends: '2024-06-30', latest: '7.9', eol: ['centos', '7'] }),
  ];
  const FAMILY = Object.fromEntries(FAMILIES.map((f) => [f.id, f]));
  const familyOf = (r) => FAMILIES.find((f) => f.platform === r.Platform && f.test(r)) || null;
  const day = 864e5;
  // compare "20348.2700" with "20348.2849", or "22.04.4" with "22.04.5"; returns <0 when a is older
  const cmp = (a, b) => { const x = String(a).split(/[.-]/).map(Number), y = String(b).split(/[.-]/).map(Number); for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };
  // the release a machine runs, as a comparable version: Windows build.UBR, or the Linux point release
  const current = (r) => (r.Platform === 'Windows' ? String(r.Build || '') : String(r.PointRelease || r.Version || ''));

  // catalog: { checked, source, families: { id: { latest, latestDate, ends, source } } } from the online check
  function merge(online) {
    const out = {};
    for (const f of FAMILIES) {
      const o = ((online || {}).families || {})[f.id] || {};
      out[f.id] = { id: f.id, name: f.name, platform: f.platform, build: f.build || null, latest: o.latest || f.latest || null, latestDate: o.latestDate || null, ends: o.ends || f.ends, note: f.note || null, source: o.latest ? o.source || 'online' : f.latest ? 'built-in' : null };
    }
    return { checked: (online || {}).checked || null, source: (online || {}).source || 'built-in', error: (online || {}).error || null, families: out };
  }

  // one row of the updates.status dataset, with the catalog's view added
  function assess(r, catalog, fleetNewest, now) {
    now = now || Date.now();
    const f = familyOf(r);
    const c = f && catalog && catalog.families[f.id];
    const cur = current(r);
    const latest = (c && c.latest) || (f && f.platform === 'Windows' && fleetNewest && fleetNewest[f.id]) || null;
    const latestFrom = c && c.latest ? c.source || 'online' : latest ? 'newest in your fleet' : null;
    const behind = !!(latest && cur && cmp(cur, latest) < 0);
    const ends = c ? c.ends : null;
    const daysLeft = ends ? Math.floor((Date.parse(ends) - now) / day) : null;
    const problems = [];
    if (!f) problems.push('Release not recognised: ' + (r.OS || 'unknown OS'));
    if (daysLeft != null && daysLeft < 0) problems.push(f.name + ' is out of support since ' + ends + (c.note ? ' (' + c.note + ')' : ''));
    else if (daysLeft != null && daysLeft < 180) problems.push(f.name + ' support ends ' + ends);
    if (behind) problems.push('Newer ' + (r.Platform === 'Windows' ? 'build ' : 'release ') + latest + ' is available (' + latestFrom + '); this machine has ' + cur);
    if (r.PendingSecurity > 0) problems.push(r.PendingSecurity + ' security updates waiting');
    else if (r.PendingUpdates > 0) problems.push(r.PendingUpdates + ' updates waiting');
    if (r.RebootPending) problems.push('Restart pending to finish updates');
    if (r.DaysSinceUpdate > 60) problems.push('No updates installed for ' + r.DaysSinceUpdate + ' days');
    const state = r.Status === 'Unreachable' ? 'Unknown' : (daysLeft != null && daysLeft < 0) || (r.PendingSecurity > 0 && r.DaysSinceUpdate > 30) || r.DaysSinceUpdate > 60 ? 'Critical' : behind || r.PendingUpdates > 0 || r.RebootPending || (daysLeft != null && daysLeft < 180) || !f ? 'Warning' : 'OK';
    return Object.assign({}, r, { Family: f ? f.id : null, Release: f ? f.name : r.OS, Current: cur, Latest: latest, LatestFrom: latestFrom, Behind: behind, SupportEnds: ends, SupportDaysLeft: daysLeft, Supported: daysLeft == null ? null : daysLeft >= 0, UpdateState: state, UpdateProblems: problems });
  }
  // newest build or point release seen per family, used when there is no online answer
  function fleetNewest(rows) {
    const out = {};
    for (const r of rows || []) { const f = familyOf(r); const cur = current(r); if (f && cur && (!out[f.id] || cmp(cur, out[f.id]) > 0)) out[f.id] = cur; }
    return out;
  }
  function assessAll(rows, catalog, now) { const fn = fleetNewest(rows); return (rows || []).map((r) => assess(r, catalog, fn, now)); }

  return { FAMILIES, FAMILY, familyOf, merge, assess, assessAll, fleetNewest, cmp };
});
