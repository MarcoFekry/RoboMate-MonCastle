/*
 * RoboMate MonCastle - Actions › Groups: every device group at a glance (health map, cards with device tiles,
 * sensor states and top issues) and one group's page; plus the alarms view grouped by group and resource
 * (Alarms › By group). Uses the same monitoring tree as the device tree, so roles and restrictions apply.
 */
(function (root) {
  'use strict';
  const MC = root.MC, C = root.MCCharts;
  const { esc, fmt, pill, ago, $, $$ } = MC;
  const V = MC.views;
  const enc = encodeURIComponent;
  const STC = { Down: '--crit', Warning: '--warn', Up: '--ok', Paused: '--s1', Unknown: '--muted' };
  const stackOf = (c) => C.statusStack({ Critical: (c.Down || 0) - (c.Ack || 0), Offline: c.Ack || 0, Warning: c.Warning || 0, OK: c.Up || 0, Unknown: (c.Unknown || 0) + (c.Paused || 0) }, { thin: true });
  const health = (c) => { const n = (c.Up || 0) + (c.Warning || 0) + (c.Down || 0); return n ? Math.round(((c.Up || 0) + (c.Warning || 0) * 0.5) / n * 1000) / 10 : null; };
  const admin = () => MC.user.role === 'admin' || !!MC.user.override;
  const worst = (c) => (c.Down ? 'Down' : c.Warning ? 'Warning' : c.Up ? 'Up' : 'Unknown');

  // groups with their devices, sensors and counts (child groups roll up into their parents)
  function model(tr) {
    const devs = new Map(tr.devices.map((d) => [d.id, d]));
    const gs = tr.groups.map((g) => ({ id: g.id, name: g.name, parent: g.parent, devices: [], sensors: [], counts: {} }));
    const byId = new Map(gs.map((g) => [g.id, g]));
    for (const d of tr.devices) { const g = byId.get(d.group); if (g) g.devices.push(d); }
    for (const s of tr.sensors) {
      const d = devs.get(s.device); if (!d) continue;
      for (let g = byId.get(d.group), hop = 0; g && hop < 8; g = byId.get(g.parent), hop++) {
        if (hop === 0) g.sensors.push(s);
        g.counts[s.state] = (g.counts[s.state] || 0) + 1;
        if (s.ack && s.state === 'Down') g.counts.Ack = (g.counts.Ack || 0) + 1;
      }
    }
    for (const g of gs) { g.health = health(g.counts); g.state = worst(g.counts); g.alarms = g.sensors.filter((s) => (s.state === 'Down' || s.state === 'Warning') && !s.related); g.path = []; for (let p = byId.get(g.parent), hop = 0; p && hop < 8; p = byId.get(p.parent), hop++) g.path.unshift(p.name); }
    return { groups: gs.filter((g) => g.devices.length || g.sensors.length || gs.some((x) => x.parent === g.id && x.devices.length)), devs, byId };
  }

  // squarified treemap: area = devices, colour = health
  function treemap(container, items, onClick) {
    container.innerHTML = '';
    const W = Math.max(300, container.clientWidth || 800), H = 260;
    const total = items.reduce((a, x) => a + x.value, 0) || 1;
    const rects = [];
    (function layout(list, x, y, w, h) {
      if (!list.length) return;
      if (list.length === 1) { rects.push(Object.assign({ x, y, w, h }, list[0])); return; }
      const sum = list.reduce((a, i) => a + i.value, 0);
      let acc = 0, k = 0;
      while (k < list.length - 1 && (acc + list[k].value) / sum <= 0.5) { acc += list[k].value; k++; }
      if (k === 0) { acc = list[0].value; k = 1; }
      const f = acc / sum;
      if (w >= h) { layout(list.slice(0, k), x, y, w * f, h); layout(list.slice(k), x + w * f, y, w * (1 - f), h); }
      else { layout(list.slice(0, k), x, y, w, h * f); layout(list.slice(k), x, y + h * f, w, h * (1 - f)); }
    })(items.slice().sort((a, b) => b.value - a.value), 0, 0, W, H);
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('viewBox', `0 0 ${W} ${H}`); svg.setAttribute('width', '100%'); svg.setAttribute('height', H); svg.setAttribute('class', 'mc-chart treemap'); svg.setAttribute('role', 'img'); svg.setAttribute('aria-label', 'Groups by device count, coloured by health');
    for (const r of rects) {
      const g = document.createElementNS(ns, 'g'); g.style.cursor = 'pointer';
      const rc = document.createElementNS(ns, 'rect');
      Object.entries({ x: r.x + 1.5, y: r.y + 1.5, width: Math.max(0, r.w - 3), height: Math.max(0, r.h - 3), rx: 6, fill: `var(${STC[r.state] || '--muted'})`, 'fill-opacity': r.state === 'Up' ? 0.22 + 0.5 * (r.value / total) : 0.85 }).forEach(([k, v]) => rc.setAttribute(k, v));
      g.appendChild(rc);
      if (r.w > 70 && r.h > 34) {
        const t = document.createElementNS(ns, 'text'); t.setAttribute('x', r.x + 10); t.setAttribute('y', r.y + 22); t.setAttribute('class', 'tm-l'); t.textContent = r.label.length > r.w / 8 ? r.label.slice(0, Math.floor(r.w / 8) - 1) + '…' : r.label; g.appendChild(t);
        const t2 = document.createElementNS(ns, 'text'); t2.setAttribute('x', r.x + 10); t2.setAttribute('y', r.y + 39); t2.setAttribute('class', 'tm-s'); t2.textContent = r.value + ' devices' + (r.health != null ? ' · ' + fmt(r.health, 0) + '%' : ''); g.appendChild(t2);
      }
      g.addEventListener('mousemove', (e) => C.showTip(`<div class="t">${esc(r.label)}</div><div class="row">Devices<b>${r.value}</b></div><div class="row">Health<b>${r.health == null ? '–' : fmt(r.health, 1) + '%'}</b></div><div class="row">Alarms<b>${r.alarms}</b></div>`, e.clientX, e.clientY));
      g.addEventListener('mouseleave', C.hideTip);
      g.addEventListener('click', () => onClick(r));
      svg.appendChild(g);
    }
    container.appendChild(svg);
  }

  const tile = (d) => `<a class="devtile ${esc(d.state)}" href="#/device/${enc(d.id)}" title="${esc(d.name)} · ${esc(d.state)}${d.counts && d.counts.Down ? ' · ' + d.counts.Down + ' down' : ''}"></a>`;

  function card(g) {
    const c = g.counts, h = g.health;
    const top = g.alarms.slice().sort((a, b) => (a.state === 'Down' ? 0 : 1) - (b.state === 'Down' ? 0 : 1)).slice(0, 3);
    return `<section class="card grpcard st-${esc(g.state)}" data-g="${esc(g.id)}">
      <div class="grpcard-h"><div><a href="#/groups/${enc(g.id)}"><b>${esc(g.name)}</b></a>${g.path.length ? `<div class="muted" style="font-size:11.5px">${esc(g.path.join(' › '))}</div>` : ''}</div><span class="spacer"></span>${pill(g.state === 'Down' ? 'Critical' : g.state === 'Warning' ? 'Warning' : g.state === 'Up' ? 'OK' : 'Unknown', g.state === 'Up' ? 'Healthy' : g.state)}</div>
      <div class="grpcard-m"><div class="grp-health"><b>${h == null ? '–' : fmt(h, h === 100 ? 0 : 1) + '%'}</b><small>health</small></div><div class="grp-nums"><span><b>${g.devices.length}</b> devices</span><span><b>${g.sensors.length}</b> sensors</span><span class="${g.alarms.length ? 'sev-text crit' : ''}"><b>${g.alarms.length}</b> alarms</span></div></div>
      ${stackOf(c)}
      <div class="devtiles">${g.devices.slice(0, 60).map(tile).join('')}${g.devices.length > 60 ? `<span class="muted" style="font-size:11.5px">+${g.devices.length - 60}</span>` : ''}</div>
      ${top.length ? `<ul class="grp-issues">${top.map((s) => `<li><span class="sdot ${s.ack ? 'Ack' : s.state}"></span><a href="#/sensor/${enc(s.id)}">${esc(s.deviceName || '')} › ${esc(s.name)}</a><span class="muted">${ago(s.since).replace(' ago', '')}</span></li>`).join('')}</ul>` : '<p class="muted" style="font-size:12.5px;margin:0">No open alarms.</p>'}
    </section>`;
  }

  V.groups = {
    title: 'Groups',
    crumb: () => (MC.route.tab ? 'group › devices, sensors and alarms' : 'every device group: health, devices and alarms'),
    async render(el, route) {
      el.innerHTML = '<div class="notice">Loading groups…</div>';
      const seq = MC.renderSeq;
      const draw = async () => {
        let tr; try { tr = await MC.api.monitor('tree'); } catch (e) { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; return; }
        if (seq !== MC.renderSeq) return;
        const devName = new Map(tr.devices.map((d) => [d.id, d.name]));
        for (const s of tr.sensors) s.deviceName = s.deviceName || devName.get(s.device);
        const m = model(tr);
        if (route.tab) return detail(el, m, tr, decodeURIComponent(route.tab));
        overview(el, m, tr);
      };
      await draw();
      clearInterval(V.groups._t);
      V.groups._t = setInterval(() => { if (seq !== MC.renderSeq) return clearInterval(V.groups._t); if (!document.querySelector('.modal')) draw(); }, 20000);
    },
  };

  function overview(el, m, tr) {
    const gs = m.groups.filter((g) => g.devices.length).sort((a, b) => (b.alarms.length - a.alarms.length) || (b.devices.length - a.devices.length));
    const bad = gs.filter((g) => g.state === 'Down').length, warn = gs.filter((g) => g.state === 'Warning').length;
    const ui = V.groups._ui = V.groups._ui || { q: '', only: '' };
    el.innerHTML = `<div class="kpis">${MC.kpi('Groups', gs.length, tr.devices.length + ' devices')}${MC.kpi('Healthy', gs.length - bad - warn, 'no warnings or errors')}${MC.kpi('With errors', bad, 'at least one sensor down', { alert: bad > 0 })}${MC.kpi('With warnings', warn, '')}${MC.kpi('Overall health', (() => { const c = {}; for (const s of tr.sensors) c[s.state] = (c[s.state] || 0) + 1; const h = health(c); return h == null ? '–' : fmt(h, 1) + '%'; })(), 'up = 100, warning = 50, down = 0')}</div>
      <div class="grid g-2-1">
        ${MC.panel('Health map', 'area = devices, colour = worst state; click a group', '<div id="gTm"></div>')}
        ${MC.panel('Alarms per group', 'down and warning', '<div id="gBars"></div>')}
      </div>
      <div class="toolbar"><input class="input" id="gQ" placeholder="Find a group" value="${esc(ui.q)}" style="max-width:260px"><div class="mfilter">${[['', 'All'], ['Down', 'With errors'], ['Warning', 'With warnings'], ['Up', 'Healthy']].map(([k, l]) => `<button class="btn sm ${ui.only === k ? 'on' : ''}" data-only="${k}">${l}</button>`).join('')}</div><span class="spacer"></span>${admin() ? '<button class="btn sm primary" id="gNew">New group</button>' : ''}<a class="btn sm" href="#/alarms/groups">Alarms by group</a></div>
      <div class="grpgrid" id="gGrid"></div>
      ${admin() ? MC.panel('Manage groups', 'create, rename, move or delete groups; built-in groups can be renamed and moved', '<div id="gMan"></div>') : ''}`;
    treemap($('#gTm', el), gs.map((g) => ({ id: g.id, label: g.name, value: Math.max(1, g.devices.length), state: g.state, health: g.health, alarms: g.alarms.length })), (r) => MC.go('groups', r.id));
    $('#gBars', el).innerHTML = C.barList(gs.filter((g) => g.alarms.length).slice(0, 10).map((g) => ({ label: g.name, value: g.alarms.length, text: g.alarms.length, sub: g.alarms.filter((s) => s.state === 'Down').length + ' down · ' + g.alarms.filter((s) => s.state === 'Warning').length + ' warning', status: g.state === 'Down' ? 'Critical' : 'Warning', href: '#/groups/' + enc(g.id) })), { compact: true }) || '<div class="muted">No alarms in any group.</div>';
    if (!gs.some((g) => g.alarms.length)) $('#gBars', el).innerHTML = '<div class="mc-empty">No alarms in any group.</div>';
    const grid = () => { const list = gs.filter((g) => (!ui.q || g.name.toLowerCase().includes(ui.q.toLowerCase())) && (!ui.only || g.state === ui.only)); $('#gGrid', el).innerHTML = list.map(card).join('') || '<div class="card panel-c empty">No group matches.</div>'; };
    grid();
    $('#gQ', el).addEventListener('input', (e) => { ui.q = e.target.value; grid(); });
    $$('[data-only]', el).forEach((b) => b.addEventListener('click', () => { ui.only = b.dataset.only; $$('[data-only]', el).forEach((x) => x.classList.toggle('on', x === b)); grid(); }));
    $$('[data-href]', el).forEach((n) => n.addEventListener('click', () => { location.hash = n.dataset.href; }));
    const redraw = () => V.groups.render(el, MC.route);
    if ($('#gNew', el)) $('#gNew', el).addEventListener('click', () => MC.groupDialog(tr, null, redraw));
    if ($('#gMan', el)) {
      const names = new Map(tr.groups.map((g) => [g.id, g.name]));
      const rows = tr.groups.map((g) => Object.assign({}, g, { inside: g.parent && g.parent !== 'probe' ? names.get(g.parent) || g.parent : 'Top level', n: tr.devices.filter((d) => MC.inGroup(d, g.id)).length, sub: tr.groups.filter((x) => x.parent === g.id).length, fixed: g.auto || g.builtIn }));
      MC.table($('#gMan', el), rows, [
        { key: 'name', label: 'Group', html: (g) => `<a href="#/groups/${enc(g.id)}"><b>${esc(g.name)}</b></a>${g.description ? `<div class="muted" style="font-size:11.5px">${esc(g.description)}</div>` : ''}` },
        { key: 'inside', label: 'Inside' },
        { key: 'n', label: 'Devices', n: true }, { key: 'sub', label: 'Subgroups', n: true },
        { key: 'fixed', label: 'Kind', html: (g) => (g.fixed ? 'Built-in' : 'Custom'), val: (g) => (g.fixed ? 'Built-in' : 'Custom') },
        { key: 'id', label: '', noCsv: true, html: (g) => `<button class="btn sm" data-ge="${esc(g.id)}">Edit</button>${g.fixed ? '' : ` <button class="btn sm ghost" data-gd="${esc(g.id)}">Delete</button>`}` },
      ], { name: 'groups', limit: 100, sort: 'name', dir: 1, after: (box) => {
        $$('[data-ge]', box).forEach((b) => b.addEventListener('click', () => MC.groupDialog(tr, tr.groups.find((g) => g.id === b.dataset.ge), redraw)));
        $$('[data-gd]', box).forEach((b) => b.addEventListener('click', () => MC.deleteGroupDialog(tr, tr.groups.find((g) => g.id === b.dataset.gd), redraw)));
      } });
    }
  }

  function detail(el, m, tr, id) {
    const g = m.byId.get(id);
    if (!g) { el.innerHTML = '<div class="notice err">No such group, or you cannot see it. <a href="#/groups">All groups</a></div>'; return; }
    const kids = m.groups.filter((x) => x.parent === id);
    const allDevs = tr.devices.filter((d) => MC.inGroup(d, id) || kids.some((k) => MC.inGroup(d, k.id)));
    const sens = tr.sensors.filter((s) => allDevs.some((d) => d.id === s.device));
    const fam = {}; for (const s of sens) { const f = s.type.split('.')[0]; fam[f] = fam[f] || {}; fam[f][s.state] = (fam[f][s.state] || 0) + 1; }
    const alarms = sens.filter((s) => (s.state === 'Down' || s.state === 'Warning') && !s.related);
    const c = g.counts;
    el.innerHTML = `<div class="toolbar"><a class="btn sm ghost" href="#/groups">← All groups</a>${g.path.length ? `<span class="muted">${esc(g.path.join(' › '))} ›</span>` : ''}<b>${esc(g.name)}</b><span class="spacer"></span>${admin() ? `<button class="btn sm" id="gEd">Edit group</button>${(tr.groups.find((x) => x.id === id) || {}).auto || (tr.groups.find((x) => x.id === id) || {}).builtIn ? '' : '<button class="btn sm ghost" id="gDel">Delete group</button>'}` : ''}<a class="btn sm" href="#/sensors">Open the device tree</a></div>
      <div class="kpis">${MC.kpi('Health', g.health == null ? '–' : fmt(g.health, 1) + '%', 'sensors weighted by state')}${MC.kpi('Devices', allDevs.length, kids.length ? kids.length + ' sub-groups' : '')}${MC.kpi('Sensors', sens.length, '')}${MC.kpi('Down', c.Down || 0, (c.Ack || 0) + ' acknowledged', { alert: (c.Down || 0) > (c.Ack || 0) })}${MC.kpi('Warning', c.Warning || 0, '')}</div>
      <div class="grid g3">
        ${MC.panel('Sensor states', '', '<div id="gdD"></div>')}
        ${MC.panel('By sensor family', 'states per kind of check', C.barList(Object.entries(fam).sort((a, b) => ((b[1].Down || 0) - (a[1].Down || 0)) || (Object.values(b[1]).reduce((x, y) => x + y, 0) - Object.values(a[1]).reduce((x, y) => x + y, 0))).slice(0, 9).map(([k, v]) => ({ label: k, value: Object.values(v).reduce((x, y) => x + y, 0), text: (v.Down ? v.Down + ' down · ' : '') + (v.Warning ? v.Warning + ' warn · ' : '') + (v.Up || 0) + ' up', status: v.Down ? 'Critical' : v.Warning ? 'Warning' : 'OK' })), { compact: true }))}
        ${MC.panel('Devices', 'colour = worst sensor state', `<div class="devtiles big">${allDevs.map(tile).join('')}</div><div class="mc-legend" style="margin-top:8px">${['Down', 'Warning', 'Up', 'Unknown'].map((k) => `<span><i style="background:var(${STC[k]})"></i>${k}<b>${allDevs.filter((d) => d.state === k).length}</b></span>`).join('')}</div>`)}
      </div>
      ${MC.panel('Open alarms in ' + g.name, alarms.length + ' sensors, grouped by device', resourceList(alarms, tr))}
      ${MC.panel('Devices in ' + g.name, '', '<div id="gdT"></div>')}`;
    const tg = tr.groups.find((x) => x.id === id);
    if ($('#gEd', el)) $('#gEd', el).addEventListener('click', () => MC.groupDialog(tr, tg, () => V.groups.render(el, MC.route)));
    if ($('#gDel', el)) $('#gDel', el).addEventListener('click', () => MC.deleteGroupDialog(tr, tg, () => MC.go('groups')));
    C.donut($('#gdD', el), [['Down', '--crit'], ['Warning', '--warn'], ['Up', '--ok'], ['Paused', '--s1'], ['Unknown', '--muted']].map(([k, col]) => ({ label: k, value: c[k] || 0, color: col })).filter((x) => x.value), { center: g.health == null ? '–' : fmt(g.health, 0) + '%', centerLabel: 'health' });
    MC.table($('#gdT', el), allDevs, [
      { key: 'state', label: 'State', html: (d) => `<span class="sdot ${esc(d.state)}" style="display:inline-block;margin:0 6px 0 0"></span>${esc(d.state)}` },
      { key: 'name', label: 'Device', html: (d) => `<a href="#/device/${enc(d.id)}">${esc(d.name)}</a>` },
      { key: 'host', label: 'Host', cls: 'mono' }, { key: 'kind', label: 'Type' },
      { key: 'sensors', label: 'Sensors', n: true },
      { key: 'counts', label: 'Sensor states', html: (d) => stackOf(d.counts || {}), val: (d) => -((d.counts || {}).Down || 0) },
    ], { name: 'group-devices', limit: 50, sort: 'counts', dir: 1 });
  }

  // alarms grouped by device ("resource"), worst first
  function resourceList(alarms, tr) {
    if (!alarms.length) return '<div class="mc-empty">No open alarms.</div>';
    const by = new Map();
    for (const s of alarms) { if (!by.has(s.device)) by.set(s.device, []); by.get(s.device).push(s); }
    const devs = new Map(tr.devices.map((d) => [d.id, d]));
    const rows = [...by.entries()].map(([id, list]) => ({ d: devs.get(id) || { id, name: id }, list: list.sort((a, b) => (a.state === 'Down' ? 0 : 1) - (b.state === 'Down' ? 0 : 1)) })).sort((a, b) => b.list.filter((s) => s.state === 'Down').length - a.list.filter((s) => s.state === 'Down').length || b.list.length - a.list.length);
    return `<div class="reslist">${rows.map(({ d, list }) => `<div class="resrow"><div class="resname"><span class="sdot ${list.some((s) => s.state === 'Down' && !s.ack) ? 'Down' : list.some((s) => s.state === 'Down') ? 'Ack' : 'Warning'}"></span><a href="#/device/${enc(d.id)}"><b>${esc(d.name)}</b></a><span class="muted">${esc(d.kind || '')}${d.host ? ' · ' + esc(d.host) : ''}</span></div><div class="reschips">${list.map((s) => `<a class="achip ${s.ack ? 'Ack' : s.state}" href="#/sensor/${enc(s.id)}" title="${esc(s.message || '')}">${esc(s.name)}${s.value ? ` <span>${esc(s.value)}</span>` : ''}<small>${ago(s.since).replace(' ago', '')}</small></a>`).join('')}</div></div>`).join('')}</div>`;
  }

  // Alarms › By group
  MC.alarmsByGroup = function (el, tr) {
    const devName = new Map(tr.devices.map((d) => [d.id, d.name]));
    for (const s of tr.sensors) s.deviceName = s.deviceName || devName.get(s.device);
    const m = model(tr);
    const gs = m.groups.filter((g) => g.alarms.length).sort((a, b) => b.alarms.filter((s) => s.state === 'Down').length - a.alarms.filter((s) => s.state === 'Down').length || b.alarms.length - a.alarms.length);
    const fams = [...new Set(gs.flatMap((g) => g.alarms.map((s) => s.type.split('.')[0])))].sort();
    el.innerHTML = `<div class="kpis">${MC.kpi('Groups with alarms', gs.length, 'of ' + m.groups.filter((g) => g.devices.length).length)}${MC.kpi('Resources affected', new Set(gs.flatMap((g) => g.alarms.map((s) => s.device))).size, 'devices with an open alarm')}${MC.kpi('Down', gs.reduce((a, g) => a + g.alarms.filter((s) => s.state === 'Down').length, 0), '', { alert: gs.some((g) => g.alarms.some((s) => s.state === 'Down')) })}${MC.kpi('Warning', gs.reduce((a, g) => a + g.alarms.filter((s) => s.state === 'Warning').length, 0), '')}</div>
      ${gs.length ? MC.panel('Where the alarms are', 'groups × sensor family, number of open alarms', '<div id="abHeat"></div>') : ''}
      ${gs.map((g) => `<section class="card panel-c grp-alarms st-${esc(g.state)}"><div class="panel-h"><h3><a href="#/groups/${enc(g.id)}">${esc(g.name)}</a></h3><span class="sub">${g.alarms.filter((s) => s.state === 'Down').length} down · ${g.alarms.filter((s) => s.state === 'Warning').length} warning · ${new Set(g.alarms.map((s) => s.device)).size} of ${g.devices.length} devices</span><div class="act" style="min-width:160px">${stackOf(g.counts)}</div></div>${resourceList(g.alarms, tr)}</section>`).join('') || '<div class="card panel-c empty">No alarms. Every group is healthy.</div>'}`;
    if (gs.length) C.heatmap($('#abHeat', el), gs.slice(0, 14).map((g) => ({ label: g.name.length > 16 ? g.name.slice(0, 15) + '…' : g.name, id: g.id, values: fams.map((f) => g.alarms.filter((s) => s.type.split('.')[0] === f).length || null) })), fams, { labelWidth: 130, rowHeight: 22, max: Math.max(1, ...gs.flatMap((g) => fams.map((f) => g.alarms.filter((s) => s.type.split('.')[0] === f).length))), metric: 'Open alarms', onRow: (r) => MC.go('groups', r.id) });
  };
})(typeof self !== 'undefined' ? self : this);
