/*
 * RoboMate MonCastle - what a sensor needs before it reports, as numbered steps (browser: window.MCReq, server: require).
 * steps(ctx) checks one sensor type on one device: the device address, the monitoring engine (engine sensors), the network
 * path from the MonCastle server, the credential, the rights and modules, and whether data has arrived. Each step has a
 * status: ok (done), todo (you must do this), check (MonCastle cannot verify it; confirm it yourself) or info.
 * Nothing here holds or shows a secret: credentials are named, never read.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCReq = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const KIND_LABEL = { windows: 'Windows', ssh: 'SSH (Linux)', snmp: 'SNMP', snmpv2: 'SNMP v2c', snmpv3: 'SNMP v3', http: 'HTTP / API', sql: 'SQL Server', database: 'database', vmware: 'VMware vCenter', cloud: 'cloud account' };
  const label = (k) => KIND_LABEL[k] || k;

  // network path a native (probe) sensor uses, from its parameters
  function nativePorts(type, params) {
    const p = params || {};
    switch (type.id) {
      case 'ping': return [{ name: 'ICMP echo', port: '-', proto: 'ICMP' }];
      case 'port': return [{ name: 'TCP port', port: String(p.port || 443), proto: 'TCP' }];
      case 'http': { let port = '443'; try { const u = new URL(p.url || 'https://x/'); port = u.port || (u.protocol === 'http:' ? '80' : '443'); } catch (e) { /* default */ } return [{ name: 'HTTP(S)', port, proto: 'TCP' }]; }
      case 'dns': return [{ name: 'DNS', port: '53', proto: 'UDP' }];
      case 'sslcert': return [{ name: 'TLS', port: String(p.port || 443), proto: 'TCP' }];
      case 'db.service': return [{ name: 'Database', port: String(p.port || 'engine default'), proto: 'TCP' }];
      case 'script': return [];
      default: return /^snmp\./.test(type.id) ? [{ name: 'SNMP', port: '161', proto: 'UDP' }] : [];
    }
  }
  // credential kind a sensor needs: native SNMP needs SNMP unless a community is typed in; engines say it in their manifest
  function credKind(type, script, perms, params) {
    if (type.source === 'native') {
      if (/^snmp\./.test(type.id)) return (params && params.community) ? null : 'snmp';
      if (type.id === 'db.service') return 'database?';
      return null;
    }
    if (script && script.credential) return script.credential;
    return perms && perms.credentials && perms.credentials[0] || null;
  }

  /*
   * ctx = { type, device: {id,name,host,kind,group,credentials}, chain: [groupIds], creds: [{id,name,kind,assign}] | null,
   *         script (manifest entry) | null, engine: {state,lastStatus,lastRun,message,host,runAs} | null | undefined,
   *         perms (MCEngineInfo.permissions) | null, sensor: {lastScan,state,message,pending,params} | null, resolve (MCCredModel.resolve),
   *         kindsFor (MCCredModel.kindsFor), server: name of the MonCastle server that polls the device }
   */
  function steps(ctx) {
    const t = ctx.type || {}, d = ctx.device || {}, s = ctx.sensor || null, out = [];
    const collector = t.source === 'collector';
    const from = ctx.server ? 'the MonCastle server ' + ctx.server : 'the MonCastle server';
    const add = (id, title, status, detail, action) => out.push({ id, title, status, detail: detail || '', action: action || null });

    // 1. address
    if (d.host) add('host', 'Device address', 'ok', `MonCastle reaches ${d.name || 'the device'} at ${d.host}.`);
    else add('host', 'Device address', 'todo', 'Set the host name or IP address of the device under Settings, so MonCastle and its engines can reach it.', 'device');

    // 2. engine, or the probe running the collector directly for this device
    if (collector && ctx.direct) {
      if (!ctx.script) add('engine', 'Script ' + (t.script || ''), 'todo', `The ${t.script} script is not in the script library yet. MonCastle fetches the library from GitHub on its own (at start, hourly and when a script is missing); nothing to do by hand.`, 'library');
      else add('engine', 'Runs from the probe', 'info', `The probe runs ${t.script} for ${d.name || 'this device'} only${ctx.interval ? ', every ' + ctx.interval + ' s' : ''}. No monitoring engine is needed.`);
    } else if (collector) {
      const e = ctx.engine;
      if (!ctx.script) add('engine', 'Monitoring engine ' + (t.script || ''), 'todo', `The ${t.script} script is not in the script library yet. MonCastle fetches the library from GitHub on its own (at start, hourly and when a script is missing); nothing to do by hand.`, 'library');
      else if (e === undefined) add('engine', 'Monitoring engine: ' + (ctx.script.title || t.script), 'check', 'You cannot see engine status with your role. Ask an administrator to check that this engine is turned on.');
      else if (!e || e.state === 'Disabled' || e.state === 'Not configured' || !e.state) add('engine', 'Turn on the engine: ' + (ctx.script.title || t.script), 'todo', `This sensor is fed by the ${t.script} engine, which is turned off. Turn it on; it then also reads ${d.name || 'this device'}.`, 'engine-on');
      else if (e.state === 'Running') add('engine', 'Engine: ' + (ctx.script.title || t.script), 'info', 'The engine is collecting now.');
      else if (e.lastStatus === 'error') add('engine', 'Engine: ' + (ctx.script.title || t.script), 'todo', 'The engine failed on its last run' + (e.message ? ': ' + e.message : '') + '. Fix the cause (often one of the steps below) and run it again.', 'engine-run');
      else if (!e.lastRun) add('engine', 'Engine: ' + (ctx.script.title || t.script), 'check', 'The engine is on but has not run yet.', 'engine-run');
      else add('engine', 'Engine: ' + (ctx.script.title || t.script), 'ok', `On, last run ${e.lastRun.slice(0, 16).replace('T', ' ')} UTC${e.every ? ', every ' + e.every : ''}.`);
      if (ctx.script) add('targets', 'Device in the engine\'s targets', 'ok', `Adding the sensor puts ${d.name || 'the device'} in the ${t.script} target list, so the next run reads it.`);
    }

    // 3. network path
    const ports = collector ? ((ctx.perms && ctx.perms.ports) || []) : nativePorts(t, (s && s.params) || ctx.params);
    if (ports.length) {
      const list = ports.map((p) => `${p.name} ${p.proto}${p.port && p.port !== '-' ? ' ' + p.port : ''}`).join(', ');
      const ok = s && s.lastScan && s.state === 'Up' && !s.pending;
      add('network', 'Network path', ok ? 'ok' : 'check', `Open from ${from} to ${d.host || 'the device'}: ${list}.${collector && ports.some((p) => p.name === 'WinRM') ? ' On the device run Enable-PSRemoting -Force once (Windows Server has it on by default).' : ''}`);
    }

    // 4. credential
    let kind = credKind(t, ctx.script, ctx.perms, (s && s.params) || ctx.params);
    const optional = /\?$/.test(kind || ''); kind = kind && kind.replace(/\?$/, '');
    if (kind) {
      const r = ctx.creds && ctx.resolve ? ctx.resolve(ctx.creds, d, ctx.chain || [], kind) : null;
      if (!ctx.creds) add('cred', label(kind) + ' credential', 'check', `This sensor signs in with a ${label(kind)} credential. You cannot list credentials with your role; ask an administrator to assign one to ${d.name || 'the device'} or its group.`);
      else if (r) add('cred', label(kind) + ' credential', 'ok', `Uses "${r.cred.name || r.cred.id}" (assigned to the ${r.from}). The secret stays on the console.`);
      else if (optional) add('cred', 'Database credential (optional)', 'info', 'Without one the sensor checks that the database answers; with one it also reads health metrics.', 'creds');
      else if (kind === 'windows') add('cred', 'Windows credential', 'check', `No Windows credential is assigned to ${d.name || 'the device'}, its group or the probe. ${ctx.direct ? 'The probe' : 'The engine'} then uses the account that runs MonCastle${!ctx.direct && ctx.engine && ctx.engine.host === 'task' ? ' (' + (ctx.engine.runAs || 'SYSTEM') + ')' : ''}, which must have the rights below. Assign one under Configure › Credentials if it does not.`, 'creds');
      else add('cred', label(kind) + ' credential', 'todo', `Add a ${label(kind)} credential under Configure › Credentials and assign it to ${d.name || 'the device'}, its group or the whole probe.`, 'creds');
      if (ctx.kindsFor && d.kind && !ctx.kindsFor(d.kind).concat(['snmp']).includes(kind) && kind !== 'vmware' && kind !== 'cloud') add('fit', 'Device type', 'check', `${t.name} reads ${label(kind)}, and ${d.name || 'the device'} is a ${d.kind}. Make sure the device really offers ${label(kind)}.`);
    }

    // 5. rights and modules
    if (collector && ctx.perms) {
      const rights = (ctx.perms.rights || []).map((r) => r.need + (r.why ? ' (' + r.why + ')' : ''));
      if (ctx.script && ctx.script.permissions && !rights.some((x) => x.indexOf(ctx.script.permissions) === 0)) rights.unshift(ctx.script.permissions);
      if (rights.length) add('rights', 'Rights for the account', 'check', rights.join('; ') + '.');
      if ((ctx.perms.modules || []).length) add('modules', 'PowerShell modules on ' + (ctx.server || 'the MonCastle server'), 'check', 'Install ' + ctx.perms.modules.join(', ') + ' where the engine runs.');
    }
    if (t.id === 'script' && !(s && s.params && s.params.script)) add('script', 'Script', 'todo', 'Choose the library script this sensor runs.', 'settings');

    // 6. data
    if (s && s.lastScan && !s.pending) add('data', 'Data received', s.state === 'Unknown' ? 'check' : 'ok', 'Last data ' + s.lastScan.slice(0, 16).replace('T', ' ') + ' UTC' + (s.state === 'Down' && s.message ? '. It is Down: ' + s.message : '.'));
    else if (s && ctx.direct) add('data', 'Data received', 'check', 'Waiting for the first scan. If it stays Down, its message says which step above is missing.', 'scan');
    else if (s) add('data', 'Data received', collector ? 'todo' : 'check', collector ? `The ${t.script} engine has not reported ${d.name || 'this device'} yet. Finish the steps above, then run the engine.` : 'Waiting for the first scan.', collector ? (out.some((x) => /^engine/.test(x.action || '')) ? null : 'engine-run') : 'scan');
    else add('data', 'Data received', 'info', collector && !ctx.direct ? 'Data arrives after the engine\'s next run.' : 'The first scan runs a few seconds after you add the sensor.');

    out.forEach((x, i) => { x.n = i + 1; });
    return out;
  }
  const summary = (list) => {
    const todo = list.filter((x) => x.status === 'todo').length, check = list.filter((x) => x.status === 'check').length;
    return { todo, check, ready: !todo, text: todo ? `${todo} step${todo > 1 ? 's' : ''} to do` + (check ? `, ${check} to confirm` : '') : check ? `Ready; ${check} item${check > 1 ? 's' : ''} to confirm` : 'All requirements met' };
  };
  return { steps, summary, label };
});
