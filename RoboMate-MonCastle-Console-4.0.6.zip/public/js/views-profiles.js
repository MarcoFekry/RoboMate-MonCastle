/*
 * RoboMate MonCastle - Configure > Monitoring profiles (4.7.4): a profile is the monitoring of one type of device in
 * one place: the monitoring options to turn on, the sensors to add (probe or engine) and the actions to offer. Assign
 * a profile to device groups (with their subgroups and the devices that are also members) or to single devices, or let
 * it apply to every device of its types. The rules live in monitor-core.js (setProfile, assignProfile, applyProfiles).
 */
(function (root) {
  'use strict';
  const MC = root.MC, S = root.MCSensors;
  const { esc, icon, ago, $, $$ } = MC;
  const V = MC.views;
  const admin = () => MC.user && (MC.user.role === 'admin' || MC.user.override);
  const KIND = Object.fromEntries(S.CLASSES.map(([k, l]) => [k, l]));
  const kindsText = (p) => (p.kinds.length ? p.kinds.map((k) => KIND[k] || k).slice(0, 4).join(', ') + (p.kinds.length > 4 ? ' +' + (p.kinds.length - 4) : '') : 'Any device type');
  const modal = (html, onReady) => {
    const m = document.createElement('div');
    m.className = 'modal'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true');
    m.innerHTML = `<div class="card wide">${html}</div>`;
    document.body.appendChild(m);
    const close = () => m.remove();
    $$('[data-x]', m).forEach((b) => b.addEventListener('click', close));
    m.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    if (onReady) onReady(m, close);
    return m;
  };
  const runnable = () => (MC.manifest.scripts || []).filter((s) => s.kind !== 'collector');
  // a starting point per device type: its default monitoring options and the matching action catalog
  const STARTERS = [
    ['server', 'Windows server baseline', ['restart', 'service']],
    ['workstation', 'Windows workstation baseline', ['restart', 'update']],
    ['linux', 'Linux server baseline', ['linux']],
    ['network', 'Switch or router', ['network']],
    ['firewall', 'Firewall', ['network']],
    ['database', 'Database server', ['database']],
    ['printer', 'Printer', ['printer']],
  ];

  V.profiles = {
    title: 'Monitoring profiles',
    crumb: () => 'the options, sensors and actions for each type of device, assigned to groups or devices',
    async render(el) {
      el.innerHTML = '<div class="notice">Loading profiles…</div>';
      let list, tr;
      try { [list, tr] = await Promise.all([MC.api.monitor('profiles'), MC.api.monitor('tree')]); } catch (e) { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; return; }
      if (!document.body.contains(el)) return;
      const gname = Object.fromEntries(tr.groups.map((g) => [g.id, g.name]));
      const dname = Object.fromEntries(tr.devices.map((d) => [d.id, d.name]));
      const covered = new Set(tr.devices.filter((d) => (d.profiles || []).length).map((d) => d.id));
      const sens = list.reduce((a, p) => a + (p.sensorsAdded || 0), 0);
      el.innerHTML = `<div class="kpis">${MC.kpi('Profiles', list.length, list.filter((p) => p.auto).length + ' apply to every device of their types')}${MC.kpi('Devices covered', covered.size, 'of ' + tr.devices.length + ' devices')}${MC.kpi('Sensors from profiles', sens, 'removed again when a profile no longer applies')}${MC.kpi('Without a profile', tr.devices.length - covered.size, 'devices', { href: '#/sensors' })}</div>
        <div class="notice">${icon('info', 'sev-ico')} A profile turns on monitoring options, adds sensors and offers actions for one type of device. Assign it to <b>device groups</b> (subgroups and devices that are also members of the group are included), to <b>single devices</b>, or let it apply to <b>every device of its types</b>, also new ones from auto-discovery or an import. A device covered by several profiles gets all of their sensors once.</div>
        ${MC.panel('Profiles', list.length ? 'choose a profile to change it' : 'none yet', '<div id="mpT"></div>', { act: admin() ? `<button class="btn sm primary" id="mpNew">${icon('plus', 'sev-ico')}New profile</button><button class="btn sm" id="mpStart">From a device type…</button>${list.length ? '<button class="btn sm ghost" id="mpApply">Apply again</button>' : ''}` : '' })}
        ${admin() ? '' : '<p class="muted" style="font-size:12.5px">Administrators create and change profiles. Contributors assign them to the devices and groups they manage, on the device page.</p>'}`;
      const scopeText = (p) => [p.groups.length ? p.groups.map((g) => gname[g] || g).slice(0, 3).join(', ') + (p.groups.length > 3 ? ' +' + (p.groups.length - 3) : '') : '', p.devices.length ? (p.devices.length > 2 ? p.devices.length + ' devices' : p.devices.map((x) => dname[x] || x).join(', ')) : '', p.auto ? 'every ' + kindsText(p).toLowerCase() : ''].filter(Boolean).join(' · ') || 'not assigned';
      MC.table($('#mpT', el), list, [
        { key: 'name', label: 'Profile', html: (p) => `<a href="#" data-mp="${esc(p.id)}"><b>${esc(p.name)}</b></a>${p.description ? `<div class="muted" style="font-size:12px">${esc(p.description)}</div>` : ''}` },
        { key: 'kinds', label: 'Device types', html: (p) => esc(kindsText(p)), val: kindsText },
        { key: 'options', label: 'Options', n: true, val: (p) => p.options.length },
        { key: 'sensors', label: 'Sensors', n: true, val: (p) => p.sensors.length },
        { key: 'actions', label: 'Actions', n: true, val: (p) => p.actions.length },
        { key: 'scope', label: 'Assigned to', html: (p) => esc(scopeText(p)), val: scopeText },
        { key: 'covers', label: 'Devices', n: true },
        { key: 'updated', label: 'Changed', html: (p) => `${ago(p.updated)}${p.updatedBy ? ' <span class="muted">' + esc(p.updatedBy) + '</span>' : ''}`, val: (p) => p.updated || '' },
        { key: 'act', label: '', noCsv: true, html: (p) => (admin() ? `<div class="actions-row" style="flex-wrap:nowrap"><button class="btn sm ghost" data-mp="${esc(p.id)}">Edit</button><button class="btn sm ghost" data-mpdel="${esc(p.id)}">Delete</button></div>` : '') },
      ], { sort: 'name', dir: 1, name: 'monitoring-profiles', empty: 'No profile yet. Start from a device type to get its usual options and sensors.', after: (w) => {
        $$('[data-mp]', w).forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); const p = list.find((x) => x.id === a.dataset.mp); if (admin()) editor(p, tr, () => V.profiles.render(el)); else viewer(p, tr); }));
        $$('[data-mpdel]', w).forEach((b) => b.addEventListener('click', () => { const p = list.find((x) => x.id === b.dataset.mpdel); modal(`<h3>Delete ${esc(p.name)}?</h3><p class="muted">The ${p.sensorsAdded} sensors it added on ${p.covers} devices are removed, and the monitoring options it turned on are turned off again unless another profile uses them. Sensors you added by hand stay.</p><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn danger" id="go">Delete profile</button></div>`, (m, close) => { $('#go', m).addEventListener('click', async () => { try { const r = await MC.api.monitor('deleteProfile', { id: p.id }); close(); MC.toast('Deleted ' + esc(p.name) + ': ' + r.removed + ' sensors removed', 'ok'); V.profiles.render(el); } catch (e) { MC.toast(esc(e.message), 'err'); } }); }); }));
      } });
      if ($('#mpNew', el)) $('#mpNew', el).addEventListener('click', () => editor(null, tr, () => V.profiles.render(el)));
      if ($('#mpStart', el)) $('#mpStart', el).addEventListener('click', () => modal(`<h3>Start from a device type</h3><p class="muted">The profile starts with the usual monitoring options of that type and the actions of its catalog. You change everything before saving.</p><div class="grid" style="gap:6px">${STARTERS.map(([k, t]) => `<button class="btn" data-k="${k}" style="justify-content:flex-start">${esc(t)} <span class="muted" style="margin-left:auto">${esc(KIND[k] || k)}</span></button>`).join('')}</div><div class="foot"><button class="btn" data-x>Cancel</button></div>`, (m, close) => $$('[data-k]', m).forEach((b) => b.addEventListener('click', () => { close(); const st = STARTERS.find((x) => x[0] === b.dataset.k); editor(starter(st), tr, () => V.profiles.render(el)); }))));
      if ($('#mpApply', el)) $('#mpApply', el).addEventListener('click', async () => { try { const r = await MC.api.monitor('applyProfiles', {}); MC.toast(`Profiles applied: ${r.added} sensors added, ${r.removed} removed on ${r.devices} devices`, 'ok'); V.profiles.render(el); } catch (e) { MC.toast(esc(e.message), 'err'); } });
    },
  };
  function starter([kind, name, words]) {
    const opts = S.optionsFor(kind).filter((o) => S.optionDefault(o, kind, [])).map((o) => o.id);
    const acts = runnable().filter((s) => (s.targets || []).includes(kind) && s.kind === 'action').filter((s) => words.some((w) => (s.id + ' ' + s.title).toLowerCase().includes(w))).slice(0, 4).map((s) => ({ script: s.id, label: s.title, params: {} }));
    return { name, description: '', kinds: [kind], options: opts, sensors: [], actions: acts, groups: [], devices: [], auto: false, fresh: true };
  }
  function viewer(p, tr) {
    const dname = Object.fromEntries(tr.devices.map((d) => [d.id, d.name]));
    modal(`<h3>${esc(p.name)}</h3><p class="muted">${esc(p.description || '')}</p><dl class="kv"><dt>Device types</dt><dd>${esc(kindsText(p))}</dd><dt>Options</dt><dd>${p.options.map((x) => esc((S.OPTIONS.find((o) => o.id === x) || {}).name || x)).join('<br>') || '–'}</dd><dt>Sensors</dt><dd>${p.sensors.map((x) => esc(x.name)).join('<br>') || '–'}</dd><dt>Actions</dt><dd>${p.actions.map((a) => esc(a.label || a.script)).join('<br>') || '–'}</dd><dt>Covers</dt><dd>${(p.coveredDevices || []).slice(0, 40).map((x) => esc(dname[x] || x)).join(', ') || 'no device'}</dd></dl><div class="foot"><button class="btn" data-x>Close</button></div>`);
  }
  // the editor: general, options, sensors, actions, assignment
  function editor(p, tr, done) {
    const st = JSON.parse(JSON.stringify(p || { name: '', description: '', kinds: [], options: [], sensors: [], actions: [], groups: [], devices: [], auto: false }));
    const types = S.TYPES.filter((t) => !t.passive && (t.source === 'native' || t.script));
    const kindsOf = () => st.kinds;
    const optList = () => S.OPTIONS.filter((o) => !kindsOf().length || o.kinds === '*' || kindsOf().some((k) => (o.kinds || []).includes(k)));
    const paramField = (t, x, i) => (t.source === 'native' ? (t.params || []).filter((d) => !d.fromDevice && !d.secret).slice(0, 4).map((d) => `<label class="muted" style="font-size:12px">${esc(d.label || d.name)} <input class="input mono" style="width:120px" data-sp="${i}" data-pn="${esc(d.name)}" value="${esc(x.params[d.name] != null ? x.params[d.name] : d.def != null ? d.def : '')}"></label>`).join('') : `<select class="input" data-smode="${i}" style="width:auto" aria-label="How it runs"><option value="engine" ${x.mode !== 'probe' ? 'selected' : ''}>Engine (${esc(t.script)})</option>${t.dataset ? `<option value="probe" ${x.mode === 'probe' ? 'selected' : ''}>Probe, this device only</option>` : ''}</select>`);
    const sensorRows = () => st.sensors.map((x, i) => { const t = S.TYPE[x.type] || {}; return `<div class="actions-row" style="flex-wrap:wrap;border-bottom:1px solid var(--line);padding:6px 0"><b style="min-width:180px">${esc(t.name || x.type)}</b><input class="input" data-sn="${i}" value="${esc(x.name)}" style="width:200px" aria-label="Sensor name">${paramField(t, x, i)}<button class="btn sm ghost" type="button" data-sdel="${i}" style="margin-left:auto">Remove</button></div>`; }).join('') || '<div class="muted">No sensors. Monitoring options above already add their usual sensors; add more here.</div>';
    const actRows = () => st.actions.map((a, i) => { const s = MC.script(a.script) || {}; return `<div class="actions-row" style="flex-wrap:wrap;border-bottom:1px solid var(--line);padding:6px 0"><b style="min-width:180px">${esc(s.title || a.script)}</b><input class="input" data-al="${i}" value="${esc(a.label || '')}" placeholder="Button text" style="width:200px" aria-label="Button text"><input class="input mono" data-ap="${i}" value="${esc(Object.entries(a.params || {}).map(([k, v]) => k + '=' + v).join('; '))}" placeholder="Name=nginx; Force=true" style="width:220px" aria-label="Parameters"><button class="btn sm ghost" type="button" data-adel="${i}" style="margin-left:auto">Remove</button></div>`; }).join('') || '<div class="muted">No actions. Actions appear as buttons on the page of every device the profile covers.</div>';
    const groups = tr.groups.slice().sort((a, b) => a.name.localeCompare(b.name));
    const devs = tr.devices.slice().sort((a, b) => a.name.localeCompare(b.name));
    modal(`<h3>${p && p.id ? 'Change ' + esc(p.name) : 'New monitoring profile'}</h3>
      <div class="steps" role="tablist"><button class="on" data-step="1">General</button><button data-step="2">Options</button><button data-step="3">Sensors</button><button data-step="4">Actions</button><button data-step="5">Assign</button></div>
      <div data-pane="1"><div class="grid g2"><div class="field"><label for="pn">Name</label><input class="input" id="pn" value="${esc(st.name)}" maxlength="80"></div><div class="field"><label for="pdsc">Description</label><input class="input" id="pdsc" value="${esc(st.description)}" maxlength="400"></div></div>
        <fieldset class="field"><legend>Device types <span class="muted">(none = any type)</span></legend><div class="pick-list" style="grid-template-columns:repeat(auto-fill,minmax(190px,1fr))">${S.CLASSES.map(([k, l]) => `<label class="check"><input type="checkbox" data-kind="${k}" ${st.kinds.includes(k) ? 'checked' : ''}> ${esc(l)}</label>`).join('')}</div></fieldset>
        <label class="check"><input type="checkbox" id="pauto" ${st.auto ? 'checked' : ''}> Apply to every device of these types, also new ones from auto-discovery or an import</label></div>
      <div data-pane="2" hidden><p class="muted" style="margin-top:0">Monitoring options turned on for the devices this profile covers. Engine options also add the device to that engine's targets, so the engine is configured for it.</p><div class="pick-list" id="popts" style="max-height:340px"></div></div>
      <div data-pane="3" hidden><div class="actions-row"><select class="input" id="ptype" style="flex:1" aria-label="Sensor type">${[...new Set(types.map((t) => t.category))].map((c) => `<optgroup label="${esc(c)}">${types.filter((t) => t.category === c).map((t) => `<option value="${esc(t.id)}">${esc(t.name)}${t.source === 'native' ? '' : ' (engine)'}</option>`).join('')}</optgroup>`).join('')}</select><button class="btn" type="button" id="padd">${icon('plus', 'sev-ico')}Add sensor</button></div><div id="psens" style="margin-top:8px"></div></div>
      <div data-pane="4" hidden><div class="actions-row"><select class="input" id="pact" style="flex:1" aria-label="Action">${runnable().map((s) => `<option value="${esc(s.id)}">${esc(s.title)} (${esc(s.kind === 'action' ? 'change' : 'read-only')})</option>`).join('')}</select><button class="btn" type="button" id="paadd">${icon('plus', 'sev-ico')}Add action</button></div><div id="pacts" style="margin-top:8px"></div><p class="muted" style="font-size:12px">The device's address fills the action's computer or host parameter. Running an action still asks for confirmation and follows the user's role.</p></div>
      <div data-pane="5" hidden><div class="grid g2"><div class="field"><label for="pg">Device groups <span class="muted">(subgroups included)</span></label><select class="input" id="pg" multiple size="9">${groups.map((g) => `<option value="${esc(g.id)}" ${st.groups.includes(g.id) ? 'selected' : ''}>${esc(g.name)} (${g.devices})</option>`).join('')}</select></div>
        <div class="field"><label for="pd">Single devices</label><input class="input" id="pdq" placeholder="Filter devices" style="margin-bottom:4px" aria-label="Filter devices"><select class="input" id="pd" multiple size="8">${devs.map((d) => `<option value="${esc(d.id)}" ${st.devices.includes(d.id) ? 'selected' : ''}>${esc(d.name)} (${esc(KIND[d.kind] || d.kind)})</option>`).join('')}</select></div></div>
        <p class="muted" style="font-size:12.5px">Only devices of the chosen types get the profile, also when their group is assigned.</p></div>
      <div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">${p && p.id ? 'Save and apply' : 'Create and apply'}</button></div>`, (m, close) => {
      const drawOpts = () => { $('#popts', m).innerHTML = optList().map((o) => `<label class="check"><input type="checkbox" data-opt="${esc(o.id)}" ${st.options.includes(o.id) ? 'checked' : ''}> <span>${esc(o.name)} <span class="muted" style="font-size:11.5px">${esc(o.area || '')}${o.script ? ' · engine ' + esc(o.script) : ''}</span></span></label>`).join('') || '<div class="muted">No option for these device types.</div>'; $$('[data-opt]', m).forEach((c) => c.addEventListener('change', () => { st.options = c.checked ? [...new Set(st.options.concat(c.dataset.opt))] : st.options.filter((x) => x !== c.dataset.opt); })); };
      const readRows = () => {
        $$('[data-sn]', m).forEach((x) => { st.sensors[+x.dataset.sn].name = x.value; });
        $$('[data-sp]', m).forEach((x) => { const s = st.sensors[+x.dataset.sp]; s.params[x.dataset.pn] = x.value; });
        $$('[data-smode]', m).forEach((x) => { st.sensors[+x.dataset.smode].mode = x.value; });
        $$('[data-al]', m).forEach((x) => { st.actions[+x.dataset.al].label = x.value; });
        $$('[data-ap]', m).forEach((x) => { st.actions[+x.dataset.ap].params = Object.fromEntries(x.value.split(';').map((y) => y.trim()).filter(Boolean).map((y) => { const i = y.indexOf('='); return i > 0 ? [y.slice(0, i).trim(), y.slice(i + 1).trim()] : [y, 'true']; })); });
      };
      const drawSens = () => { $('#psens', m).innerHTML = sensorRows(); $$('[data-sdel]', m).forEach((b) => b.addEventListener('click', () => { readRows(); st.sensors.splice(+b.dataset.sdel, 1); drawSens(); })); };
      const drawActs = () => { $('#pacts', m).innerHTML = actRows(); $$('[data-adel]', m).forEach((b) => b.addEventListener('click', () => { readRows(); st.actions.splice(+b.dataset.adel, 1); drawActs(); })); };
      drawOpts(); drawSens(); drawActs();
      $$('[data-kind]', m).forEach((c) => c.addEventListener('change', () => { st.kinds = $$('[data-kind]:checked', m).map((x) => x.dataset.kind); drawOpts(); }));
      $('#padd', m).addEventListener('click', () => { readRows(); const t = S.TYPE[$('#ptype', m).value]; const params = {}; for (const d of t.params || []) if (!d.fromDevice && !d.secret && d.def != null) params[d.name] = d.def; st.sensors.push({ type: t.id, name: t.name, params, mode: t.source === 'native' ? '' : 'engine' }); drawSens(); });
      $('#paadd', m).addEventListener('click', () => { readRows(); const s = MC.script($('#pact', m).value); st.actions.push({ script: s.id, label: s.title, params: {} }); drawActs(); });
      $('#pdq', m).addEventListener('input', (e) => { const q = e.target.value.toLowerCase(); [...$('#pd', m).options].forEach((o) => { o.hidden = !!q && !o.textContent.toLowerCase().includes(q); }); });
      $$('[data-step]', m).forEach((b) => b.addEventListener('click', () => { readRows(); $$('[data-pane]', m).forEach((x) => (x.hidden = x.dataset.pane !== b.dataset.step)); $$('[data-step]', m).forEach((x) => x.classList.toggle('on', x === b)); }));
      $('#go', m).addEventListener('click', async () => {
        readRows();
        const body = { id: p && p.id ? p.id : undefined, name: $('#pn', m).value, description: $('#pdsc', m).value, kinds: st.kinds, auto: $('#pauto', m).checked, options: st.options, sensors: st.sensors, actions: st.actions, groups: [...$('#pg', m).selectedOptions].map((o) => o.value), devices: [...$('#pd', m).selectedOptions].map((o) => o.value) };
        $('#go', m).disabled = true;
        try { const r = await MC.api.monitor('setProfile', body); close(); MC.toast(`${esc(r.name)} saved: covers ${r.covers} devices; ${r.applied.added} sensors added, ${r.applied.removed} removed`, 'ok'); done && done(); }
        catch (e) { $('#go', m).disabled = false; $('[data-err]', m).innerHTML = `<div class="notice err" style="margin-top:10px">${esc(e.message)}</div>`; }
      });
    });
  }
  // device page: the profiles covering a device, assign or remove one, and the profiles' actions as buttons
  MC.profilePanel = async (box, d) => {
    let list = [];
    try { list = await MC.api.monitor('profiles'); } catch (e) { box.innerHTML = ''; return; }
    if (!box.isConnected) return;
    const mine = list.filter((p) => (d.profiles || []).includes(p.id));
    const can = d.access === 'admin' || d.access === 'contributor' || (!d.access && (MC.user.role === 'admin' || MC.user.role === 'contributor')) || MC.user.override;
    const fits = list.filter((p) => !mine.includes(p) && (!p.kinds.length || p.kinds.includes(d.kind)));
    const host = d.host || d.name;
    const runParams = (a) => { const s = MC.script(a.script) || {}; const hp = (s.parameters || []).find((x) => /^(ComputerName|Target|Host|HostName|Device)$/i.test(x.name)); return Object.assign(hp ? { [hp.name]: host } : {}, a.params || {}); };
    const acts = mine.flatMap((p) => p.actions.map((a) => Object.assign({ profile: p.name }, a)));
    box.innerHTML = MC.panel('Monitoring profiles', mine.length ? mine.length + ' on this device' : 'none', `${mine.length ? `<ul class="plain">${mine.map((p) => `<li><b>${esc(p.name)}</b> <span class="muted" style="font-size:12px">${p.options.length} options · ${p.sensors.length} sensors · ${p.devices.includes(d.id) ? 'assigned to this device' : p.groups.length ? 'from its group' : 'every ' + esc(kindsText(p).toLowerCase())}</span>${can && p.devices.includes(d.id) ? ` <button class="btn sm ghost" data-unp="${esc(p.id)}">Remove</button>` : ''}</li>`).join('')}</ul>` : '<p class="muted" style="margin:0">No profile covers this device.</p>'}
      ${acts.length ? `<h4 style="margin:12px 0 6px">Profile actions</h4><div class="actions-row">${acts.map((a) => `<button class="btn sm" ${MC.runAttr(a.script, runParams(a))} title="${esc(a.profile)}">${icon('bolt', 'sev-ico')}${esc(a.label || (MC.script(a.script) || {}).title || a.script)}</button>`).join('')}</div>` : ''}
      ${can && fits.length ? `<div class="actions-row" style="margin-top:10px"><select class="input" id="dpSel" style="flex:1" aria-label="Profile">${fits.map((p) => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('')}</select><button class="btn sm" id="dpAdd">Assign profile</button></div>` : ''}${admin() ? '<p class="muted" style="font-size:12px;margin:8px 0 0"><a href="#/profiles">Manage profiles</a></p>' : ''}`);
    const redo = async (body, msg) => { try { const r = await MC.api.monitor('assignProfile', body); MC.toast(msg + ': ' + r.applied.added + ' sensors added, ' + r.applied.removed + ' removed', 'ok'); MC.render(); } catch (e) { MC.toast(esc(e.message), 'err'); } };
    if ($('#dpAdd', box)) $('#dpAdd', box).addEventListener('click', () => redo({ id: $('#dpSel', box).value, device: d.id }, 'Profile assigned'));
    $$('[data-unp]', box).forEach((b) => b.addEventListener('click', () => redo({ id: b.dataset.unp, device: d.id, on: false }, 'Profile removed')));
  };
})(typeof self !== 'undefined' ? self : this);
