/*
 * RoboMate MonCastle - PRTG-style monitoring views.
 *   Devices & sensors (probe > groups > devices > sensors), device page, sensor page (channels, limits, graphs, log),
 *   alarms and state log, connectors (sensor types), auto-discovery and notifications.
 * Data comes from MC.api.monitor(op, body); the same calls work against the server and the in-browser demo.
 */
(function (root) {
  'use strict';
  const MC = root.MC, C = root.MCCharts;
  const { esc, fmt, pill, icon, ago, dt, $, $$ } = MC;
  const V = MC.views;
  const api = (op, body) => MC.api.monitor(op, body);
  const enc = encodeURIComponent;

  const STATES = ['Down', 'Warning', 'Unknown', 'Up', 'Paused'];
  const COLOR = { Down: '--crit', Ack: '--serious', Warning: '--warn', Up: '--ok', Paused: '--s1', Unknown: '--muted' };
  const look = (s) => (s.ack && s.state === 'Down' ? 'Ack' : s.state);
  const stPill = (s) => (s.ack && s.state === 'Down' ? pill('Ack', 'Down (acknowledged)') : s.ack && s.state === 'Warning' ? pill('Warning', 'Warning (acknowledged)') : pill(s.state, s.state));
  const CM = root.MCCredModel, S = root.MCSensors, RB = root.MCRbac;
  const admin = () => MC.user.role === 'admin' || !!MC.user.override;
  // role on a device, group or sensor: the server adds "access" (from user groups) to each; else the console role
  const accOf = (x) => (admin() ? 'admin' : (x && x.access) || (MC.user.restricted ? 'none' : RB.norm(MC.user.role)));
  const canOn = (x) => RB.atLeast(accOf(x), 'contributor');
  const operator = (x) => canOn(x);
  const KIND_ICON = { external: 'bell', server: 'server', workstation: 'desktop', network: 'net', appliance: 'box', printer: 'printer', linux: 'linux', web: 'cloud', vm: 'layers', host: 'layers', datastore: 'db', cluster: 'layers', sql: 'db', domain: 'id' };
  // counts per state, for the stacked bars (the chart kit knows OK/Warning/Critical/Unknown)
  const stack = (c, opt) => C.statusStack({ Critical: (c.Down || 0) - (c.Acknowledged || 0), Offline: c.Acknowledged || 0, Warning: c.Warning || 0, OK: c.Up || 0, Unknown: (c.Unknown || 0) + (c.Paused || 0) }, opt);
  const sensorLink = (s) => '#/sensor/' + enc(s.id);
  const deviceLink = (id) => '#/device/' + enc(id);
  // ---- remote control: RDP, SSH or the device's web interface, opened in the person's own client and logged
  function remoteControlDialog(d) {
    const RC = root.MCRemoteControl, list = RC.methodsFor(d);
    modal(`<h3>Remote control · ${esc(d.name)}</h3>
      <p class="muted" style="margin-top:0">MonCastle prepares the session and logs it in Licences &amp; access. It opens in your own client with the user name of the device's credential; you type the password there. Your computer must reach <span class="mono">${esc(d.host || d.name)}</span>.</p>
      <div class="rc-list">${list.map((id) => { const m = RC.METHODS[id]; return `<div class="rc-row"><div><b>${esc(m.label)}</b><small>${esc(m.how)}</small></div><label class="rc-port">Port <input class="input sm mono" type="number" min="1" max="65535" value="${m.port}" data-rcp="${id}" aria-label="${esc(m.label)} port"></label><button class="btn sm primary" data-rc="${id}">${id === 'rdp' ? 'Download .rdp' : 'Open'}</button></div>`; }).join('')}</div>
      <div id="rcOut"></div><div data-err></div>
      <div class="foot"><button class="btn" data-x>Close</button></div>`, (m) => {
      $$('[data-rc]', m).forEach((b) => b.addEventListener('click', async () => {
        const id = b.dataset.rc;
        $('[data-err]', m).innerHTML = '';
        try {
          const r = await MC.api.remoteControl(d.id, id, +$(`[data-rcp="${id}"]`, m).value);
          if (r.file) { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([r.file.text], { type: r.file.type })); a.download = r.file.name; document.body.appendChild(a); a.click(); a.remove(); }
          else if (r.method === 'ssh') { location.href = r.url; }
          else window.open(r.url, '_blank', 'noopener');
          $('#rcOut', m).innerHTML = `<div class="notice" style="margin-top:10px"><b>${esc(r.label)}</b> · ${esc(r.host)}:${r.port}${r.command ? `<div class="cmdline" style="margin-top:6px"><code class="mono">${esc(r.command)}</code><button type="button" class="btn sm ghost" data-copy="${esc(r.command)}">Copy</button></div>` : ''}${r.url && r.method !== 'ssh' ? `<div style="margin-top:6px"><a href="${esc(r.url)}" target="_blank" rel="noopener">${esc(r.url)}</a></div>` : ''}${r.method === 'ssh' ? '<p class="muted" style="margin:6px 0 0">Nothing opened? Your computer has no ssh:// handler: paste the command in a terminal.</p>' : ''}</div>`;
          $$('[data-copy]', m).forEach((c) => c.addEventListener('click', () => { try { navigator.clipboard.writeText(c.dataset.copy); MC.toast('Copied', 'ok'); } catch (e) { /* no clipboard */ } }));
        } catch (e) { errBox(m, e); }
      }));
    });
  }
  // ---- inventory of one device: every dataset the inventory collectors fill for it, the same as for engine-found devices
  const INV_LINK = { 'inventory.software': 'inventory/software', 'inventory.hardware': 'inventory/servers', 'inventory.workstations': 'inventory/workstations', 'inventory.printers': 'inventory/printers', 'updates.status': 'osupdates', 'security.patches': 'security/patches', 'security.defender': 'security/defender', 'security.localadmins': 'security/admins', 'linux.hosts': 'linux' };
  const shortName = (v) => String(v || '').split('.')[0].toUpperCase();
  const invRows = (d, x) => MC.data(x.dataset).filter((r) => [d.name, d.host].filter(Boolean).map(shortName).includes(shortName(r[x.key])));
  function invPanel(d) {
    const plan = root.MCSensors.inventoryPlan(d);
    if (!plan.length) return '';
    const items = plan.map((x) => ({ x, n: invRows(d, x).length }));
    const have = items.filter((i) => i.n).length;
    return MC.panel('Inventory', have ? have + ' of ' + plan.length + ' inventory areas collected for this device' : 'not collected yet: use Collect inventory', `<div class="inv-areas">${items.map(({ x, n }) => `<button class="inv-area${n ? '' : ' empty'}" data-invds="${esc(x.script)}" ${n ? '' : 'disabled'}><b>${esc(x.label)}</b><small>${n ? fmt(n, 0) + (n === 1 ? ' row' : ' rows') : 'no data yet'}</small></button>`).join('')}</div>`);
  }
  function invRowsDialog(d, script) {
    const x = root.MCSensors.inventoryPlan(d).find((i) => i.script === script); if (!x) return;
    const rows = invRows(d, x);
    const keys = [...new Set(rows.flatMap((r) => Object.keys(r)))].filter((k) => k !== x.key && rows.some((r) => r[k] != null && typeof r[k] !== 'object')).slice(0, 9);
    const link = INV_LINK[x.dataset];
    modal(`<h3>${esc(x.label)} · ${esc(d.name)}</h3><p class="muted">${rows.length} row(s) from the ${esc(x.script)} collector${link ? ` · <a href="#/${link}?q=${encodeURIComponent(d.name)}">open in ${esc(link.split('/').pop())}</a>` : ''}</p><div id="invRT"></div><div class="foot"><button class="btn" data-x>Close</button></div>`, (m) => {
      MC.table($('#invRT', m), rows, keys.map((k) => ({ key: k, label: k.replace(/([a-z])([A-Z])/g, '$1 $2'), val: (r) => (Array.isArray(r[k]) ? r[k].join(', ') : r[k]) , html: (r) => esc(Array.isArray(r[k]) ? r[k].join(', ') : r[k] == null ? '' : typeof r[k] === 'boolean' ? (r[k] ? 'Yes' : 'No') : String(r[k])) })), { name: 'inv-' + x.dataset + '-' + d.name, limit: 50 });
      const mm = m.querySelector('.modal-card, .card') || m.firstElementChild; if (mm) mm.style.maxWidth = '1100px';
    });
  }
  const modal = (html, onReady) => {
    const m = document.createElement('div');
    m.className = 'modal'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true');
    m.innerHTML = `<div class="card">${html}</div>`;
    document.body.appendChild(m);
    const close = () => m.remove();
    $$('[data-x]', m).forEach((b) => b.addEventListener('click', close));
    m.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    const f = $('input,textarea,select', m); if (f) f.focus();
    if (onReady) onReady(m, close);
    return m;
  };
  const errBox = (m, e) => { const b = $('[data-err]', m); if (b) b.innerHTML = `<div class="notice err" style="margin-top:10px">${esc(e.message)}</div>`; else MC.toast(esc(e.message), 'err'); };
  // groups: create, rename, move under another group, delete (used by Devices & sensors and Monitor > Groups)
  const groupOpts = (t, sel, skip) => {
    const kids = (id) => t.groups.filter((g) => g.parent === id).flatMap((g) => [g.id].concat(kids(g.id)));
    const no = skip ? new Set([skip].concat(kids(skip))) : new Set();
    return t.groups.filter((g) => !no.has(g.id)).sort((a, b) => a.name.localeCompare(b.name)).map((g) => `<option value="${esc(g.id)}" ${g.id === sel ? 'selected' : ''}>${esc(g.name)}</option>`).join('');
  };
  MC.groupDialog = function (t, g, done) {
    modal(`<h3>${g ? 'Edit group ' + esc(g.name) : 'New group'}</h3><p class="muted">Groups hold devices, like folders. Access for user groups, notification rules, scheduled jobs and reports can target a group; a group includes its subgroups.</p>
      <div class="field"><label for="gn">Name</label><input class="input" id="gn" maxlength="80" value="${esc(g ? g.name : '')}" placeholder="Branch North"></div>
      <div class="field"><label for="gp">Inside</label><select class="input" id="gp"><option value="probe">Top level</option>${groupOpts(t, g ? g.parent : 'probe', g && g.id)}</select></div>
      <div class="field"><label for="gdsc">Description <span class="muted">(optional)</span></label><input class="input" id="gdsc" maxlength="300" value="${esc((g && g.description) || '')}"></div>
      <div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">${g ? 'Save' : 'Create group'}</button></div>`, (m, close) => {
      $('#go', m).addEventListener('click', async () => {
        const body = { name: $('#gn', m).value, parent: $('#gp', m).value, description: $('#gdsc', m).value };
        try { const r = g ? await api('setGroup', Object.assign({ id: g.id }, body)) : await api('addGroup', body); close(); MC.toast(g ? 'Group saved' : 'Group created', 'ok'); await tree(true); done && done(r); } catch (e) { errBox(m, e); }
      });
    });
  };
  MC.deleteGroupDialog = function (t, g, done) {
    const held = t.devices.filter((d) => d.group === g.id).length;
    const subs = t.groups.filter((x) => x.parent === g.id).length;
    const def = g.parent && g.parent !== 'probe' ? g.parent : 'g:srv';
    modal(`<h3>Delete group ${esc(g.name)}?</h3><p class="muted">${held ? held + ' device(s) in it move to the group you choose; nothing is removed from monitoring.' : 'The group is empty.'}${subs ? ' Its ' + subs + ' subgroup(s) move up one level.' : ''}</p>
      ${held ? `<div class="field"><label for="gm">Move its devices to</label><select class="input" id="gm">${groupOpts(t, def, g.id)}</select></div>` : ''}
      <div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn danger" id="go">Delete group</button></div>`, (m, close) => {
      $('#go', m).addEventListener('click', async () => {
        try { const r = await api('deleteGroup', { id: g.id, moveTo: held ? $('#gm', m).value : undefined }); close(); MC.toast('Group deleted' + (r.moved ? ', ' + r.moved + ' devices moved' : ''), 'ok'); await tree(true); done && done(r); } catch (e) { errBox(m, e); }
      });
    });
  };

  const sparkAll = (el) => $$('[data-sp]', el).forEach((n) => { try { const v = JSON.parse(n.dataset.sp); if (v && v.length > 2) n.appendChild(C.sparkline(v, { width: 90, height: 22, color: COLOR[n.dataset.st] || '--s1' })); } catch (e) { /* no trend */ } });

  // ------------------------------------------------------------------ shared tree cache + global status bar
  const cache = { tree: null, at: 0, wait: null };
  async function tree(force) {
    if (!force && cache.tree && Date.now() - cache.at < 10000) return cache.tree;
    if (cache.wait) return cache.wait;
    cache.wait = api('tree').then((t) => { cache.tree = t; cache.at = Date.now(); cache.wait = null; statusBar(t); return t; }).catch((e) => { cache.wait = null; throw e; });
    return cache.wait;
  }
  MC.monTree = tree;
  function statusBar(t) {
    const c = (t || cache.tree || {}).probe ? (t || cache.tree).probe.counts : null;
    let bar = $('#monBar');
    const top = $('.topbar .spacer');
    if (!bar && top) { bar = document.createElement('div'); bar.id = 'monBar'; bar.className = 'mon-bar'; top.after(bar); }
    if (bar && c) {
      const al = (t || cache.tree).probe.alarms;
      const down = al ? al.Down : (c.Down || 0) - (c.Acknowledged || 0);
      const warn = al ? al.Warning : c.Warning || 0;
      const item = (cls, n, label, href) => `<a class="${n ? cls : cls + ' zero'}" href="${href}" title="${n} ${label}">${n}<span class="lbl">${label}</span></a>`;
      bar.innerHTML = item('Down', down, 'Down', '#/alarms?state=Down') + (c.Acknowledged ? item('Ack', c.Acknowledged, 'Ack', '#/alarms?state=Ack') : '') + item('Warning', warn, 'Warning', '#/alarms?state=Warning') + item('Up', c.Up || 0, 'Up', '#/sensors?state=Up') + item('Paused', c.Paused || 0, 'Paused', '#/sensors?state=Paused') + item('Unknown', c.Unknown || 0, 'Unknown', '#/sensors?state=Unknown');
    }
    const a = $('.nav a[data-r="alarms"]');
    if (a && c) { const old = $('.cnt', a); if (old) old.remove(); const al = (t || cache.tree).probe.alarms || {}, down = al.Down != null ? al.Down : c.Down || 0, w = al.Warning != null ? al.Warning : c.Warning || 0; if (down || w) a.insertAdjacentHTML('beforeend', down ? `<span class="cnt">${down}</span>` : `<span class="cnt w">${w}</span>`); }
  }
  // keep the status bar fresh on every page
  setInterval(() => { if ($('.topbar') && document.visibilityState !== 'hidden') tree(true).catch(() => null); }, 30000);
  root.addEventListener('hashchange', () => setTimeout(() => { if ($('.topbar') && !$('#monBar')) tree().catch(() => null); else statusBar(); }, 50));
  const boot = setInterval(() => { if ($('.topbar')) { clearInterval(boot); tree().catch(() => null); } }, 400);

  // live refresh while a monitoring page is open (skipped while a dialog is open)
  function every(el, ms, fn) {
    clearInterval(V._monTimer);
    // #view is reused by every page, so tie the timer to this render: once the user navigates away it stops
    const seq = MC.renderSeq;
    V._monTimer = setInterval(() => { if (!document.body.contains(el) || MC.renderSeq !== seq) return clearInterval(V._monTimer); if ($('.modal') || $('.drawer')) return; fn(); }, ms);
  }

  // ================================================================== DEVICES & SENSORS (tree)
  V.sensors = {
    title: 'Devices & sensors',
    crumb: () => 'probe › groups › devices › sensors · like PRTG',
    render(el, route) {
      const q = route.q || {};
      const ui = { state: q.state || '', view: q.view || 'tree', text: q.q || '', open: new Set(), select: false, pd: new Set(), ps: new Set() };
      el.innerHTML = '<div class="notice">Loading the device tree…</div>';
      const draw = (t) => {
        const c = t.probe.counts;
        const match = (s) => (!ui.state || (ui.state === 'Ack' ? s.ack && s.state === 'Down' : ui.state === 'alarms' ? s.state === 'Down' || s.state === 'Warning' : s.state === ui.state));
        const text = ui.text.toLowerCase();
        const byDev = new Map();
        for (const s of t.sensors) { if (!byDev.has(s.device)) byDev.set(s.device, []); byDev.get(s.device).push(s); }
        const devOk = (d) => (!text || (d.name + ' ' + (d.host || '') + ' ' + (d.os || '')).toLowerCase().includes(text) || (byDev.get(d.id) || []).some((s) => s.name.toLowerCase().includes(text))) && (!ui.state || (byDev.get(d.id) || []).some(match));
        const devs = t.devices.filter(devOk);
        const groups = t.groups.filter((g) => devs.some((d) => MC.inGroup(d, g.id))).sort((a, b) => (b.counts.Down || 0) - (a.counts.Down || 0) || a.order - b.order);
        const chip = (s) => ui.select && canOn(s) ? `<label class="schip pick ${look(s)} ${ui.ps.has(s.id) || ui.pd.has(s.device) ? 'on' : ''}" title="${esc(s.name + ': ' + s.state)}"><input type="checkbox" data-ps="${esc(s.id)}" ${ui.ps.has(s.id) || ui.pd.has(s.device) ? 'checked' : ''} ${ui.pd.has(s.device) ? 'disabled' : ''} aria-label="${esc('Select sensor ' + s.name)}"><span>${esc(s.name)}</span></label>` : `<a class="schip ${look(s)}" href="${sensorLink(s)}" title="${esc(s.name + ': ' + s.state + ' · ' + (s.message || ''))}"><span>${esc(s.name)}</span>${s.value ? `<em>${esc(s.value)}</em>` : ''}</a>`;
        const devRow = (d) => {
          const list = (byDev.get(d.id) || []).filter(match).sort((a, b) => STATES.indexOf(a.state) - STATES.indexOf(b.state));
          const box = ui.select && canOn(d) ? `<input type="checkbox" class="pickbox" data-pd="${esc(d.id)}" ${ui.pd.has(d.id) ? 'checked' : ''} aria-label="${esc('Select device ' + d.name + ' with all its sensors')}">` : '';
          return `<div class="mdev ${ui.pd.has(d.id) ? 'picked' : ''}">${box}<div class="dn" data-href="${deviceLink(d.id)}" role="link" tabindex="0"><span class="sdot ${d.paused ? 'Paused' : d.state}"></span><div style="min-width:0"><b>${esc(d.name)}</b><small>${esc([d.host, d.os || d.kind].filter(Boolean).join(' · '))}</small></div></div><div class="schips">${list.map(chip).join('') || '<span class="muted" style="font-size:12px">No sensors in this filter</span>'}</div></div>`;
        };
        const filters = [['', 'All', t.sensors.length], ['alarms', 'Alarms', (c.Down || 0) + (c.Warning || 0)], ['Down', 'Down', c.Down || 0], ['Ack', 'Acknowledged', c.Acknowledged || 0], ['Warning', 'Warning', c.Warning || 0], ['Up', 'Up', c.Up || 0], ['Paused', 'Paused', c.Paused || 0], ['Unknown', 'Unknown', c.Unknown || 0]];
        el.innerHTML = `
          <div class="kpis">${MC.kpi('Probe', esc(t.probe.state), esc(t.probe.name))}${MC.kpi('Devices', t.devices.length, t.groups.filter((g) => g.devices).length + ' groups')}${MC.kpi('Sensors', t.sensors.length, t.sensors.filter((s) => s.source === 'native').length + ' probe · ' + t.sensors.filter((s) => s.source === 'collector').length + ' engine')}${MC.kpi('Down', c.Down || 0, (c.Acknowledged || 0) + ' acknowledged', { alert: (c.Down || 0) > (c.Acknowledged || 0), href: '#/alarms' })}${MC.kpi('Warning', c.Warning || 0, 'over a warning limit', { href: '#/alarms?state=Warning' })}${MC.kpi('Paused', c.Paused || 0, (c.Unknown || 0) + ' unknown')}</div>
          ${MC.panel('Sensor states', `${t.sensors.length} sensors · updated ${ago(t.generated)}`, `${stack(c, { legend: false })}<div class="mc-legend" style="margin-top:8px">${['Down', 'Ack', 'Warning', 'Up', 'Paused', 'Unknown'].map((k) => `<span><i style="background:var(${COLOR[k]})"></i>${k === 'Ack' ? 'Down (ack)' : k}<b>${k === 'Ack' ? c.Acknowledged || 0 : k === 'Down' ? (c.Down || 0) - (c.Acknowledged || 0) : c[k] || 0}</b></span>`).join('')}</div>`)}
          <section class="card panel-c">
            <div class="toolbar" style="gap:8px;flex-wrap:wrap;margin-bottom:10px">
              <div class="mfilter" role="group" aria-label="Filter by state">${filters.map(([k, l, n]) => `<button class="btn sm ${ui.state === k ? 'on' : ''}" data-st="${k}">${k && COLOR[k] ? `<span class="sdot ${k}" style="margin:0"></span>` : ''}${l} <span class="muted">${n}</span></button>`).join('')}</div>
              <input class="input" type="search" id="mq" placeholder="Find a device or sensor" value="${esc(ui.text)}" style="max-width:240px" aria-label="Find a device or sensor">
              <span style="flex:1"></span>
              <div class="mfilter"><button class="btn sm ${ui.view === 'tree' ? 'on' : ''}" data-view="tree">Tree</button><button class="btn sm ${ui.view === 'tiles' ? 'on' : ''}" data-view="tiles">Tiles</button></div>
              ${t.groups.some(canOn) ? `<button class="btn sm primary" id="addDev">${icon('play', 'sev-ico')}Add device</button><button class="btn sm" id="impDev">${icon('download', 'sev-ico')}Import devices</button>${admin() ? '<button class="btn sm" id="addGrp">New group</button>' : ''}<button class="btn sm ${ui.select ? 'on' : ''}" id="selMode" aria-pressed="${ui.select}">${ui.select ? 'Done selecting' : 'Select to remove'}</button>` : ''}
              ${admin() && (t.removed || []).length ? `<button class="btn sm ghost" id="removedBtn">Removed devices <span class="muted">${t.removed.length}</span></button>` : ''}
              <button class="btn sm" data-href="#/discovery">Auto-discovery</button>
            </div>
            ${ui.select ? `<div class="selbar" role="region" aria-label="Selection"><b id="selN"></b><span class="muted">Tick a device to remove it with all its sensors, or tick single sensors.</span><span style="flex:1"></span><button class="btn sm" id="selAll">Select all shown</button><button class="btn sm" id="selNone">Clear</button><button class="btn sm danger" id="selGo">Remove…</button></div>` : ''}
            <div id="mbody"></div>
          </section>`;
        const body = $('#mbody', el);
        if (!devs.length) body.innerHTML = '<div class="empty">No devices match this filter.</div>';
        else if (ui.view === 'tiles' && !ui.select) {
          body.innerHTML = groups.map((g) => `<h4 style="margin:14px 0 6px;font-size:13px">${esc(g.name)} <span class="muted" style="font-weight:400">${devs.filter((d) => MC.inGroup(d, g.id)).length}</span></h4><div class="mtiles">${devs.filter((d) => MC.inGroup(d, g.id)).sort((a, b) => STATES.indexOf(a.state) - STATES.indexOf(b.state)).map((d) => `<div class="mtile ${d.paused ? 'Paused' : d.state}" data-href="${deviceLink(d.id)}" role="link" tabindex="0" title="${esc(d.name)}"><b>${esc(d.name)}</b><small>${d.counts.Down ? d.counts.Down + ' down · ' : ''}${d.counts.Warning ? d.counts.Warning + ' warn · ' : ''}${d.sensors} sensors</small></div>`).join('')}</div>`).join('');
        } else {
          body.innerHTML = `<div class="mtree">${groups.map((g) => {
            const gd = devs.filter((d) => MC.inGroup(d, g.id)).sort((a, b) => STATES.indexOf(a.state) - STATES.indexOf(b.state) || a.name.localeCompare(b.name));
            const open = ui.state || ui.text || ui.open.has(g.id) || g.counts.Down || groups.length <= 3;
            return `<details class="mgroup" data-g="${esc(g.id)}" ${open ? 'open' : ''}><summary><svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m9 6 6 6-6 6"/></svg><span class="sdot ${g.state}" style="margin:0"></span><b>${esc(g.name)}</b><span class="muted" style="font-size:12px">${gd.length} devices · ${(g.counts.Down || 0)} down · ${(g.counts.Warning || 0)} warning</span>${stack(g.counts, { thin: true })}${admin() ? `<button class="btn sm ghost" data-edg="${esc(g.id)}" title="Rename or move this group">Edit</button>${!g.auto && !g.builtIn ? `<button class="btn sm ghost" data-delg="${esc(g.id)}" title="Delete this group">Delete</button>` : ''}` : ''}</summary>${gd.map(devRow).join('')}</details>`;
          }).join('')}</div>`;
          $$('details.mgroup', body).forEach((d) => d.addEventListener('toggle', () => { if (d.open) ui.open.add(d.dataset.g); else ui.open.delete(d.dataset.g); }));
          $$('[data-delg]', body).forEach((b) => b.addEventListener('click', (e) => { e.preventDefault(); MC.deleteGroupDialog(t, t.groups.find((g) => g.id === b.dataset.delg), async () => draw(await tree(true))); }));
          $$('[data-edg]', body).forEach((b) => b.addEventListener('click', (e) => { e.preventDefault(); MC.groupDialog(t, t.groups.find((g) => g.id === b.dataset.edg), async () => draw(await tree(true))); }));
          $$('[data-pd]', body).forEach((b) => b.addEventListener('change', () => {
            if (b.checked) ui.pd.add(b.dataset.pd); else ui.pd.delete(b.dataset.pd);
            const row = b.closest('.mdev'); row.classList.toggle('picked', b.checked);
            $$('[data-ps]', row).forEach((x) => { x.disabled = b.checked; x.checked = b.checked || ui.ps.has(x.dataset.ps); x.closest('.schip').classList.toggle('on', x.checked); });
            selCount();
          }));
          $$('[data-ps]', body).forEach((b) => b.addEventListener('change', () => { if (b.checked) ui.ps.add(b.dataset.ps); else ui.ps.delete(b.dataset.ps); selCount(); b.closest('.schip').classList.toggle('on', b.checked); }));
        }
        $$('[data-st]', el).forEach((b) => b.addEventListener('click', () => { ui.state = b.dataset.st; draw(t); }));
        $$('[data-view]', el).forEach((b) => b.addEventListener('click', () => { ui.view = b.dataset.view; draw(t); }));
        const mq = $('#mq', el);
        mq.addEventListener('input', () => { ui.text = mq.value; const pos = mq.selectionStart; draw(t); const n = $('#mq', el); n.focus(); n.setSelectionRange(pos, pos); });
        if ($('#addDev', el)) $('#addDev', el).addEventListener('click', () => addDeviceDialog(t, async () => draw(await tree(true))));
        if ($('#impDev', el)) $('#impDev', el).addEventListener('click', () => importDialog(async () => draw(await tree(true))));
        if ($('#addGrp', el)) $('#addGrp', el).addEventListener('click', () => MC.groupDialog(t, null, async () => draw(await tree(true))));
        if ($('#removedBtn', el)) $('#removedBtn', el).addEventListener('click', () => removedDialog(t, async () => draw(await tree(true))));
        if ($('#selMode', el)) $('#selMode', el).addEventListener('click', () => { ui.select = !ui.select; ui.pd.clear(); ui.ps.clear(); draw(t); });
        // selection: devices (with all their sensors) and single sensors
        const sensorsPicked = () => [...ui.ps].filter((id) => { const s = t.sensors.find((x) => x.id === id); return s && !ui.pd.has(s.device); });
        function selCount() {
          const n = $('#selN', el); if (!n) return;
          const sp = sensorsPicked().length;
          n.textContent = ui.pd.size || sp ? [ui.pd.size ? ui.pd.size + ' device' + (ui.pd.size > 1 ? 's' : '') : '', sp ? sp + ' sensor' + (sp > 1 ? 's' : '') : ''].filter(Boolean).join(' and ') + ' selected' : 'Nothing selected';
          $('#selGo', el).disabled = !ui.pd.size && !sp;
        }
        if (ui.select) {
          selCount();
          $('#selAll', el).addEventListener('click', () => { for (const d of devs) if (canOn(d)) ui.pd.add(d.id); draw(t); });
          $('#selNone', el).addEventListener('click', () => { ui.pd.clear(); ui.ps.clear(); draw(t); });
          $('#selGo', el).addEventListener('click', () => removeDialog(t, [...ui.pd], sensorsPicked(), async () => { ui.pd.clear(); ui.ps.clear(); ui.select = false; draw(await tree(true)); }));
        }
      };
      tree(true).then(draw).catch((e) => { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
      every(el, 15000, async () => { const n = $('#mq', el); if ((n && document.activeElement === n) || ui.select) return; draw(await tree(true)); });
    },
  };

  // remove devices (with all their sensors) and single sensors. Devices found by an engine stay out of monitoring
  // until an administrator brings them back (Removed devices); devices you added are deleted.
  function removeDialog(t, devIds, sensorIds, done) {
    const devs = devIds.map((id) => t.devices.find((d) => d.id === id)).filter(Boolean);
    const sens = sensorIds.map((id) => t.sensors.find((s) => s.id === id)).filter(Boolean);
    const nSens = devs.reduce((a, d) => a + (d.sensors || 0), 0) + sens.length;
    const found = devs.filter((d) => !d.manual).length;
    const list = devs.slice(0, 12).map((d) => `<li><b>${esc(d.name)}</b> <span class="muted">${d.sensors} sensors${d.manual ? '' : ' · found by an engine'}</span></li>`).concat(sens.slice(0, 12).map((s) => `<li>${esc((t.devices.find((d) => d.id === s.device) || {}).name || '')} › ${esc(s.name)}</li>`));
    const more = devs.length + sens.length - list.length;
    modal(`<h3>Remove ${devs.length ? devs.length + ' device' + (devs.length > 1 ? 's' : '') : ''}${devs.length && sens.length ? ' and ' : ''}${sens.length ? sens.length + ' sensor' + (sens.length > 1 ? 's' : '') : ''}?</h3>
      <ul class="rm-list">${list.join('')}${more > 0 ? `<li class="muted">and ${more} more</li>` : ''}</ul>
      <p class="muted">${nSens} sensors stop monitoring and alerting, and their history, limits and settings are deleted.${found ? ' ' + found + ' device(s) were found by a monitoring engine: they stay out of monitoring even when the engine reports them again, until an administrator brings them back under Removed devices.' : ''} Sensors found by an engine come back only if you add them again.</p>
      <div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn danger" id="go">Remove</button></div>`, (m, close) => {
      $('#go', m).addEventListener('click', async () => {
        try { const r = await api('removeItems', { devices: devIds, sensors: sensorIds }); close(); MC.toast('Removed ' + [r.devices.length ? r.devices.length + ' devices' : '', r.sensors ? r.sensors + ' sensors' : ''].filter(Boolean).join(' and '), 'ok'); await tree(true); done && done(r); } catch (e) { errBox(m, e); }
      });
    });
  }
  function removedDialog(t, done) {
    const rows = t.removed || [];
    modal(`<h3>Removed devices</h3><p class="muted">Devices found by monitoring engines that were removed from monitoring. Bring one back to monitor it again with the engine's sensors.</p>
      <div class="tbl-wrap"><table class="tbl"><thead><tr><th>Device</th><th>Removed</th><th>By</th><th>Engine still reports it</th><th></th></tr></thead><tbody>${rows.map((r) => `<tr><td><b>${esc(r.name)}</b> <span class="muted">${esc(r.kind || '')}</span></td><td>${ago(r.at)}</td><td>${esc(r.by || '')}</td><td>${r.reported ? 'Yes' : 'No'}</td><td><button class="btn sm" data-rs="${esc(r.id)}">Bring back</button></td></tr>`).join('')}</tbody></table></div>
      <div data-err></div><div class="foot"><button class="btn" data-x>Close</button></div>`, (m, close) => {
      $$('[data-rs]', m).forEach((b) => b.addEventListener('click', async () => { try { await api('restoreDevice', { id: b.dataset.rs }); b.closest('tr').remove(); MC.toast('Brought back', 'ok'); if (!$('[data-rs]', m)) close(); done && done(); } catch (e) { errBox(m, e); } }));
    });
  }

  // ------------------------------------------------------------------ add device: type, access credentials, monitoring options
  // Credentials: per supported method, inherit (device group or probe default), pick a saved one, or enter a new one,
  // either saved to the console for other devices or kept private to this device. Options: what to monitor, by area.
  const KINDS = S.CLASSES.map(([k, l]) => [k, l]);
  const KIND_GROUP = S.KIND_GROUP;
  const chainOf = (t, gid) => { const out = [gid]; let g = t.groups.find((x) => x.id === gid); while (g && g.parent && g.parent !== 'probe' && out.length < 10) { out.push(g.parent); g = t.groups.find((x) => x.id === g.parent); } return out; };
  function credFieldsHtml(kind, pre) {
    return CM.KIND[kind].fields.map((f) => {
      const id = pre + f.name, lbl = `<label for="${id}">${esc(f.label)}${f.required ? ' *' : ''}</label>`;
      if (f.values) return `<div class="field">${lbl}<select class="input" id="${id}" data-f="${f.name}">${f.values.map((v) => `<option ${v === f.def ? 'selected' : ''}>${esc(v)}</option>`).join('')}</select></div>`;
      if (f.multiline) return `<div class="field">${lbl}<textarea class="input mono" id="${id}" data-f="${f.name}" rows="3" autocomplete="off" spellcheck="false"></textarea></div>`;
      return `<div class="field">${lbl}<input class="input${f.type === 'int' ? '' : ''}" id="${id}" data-f="${f.name}" ${f.secret ? 'type="password" autocomplete="new-password"' : f.type === 'int' ? `type="number" value="${f.def != null ? f.def : ''}"` : 'autocomplete="off"'}></div>`;
    }).join('');
  }
  const readFields = (box) => Object.fromEntries($$('[data-f]', box).map((i) => [i.dataset.f, i.value]).filter(([, v]) => v !== ''));
  // access level: asked for every device added by hand (sensors.js ACCESS_LEVELS)
  const accessField = (cur) => `<fieldset class="field acc-levels"><legend>Access level <span class="muted">(required)</span></legend>${S.ACCESS_LEVELS.map((a) => `<label class="check acc-level"><input type="radio" name="acc" value="${a.id}" ${cur === a.id ? 'checked' : ''}> <span><b>${esc(a.label)}</b><small>${esc(a.desc)}</small></span></label>`).join('')}</fieldset>`;
  const readAccess = (m) => { const r = $('input[name=acc]:checked', m); if (!r) throw new Error('Choose the access level for this device (step 2 · Access).'); return r.value; };
  function credSection(t, kind, gid, saved, current) {
    const kinds = CM.kindsFor(kind);
    const dev = { id: '', group: gid, credentials: {} };
    return `<p class="muted" style="margin-top:0">MonCastle signs in to the device with these accounts. A device uses its own credential, else the one set on its group, else the probe default (like PRTG). Secrets are stored encrypted on the console and are never shown again.</p>` + kinds.map((k) => {
      const K = CM.KIND[k], inh = CM.resolve(saved, dev, chainOf(t, gid), k);
      const mine = saved.filter((c) => c.kind === k);
      const cur = (current || {})[k] || '';
      return `<fieldset class="credk" data-kind="${k}"><legend>${icon(K.icon, 'sev-ico')} ${esc(K.name)}</legend>
        <select class="input" data-pick="${k}" aria-label="${esc(K.name)} credential">
          <option value="">${inh ? 'Inherit: ' + esc(inh.cred.name) + ' (' + esc(inh.from === 'probe default' ? 'probe default' : 'from ' + ((t.groups.find((g) => 'group ' + g.id === inh.from) || {}).name || inh.from.replace(/^group /, '')) + ' group') + ')' : 'Inherit: none set, the engine account is used'}</option>
          ${mine.map((c) => `<option value="${esc(c.id)}" ${cur === c.id ? 'selected' : ''}>Saved: ${esc(c.name)}${c.private ? ' (private)' : ''}</option>`).join('')}
          <option value="new">Enter a new credential…</option>
          ${k === 'windows' || k === 'ssh' ? '' : '<option value="none">Do not use this method</option>'}
        </select>
        <div class="newcred" data-new="${k}" hidden>
          <div class="field"><label for="cn-${k}">Name</label><input class="input" id="cn-${k}" placeholder="${esc(K.name)} for this device"></div>
          ${credFieldsHtml(k, 'cf-' + k + '-')}
          <label class="check"><input type="checkbox" data-share="${k}" checked> Save to the console so other devices can use it (otherwise it stays private to this device)</label>
        </div></fieldset>`;
    }).join('');
  }
  function wireCreds(m) {
    $$('[data-pick]', m).forEach((s) => s.addEventListener('change', () => { $(`[data-new="${s.dataset.pick}"]`, m).hidden = s.value !== 'new'; }));
  }
  // saves any new credentials, returns { kind: credentialId } for the device
  async function collectCreds(m, devName) {
    const out = {};
    for (const s of $$('[data-pick]', m)) {
      const k = s.dataset.pick;
      if (s.value === 'new') {
        const box = $(`[data-new="${k}"]`, m);
        const c = await MC.api.saveCredential({ kind: k, name: $('#cn-' + k, m).value.trim() || CM.KIND[k].name + ' · ' + devName, fields: readFields(box), private: !$(`[data-share="${k}"]`, box).checked, assign: { all: false, groups: [], devices: [] } });
        out[k] = c.id; s.insertAdjacentHTML('beforeend', `<option value="${esc(c.id)}">Saved: ${esc(c.name)}</option>`); s.value = c.id; box.hidden = true;
      } else if (s.value && s.value !== 'none') out[k] = s.value;
    }
    return out;
  }
  function optionsSection(kind, ports, chosen, profile, extra) {
    const opts = S.optionsFor(kind);
    const areas = [...new Set(opts.map((o) => o.area))];
    const prof = S.PROFILE[profile] || null;
    const on = (o) => (o.profile && !(prof && prof.sensors.length + (prof.ports || []).length) ? false : chosen ? chosen.includes(o.id) : S.optionDefault(o, kind, ports));
    const label = (o) => (o.profile ? (prof ? 'Vendor health for ' + prof.name + (prof.sensors.length ? ': ' + prof.sensors.map((x) => x.name).join(', ') : ': no SNMP health OIDs, monitored over HTTPS and ping') : 'Vendor health sensors: choose the model on the first step') : o.name);
    extra = extra || {};
    return `<div class="toolbar" style="margin:0 0 8px"><span class="muted" style="font-size:12.5px">Pick what to monitor. Probe checks start right away; engine options add the device to that engine's targets.</span><span class="spacer"></span><button type="button" class="btn sm ghost" data-allopt="1">Select all</button><button type="button" class="btn sm ghost" data-allopt="0">Clear</button></div>
      <div class="optgrid">${areas.map((a) => `<fieldset><legend>${esc(a)}</legend>${opts.filter((o) => o.area === a).map((o) => `<label class="check"><input type="checkbox" data-opt="${o.id}" ${on(o) ? 'checked' : ''}> <span>${esc(label(o))} <span class="tag ${o.script ? 'collector' : 'native'}">${o.script ? 'engine' : 'probe'}</span></span></label>${o.interfaces ? `<input class="input mono" data-ifs placeholder="Interface numbers, e.g. 1, 2, 10" value="${esc((extra.interfaces || [1]).join(', '))}" style="margin:2px 0 6px 26px;width:calc(100% - 26px)">` : ''}${o.volumes ? `<input class="input mono" data-vols placeholder="hrStorage index numbers, e.g. 31, 32" value="${esc((extra.volumes || [1]).join(', '))}" style="margin:2px 0 6px 26px;width:calc(100% - 26px)">` : ''}`).join('')}</fieldset>`).join('')}</div>`;
  }
  function wireOptions(m) { $$('[data-allopt]', m).forEach((b) => b.addEventListener('click', () => $$('[data-opt]', m).forEach((c) => (c.checked = b.dataset.allopt === '1')))); }
  const nums = (el) => ((el || {}).value || '').split(/[\s,;]+/).map(Number).filter((n) => n > 0);
  const readOptions = (m) => ({ monitor: $$('[data-opt]', m).filter((c) => c.checked).map((c) => c.dataset.opt), interfaces: nums($('[data-ifs]', m)), volumes: nums($('[data-vols]', m)) });
  const modelLabel = (kind) => (kind === 'database' ? 'Engine' : kind === 'cloudstorage' ? 'Provider' : 'Model');
  const modelOptions = (kind, cur) => { const list = S.profilesFor(kind); return list.length ? `<option value="">Not listed / generic</option>` + [...new Set(list.map((p) => p.vendor))].map((v) => `<optgroup label="${esc(v)}">${list.filter((p) => p.vendor === v).map((p) => `<option value="${esc(p.id)}" ${cur === p.id ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}</optgroup>`).join('') : ''; };

  // MonCastle infrastructure: which server monitors the device, with each server's current load to choose by
  const pctTxt = (v) => (v == null ? '–' : Math.round(v) + '%');
  const serverField = (t, id, cur) => {
    const list = (t.servers || []).filter((x) => x.state !== 'Unknown' || x.id === cur);
    if (list.length < 2) return '';
    const pick = cur || ((list.find((x) => x.role === 'central') || list[0]).id);
    return `<div class="field"><label for="${id}">Monitored by</label><select class="input" id="${id}">${list.map((x) => `<option value="${esc(x.id)}" ${x.id === pick ? 'selected' : ''}>${esc(x.name)}${x.site ? ' · ' + esc(x.site) : ''} · CPU ${pctTxt(x.cpu)} · memory ${pctTxt(x.mem)} · ${x.devices || 0} devices</option>`).join('')}</select><div class="srvload" data-srvload="${id}"></div><span class="hint">The MonCastle server that runs this device's probe sensors and engines. Pick the one at the device's site, or the least busy one. <a href="#/servers">MonCastle servers</a></span></div>`;
  };
  const wireServerField = (m, t, id) => {
    const sel = $('#' + id, m), box = $(`[data-srvload="${id}"]`, m);
    if (!sel || !box) return;
    const draw = () => { const x = (t.servers || []).find((y) => y.id === sel.value); if (!x) return (box.innerHTML = ''); const bar = (l, v) => `<span class="srvbar"><span>${l}</span><span class="track"><span class="fill ${v >= 90 ? 'crit' : v >= 75 ? 'warn' : ''}" style="width:${Math.max(2, Math.min(100, v || 0))}%"></span></span><b>${pctTxt(v)}</b></span>`; box.innerHTML = bar('CPU', x.cpu) + bar('Memory', x.mem) + `<span class="muted">${x.devices || 0} devices · ${x.sensors || 0} probe sensors · ${esc(x.state)}</span>`; };
    sel.addEventListener('change', draw); draw();
  };

  // ------------------------------------------------------------------ bulk import: Name, Type, IP (+ Group, Model, Server)
  // CSV or pasted text; the separator (comma, semicolon or tab) is detected from the header line.
  function parseTable(text) {
    text = String(text || '').replace(/^\uFEFF/, '');
    const first = text.split(/\r?\n/).find((l) => l.trim()) || '';
    const sep = [',', ';', '\t'].map((c) => [c, first.split(c).length]).sort((a, b) => b[1] - a[1])[0][0];
    const rows = []; let row = [], cell = '', q = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (q) { if (ch === '"' && text[i + 1] === '"') { cell += '"'; i++; } else if (ch === '"') q = false; else cell += ch; continue; }
      if (ch === '"') q = true;
      else if (ch === sep) { row.push(cell); cell = ''; }
      else if (ch === '\n' || ch === '\r') { if (ch === '\r' && text[i + 1] === '\n') i++; row.push(cell); cell = ''; if (row.some((c) => c.trim())) rows.push(row); row = []; }
      else cell += ch;
    }
    row.push(cell); if (row.some((c) => c.trim())) rows.push(row);
    if (!rows.length) return [];
    const head = rows[0].map((h) => h.trim().toLowerCase().replace(/[^a-z]/g, ''));
    const col = (names) => head.findIndex((h) => names.includes(h));
    const ix = { name: col(['name', 'devicename', 'hostname']), type: col(['type', 'devicetype', 'kind']), host: col(['ip', 'ipaddress', 'address', 'dnsname', 'dns', 'host', 'ipordnsname', 'fqdn']), group: col(['group', 'devicegroup']), model: col(['model', 'vendor', 'profile']), server: col(['server', 'moncastleserver']), access: col(['access', 'accesslevel']) };
    if (ix.name < 0 || ix.type < 0 || ix.host < 0) throw new Error('The first line must be the header Name, Type, IP (Group, Model and Server are optional).');
    return rows.slice(1).map((r) => Object.fromEntries(Object.entries(ix).filter(([, i]) => i >= 0).map(([k, i]) => [k, (r[i] || '').trim()])));
  }
  const TEMPLATE = 'Name,Type,IP,Group,Model\r\nDC01,Windows server,10.10.0.10,,\r\nCORE-SW01,Switch or router,core-sw01.corp.local,,cisco-ios\r\nWEB01,Linux server,10.10.4.21,Web servers,\r\nNAS01,NAS storage,nas01.corp.local,,\r\nPRN-HQ-01,Printer,10.10.9.30,,\r\n';
  function importDialog(done) {
    const types = S.CLASSES.map(([k, label]) => `<tr><td>${esc(label)}</td><td class="mono">${esc(k)}</td></tr>`).join('');
    modal(`<h3>Import devices</h3>
      <p class="muted" style="margin:0 0 10px">Fill the template, one device per line: <b>Name</b>, <b>Type</b> and <b>IP</b> (an IP address or a DNS name). <b>Group</b>, <b>Model</b> and <b>Access</b> (monitor, read or admin; read when empty) are optional; without a group the device goes to the usual group for its type. Save Excel sheets as CSV, or paste the cells straight in.</p>
      <div class="toolbar" style="margin:0 0 8px"><button class="btn sm" id="imTpl" type="button">${icon('download', 'sev-ico')}Download template</button><label class="btn sm" style="cursor:pointer">Open CSV file<input type="file" id="imFile" accept=".csv,.txt,text/csv" hidden></label><button class="btn sm ghost" id="imTypes" type="button">Device types</button></div>
      <div id="imTypeList" hidden style="max-height:180px;overflow:auto;margin-bottom:8px"><table class="tbl"><thead><tr><th>Type (name)</th><th>or id</th></tr></thead><tbody>${types}</tbody></table><p class="muted" style="font-size:12px;margin:6px 0 0">Model names from the Add device dialog also work as the type, and so do common words such as switch, router, firewall, NAS, UPS, ESXi or PostgreSQL.</p></div>
      <textarea class="input mono" id="imText" rows="8" spellcheck="false" placeholder="Name,Type,IP&#10;DC01,Windows server,10.10.0.10&#10;CORE-SW01,Switch or router,core-sw01.corp.local"></textarea>
      <div id="imOut" style="margin-top:10px"></div><div data-err></div>
      <div class="actions-row" style="margin-top:12px"><button class="btn" type="button" id="imCheck">Check</button><button class="btn primary" type="button" id="imGo" disabled>Import</button><button class="btn ghost" type="button" data-x>Close</button></div>`, (m, close) => {
      let rows = null;
      $('#imTpl', m).addEventListener('click', () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\uFEFF' + TEMPLATE], { type: 'text/csv' })); a.download = 'moncastle-devices-template.csv'; document.body.appendChild(a); a.click(); a.remove(); if (!$('#imText', m).value.trim()) $('#imText', m).value = TEMPLATE.replace(/\r/g, ''); });
      $('#imTypes', m).addEventListener('click', () => { $('#imTypeList', m).hidden = !$('#imTypeList', m).hidden; });
      $('#imFile', m).addEventListener('change', async (e) => { const f = e.target.files[0]; if (!f) return; if (f.size > 900000) return errBox(m, new Error('That file is too large (900 KB at most).')); $('#imText', m).value = await f.text(); check(); });
      $('#imText', m).addEventListener('input', () => { $('#imGo', m).disabled = true; });
      const show = (r, final) => {
        const lab = { ready: 'Ready', added: 'Added', skip: 'Skipped', error: 'Error' }, cls = { ready: 'Up', added: 'Up', skip: 'Paused', error: 'Down' };
        $('#imOut', m).innerHTML = `<p style="margin:0 0 6px"><b>${final ? r.added + ' added' : r.ready + ' ready'}</b> · ${r.skipped} skipped · ${r.errors} with errors</p>
          <div style="max-height:260px;overflow:auto"><table class="tbl"><thead><tr><th>#</th><th>Name</th><th>IP or DNS name</th><th>Type</th><th>Result</th></tr></thead><tbody>${r.rows.map((x) => `<tr><td>${x.row}</td><td>${esc(x.name)}</td><td class="mono">${esc(x.host)}</td><td>${esc(x.kind ? (S.CLASSES.find((c) => c[0] === x.kind) || [, x.kind])[1] : x.type)}</td><td>${pill(cls[x.result], lab[x.result])} <span class="muted" style="font-size:12px">${esc(x.error || x.skip || '')}</span></td></tr>`).join('')}</tbody></table></div>`;
      };
      const check = async () => {
        $('[data-err]', m).innerHTML = '';
        try {
          rows = parseTable($('#imText', m).value);
          if (!rows.length) throw new Error('Add at least one device line under the header.');
          if (rows.length > 2000) throw new Error('Import at most 2000 devices at a time.');
          const r = await api('importDevices', { rows, dryRun: true });
          show(r, false);
          $('#imGo', m).disabled = !r.ready;
        } catch (e) { $('#imGo', m).disabled = true; errBox(m, e); }
      };
      $('#imCheck', m).addEventListener('click', check);
      $('#imGo', m).addEventListener('click', async () => {
        $('#imGo', m).disabled = true;
        try { const r = await api('importDevices', { rows, dryRun: false }); show(r, true); MC.toast(r.added + ' devices imported', 'ok'); done(); } catch (e) { errBox(m, e); }
      });
    });
  }

  async function addDeviceDialog(t, done, preset = {}) {
    const groups = t.groups.filter((g) => canOn(g)).sort((a, b) => a.name.localeCompare(b.name));
    if (!groups.length) return MC.toast('Your role cannot add devices to any group.', 'err');
    let saved = [];
    try { saved = await MC.api.credentials(); } catch (e) { saved = []; }
    const kind0 = preset.kind || 'server';
    modal(`<h3>Add a device</h3>
      <div class="steps" role="tablist"><button class="on" data-step="1">1 · Device</button><button data-step="2">2 · Access</button><button data-step="3">3 · Monitoring</button></div>
      <div data-pane="1">
        <div class="field"><label for="dn">Name</label><input class="input" id="dn" value="${esc(preset.name || '')}" placeholder="SW-CORE-02"></div>
        <div class="field"><label for="dh">DNS name or IP address</label><input class="input mono" id="dh" value="${esc(preset.host || '')}" placeholder="10.10.0.2"></div>
        <div class="field"><label for="dk">Device type</label><select class="input" id="dk">${KINDS.map(([k, l]) => `<option value="${k}" ${kind0 === k ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
        <div class="field" id="dpBox" ${S.profilesFor(kind0).length ? '' : 'hidden'}><label for="dp" id="dpL">${modelLabel(kind0)}</label><select class="input" id="dp">${modelOptions(kind0, preset.profile)}</select><span class="hint">The model adds its vendor health sensors (CPU, memory, temperature, status, sessions, latency…). Auto-discovery picks it from the SNMP sysObjectID.</span></div>
        <div class="field"><label for="dg">Group</label><select class="input" id="dg">${groups.map((g) => `<option value="${esc(g.id)}" ${(preset.group || KIND_GROUP[kind0] || 'g:srv') === g.id ? 'selected' : ''}>${esc(g.name)}</option>`).join('')}</select></div>
        ${serverField(t, 'dsv', preset.server)}
      </div>
      <div data-pane="2" hidden></div>
      <div data-pane="3" hidden></div>
      <div data-err></div>
      <div class="foot"><button class="btn" data-x>Cancel</button><button class="btn" id="back" hidden>Back</button><button class="btn primary" id="next">Next</button><button class="btn primary" id="go" hidden>Add device</button></div>`, (m, close) => {
      m.querySelector('.card').classList.add('wide');
      wireServerField(m, t, 'dsv');
      let step = 1, built = '';
      const build = () => {
        const sig = $('#dk', m).value + '|' + $('#dg', m).value + '|' + $('#dp', m).value;
        if (sig === built) return;
        built = sig;
        const acc = ($('input[name=acc]:checked', m) || {}).value || preset.accessLevel || '';
        $('[data-pane="2"]', m).innerHTML = accessField(acc) + credSection(t, $('#dk', m).value, $('#dg', m).value, saved, null); wireCreds(m);
        $('[data-pane="3"]', m).innerHTML = optionsSection($('#dk', m).value, preset.ports || [], null, $('#dp', m).value); wireOptions(m);
      };
      const show = (n) => {
        if (n > 1) { if (!$('#dn', m).value.trim() || !$('#dh', m).value.trim()) { errBox(m, new Error('Give the device a name and a DNS name or IP address.')); return; } build(); }
        if (n > 2) { try { readAccess(m); } catch (e) { errBox(m, e); return; } }
        $('[data-err]', m).innerHTML = '';
        step = n;
        $$('[data-pane]', m).forEach((p) => (p.hidden = +p.dataset.pane !== n));
        $$('[data-step]', m).forEach((b) => b.classList.toggle('on', +b.dataset.step === n));
        $('#back', m).hidden = n === 1; $('#next', m).hidden = n === 3; $('#go', m).hidden = n !== 3;
      };
      $$('[data-step]', m).forEach((b) => b.addEventListener('click', () => show(+b.dataset.step)));
      $('#next', m).addEventListener('click', () => show(step + 1));
      $('#back', m).addEventListener('click', () => show(step - 1));
      $('#dk', m).addEventListener('change', () => { const k = $('#dk', m).value, g = KIND_GROUP[k]; if (g && groups.some((x) => x.id === g)) $('#dg', m).value = g; $('#dp', m).innerHTML = modelOptions(k); $('#dpL', m).textContent = modelLabel(k); $('#dpBox', m).hidden = !S.profilesFor(k).length; });
      $('#go', m).addEventListener('click', async () => {
        const go = $('#go', m); go.disabled = true;
        try {
          const name = $('#dn', m).value.trim();
          const accessLevel = readAccess(m);
          const credentials = await collectCreds(m, name);
          const o = readOptions(m);
          const d = await api('addDevice', { name, accessLevel, host: $('#dh', m).value.trim(), kind: $('#dk', m).value, group: $('#dg', m).value, profile: $('#dp', m).value || null, ports: preset.ports || [], credentials, monitor: o.monitor, interfaces: o.interfaces, volumes: o.volumes, server: $('#dsv', m) ? $('#dsv', m).value : undefined });
          const inv = (d.inventoryJobs || []).filter((j) => j.state !== 'failed');
          close(); MC.toast('Added ' + esc(d.name) + ' with ' + o.monitor.length + ' monitoring options; the first scan runs now' + (inv.length ? '. Collecting its inventory: ' + inv.map((j) => esc(j.label.toLowerCase())).join(', ') : ''), 'ok');
          if (inv.length) MC.refreshDatasets(inv.some((j) => j.job) ? 20000 : 300);
          await done(d);
        } catch (e) { errBox(m, e); go.disabled = false; }
      });
    });
  }
  // other pages (Virtualization › OpenShift / Nutanix) open the same dialog with a preset
  MC.addDevice = async (preset) => { const t = await MC.api.monitor('tree'); addDeviceDialog(t, async () => { if (MC.sourceReset) MC.sourceReset(); MC.render(); }, preset || {}); };
  function deviceSettingsDialog(t, d, done) {
    MC.api.credentials().catch(() => []).then((saved) => modal(`<h3>${esc(d.name)} settings</h3>
      <div class="steps" role="tablist"><button class="on" data-step="1">General</button><button data-step="2">Access</button><button data-step="3">Monitoring</button></div>
      <div data-pane="1">
        <div class="field"><label for="en">Display name</label><input class="input" id="en" value="${esc(d.name)}"></div>
        ${d.manual ? `<div class="field"><label for="eh">DNS name or IP address</label><input class="input mono" id="eh" value="${esc(d.host || '')}"></div>` : ''}
        ${d.manual && S.profilesFor(d.kind).length ? `<div class="field"><label for="ep">${modelLabel(d.kind)}</label><select class="input" id="ep">${modelOptions(d.kind, d.profile)}</select></div>` : ''}
        <div class="grid g2"><div class="field"><label for="eg">Primary group</label><select class="input" id="eg">${t.groups.filter((g) => canOn(g)).sort((a, b) => a.name.localeCompare(b.name)).map((x) => `<option value="${esc(x.id)}" ${x.id === d.group ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></div>
        <div class="field"><label for="ealso">Also a member of <span class="muted">(Ctrl+click for several)</span></label><select class="input" id="ealso" multiple size="4">${t.groups.filter((g) => canOn(g) || (d.also || []).includes(g.id)).sort((a, b) => a.name.localeCompare(b.name)).map((x) => `<option value="${esc(x.id)}" ${(d.also || []).includes(x.id) ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select><span class="hint">The device counts in each of its groups: dashboards, notifications, scheduled jobs, engine targets, monitoring profiles and permissions.</span></div></div>
        ${serverField(t, 'esv', d.server)}
      </div>
      <div data-pane="2" hidden>${d.manual ? accessField(S.accessOf(d)) : ''}${credSection(t, d.kind || 'server', d.group, saved, d.credentials)}</div>
      <div data-pane="3" hidden>${optionsSection(d.kind || 'server', d.ports || [], d.monitor, d.profile)}</div>
      <div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Save</button></div>`, (m, close) => {
      m.querySelector('.card').classList.add('wide');
      wireCreds(m); wireOptions(m); wireServerField(m, t, 'esv');
      $$('[data-step]', m).forEach((b) => b.addEventListener('click', () => { $$('[data-pane]', m).forEach((p) => (p.hidden = p.dataset.pane !== b.dataset.step)); $$('[data-step]', m).forEach((x) => x.classList.toggle('on', x === b)); }));
      $('#go', m).addEventListener('click', async () => {
        try {
          const credentials = await collectCreds(m, d.name);
          const o = readOptions(m);
          await api('setDevice', { id: d.id, accessLevel: d.manual ? readAccess(m) : undefined, name: $('#en', m).value, group: $('#eg', m).value, also: [...$('#ealso', m).selectedOptions].map((x) => x.value).filter((x) => x !== $('#eg', m).value), host: $('#eh', m) ? $('#eh', m).value : undefined, profile: $('#ep', m) ? $('#ep', m).value || null : undefined, credentials, monitor: o.monitor, interfaces: o.interfaces, volumes: o.volumes, server: $('#esv', m) && $('#esv', m).value !== (d.server || 'srv:local') ? $('#esv', m).value : undefined });
          close(); MC.toast('Saved', 'ok'); done();
        } catch (e) { errBox(m, e); }
      });
    }));
  }

  // ------------------------------------------------------------------ investigation steps for a sensor in trouble (public/js/investigate.js)
  const CAUSE = { connectivity: 'Connectivity', auth: 'Credential', certificate: 'Certificate', dns: 'Name resolution', engine: 'Engine', config: 'Sensor setup', limit: 'Limit breach', content: 'Content', paused: 'Paused', other: 'Check' };
  function investigateHtml(s, dev) {
    const r = root.MCInvestigate.forSensor(s, dev);
    return `<p style="margin:0 0 10px"><span class="pill ${r.cause === 'limit' ? 'Warning' : 'Critical'}" style="margin-right:6px">${esc(CAUSE[r.cause] || 'Check')}</span>${esc(r.summary)}</p>
      <ol class="invest">${r.steps.map((x, i) => `<li><b>${esc(x.title)}</b>${x.detail ? `<p>${esc(x.detail)}</p>` : ''}${x.cmd ? `<div class="cmdline"><code class="mono">${esc(x.cmd)}</code><button type="button" class="btn sm ghost" data-copy="${esc(x.cmd)}">Copy</button></div>` : ''}${x.action ? `<button type="button" class="btn sm" data-inv="${i}">${icon(x.action.scan ? 'refresh' : x.action.href ? 'play' : 'bolt', 'sev-ico')}${esc(x.action.label)}</button>` : ''}</li>`).join('')}</ol>`;
  }
  function wireInvestigate(box, s, dev, after) {
    const r = root.MCInvestigate.forSensor(s, dev);
    $$('[data-copy]', box).forEach((b) => b.addEventListener('click', () => { try { navigator.clipboard.writeText(b.dataset.copy); MC.toast('Copied', 'ok'); } catch (e) { /* no clipboard */ } }));
    $$('[data-inv]', box).forEach((b) => b.addEventListener('click', async () => {
      const a = r.steps[+b.dataset.inv].action;
      try {
        if (a.scan) { await api('sensorAction', { id: s.id, action: 'scan' }); MC.toast('Scanning ' + esc(s.name) + ' now', 'ok'); after && after(); }
        else if (a.run) { if (!MC.script(a.run)) return MC.toast('The script ' + esc(a.run) + ' is not in the library', 'err'); MC.runDialog(a.run, a.params || {}); }
        else if (a.href) { const m = b.closest('.modal'); if (m) $('[data-x]', m) && $('[data-x]', m).click(); location.hash = a.href; }
        else if (a.settings) { const m = b.closest('.modal'); if (m) $('[data-x]', m) && $('[data-x]', m).click(); if (location.hash !== sensorLink(s)) location.hash = sensorLink(s); setTimeout(() => { const x = $('#sSet'); if (x) x.click(); }, 400); }
        else if (a.cred) {
          const creds = await MC.api.credentials(); const t = cache.tree || await tree();
          const d = t.devices.find((x) => x.id === s.device) || { id: s.device, group: 'g:srv', credentials: {} };
          const hit = CM.resolve(creds, d, chainOf(t, d.group), a.cred);
          if (!hit) return MC.toast('No ' + esc(a.cred) + ' credential applies to this device. Add one in the device settings (Access) or in Credentials.', 'err');
          MC.toast('Testing ' + esc(hit.cred.name) + '…', 'ok');
          const h = d.host || s.deviceHost || '', sp = s.params || {};
          const res = await MC.api.testCredential(hit.cred.id, a.cred === 'database' ? (sp.engine || d.engine || 'mysql') + '://' + (sp.host || h) + (sp.port ? ':' + sp.port : '') : a.cred === 'cloud' ? '' : h);
          MC.toast(esc(hit.cred.name) + ': ' + esc(res.ok ? 'works' : res.message || 'failed'), res.ok ? 'ok' : 'err');
        }
      } catch (e) { MC.toast(esc(e.message), 'err'); }
    }));
  }
  function investigateDialog(s) {
    Promise.all([api('sensor', { id: s.id }), tree()]).then(([d, t]) => {
      const dev = t.devices.find((x) => x.id === d.device) || {};
      const infra = (t.servers || []);
      const ctx = { host: dev.host, server: dev.server, servers: infra.length, serverName: (infra.find((x) => x.id === dev.server) || {}).name };
      modal(`<h3>Investigate ${esc(d.deviceName || '')} · ${esc(d.name)}</h3><p class="muted" style="margin-top:-4px">${esc(d.message || '')}</p><div id="invB">${investigateHtml(d, ctx)}</div><div class="foot"><a class="btn ghost" href="${sensorLink(d)}">Open the sensor</a><button class="btn" data-x>Close</button></div>`, (m) => { m.querySelector('.card').classList.add('wide'); wireInvestigate(m, d, ctx); $('a.btn', m).addEventListener('click', () => $('[data-x]', m).click()); });
    }).catch((e) => MC.toast(esc(e.message), 'err'));
  }
  MC.investigate = investigateDialog;

  // ------------------------------------------------------------------ live visuals: gauges for utilisation, bars for volumes and traffic
  // list: sensors with channels (op 'channels'). Shared by the device page, the sensor page and dashboards.
  const ST = { Down: 'Critical', Warning: 'Warning', Up: 'OK' };
  function visuals(list, opt = {}) {
    const gauges = [], vols = [], traffic = [], tiles = [];
    for (const s of list) for (const c of s.channels || []) {
      if (c.value == null || isNaN(c.value)) continue;
      const label = opt.channelNames ? c.name : (s.channels.length > 1 && !c.primary) || opt.withDevice ? (opt.withDevice ? s.deviceName + ' · ' : '') + (c.primary ? s.name : c.name) : s.name;
      if (c.unit === '%' && s.type === 'snmp.storage' && c.primary) vols.push({ label: s.name, sub: opt.withDevice ? s.deviceName : '', value: c.value, text: fmt(c.value, 0) + '% used' + ((s.channels.find((x) => x.name === 'Free') || {}).value != null ? ' · ' + fmt(s.channels.find((x) => x.name === 'Free').value, 0) + ' GB free' : ''), status: ST[c.state] || null, color: '--s1', href: sensorLink(s) });
      else if (c.unit === '%' && /free/i.test(c.name)) vols.push({ label: opt.channelNames ? c.name : s.name.replace(/^Disk free\s*/, '') || s.name, sub: opt.withDevice ? s.deviceName : '', value: 100 - c.value, text: fmt(100 - c.value, 0) + '%' + ((s.channels.find((x) => x.unit === 'GB') || {}).value != null ? ' · ' + fmt(s.channels.find((x) => x.unit === 'GB').value, 0) + ' GB free' : ' used'), status: ST[c.state] || null, color: '--s1', href: sensorLink(s) });
      else if (c.unit === '%') gauges.push({ v: c.value, label, warn: c.limits.warnHigh || 80, crit: c.limits.errHigh || 95, href: sensorLink(s) });
      else if (/bit\/s|B\/s/.test(c.unit || '')) traffic.push({ label: s.name + (c.primary ? '' : ' · ' + c.name), sub: opt.withDevice ? s.deviceName : '', value: c.value, text: fmt(c.value) + ' ' + c.unit, color: /out/i.test(c.name) ? '--s2' : '--s1', href: sensorLink(s) });
      else if (c.primary || opt.channelNames) tiles.push({ label: opt.channelNames ? c.name : s.name, text: c.text || fmt(c.value) + (c.unit ? ' ' + c.unit : ''), state: s.state, href: sensorLink(s) });
    }
    const max = opt.max || 24;
    return {
      count: gauges.length + vols.length + traffic.length + tiles.length,
      gauges: gauges.length ? `<div class="gauges wrap">${gauges.slice(0, max).map((g) => `<a href="${g.href}" class="gauge-link">${C.gauge(g.v, { label: g.label, warn: g.warn, crit: g.crit })}</a>`).join('')}</div>` : '',
      volumes: vols.length ? C.barList(vols.sort((a, b) => b.value - a.value).slice(0, max), { max: 100 }) : '',
      traffic: traffic.length ? C.barList(traffic.sort((a, b) => b.value - a.value).slice(0, max), {}) : '',
      tiles: tiles.length ? `<div class="vtiles">${tiles.slice(0, max).map((x) => `<a class="vtile ${look(x)}" href="${x.href}"><small>${esc(x.label)}</small><b>${esc(x.text)}</b></a>`).join('')}</div>` : '',
    };
  }
  MC.monVisuals = visuals;
  MC.monApi = api;
  function liveView(host, deviceId) {
    api('channels', { device: deviceId }).then((list) => {
      const v = visuals(list);
      if (!v.count) { host.innerHTML = '<div class="muted">No numeric channels yet. They appear after the first scan.</div>'; return; }
      host.innerHTML = `<div class="grid ${v.volumes || v.traffic ? 'g-1-2' : ''}" style="gap:14px">
        <div>${v.gauges ? '<div class="vh">Utilisation</div>' + v.gauges : ''}${v.tiles ? '<div class="vh">Checks</div>' + v.tiles : ''}</div>
        <div>${v.volumes ? '<div class="vh">Storage by volume</div>' + v.volumes : ''}${v.traffic ? '<div class="vh">Network traffic</div>' + v.traffic : ''}</div></div>`;
    }).catch((e) => { host.innerHTML = `<div class="muted">${esc(e.message)}</div>`; });
  }

  // ================================================================== DEVICE PAGE
  V.device = {
    title: 'Device',
    crumb: () => 'device › sensors',
    render(el, route) {
      const id = decodeURIComponent(route.tab || '');
      el.innerHTML = '<div class="notice">Loading…</div>';
      const draw = (t) => {
        const d = t.devices.find((x) => x.id === id);
        if (!d) { el.innerHTML = `<div class="notice err">No device ${esc(id)}. It may have been deleted, or its engine stopped reporting it.</div>`; return; }
        $('#pageTitle').textContent = d.name;
        const sensors = t.sensors.filter((s) => s.device === id).sort((a, b) => STATES.indexOf(a.state) - STATES.indexOf(b.state) || a.name.localeCompare(b.name));
        const g = t.groups.find((x) => x.id === d.group) || {};
        const c = d.counts;
        const win = /server|workstation/.test(d.kind || '') || /Windows/i.test(d.os || '');
        const actions = (MC.manifest.scripts || []).filter((s) => s.kind !== 'collector' && (s.parameters || []).some((p) => p.name === 'ComputerName'));
        const look2 = actions.filter((s) => s.kind === 'ondemand'), fix = actions.filter((s) => s.kind === 'action' && s.risk !== 'high'), hard = actions.filter((s) => s.kind === 'action' && s.risk === 'high');
        const actBtn = (s) => `<button class="btn sm ${s.risk === 'high' ? 'ghost' : ''}" ${MC.runAttr(s.id, { ComputerName: d.name })} title="${esc(s.synopsis || '')}">${esc(s.title)}</button>`;
        el.innerHTML = `
          <section class="card panel-c"><div class="shead">
            <span style="color:var(${COLOR[d.paused ? 'Paused' : d.state]})">${icon(KIND_ICON[d.kind] || 'server')}</span>
            <div style="flex:1;min-width:220px"><div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><h2 style="margin:0;font-size:20px">${esc(d.name)}</h2>${pill(d.paused ? 'Paused' : d.state, d.paused ? 'Paused' : d.state)}<span class="tag">${esc(d.kind || 'device')}</span>${d.manual ? '<span class="tag native">added in the console</span>' : '<span class="tag collector">found by the engines</span>'}</div>
            <div class="msg">${esc([d.host, d.os, d.model, d.site].filter(Boolean).join(' · ') || 'No details')}${d.manual ? ' · access <b>' + esc((S.ACCESS_LEVELS.find((a) => a.id === S.accessOf(d)) || {}).label || '') + '</b>' : ''} · group <a href="#/sensors?q=">${esc(g.name || d.group)}</a>${(d.also || []).length ? ' · also in ' + d.also.map((x) => `<a href="#/groups/${encodeURIComponent(x)}">${esc((t.groups.find((y) => y.id === x) || {}).name || x)}</a>`).join(', ') : ''}${d.roles && d.roles.length ? ' · roles ' + esc(d.roles.join(', ')) : ''}</div></div>
            <div class="actions-row">
              ${operator(d) ? `<button class="btn sm" data-da="scan">${icon('refresh', 'sev-ico')}Scan now</button>${d.paused ? '<button class="btn sm" data-da="resume">Resume</button>' : '<button class="btn sm" data-da="pause">Pause…</button>'}` : ''}
              <button class="btn sm" id="tsD">${icon('bolt', 'sev-ico')}Troubleshoot</button>${canOn(d) ? `<button class="btn sm primary" id="addS">Add sensor</button><button class="btn sm" id="editD">Settings</button><button class="btn sm ghost" id="delD">Remove</button>` : ''}
              ${win ? `<button class="btn sm" data-host="${esc(d.name)}">Inventory</button>` : ''}${canOn(d) && (root.MCSensors.inventoryPlan(d).length) ? `<button class="btn sm" id="invD" title="Run the inventory collectors for this device: ${esc(root.MCSensors.inventoryPlan(d).map((x) => x.label.toLowerCase()).join(', '))}">${icon('refresh', 'sev-ico')}Collect inventory</button>` : ''}${canOn(d) && S.accessOf(d) === 'admin' && root.MCRemoteControl && root.MCRemoteControl.methodsFor(d).length ? `<button class="btn sm" id="rcD">${icon('desktop', 'sev-ico')}Remote control</button>` : ''}${MC.user.role === 'admin' && S.accessOf(d) === 'admin' && root.MCRemote && root.MCRemote.languagesFor(d).length ? `<a class="btn sm" href="#/remote?device=${enc(d.id)}">${icon('code', 'sev-ico')}Run code</a>` : ''}
            </div></div></section>
          <div class="kpis">${MC.kpi('Sensors', sensors.length, sensors.filter((s) => s.source === 'native').length + ' probe · ' + sensors.filter((s) => s.source === 'collector').length + ' engine')}${MC.kpi('Down', c.Down || 0, (c.Acknowledged || 0) + ' acknowledged', { alert: (c.Down || 0) > (c.Acknowledged || 0) })}${MC.kpi('Warning', c.Warning || 0, '')}${MC.kpi('Up', c.Up || 0, '')}${MC.kpi('Paused', c.Paused || 0, (c.Unknown || 0) + ' unknown')}</div>
          ${invPanel(d)}
          ${MC.panel('Live view', 'gauges, volumes and traffic from the latest scan', '<div id="dvis"><div class="muted">Loading…</div></div>')}
          ${MC.panel('Sensors', 'click a sensor for its channels, graphs and limits', '<div id="dsT"></div>')}
          <div id="dprof"></div>
          ${actions.length && win && S.accessOf(d) === 'admin' ? MC.panel('Client actions', 'run on ' + esc(d.name) + ' with the same scripts as Actions & jobs; every run is logged', `
            <div style="display:grid;gap:10px">
              <div><div class="muted" style="font-size:12px;margin-bottom:4px">Look (read-only)</div><div class="actions-row">${look2.map(actBtn).join('')}</div></div>
              <div><div class="muted" style="font-size:12px;margin-bottom:4px">Fix</div><div class="actions-row">${fix.map(actBtn).join('')}</div></div>
              <div><div class="muted" style="font-size:12px;margin-bottom:4px">Power, isolation and passwords (high risk, asks to type the name)</div><div class="actions-row">${hard.map(actBtn).join('')}</div></div>
            </div>`) : ''}`;
        liveView($('#dvis', el), id);
        if (MC.profilePanel && d.kind !== 'external') MC.profilePanel($('#dprof', el), d);
        MC.table($('#dsT', el), sensors, [
          { key: 'state', label: 'State', html: stPill, val: (s) => STATES.indexOf(s.state) },
          { key: 'name', label: 'Sensor', html: (s) => `<a href="${sensorLink(s)}"><b>${esc(s.name)}</b></a><br><span class="muted" style="font-size:11.5px">${esc(s.type)}${s.source === 'collector' ? ' · engine ' + esc(s.script) : ' · probe'}${s.profile ? ' · from a profile' : ''}</span>` },
          { key: 'value', label: 'Last value', cls: 'mono' },
          ...(sensors.some((s) => s.spark && s.spark.length > 2) ? [{ key: 'spark', label: 'Trend', noCsv: true, html: (s) => `<span data-sp="${esc(JSON.stringify(s.spark || []))}" data-st="${look(s)}" style="display:inline-block;width:90px"></span>` }] : []),
          { key: 'message', label: 'Message', html: (s) => `<span style="font-size:12.5px">${esc(s.message || '')}</span>` },
          { key: 'lastScan', label: 'Last scan', html: (s) => ago(s.lastScan) },
          { key: 'uptime', label: 'Uptime %', n: true, html: (s) => (s.uptime == null ? '–' : fmt(s.uptime, 2)) },
        ], { sort: 'state', dir: 1, name: 'sensors-' + d.name, limit: 200, after: sparkAll });
        $$('[data-da]', el).forEach((b) => b.addEventListener('click', () => {
          const a = b.dataset.da;
          if (a === 'pause') return pauseDialog('Pause ' + d.name + '?', 'All sensors of the device stop scanning and stop alerting. Engines keep collecting; their results are ignored while paused.', async (minutes) => { await api('deviceAction', { id, action: 'pause', minutes }); draw(await tree(true)); });
          api('deviceAction', { id, action: a }).then(async () => { MC.toast(a === 'scan' ? 'Scanning ' + esc(d.name) + ' now' : esc(d.name) + ' resumed', 'ok'); setTimeout(async () => draw(await tree(true)), 1500); }).catch((e) => MC.toast(esc(e.message), 'err'));
        }));
        if ($('#addS', el)) $('#addS', el).addEventListener('click', () => addSensorDialog(d, async () => draw(await tree(true))));
        $$('[data-invds]', el).forEach((b) => b.addEventListener('click', () => invRowsDialog(d, b.dataset.invds)));
        if ($('#rcD', el)) $('#rcD', el).addEventListener('click', () => remoteControlDialog(d));
        if ($('#invD', el)) $('#invD', el).addEventListener('click', async (e) => {
          e.target.disabled = true;
          try { const r = await MC.api.inventoryCollect(d.id); MC.toast(r.jobs.length ? 'Collecting inventory for ' + esc(d.name) + ': ' + r.jobs.map((j) => esc(j.label.toLowerCase())).join(', ') : 'Nothing to collect for this device type', 'ok'); MC.refreshDatasets(r.jobs.some((j) => j.job) ? 20000 : 300); }
          catch (x) { MC.toast(esc(x.message), 'err'); }
          e.target.disabled = false;
        });
        $('#tsD', el).addEventListener('click', () => { const vm = (MC.allVMs ? MC.allVMs() : []).find((v) => v.Name.toUpperCase() === String(d.name).toUpperCase()); MC.troubleshoot({ name: d.host || d.name, label: d.name, kind: d.kind, os: d.os, platform: vm && vm.Platform, guestOS: vm && vm.GuestOS, vmHost: vm && vm.vmHost, vcenter: vm && vm.vcenter, vmName: vm && vm.Name }); });
        if ($('#editD', el)) $('#editD', el).addEventListener('click', () => deviceSettingsDialog(t, d, async () => draw(await tree(true))));
        if ($('#delD', el)) $('#delD', el).addEventListener('click', () => removeDialog(t, [id], [], () => MC.go('sensors')));
      };
      tree(true).then(draw).catch((e) => { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
      every(el, 15000, async () => draw(await tree(true)));
    },
  };

  function pauseDialog(title, text, run) {
    modal(`<h3>${esc(title)}</h3><p class="muted">${esc(text)}</p><div class="field"><label for="pm">For how long</label><select class="input" id="pm"><option value="60">1 hour</option><option value="240">4 hours</option><option value="1440">1 day</option><option value="10080">1 week</option><option value="0">Until I resume it</option></select></div><div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Pause</button></div>`, (m, close) => {
      $('#go', m).addEventListener('click', async () => { try { await run(+$('#pm', m).value); close(); MC.toast('Paused', 'ok'); } catch (e) { errBox(m, e); } });
    });
  }

  let typesCache = null;
  const types = async () => typesCache || (typesCache = await api('types'));
  function paramInput(p, v) {
    const val = v != null ? v : p.def != null ? p.def : '';
    if (p.values) return `<select class="input" data-p="${esc(p.name)}">${p.values.map((x) => `<option ${String(val) === x ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select>`;
    if (p.secret) return `<input class="input mono" data-p="${esc(p.name)}" type="password" autocomplete="new-password" value="${esc(v ? '••••••' : val)}" placeholder="kept on the console, never shown">`;
    return `<input class="input ${p.type === 'int' ? '' : 'mono'}" data-p="${esc(p.name)}" ${p.type === 'int' ? 'type="number"' : ''} value="${esc(val)}" ${p.min != null ? 'min="' + p.min + '"' : ''} ${p.max != null ? 'max="' + p.max + '"' : ''}>`;
  }
  const readP = (m) => Object.fromEntries($$('[data-p]', m).map((i) => [i.dataset.p, i.value]));

  // ------------------------------------------------------------------ requirements (what a sensor needs, as steps)
  const reqCache = { at: 0, engines: null, creds: null };
  async function reqSources() {
    if (Date.now() - reqCache.at > 30000) {
      const [e, c] = await Promise.all([MC.api.engines().catch(() => null), MC.api.credentials().catch(() => null)]);
      Object.assign(reqCache, { at: Date.now(), engines: e && e.engines, creds: c && (c.credentials || c.items || (Array.isArray(c) ? c : null)) });
    }
    return reqCache;
  }
  // steps for sensor type `typeId` on tree device `d`; `sensor` is the sensor view when it exists already
  async function reqSteps(typeId, d, sensor, params, opts) {
    opts = opts || {};
    const all = await types(), t = all.find((x) => x.id === typeId) || {};
    const src = await reqSources(), t0 = cache.tree || {};
    const script = t.script ? MC.script(t.script) : null;
    const engine = !t.script ? null : src.engines ? src.engines.find((x) => x.id === t.script) || null : undefined;
    const parentOf = (g) => ((t0.groups || []).find((x) => x.id === g) || {}).parent;
    const chain = []; for (let g = d.group; g && g !== 'probe' && chain.length < 12; g = parentOf(g)) chain.push(g);
    const srv = (t0.servers || []).find((x) => x.id === d.server);
    const perms = script && root.MCEngineInfo ? root.MCEngineInfo.permissions(script, opts.direct ? null : engine || null) : null;
    return root.MCReq.steps({ type: t, device: d, chain, creds: src.creds, script, engine, perms, sensor, params, resolve: CM.resolve, kindsFor: CM.kindsFor, server: srv && srv.name, direct: !!opts.direct, interval: opts.interval });
  }
  const REQ_ICON = { ok: 'check', todo: 'alert', check: 'info', info: 'info' };
  const REQ_WORD = { ok: 'Done', todo: 'To do', check: 'Confirm', info: 'Note' };
  const REQ_BTN = { 'engine-on': 'Turn on and run', 'engine-run': 'Run engine now', creds: 'Open credentials', device: 'Device settings', library: 'Script library', scan: 'Scan now', settings: 'Sensor settings' };
  function reqHtml(list, opts) {
    opts = opts || {};
    const sum = root.MCReq.summary(list);
    return `<div class="req-sum ${sum.todo ? 'todo' : 'ok'}">${icon(sum.todo ? 'alert' : 'check', 'sev-ico')}<b>${esc(sum.text)}</b></div>
      <ol class="req-list">${list.map((x) => `<li class="req ${x.status}"><span class="req-n" aria-hidden="true">${x.status === 'ok' ? icon('check') : x.n}</span><div><div class="req-t"><b>${esc(x.title)}</b><span class="req-st">${icon(REQ_ICON[x.status], 'sev-ico')}${REQ_WORD[x.status]}</span></div><p>${esc(x.detail)}</p>${opts.actions !== false && x.action && x.status !== 'ok' && REQ_BTN[x.action] ? `<button class="btn sm ${x.status === 'todo' ? 'primary' : ''}" data-req="${esc(x.action)}">${esc(REQ_BTN[x.action])}</button>` : ''}</div></li>`).join('')}</ol>`;
  }
  function wireReq(box, ctx) {
    $$('[data-req]', box).forEach((b) => b.addEventListener('click', async () => {
      const a = b.dataset.req;
      try {
        if (a === 'engine-on' || a === 'engine-run') { if (!admin()) return MC.toast('Only administrators start monitoring engines.', 'err'); b.disabled = true; if (a === 'engine-on') await MC.api.engineAction('enable', ctx.script); await MC.api.engineAction('start', ctx.script); reqCache.at = 0; MC.toast(esc(ctx.script) + ' is running. The sensor fills in when it reports.', 'ok'); ctx.done && setTimeout(ctx.done, 1500); }
        else if (a === 'creds') location.hash = '#/credentials';
        else if (a === 'library') location.hash = '#/remote/library';
        else if (a === 'device') location.hash = deviceLink(ctx.device);
        else if (a === 'scan' || a === 'settings') { const x = $(a === 'scan' ? '[data-sa="scan"]' : '#sSet'); if (x) x.click(); }
      } catch (e) { b.disabled = false; MC.toast(esc(e.message), 'err'); }
    }));
  }
  MC.reqSteps = reqSteps; MC.reqHtml = reqHtml;

  // types whose engine reports several items per device (volumes, scopes, VMs ...): a direct sensor can pick one
  const ITEM_HINT = { 'wmi.disk': 'Volume, e.g. C:', 'dhcp.scope': 'Scope, e.g. 10.10.0.0', 'hv.vm': 'VM name', 'vmw.vm': 'VM name', 'vmw.datastore': 'Datastore name', 'cluster.csv': 'Volume name', printer: 'Printer name', 'db.instance': 'Instance or database', 'cloud.bucket': 'Bucket or container', 'sql.instance': 'Instance name' };
  async function addSensorDialog(d, done) {
    const all = (await types()).filter((x) => !x.passive);
    const t0 = cache.tree || {};
    const have = new Set((t0.sensors || []).filter((x) => x.device === d.id).map((x) => x.type));
    const catOf = (x) => (x.source === 'native' ? 'Network and web: ' : '') + x.category;
    const cats = [...new Set(all.map(catOf))];
    const optFor = (x) => `<option value="${esc(x.id)}">${esc(x.name)}${have.has(x.id) ? ' (already on this device)' : ''}</option>`;
    const fill = (tp) => tp.params.map((p) => {
      const v = p.fromDevice ? d.host : p.name === 'url' ? 'https://' + (d.host || '') + '/' : p.name === 'name' ? (d.host || '').split('.').slice(1).join('.') || d.host : undefined;
      return `<div class="field"><label>${esc(p.label)}</label>${paramInput(p, v)}</div>`;
    }).join('');
    modal(`<h3>Add a sensor to ${esc(d.name)}</h3><p class="muted">Every sensor type runs directly from the MonCastle probe for this device, on its own schedule; no monitoring engine is needed. For Windows, Active Directory, DNS, DHCP, Hyper-V, VMware, SQL, printer and Linux types you can instead let the engine collect it together with everything it discovers.</p>
      <div class="field"><label for="st">Sensor type</label><select class="input" id="st">${cats.map((c) => `<optgroup label="${esc(c)}">${all.filter((x) => catOf(x) === c).map(optFor).join('')}</optgroup>`).join('')}</select><span class="hint" id="sd"></span></div>
      <fieldset class="field" id="modeF"><legend>Runs by</legend>
        <label class="check"><input type="radio" name="mode" value="direct" checked> <span><b>The probe, directly</b>: this device only, every few seconds or minutes</span></label>
        <label class="check"><input type="radio" name="mode" value="engine"> <span><b>The <span id="engN"></span> engine</b>: on the engine's schedule, together with what it discovers</span></label></fieldset>
      <div class="field"><label for="sn">Name</label><input class="input" id="sn"></div>
      <div class="field" id="itF"><label for="sit">Item <span class="muted">(optional)</span></label><input class="input mono" id="sit" maxlength="120"><span class="hint" id="itH"></span></div>
      <div id="sp"></div>
      <div class="field" id="siF"><label for="si">Scan every (seconds)</label><input class="input" id="si" type="number" min="30" max="86400"></div>
      <section class="req-box"><h4>Requirements on ${esc(d.name)}</h4><div id="sReq"><div class="muted">Checking…</div></div></section>
      <div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Add sensor</button></div>`, (m, close) => {
      let seq = 0;
      const mode = () => (($('input[name=mode]:checked', m) || {}).value || 'direct');
      const showReq = async () => {
        const my = ++seq, tp = all.find((x) => x.id === $('#st', m).value), dir = tp.source === 'collector' && mode() === 'direct';
        try { const list = await reqSteps(tp.id, d, null, tp.source === 'native' ? readP(m) : null, { direct: dir, interval: +$('#si', m).value }); if (my === seq) $('#sReq', m).innerHTML = reqHtml(list, { actions: false }); }
        catch (e) { if (my === seq) $('#sReq', m).innerHTML = `<div class="muted">${esc(e.message)}</div>`; }
      };
      const look = () => {
        const tp = all.find((x) => x.id === $('#st', m).value), coll = tp.source === 'collector', eng = coll && mode() === 'engine';
        $('#modeF', m).hidden = !coll; $('#engN', m).textContent = tp.script || '';
        $('#siF', m).hidden = eng; $('#itF', m).hidden = eng || !ITEM_HINT[tp.id]; $('#itH', m).textContent = ITEM_HINT[tp.id] ? ITEM_HINT[tp.id] + '. Empty = all of them in one sensor, one channel each.' : '';
        $('#go', m).textContent = eng ? 'Add engine sensor' : 'Add sensor';
        showReq();
      };
      const upd = () => {
        const tp = all.find((x) => x.id === $('#st', m).value), coll = tp.source === 'collector';
        $('#sd', m).textContent = tp.desc + (coll ? ' Reads the device with the ' + tp.script + ' script.' : '');
        $('#sn', m).value = tp.name; $('#si', m).value = tp.interval || (coll ? ({ 'wmi.cpu': 60, 'wmi.memory': 60, 'wmi.diskio': 60, 'wmi.network': 60, 'wmi.availability': 60 }[tp.id] || 300) : 60); $('#sit', m).value = '';
        $('#sp', m).innerHTML = coll ? '' : fill(tp);
        look();
      };
      $('#st', m).addEventListener('change', upd); $$('input[name=mode]', m).forEach((r) => r.addEventListener('change', look)); $('#sp', m).addEventListener('change', showReq); upd();
      $('#go', m).addEventListener('click', async () => {
        const tp = all.find((x) => x.id === $('#st', m).value), coll = tp.source === 'collector', eng = coll && mode() === 'engine';
        try {
          const body = eng ? { device: d.id, type: tp.id, name: $('#sn', m).value, mode: 'engine' }
            : coll ? { device: d.id, type: tp.id, name: $('#sn', m).value, mode: 'direct', interval: +$('#si', m).value, params: { item: $('#sit', m).value.trim() } }
            : { device: d.id, type: tp.id, name: $('#sn', m).value, interval: +$('#si', m).value, params: readP(m) };
          const r = await api('addSensor', body);
          close(); reqCache.at = 0;
          MC.toast(eng ? `Engine sensor added. ${esc(tp.script)} reads ${esc(d.name)} on its next run. The sensor page lists the steps that are left.` : 'Sensor added; first scan in a few seconds', 'ok');
          setTimeout(done, eng ? 300 : 1200);
          if (coll && r && r.id) setTimeout(() => { location.hash = sensorLink(r); }, eng ? 400 : 1500);
        } catch (e) { errBox(m, e); }
      });
    });
  }

  // ================================================================== SENSOR PAGE
  const RANGES = [['live', 'Live (2 hours)'], ['five', '2 days'], ['hour', '30 days']];
  V.sensor = {
    title: 'Sensor',
    crumb: () => 'sensor › channels, limits, graphs and log',
    render(el, route) {
      const id = decodeURIComponent(route.tab || '');
      const ui = { range: (route.q || {}).range || 'live' };
      el.innerHTML = '<div class="notice">Loading…</div>';
      const draw = (s) => {
        $('#pageTitle').textContent = s.name;
        $('#crumb').textContent = (s.deviceName || s.device) + ' › ' + s.name;
        const h = s.history || { names: [], live: [] };
        const rows = (h[ui.range] || []).filter((r) => r && r.length > 1);
        const total = s.upMs + s.downMs;
        const isAlarm = s.state === 'Down' || s.state === 'Warning';
        const srvs = (cache.tree && cache.tree.servers) || [];
        const invCtx = { host: s.deviceHost, server: s.deviceServer, servers: srvs.length, serverName: (srvs.find((x) => x.id === s.deviceServer) || {}).name };
        el.innerHTML = `
          <section class="card panel-c"><div class="shead">
            <div style="flex:1;min-width:240px">
              <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">${stPill(s)}<span class="tag ${s.source}">${s.direct ? 'probe sensor · ' + esc(s.script || '') : s.source === 'native' ? 'probe sensor' : 'engine sensor'}</span><span class="muted" style="font-size:12.5px">${esc(s.typeName || s.type)} · ${esc(s.category || '')} · on <a href="${deviceLink(s.device)}">${esc(s.deviceName || s.device)}</a></span></div>
              <div class="big" style="margin-top:8px;color:var(${s.state === 'Down' ? '--crit-ink' : s.state === 'Warning' ? '--warn-ink' : '--text'})">${esc(s.value || '–')}</div>
              <div class="msg">${esc(s.message || '')}</div>
              ${s.ack ? `<div class="notice" style="margin-top:8px">${icon('check', 'sev-ico')} Acknowledged by <b>${esc(s.ack.by)}</b> ${ago(s.ack.at)}${s.ack.note ? ': ' + esc(s.ack.note) : ''}. Notifications for this alarm are silenced until the sensor is Up again.</div>` : ''}
            </div>
            <div class="actions-row" style="align-self:flex-start">
              ${operator(s) ? `<button class="btn sm" data-sa="scan">${icon('refresh', 'sev-ico')}Scan now</button>${s.paused ? '<button class="btn sm" data-sa="resume">Resume</button>' : '<button class="btn sm" data-sa="pause">Pause…</button>'}${isAlarm && !s.ack ? '<button class="btn sm primary" data-sa="ack">Acknowledge…</button>' : ''}${s.ack ? '<button class="btn sm ghost" data-sa="unack">Remove acknowledgement</button>' : ''}` : ''}
              ${canOn(s) ? `<button class="btn sm" id="sSet">Settings & limits</button><button class="btn sm ghost" id="sDel">Remove</button>` : ''}
            </div>
          </div></section>
          <div class="kpis">
            ${MC.kpi('State since', ago(s.since), dt(s.since))}
            ${MC.kpi('Last scan', ago(s.lastScan), s.source === 'native' ? 'every ' + fmt(s.interval, 0) + ' s' : 'engine ' + esc(s.script || ''))}
            ${MC.kpi('Uptime', s.uptime == null ? '–' : fmt(s.uptime, 2) + '%', total ? 'downtime ' + fmtDur(s.downMs) + ' of ' + fmtDur(total) : 'measured from now on')}
            ${MC.kpi('Last up', s.lastUp ? ago(s.lastUp) : '–', s.lastDown ? 'last down ' + ago(s.lastDown) : 'never down')}
          </div>
          ${s.source === 'collector' || s.direct || s.pending || (s.state !== 'Up' && s.state !== 'Paused') ? MC.panel('Requirements', s.pending ? 'this sensor reports once these steps are done' : 'what this sensor needs on ' + (s.deviceName || 'the device'), '<div id="reqP"><div class="muted">Checking…</div></div>') : ''}
          ${s.state !== 'Up' && s.state !== 'Paused' && !s.pending ? MC.panel('Investigate', 'what to check, in order, to get this sensor back up', `<div id="invP">${investigateHtml(s, invCtx)}</div>`) : ''}
          <section class="card panel-c"><div class="panel-h"><h3>Graphs</h3><span class="sub">${rows.length} points · dashed lines are the warning and error limits</span><div class="act">${RANGES.map(([k, l]) => `<button class="btn sm ${ui.range === k ? 'on' : ''}" data-r="${k}" aria-pressed="${ui.range === k}">${l}</button>`).join('')}</div></div>
            <div class="chgrid" id="charts">${(h.names || []).map((n, i) => `<div><div style="display:flex;justify-content:space-between;font-size:12.5px;margin-bottom:4px"><b>${esc(n)}</b><span class="muted">${esc(((s.channels || [])[i] || {}).text || '')}</span></div><div data-ch="${i}"></div></div>`).join('') || '<div class="empty">No values yet. The graphs fill after the first scans.</div>'}</div></section>
          ${(() => { const v = visuals([s], { channelNames: true }); return v.count ? MC.panel('Now', 'latest value of every channel', `<div class="grid ${v.gauges && (v.volumes || v.traffic || v.tiles) ? 'g-1-2' : ''}" style="gap:14px"><div>${v.gauges}${v.tiles}</div><div>${v.volumes}${v.traffic}</div></div>`) : ''; })()}
          ${MC.panel('Channels', 'the worst channel decides the sensor state', '<div id="chT"></div>')}
          ${s.params ? MC.panel('Settings', 'probe sensor parameters', `<div class="tbl-wrap"><table class="tbl"><tbody>${Object.entries(s.params).map(([k, v]) => `<tr><th scope="row" style="position:static;cursor:default">${esc(k)}</th><td class="mono">${esc(v)}</td></tr>`).join('')}</tbody></table></div>`) : ''}
          ${MC.panel('Log', 'state changes of this sensor', '<div id="slT"></div>')}`;
        if ($('#invP', el)) wireInvestigate($('#invP', el), s, invCtx, () => setTimeout(load, 1500));
        if ($('#reqP', el)) {
          const dev = ((cache.tree && cache.tree.devices) || []).find((x) => x.id === s.device) || { id: s.device, name: s.deviceName, host: s.deviceHost, kind: s.deviceKind, server: s.deviceServer, credentials: {} };
          reqSteps(s.type, dev, s, null, { direct: s.direct, interval: s.interval }).then((list) => { const box = $('#reqP', el); if (!box) return; box.innerHTML = reqHtml(list, { actions: canOn(s) }); wireReq(box, { script: s.script, device: s.device, done: load }); }).catch((e) => { const box = $('#reqP', el); if (box) box.innerHTML = `<div class="muted">${esc(e.message)}</div>`; });
        }
        // charts
        const chans = s.channels || [];
        (h.names || []).forEach((n, i) => {
          const host = $(`[data-ch="${i}"]`, el);
          const ch = chans.find((c) => c.name === n) || {};
          const pts = rows.filter((r) => r[i + 1] != null).map((r) => ({ t: r[0], v: +r[i + 1] }));
          const lim = ch.limits || {};
          const limits = [['warnHigh', 'warn'], ['errHigh', 'err'], ['warnLow', 'warn'], ['errLow', 'err']].filter(([k]) => lim[k] != null).map(([k, kind]) => ({ v: lim[k], kind }));
          C.timeSeries(host, [{ name: n, points: pts, color: ch.state === 'Down' ? '--crit' : ch.state === 'Warning' ? '--warn' : '--s1' }], { height: 170, unit: ch.unit && ch.unit !== '#' ? (ch.unit === '%' ? '%' : ' ' + ch.unit) : '', limits, label: n });
        });
        $$('[data-r]', el).forEach((b) => b.addEventListener('click', () => { ui.range = b.dataset.r; draw(s); }));
        MC.table($('#chT', el), chans, [
          { key: 'name', label: 'Channel', html: (c) => `<b>${esc(c.name)}</b>${c.primary ? ' <span class="tag">primary</span>' : ''}` },
          { key: 'text', label: 'Last value', cls: 'mono' },
          { key: 'state', label: 'State', html: (c) => pill(c.state, c.state) },
          { key: 'errLow', label: 'Error below', n: true, val: (c) => c.limits.errLow },
          { key: 'warnLow', label: 'Warning below', n: true, val: (c) => c.limits.warnLow },
          { key: 'warnHigh', label: 'Warning above', n: true, val: (c) => c.limits.warnHigh },
          { key: 'errHigh', label: 'Error above', n: true, val: (c) => c.limits.errHigh },
        ], { search: false, name: 'channels', empty: 'No channels: the last scan failed. See the message above.' });
        MC.table($('#slT', el), s.log || [], [
          { key: 't', label: 'Time', html: (e) => dt(e.t) },
          { key: 'from', label: 'From', html: (e) => pill(e.from, e.from) },
          { key: 'to', label: 'To', html: (e) => pill(e.to, e.to) },
          { key: 'message', label: 'Message' },
        ], { search: false, name: 'sensor-log', limit: 20, empty: 'No state changes recorded yet.' });
        $$('[data-sa]', el).forEach((b) => b.addEventListener('click', () => {
          const a = b.dataset.sa;
          if (a === 'pause') return pauseDialog('Pause ' + s.name + '?', 'The sensor stops scanning and alerting until it is resumed.', async (minutes) => { draw(await act('pause', { minutes })); });
          if (a === 'ack') return modal(`<h3>Acknowledge this alarm</h3><p class="muted">Tells the team someone is on it. The alarm stays visible but sends no more notifications until the sensor is Up again.</p><div class="field"><label for="an">Note</label><input class="input" id="an" placeholder="Replacing the disk tonight" maxlength="300"></div><div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Acknowledge</button></div>`, (m, close) => {
            $('#go', m).addEventListener('click', async () => { try { draw(await act('ack', { note: $('#an', m).value })); close(); MC.toast('Alarm acknowledged', 'ok'); } catch (e) { errBox(m, e); } });
          });
          act(a).then((x) => { draw(x); MC.toast(a === 'scan' ? 'Scanning now' : a === 'resume' ? 'Resumed' : 'Done', 'ok'); if (a === 'scan') setTimeout(load, 2500); }).catch((e) => MC.toast(esc(e.message), 'err'));
        }));
        if ($('#sSet', el)) $('#sSet', el).addEventListener('click', () => settingsDialog(s, draw));
        if ($('#sDel', el)) $('#sDel', el).addEventListener('click', () => modal(`<h3>Remove ${esc(s.name)}?</h3><p class="muted">${s.source === 'native' ? 'The sensor, its history and its limits are removed.' : 'The sensor is no longer shown or alerted on, and its history and limits are deleted; the engine keeps collecting the data for its own pages. Pause it instead if you only need a break.'}</p><div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn danger" id="go">Remove sensor</button></div>`, (m, close) => {
          $('#go', m).addEventListener('click', async () => { try { await api('deleteSensor', { id }); close(); MC.toast('Done', 'ok'); await tree(true); location.hash = deviceLink(s.device); } catch (e) { errBox(m, e); } });
        }));
      };
      const act = async (action, extra) => { await api('sensorAction', Object.assign({ id, action }, extra || {})); tree(true).catch(() => null); return api('sensor', { id }); };
      const load = () => api('sensor', { id }).then(draw).catch((e) => { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
      load();
      every(el, 20000, load);
    },
  };
  const fmtDur = (ms) => { const m = ms / 6e4; return m < 60 ? Math.round(m) + ' min' : m < 2880 ? Math.round(m / 60) + ' h' : Math.round(m / 1440) + ' d'; };

  async function settingsDialog(s, done) {
    const tp = (await types()).find((x) => x.id === s.type) || { params: [] };
    const chans = s.channels || [];
    const cell = (c, k) => `<td><input class="input" type="number" step="any" data-l="${esc(c.name)}" data-k="${k}" value="${c.limits[k] == null ? '' : esc(c.limits[k])}" aria-label="${esc(c.name + ' ' + k)}"></td>`;
    modal(`<h3>Settings & limits · ${esc(s.name)}</h3>
      <div class="field"><label for="sn">Name</label><input class="input" id="sn" value="${esc(s.name)}"></div>
      ${s.source === 'native' ? `<div class="field"><label for="si">Scan every (seconds)</label><input class="input" id="si" type="number" min="30" max="86400" value="${esc(s.interval || tp.interval || 60)}"></div>${s.direct ? `<div class="field"><label>Item <span class="muted">(empty = all)</span></label><input class="input mono" data-p="item" maxlength="120" value="${esc((s.params || {}).item || '')}"><span class="hint">${esc(ITEM_HINT[s.type] || 'Only for types with several items per device')}</span></div><p class="muted" style="font-size:12.5px">The probe runs <b>${esc(s.script || '')}</b> for this device only.</p>` : ''}${tp.params.map((p) => `<div class="field"><label>${esc(p.label)}</label>${paramInput(p, (s.params || {})[p.name])}</div>`).join('')}` : `<p class="muted" style="font-size:12.5px">This sensor is fed by the <b>${esc(s.script)}</b> engine; change how often it runs under <a href="#/engines">Monitoring engines</a>.</p>`}
      <h4 style="margin:14px 0 6px;font-size:13px">Channel limits</h4>
      <p class="muted" style="font-size:12.5px;margin:0 0 6px">A value above an upper limit or below a lower limit sets the sensor to Warning or Down. Leave a box empty for no limit.</p>
      ${chans.length ? `<div class="tbl-wrap"><table class="tbl limits-tbl"><thead><tr><th>Channel</th><th>Error below</th><th>Warning below</th><th>Warning above</th><th>Error above</th></tr></thead><tbody>${chans.map((c) => `<tr><td><b>${esc(c.name)}</b>${c.unit && c.unit !== '#' ? ' <span class="muted">' + esc(c.unit) + '</span>' : ''}</td>${cell(c, 'errLow')}${cell(c, 'warnLow')}${cell(c, 'warnHigh')}${cell(c, 'errHigh')}</tr>`).join('')}</tbody></table></div>` : '<p class="muted">Limits can be set once the sensor has reported channels.</p>'}
      <h4 style="margin:14px 0 6px;font-size:13px">History retention</h4>
      <div class="field two"><div><label for="srd">Keep history (days)</label><input class="input" id="srd" type="number" min="1" max="3650" value="${esc((s.overrides || {}).retentionDays || '')}" placeholder="policy: ${esc((s.retention || {}).policyDays || 31)} days"></div><div><label>&nbsp;</label><label class="check"><input type="checkbox" id="sra" ${(s.overrides || {}).archive === false ? '' : 'checked'}> <span>Archive older history</span></label></div></div>
      <p class="muted" style="font-size:12.5px;margin:0 0 6px">Leave empty to follow the system policy (<a href="#/retention">Data retention</a>). Older history moves to the encrypted archive, or is deleted when archiving is off for this sensor.</p>
      <div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Save</button></div>`, (m, close) => {
      $('#go', m).addEventListener('click', async () => {
        const limits = {};
        $$('[data-l]', m).forEach((i) => { (limits[i.dataset.l] = limits[i.dataset.l] || {})[i.dataset.k] = i.value === '' ? null : +i.value; });
        for (const [n, l] of Object.entries(limits)) {
          if (l.warnHigh != null && l.errHigh != null && l.warnHigh > l.errHigh) return errBox(m, new Error(n + ': the warning limit above must be lower than the error limit above.'));
          if (l.warnLow != null && l.errLow != null && l.warnLow < l.errLow) return errBox(m, new Error(n + ': the warning limit below must be higher than the error limit below.'));
        }
        const body = { id: s.id, name: $('#sn', m).value, limits, retentionDays: $('#srd', m).value === '' ? null : +$('#srd', m).value, archive: $('#sra', m).checked };
        if ($('#si', m)) { body.interval = +$('#si', m).value; body.params = readP(m); }
        try { const r = await api('sensorSettings', body); close(); MC.toast('Saved; the state is re-checked against the new limits', 'ok'); tree(true).catch(() => null); done(r); } catch (e) { errBox(m, e); }
      });
    });
  }

  // ================================================================== ALARMS & LOG
  V.alarms = {
    title: 'Alarms',
    crumb: () => 'sensors that are down, in warning or unknown · state log',
    render(el, route) {
      const tab = route.tab || 'open';
      const q = route.q || {};
      el.innerHTML = MC.tabs('alarms', [['open', 'Open alarms'], ['groups', 'By group'], ['log', 'State log']], tab) + '<div id="tab" class="grid"></div>';
      const t = $('#tab', el);
      if (tab === 'groups') {
        tree(true).then((tr) => MC.alarmsByGroup(t, tr)).catch((e) => { t.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
        every(el, 15000, async () => MC.alarmsByGroup(t, await tree(true)));
        return;
      }
      if (tab === 'log') {
        api('log', { limit: 1000 }).then((log) => {
          const hours = 24, now = Date.now();
          const buckets = Array.from({ length: hours }, (_, i) => { const st = now - (hours - i) * 36e5; return { label: new Date(st).getHours() + 'h', title: new Date(st).toLocaleString(undefined, { weekday: 'short', hour: '2-digit', minute: '2-digit' }), values: {} }; });
          for (const e of log) { const i = Math.floor((Date.parse(e.t) - (now - hours * 36e5)) / 36e5); if (i >= 0 && i < hours) buckets[i].values[e.to] = (buckets[i].values[e.to] || 0) + 1; }
          t.innerHTML = MC.panel('State changes, last 24 hours', 'by the state the sensor moved to', '<div id="lc"></div>') + MC.panel('State log', log.length + ' changes', '<div id="lt"></div>');
          C.columns($('#lc', t), buckets, [{ key: 'Down', name: 'To Down', color: '--crit' }, { key: 'Warning', name: 'To Warning', color: '--warn' }, { key: 'Up', name: 'To Up', color: '--ok' }, { key: 'Paused', name: 'Paused', color: '--s1' }, { key: 'Unknown', name: 'Unknown', color: '--muted' }], { height: 160, label: 'State changes per hour' });
          MC.table($('#lt', t), log, [
            { key: 't', label: 'Time', html: (e) => dt(e.t) },
            { key: 'deviceName', label: 'Device', html: (e) => `<a href="${deviceLink(e.device)}">${esc(e.deviceName || e.device)}</a>` },
            { key: 'sensorName', label: 'Sensor', html: (e) => `<a href="#/sensor/${enc(e.sensor)}">${esc(e.sensorName)}</a>` },
            { key: 'from', label: 'From', html: (e) => pill(e.from, e.from) },
            { key: 'to', label: 'To', html: (e) => pill(e.to, e.to) },
            { key: 'message', label: 'Message' },
          ], { name: 'monitoring-log', limit: 100 });
        }).catch((e) => { t.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
        return;
      }
      const ui = { state: q.state || '', related: false };
      const draw = (tr) => {
        const devs = new Map(tr.devices.map((d) => [d.id, d]));
        const byId = new Map(tr.sensors.map((s) => [s.id, s]));
        // an alarm that repeats another one on the same device (device unreachable, same metric twice) is folded into it
        const related = tr.sensors.filter((s) => s.related);
        const all = tr.sensors.filter((s) => (s.state === 'Down' || s.state === 'Warning' || s.state === 'Unknown') && (ui.related || !s.related));
        const list = all.filter((s) => !ui.state || (ui.state === 'Ack' ? s.ack && s.state === 'Down' : ui.state === 'Down' ? s.state === 'Down' && !s.ack : s.state === ui.state));
        const n = (f) => all.filter(f).length;
        const byCat = {};
        for (const s of all.filter((x) => x.state !== 'Unknown')) { const k = s.type.split('.')[0]; byCat[k] = (byCat[k] || 0) + 1; }
        const filters = [['', 'All', all.length], ['Down', 'Down', n((s) => s.state === 'Down' && !s.ack)], ['Ack', 'Acknowledged', n((s) => s.state === 'Down' && s.ack)], ['Warning', 'Warning', n((s) => s.state === 'Warning')], ['Unknown', 'Unknown', n((s) => s.state === 'Unknown')]];
        t.innerHTML = `<div class="kpis">${MC.kpi('Down', n((s) => s.state === 'Down' && !s.ack), 'not acknowledged', { alert: n((s) => s.state === 'Down' && !s.ack) > 0 })}${MC.kpi('Acknowledged', n((s) => s.ack), 'someone is on it')}${MC.kpi('Warning', n((s) => s.state === 'Warning'), 'over a warning limit')}${MC.kpi('Unknown', n((s) => s.state === 'Unknown'), 'no recent data')}${MC.kpi('Devices affected', new Set(all.filter((s) => s.state !== 'Unknown').map((s) => s.device)).size, 'of ' + tr.devices.length)}</div>
          <div class="grid g-1-2">${MC.panel('Alarms by sensor family', 'down and warning', C.barList(Object.entries(byCat).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([k, v]) => ({ label: k, value: v, color: '--s3' }))))}
          ${MC.panel('Longest open', 'oldest alarms first', C.barList(all.filter((s) => s.state !== 'Unknown').sort((a, b) => Date.parse(a.since) - Date.parse(b.since)).slice(0, 8).map((s) => ({ label: (devs.get(s.device) || {}).name + ' · ' + s.name, value: (Date.now() - Date.parse(s.since)) / 36e5, text: ago(s.since).replace(' ago', ''), status: s.state === 'Down' ? 'Critical' : 'Warning', href: sensorLink(s) }))))}</div>
          <section class="card panel-c"><div class="toolbar" style="margin-bottom:8px;flex-wrap:wrap;gap:8px"><div class="mfilter">${filters.map(([k, l, c]) => `<button class="btn sm ${ui.state === k ? 'on' : ''}" data-st="${k}">${k ? `<span class="sdot ${k}" style="margin:0"></span>` : ''}${l} <span class="muted">${c}</span></button>`).join('')}</div>${related.length ? `<label class="check" style="font-size:12.5px"><input type="checkbox" id="aRel" ${ui.related ? 'checked' : ''}> Show ${related.length} folded duplicate${related.length === 1 ? '' : 's'}</label>` : ''}</div><div id="aT"></div></section>`;
        MC.table($('#aT', t), list, [
          { key: 'state', label: 'State', html: stPill, val: (s) => (s.state === 'Down' ? (s.ack ? 1 : 0) : s.state === 'Warning' ? 2 : 3) },
          { key: 'device', label: 'Device', html: (s) => `<a href="${deviceLink(s.device)}">${esc((devs.get(s.device) || {}).name || s.device)}</a>`, val: (s) => (devs.get(s.device) || {}).name },
          { key: 'name', label: 'Sensor', html: (s) => `<a href="${sensorLink(s)}"><b>${esc(s.name)}</b></a>` },
          { key: 'value', label: 'Value', cls: 'mono' },
          { key: 'message', label: 'Message', html: (s) => `<span style="font-size:12.5px">${esc(s.message || '')}</span>${s.relatedCount ? `<br><span class="muted" style="font-size:11.5px">${s.relatedCount} more alarm${s.relatedCount === 1 ? '' : 's'} on this device folded in</span>` : ''}${s.related && byId.get(s.related) ? `<br><span class="muted" style="font-size:11.5px">Duplicate of ${esc(byId.get(s.related).name)}</span>` : ''}${s.ack ? `<br><span class="muted" style="font-size:11.5px">ack by ${esc(s.ack.by)}${s.ack.note ? ': ' + esc(s.ack.note) : ''}</span>` : ''}` },
          { key: 'since', label: 'Since', html: (s) => ago(s.since), val: (s) => -Date.parse(s.since || 0) },
          { key: 'act', label: '', noCsv: true, html: (s) => `<div class="actions-row" style="flex-wrap:nowrap"><button class="btn sm" data-invs="${esc(s.id)}">Investigate</button>${operator((cache.tree && cache.tree.devices.find((d) => d.id === s.device)) || null) && s.state !== 'Unknown' ? `${!s.ack ? `<button class="btn sm" data-ack="${esc(s.id)}">Acknowledge</button>` : ''}<button class="btn sm ghost" data-scan="${esc(s.id)}">Scan</button>` : ''}</div>` },
        ], { sort: 'state', dir: 1, name: 'alarms', limit: 100, empty: 'No alarms. Every sensor is up or paused.', after: (w) => {
          $$('[data-ack]', w).forEach((b) => b.addEventListener('click', () => modal(`<h3>Acknowledge this alarm</h3><div class="field"><label for="an">Note</label><input class="input" id="an" maxlength="300" placeholder="Working on it"></div><div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Acknowledge</button></div>`, (m, close) => {
            $('#go', m).addEventListener('click', async () => { try { await api('sensorAction', { id: b.dataset.ack, action: 'ack', note: $('#an', m).value }); close(); MC.toast('Acknowledged', 'ok'); draw(await tree(true)); } catch (e) { errBox(m, e); } });
          })));
          $$('[data-scan]', w).forEach((b) => b.addEventListener('click', async () => { try { await api('sensorAction', { id: b.dataset.scan, action: 'scan' }); MC.toast('Scanning now', 'ok'); } catch (e) { MC.toast(esc(e.message), 'err'); } }));
          $$('[data-invs]', w).forEach((b) => b.addEventListener('click', () => investigateDialog({ id: b.dataset.invs })));
        } });
        $$('[data-st]', t).forEach((b) => b.addEventListener('click', () => { ui.state = b.dataset.st; draw(tr); }));
        if ($('#aRel', t)) $('#aRel', t).addEventListener('change', (e) => { ui.related = e.target.checked; draw(tr); });
      };
      tree(true).then(draw).catch((e) => { t.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
      every(el, 15000, async () => draw(await tree(true)));
    },
  };

  // ================================================================== CONNECTORS (sensor types)
  const wireCopy = (box) => $$('[data-copy]', box).forEach((b) => b.addEventListener('click', () => { try { navigator.clipboard.writeText(b.dataset.copy); MC.toast('Copied', 'ok'); } catch (e) { /* no clipboard */ } }));
  // ------------------------------------------------------------------ Monitor > Alert integrations
  const OB = () => root.MCOutbound;
  // what a direction is for, what the user needs and the steps, from outbound.js
  const dirCard = (id) => { const d = OB().DIRECTIONS.find((x) => x.id === id); return `<div class="card dircard"><div class="dirhead">${icon(d.icon, 'sev-ico')}<b>${esc(d.name)}</b></div><p>${esc(d.what)}</p><div class="dircols"><div><h4>You need</h4><ul>${d.requirements.map((x) => `<li>${esc(x)}</li>`).join('')}</ul></div><div><h4>Steps</h4><ol>${d.steps.map((x) => `<li>${esc(x)}</li>`).join('')}</ol></div></div></div>`; };
  V.integrations = {
    title: 'Alert integrations',
    crumb: () => 'ingress: alerts into MonCastle · egress: alarms out to chat, SIEM and automation · incidents: tickets in your service desk',
    render(el, route) {
      const tab = (route && route.tab) || 'ingress';
      el.innerHTML = MC.tabs('integrations', [['ingress', 'Ingress (alerts in)'], ['egress', 'Egress (alarms out)'], ['incident', 'Incidents (tickets)']], tab) + '<div id="igTab" class="grid"></div>';
      const t = $('#igTab', el);
      return tab === 'ingress' ? ingressTab(t) : outboundTab(t, tab === 'incident' ? 'incident' : 'egress');
    },
  };
  async function ingressTab(el) {
      const AS = root.MCAlertSources;
      el.innerHTML = '<div class="muted">Loading…</div>';
      let list;
      try { list = await api('integrations'); } catch (e) { el.innerHTML = `<div class="notice ${e.status === 403 ? 'warn' : 'err'}">${esc(e.message)}</div>`; return; }
      const base = String((MC.status && MC.status.url) || location.origin).replace(/\/$/, '');
      const urlOf = (x) => base + '/api/ingest/' + x.id;
      const open = list.reduce((a, x) => a + x.open, 0);
      el.innerHTML = dirCard('ingress') + `<div class="kpis">${MC.kpi('Integrations', list.length, list.filter((x) => x.enabled).length + ' on')}${MC.kpi('Open external alarms', open, 'Down or Warning now', { alert: open > 0, href: '#/alarms' })}${MC.kpi('Alerts received', fmt(list.reduce((a, x) => a + x.received, 0), 0), 'since each integration was added')}${MC.kpi('Supported systems', AS.SOURCES.length, 'plus any tool that can post JSON')}</div>
        ${MC.panel('Integrations', 'each one has its own address and token; alerts become External alert sensors on the matching device', `<div class="toolbar" style="margin-bottom:10px"><button class="btn sm primary" id="inAdd">${icon('plus', 'sev-ico')}Add integration</button></div><div id="inList"></div>`)}
        ${MC.panel('How it works', '', `<ul class="muted" style="margin:0;padding-left:18px;font-size:13px;line-height:1.6"><li>The other tool posts its alert to the integration's address with the token (as <span class="mono">Authorization: Bearer …</span>, or <span class="mono">?token=</span> for tools that cannot set headers).</li><li>MonCastle matches the alert's host to a device by name or address. Hosts it does not know get a device of their own in the integration's group.</li><li>Each alert is one sensor, so it shows in Alarms, Groups, notifications and reports like any other. A resolved alert turns the sensor Up; it is removed after 7 days.</li><li>Tokens are stored only as a hash. A lost token cannot be shown again: issue a new one.</li></ul>`)}`;
      const box = $('#inList', el);
      box.innerHTML = list.length ? `<table class="tbl"><thead><tr><th>Name</th><th>System</th><th>Address</th><th>Last alert</th><th class="num">Alerts</th><th class="num">Open</th><th>State</th><th></th></tr></thead><tbody>${list.map((x) => `<tr><td><b>${esc(x.name)}</b></td><td>${esc(x.sourceName)}</td><td class="mono" style="font-size:12px;word-break:break-all">${esc(urlOf(x))}</td><td>${x.lastAt ? esc(ago(x.lastAt)) : '<span class="muted">never</span>'}${x.lastError ? `<div class="muted" style="font-size:12px">${esc(x.lastError)}</div>` : ''}</td><td class="num">${x.alerts}</td><td class="num">${x.open ? `<b>${x.open}</b>` : 0}</td><td>${x.enabled ? pill('Up', 'On') : pill('Paused', 'Off')}</td><td><div class="actions-row" style="justify-content:flex-end"><button class="btn sm" data-in-test="${esc(x.id)}">Send test</button><button class="btn sm ghost" data-in-guide="${esc(x.id)}">Setup</button><button class="btn sm ghost" data-in-tog="${esc(x.id)}">${x.enabled ? 'Turn off' : 'Turn on'}</button><button class="btn sm ghost" data-in-rot="${esc(x.id)}">New token</button><button class="btn sm ghost" data-in-del="${esc(x.id)}">Delete</button></div></td></tr>`).join('')}</tbody></table>` : '<p class="muted" style="margin:0">No integrations yet. Add one for each monitoring system that should send its alerts here.</p>';
      const byId = (id) => list.find((x) => x.id === id);
      const guide = (x, token) => modal(`<h3>Connect ${esc(x.sourceName)}</h3>
          ${token ? `<div class="notice warn" style="margin-bottom:10px">Copy the token now. It is stored only as a hash and cannot be shown again.</div>` : ''}
          <div class="field"><label>Address</label><div class="cmdline"><code class="mono">${esc(urlOf(x))}</code><button type="button" class="btn sm ghost" data-copy="${esc(urlOf(x))}">Copy</button></div></div>
          <div class="field"><label>Token</label>${token ? `<div class="cmdline"><code class="mono">${esc(token)}</code><button type="button" class="btn sm ghost" data-copy="${esc(token)}">Copy</button></div>` : '<span class="muted">Hidden. Use New token to issue a replacement.</span>'}</div>
          <div class="field"><label>In ${esc(x.sourceName)}</label><p style="margin:0;font-size:13px;line-height:1.55">${esc(AS.SOURCE[x.source].setup.replace(/<URL>/g, urlOf(x)).replace(/<TOKEN>/g, token || '<token>'))}</p></div>
          <details><summary class="muted" style="cursor:pointer">Example message</summary><pre class="mono" style="font-size:12px;white-space:pre-wrap;margin:6px 0 0">${esc(JSON.stringify(AS.SOURCE[x.source].sample, null, 2))}</pre></details>
          <div class="actions-row" style="margin-top:12px"><button class="btn ghost" type="button" data-x>Close</button></div>`, (m) => wireCopy(m));
      $('#inAdd', el).addEventListener('click', async () => {
        const t = await tree();
        const groups = t.groups.slice().sort((a, b) => a.name.localeCompare(b.name));
        modal(`<h3>Add an alert integration</h3>
          <div class="field"><label for="inSrc">Monitoring system</label><select class="input" id="inSrc">${AS.SOURCES.map((x) => `<option value="${x.id}">${esc(x.name)}</option>`).join('')}</select></div>
          <div class="field"><label for="inName">Name</label><input class="input" id="inName" maxlength="80" placeholder="Prometheus Alertmanager"></div>
          <div class="field"><label for="inGrp">Group for hosts MonCastle does not know yet</label><select class="input" id="inGrp">${groups.map((g) => `<option value="${esc(g.id)}" ${g.id === 'g:ext' ? 'selected' : ''}>${esc(g.name)}</option>`).join('')}</select></div>
          <div data-err></div><div class="actions-row"><button class="btn primary" id="inSave" type="button">Add</button><button class="btn ghost" type="button" data-x>Cancel</button></div>`, (m, close) => {
          $('#inSrc', m).addEventListener('change', () => { $('#inName', m).placeholder = AS.SOURCE[$('#inSrc', m).value].name; });
          $('#inSave', m).addEventListener('click', async () => {
            try { const x = await api('addIntegration', { source: $('#inSrc', m).value, name: $('#inName', m).value.trim() || undefined, group: $('#inGrp', m).value }); close(); await ingressTab(el); guide(x, x.token); } catch (e) { errBox(m, e); }
          });
        });
      });
      $$('[data-in-guide]', el).forEach((b) => b.addEventListener('click', () => guide(byId(b.dataset.inGuide))));
      $$('[data-in-test]', el).forEach((b) => b.addEventListener('click', async () => { try { const r = await api('testIntegration', { id: b.dataset.inTest }); MC.toast(r.received + ' test alert received' + (r.alerts[0] ? ' on ' + esc(r.alerts[0].device.replace(/^d:/, '')) : ''), 'ok'); cache.at = 0; ingressTab(el); } catch (e) { MC.toast(esc(e.message), 'err'); } }));
      $$('[data-in-tog]', el).forEach((b) => b.addEventListener('click', async () => { const x = byId(b.dataset.inTog); try { await api('setIntegration', { id: x.id, enabled: !x.enabled }); ingressTab(el); } catch (e) { MC.toast(esc(e.message), 'err'); } }));
      $$('[data-in-rot]', el).forEach((b) => b.addEventListener('click', async () => { if (!confirm('Issue a new token? The old one stops working at once.')) return; try { const x = await api('setIntegration', { id: b.dataset.inRot, rotate: true }); guide(x, x.token); } catch (e) { MC.toast(esc(e.message), 'err'); } }));
      $$('[data-in-del]', el).forEach((b) => b.addEventListener('click', async () => { if (!confirm('Delete this integration and its external alert sensors?')) return; try { await api('deleteIntegration', { id: b.dataset.inDel }); cache.at = 0; ingressTab(el); } catch (e) { MC.toast(esc(e.message), 'err'); } }));
  }

  async function outboundTab(el, dir) {
    el.innerHTML = '<div class="muted">Loading…</div>';
    let res, tr, types;
    try { [res, tr, types] = await Promise.all([api('outbound'), tree(), api('types').catch(() => [])]); } catch (e) { el.innerHTML = `<div class="notice ${e.status === 403 ? 'warn' : 'err'}">${esc(e.message)}</div>`; return; }
    const defs = OB().TARGETS.filter((x) => x.direction === dir);
    const list = res.list.filter((x) => x.direction === dir);
    const sent = (res.sent || []).filter((x) => x.direction === dir);
    const failed = list.filter((x) => /^failed/.test(x.lastResult || '')).length;
    el.innerHTML = dirCard(dir) + `
      <div class="kpis">${MC.kpi(dir === 'incident' ? 'Service desks' : 'Receivers', list.length, list.filter((x) => x.enabled).length + ' on')}${MC.kpi('Sent', sent.length, 'since the console started')}${MC.kpi('Failing', failed, 'last attempt failed', { alert: failed > 0 })}${MC.kpi('Supported', defs.length, defs.map((d) => d.name.split(' (')[0]).join(', '))}</div>
      ${MC.panel(dir === 'incident' ? 'Incident integrations' : 'Egress integrations', dir === 'incident' ? 'one incident per alarm; resolved when the sensor is Up again' : 'each matching state change is sent as one event', `${admin() ? `<div class="toolbar" style="margin-bottom:10px">${defs.map((d) => `<button class="btn sm ${d === defs[0] ? 'primary' : ''}" data-ob-add="${d.id}">${icon('plus', 'sev-ico')}${esc(d.name)}</button>`).join('')}</div>` : ''}<div id="obList"></div>`)}
      ${MC.panel('Sent', 'latest first', '<div id="obSent"></div>')}`;
    const scopeTxt = (x) => ruleScope(x, tr, types);
    $('#obList', el).innerHTML = list.length ? `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Name</th><th>Type</th><th>States</th><th>Alarms</th><th>Secret</th><th>Last</th><th>State</th><th></th></tr></thead><tbody>${list.map((x) => `<tr><td><b>${esc(x.name)}</b>${x.fields.url ? `<div class="mono muted" style="font-size:11.5px">${esc(x.fields.url.replace(/(\/\/[^/]+).*/, '$1'))}</div>` : ''}</td><td>${esc((OB().TARGET[x.kind] || {}).name || x.kind)}</td><td>${x.on.map(esc).join(', ')}${x.delayMin ? `<div class="muted" style="font-size:12px">after ${x.delayMin} min</div>` : ''}</td><td style="font-size:12.5px">${esc(scopeTxt(x))}</td><td>${OB().secretsOf(x.kind).length ? (x.secretSet ? pill('Up', 'stored') : pill('Warning', 'missing')) : '<span class="muted">none needed</span>'}</td><td style="font-size:12.5px">${x.lastSent ? esc(ago(x.lastSent)) + `<div class="${/^failed/.test(x.lastResult || '') ? '' : 'muted'}" style="font-size:12px;${/^failed/.test(x.lastResult || '') ? 'color:var(--crit-ink)' : ''}">${esc(x.lastResult || '')}</div>` : '<span class="muted">never</span>'}</td><td>${x.enabled ? pill('Up', 'On') : pill('Paused', 'Off')}</td><td>${admin() ? `<div class="actions-row" style="justify-content:flex-end;flex-wrap:nowrap"><button class="btn sm" data-ob-test="${esc(x.id)}">Test</button><button class="btn sm ghost" data-ob-ed="${esc(x.id)}">Edit</button><button class="btn sm ghost" data-ob-tog="${esc(x.id)}">${x.enabled ? 'Turn off' : 'Turn on'}</button><button class="btn sm ghost" data-ob-del="${esc(x.id)}">Delete</button></div>` : ''}</td></tr>`).join('')}</tbody></table></div>` : `<p class="muted" style="margin:0">${dir === 'incident' ? 'No service desk connected yet.' : 'Nothing receives MonCastle alarms yet.'} Pick a type above to add one.</p>`;
    MC.table($('#obSent', el), sent, [
      { key: 't', label: 'Time', html: (x) => dt(x.t) }, { key: 'integration', label: 'Integration' }, { key: 'state', label: 'State', html: (x) => pill(x.state, x.state) },
      { key: 'device', label: 'Device' }, { key: 'sensor', label: 'Sensor' }, { key: 'result', label: 'Result', html: (x) => (/^failed/.test(x.result) ? `<span style="color:var(--crit-ink)">${esc(x.result)}</span>` : esc(x.result)) },
    ], { name: 'outbound-' + dir, limit: 50, empty: 'Nothing sent yet.' });
    const again = () => outboundTab(el, dir);
    const byId = (id) => list.find((x) => x.id === id);
    $$('[data-ob-add]', el).forEach((b) => b.addEventListener('click', () => outboundDialog({ kind: b.dataset.obAdd }, tr, types, again)));
    $$('[data-ob-ed]', el).forEach((b) => b.addEventListener('click', () => outboundDialog(byId(b.dataset.obEd), tr, types, again)));
    $$('[data-ob-tog]', el).forEach((b) => b.addEventListener('click', async () => { const x = byId(b.dataset.obTog); try { await api('setOutbound', Object.assign({}, x, { enabled: !x.enabled })); again(); } catch (e) { MC.toast(esc(e.message), 'err'); } }));
    $$('[data-ob-test]', el).forEach((b) => b.addEventListener('click', async () => { b.disabled = true; try { const r = await api('testOutbound', { id: b.dataset.obTest }); MC.toast('Test ' + esc(r.result || 'sent') + (dir === 'incident' ? '; it resolves in a few seconds' : ''), 'ok'); again(); } catch (e) { MC.toast(esc(e.message), 'err'); again(); } }));
    $$('[data-ob-del]', el).forEach((b) => b.addEventListener('click', () => modal(`<h3>Delete ${esc(byId(b.dataset.obDel).name)}?</h3><p class="muted">MonCastle stops sending to it and deletes its stored secret. Open incidents stay open in the service desk.</p><div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn danger" id="go">Delete</button></div>`, (m, close) => {
      $('#go', m).addEventListener('click', () => api('removeOutbound', { id: b.dataset.obDel }).then(() => { close(); MC.toast('Deleted', 'ok'); again(); }).catch((e) => errBox(m, e)));
    })));
  }

  function outboundDialog(x, tr, types, done) {
    const def = OB().TARGET[x.kind];
    const isNew = !x.id;
    x = Object.assign({ name: '', enabled: true, on: def.on.slice(), delayMin: def.direction === 'incident' ? 5 : 0, groups: [], devices: [], sensors: [], types: [], fields: {} }, x);
    const scoped = x.groups.length + x.devices.length + x.sensors.length > 0;
    const devName = (id) => (tr.devices.find((d) => d.id === id) || {}).name || id;
    const field = (f) => {
      const v = (x.fields || {})[f.id] || '';
      if (f.type === 'select') return `<div class="field"><label for="of-${f.id}">${esc(f.label)}</label><select class="input" id="of-${f.id}" data-of="${f.id}">${f.options.map(([k, l]) => `<option value="${esc(k)}" ${v === k ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></div>`;
      if (f.secret) return `<div class="field"><label for="of-${f.id}">${esc(f.label)}${f.required ? '' : ' (optional)'}</label><input class="input mono" id="of-${f.id}" data-os="${f.id}" type="password" autocomplete="new-password" placeholder="${x.secretSet && !isNew ? 'stored; type to replace' : esc(f.placeholder || '')}"><span class="hint">Stored encrypted on the console server; never shown again.</span></div>`;
      return `<div class="field"><label for="of-${f.id}">${esc(f.label)}</label><input class="input ${f.type === 'url' ? 'mono' : ''}" id="of-${f.id}" data-of="${f.id}" value="${esc(v)}" placeholder="${esc(f.placeholder || '')}"></div>`;
    };
    modal(`<h3>${isNew ? 'Add' : 'Edit'} ${esc(def.name)}</h3>
      <div class="notice" style="margin-bottom:10px;font-size:13px">${esc(def.help)}</div>
      <div class="field"><label for="oN">Name</label><input class="input" id="oN" value="${esc(x.name)}" placeholder="${esc(def.name)}"></div>
      <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:0 12px">${def.fields.map(field).join('')}</div>
      <div class="field"><label>Send when a sensor changes to</label><div class="actions-row">${['Down', 'Warning', 'Unknown', 'Up'].map((s2) => `<label class="check" style="margin:0"><input type="checkbox" data-on="${s2}" ${x.on.includes(s2) ? 'checked' : ''} ${def.direction === 'incident' && s2 === 'Up' ? 'disabled checked' : ''}> ${s2 === 'Up' ? (def.direction === 'incident' ? 'Up (resolves the incident)' : 'Up (recovered)') : s2}</label>`).join('')}</div></div>
      <div class="field"><label>Which alarms</label><div class="actions-row"><label class="check" style="margin:0"><input type="radio" name="osc" value="all" ${scoped ? '' : 'checked'}> All alarms</label><label class="check" style="margin:0"><input type="radio" name="osc" value="some" ${scoped ? 'checked' : ''}> Only the groups, devices or sensors I pick</label></div></div>
      <div id="oscW" class="pick-grid" ${scoped ? '' : 'hidden'}>
        ${picker('groups', 'Device groups', tr.groups.filter((g) => g.id !== 'probe').map((g) => ({ id: g.id, name: g.name, sub: (g.devices || 0) + ' devices' })), x.groups)}
        ${picker('devices', 'Devices', tr.devices.map((d) => ({ id: d.id, name: d.name, sub: d.host || '' })), x.devices)}
        ${picker('sensors', 'Sensors', tr.sensors.map((s2) => ({ id: s2.id, name: s2.name, sub: devName(s2.device) })), x.sensors, { show: 40 })}
      </div>
      <div class="pick-grid">${picker('types', 'Only these sensor types (optional)', types.map((t) => ({ id: t.id, name: t.name, sub: t.category })), x.types, { show: 40 })}</div>
      <div class="field"><label for="oD">Wait before sending (minutes)</label><input class="input" id="oD" type="number" min="0" max="1440" value="${esc(x.delayMin || 0)}"><span class="hint">${def.direction === 'incident' ? 'Avoids tickets for short blips: no incident is opened if the sensor recovers during the wait.' : 'Nothing is sent if the sensor recovers during the wait.'}</span></div>
      <label class="check"><input type="checkbox" id="oE" ${x.enabled !== false ? 'checked' : ''}> On</label>
      <div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Save</button></div>`, (m, close) => {
      m.querySelector('.card').classList.add('wide');
      wirePickers(m);
      $$('input[name=osc]', m).forEach((r) => r.addEventListener('change', () => { $('#oscW', m).hidden = $('input[name=osc]:checked', m).value !== 'some'; }));
      $('#go', m).addEventListener('click', async () => {
        const some = $('input[name=osc]:checked', m).value === 'some';
        const fields = {}; $$('[data-of]', m).forEach((i) => (fields[i.dataset.of] = i.value.trim()));
        const secrets = {}; $$('[data-os]', m).forEach((i) => { if (i.value.trim()) secrets[i.dataset.os] = i.value.trim(); });
        const out = { id: x.id, kind: x.kind, name: $('#oN', m).value.trim() || def.name, enabled: $('#oE', m).checked, on: $$('[data-on]', m).filter((c) => c.checked).map((c) => c.dataset.on), delayMin: +$('#oD', m).value || 0, groups: some ? pickRead(m, 'groups') : [], devices: some ? pickRead(m, 'devices') : [], sensors: some ? pickRead(m, 'sensors') : [], types: pickRead(m, 'types'), fields, secrets };
        if (!out.on.filter((s2) => s2 !== 'Up').length) return errBox(m, new Error('Pick at least one alarm state.'));
        if (some && !out.groups.length && !out.devices.length && !out.sensors.length) return errBox(m, new Error('Pick at least one group, device or sensor, or choose All alarms.'));
        try { await api('setOutbound', out); close(); MC.toast('Saved ' + esc(out.name), 'ok'); done(); } catch (e) { errBox(m, e); }
      });
    });
  }

  V.connectors = {
    title: 'Sensor types',
    crumb: () => 'what MonCastle can monitor; every type runs directly from the probe, engine types can also come from an engine',
    async render(el) {
      el.innerHTML = '<div class="notice">Loading…</div>';
      try {
        const [list, tr] = await Promise.all([types(), tree()]);
        const use = {};
        for (const s of tr.sensors) { const u = (use[s.type] = use[s.type] || { n: 0, c: {} }); u.n++; u.c[s.state] = (u.c[s.state] || 0) + 1; if (s.ack && s.state === 'Down') u.c.Acknowledged = (u.c.Acknowledged || 0) + 1; }
        const cats = [...new Set(list.map((x) => x.category))];
        const nNative = list.filter((x) => x.source === 'native').length;
        el.innerHTML = `<div class="kpis">${MC.kpi('Sensor types', list.length, 'all run directly · ' + (list.length - nNative) + ' also by engines')}${MC.kpi('In use', Object.keys(use).length, 'types with at least one sensor')}${MC.kpi('Sensors', tr.sensors.length, 'across ' + tr.devices.length + ' devices')}${MC.kpi('Categories', cats.length, 'Windows, AD, network, virtualization…')}</div>
          <div class="notice">${icon('info', 'sev-ico')} <b>Every sensor type runs directly</b>: add it to any device and the MonCastle probe checks that device on the sensor's own schedule, no monitoring engine needed. Network and web types (ping, TCP port, HTTP, DNS, SSL certificate, SNMP, databases, PowerShell script) are checked by the console itself; Windows, Active Directory, DNS, DHCP, Hyper-V, VMware, SQL, printer and Linux types run their PowerShell script for that one device over WinRM or SSH. <b>Engines</b> are the automatic way: they discover servers and roles and create these sensors for everything they find.</div>
          ${cats.map((cat) => MC.panel(cat, list.filter((x) => x.category === cat).length + ' types', `<div class="conn-grid">${list.filter((x) => x.category === cat).map((x) => {
            const u = use[x.id];
            return `<div class="conn"><div class="top">${icon(x.source === 'native' ? 'activity' : 'play')}<b>${esc(x.name)}</b><span class="tag ${x.source}" style="margin-left:auto">${x.source === 'native' ? 'probe' : 'probe or engine'}</span></div><p>${esc(x.desc)}</p>${x.channels.length ? `<div class="chs">Channels: ${x.channels.map((c) => esc(c.name)).join(', ')}</div>` : ''}${x.script ? `<div class="chs">Engine <a href="#/engines">${esc(x.script)}</a> → dataset <span class="mono">${esc(x.dataset)}</span></div>` : `<div class="chs">Every ${x.interval} s by default</div>`}${u ? `<div style="display:flex;gap:8px;align-items:center"><span style="flex:1">${stack(u.c, { thin: true })}</span><a href="#/sensors?q=" class="muted" style="font-size:12px">${u.n} in use</a></div>` : '<div class="chs">Not in use yet</div>'}</div>`;
          }).join('')}</div>`)).join('')}`;
      } catch (e) { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; }
    },
  };

  // ================================================================== AUTO-DISCOVERY
  V.discovery = {
    title: 'Auto-discovery',
    crumb: () => 'find devices and add them with sensor templates',
    render(el) {
      const sel = new Set();
      const ui = { show: 'new', src: '', nets: null, custom: '', over: {} };
      el.innerHTML = '<div class="notice">Loading…</div>';
      let groupsList = S.GROUPS.map(([id, name]) => ({ id, name }));
      const kindName = (k) => (S.CLASSES.find((x) => x[0] === k) || [, k])[1];
      const draw = (d) => {
        const all = d.candidates || [];
        const sources = [...new Set(all.map((c) => c.source.replace(/^Print server .+/, 'Print servers')))];
        const list = all.filter((c) => (ui.show === 'all' || !c.monitored) && (!ui.src || c.source.replace(/^Print server .+/, 'Print servers') === ui.src));
        const scan = d.scan;
        if (!ui.nets) ui.nets = new Set((d.local || []).map((n) => n.cidr));
        el.innerHTML = `
          <div class="kpis">${MC.kpi('Found', all.length, 'from the engines and range scans')}${MC.kpi('Not monitored yet', all.filter((c) => !c.monitored).length, 'no probe sensors')}${MC.kpi('Sources', sources.length, esc(sources.join(' · ')))}${MC.kpi('Last range scan', scan ? (scan.state === 'running' ? Math.round((scan.done / scan.total) * 100) + '%' : scan.found.length + ' devices') : '–', scan ? esc(scan.range) + ' · ' + ago(scan.finished || scan.started) : 'none yet')}</div>
          <div class="grid g-1-2">
            ${MC.panel('Scan networks', 'TCP sweep of the common ports, reverse DNS and SNMP', `${admin() ? `<fieldset class="netpick"><legend>This machine's networks</legend>${(d.local || []).length ? d.local.map((n) => `<label class="chk"><input type="checkbox" data-net="${esc(n.cidr)}" ${ui.nets.has(n.cidr) ? 'checked' : ''}> <span class="mono">${esc(n.cidr)}</span> <span class="muted">${esc(n.iface)} · this server is ${esc(n.address)}${n.narrowed ? ' · network is /' + n.prefix + ', the /24 around this server is scanned' : ''}</span></label>`).join('') : '<p class="muted" style="margin:0">No IPv4 network found on this machine.</p>'}</fieldset>
              <div class="field"><label for="rg">Custom ranges <span class="muted">(optional)</span></label><input class="input mono" id="rg" placeholder="10.20.0.0/24, 192.168.5.10-80" value="${esc(ui.custom)}"><span class="hint">CIDR (/22 to /32), a range like 10.10.0.1-254 or single addresses, separated by commas; up to 4096 addresses in all. 30 ports that tell what a host is (Windows, domain controllers, Linux, printers, ESXi, databases, containers, cameras, VoIP), SNMP 161, the web server and certificate it shows, and the ping TTL.</span></div><button class="btn primary" id="go" ${scan && scan.state === 'running' ? 'disabled' : ''}>${scan && scan.state === 'running' ? 'Scanning… ' + scan.done + ' of ' + scan.total : 'Start scan'}</button>${scan && scan.state === 'failed' ? `<div class="notice err" style="margin-top:8px">${esc(scan.error)}</div>` : ''}` : '<p class="muted">Only administrators can scan networks.</p>'}`)}
            ${MC.panel('How templates work', '', `<p class="muted" style="margin:0;font-size:13px"><b>Type and group are detected</b> from what other engines know (Active Directory, inventories, Linux), the SNMP model and description, the web interface, the open ports, the name and the TTL; <i>Detected from</i> shows why, and you can change both before adding. Each device gets the default sensors for its type: <b>servers and workstations</b> ping, RDP and WinRM ports; <b>switches and firewalls</b> ping, SNMP uptime and interface traffic, HTTPS and certificate when open; <b>printers</b> ping and SNMP; <b>Linux</b> ping and SSH; <b>websites</b> HTTP and certificate. Engine sensors (WMI, AD, Hyper-V…) are added by the engines on their own. Change limits per sensor afterwards.</p>`)}
          </div>
          <section class="card panel-c"><div class="panel-h"><h3>Candidates</h3><span class="sub">${list.length} shown · ${sel.size} selected</span><div class="act"><select class="input" id="src" style="width:auto"><option value="">All sources</option>${sources.map((x) => `<option ${ui.src === x ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select><select class="input" id="show" style="width:auto"><option value="new" ${ui.show === 'new' ? 'selected' : ''}>Not monitored</option><option value="all" ${ui.show === 'all' ? 'selected' : ''}>All</option></select>${admin() ? `<button class="btn sm primary" id="add" ${sel.size ? '' : 'disabled'}>Add ${sel.size || ''} selected</button><button class="btn sm ghost" id="clr" ${scan && scan.state === 'running' ? 'disabled' : ''} title="Empty the list to start a new discovery">Clear results</button>` : ''}</div></div>${d.cleared ? `<p class="muted" style="font-size:12px;margin:0 0 8px">Results cleared ${ago(d.cleared)}. Engines add what they find again on their next run; start a scan above for a new range.</p>` : ''}<div id="cT"></div></section>`;
        MC.table($('#cT', el), list, [
          { key: 'pick', label: '', noCsv: true, html: (c) => (c.monitored ? '<span class="muted" title="Already monitored">✓</span>' : `<input type="checkbox" data-pick="${esc(c.name)}" ${sel.has(c.name) ? 'checked' : ''} aria-label="Select ${esc(c.name)}">`) },
          { key: 'name', label: 'Name', html: (c) => `<b>${esc(c.name)}</b>` },
          { key: 'host', label: 'Address', cls: 'mono' },
          { key: 'kind', label: 'Type', val: (c) => kindName((ui.over[c.name] || {}).kind || c.kind), html: (c) => (c.monitored ? esc(kindName(c.kind)) : `<select class="input" data-ck="${esc(c.name)}" style="width:190px;padding:4px 8px" aria-label="Type of ${esc(c.name)}">${S.CLASSES.map(([k, l]) => `<option value="${k}" ${k === ((ui.over[c.name] || {}).kind || c.kind) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`) },
          { key: 'group', label: 'Group', val: (c) => (groupsList.find((g) => g.id === ((ui.over[c.name] || {}).group || c.group)) || {}).name || c.group, html: (c) => (c.monitored ? esc((groupsList.find((g) => g.id === c.group) || {}).name || c.group || '') : `<select class="input" data-cg="${esc(c.name)}" style="width:170px;padding:4px 8px" aria-label="Group of ${esc(c.name)}">${groupsList.slice().sort((a, b) => a.name.localeCompare(b.name)).map((g) => `<option value="${esc(g.id)}" ${g.id === ((ui.over[c.name] || {}).group || c.group) ? 'selected' : ''}>${esc(g.name)}</option>`).join('')}</select>`) },
          { key: 'why', label: 'Detected from', html: (c) => (c.why ? `${pill(c.confidence === 'high' ? 'OK' : c.confidence === 'medium' ? 'Info' : 'Unknown', c.confidence || 'low')} <span style="font-size:12px">${esc(c.why)}</span>` : `<span class="muted" style="font-size:12px">${esc(c.source)}</span>`), val: (c) => c.confidence || '' },
          { key: 'source', label: 'Found by' },
          { key: 'detail', label: 'Detail', html: (c) => `<span style="font-size:12.5px">${esc(c.detail || '')}</span>` },
          { key: 'monitored', label: 'Monitored', html: (c) => (c.monitored ? pill('Up', 'yes') : pill('Unknown', 'no')) },
        ], { sort: 'source', dir: 1, name: 'discovery', limit: 100, empty: 'Nothing found yet. Run a range scan, or let the network discovery and AD engines report.', after: (w) => { $$('[data-ck]', w).forEach((b) => b.addEventListener('change', () => { const o = (ui.over[b.dataset.ck] = ui.over[b.dataset.ck] || {}); o.kind = b.value; const g = S.KIND_GROUP[b.value]; const gs = $(`[data-cg="${CSS.escape(b.dataset.ck)}"]`, w); if (g && gs && !o.groupSet) { o.group = g; gs.value = g; } })); $$('[data-cg]', w).forEach((b) => b.addEventListener('change', () => { const o = (ui.over[b.dataset.cg] = ui.over[b.dataset.cg] || {}); o.group = b.value; o.groupSet = true; })); $$('[data-pick]', w).forEach((b) => b.addEventListener('change', () => { if (b.checked) sel.add(b.dataset.pick); else sel.delete(b.dataset.pick); const a = $('#add', el); if (a) { a.disabled = !sel.size; a.textContent = 'Add ' + (sel.size || '') + ' selected'; } $('.panel-h .sub', $('#cT', el).closest('section')).textContent = list.length + ' shown · ' + sel.size + ' selected'; })); } });
        $('#src', el).addEventListener('change', (e) => { ui.src = e.target.value; draw(d); });
        $('#show', el).addEventListener('change', (e) => { ui.show = e.target.value; draw(d); });
        $$('[data-net]', el).forEach((b) => b.addEventListener('change', () => { if (b.checked) ui.nets.add(b.dataset.net); else ui.nets.delete(b.dataset.net); }));
        if ($('#rg', el)) $('#rg', el).addEventListener('input', (e) => { ui.custom = e.target.value; });
        if ($('#go', el)) $('#go', el).addEventListener('click', async () => {
          const range = [...ui.nets].concat(ui.custom.split(/[,;\s]+/).filter(Boolean)).join(', ');
          if (!range) return MC.toast('Tick one of this machine\'s networks or enter a custom range.', 'err');
          try { await api('scan', { range }); MC.toast('Scan started', 'ok'); poll(); } catch (e) { MC.toast(esc(e.message), 'err'); }
        });
        if ($('#clr', el)) $('#clr', el).addEventListener('click', () => modal(`<h3>Clear the discovery results?</h3><p class="muted">The candidate list and the last range scan are emptied so you can start a new discovery. Devices you already added stay monitored. Engines (network discovery, Active Directory, print servers) list what they find again after their next run.</p><div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn danger" id="go2">Clear results</button></div>`, (m, close) => {
          $('#go2', m).addEventListener('click', async () => { try { await api('clearDiscovery', {}); sel.clear(); close(); MC.toast('Discovery results cleared', 'ok'); load(); } catch (e) { errBox(m, e); } });
        }));
        if ($('#add', el)) $('#add', el).addEventListener('click', async () => {
          // the type and group chosen in the list win over what discovery detected
          const items = all.filter((c) => sel.has(c.name)).map((c) => { const o = ui.over[c.name] || {}; return Object.assign({}, c, o.kind ? { kind: o.kind, profile: o.kind === c.kind ? c.profile : null } : {}, o.group ? { group: o.group } : {}); });
          try { const r = await api('applyDiscovery', { items }); sel.clear(); MC.toast('Added ' + r.added.length + ' devices with their default sensors', 'ok'); await tree(true); load(); } catch (e) { MC.toast(esc(e.message), 'err'); }
        });
      };
      const load = () => Promise.all([api('discovery'), tree().catch(() => null)]).then(([d, t]) => { if (t && t.groups) groupsList = t.groups.map((g) => ({ id: g.id, name: g.name })); draw(d); }).catch((e) => { el.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
      const poll = () => { clearInterval(V._scanPoll); const seq = MC.renderSeq; V._scanPoll = setInterval(async () => { if (!document.body.contains(el) || MC.renderSeq !== seq) return clearInterval(V._scanPoll); const d = await api('discovery'); if (MC.renderSeq !== seq) return clearInterval(V._scanPoll); if (![$('input[type=search]', el), $('#rg', el)].includes(document.activeElement)) draw(d); if (!d.scan || d.scan.state !== 'running') clearInterval(V._scanPoll); }, 1500); };
      load().then(() => poll());
    },
  };

  // ================================================================== NOTIFICATIONS
  // rules pick alarms (all, or any of chosen groups, devices and sensors, optionally only some sensor types) and send
  // them to console users, user groups, e-mail addresses, Teams, Slack or a webhook, with the RoboMate e-mail template
  // or one of the console's own templates
  const ML = () => root.MCMail;
  V.notifications = {
    title: 'Notifications',
    crumb: () => 'who hears about which alarms: users, user groups, e-mail, Teams, Slack or webhook, with your own e-mail templates',
    render(el, route) {
      const tab = route.tab || 'rules';
      el.innerHTML = MC.tabs('notifications', [['rules', 'Rules'], ['templates', 'E-mail templates'], ['email', 'E-mail server'], ['sent', 'Sent']], tab) + '<div id="nTab" class="grid"><div class="notice">Loading…</div></div>';
      const t = $('#nTab', el);
      Promise.all([api('notifications'), tree(), admin() ? MC.api.users().catch(() => []) : Promise.resolve([]), admin() ? MC.api.userGroups().then((x) => x.groups).catch(() => []) : Promise.resolve([]), api('types').catch(() => [])])
        .then(([n, tr, users, ugroups, types]) => {
          const ctx = { n, tr, users, ugroups, types, reload: () => V.notifications.render(el, route) };
          ({ rules: rulesTab, templates: templatesTab, email: smtpTab, sent: sentTab }[tab] || rulesTab)(t, ctx);
        })
        .catch((e) => { t.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
    },
  };
  const tplName = (n, id) => (id === 'default' ? 'RoboMate default' : ((n.templates || []).find((x) => x.id === id) || {}).name || null);
  const ruleScope = (r, tr, types) => {
    const g = (r.groups || []).map((id) => (tr.groups.find((x) => x.id === id) || {}).name || id), d = (r.devices || []).map((id) => (tr.devices.find((x) => x.id === id) || {}).name || id), sn = (r.sensors || []).map((id) => (tr.sensors.find((x) => x.id === id) || {}).name || id);
    const parts = [];
    if (g.length) parts.push((g.length > 1 ? 'groups ' : 'group ') + g.join(', '));
    if (d.length) parts.push((d.length > 1 ? 'devices ' : 'device ') + d.join(', '));
    if (sn.length) parts.push(sn.length + ' sensor' + (sn.length > 1 ? 's' : ''));
    let out = parts.length ? parts.join(' + ') : 'every alarm';
    if ((r.types || []).length) out += ' · only ' + r.types.map((id) => (types.find((x) => x.id === id) || {}).name || id).join(', ');
    return out;
  };
  const tgtHtml = (t, ctx) => {
    if (t.kind === 'user') { const u = ctx.users.find((x) => x.name === t.name); return icon('users', 'sev-ico') + ' ' + esc(t.name) + (u ? (u.email ? ' <span class="muted">' + esc(u.email) + '</span>' : ' <span style="color:var(--crit-ink)">no e-mail address</span>') : ''); }
    if (t.kind === 'usergroup') { const g = ctx.ugroups.find((x) => x.id === t.id); const mails = g ? g.members.filter((m) => (ctx.users.find((u) => u.name === m) || {}).email).length : 0; return icon('users', 'sev-ico') + ' User group ' + esc(g ? g.name : t.id) + (g ? ` <span class="muted">${g.members.length} member${g.members.length === 1 ? '' : 's'}, ${mails} with e-mail</span>` : ''); }
    if (t.kind === 'email') return icon('send', 'sev-ico') + ' ' + esc(t.to);
    return icon('cloud', 'sev-ico') + ' ' + esc({ teams: 'Teams', slack: 'Slack', json: 'Webhook' }[t.format] || 'Webhook') + ' <span class="mono muted">' + esc(t.url.replace(/(\/\/[^/]+\/).+/, '$1…')) + '</span>';
  };
  const saveN = async (body, ctx, msg) => { try { await api('setNotifications', body); MC.toast(msg || 'Saved', 'ok'); ctx.reload(); } catch (e) { MC.toast(esc(e.message), 'err'); } };

  function rulesTab(el, ctx) {
    const { n, tr, types } = ctx, rules = n.rules || [];
    const failed = (n.sent || []).filter((x) => /^failed/.test(x.result)).length;
    el.innerHTML = `
      <div class="kpis">${MC.kpi('Rules', rules.length, rules.filter((r) => r.enabled).length + ' enabled')}${MC.kpi('E-mail', n.smtp && n.smtp.host ? 'set up' : 'not set', n.smtp && n.smtp.host ? esc(n.smtp.host + ':' + n.smtp.port) : 'add an SMTP server')}${MC.kpi('Templates', (n.templates || []).length + 1, 'default: ' + esc(tplName(n, n.defaultTemplate) || 'RoboMate'))}${MC.kpi('Sent', (n.sent || []).length, 'since the console started')}${MC.kpi('Failed', failed, 'see Sent', { alert: failed > 0 })}</div>
      ${MC.panel('Rules', 'every enabled rule whose states and alarms match a change sends to all its recipients; a wait is cancelled if the sensor recovers', `<div style="display:grid;gap:8px">${rules.map((r, i) => `<div class="rule"><div class="top"><b>${esc(r.name)}</b>${r.enabled ? pill('Up', 'enabled') : pill('Paused', 'off')}<span class="muted" style="font-size:12.5px">on ${r.on.map((x) => esc(x)).join(', ') || 'nothing'} · ${esc(ruleScope(r, tr, types))}${r.delayMin ? ' · after ' + r.delayMin + ' min' : ' · at once'} · template ${esc(tplName(n, r.template) || 'console default')}</span>${admin() ? `<span style="margin-left:auto" class="actions-row"><button class="btn sm" data-edit="${i}">Edit</button><button class="btn sm ghost" data-del="${i}">Delete</button></span>` : ''}</div><div style="font-size:12.5px;display:grid;gap:3px">${r.targets.map((x) => '<div>' + tgtHtml(x, ctx) + '</div>').join('') || '<span class="muted">No recipients</span>'}</div></div>`).join('') || '<div class="empty">No rules yet. Add one so the team hears about outages.</div>'}</div>${admin() ? '<div style="margin-top:10px"><button class="btn primary sm" id="addR">Add rule</button></div>' : ''}`)}
      ${MC.panel('Recipients', 'users receive e-mail at the address on their account (Administrate > Users & permissions); a user group reaches every member with an address', `<div class="optgrid">${ctx.ugroups.map((g) => `<div><b>${esc(g.name)}</b> <span class="muted" style="font-size:12.5px">${g.members.map((m) => { const u = ctx.users.find((x) => x.name === m) || {}; return esc(m) + (u.email ? '' : ' (no e-mail)'); }).join(', ') || 'no members'}</span></div>`).join('') || '<span class="muted">No user groups yet.</span>'}</div>`)}`;
    const save = (list) => saveN({ rules: list }, ctx, 'Rules saved');
    if ($('#addR', el)) $('#addR', el).addEventListener('click', () => ruleDialog({ name: '', enabled: true, on: ['Down'], delayMin: 0, groups: [], devices: [], sensors: [], types: [], template: null, targets: [] }, ctx, (r) => save(rules.concat([r]))));
    $$('[data-edit]', el).forEach((b) => b.addEventListener('click', () => ruleDialog(rules[+b.dataset.edit], ctx, (r) => save(rules.map((x, i) => (i === +b.dataset.edit ? Object.assign(r, { id: x.id }) : x))))));
    $$('[data-del]', el).forEach((b) => b.addEventListener('click', () => save(rules.filter((x, i) => i !== +b.dataset.del))));
  }

  // a searchable list of checkboxes; returns html, read with pickRead(m, name)
  function picker(name, label, items, chosen, opt) {
    opt = opt || {};
    const on = new Set(chosen || []);
    const sorted = items.slice().sort((a, b) => (on.has(b.id) - on.has(a.id)) || String(a.name).localeCompare(String(b.name)));
    return `<fieldset class="pick" data-pick="${name}"><legend>${esc(label)} <span class="muted" data-pc>${on.size ? on.size + ' chosen' : ''}</span></legend>${items.length > 8 ? `<input class="input sm" type="search" data-pf placeholder="Filter ${esc(label.toLowerCase())}" aria-label="Filter ${esc(label)}">` : ''}<div class="pick-list">${sorted.map((x, i) => `<label class="check" data-pn="${esc(String(x.name + ' ' + (x.sub || '')).toLowerCase())}" ${i >= (opt.show || 60) && !on.has(x.id) ? 'hidden' : ''}><input type="checkbox" value="${esc(x.id)}" ${on.has(x.id) ? 'checked' : ''}> <span>${esc(x.name)}${x.sub ? ` <span class="muted" style="font-size:12px">${esc(x.sub)}</span>` : ''}</span></label>`).join('') || '<span class="muted">None</span>'}</div></fieldset>`;
  }
  function wirePickers(m) {
    $$('[data-pick]', m).forEach((f) => {
      const q = $('[data-pf]', f), cnt = $('[data-pc]', f);
      const count = () => { const k = $$('input[type=checkbox]:checked', f).length; cnt.textContent = k ? k + ' chosen' : ''; };
      f.addEventListener('change', count);
      if (q) q.addEventListener('input', () => { const v = q.value.trim().toLowerCase(); let shown = 0; $$('[data-pn]', f).forEach((l) => { const hit = $('input', l).checked || (v ? l.dataset.pn.includes(v) : true); l.hidden = !hit || (!$('input', l).checked && ++shown > 60); }); });
    });
  }
  const pickRead = (m, name) => $$(`[data-pick="${name}"] input[type=checkbox]:checked`, m).map((c) => c.value);

  function ruleDialog(r, ctx, done) {
    const { tr, n, users, ugroups, types } = ctx;
    const KINDS = [['user', 'User'], ['usergroup', 'User group'], ['email', 'E-mail address'], ['teams', 'Microsoft Teams'], ['slack', 'Slack'], ['json', 'Webhook (JSON)']];
    const kindOf = (t) => (t.kind === 'webhook' ? t.format || 'json' : t.kind);
    const valField = (k, t) => (k === 'user' ? `<select class="input" data-tv style="flex:1;min-width:0">${users.map((u) => `<option value="${esc(u.name)}" ${t.name === u.name ? 'selected' : ''}>${esc(u.name)}${u.email ? ' · ' + esc(u.email) : ' · no e-mail address'}</option>`).join('')}</select>`
      : k === 'usergroup' ? `<select class="input" data-tv style="flex:1;min-width:0">${ugroups.map((g) => `<option value="${esc(g.id)}" ${t.id === g.id ? 'selected' : ''}>${esc(g.name)} (${g.members.length})</option>`).join('')}</select>`
        : `<input class="input mono" data-tv value="${esc(t.to || t.url || '')}" placeholder="${k === 'email' ? 'team@company.com; oncall@company.com' : 'https://…'}" style="flex:1;min-width:0">`);
    const tgtRow = (t) => { const k = kindOf(t); return `<div class="actions-row tgtrow" data-t style="flex-wrap:nowrap;margin-bottom:6px"><select class="input" data-tk style="width:auto" aria-label="Recipient type">${KINDS.map(([id, l]) => `<option value="${id}" ${k === id ? 'selected' : ''}>${l}</option>`).join('')}</select><span data-tvw style="display:flex;flex:1;min-width:0">${valField(k, t)}</span><button class="btn sm ghost" data-tt title="Send a test">Test</button><button class="btn sm ghost" data-tr aria-label="Remove recipient">${icon('x', 'sev-ico')}</button></div>`; };
    const scoped = (r.groups || []).length + (r.devices || []).length + (r.sensors || []).length > 0;
    const devName = (id) => (tr.devices.find((d) => d.id === id) || {}).name || id;
    modal(`<h3>${r.name ? 'Edit rule' : 'Add a notification rule'}</h3>
      <div class="field"><label for="rn">Name</label><input class="input" id="rn" value="${esc(r.name)}" placeholder="Service desk: anything down"></div>
      <div class="field"><label>When a sensor changes to</label><div class="actions-row">${['Down', 'Warning', 'Unknown', 'Up'].map((x) => `<label class="check" style="margin:0"><input type="checkbox" data-on="${x}" ${r.on.includes(x) ? 'checked' : ''}> ${x === 'Up' ? 'Up (recovered)' : x}</label>`).join('')}</div></div>
      <div class="field"><label>Which alarms</label><div class="actions-row"><label class="check" style="margin:0"><input type="radio" name="sc" value="all" ${scoped ? '' : 'checked'}> All alarms</label><label class="check" style="margin:0"><input type="radio" name="sc" value="some" ${scoped ? 'checked' : ''}> Only alarms from the groups, devices or sensors I pick</label></div></div>
      <div id="scW" class="pick-grid" ${scoped ? '' : 'hidden'}>
        ${picker('groups', 'Device groups', tr.groups.filter((g) => g.id !== 'probe').map((g) => ({ id: g.id, name: g.name, sub: (g.devices || 0) + ' devices' })), r.groups)}
        ${picker('devices', 'Devices', tr.devices.map((d) => ({ id: d.id, name: d.name, sub: d.host || '' })), r.devices)}
        ${picker('sensors', 'Sensors', tr.sensors.map((x) => ({ id: x.id, name: x.name, sub: devName(x.device) })), r.sensors, { show: 40 })}
      </div>
      <div class="pick-grid">${picker('types', 'Only these sensor types (optional)', types.map((x) => ({ id: x.id, name: x.name, sub: x.category })), r.types, { show: 40 })}</div>
      <div class="field"><label for="rd">Wait before sending (minutes)</label><input class="input" id="rd" type="number" min="0" max="1440" value="${esc(r.delayMin || 0)}"><span class="hint">If the sensor recovers during the wait, nothing is sent. Recoveries are sent at once.</span></div>
      <div class="field"><label>Send to</label><div id="tg">${r.targets.map(tgtRow).join('')}</div><div class="actions-row"><button class="btn sm" id="addT">Add recipient</button><span class="hint">Users and user groups get e-mail at the address on their account.</span></div></div>
      <div class="field"><label for="rt">E-mail template</label><select class="input" id="rt"><option value="">Console default (${esc(tplName(n, n.defaultTemplate) || 'RoboMate default')})</option><option value="default" ${r.template === 'default' ? 'selected' : ''}>RoboMate default</option>${(n.templates || []).map((x) => `<option value="${esc(x.id)}" ${r.template === x.id ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select><span class="hint"><a href="#/notifications/templates">Manage templates</a></span></div>
      <label class="check"><input type="checkbox" id="re" ${r.enabled !== false ? 'checked' : ''}> Rule enabled</label>
      <div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Save rule</button></div>`, (m, close) => {
      m.querySelector('.card').classList.add('wide');
      wirePickers(m);
      $$('input[name=sc]', m).forEach((x) => x.addEventListener('change', () => { $('#scW', m).hidden = $('input[name=sc]:checked', m).value !== 'some'; }));
      const readT = (row) => { const k = $('[data-tk]', row).value, v = $('[data-tv]', row).value.trim(); return k === 'user' ? { kind: 'user', name: v } : k === 'usergroup' ? { kind: 'usergroup', id: v } : k === 'email' ? { kind: 'email', to: v } : { kind: 'webhook', url: v, format: k }; };
      const wire = () => {
        $$('[data-tr]', m).forEach((b) => (b.onclick = () => b.closest('[data-t]').remove()));
        $$('[data-tk]', m).forEach((s2) => (s2.onchange = () => { $('[data-tvw]', s2.closest('[data-t]')).innerHTML = valField(s2.value, {}); }));
        $$('[data-tt]', m).forEach((b) => (b.onclick = async () => { try { const x = await api('testNotification', { target: readT(b.closest('[data-t]')), template: $('#rt', m).value || undefined }); MC.toast(x.demo ? 'Test recorded (demo mode sends nothing)' : 'Test sent', 'ok'); } catch (e) { errBox(m, e); } }));
      };
      $('#addT', m).addEventListener('click', () => { $('#tg', m).insertAdjacentHTML('beforeend', tgtRow({ kind: ugroups.length ? 'usergroup' : 'email' })); wire(); });
      wire();
      $('#go', m).addEventListener('click', () => {
        const some = $('input[name=sc]:checked', m).value === 'some';
        const out = { name: $('#rn', m).value.trim() || 'Rule', enabled: $('#re', m).checked, on: $$('[data-on]', m).filter((c) => c.checked).map((c) => c.dataset.on), delayMin: +$('#rd', m).value || 0,
          groups: some ? pickRead(m, 'groups') : [], devices: some ? pickRead(m, 'devices') : [], sensors: some ? pickRead(m, 'sensors') : [], types: pickRead(m, 'types'), template: $('#rt', m).value || null,
          targets: $$('[data-t]', m).map(readT).filter((t) => t.to || t.url || t.name || t.id) };
        if (!out.on.length) return errBox(m, new Error('Pick at least one state.'));
        if (some && !out.groups.length && !out.devices.length && !out.sensors.length) return errBox(m, new Error('Pick at least one group, device or sensor, or choose All alarms.'));
        if (!out.targets.length) return errBox(m, new Error('Add at least one recipient.'));
        const badT = out.targets.find((t) => (t.kind === 'email' ? !/^\s*[^\s@<>;,]+@[^\s@<>;,]+(\s*[;,]\s*[^\s@<>;,]+@[^\s@<>;,]+)*\s*$/.test(t.to) : t.kind === 'webhook' ? !/^https?:\/\//.test(t.url) : false));
        if (badT) return errBox(m, new Error((badT.to || badT.url) + ' is not a valid ' + (badT.kind === 'email' ? 'e-mail address' : 'URL')));
        close(); done(out);
      });
    });
  }

  // ---- e-mail templates: the RoboMate default, the console's own, and which one is the default for all alarm types
  function mailPreview(frame, tpl, state) {
    const e = Object.assign({}, ML().SAMPLE, { t: new Date().toISOString(), to: state || 'Down', from: state === 'Up' ? 'Down' : 'Up', message: state === 'Up' ? 'Free space 18.4%' : state === 'Warning' ? 'Free space 8.9% (below the 10% warning)' : ML().SAMPLE.message });
    const r = ML().render(e, { rule: 'File servers: disk space', link: location.origin + '/#/sensor/s%3Ademo', console: 'MONCASTLE01' }, tpl);
    frame.srcdoc = r.html; // sandboxed: no scripts, no same-origin access
    return r;
  }
  function templatesTab(el, ctx) {
    const { n } = ctx, list = n.templates || [];
    const card = (id, name, subject, isDefault, builtIn) => `<div class="card tplcard"><div class="top"><b>${esc(name)}</b>${isDefault ? pill('Up', 'default for all alarms') : ''}${builtIn ? '<span class="tag">built in</span>' : ''}</div><div class="mono muted" style="font-size:12px">${esc(subject)}</div><iframe class="tplprev" sandbox="" title="Preview of ${esc(name)}" data-prev="${esc(id)}"></iframe>
      <div class="actions-row"><button class="btn sm" data-view="${esc(id)}">Preview</button>${admin() ? `${isDefault ? '' : `<button class="btn sm ghost" data-def="${esc(id)}">Make default</button>`}${builtIn ? `<button class="btn sm ghost" data-copy="default">Copy to edit</button>` : `<button class="btn sm ghost" data-ed="${esc(id)}">Edit</button><button class="btn sm ghost" data-rm="${esc(id)}">Delete</button>`}` : ''}</div></div>`;
    el.innerHTML = `
      <div class="notice">Every e-mail from a rule uses the rule's template, else the console default below. The RoboMate default works for every alarm type (Down, Warning, Unknown, recovered and tests) and every mail client, with a plain-text copy for clients that do not show HTML.</div>
      ${MC.panel('Templates', 'placeholders like {{device}} are filled in when an e-mail is sent; values are escaped, so alarm text cannot change your HTML', `<div class="tplgrid">${card('default', 'RoboMate default', ML().DEFAULT_SUBJECT, !n.defaultTemplate, true)}${list.map((x) => card(x.id, x.name, x.subject, n.defaultTemplate === x.id, false)).join('')}</div>${admin() ? '<div style="margin-top:10px"><button class="btn primary sm" id="newT">New template</button></div>' : ''}`)}
      ${MC.panel('Placeholders', '', `<div class="optgrid">${ML().PLACEHOLDERS.map(([k, d]) => `<div><span class="mono">{{${k}}}</span> <span class="muted" style="font-size:12.5px">${esc(d)}</span></div>`).join('')}</div>`)}`;
    const byId = (id) => (id === 'default' ? null : list.find((x) => x.id === id));
    $$('[data-prev]', el).forEach((f) => mailPreview(f, byId(f.dataset.prev), 'Down'));
    $$('[data-view]', el).forEach((b) => b.addEventListener('click', () => previewDialog(byId(b.dataset.view), b.closest('.tplcard').querySelector('b').textContent)));
    $$('[data-def]', el).forEach((b) => b.addEventListener('click', () => saveN({ defaultTemplate: b.dataset.def === 'default' ? null : b.dataset.def }, ctx, 'Default template changed')));
    $$('[data-rm]', el).forEach((b) => b.addEventListener('click', () => saveN({ templates: list.filter((x) => x.id !== b.dataset.rm) }, ctx, 'Template deleted; rules that used it now use the default')));
    const edit = (t) => templateDialog(t, (out) => saveN({ templates: t && t.id ? list.map((x) => (x.id === t.id ? Object.assign(out, { id: t.id }) : x)) : list.concat([out]) }, ctx, 'Template saved'));
    $$('[data-ed]', el).forEach((b) => b.addEventListener('click', () => edit(byId(b.dataset.ed))));
    $$('[data-copy]', el).forEach((b) => b.addEventListener('click', () => edit({ name: 'My template', subject: ML().DEFAULT_SUBJECT, html: ML().STARTER })));
    if ($('#newT', el)) $('#newT', el).addEventListener('click', () => edit({ name: '', subject: ML().DEFAULT_SUBJECT, html: ML().STARTER }));
  }
  function previewDialog(tpl, name) {
    modal(`<h3>${esc(name)}</h3><div class="actions-row" style="margin-bottom:8px">${['Down', 'Warning', 'Unknown', 'Up'].map((x, i) => `<button class="btn sm ${i ? 'ghost' : ''}" data-st="${x}">${x === 'Up' ? 'Recovered' : x}</button>`).join('')}<span class="muted" data-subj style="font-size:12.5px"></span></div><iframe class="tplprev big" sandbox="" title="E-mail preview"></iframe><div class="foot"><button class="btn" data-x>Close</button></div>`, (m) => {
      m.querySelector('.card').classList.add('wide');
      const f = $('iframe', m);
      const show = (st) => { const r = mailPreview(f, tpl, st); $('[data-subj]', m).textContent = 'Subject: ' + r.subject; $$('[data-st]', m).forEach((b) => b.classList.toggle('ghost', b.dataset.st !== st)); };
      $$('[data-st]', m).forEach((b) => b.addEventListener('click', () => show(b.dataset.st)));
      show('Down');
    });
  }
  function templateDialog(t, done) {
    modal(`<h3>${t && t.id ? 'Edit template' : 'New e-mail template'}</h3>
      <div class="tpledit"><div>
        <div class="field"><label for="tn">Name</label><input class="input" id="tn" value="${esc(t.name || '')}" placeholder="On-call short card"></div>
        <div class="field"><label for="ts">Subject</label><input class="input mono" id="ts" value="${esc(t.subject || '')}"></div>
        <div class="field"><label for="th">HTML body</label><textarea class="input mono" id="th" rows="16" spellcheck="false">${esc(t.html || '')}</textarea><span class="hint">Use inline styles; mail clients drop style sheets and scripts. ${ML().PLACEHOLDERS.slice(0, 7).map(([k]) => '{{' + k + '}}').join(' ')} …</span></div>
      </div><div><div class="actions-row" style="margin-bottom:6px">${['Down', 'Warning', 'Up'].map((x, i) => `<button class="btn sm ${i ? 'ghost' : ''}" data-st="${x}">${x === 'Up' ? 'Recovered' : x}</button>`).join('')}</div><div class="muted mono" data-subj style="font-size:12px;margin-bottom:6px"></div><iframe class="tplprev big" sandbox="" title="Live preview"></iframe></div></div>
      <div data-err></div><div class="foot"><button class="btn" data-x>Cancel</button><button class="btn primary" id="go">Save template</button></div>`, (m, close) => {
      m.querySelector('.card').classList.add('wide');
      let st = 'Down';
      const read = () => ({ name: $('#tn', m).value.trim() || 'Template', subject: $('#ts', m).value.trim(), html: $('#th', m).value });
      const show = () => { const r = mailPreview($('iframe', m), read(), st); $('[data-subj]', m).textContent = 'Subject: ' + r.subject; };
      let tm; ['#ts', '#th'].forEach((q) => $(q, m).addEventListener('input', () => { clearTimeout(tm); tm = setTimeout(show, 250); }));
      $$('[data-st]', m).forEach((b) => b.addEventListener('click', () => { st = b.dataset.st; $$('[data-st]', m).forEach((x) => x.classList.toggle('ghost', x !== b)); show(); }));
      show();
      $('#go', m).addEventListener('click', () => { const out = read(); if (!out.html.trim()) return errBox(m, new Error('The template needs an HTML body.')); if (!out.subject) return errBox(m, new Error('Give the template a subject.')); close(); done(out); });
    });
  }

  function smtpTab(el, ctx) {
    const { n } = ctx, sm = n.smtp || {};
    el.innerHTML = MC.panel('E-mail server (SMTP)', 'used by every e-mail recipient; the password is stored encrypted on the console and never shown', admin() ? `
      <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px">
        <div class="field"><label for="sh">Server</label><input class="input mono" id="sh" value="${esc(sm.host || '')}" placeholder="smtp.office365.com"></div>
        <div class="field"><label for="sp">Port</label><input class="input" id="sp" type="number" value="${esc(sm.port || 587)}"></div>
        <div class="field"><label for="su">User</label><input class="input" id="su" value="${esc(sm.user || '')}" autocomplete="off"></div>
        <div class="field"><label for="spw">Password</label><input class="input" id="spw" type="password" autocomplete="new-password" placeholder="${sm.passwordSet ? 'saved; type to replace' : 'not set'}"></div>
        <div class="field"><label for="sf">From</label><input class="input" id="sf" value="${esc(sm.from || '')}" placeholder="MonCastle &lt;moncastle@company.com&gt;"></div>
        <div class="field"><label for="ss">Security</label><select class="input" id="ss">${[['auto', 'Auto (recommended)'], ['starttls', 'STARTTLS (port 587 or 25)'], ['tls', 'SSL/TLS (port 465)'], ['none', 'None (internal relay only)']].map(([v, l]) => `<option value="${v}"${(sm.security || (sm.secure && +sm.port === 465 ? 'tls' : 'auto')) === v ? ' selected' : ''}>${l}</option>`).join('')}</select></div>
      </div>
      <p class="muted" style="font-size:12.5px;margin:6px 0 0">Auto uses SSL/TLS on port 465 and STARTTLS on other ports, and tries the other one if the server answers differently. The server certificate is always checked.</p>
      <div class="actions-row" style="margin-top:10px"><button class="btn primary sm" id="saveS">Save</button><input class="input" id="tt" placeholder="test@company.com" style="max-width:240px" aria-label="Test address"><button class="btn sm" id="testS">Send test e-mail</button></div>
      <p class="muted" style="font-size:12.5px;margin-top:10px">E-mails go out as HTML with a plain-text copy, using the console default template.</p>` : `<p class="muted">${esc(sm.host || 'Not set')}</p>`);
    const saveSmtp = () => api('setNotifications', { smtp: { host: $('#sh', el).value, port: +$('#sp', el).value, user: $('#su', el).value, password: $('#spw', el).value, from: $('#sf', el).value, security: $('#ss', el).value } }).then((r) => { $('#spw', el).value = ''; return r; });
    if ($('#saveS', el)) $('#saveS', el).addEventListener('click', async () => {
      try { await saveSmtp(); MC.toast('E-mail settings saved', 'ok'); ctx.reload(); } catch (e) { MC.toast(esc(e.message), 'err'); }
    });
    // the test uses what is in the form: it saves first, so a corrected port or security setting is what gets tested
    if ($('#testS', el)) $('#testS', el).addEventListener('click', async (ev) => {
      const b = ev.currentTarget; b.disabled = true; b.textContent = 'Sending…';
      try { await saveSmtp(); const r = await api('testNotification', { target: { kind: 'email', to: $('#tt', el).value } }); MC.toast(r.demo ? 'Settings saved. Test recorded (demo mode sends nothing)' : 'Settings saved. Test e-mail sent', 'ok'); } catch (e) { MC.toast(esc(e.message), 'err', 12000); } finally { b.disabled = false; b.textContent = 'Send test e-mail'; }
    });
  }
  function sentTab(el, ctx) {
    el.innerHTML = MC.panel('Sent notifications', 'latest first', '<div id="nT"></div>');
    MC.table($('#nT', el), ctx.n.sent || [], [
      { key: 't', label: 'Time', html: (x) => dt(x.t) },
      { key: 'rule', label: 'Rule' },
      { key: 'state', label: 'State', html: (x) => pill(x.state, x.state) },
      { key: 'device', label: 'Device' },
      { key: 'sensor', label: 'Sensor' },
      { key: 'target', label: 'Recipient', cls: 'mono' },
      { key: 'result', label: 'Result', html: (x) => (/^failed/.test(x.result) ? `<span style="color:var(--crit-ink)">${esc(x.result)}</span>` : esc(x.result)) },
    ], { name: 'notifications', limit: 50, empty: 'Nothing sent yet.' });
  }
})(typeof self !== 'undefined' ? self : this);
