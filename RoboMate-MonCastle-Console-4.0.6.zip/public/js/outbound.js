/*
 * RoboMate MonCastle - where alarms go out to. Shared by the browser (window.MCOutbound: forms, requirements, steps)
 * and the server (what is sent). Three directions:
 *   ingress   other tools send their alerts into MonCastle (alertsources.js, Configure > Alert integrations > Ingress)
 *   egress    MonCastle streams its alarms out as events: webhook, Teams, Slack, Splunk, syslog
 *   incident  MonCastle opens a ticket when a sensor goes Down and resolves it when the sensor is Up again:
 *             ServiceNow, Jira Service Management, PagerDuty, Opsgenie
 * Secret fields (tokens, passwords, webhook addresses that carry their own key) are stored only on the console server,
 * encrypted, and never sent back to a browser. build() returns the HTTP request; the server sends it.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCOutbound = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const DIRECTIONS = [
    { id: 'ingress', name: 'Ingress: alerts into MonCastle', short: 'Ingress', icon: 'download',
      what: 'Other monitoring tools send their alerts to MonCastle. Each alert becomes a sensor, so it shows in Alarms, Groups, notifications and reports.',
      requirements: ['The other tool can call an HTTPS address (webhook) when an alert fires and when it resolves.', 'It can reach the MonCastle console on its port (5050 by default) through the firewall.', 'It can send a header or add ?token= to the address.'],
      steps: ['Add an integration and pick the tool (Zabbix, PRTG, Nagios, Prometheus Alertmanager, Grafana, Azure Monitor, SolarWinds, Datadog, generic JSON).', 'Copy the address and the token. The token is shown once.', 'In the other tool, add a webhook to that address with the token as Authorization: Bearer.', 'Send a test alert and check it under Alarms.'] },
    { id: 'egress', name: 'Egress: alarms out of MonCastle', short: 'Egress', icon: 'send',
      what: 'MonCastle streams each state change of the alarms you pick as an event: to a chat channel, a SIEM, a log collector or your own automation.',
      requirements: ['The receiver accepts HTTPS POST (webhook, Teams, Slack, Splunk HEC) or syslog (UDP 514, TCP 514 or TLS 6514).', 'The console server can reach the receiver (proxy and firewall).', 'A token or webhook address from the receiver, where it needs one.'],
      steps: ['Pick the receiver type and give it a name.', 'Fill in the address and, where asked, the token. Secrets are stored encrypted on the console and never shown again.', 'Choose which states (Down, Warning, Unknown, Up) and which alarms (groups, devices, sensors, sensor types).', 'Save, then press Test to send a sample event.'] },
    { id: 'incident', name: 'Incidents: tickets from alarms', short: 'Incidents', icon: 'alert',
      what: 'MonCastle opens one incident per alarm when a sensor goes Down (or Warning, if you choose), adds nothing while it stays down, and resolves the incident when the sensor is Up again.',
      requirements: ['An account or integration key in the service desk with the right to create and resolve incidents.', 'The console server can reach the service over HTTPS (proxy and firewall).', 'For ServiceNow and Jira, the assignment group or project the tickets go to.'],
      steps: ['Pick the service desk and fill in its address and account.', 'Paste the password, API token or integration key. It is stored encrypted on the console only.', 'Choose which alarms open incidents and how long to wait before opening one (a short wait avoids tickets for blips).', 'Save, then press Test: MonCastle opens a test incident and resolves it a few seconds later.'] },
  ];

  const sev = (s) => (s === 'Down' ? 'critical' : s === 'Warning' ? 'warning' : s === 'Up' ? 'info' : 'warning');
  const json = (o) => JSON.stringify(o);
  const H = (o) => Object.assign({ 'Content-Type': 'application/json', Accept: 'application/json' }, o || {});
  const basic = (u, p) => 'Basic ' + (typeof Buffer !== 'undefined' ? Buffer.from(u + ':' + p).toString('base64') : btoa(unescape(encodeURIComponent(u + ':' + p))));
  const trimUrl = (u) => String(u || '').replace(/\/+$/, '');
  const title = (e) => `${e.to === 'Up' ? 'Recovered' : e.to}: ${e.deviceName || e.device} · ${e.sensorName}`;
  const desc = (e, link) => `${e.sensorName} on ${e.deviceName || e.device}${e.groupName ? ' (' + e.groupName + ')' : ''} changed from ${e.from} to ${e.to} at ${e.t}.\n${e.message || ''}\n\nOpen in MonCastle: ${link}`.trim();
  const event = (e, ctx) => ({ source: 'RoboMate MonCastle', console: ctx.console, state: e.to, previous: e.from, severity: sev(e.to), sensor: e.sensor, sensorName: e.sensorName, device: e.device, deviceName: e.deviceName, group: e.groupName || '', message: e.message || '', time: e.t, link: ctx.link });

  const TARGETS = [
    // ------------------------------------------------------------ egress
    { id: 'webhook', direction: 'egress', name: 'Webhook (JSON)', on: ['Down', 'Warning', 'Up'],
      help: 'Any HTTPS endpoint: your automation, an iPaaS (Logic Apps, Power Automate, n8n, Zapier) or a script. The body is one JSON event; with a signing secret MonCastle adds X-MonCastle-Signature: sha256=<HMAC of the body>.',
      fields: [{ id: 'url', label: 'Address', type: 'url', required: true, allowHttp: true, placeholder: 'https://automation.company.com/hooks/moncastle' }, { id: 'header', label: 'Extra header name (optional)', placeholder: 'X-Api-Key' }, { id: 'secret', label: 'Header value or signing secret', secret: true }, { id: 'mode', label: 'Use the secret as', type: 'select', options: [['sign', 'HMAC signature'], ['header', 'Value of the extra header']] }],
      build: (f, s, e, ctx) => { const body = json(event(e, ctx)); const h = H(); if (s.secret && f.mode === 'header' && f.header) h[f.header] = s.secret; if (s.secret && f.mode !== 'header') h['X-MonCastle-Signature'] = 'sha256=' + ctx.hmac(s.secret, body); return { method: 'POST', url: f.url, headers: h, body }; } },
    { id: 'teams', direction: 'egress', name: 'Microsoft Teams (Workflows)', on: ['Down', 'Warning', 'Up'],
      help: 'In Teams, open the channel > Workflows > "Post to a channel when a webhook request is received", finish the wizard and copy the address it gives. The address carries its own key, so MonCastle stores it as a secret. Posts an Adaptive Card.',
      fields: [{ id: 'url', label: 'Workflow address', type: 'url', secret: true, required: true, placeholder: 'https://prod-00.westeurope.logic.azure.com/workflows/…' }],
      build: (f, s, e, ctx) => {
        const color = e.to === 'Down' ? 'Attention' : e.to === 'Warning' ? 'Warning' : e.to === 'Up' ? 'Good' : 'Default';
        const card = { type: 'AdaptiveCard', $schema: 'http://adaptivecards.io/schemas/adaptive-card.json', version: '1.4', body: [
          { type: 'TextBlock', text: 'RoboMate MonCastle', size: 'Small', isSubtle: true },
          { type: 'TextBlock', text: title(e), weight: 'Bolder', size: 'Medium', color, wrap: true },
          { type: 'TextBlock', text: e.message || '', wrap: true, spacing: 'Small' },
          { type: 'FactSet', facts: [{ title: 'Device', value: e.deviceName || e.device }, { title: 'Sensor', value: e.sensorName }, { title: 'Group', value: e.groupName || '-' }, { title: 'Was', value: e.from }, { title: 'When', value: e.t }] },
        ], actions: [{ type: 'Action.OpenUrl', title: 'Open in MonCastle', url: ctx.link }] };
        return { method: 'POST', url: s.url, headers: H(), body: json({ type: 'message', attachments: [{ contentType: 'application/vnd.microsoft.card.adaptive', content: card }] }) };
      } },
    { id: 'slack', direction: 'egress', name: 'Slack', on: ['Down', 'Warning', 'Up'],
      help: 'In Slack, create an app > Incoming Webhooks > Add New Webhook to Workspace, pick the channel and copy the address. MonCastle stores it as a secret.',
      fields: [{ id: 'url', label: 'Incoming webhook address', type: 'url', secret: true, required: true, placeholder: 'https://hooks.slack.com/services/…' }],
      build: (f, s, e, ctx) => ({ method: 'POST', url: s.url, headers: H(), body: json({ text: title(e), blocks: [
        { type: 'section', text: { type: 'mrkdwn', text: `${e.to === 'Down' ? ':red_circle:' : e.to === 'Warning' ? ':large_orange_circle:' : e.to === 'Up' ? ':large_green_circle:' : ':white_circle:'} *${title(e)}*\n${e.message || ''}` } },
        { type: 'context', elements: [{ type: 'mrkdwn', text: `${e.groupName || ''} · was ${e.from} · ${e.t}` }] },
        { type: 'actions', elements: [{ type: 'button', text: { type: 'plain_text', text: 'Open in MonCastle' }, url: ctx.link }] }] }) }) },
    { id: 'splunk', direction: 'egress', name: 'Splunk (HTTP Event Collector)', on: ['Down', 'Warning', 'Unknown', 'Up'],
      help: 'In Splunk: Settings > Data inputs > HTTP Event Collector > New Token. Pick the index, copy the token. The address is https://<splunk>:8088/services/collector/event.',
      fields: [{ id: 'url', label: 'HEC address', type: 'url', required: true, placeholder: 'https://splunk.company.com:8088/services/collector/event' }, { id: 'index', label: 'Index (optional)', placeholder: 'moncastle' }, { id: 'sourcetype', label: 'Source type', placeholder: 'moncastle:alarm' }, { id: 'token', label: 'HEC token', secret: true, required: true }],
      build: (f, s, e, ctx) => ({ method: 'POST', url: f.url, headers: H({ Authorization: 'Splunk ' + s.token }), body: json(Object.assign({ time: Date.parse(e.t) / 1000, host: ctx.console, source: 'moncastle', sourcetype: f.sourcetype || 'moncastle:alarm', event: event(e, ctx) }, f.index ? { index: f.index } : {})) }) },
    { id: 'syslog', direction: 'egress', name: 'Syslog (SIEM)', on: ['Down', 'Warning', 'Unknown', 'Up'],
      help: 'RFC 5424 messages with structured data, to any SIEM or log collector (QRadar, ArcSight, Sentinel via AMA, Graylog, rsyslog). TLS uses port 6514 and checks the collector certificate.',
      fields: [{ id: 'host', label: 'Collector', required: true, placeholder: 'siem.company.com' }, { id: 'port', label: 'Port', placeholder: '514' }, { id: 'protocol', label: 'Protocol', type: 'select', options: [['udp', 'UDP'], ['tcp', 'TCP'], ['tls', 'TLS']] }, { id: 'facility', label: 'Facility (0-23)', placeholder: '16 (local0)' }],
      build: (f, s, e, ctx) => {
        const pri = (Math.max(0, Math.min(23, parseInt(f.facility, 10) || 16)) * 8) + (e.to === 'Down' ? 2 : e.to === 'Warning' ? 4 : e.to === 'Up' ? 6 : 5);
        const sd = (v) => String(v == null ? '' : v).replace(/["\\\]]/g, (c) => '\\' + c);
        const msg = `<${pri}>1 ${e.t} ${String(ctx.console).replace(/\s+/g, '-')} MonCastle - ALARM [moncastle@32473 state="${sd(e.to)}" previous="${sd(e.from)}" device="${sd(e.deviceName || e.device)}" sensor="${sd(e.sensorName)}" group="${sd(e.groupName)}"] ${title(e)}${e.message ? ' - ' + e.message : ''}`;
        return { syslog: { host: f.host, port: parseInt(f.port, 10) || (f.protocol === 'tls' ? 6514 : 514), protocol: f.protocol || 'udp', message: msg } };
      } },
    // ------------------------------------------------------------ incidents
    { id: 'servicenow', direction: 'incident', name: 'ServiceNow', on: ['Down', 'Up'],
      help: 'Create an integration user in ServiceNow with the itil role (or a role that can create and update incident records) and Web service access only. MonCastle uses the Table API (/api/now/table/incident).',
      fields: [{ id: 'url', label: 'Instance address', type: 'url', required: true, placeholder: 'https://company.service-now.com' }, { id: 'user', label: 'Integration user', required: true }, { id: 'password', label: 'Password', secret: true, required: true }, { id: 'group', label: 'Assignment group (name or sys_id)', placeholder: 'Service Desk' }, { id: 'caller', label: 'Caller (user id, optional)' }, { id: 'category', label: 'Category', placeholder: 'network' }, { id: 'closeCode', label: 'Close code', placeholder: 'Solution provided' }],
      build: (f, s, e, ctx, ref) => {
        const auth = { Authorization: basic(f.user, s.password) };
        if (e.to === 'Up') return ref ? { method: 'PATCH', url: trimUrl(f.url) + '/api/now/table/incident/' + encodeURIComponent(ref), headers: H(auth), body: json({ state: '6', close_code: f.closeCode || 'Solution provided', close_notes: 'Resolved by RoboMate MonCastle: ' + e.sensorName + ' on ' + (e.deviceName || e.device) + ' is Up again at ' + e.t + '.' }) } : null;
        return { method: 'POST', url: trimUrl(f.url) + '/api/now/table/incident', headers: H(auth), body: json(Object.assign({ short_description: '[MonCastle] ' + title(e), description: desc(e, ctx.link), urgency: e.to === 'Down' ? '1' : '2', impact: e.to === 'Down' ? '2' : '3', correlation_id: 'moncastle:' + e.sensor, correlation_display: 'RoboMate MonCastle' }, f.group ? { assignment_group: f.group } : {}, f.caller ? { caller_id: f.caller } : {}, f.category ? { category: f.category } : {})), ref: (r) => r && r.result && r.result.sys_id, show: (r) => r && r.result && r.result.number };
      } },
    { id: 'jira', direction: 'incident', name: 'Jira Service Management', on: ['Down', 'Up'],
      help: 'Use an Atlassian account that can create issues in the service project; create an API token at id.atlassian.com > Security > API tokens. MonCastle opens the issue and, on recovery, moves it with the transition you name and adds a comment.',
      fields: [{ id: 'url', label: 'Site address', type: 'url', required: true, placeholder: 'https://company.atlassian.net' }, { id: 'user', label: 'Account e-mail', required: true }, { id: 'token', label: 'API token', secret: true, required: true }, { id: 'project', label: 'Project key', required: true, placeholder: 'ITSM' }, { id: 'issueType', label: 'Issue type', placeholder: '[System] Incident' }, { id: 'resolve', label: 'Resolve transition', placeholder: 'Resolve' }],
      build: (f, s, e, ctx, ref) => {
        const auth = { Authorization: basic(f.user, s.token) };
        const adf = (t) => ({ type: 'doc', version: 1, content: t.split('\n').filter(Boolean).map((line) => ({ type: 'paragraph', content: [{ type: 'text', text: line }] })) });
        if (e.to === 'Up') return ref ? { jira: { base: trimUrl(f.url), key: ref, headers: H(auth), transition: f.resolve || 'Resolve', comment: json({ body: adf('Resolved by RoboMate MonCastle: ' + e.sensorName + ' on ' + (e.deviceName || e.device) + ' is Up again at ' + e.t + '.') }) } } : null;
        return { method: 'POST', url: trimUrl(f.url) + '/rest/api/3/issue', headers: H(auth), body: json({ fields: { project: { key: f.project }, issuetype: { name: f.issueType || '[System] Incident' }, summary: '[MonCastle] ' + title(e), description: adf(desc(e, ctx.link)), labels: ['moncastle'] } }), ref: (r) => r && r.key, show: (r) => r && r.key };
      } },
    { id: 'pagerduty', direction: 'incident', name: 'PagerDuty', on: ['Down', 'Up'],
      help: 'In PagerDuty: Services > your service > Integrations > Add an integration > Events API V2, then copy the integration (routing) key. MonCastle triggers with a dedup key per sensor and resolves it on recovery.',
      fields: [{ id: 'region', label: 'Region', type: 'select', options: [['us', 'US (events.pagerduty.com)'], ['eu', 'EU (events.eu.pagerduty.com)']] }, { id: 'key', label: 'Integration key', secret: true, required: true }],
      build: (f, s, e, ctx) => ({ method: 'POST', url: 'https://events.' + (f.region === 'eu' ? 'eu.' : '') + 'pagerduty.com/v2/enqueue', headers: H(), body: json(Object.assign({ routing_key: s.key, event_action: e.to === 'Up' ? 'resolve' : 'trigger', dedup_key: 'moncastle:' + e.sensor }, e.to === 'Up' ? {} : { payload: { summary: '[MonCastle] ' + title(e), source: e.deviceName || e.device, severity: e.to === 'Down' ? 'critical' : 'warning', component: e.sensorName, group: e.groupName || undefined, class: 'monitoring', custom_details: event(e, ctx) }, links: [{ href: ctx.link, text: 'Open in MonCastle' }] })), ref: () => 'moncastle:' + e.sensor }) },
    { id: 'opsgenie', direction: 'incident', name: 'Opsgenie', on: ['Down', 'Up'],
      help: 'In Opsgenie: Teams > your team > Integrations > Add integration > API, copy the API key and keep "Create and update access" on. MonCastle uses the sensor as the alert alias and closes it on recovery.',
      fields: [{ id: 'region', label: 'Region', type: 'select', options: [['us', 'US (api.opsgenie.com)'], ['eu', 'EU (api.eu.opsgenie.com)']] }, { id: 'key', label: 'API key', secret: true, required: true }, { id: 'responders', label: 'Responder team (optional)' }],
      build: (f, s, e, ctx) => {
        const base = 'https://api.' + (f.region === 'eu' ? 'eu.' : '') + 'opsgenie.com/v2/alerts', alias = 'moncastle:' + e.sensor, auth = { Authorization: 'GenieKey ' + s.key };
        if (e.to === 'Up') return { method: 'POST', url: base + '/' + encodeURIComponent(alias) + '/close?identifierType=alias', headers: H(auth), body: json({ source: 'RoboMate MonCastle', note: e.sensorName + ' is Up again at ' + e.t }) };
        return { method: 'POST', url: base, headers: H(auth), body: json(Object.assign({ message: ('[MonCastle] ' + title(e)).slice(0, 130), alias, description: desc(e, ctx.link), priority: e.to === 'Down' ? 'P1' : 'P3', source: 'RoboMate MonCastle', tags: ['moncastle', e.to.toLowerCase()], details: { device: e.deviceName || e.device, sensor: e.sensorName, group: e.groupName || '', link: ctx.link } }, f.responders ? { responders: [{ name: f.responders, type: 'team' }] } : {})), ref: () => alias };
      } },
  ];
  const TARGET = {}; for (const t of TARGETS) TARGET[t.id] = t;
  const secretsOf = (kind) => ((TARGET[kind] || {}).fields || []).filter((f) => f.secret).map((f) => f.id);
  return { DIRECTIONS, TARGETS, TARGET, secretsOf, severity: sev };
});
