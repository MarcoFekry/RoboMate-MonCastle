/*
 * RoboMate MonCastle - Actions › Remote scripting (replaces the 4.6 "Script library" page).
 *   Run code   choose onboarded devices, write PowerShell / Bash / sh / Python / network CLI, run it, read the output per device
 *   History    earlier runs: who, when, which devices, the code and the output
 *   Library    the RoboMate scripts, read live from GitHub and held in memory (nothing saved on disk); read-only
 * Running code is for administrators only, needs a typed confirmation and is written to the access log.
 */
(function (root) {
  'use strict';
  const MC = root.MC, R = root.MCRemote;
  const { esc, pill, icon, ago, dt, $, $$ } = MC;
  const V = MC.views;
  const store = { get: (k) => { try { return localStorage.getItem('mc.remote.' + k); } catch (e) { return null; } }, set: (k, v) => { try { localStorage.setItem('mc.remote.' + k, v); } catch (e) { /* private window */ } } };
  const RES = { Done: 'OK', WhatIf: 'Info', 'Finished with errors': 'Warning', Unreachable: 'Critical' };
  const GROUPS = [['', 'All devices'], ['win', 'Windows'], ['lnx', 'Linux'], ['net', 'Network'], ['other', 'Other']];
  const groupOf = (d) => { const l = R.languagesFor(d); return l[0] === 'PowerShell' ? 'win' : l[0] === 'Bash' ? 'lnx' : l[0] === 'NetworkCli' ? 'net' : 'other'; };

  function modal(html, onReady) {
    const m = document.createElement('div');
    m.className = 'modal'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true');
    m.innerHTML = `<div class="card">${html}</div>`;
    document.body.appendChild(m);
    const close = () => m.remove();
    $$('[data-x]', m).forEach((b) => b.addEventListener('click', close));
    m.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
    const f = $('input,textarea,select', m); if (f) f.focus();
    if (onReady) onReady(m, close);
    return m;
  }
  const outputHtml = (rows) => (rows || []).map((r) => `<div class="rs-out">
      <div class="rs-out-h"><b>${esc(r.ComputerName)}</b>${pill(RES[r.Result] || 'Unknown', r.Result || 'Unknown')}<span class="muted">${r.ExitCode != null ? 'exit ' + esc(r.ExitCode) + ' · ' : ''}${esc(r.Seconds || 0)} s</span><button class="btn sm ghost" data-copy title="Copy the output">${icon('copy', 'sev-ico')}Copy</button></div>
      ${r.Error ? `<div class="notice err" style="margin:6px 0">${esc(r.Error)}</div>` : ''}
      ${r.Output ? `<pre class="rs-pre" tabindex="0">${esc(r.Output)}</pre>` : ''}</div>`).join('') || '<p class="muted">No output.</p>';
  const wireCopy = (box) => $$('[data-copy]', box).forEach((b) => b.addEventListener('click', () => { const p = b.closest('.rs-out').querySelector('pre'); if (p && navigator.clipboard) navigator.clipboard.writeText(p.textContent).then(() => MC.toast('Copied', 'ok'), () => {}); }));

  V.remote = {
    title: 'Remote scripting',
    crumb: () => 'run code on onboarded devices · library read live from GitHub',
    render(el, route) {
      const tab = ['run', 'history', 'library'].includes(route.tab) ? route.tab : 'run';
      el.innerHTML = MC.tabs('remote', [['run', 'Run code'], ['history', 'History'], ['library', 'Script library']], tab) + '<div id="rsT" class="grid"></div>';
      const box = $('#rsT', el);
      if (tab === 'history') return history(box);
      if (tab === 'library') return library(box, route);
      return runTab(box, route);
    },
  };
  // 4.6 links
  V.library = { title: 'Remote scripting', render(el, route) { location.replace('#/remote/library' + (route.q && route.q.q ? '?q=' + encodeURIComponent(route.q.q) : '')); } };

  // ------------------------------------------------------------------ run code
  function runTab(box, route) {
    const admin = MC.user.role === 'admin' || MC.user.override;
    let lang = store.get('lang') || 'PowerShell';
    if (!R.lang(lang)) lang = 'PowerShell';
    const chosen = new Set(String((route.q || {}).device || '').split(',').filter(Boolean));
    box.innerHTML = `${admin ? '' : `<div class="notice">${icon('lock', 'sev-ico')} Only administrators can run code on devices. You can look at the page and at earlier runs under History.</div>`}
      <div class="rs-grid">
        ${MC.panel('1 · Devices', 'onboarded for monitoring: found by engines or manually added', `<div class="rs-filter"><input class="input sm" id="rsQ" type="search" placeholder="Filter by name, address or group" aria-label="Filter devices"><select class="input sm" id="rsG" aria-label="Device type">${GROUPS.map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select></div><div class="rs-sel"><span id="rsN" class="muted">Nothing chosen</span><button class="btn sm ghost" id="rsAll">Choose all shown</button><button class="btn sm ghost" id="rsNone">Clear</button></div><div id="rsDevs" class="rs-devs" role="group" aria-label="Devices"><div class="notice">Loading devices…</div></div>`)}
        ${MC.panel('2 · Code', 'runs on every chosen device that speaks the language', `<div class="seg" role="radiogroup" aria-label="Language" id="rsL">${R.LANGS.map((l) => `<button role="radio" aria-checked="${l.id === lang}" class="${l.id === lang ? 'on' : ''}" data-l="${l.id}">${esc(l.label)}</button>`).join('')}</div>
          <p class="muted rs-via" id="rsVia"></p>
          <label for="rsCode" class="sr-only">Code</label><textarea class="input mono rs-code" id="rsCode" spellcheck="false" autocapitalize="off" autocomplete="off" wrap="off"></textarea>
          <div class="rs-opts"><button class="btn sm ghost" id="rsSample">Insert an example</button><label class="rs-chk"><input type="checkbox" id="rsWhat"> Dry run (WhatIf): check the request, run nothing</label><label class="rs-chk">Time-out <input class="input sm mono" id="rsTo" type="number" min="10" max="3600" value="300" style="width:80px"> s</label></div>
          <div class="actions-row"><button class="btn primary" id="rsGo" ${admin ? '' : 'disabled'}>${icon('play', 'sev-ico')}Run…</button><span class="muted" id="rsHint"></span></div>`)}
      </div>
      <div id="rsRes"></div>`;
    const code = $('#rsCode', box);
    const draft = (l) => store.get('code.' + l);
    code.value = draft(lang) || R.lang(lang).sample;
    code.addEventListener('input', () => store.set('code.' + lang, code.value));
    let devices = [];
    const shown = () => {
      const q = $('#rsQ', box).value.trim().toLowerCase(), g = $('#rsG', box).value;
      return devices.filter((d) => (!g || groupOf(d) === g) && (!q || [d.name, d.host, d.group, d.kind, d.os].join(' ').toLowerCase().includes(q)));
    };
    const fits = (d) => (!root.MCSensors || root.MCSensors.accessOf(d) === 'admin') && R.languagesFor(d).includes(lang);
    const draw = () => {
      const list = shown();
      $('#rsDevs', box).innerHTML = list.length ? list.slice(0, 400).map((d) => {
        const adm = !root.MCSensors || root.MCSensors.accessOf(d) === 'admin', l = adm ? R.languagesFor(d) : [], ok = l.includes(lang);
        return `<label class="rs-dev ${ok ? '' : 'off'}" ${adm ? '' : 'title="Access level is not Administrator: change it in the device settings to run code here"'}><input type="checkbox" data-d="${esc(d.id)}" ${chosen.has(d.id) ? 'checked' : ''} ${l.length ? '' : 'disabled'}><span><span class="rs-dev-n"><b>${esc(d.name)}</b>${pill(d.state, d.state)}</span><small class="muted">${esc(d.host || '')}${d.host ? ' · ' : ''}${esc(d.kind)}${d.os ? ' · ' + esc(d.os) : ''} · ${d.origin === 'engine' ? 'found by an engine' : 'manually added'}</small><small>${l.length ? l.map((x) => `<span class="tag ${x === lang ? 'native' : ''}">${esc(R.lang(x).label)}</span>`).join(' ') : '<span class="muted">cannot run code</span>'}</small></span></label>`;
      }).join('') + (list.length > 400 ? `<p class="muted">Showing 400 of ${list.length}. Filter to see the rest.</p>` : '') : '<p class="muted">No device matches.</p>';
      $$('[data-d]', box).forEach((c) => c.addEventListener('change', () => { if (c.checked) chosen.add(c.dataset.d); else chosen.delete(c.dataset.d); count(); }));
      count();
    };
    const count = () => {
      const sel = devices.filter((d) => chosen.has(d.id)), good = sel.filter(fits);
      $('#rsN', box).textContent = sel.length ? `${sel.length} chosen` + (sel.length !== good.length ? ` · ${sel.length - good.length} cannot run ${R.lang(lang).label}` : '') : 'Nothing chosen';
      $('#rsHint', box).textContent = good.length ? `Runs on ${good.length} device${good.length > 1 ? 's' : ''}` + (sel.length !== good.length ? '; the others are skipped' : '') : '';
    };
    const setLang = (l) => {
      lang = l; store.set('lang', l);
      $$('#rsL [data-l]', box).forEach((b) => { b.classList.toggle('on', b.dataset.l === l); b.setAttribute('aria-checked', b.dataset.l === l); });
      const L = R.lang(l);
      $('#rsVia', box).innerHTML = `Runs over ${esc(L.via)} with the ${L.cred === 'windows' ? 'Windows' : 'SSH'} credential assigned to each device under <a href="#/credentials">Configure › Credentials</a> (or the account MonCastle runs as). The code goes to the devices in memory and is never saved on the MonCastle server.`;
      code.value = draft(l) || L.sample;
      draw();
    };
    $$('#rsL [data-l]', box).forEach((b) => b.addEventListener('click', () => setLang(b.dataset.l)));
    $('#rsQ', box).addEventListener('input', draw);
    $('#rsG', box).addEventListener('change', draw);
    $('#rsAll', box).addEventListener('click', () => { shown().filter(fits).forEach((d) => chosen.add(d.id)); draw(); });
    $('#rsNone', box).addEventListener('click', () => { chosen.clear(); draw(); });
    $('#rsSample', box).addEventListener('click', () => { code.value = R.lang(lang).sample; store.set('code.' + lang, code.value); });
    code.addEventListener('keydown', (e) => { if (e.key === 'Tab' && !e.shiftKey && !e.ctrlKey) { e.preventDefault(); const s = code.selectionStart; code.setRangeText('    ', s, code.selectionEnd, 'end'); } });
    setLang(lang);
    MC.api.monitor('tree').then((t) => { devices = (t.devices || []).slice().sort((a, b) => a.name.localeCompare(b.name)); if (document.body.contains(box)) draw(); }).catch((e) => { $('#rsDevs', box).innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });

    $('#rsGo', box).addEventListener('click', () => {
      const sel = devices.filter((d) => chosen.has(d.id) && fits(d));
      const whatIf = $('#rsWhat', box).checked, timeout = +$('#rsTo', box).value || 300;
      const err = R.check({ devices: sel, language: lang, code: code.value });
      if (err) return MC.toast(esc(err), 'err');
      const word = R.confirmWord(sel);
      modal(`<h3>${whatIf ? 'Dry run' : 'Run'} ${esc(R.lang(lang).label)} on ${sel.length} device${sel.length > 1 ? 's' : ''}?</h3>
        <p class="muted">${sel.slice(0, 12).map((d) => esc(d.name)).join(', ')}${sel.length > 12 ? ' and ' + (sel.length - 12) + ' more' : ''}</p>
        <pre class="rs-pre" style="max-height:180px">${esc(code.value.slice(0, 3000))}${code.value.length > 3000 ? '\n…' : ''}</pre>
        ${whatIf ? '<p class="muted">Dry run: MonCastle checks the request and the devices, and runs nothing.</p>' : `<p>This code runs with administrator rights on the devices and can change them. The run is written to the access log with your name.</p><div class="field"><label for="rsC">Type <b class="mono">${esc(word)}</b> to confirm</label><input class="input mono" id="rsC" autocomplete="off"></div>`}
        <div class="foot"><button class="btn" data-x>Cancel</button><button class="btn ${whatIf ? 'primary' : 'danger'}" id="go">${whatIf ? 'Dry run' : 'Run now'}</button></div>`, (m, close) => {
        $('#go', m).addEventListener('click', async () => {
          const confirm = whatIf ? '' : $('#rsC', m).value.trim();
          if (!whatIf && confirm !== word) { $('#rsC', m).classList.add('invalid'); return MC.toast('Type ' + esc(word) + ' exactly.', 'err'); }
          $('#go', m).disabled = true;
          try { const r = await MC.api.remoteRun({ devices: sel.map((d) => d.id), language: lang, code: code.value, whatIf, confirm, timeout }); close(); follow(r.job.id, $('#rsRes', box)); }
          catch (e) { $('#go', m).disabled = false; MC.toast(esc(e.message), 'err'); }
        });
      });
    });
  }
  // show a run's output as it finishes
  function follow(id, host) {
    const seq = MC.renderSeq;
    host.innerHTML = MC.panel('3 · Output', 'running…', '<div class="notice">Running on the devices…</div>');
    host.scrollIntoView({ behavior: 'smooth', block: 'start' });
    const tick = async () => {
      if (MC.renderSeq !== seq || !document.body.contains(host)) return;
      let j; try { j = await MC.api.job(id); } catch (e) { host.innerHTML = MC.panel('3 · Output', '', `<div class="notice err">${esc(e.message)}</div>`); return; }
      if (!j.finished) return setTimeout(tick, 1200);
      const r = j.result || {};
      host.innerHTML = MC.panel('3 · Output', `${esc(j.language || '')} · ${ago(j.finished)} · ${esc(r.message || '')}`, `<div class="rs-outs">${outputHtml(r.data)}</div>`, { act: `<a class="btn sm ghost" href="#/remote/history">History</a>` });
      wireCopy(host);
    };
    tick();
  }

  // ------------------------------------------------------------------ history
  function history(box) {
    box.innerHTML = '<div class="notice">Loading…</div>';
    MC.api.jobs().then((all) => {
      const list = all.filter((j) => j.script === 'act.remote.code');
      box.innerHTML = MC.panel('Earlier runs', list.length + ' runs kept since the console started; every run is also in the access log', '<div id="rhT"></div>');
      MC.table($('#rhT', box), list, [
        { key: 'started', label: 'Started', html: (j) => `<span title="${esc(j.started)}">${ago(j.started)}</span>` },
        { key: 'user', label: 'By' },
        { key: 'language', label: 'Language', val: (j) => j.language || (j.params || {}).Language },
        { key: 'devices', label: 'Devices', val: (j) => [].concat((j.params || {}).ComputerName || []).join(', ') },
        { key: 'whatIf', label: 'Mode', val: (j) => (j.whatIf ? 'Dry run' : 'Run') },
        { key: 'state', label: 'Result', html: (j) => pill(j.state === 'done' ? (j.result && j.result.status === 'partial' ? 'Warning' : 'OK') : j.state === 'failed' ? 'Critical' : 'Running', j.result ? j.result.message || j.state : j.state) },
        { key: 'act', label: '', noCsv: true, html: (j) => `<button class="btn sm ghost" data-open="${esc(j.id)}">Open</button>` },
      ], { sort: 'started', dir: -1, name: 'remote-history', empty: 'No code has run yet.', after: (w) => $$('[data-open]', w).forEach((b) => b.addEventListener('click', async () => {
        const j = await MC.api.job(b.dataset.open);
        modal(`<h3>${esc(j.language || '')} on ${[].concat((j.params || {}).ComputerName || []).length} device(s)</h3><p class="muted">${esc(j.user)} · ${dt(j.started)}${j.whatIf ? ' · dry run' : ''}${j.codeSha256 ? ' · sha256 <span class="mono">' + esc(j.codeSha256.slice(0, 16)) + '</span>' : ''}</p><h4>Code</h4><pre class="rs-pre">${esc(j.code || '(not kept)')}</pre><h4>Output</h4><div class="rs-outs">${outputHtml((j.result || {}).data)}</div><div class="foot"><button class="btn" data-x>Close</button></div>`, (m) => wireCopy(m));
      })) });
    }).catch((e) => { box.innerHTML = `<div class="notice err">${esc(e.message)}</div>`; });
  }

  // ------------------------------------------------------------------ library (read-only, live from GitHub)
  function library(box, route) {
    const m = MC.manifest, sc = m.scripts || [], st = MC.status.scripts || {};
    const mem = st.cache !== 'disk';
    box.innerHTML = `${MC.panel('Source', mem ? 'read live from GitHub and held in memory' : 'disk cache', `<dl class="kv"><dt>Repository</dt><dd class="mono">${esc((MC.status.repos || {}).scripts || 'local folder')}</dd><dt>Branch</dt><dd>${esc(st.ref || 'main')}${st.commit ? ' · <span class="mono">' + esc(String(st.commit).slice(0, 10)) + '</span>' : ''}</dd><dt>Last fetched</dt><dd>${st.synced ? dt(st.synced) : st.error ? 'not yet: ' + esc(st.error) + ' (retried every 5 minutes)' : 'fetching now'}</dd><dt>Where scripts live</dt><dd>${mem ? 'In memory only. MonCastle reads the manifest and every script from GitHub, checks each SHA-256, and keeps nothing on disk. It fetches the library on its own: at start, every hour, and whenever a script it needs is missing or changed. Nothing to do by hand.' : 'In a local cache (scripts.cache = disk in the configuration). Remove that setting to keep the scripts in memory only.'}</dd><dt>Integrity</dt><dd>A script runs only when its SHA-256 matches manifest.json; files that do not match are refused.</dd></dl>`)}
      ${MC.panel('Catalog', sc.length + ' scripts · ' + (m.support || []).length + ' support files', '<div id="lt"></div>')}`;
    MC.table($('#lt', box), sc, [
      { key: 'title', label: 'Script', html: (r) => `<b>${esc(r.title)}</b><div class="mono muted" style="font-size:11.5px">${esc(r.id)}</div>` }, { key: 'category', label: 'Category' }, { key: 'resource', label: 'Resource' }, { key: 'kind', label: 'Kind' },
      { key: 'risk', label: 'Risk', html: (r) => `<span class="risk-tag ${esc(r.risk)}">${esc(r.risk)}</span>` }, { key: 'path', label: 'Path', cls: 'mono' },
      { key: 'sha256', label: 'SHA-256', html: (r) => `<span class="mono" title="${esc(r.sha256)}">${esc((r.sha256 || '').slice(0, 10))}…</span>` },
      { key: 'act', label: '', noCsv: true, html: (r) => `<div class="actions-row" style="flex-wrap:nowrap"><button class="btn sm ghost" data-src="${esc(r.path)}">View code</button>${r.kind !== 'collector' && r.id !== 'act.remote.code' ? `<button class="btn sm ghost" ${MC.runAttr(r.id, {})}>Run…</button>` : ''}</div>` },
    ], { q: (route.q || {}).q, sort: 'path', dir: 1, name: 'script-catalog', limit: 60, after: (w) => $$('[data-src]', w).forEach((b) => b.addEventListener('click', async () => {
      try { const t = await MC.api.scriptSource(b.dataset.src); modal(`<h3 class="mono" style="font-size:14px">${esc(t.path)}</h3><p class="muted">${t.cache === 'disk' ? 'From the disk cache.' : 'Read from memory; fetched from GitHub and checked against its SHA-256.'}</p><pre class="rs-pre" style="max-height:60vh">${esc(t.text)}</pre><div class="foot"><button class="btn" data-x>Close</button></div>`); }
      catch (e) { MC.toast(esc(e.message), 'err'); }
    })) });
  }
})(typeof self !== 'undefined' ? self : this);
