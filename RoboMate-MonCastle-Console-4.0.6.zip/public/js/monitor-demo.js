/*
 * RoboMate MonCastle - simulated probe for demo mode (browser demo and node server --demo).
 * Gives the probe sensors (ping, port, HTTP, DNS, SNMP, SSL, script) believable readings and builds a 30-day history
 * the first time a sensor page opens, so the graphs look like a console that has been running for weeks.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCMonitorDemo = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // deterministic noise per sensor so a reload looks the same
  const hash = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619); return h >>> 0; };
  const noise = (seed, t) => { const x = Math.sin(seed * 0.0001 + t * 12.9898) * 43758.5453; return x - Math.floor(x); };
  const day = (t) => { const h = new Date(t).getHours() + new Date(t).getMinutes() / 60; return h >= 8 && h <= 18 ? 1 : h >= 6 && h <= 20 ? 0.5 : 0.15; };

  // the probe sensors a fresh demo console starts with
  function config(S) {
    const dev = (name, host, kind, group) => ({ id: 'd:' + name.toLowerCase(), name, host, kind, group, tags: [], auto: false });
    const devices = [
      dev('CORE-SW-HQ01', '10.10.0.1', 'network', 'g:net'),
      dev('FW-HQ01', '10.10.0.254', 'firewall', 'g:fw'),
      dev('UPS-HQ01', '10.10.0.40', 'ups', 'g:power'),
      dev('intranet.corp.moncastle.local', '10.10.20.15', 'web', 'g:web-checks'),
      dev('mail.moncastle.com', 'mail.moncastle.com', 'web', 'g:web-checks'),
      dev('vpn.moncastle.com', 'vpn.moncastle.com', 'web', 'g:web-checks'),
      dev('erp.moncastle.com', 'erp.moncastle.com', 'web', 'g:web-checks'),
    ];
    let n = 0;
    const s = (device, type, name, params, interval) => ({ id: 'n:demo' + (++n), device: 'd:' + device.toLowerCase(), type, name, params, interval: interval || null });
    const sensors = [
      s('CORE-SW-HQ01', 'ping', 'Ping', { host: '10.10.0.1', count: 3 }),
      s('CORE-SW-HQ01', 'snmp.uptime', 'SNMP system uptime', { host: '10.10.0.1' }),
      s('CORE-SW-HQ01', 'snmp.traffic', 'Uplink Te1/0/1', { host: '10.10.0.1', ifIndex: 1 }),
      s('CORE-SW-HQ01', 'snmp.traffic', 'Server farm Po10', { host: '10.10.0.1', ifIndex: 10 }),
      s('FW-HQ01', 'ping', 'Ping', { host: '10.10.0.254', count: 3 }),
      s('FW-HQ01', 'snmp.traffic', 'WAN', { host: '10.10.0.254', ifIndex: 2 }),
      s('FW-HQ01', 'http', 'Management page', { url: 'https://10.10.0.254/', expect: 200 }),
      s('UPS-HQ01', 'ping', 'Ping', { host: '10.10.0.40', count: 3 }),
      s('UPS-HQ01', 'snmp.custom', 'Battery capacity', { host: '10.10.0.40', oid: '1.3.6.1.2.1.33.1.2.4.0', label: 'Value', unit: '%' }),
      s('UPS-HQ01', 'snmp.custom', 'Battery temperature', { host: '10.10.0.40', oid: '1.3.6.1.2.1.33.1.2.7.0', label: 'Value', unit: '°C' }),
      s('intranet.corp.moncastle.local', 'http', 'Intranet home', { url: 'https://intranet.corp.moncastle.local/', keyword: 'Welcome', expect: 200 }),
      s('intranet.corp.moncastle.local', 'sslcert', 'SSL certificate', { host: 'intranet.corp.moncastle.local', port: 443 }, 3600),
      s('mail.moncastle.com', 'http', 'Outlook on the web', { url: 'https://mail.moncastle.com/owa/', expect: 200 }),
      s('mail.moncastle.com', 'port', 'SMTP port', { host: 'mail.moncastle.com', port: 25 }),
      s('mail.moncastle.com', 'sslcert', 'SSL certificate', { host: 'mail.moncastle.com', port: 443 }, 3600),
      s('vpn.moncastle.com', 'port', 'VPN port', { host: 'vpn.moncastle.com', port: 443 }),
      s('vpn.moncastle.com', 'sslcert', 'SSL certificate', { host: 'vpn.moncastle.com', port: 443 }, 3600),
      s('erp.moncastle.com', 'http', 'ERP login page', { url: 'https://erp.moncastle.com/login', keyword: 'Sign in', expect: 200 }),
      s('erp.moncastle.com', 'sslcert', 'SSL certificate', { host: 'erp.moncastle.com', port: 443 }, 3600),
      s('DC01', 'dns', 'DNS: corp.moncastle.local', { server: 'DC01.corp.moncastle.local', name: 'corp.moncastle.local', recordType: 'A' }),
      s('DC01', 'dns', 'DNS: _ldap SRV', { server: 'DC01.corp.moncastle.local', name: '_ldap._tcp.dc._msdcs.corp.moncastle.local', recordType: 'SRV' }),
      s('DC02', 'dns', 'DNS: corp.moncastle.local', { server: 'DC02.corp.moncastle.local', name: 'corp.moncastle.local', recordType: 'A' }),
      s('DC01', 'port', 'LDAP port', { host: 'DC01.corp.moncastle.local', port: 389 }),
      s('DC01', 'port', 'Kerberos port', { host: 'DC01.corp.moncastle.local', port: 88 }),
    ];
    // storage, power and hardware devices with their vendor model profile (the same sensors the add-device wizard creates)
    const overrides = {};
    const prof = [['CORE-SW-HQ01', 'cisco-ios'], ['FW-HQ01', 'fortigate'], ['UPS-HQ01', null], ['SAN-HQ01', 'netapp', '10.10.5.20', 'san', 'g:storage'], ['SAN-HQ02', 'pure', '10.10.5.21', 'san', 'g:storage'], ['NAS-BR01', 'synology', '10.20.5.10', 'nas', 'g:storage'],
      ['FC-SW-A', 'brocade', '10.10.5.2', 'fcswitch', 'g:storage'], ['DD-HQ01', 'datadomain', '10.10.5.30', 'backup', 'g:storage'], ['PDU-R12-A', 'apc-pdu', '10.10.0.61', 'pdu', 'g:power'], ['ENV-DC-HQ', 'akcp', '10.10.0.70', 'environment', 'g:power'],
      ['IDRAC-HV01', 'idrac', '10.10.9.11', 'bmc', 'g:hw'], ['ILO-SQL01', 'ilo', '10.10.9.21', 'bmc', 'g:hw'], ['LB-HQ01', 'f5', '10.10.0.80', 'loadbalancer', 'g:net'], ['WLC-HQ01', 'cisco-wlc', '10.10.0.90', 'wireless', 'g:net']];
    for (const [name, p, host, kind, group] of prof) {
      let d = devices.find((x) => x.name === name);
      if (!d) { d = dev(name, host, kind, group); devices.push(d); sensors.push(s(name, 'ping', 'Ping', { host, count: 3 })); }
      if (!p || !S) continue;
      d.profile = p;
      for (const t of S.profileSensors(p)) {
        const x = s(name, t.type, t.name, Object.assign({ host: d.host }, t.params)); x.option = 'vendor'; sensors.push(x);
        if (t.limits) overrides[x.id] = { limits: t.limits };
      }
      if (kind === 'san' || kind === 'nas' || kind === 'backup' || kind === 'bmc' || kind === 'loadbalancer') sensors.push(s(name, 'http', 'Management page', { url: 'https://' + d.host + '/', expect: 200 }));
    }
    // multi-server demo: the branch and DR MonCastle servers monitor their own sites
    for (const d of devices) if (/-BR\d/.test(d.name)) d.server = 'srv:moncastle-br01'; else if (/^(SAN-HQ02|DD-HQ01)$/.test(d.name)) d.server = 'srv:moncastle-dr01';
    // database services (the devices come from the database engine dataset) and cloud storage endpoints
    const dbs = [['ORA01', 'oracle', '10.10.7.21'], ['ORA02', 'oracle', '10.20.7.21'], ['PGSQL01', 'postgres', '10.10.7.31'], ['PGSQL02', 'postgres', '10.20.7.31'], ['MYSQL01', 'mysql', '10.10.7.41'], ['MARIA01', 'mariadb', '10.10.7.42'],
      ['MONGO01', 'mongodb', '10.10.7.51'], ['MONGO02', 'mongodb', '10.20.7.51'], ['REDIS01', 'redis', '10.10.7.61'], ['ELASTIC01', 'elastic', '10.10.7.71'], ['CASS01', 'cassandra', '10.10.7.81']];
    for (const [name, engine, host] of dbs) { const x = s(name, 'db.service', ((S && S.DB_ENGINE[engine]) || { name: engine }).name + ' service', { host, engine }, 120); x.option = 'dbservice'; sensors.push(x); }
    for (const [name, host] of [['AZ-moncastlebackup', 'moncastlebackup.blob.core.windows.net'], ['AWS-481516234200', 's3.eu-central-1.amazonaws.com'], ['GCP-moncastle-prod', 'storage.googleapis.com'], ['OCI-moncastle-tenancy', 'objectstorage.me-jeddah-1.oraclecloud.com'], ['HWC-moncastle-hwc', 'obs.af-north-1.myhuaweicloud.com']]) {
      const x = s(name, 'sslcert', 'TLS certificate', { host, port: 443 }, 3600); x.option = 'cloud-endpoint'; sensors.push(x);
    }
    if (S) { const v = s('NAS-BR01', 'snmp.storage', 'Volume 2 (Backups)', { host: '10.20.5.10', index: 32 }); sensors.push(v); }
    const rules = [
      { id: 'r:demo1', name: 'Service desk: anything down', enabled: true, on: ['Down'], delayMin: 2, group: null, device: null, sensor: null, targets: [{ kind: 'email', to: 'servicedesk@moncastle.com' }, { kind: 'webhook', url: 'https://moncastle.webhook.office.com/webhookb2/demo', format: 'teams' }] },
      { id: 'r:demo2', name: 'Domain controllers: warnings and recoveries', enabled: true, on: ['Warning', 'Up'], delayMin: 5, group: 'g:dc', device: null, sensor: null, targets: [{ kind: 'email', to: 'ad-team@moncastle.com' }] },
    ];
    const templates = [{ id: 'tpl:short', name: 'Short on-call card', subject: '{{state}} · {{device}} · {{sensor}}', html: '<div style="font-family:Segoe UI,Arial,sans-serif;max-width:560px;margin:auto;border:1px solid #dde3ea;border-radius:10px;overflow:hidden"><div style="background:{{stateColor}};color:#fff;padding:14px 18px;font-weight:700">{{state}}: {{device}}</div><div style="padding:16px 18px;color:#13233A"><p style="margin:0 0 8px"><b>{{sensor}}</b> changed from {{previous}} to {{state}} at {{time}}.</p><p style="margin:0 0 14px;color:#3D4F66">{{message}}</p><a href="{{link}}" style="color:#1673BF">Open in MonCastle</a></div></div>' }];
    const outbound = [
      { id: 'out:demo-teams', kind: 'teams', direction: 'egress', name: 'NOC Teams channel', enabled: true, on: ['Down', 'Warning', 'Up'], delayMin: 0, groups: [], devices: [], sensors: [], types: [], fields: {}, secretSet: true, created: '2026-10-01T09:00:00Z' },
      { id: 'out:demo-snow', kind: 'servicenow', direction: 'incident', name: 'ServiceNow: server outages', enabled: true, on: ['Down', 'Up'], delayMin: 5, groups: ['g:srv', 'g:dc', 'g:sql'], devices: [], sensors: [], types: [], fields: { url: 'https://moncastle.service-now.com', user: 'svc_moncastle', group: 'Service Desk', category: 'hardware', closeCode: 'Solution provided' }, secretSet: true, created: '2026-10-01T09:00:00Z' },
    ];
    return { groups: [], devices, sensors, overrides, deviceOverrides: {}, outbound, notifications: { rules, templates, defaultTemplate: null, smtp: { host: 'smtp.moncastle.com', port: 587, security: 'auto', user: 'moncastle@moncastle.com', from: 'MonCastle <moncastle@moncastle.com>' } }, dismissed: [] };
  }

  // channel values for one sensor at time t (no randomness beyond the deterministic noise)
  function values(sensor, t) {
    const p = sensor.params || {};
    const seed = hash(sensor.id + (p.host || p.url || p.server || ''));
    const r = (k) => noise(seed + k, Math.floor(t / 30e3));
    const d = day(t);
    const spike = r(9) > 0.985;
    switch (sensor.type) {
      case 'ping': {
        const base = /^10\./.test(p.host || '') ? 1 + (seed % 4) : 18 + (seed % 25);
        return [['Ping time', +(base + r(1) * base * 0.6 + (spike ? base * 8 : 0)).toFixed(1)], ['Packet loss', spike && r(2) > 0.5 ? 33 : 0]];
      }
      case 'port': return [['Response time', Math.round(2 + (seed % 30) + r(1) * 20 + (spike ? 400 : 0))]];
      case 'http': {
        const base = 120 + (seed % 300);
        return [['Response time', Math.round(base * (0.8 + d * 0.6) + r(1) * base * 0.5 + (spike ? 2400 : 0))], ['Status code', 200]];
      }
      case 'dns': return [['Response time', Math.round(3 + r(1) * 9 + (spike ? 180 : 0))], ['Records', /SRV/.test(p.recordType) ? 4 : 1 + (seed % 2)]];
      case 'sslcert': {
        // one certificate is close to expiring so the demo shows a warning
        const left = /intranet/.test(p.host) ? 19 : /vpn/.test(p.host) ? 64 : 120 + (seed % 200);
        return [['Days to expiration', left]];
      }
      case 'snmp.uptime': return [['System uptime', +(((t - (Date.UTC(2026, 7, 2) + (seed % 50) * 864e5)) / 3600e3)).toFixed(1)], ['Response time', Math.round(3 + r(1) * 6)]];
      case 'snmp.traffic': {
        const cap = /WAN/.test(sensor.name) ? 400 : 2000;
        const inn = cap * (0.05 + d * 0.35 * (0.6 + r(1) * 0.7)) + (spike ? cap * 0.4 : 0);
        return [['Traffic in', +inn.toFixed(1)], ['Traffic out', +(inn * (0.25 + r(2) * 0.3)).toFixed(1)], ['Interface up', 1]];
      }
      case 'snmp.custom': {
        if (/33\.1\.2\.4/.test(p.oid) || /318\.1\.1\.1\.2\.2\.1/.test(p.oid)) return [['Value', 100]];
        if (/33\.1\.2\.7/.test(p.oid) || /318\.1\.1\.1\.2\.2\.2/.test(p.oid)) return [['Value', +(27 + d * 4 + r(1) * 1.5).toFixed(1)]];
        // vendor profile sensors: a believable value from the channel unit; status OIDs report their "ok" value
        const lim = sensor.limits || {};
        if (lim.errHigh === 0 && lim.warnHigh == null) return [['Value', 0]];
        if (!p.unit) return [['Value', lim.warnHigh != null ? lim.warnHigh : lim.errHigh != null ? Math.max(0, lim.errHigh) : 1]];
        if (p.unit === '%') return [['Value', Math.round(18 + d * 30 + r(1) * 15)]];
        if (p.unit === '°C') return [['Value', +(34 + d * 6 + r(1) * 3).toFixed(1)]];
        if (p.unit === 'min') return [['Value', Math.round(38 + r(1) * 4)]];
        if (p.unit === 'µs') return [['Value', Math.round(350 + d * 400 + r(1) * 200 + (spike ? 2500 : 0))]];
        if (p.unit === 'A') return [['Value', +(4 + d * 3 + r(1)).toFixed(1)]];
        if (p.unit === 'MB') return [['Value', Math.round(380 + r(1) * 40)]];
        if (p.unit === '#') return [['Value', Math.round((/IOPS/.test(p.label) ? 9000 : 2500) * (0.3 + d * 0.8) * (0.8 + r(1) * 0.4))]];
        return [['Value', Math.round(r(1) * 100)]];
      }
      case 'snmp.storage': {
        const size = 8000 + (seed % 5) * 4000, used = size * (0.45 + (seed % 40) / 100 + r(1) * 0.01);
        return [['Used', +((used / size) * 100).toFixed(1)], ['Free', Math.round(size - used)], ['Size', size]];
      }
      case 'db.service': {
        const base = { redis: 1, postgres: 3, mysql: 3, mariadb: 3, mongodb: 4, oracle: 6, elastic: 18, cassandra: 5 }[p.engine] || 5;
        const rt = [['Response time', +(base + r(1) * base * 0.8 + (spike ? base * 20 : 0)).toFixed(1)]];
        if (p.engine === 'redis') return rt.concat([['Connected clients', Math.round(700 + d * 200 + r(2) * 40)], ['Memory used', Math.round(11200 + r(3) * 600)], ['Operations', Math.round(2000 + d * 9000 + r(4) * 800)], ['Rejected connections', 0]]);
        if (p.engine === 'elastic') return rt.concat([['Cluster health', 1], ['Nodes', 3], ['Unassigned shards', 2], ['Pending tasks', 0]]);
        if (p.engine === 'mongodb') return rt.concat([['Writable primary', /^10\.10/.test(p.host) ? 1 : 0]]);
        if (['postgres', 'mysql', 'mariadb', 'mssql'].includes(p.engine)) return rt.concat([['TLS offered', p.engine === 'mariadb' ? 0 : 1]]);
        return rt;
      }
      case 'script': return [['Value', Math.round(r(1) * 10)], ['Execution time', +(2 + r(2) * 6).toFixed(1)]];
      default: return [];
    }
  }

  // units and limits of the engine-specific database channels (the real probe sends them with the reading)
  const DBX = { 'Connected clients': { unit: '#' }, 'Memory used': { unit: 'MB' }, Operations: { unit: '#/s' }, 'Rejected connections': { unit: '#', limits: { warnHigh: 0 } }, 'Cluster health': { limits: { warnHigh: 0, errHigh: 1 } }, Nodes: { unit: '#' }, 'Unassigned shards': { unit: '#', limits: { warnHigh: 0 } }, 'Pending tasks': { unit: '#' } };
  function probe(sensor, S) {
    const t = Date.now();
    const type = (S && S.TYPE[sensor.type]) || {};
    const defs = Object.fromEntries((type.channels || []).map((c) => [c.name, c]));
    const v = values(sensor, t);
    const p = sensor.params || {};
    const channels = v.map(([name, value]) => {
      const d = defs[name] || {};
      const c = { name, value, unit: d.unit || '', limits: d.limits || {}, primary: !!d.primary };
      if (sensor.type === 'snmp.custom') { c.name = p.label || 'Value'; c.unit = p.unit || ''; c.primary = true; }
      if (sensor.type === 'db.service' && DBX[name]) Object.assign(c, DBX[name]);
      return c;
    });
    const out = { channels };
    if (sensor.type === 'db.service') out.message = { oracle: 'Oracle listener · port open; the database engine collector signs in for details', postgres: 'PostgreSQL · TLS offered', mysql: 'MySQL 8.0.39', mariadb: 'MariaDB 10.11.8', mongodb: 'MongoDB 7.0+ · replica set rs-prod, ' + (/^10\.10/.test(p.host) ? 'primary' : 'secondary'), redis: 'Redis 7.2.5 · role master', elastic: 'Elasticsearch cluster logs-prod · health yellow', cassandra: 'CQL 3.4.6' }[p.engine] || '';
    if (sensor.type === 'http' && p.keyword) out.message = 'Keyword "' + p.keyword + '" found';
    return new Promise((res) => setTimeout(() => res(out), 150 + (hash(sensor.id) % 600)));
  }

  // 2 hours of live points, 2 days of 5-minute points and 30 days of hourly points
  function seed(sensor, channels, nowT) {
    const t0 = nowT || Date.now();
    const names = channels.map((c) => c.name);
    const at = (t) => {
      if (sensor.source === 'collector') {
        // collector sensors: wander around the current value
        const sd = hash(sensor.id);
        return channels.map((c, i) => {
          if (c.value == null) return null;
          const v = +c.value, w = noise(sd + i, Math.floor(t / 300e3)) - 0.5;
          const amp = /%|ms|MB\/s|Mbit|KB/.test(c.unit || '') ? Math.max(Math.abs(v) * 0.35, 2) : Math.abs(v) * 0.08;
          let x = v + w * amp * (0.6 + day(t) * 0.8);
          if (c.unit === '%') x = Math.max(0, Math.min(100, x));
          if (Number.isInteger(v) && Math.abs(v) < 50) x = Math.round(x);
          return +x.toFixed(1);
        });
      }
      const v = Object.fromEntries(values(sensor, t));
      return channels.map((c) => (v[c.name] != null ? v[c.name] : sensor.type === 'snmp.custom' ? (values(sensor, t)[0] || [])[1] : c.value));
    };
    const series = (from, step, n) => { const out = []; for (let i = n; i > 0; i--) { const t = Math.floor((t0 - i * step) / step) * step; out.push([t, ...at(t)].concat(step > 60e3 ? [1] : [])); } return out; };
    return { names, live: series(0, 40e3, 180), five: series(0, 300e3, 576), hour: series(0, 3600e3, 720) };
  }

  return { config, probe, seed, values };
});
