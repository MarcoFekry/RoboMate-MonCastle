/*
 * RoboMate MonCastle - 4.7.2 monitoring views: Containers & Kubernetes, cloud firewalls / WAF / VPN on the Network page,
 * Linux filesystems, services and audit, Web servers, and the discovery methods on Auto-discovery. 4.7.3: Databases page,
 * Network tabs by device type (switches, firewalls, WAF, VPN, wireless, load balancers). Temperature is a sensor only.
 * Every action button opens the normal run dialog (MC.runDialog), so role checks, confirmation and audit stay the same.
 */
(function (root) {
  'use strict';
  const MC = root.MC, C = root.MCCharts;
  const { esc, fmt, pill, icon, ago, $, $$ } = MC;
  const V = MC.views;
  const sum = (a) => a.reduce((x, y) => x + (+y || 0), 0);
  const cnt = (a, f) => a.filter(f).length;
  const bad = (r) => r.Status && r.Status !== 'OK';
  const canAct = () => MC.user.role !== 'reader';
  const lc = (s) => String(s || '').toLowerCase();
  const small = (t) => `<span style="font-size:12.5px">${esc(t == null ? '' : t)}</span>`;
  const run = (id, p, label, cls) => (canAct() && MC.script(id) ? `<button class="btn sm ${cls || 'ghost'}" ${MC.runAttr(id, p)}>${esc(label)}</button>` : '');
  const collect = (id, label) => `<a class="btn sm ghost" href="#/engines/${esc(id)}">Engine</a><button class="btn sm" ${MC.runAttr(id, {})}>${esc(label || 'Collect now…')}</button>`;
  const empty = (what, how) => `<div class="notice">${icon('info', 'sev-ico')} No ${esc(what)} yet. ${how}</div>`;
  const bytes = (b) => (b == null ? '–' : b >= 1e12 ? fmt(b / 1e12, 1) + ' TB' : b >= 1e9 ? fmt(b / 1e9, 1) + ' GB' : b >= 1e6 ? fmt(b / 1e6, 1) + ' MB' : fmt(b / 1e3, 0) + ' KB');

  // ================================================================== CONTAINERS & KUBERNETES
  const K8S_TABS = [['overview', 'Overview'], ['clusters', 'Clusters'], ['nodes', 'Nodes'], ['workloads', 'Workloads'], ['pods', 'Failing pods'], ['hosts', 'Docker & Podman hosts'], ['containers', 'Containers'], ['actions', 'Actions & integrations']];
  V.containers = {
    title: 'Containers & Kubernetes',
    crumb: () => { const k = MC.data('containers.kubernetes'), d = MC.data('containers.docker'); return cnt(k, (r) => r.Kind === 'Cluster') + ' clusters · ' + cnt(k, (r) => r.Kind === 'Node') + ' nodes · ' + cnt(d, (r) => r.Kind === 'Host') + ' container hosts · ' + cnt(d, (r) => r.Kind === 'Container') + ' containers'; },
    render(el, route) {
      const tab = K8S_TABS.some(([t]) => t === route.tab) ? route.tab : 'overview';
      const k = MC.data('containers.kubernetes'), d = MC.data('containers.docker');
      const pods = k.filter((r) => r.Kind === 'Pod');
      el.innerHTML = MC.tabs('containers', K8S_TABS.map(([t, l]) => (t === 'pods' && pods.length ? [t, l, { s: 'Critical', n: pods.length }] : [t, l])), tab) + '<div id="kTab" class="grid"></div>';
      const box = $('#kTab', el);
      ({ overview: k8sOverview, clusters: k8sClusters, nodes: k8sNodes, workloads: k8sWorkloads, pods: k8sPods, hosts: dockerHosts, containers: dockerContainers, actions: k8sActions })[tab](box, k, d);
    },
  };
  function k8sOverview(el, k, d) {
    const cl = k.filter((r) => r.Kind === 'Cluster'), nodes = k.filter((r) => r.Kind === 'Node'), wl = k.filter((r) => /Deployment|StatefulSet|DaemonSet/.test(r.Kind));
    const hosts = d.filter((r) => r.Kind === 'Host'), cs = d.filter((r) => r.Kind === 'Container');
    el.innerHTML = `<div class="kpis">${MC.kpi('Clusters', cl.length, cnt(cl, bad) + ' with problems', { alert: cl.some((r) => r.Status === 'Critical'), href: '#/containers/clusters' })}${MC.kpi('Nodes ready', sum(cl.map((r) => r.NodesReady)) + ' / ' + sum(cl.map((r) => r.Nodes)), '', { alert: cl.some((r) => r.NodesReady < r.Nodes), href: '#/containers/nodes' })}${MC.kpi('Pods running', sum(cl.map((r) => r.PodsRunning)), sum(cl.map((r) => r.PodsFailing)) + ' failing', { alert: cl.some((r) => r.PodsFailing), href: '#/containers/pods' })}${MC.kpi('Workloads degraded', cnt(wl, bad), wl.length + ' deployments, stateful and daemon sets', { href: '#/containers/workloads' })}${MC.kpi('Container hosts', hosts.length, sum(hosts.map((r) => r.Running)) + ' of ' + cs.length + ' containers running', { href: '#/containers/hosts' })}${MC.kpi('Containers with problems', cnt(cs, bad), 'restarting, unhealthy or stopped', { alert: cs.some((r) => r.Status === 'Critical'), href: '#/containers/containers' })}</div>
      ${cl.length || hosts.length ? '' : empty('container platform', 'Add a Kubernetes cluster (type <b>Kubernetes cluster</b>, its API address and an http credential with a read-only service account token) or a Linux host that runs Docker or Podman, then turn on the Kubernetes and Containers engines.')}
      <div class="host-cards">${cl.map((c) => `<div class="card host-card" data-href="#/containers/clusters" tabindex="0" role="button" style="cursor:pointer"><div style="display:flex;gap:8px;align-items:center"><b>${esc(c.Name)}</b><span style="margin-left:auto">${pill(c.Status)}</span></div><div class="muted mono" style="font-size:11.5px">${esc(c.Address || '')}</div><div class="muted" style="font-size:12px">${esc(c.Version || '')} · ${c.NodesReady}/${c.Nodes} nodes · ${c.PodsRunning} pods · ${c.WarningEvents1h} warning events in 1 h</div>${c.CPUPct != null ? `<div class="gauges">${C.gauge(c.CPUPct, { label: 'CPU', warn: 80, crit: 95 })}${C.gauge(c.MemoryPct, { label: 'Memory', warn: 85, crit: 95 })}</div>` : ''}<div style="font-size:12.5px">${esc(c.Message || '')}</div></div>`).join('')}</div>
      <div class="grid g-1-2">
        ${MC.panel('Top warning events', 'last hour, per cluster', C.barList(cl.flatMap((c) => (c.TopEvents || []).map((e) => { const m = /^(.*) \((\d+)\)$/.exec(e) || [0, e, 1]; return { label: m[1], sub: c.Name, value: +m[2], text: m[2], color: '--s3' }; })).sort((a, b) => b.value - a.value).slice(0, 8), { compact: true }))}
        ${MC.panel('Problems now', 'failing pods, degraded workloads and containers', '<div id="kProb"></div>')}
      </div>`;
    const prob = k.filter((r) => ['Pod', 'Deployment', 'StatefulSet', 'DaemonSet', 'Node', 'PVC'].includes(r.Kind) && bad(r)).map((r) => ({ Where: r.Cluster, Kind: r.Kind, Name: (r.Namespace ? r.Namespace + '/' : '') + r.Name, Status: r.Status, Message: r.Message }))
      .concat(d.filter((r) => r.Kind === 'Container' && bad(r)).map((r) => ({ Where: r.Host, Kind: 'Container', Name: r.Name, Status: r.Status, Message: r.Message })));
    MC.table($('#kProb', el), prob, [{ key: 'Where', label: 'Cluster / host' }, { key: 'Kind', label: 'Kind' }, { key: 'Name', label: 'Name', cls: 'mono' }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }, { key: 'Message', label: 'Detail', html: (r) => small(r.Message) }], { sort: 'Status', name: 'k8s-problems', limit: 12, empty: 'Nothing failing.' });
  }
  function k8sClusters(el, k) {
    el.innerHTML = MC.panel('Clusters', 'Kubernetes engine · every 5 minutes', '<div id="kc"></div>', { act: collect('mon.kubernetes') });
    MC.table($('#kc', el), k.filter((r) => r.Kind === 'Cluster'), [
      { key: 'Name', label: 'Cluster', html: (r) => `<b>${esc(r.Name)}</b><div class="muted mono" style="font-size:11.5px">${esc(r.Address || '')}</div>` }, { key: 'Version', label: 'Version' },
      { key: 'NodesReady', label: 'Nodes ready', val: (r) => r.NodesReady + '/' + r.Nodes, html: (r) => (r.NodesReady < r.Nodes ? pill('Critical', r.NodesReady + '/' + r.Nodes) : r.NodesReady + '/' + r.Nodes) },
      { key: 'PodsRunning', label: 'Pods running', n: true }, { key: 'PodsFailing', label: 'Failing', n: true, html: (r) => (r.PodsFailing ? pill('Critical', String(r.PodsFailing)) : '0') },
      { key: 'WorkloadsDegraded', label: 'Degraded workloads', n: true }, { key: 'PvcPending', label: 'PVC pending', n: true }, { key: 'WarningEvents1h', label: 'Warnings 1 h', n: true },
      { key: 'CPUPct', label: 'CPU', n: true, html: (r) => MC.minibar(r.CPUPct, 80, 95) }, { key: 'MemoryPct', label: 'Memory', n: true, html: (r) => MC.minibar(r.MemoryPct, 85, 95) },
      { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }, { key: 'Message', label: 'Detail', html: (r) => small(r.Message) },
    ], { sort: 'Status', name: 'k8s-clusters', empty: 'No cluster read yet.' });
  }
  function k8sNodes(el, k) {
    el.innerHTML = MC.panel('Nodes', 'ready, pressure, CPU and memory from the metrics API when installed', '<div id="kn"></div>');
    MC.table($('#kn', el), k.filter((r) => r.Kind === 'Node'), [
      { key: 'Name', label: 'Node', html: (r) => `<b>${esc(r.Name)}</b><div class="muted mono" style="font-size:11.5px">${esc(r.Address || '')}</div>` }, { key: 'Cluster', label: 'Cluster' }, { key: 'Roles', label: 'Roles' }, { key: 'OS', label: 'OS' }, { key: 'Version', label: 'Kubelet' },
      { key: 'Ready', label: 'Ready', val: (r) => (r.Ready ? 'Yes' : 'No'), html: (r) => pill(r.Ready ? 'OK' : 'Critical', r.Ready ? 'Ready' : 'NotReady') }, { key: 'Pressure', label: 'Pressure', html: (r) => (r.Pressure ? pill('Warning', r.Pressure) : '') },
      { key: 'CPUPct', label: 'CPU', n: true, html: (r) => MC.minibar(r.CPUPct, 85, 97) }, { key: 'MemoryPct', label: 'Memory', n: true, html: (r) => MC.minibar(r.MemoryPct, 85, 95) }, { key: 'Pods', label: 'Pods', n: true },
      { key: 'act', label: '', noCsv: true, html: (r) => (r.Unschedulable ? run('act.k8s', { ComputerName: [r.Cluster], Operation: 'UncordonNode', Name: lc(r.Name) }, 'Uncordon…') : run('act.k8s', { ComputerName: [r.Cluster], Operation: 'CordonNode', Name: lc(r.Name) }, 'Cordon…')) },
    ], { sort: 'Ready', name: 'k8s-nodes', empty: 'No node read yet.' });
  }
  function k8sWorkloads(el, k) {
    el.innerHTML = MC.panel('Workloads', 'deployments, stateful sets and daemon sets: ready replicas against desired', '<div id="kw"></div>');
    MC.table($('#kw', el), k.filter((r) => /Deployment|StatefulSet|DaemonSet/.test(r.Kind)), [
      { key: 'Name', label: 'Workload', html: (r) => `<b>${esc(r.Name)}</b><div class="muted" style="font-size:11.5px">${esc(r.Kind)}</div>` }, { key: 'Namespace', label: 'Namespace', cls: 'mono' }, { key: 'Cluster', label: 'Cluster' },
      { key: 'ReadyCount', label: 'Ready', val: (r) => r.ReadyCount + '/' + r.Desired, html: (r) => (r.ReadyCount < r.Desired ? pill(r.Status, r.ReadyCount + '/' + r.Desired) : r.ReadyCount + '/' + r.Desired) },
      { key: 'Images', label: 'Image', html: (r) => `<span class="mono" style="font-size:11.5px">${esc(r.Images || '')}</span>` }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status) },
      { key: 'act', label: '', noCsv: true, html: (r) => (r.Kind === 'DaemonSet' ? '' : run('act.k8s', { ComputerName: [r.Cluster], Operation: 'RestartWorkload', Namespace: r.Namespace, Name: r.Name, WorkloadKind: r.Kind }, 'Restart…') + run('act.k8s', { ComputerName: [r.Cluster], Operation: 'ScaleWorkload', Namespace: r.Namespace, Name: r.Name, WorkloadKind: r.Kind, Replicas: r.Desired }, 'Scale…')) },
    ], { sort: 'Status', name: 'k8s-workloads', empty: 'No workload read yet.' });
  }
  function k8sPods(el, k) {
    el.innerHTML = MC.panel('Failing pods', 'CrashLoopBackOff, ImagePullBackOff, Pending, Failed and pods restarting often', '<div id="kp"></div>') + MC.panel('Volume claims not bound', '', '<div id="kv"></div>');
    MC.table($('#kp', el), k.filter((r) => r.Kind === 'Pod'), [
      { key: 'Name', label: 'Pod', cls: 'mono' }, { key: 'Namespace', label: 'Namespace', cls: 'mono' }, { key: 'Cluster', label: 'Cluster' }, { key: 'Node', label: 'Node' }, { key: 'Reason', label: 'Reason', html: (r) => pill(r.Status, r.Reason || r.Phase) },
      { key: 'Restarts', label: 'Restarts', n: true }, { key: 'Message', label: 'Detail', html: (r) => small(r.Message) },
      { key: 'act', label: '', noCsv: true, html: (r) => run('act.k8s', { ComputerName: [r.Cluster], Operation: 'DeletePod', Namespace: r.Namespace, Name: r.Name }, 'Delete pod…') },
    ], { sort: 'Restarts', dir: -1, name: 'k8s-pods', empty: 'No failing pods.' });
    MC.table($('#kv', el), k.filter((r) => r.Kind === 'PVC'), [{ key: 'Name', label: 'Claim', cls: 'mono' }, { key: 'Namespace', label: 'Namespace', cls: 'mono' }, { key: 'Cluster', label: 'Cluster' }, { key: 'StorageClass', label: 'Storage class' }, { key: 'Phase', label: 'Phase', html: (r) => pill(r.Status, r.Phase) }, { key: 'Message', label: 'Detail', html: (r) => small(r.Message) }], { name: 'k8s-pvc', empty: 'Every claim is bound.' });
  }
  function dockerHosts(el, k, d) {
    el.innerHTML = MC.panel('Docker and Podman hosts', 'Containers engine over SSH · every 5 minutes', '<div id="dh"></div>', { act: collect('mon.containers') });
    MC.table($('#dh', el), d.filter((r) => r.Kind === 'Host'), [
      { key: 'Name', label: 'Host', html: (r) => `<a href="#" data-host="${esc(r.Name)}"><b>${esc(r.Name)}</b></a>` }, { key: 'Engine', label: 'Engine', val: (r) => r.Engine + ' ' + (r.Version || '') },
      { key: 'Running', label: 'Running', val: (r) => r.Running + '/' + r.Containers }, { key: 'Images', label: 'Images', n: true }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }, { key: 'Message', label: 'Detail', html: (r) => small(r.Message) },
      { key: 'act', label: '', noCsv: true, html: (r) => run('act.containers', { ComputerName: [r.Name], Operation: 'Prune' }, 'Prune…') },
    ], { name: 'docker-hosts', empty: 'No container host read yet. Turn on the Containers engine for Linux hosts that run Docker or Podman.' });
  }
  function dockerContainers(el, k, d) {
    el.innerHTML = MC.panel('Containers', 'state, health check, restarts, CPU and memory', '<div id="dc"></div>');
    MC.table($('#dc', el), d.filter((r) => r.Kind === 'Container'), [
      { key: 'Name', label: 'Container', html: (r) => `<b>${esc(r.Name)}</b><div class="muted mono" style="font-size:11.5px">${esc(r.Image)}</div>` }, { key: 'Host', label: 'Host' },
      { key: 'State', label: 'State', html: (r) => pill(r.State === 'running' ? (r.Health === 'unhealthy' ? 'Warning' : 'OK') : r.Status === 'OK' ? 'Unknown' : r.Status, r.State + (r.Health ? ' · ' + r.Health : '')) },
      { key: 'Restarts', label: 'Restarts', n: true }, { key: 'CPUPct', label: 'CPU', n: true, html: (r) => MC.minibar(r.CPUPct, 85, 97) }, { key: 'MemoryPct', label: 'Memory', n: true, html: (r) => MC.minibar(r.MemoryPct, 85, 95) },
      { key: 'Ports', label: 'Ports', cls: 'mono' }, { key: 'RestartPolicy', label: 'Restart policy' },
      { key: 'act', label: '', noCsv: true, html: (r) => (r.State === 'running' ? run('act.containers', { ComputerName: [r.Host], Operation: 'Restart', Container: r.Name }, 'Restart…') + run('act.containers', { ComputerName: [r.Host], Operation: 'Stop', Container: r.Name }, 'Stop…') : run('act.containers', { ComputerName: [r.Host], Operation: 'Start', Container: r.Name }, 'Start…')) + run('act.containers', { ComputerName: [r.Host], Operation: 'Logs', Container: r.Name }, 'Logs') },
    ], { sort: 'Status', name: 'docker-containers', empty: 'No container read yet.' });
  }
  function k8sActions(el, k) {
    const cl = k.filter((r) => r.Kind === 'Cluster').map((r) => r.Name);
    const acts = [
      ['act.k8s', 'Restart a deployment or stateful set', 'Rolling restart, the same as kubectl rollout restart.', { ComputerName: cl.slice(0, 1), Operation: 'RestartWorkload' }],
      ['act.k8s', 'Scale a workload', 'Set the replica count of a deployment or stateful set.', { ComputerName: cl.slice(0, 1), Operation: 'ScaleWorkload' }],
      ['act.k8s', 'Delete a pod', 'The controller starts a fresh pod.', { ComputerName: cl.slice(0, 1), Operation: 'DeletePod' }],
      ['act.k8s', 'Cordon or uncordon a node', 'Stop or allow new pods on a node before maintenance.', { ComputerName: cl.slice(0, 1), Operation: 'CordonNode' }],
      ['act.containers', 'Start, stop or restart a container', 'Docker or Podman over SSH.', { Operation: 'Restart' }],
      ['act.containers', 'Read container logs', 'The last lines of a container log.', { Operation: 'Logs' }],
      ['act.containers', 'Prune a host', 'Remove stopped containers, dangling images and unused networks.', { Operation: 'Prune' }],
    ];
    el.innerHTML = `${MC.panel('Actions', 'high-risk actions ask you to type the target and are written to the audit log', `<div class="grid g2">${acts.map(([id, t, s, p]) => `<div class="card" style="padding:12px;display:flex;gap:10px;align-items:center"><div style="flex:1"><b>${esc(t)}</b><div class="muted" style="font-size:12.5px">${esc(s)}</div></div>${run(id, p, 'Run…', 'primary') || '<span class="muted" style="font-size:12px">needs operator role</span>'}</div>`).join('')}</div>`)}
      <div class="grid g2">
        ${MC.panel('Alerts in', 'Prometheus Alertmanager, Grafana and Datadog alerts become MonCastle alarms', `<p class="muted" style="margin:0 0 8px;font-size:13px">Point the Alertmanager webhook receiver of each cluster at MonCastle; alerts are matched to the cluster, node or workload device by name.</p><a class="btn sm" href="#/integrations/ingress">${icon('download', 'sev-ico')} Alert integrations</a>`)}
        ${MC.panel('Alarms out', 'send container and Kubernetes alarms to Teams, Slack, PagerDuty, ServiceNow or Jira', `<p class="muted" style="margin:0 0 8px;font-size:13px">Use a notification rule on the group <b>Containers &amp; Kubernetes</b> or on the sensor types Kubernetes cluster, node, workload and container.</p><a class="btn sm" href="#/integrations/egress">${icon('send', 'sev-ico')} Egress integrations</a> <a class="btn sm ghost" href="#/notifications">Notification rules</a>`)}
      </div>`;
  }

  // ================================================================== NETWORK: cloud firewalls, WAF, VPN
  const net = V.network, netRender = net.render;
  // every kind of network device on one page: SNMP devices by class (switches, routers, firewalls, WAF, VPN gateways,
  // wireless controllers and access points, load balancers) next to the cloud firewalls, WAF and VPN of the providers
  const NET_TABS = [['overview', 'Overview'], ['switches', 'Switches & routers'], ['firewalls', 'Firewalls'], ['waf', 'WAF'], ['vpn', 'VPN'], ['clients', 'VPN clients'], ['wireless', 'Wireless'], ['lb', 'Load balancers'], ['discovery', 'Discovery & tools']];
  const NET_OLD = { devices: 'discovery', cloud: 'firewalls' };
  const NCLS = { switches: ['Switch', 'Router', 'Other'], firewalls: ['Firewall'], waf: ['WAF'], vpn: ['VPN gateway'], wireless: ['Wireless controller', 'Access point'], lb: ['Load balancer'] };
  const snmpOf = (tab) => MC.data('network.devices').filter((r) => (NCLS[tab] || []).includes(r.Class || 'Other') || (tab === 'switches' && !r.Class));
  const netActs = (r) => (r.SysName || r.Name ? run('act.net.show', { ComputerName: r.Name, Show: 'Interfaces' }, 'Show…') + run('act.net.config.backup', { ComputerName: r.Name }, 'Back up config…') + (r.DownEnabled ? run('act.net.interface', { ComputerName: r.Name, Interface: String(r.DownList || '').split(',')[0].trim(), Operation: 'Bounce' }, 'Bounce port…') : '') : '');
  const devCell = (r) => `<a href="#" data-host="${esc(r.SysName || r.Name)}">${esc(r.SysName || r.Name)}</a><div class="muted mono" style="font-size:11px">${esc(r.Name)}${r.Vendor && r.Vendor !== 'Other' ? ' · ' + esc(r.Vendor) : ''}</div>`;
  const model = { key: 'Description', label: 'Model / OS', html: (r) => small(String(r.Description || '').slice(0, 70)) };
  const pctCell = (k, label, w, c) => ({ key: k, label, n: true, html: (r) => (r[k] == null ? '–' : MC.minibar(r[k], w, c)) });
  const stCols = [{ key: 'Status', label: 'Status', html: (r) => pill(r.Status) }, { key: 'Message', label: 'Detail', html: (r) => small(r.Message) }, { key: 'act', label: '', noCsv: true, html: netActs }];
  net.render = function (el, route) {
    const tab = NET_OLD[route.tab] || (NET_TABS.some(([t]) => t === route.tab) ? route.tab : 'overview');
    const c = MC.data('network.cloud'), s = MC.data('network.devices');
    const badge = (t) => {
      const n = t === 'vpn' ? cnt(c, (r) => r.Kind === 'VPN tunnel' && r.Status !== 'OK') + sum(snmpOf('vpn').concat(snmpOf('firewalls')).map((r) => r.VpnTunnelsDown)) : t === 'wireless' ? sum(snmpOf('wireless').map((r) => r.APsDown)) : NCLS[t] ? cnt(snmpOf(t), (r) => r.Status === 'Critical') : 0;
      return n ? { s: t === 'vpn' || t === 'wireless' ? 'Critical' : 'Warning', n } : null;
    };
    el.innerHTML = MC.tabs('network', NET_TABS.map(([t, l]) => [t, l, badge(t)]), tab) + '<div id="nTab"></div>';
    const box = $('#nTab', el);
    if (tab === 'discovery') return netRender.call(net, box, route);
    ({ overview: netOverview, switches: netSwitches, firewalls: netFirewalls, waf: netWaf, vpn: netVpn, clients: vpnClients, wireless: netWireless, lb: netLb })[tab](box, c, s);
  };
  function netOverview(el, c, s) {
    const classes = [['Switches', s.filter((r) => r.Class === 'Switch' || !r.Class).length, 'switches'], ['Routers', cnt(s, (r) => r.Class === 'Router'), 'switches'], ['Firewalls', cnt(s, (r) => r.Class === 'Firewall') + cnt(c, (r) => r.Kind === 'Firewall'), 'firewalls'], ['WAF', cnt(s, (r) => r.Class === 'WAF') + cnt(c, (r) => r.Kind === 'WAF'), 'waf'],
      ['VPN gateways', cnt(s, (r) => r.Class === 'VPN gateway') + cnt(c, (r) => r.Kind === 'VPN gateway'), 'vpn'], ['Wireless controllers', cnt(s, (r) => r.Class === 'Wireless controller'), 'wireless'], ['Access points', cnt(s, (r) => r.Class === 'Access point') + sum(s.filter((r) => r.Class === 'Wireless controller').map((r) => r.APs)), 'wireless'], ['Load balancers', cnt(s, (r) => r.Class === 'Load balancer'), 'lb']];
    const tun = sum(s.map((r) => r.VpnTunnels)) + cnt(c, (r) => r.Kind === 'VPN tunnel'), tunDown = sum(s.map((r) => r.VpnTunnelsDown)) + cnt(c, (r) => r.Kind === 'VPN tunnel' && r.Status !== 'OK');
    const problems = s.filter(bad).concat(c.filter((r) => bad(r) && r.Kind !== 'VPN client')).slice(0, 14);
    el.innerHTML = `<div class="kpis">${MC.kpi('Network devices', s.length + c.filter((r) => ['Firewall', 'WAF', 'VPN gateway'].includes(r.Kind)).length, cnt(s, (r) => r.Status === 'Critical') + ' not answering SNMP', { alert: s.some((r) => r.Status === 'Critical') })}${MC.kpi('Interfaces down', sum(s.map((r) => r.DownEnabled)), 'enabled but down', { alert: s.some((r) => r.DownEnabled) })}${MC.kpi('VPN tunnels', (tun - tunDown) + ' / ' + tun, tunDown + ' down', { alert: tunDown > 0 })}${MC.kpi('VPN users', sum(s.map((r) => r.VpnUsers)) + cnt(c, (r) => r.Kind === 'VPN client'), 'connected now')}${MC.kpi('Wireless clients', sum(s.map((r) => r.WifiClients)), sum(s.map((r) => r.APsDown)) + ' access points down', { alert: s.some((r) => r.APsDown) })}</div>
      <div class="grid g-1-2">
        ${MC.panel('Device types', 'SNMP devices and cloud resources', `<div class="grp-cards" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px">${classes.map(([l, n, t]) => `<div class="card" data-href="#/network/${t}" role="button" tabindex="0" style="cursor:pointer;padding:10px 12px"><div class="muted" style="font-size:12px">${esc(l)}</div><b style="font-size:20px">${fmt(n, 0)}</b></div>`).join('')}</div>`)}
        ${MC.panel('Needs attention', 'devices and cloud resources with findings', problems.length ? `<div id="nP"></div>` : '<p class="muted">Every network device and cloud resource is OK.</p>')}
      </div>
      ${MC.panel('Busiest devices', 'CPU and memory from the vendor MIB or HOST-RESOURCES', C.barList(s.filter((r) => r.CpuPct != null).sort((a, b) => b.CpuPct - a.CpuPct).slice(0, 10).map((r) => ({ label: r.SysName || r.Name, sub: (r.Class || '') + ' · ' + (r.Vendor || ''), value: r.CpuPct, text: r.CpuPct + '% CPU' + (r.MemPct != null ? ' · ' + r.MemPct + '% memory' : ''), status: r.CpuPct >= 90 ? 'Critical' : r.CpuPct >= 80 ? 'Warning' : 'OK' })), { max: 100 }), { act: collect('mon.network.devices') })}`;
    if (problems.length) MC.table($('#nP', el), problems, [{ key: 'Name', label: 'Device', html: (r) => (r.Kind ? `<b>${esc(r.Name)}</b><div class="muted" style="font-size:11px">${esc(r.Provider + ' ' + r.Kind)}</div>` : devCell(r)) }, { key: 'Class', label: 'Type', val: (r) => r.Class || r.Kind }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }, { key: 'Message', label: 'Detail', html: (r) => small(r.Message) }], { sort: 'Status', name: 'network-attention' });
  }
  function netSwitches(el, c, s) {
    const r = snmpOf('switches');
    el.innerHTML = `<div class="kpis">${MC.kpi('Switches', cnt(r, (x) => x.Class === 'Switch' || !x.Class), '')}${MC.kpi('Routers', cnt(r, (x) => x.Class === 'Router'), sum(r.map((x) => x.BgpPeers)) + ' BGP peers')}${MC.kpi('BGP peers down', sum(r.map((x) => x.BgpDown)), 'not established', { alert: r.some((x) => x.BgpDown) })}${MC.kpi('Interfaces down', sum(r.map((x) => x.DownEnabled)), 'enabled but down', { alert: r.some((x) => x.DownEnabled) })}${MC.kpi('Input errors', fmt(sum(r.map((x) => x.InErrors)), 0), 'since restart')}</div>
      ${MC.panel('Switches and routers', 'network devices engine (SNMP) · every 10 minutes', '<div id="nsw"></div>', { act: collect('mon.network.devices') })}`;
    MC.table($('#nsw', el), r, [{ key: 'SysName', label: 'Device', html: devCell }, { key: 'Class', label: 'Type', val: (x) => x.Class || 'Switch' }, model, { key: 'Location', label: 'Site' }, { key: 'UptimeDays', label: 'Up days', n: true, html: (x) => (x.UptimeDays == null ? '–' : fmt(x.UptimeDays, 0)) },
      { key: 'Up', label: 'Ports up', n: true, html: (x) => x.Up + ' / ' + x.Interfaces }, { key: 'DownEnabled', label: 'Down', n: true, html: (x) => (x.DownEnabled ? pill('Warning', String(x.DownEnabled)) : '0') }, pctCell('CpuPct', 'CPU', 80, 95), pctCell('MemPct', 'Memory', 85, 95), { key: 'BgpPeers', label: 'BGP', n: true, html: (x) => (x.BgpPeers == null ? '–' : x.BgpDown ? pill('Warning', (x.BgpPeers - x.BgpDown) + ' / ' + x.BgpPeers) : x.BgpPeers + ' up') }].concat(stCols),
      { sort: 'Status', name: 'network-switches', empty: 'No switch or router read yet. Add them with an SNMP credential; the network devices engine reads them every 10 minutes.' });
  }
  function netFirewalls(el, c, s) {
    const r = snmpOf('firewalls');
    el.innerHTML = `<div class="kpis">${MC.kpi('Firewalls', r.length + cnt(c, (x) => x.Kind === 'Firewall'), r.length + ' appliances · ' + cnt(c, (x) => x.Kind === 'Firewall') + ' cloud')}${MC.kpi('Sessions', fmt(sum(r.map((x) => x.Sessions)), 0), 'on the appliances')}${MC.kpi('HA', cnt(r, (x) => x.HaState && !/standalone/i.test(x.HaState)) + ' / ' + r.length, 'in a cluster')}${MC.kpi('With findings', cnt(r, bad) + cnt(c, (x) => x.Kind === 'Firewall' && bad(x)), '', { alert: r.some(bad) })}</div>
      ${MC.panel('Firewall appliances', 'FortiGate, Palo Alto, Check Point, Cisco ASA / Firepower, Sophos, SonicWall and more over SNMP', '<div id="nfw"></div>', { act: collect('mon.network.devices') })}<div id="nfc"></div>`;
    MC.table($('#nfw', el), r, [{ key: 'SysName', label: 'Firewall', html: devCell }, model, { key: 'Location', label: 'Site' }, pctCell('CpuPct', 'CPU', 80, 95), pctCell('MemPct', 'Memory', 85, 95), { key: 'Sessions', label: 'Sessions', n: true, html: (x) => (x.Sessions == null ? '–' : fmt(x.Sessions, 0)) }, { key: 'HaState', label: 'HA' },
      { key: 'VpnTunnels', label: 'VPN tunnels', n: true, html: (x) => (x.VpnTunnels == null ? '–' : x.VpnTunnelsDown ? pill('Warning', (x.VpnTunnels - x.VpnTunnelsDown) + ' / ' + x.VpnTunnels) : x.VpnTunnels + ' up') }, { key: 'VpnUsers', label: 'VPN users', n: true }].concat(stCols), { sort: 'Status', name: 'network-firewalls', empty: 'No firewall appliance read yet.' });
    cloudFw($('#nfc', el), c);
  }
  function netWaf(el, c, s) {
    const r = snmpOf('waf'), w = c.filter((x) => x.Kind === 'WAF');
    el.innerHTML = `<div class="kpis">${MC.kpi('WAF appliances', r.length, 'FortiWeb, Imperva, Barracuda, F5 ASM')}${MC.kpi('Cloud WAF policies', w.length, cnt(w, (x) => /detect|log/i.test(x.Mode || '')) + ' only detecting', { alert: w.some((x) => /detect|log/i.test(x.Mode || '')) })}</div>
      ${MC.panel('WAF appliances', 'over SNMP', '<div id="nwa"></div>', { act: collect('mon.network.devices') })}
      ${MC.panel('Cloud WAF policies', 'Azure WAF, AWS WAF, Google Cloud Armor, OCI WAF, Huawei WAF', '<div id="nwc"></div>', { act: collect('mon.cloud.network') })}`;
    MC.table($('#nwa', el), r, [{ key: 'SysName', label: 'WAF', html: devCell }, model, { key: 'Location', label: 'Site' }, pctCell('CpuPct', 'CPU', 80, 95), pctCell('MemPct', 'Memory', 85, 95), { key: 'Sessions', label: 'Sessions', n: true }].concat(stCols), { sort: 'Status', name: 'network-waf', empty: 'No WAF appliance read yet.' });
    MC.table($('#nwc', el), w, [{ key: 'Name', label: 'WAF policy', html: (x) => `<b>${esc(x.Name)}</b><div class="muted mono" style="font-size:11px">${esc(x.Id || '')}</div>` }].concat(provCols, [{ key: 'Mode', label: 'Mode', html: (x) => (/detect|log/i.test(x.Mode || '') ? pill('Warning', x.Mode) : small(x.Mode)) }, { key: 'Rules', label: 'Rules' }, { key: 'Status', label: 'Status', html: (x) => pill(x.Status) }, { key: 'Message', label: 'Detail', html: (x) => small(x.Message) },
      { key: 'act', label: '', noCsv: true, html: (x) => (x.Provider === 'Azure' ? (/detect/i.test(x.Mode || '') ? run('act.cloud.network', { Provider: 'Azure', Operation: 'SetWafPrevention', ResourceId: x.Id }, 'Set Prevention…') : run('act.cloud.network', { Provider: 'Azure', Operation: 'SetWafDetection', ResourceId: x.Id }, 'Set Detection…')) : '') }]), { sort: 'Status', name: 'cloud-waf2', empty: 'No cloud WAF policy found.' });
  }
  function netVpn(el, c, s) {
    const r = snmpOf('vpn').concat(snmpOf('firewalls').filter((x) => x.VpnTunnels != null || x.VpnUsers != null));
    el.innerHTML = `<div class="kpis">${MC.kpi('On-premises VPN', r.length, 'gateways and firewalls with VPN')}${MC.kpi('Tunnels down', sum(r.map((x) => x.VpnTunnelsDown)), 'site-to-site, appliances', { alert: r.some((x) => x.VpnTunnelsDown) })}${MC.kpi('Remote users', sum(r.map((x) => x.VpnUsers)), 'SSL / IPsec remote access')}</div>
      ${MC.panel('VPN gateways and firewalls', 'site-to-site tunnels and remote-access users read over SNMP', '<div id="nvp"></div>', { act: collect('mon.network.devices') })}<div id="nvc"></div>`;
    MC.table($('#nvp', el), r, [{ key: 'SysName', label: 'Gateway', html: devCell }, { key: 'Class', label: 'Type' }, model, { key: 'VpnTunnels', label: 'Tunnels', n: true, html: (x) => (x.VpnTunnels == null ? '–' : x.VpnTunnelsDown ? pill('Critical', (x.VpnTunnels - x.VpnTunnelsDown) + ' / ' + x.VpnTunnels + ' up') : x.VpnTunnels + ' up') }, { key: 'VpnUsers', label: 'Users', n: true }, pctCell('CpuPct', 'CPU', 80, 95)].concat(stCols), { sort: 'Status', name: 'network-vpn', empty: 'No on-premises VPN gateway read yet.' });
    vpnTunnels($('#nvc', el), c);
  }
  function netWireless(el, c, s) {
    const wlc = snmpOf('wireless').filter((x) => x.Class === 'Wireless controller'), ap = snmpOf('wireless').filter((x) => x.Class !== 'Wireless controller');
    el.innerHTML = `<div class="kpis">${MC.kpi('Controllers', wlc.length, '')}${MC.kpi('Access points', sum(wlc.map((x) => x.APs)) + ap.length, sum(wlc.map((x) => x.APsDown)) + ' down on the controllers', { alert: wlc.some((x) => x.APsDown) })}${MC.kpi('Wireless clients', sum(wlc.map((x) => x.WifiClients)) + sum(ap.map((x) => x.WifiClients)), 'connected now')}</div>
      ${MC.panel('Wireless LAN controllers', 'Cisco Catalyst 9800 / AireOS, Aruba, Huawei AC, Ruckus', '<div id="nwl"></div>', { act: collect('mon.network.devices') })}
      ${MC.panel('Access points', 'read directly over SNMP (standalone or cloud-managed APs)', '<div id="nap"></div>')}`;
    MC.table($('#nwl', el), wlc, [{ key: 'SysName', label: 'Controller', html: devCell }, model, { key: 'Location', label: 'Site' }, { key: 'APs', label: 'Access points', n: true, html: (x) => (x.APs == null ? '–' : x.APsDown ? pill('Warning', (x.APs - x.APsDown) + ' / ' + x.APs + ' up') : x.APs + ' up') }, { key: 'WifiClients', label: 'Clients', n: true }, pctCell('CpuPct', 'CPU', 80, 95), pctCell('MemPct', 'Memory', 85, 95)].concat(stCols), { sort: 'Status', name: 'network-wlc', empty: 'No wireless controller read yet.' });
    MC.table($('#nap', el), ap, [{ key: 'SysName', label: 'Access point', html: devCell }, model, { key: 'Location', label: 'Site' }, { key: 'WifiClients', label: 'Clients', n: true }, { key: 'UptimeDays', label: 'Up days', n: true, html: (x) => (x.UptimeDays == null ? '–' : fmt(x.UptimeDays, 0)) }, pctCell('CpuPct', 'CPU', 80, 95)].concat(stCols.slice(0, 2)), { sort: 'Status', name: 'network-aps', empty: 'No access point read directly.' });
  }
  function netLb(el, c, s) {
    const r = snmpOf('lb');
    el.innerHTML = `<div class="kpis">${MC.kpi('Load balancers', r.length, 'F5, Citrix NetScaler, Kemp, A10')}${MC.kpi('Connections', fmt(sum(r.map((x) => x.LbConnections)), 0), 'client side')}${MC.kpi('Pool members down', sum(r.map((x) => x.PoolMembersDown)), sum(r.map((x) => x.VirtualServersDown)) + ' virtual servers down', { alert: r.some((x) => x.PoolMembersDown || x.VirtualServersDown) })}</div>
      ${MC.panel('Load balancers / ADC', 'over SNMP', '<div id="nlb"></div>', { act: collect('mon.network.devices') })}`;
    MC.table($('#nlb', el), r, [{ key: 'SysName', label: 'Load balancer', html: devCell }, model, { key: 'HaState', label: 'HA' }, { key: 'LbConnections', label: 'Connections', n: true, html: (x) => (x.LbConnections == null ? '–' : fmt(x.LbConnections, 0)) }, { key: 'VirtualServersDown', label: 'Virtual servers down', n: true }, { key: 'PoolMembersDown', label: 'Pool members down', n: true, html: (x) => (x.PoolMembersDown ? pill('Warning', String(x.PoolMembersDown)) : '0') }, pctCell('CpuPct', 'CPU', 80, 95)].concat(stCols), { sort: 'Status', name: 'network-lb', empty: 'No load balancer read yet.' });
  }
  const provCols = [{ key: 'Provider', label: 'Cloud' }, { key: 'Account', label: 'Account' }, { key: 'Region', label: 'Region' }];
  function cloudFw(el, c) {
    const fw = c.filter((r) => r.Kind === 'Firewall'), waf = c.filter((r) => r.Kind === 'WAF'), acct = c.filter((r) => r.Kind === 'Account');
    const provs = [...new Set(c.map((r) => r.Provider).filter(Boolean))];
    el.innerHTML = `<div class="kpis">${MC.kpi('Clouds', provs.length, esc(provs.join(' · ')))}${MC.kpi('Firewalls', fw.length, cnt(fw, bad) + ' with findings', { alert: fw.some((r) => r.Status === 'Critical') })}${MC.kpi('WAF policies', waf.length, cnt(waf, (r) => /detect|log/i.test(r.Mode || '')) + ' only detect', { alert: waf.some(bad) })}${MC.kpi('API errors', acct.length, 'accounts the engine could not read', { alert: acct.length > 0 })}</div>
      ${c.length ? '' : empty('cloud network resource', 'Add a cloud credential (Azure, AWS, Google, Oracle or Huawei) under <a href="#/credentials">Credentials</a>, then turn on the <b>Cloud network</b> engine.')}
      ${acct.length ? `<div class="notice err">${acct.map((r) => esc(r.Provider + ' ' + r.Name + ': ' + r.Message)).join('<br>')}</div>` : ''}
      ${MC.panel('Firewalls', 'Azure Firewall, AWS Network Firewall, Google VPC firewall rules, OCI Network Firewall, Huawei Cloud Firewall', '<div id="cf"></div>', { act: collect('mon.cloud.network') })}
      ${MC.panel('Web application firewalls', 'Azure WAF, AWS WAF, Google Cloud Armor, OCI WAF, Huawei WAF', '<div id="cw"></div>')}`;
    MC.table($('#cf', el), fw, [{ key: 'Name', label: 'Firewall', html: (r) => `<b>${esc(r.Name)}</b><div class="muted mono" style="font-size:11px">${esc(r.Id || '')}</div>` }].concat(provCols, [
      { key: 'State', label: 'State' }, { key: 'Mode', label: 'Policy / mode', html: (r) => small(r.Mode) }, { key: 'Rules', label: 'Rules', n: true }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }, { key: 'Message', label: 'Detail', html: (r) => small(r.Message) },
      { key: 'act', label: '', noCsv: true, html: (r) => (r.Provider === 'Google Cloud' ? run('act.cloud.network', { Provider: r.Provider, Operation: 'DisableFirewallRule', ResourceId: r.Account }, 'Disable rule…') + run('act.cloud.network', { Provider: r.Provider, Operation: 'EnableFirewallRule', ResourceId: r.Account }, 'Enable rule…') : '') },
    ]), { sort: 'Status', name: 'cloud-firewalls', empty: 'No cloud firewall found.' });
    MC.table($('#cw', el), waf, [{ key: 'Name', label: 'WAF policy', html: (r) => `<b>${esc(r.Name)}</b><div class="muted mono" style="font-size:11px">${esc(r.Id || '')}</div>` }].concat(provCols, [
      { key: 'State', label: 'State' }, { key: 'Mode', label: 'Mode', html: (r) => (/detect|log/i.test(r.Mode || '') ? pill('Warning', r.Mode) : small(r.Mode)) }, { key: 'Rules', label: 'Rules' }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }, { key: 'Message', label: 'Detail', html: (r) => small(r.Message) },
      { key: 'act', label: '', noCsv: true, html: (r) => (r.Provider === 'Azure' ? (/detect/i.test(r.Mode || '') ? run('act.cloud.network', { Provider: 'Azure', Operation: 'SetWafPrevention', ResourceId: r.Id }, 'Set Prevention…') : run('act.cloud.network', { Provider: 'Azure', Operation: 'SetWafDetection', ResourceId: r.Id }, 'Set Detection…')) : '') },
    ]), { sort: 'Status', name: 'cloud-waf', empty: 'No WAF policy found.' });
  }
  function vpnTunnels(el, c) {
    const gw = c.filter((r) => r.Kind === 'VPN gateway'), tn = c.filter((r) => r.Kind === 'VPN tunnel');
    el.innerHTML = `<div class="kpis">${MC.kpi('VPN gateways', gw.length, [...new Set(gw.map((r) => r.Provider))].join(' · '))}${MC.kpi('Tunnels up', cnt(tn, (r) => r.Status === 'OK') + ' / ' + tn.length, cnt(tn, (r) => r.Status !== 'OK') + ' down', { alert: tn.some((r) => r.Status !== 'OK') })}${MC.kpi('Traffic in', bytes(sum(tn.map((r) => r.BytesIn))), 'all tunnels')}${MC.kpi('Traffic out', bytes(sum(tn.map((r) => r.BytesOut))), '')}</div>
      ${MC.panel('VPN gateways', 'site-to-site and remote-access endpoints', '<div id="vg"></div>', { act: collect('mon.cloud.network') })}
      ${MC.panel('Tunnels', 'one row per IPsec tunnel', '<div id="vt"></div>')}`;
    MC.table($('#vg', el), gw, [{ key: 'Name', label: 'Gateway', html: (r) => `<b>${esc(r.Name)}</b>` }].concat(provCols, [{ key: 'Address', label: 'Public IP', cls: 'mono' }, { key: 'State', label: 'State' }, { key: 'Mode', label: 'Type', html: (r) => small(r.Mode) }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }, { key: 'Message', label: 'Detail', html: (r) => small(r.Message) }]), { name: 'vpn-gateways', empty: 'No VPN gateway found.' });
    MC.table($('#vt', el), tn, [{ key: 'Name', label: 'Tunnel', html: (r) => `<b>${esc(r.Name)}</b>` }, { key: 'Gateway', label: 'Gateway' }, { key: 'Provider', label: 'Cloud' }, { key: 'Address', label: 'Outside IP', cls: 'mono' }, { key: 'Peer', label: 'Peer', cls: 'mono' },
      { key: 'State', label: 'State', html: (r) => pill(r.Status, r.State) }, { key: 'BytesIn', label: 'In', n: true, html: (r) => bytes(r.BytesIn) }, { key: 'BytesOut', label: 'Out', n: true, html: (r) => bytes(r.BytesOut) }, { key: 'Message', label: 'Detail', html: (r) => small(r.Message) },
      { key: 'act', label: '', noCsv: true, html: (r) => (r.Provider === 'Azure' ? run('act.cloud.network', { Provider: 'Azure', Operation: 'ResetVpnConnection', ResourceId: r.Id }, 'Reset…') : r.Provider === 'AWS' ? run('act.cloud.network', { Provider: 'AWS', Operation: 'ResetVpnConnection', ResourceId: r.Id, Item: r.Address, Region: r.Region }, 'Replace tunnel…') : '') },
    ], { sort: 'State', name: 'vpn-tunnels', empty: 'No VPN tunnel found.' });
  }
  function vpnClients(el, c) {
    const cl = c.filter((r) => r.Kind === 'VPN client'), gws = c.filter((r) => r.Kind === 'VPN gateway');
    const gwOf = (r) => gws.find((g) => g.Name === r.Gateway || g.Id === r.Gateway) || {};
    el.innerHTML = `<div class="kpis">${MC.kpi('Connected clients', cl.length, [...new Set(cl.map((r) => r.Gateway))].length + ' remote-access gateways')}${MC.kpi('Users', new Set(cl.map((r) => lc(r.User))).size, '')}</div>
      ${MC.panel('Connected VPN clients', 'Azure point-to-site, AWS Client VPN and Huawei P2C', '<div id="vc"></div>', { act: collect('mon.cloud.network') })}`;
    MC.table($('#vc', el), cl, [{ key: 'User', label: 'User', html: (r) => `<b>${esc(r.User || r.Name)}</b>` }, { key: 'Gateway', label: 'Gateway' }, { key: 'Provider', label: 'Cloud' }, { key: 'Address', label: 'Public IP', cls: 'mono' }, { key: 'ClientIp', label: 'VPN IP', cls: 'mono' },
      { key: 'ConnectedSince', label: 'Connected', html: (r) => (r.ConnectedSince ? ago(r.ConnectedSince) : '–'), val: (r) => r.ConnectedSince }, { key: 'BytesIn', label: 'In', n: true, html: (r) => bytes(r.BytesIn) },
      { key: 'act', label: '', noCsv: true, html: (r) => (r.Provider === 'Azure' ? run('act.cloud.network', { Provider: 'Azure', Operation: 'DisconnectVpnClient', ResourceId: gwOf(r).Id || '', Item: r.Id }, 'Disconnect…') : r.Provider === 'AWS' ? run('act.cloud.network', { Provider: 'AWS', Operation: 'DisconnectVpnClient', ResourceId: gwOf(r).Id || r.Id, Item: r.User, Region: r.Region }, 'Disconnect…') : '') },
    ], { sort: 'ConnectedSince', name: 'vpn-clients', empty: 'Nobody is connected.' });
  }

  // ================================================================== LINUX: filesystems, services, audit
  const lin = V.linux, linRender = lin.render;
  const LIN_TABS = [['hosts', 'Hosts'], ['filesystems', 'Filesystems'], ['services', 'Services'], ['audit', 'Audit']];
  lin.render = function (el, route) {
    const tab = LIN_TABS.some(([t]) => t === route.tab) ? route.tab : 'hosts';
    el.innerHTML = MC.tabs('linux', LIN_TABS, tab) + '<div id="lTab"></div>';
    const box = $('#lTab', el);
    if (tab === 'hosts') return linRender.call(lin, box, route);
    ({ filesystems: linFs, services: linSvc, audit: linAudit })[tab](box);
  };
  function linFs(el) {
    const r = MC.data('linux.filesystems');
    el.innerHTML = `<div class="kpis">${MC.kpi('Filesystems', r.length, new Set(r.map((x) => x.Name)).size + ' hosts')}${MC.kpi('Over 85 %', cnt(r, (x) => x.UsedPct >= 85), 'space', { alert: r.some((x) => x.UsedPct >= 95) })}${MC.kpi('Inodes over 85 %', cnt(r, (x) => x.InodesPct >= 85), '')}${MC.kpi('Not mounted / read-only', cnt(r, (x) => x.ReadOnly || x.UsedPct == null), 'fstab entries and read-only mounts', { alert: r.some((x) => x.ReadOnly || x.UsedPct == null) })}</div>
      ${MC.panel('Filesystems', 'Linux filesystems engine over SSH · every 15 minutes', '<div id="lf"></div>', { act: collect('mon.linux.filesystems') })}`;
    MC.table($('#lf', el), r, [{ key: 'Name', label: 'Host', html: (x) => `<a href="#" data-host="${esc(x.Name)}">${esc(x.Name)}</a>` }, { key: 'Mount', label: 'Mount', cls: 'mono' }, { key: 'Device', label: 'Device', cls: 'mono' }, { key: 'Type', label: 'Type' }, { key: 'SizeGB', label: 'Size GB', n: true },
      { key: 'UsedPct', label: 'Used', n: true, html: (x) => (x.UsedPct == null ? '–' : MC.minibar(x.UsedPct, 85, 95)) }, { key: 'InodesPct', label: 'Inodes', n: true, html: (x) => (x.InodesPct == null ? '–' : MC.minibar(x.InodesPct, 85, 95)) }, { key: 'Status', label: 'Status', html: (x) => pill(x.Status) }, { key: 'Message', label: 'Detail', html: (x) => small(x.Message) }], { sort: 'UsedPct', dir: -1, name: 'linux-filesystems', empty: 'No filesystem read yet. Turn on the Linux filesystems engine.' });
  }
  function linSvc(el) {
    const r = MC.data('linux.services').filter((x) => x.Kind !== 'Host');
    el.innerHTML = `<div class="kpis">${MC.kpi('Failed units', cnt(r, (x) => x.Kind === 'Failed unit'), 'systemd', { alert: r.some((x) => x.Kind === 'Failed unit') })}${MC.kpi('Watched services stopped', cnt(r, (x) => x.Kind === 'Watched service' && x.Status !== 'OK'), cnt(r, (x) => x.Kind === 'Watched service') + ' watched', { alert: r.some((x) => x.Kind === 'Watched service' && x.Status !== 'OK') })}</div>
      ${MC.panel('Services', 'failed units and watched services (sshd, web servers, databases, kubelet and the ones you name)', '<div id="ls"></div>', { act: collect('mon.linux.services') })}`;
    MC.table($('#ls', el), r, [{ key: 'Name', label: 'Host', html: (x) => `<a href="#" data-host="${esc(x.Name)}">${esc(x.Name)}</a>` }, { key: 'Unit', label: 'Unit', cls: 'mono' }, { key: 'Kind', label: 'Kind' }, { key: 'Active', label: 'Active', val: (x) => x.Active + '/' + x.Sub }, { key: 'Enabled', label: 'Enabled' }, { key: 'Status', label: 'Status', html: (x) => pill(x.Status) }, { key: 'Message', label: 'Detail', html: (x) => small(x.Message) }], { sort: 'Status', name: 'linux-services', empty: 'No service read yet.' });
  }
  function linAudit(el) {
    const r = MC.data('linux.audit');
    el.innerHTML = `<div class="kpis">${MC.kpi('Failed logins', sum(r.map((x) => x.FailedLogins)), 'last 24 h', { alert: r.some((x) => x.FailedLogins >= 100) })}${MC.kpi('Root SSH logins', sum(r.map((x) => x.RootLogins)), cnt(r, (x) => x.PermitRootLogin === 'yes') + ' hosts allow root password logins', { alert: r.some((x) => x.RootLogins) })}${MC.kpi('Refused sudo', sum(r.map((x) => x.SudoFailures)), sum(r.map((x) => x.SudoCommands)) + ' sudo commands')}${MC.kpi('New accounts', sum(r.map((x) => (x.NewUsers || []).length)), '')}${MC.kpi('auditd off', cnt(r, (x) => x.Auditd !== 'active'), '', { alert: r.some((x) => x.Auditd !== 'active') })}</div>
      ${MC.panel('Audit', 'Linux audit engine: journal or auth log, auditd and sshd settings · every 30 minutes', '<div id="la"></div>', { act: collect('mon.linux.audit') })}`;
    MC.table($('#la', el), r, [{ key: 'Name', label: 'Host', html: (x) => `<a href="#" data-host="${esc(x.Name)}">${esc(x.Name)}</a>` }, { key: 'FailedLogins', label: 'Failed logins', n: true }, { key: 'TopSources', label: 'Top sources', html: (x) => `<span class="mono" style="font-size:11.5px">${esc((x.TopSources || []).join(', '))}</span>` },
      { key: 'RootLogins', label: 'Root logins', n: true }, { key: 'SudoFailures', label: 'Refused sudo', n: true }, { key: 'NewUsers', label: 'New accounts', val: (x) => (x.NewUsers || []).join(', ') }, { key: 'Auditd', label: 'auditd', html: (x) => pill(x.Auditd === 'active' ? 'OK' : 'Warning', x.Auditd) }, { key: 'PermitRootLogin', label: 'PermitRootLogin', html: (x) => (x.PermitRootLogin === 'yes' ? pill('Warning', 'yes') : esc(x.PermitRootLogin || '')) },
      { key: 'Status', label: 'Status', html: (x) => pill(x.Status) }], { sort: 'FailedLogins', dir: -1, name: 'linux-audit', empty: 'No audit read yet. Turn on the Linux audit engine (off by default).' });
  }

  // ================================================================== WEB SERVERS
  // the web server software on Windows and Linux hosts, the sites it serves, IIS pools and the certificates
  // the kind of web software (4.7.4): web servers, application servers, gateways and proxies, application runtimes
  const WEB_KIND = { 'Web server': /^(IIS|IIS Express|Apache httpd|nginx|OpenResty|Tengine|LiteSpeed|lighttpd|Caddy|Cherokee|H2O|Hiawatha|Monkey|thttpd|Abyss Web Server|NGINX Unit|Mongoose)/, 'Application server': /Tomcat|TomEE|Jetty|WildFly|JBoss|WebLogic|WebSphere|Liberty|GlassFish|Payara|Resin|Spring Boot|Undertow/, 'Gateway and proxy': /HAProxy|Traefik|Varnish|Envoy|Traffic Server|Kong|Pound/, 'Application runtime': /Node\.js|Deno|Bun|Gunicorn|uWSGI|Uvicorn|Hypercorn|Waitress|Python|Puma|Unicorn|Passenger|PHP|Kestrel/ };
  const webKind = (p) => (Object.entries(WEB_KIND).find(([, re]) => re.test(p || '')) || ['Other'])[0];
  const WEB_TABS = [['overview', 'Overview'], ['servers', 'Web server software'], ['sites', 'Sites & URLs'], ['iis', 'IIS pools'], ['certificates', 'Certificates']];
  V.web = {
    title: 'Web servers',
    crumb: () => new Set(MC.data('web.hosts').filter((x) => x.Product !== 'None').map((x) => x.Name)).size + ' hosts · ' + MC.data('web.servers').length + ' sites · ' + MC.data('ssl.certificates').length + ' TLS endpoints',
    render(el, route) {
      const tab = WEB_TABS.some(([t]) => t === route.tab) ? route.tab : 'overview';
      const h = MC.data('web.hosts').filter((x) => x.Product !== 'None'), w = MC.data('web.servers'), s = MC.data('ssl.certificates'), iis = MC.data('servers.iis');
      const exp = cnt(s, (x) => x.DaysLeft < 30);
      el.innerHTML = MC.tabs('web', WEB_TABS.map(([t, l]) => [t, l, t === 'servers' && cnt(h, bad) ? { s: cnt(h, (x) => x.Status === 'Critical') ? 'Critical' : 'Warning', n: cnt(h, bad) } : t === 'sites' && cnt(w, (x) => x.Status === 'Critical') ? { s: 'Critical', n: cnt(w, (x) => x.Status === 'Critical') } : t === 'certificates' && exp ? { s: 'Warning', n: exp } : null]), tab) + '<div id="wTab"></div>';
      const box = $('#wTab', el);
      const act = (x) => (x.Service ? (/linux/i.test(x.OS || '') ? run('act.lnx.service', { ComputerName: x.Name, ServiceName: String(x.Service).replace(/\.service$/, ''), Operation: 'Restart' }, 'Restart…') : run('act.service', { ComputerName: x.Name, ServiceName: x.Service, Operation: 'Restart' }, 'Restart…')) : '');
      if (tab === 'overview') {
        const prods = Object.entries(h.reduce((a, x) => ((a[x.Product] = (a[x.Product] || 0) + 1), a), {})).sort((a, b) => b[1] - a[1]);
        box.innerHTML = `<div class="kpis">${MC.kpi('Web servers', h.length, new Set(h.map((x) => x.Name)).size + ' hosts · ' + cnt(h, (x) => /linux/i.test(x.OS || '')) + ' on Linux')}${MC.kpi('Not running', cnt(h, (x) => x.Running === false), '', { alert: h.some((x) => x.Running === false) })}${MC.kpi('Config test failed', cnt(h, (x) => x.ConfigOk === false), '', { alert: h.some((x) => x.ConfigOk === false) })}${MC.kpi('Sites down', cnt(w, (x) => x.Status === 'Critical'), w.length + ' checked', { alert: w.some((x) => x.Status === 'Critical') })}${MC.kpi('Certificates < 30 days', exp, s.length + ' endpoints', { alert: exp > 0 })}</div>
          <div class="grid g-1-2">
            ${MC.panel('Software', 'web server products found on the hosts', C.barList(prods.map(([p, n]) => ({ label: p, value: n, text: n + ' host' + (n > 1 ? 's' : ''), status: h.some((x) => x.Product === p && x.Status === 'Critical') ? 'Critical' : h.some((x) => x.Product === p && bad(x)) ? 'Warning' : 'OK' }))))}
            ${MC.panel('Needs attention', 'web servers, sites and certificates', '<div id="wP"></div>')}
          </div>`;
        const att = h.filter(bad).map((x) => ({ What: x.Product + ' on ' + x.Name, Kind: 'Web server', Status: x.Status, Message: x.Message })).concat(w.filter(bad).map((x) => ({ What: x.Url, Kind: 'Site', Status: x.Status, Message: x.Message })), s.filter(bad).map((x) => ({ What: x.Name + ':' + x.Port, Kind: 'Certificate', Status: x.Status, Message: x.Message })));
        MC.table($('#wP', box), att, [{ key: 'What', label: 'What', html: (x) => `<b>${esc(x.What)}</b>` }, { key: 'Kind', label: 'Kind' }, { key: 'Status', label: 'Status', html: (x) => pill(x.Status) }, { key: 'Message', label: 'Detail', html: (x) => small(x.Message) }], { sort: 'Status', name: 'web-attention', empty: 'Every web server, site and certificate is OK.' });
      } else if (tab === 'servers') {
        const wk = (route.q || {}).kind || '', kinds = [...new Set(h.map((x) => webKind(x.Product)))].sort();
        const hl = h.filter((x) => !wk || webKind(x.Product) === wk);
        box.innerHTML = `<div class="mfilter env-chips" role="group" aria-label="Kind"><button class="btn sm ${!wk ? 'on' : ''}" data-href="#/web/servers">All <span class="muted">${h.length}</span></button>${kinds.map((k) => `<button class="btn sm ${k === wk ? 'on' : ''}" data-href="#/web/servers?kind=${encodeURIComponent(k)}">${esc(k)} <span class="muted">${cnt(h, (x) => webKind(x.Product) === k)}</span></button>`).join('')}</div>` + MC.panel('Web server software', 'every web server, application server, gateway and runtime on Windows and Linux: IIS, Apache, nginx, LiteSpeed, Tomcat, Jetty, WildFly, WebLogic, WebSphere, GlassFish, Node.js, Gunicorn, PHP-FPM, Kestrel and more', '<div id="wh"></div>', { act: collect('mon.web.hosts') });
        MC.table($('#wh', box), hl, [{ key: 'Name', label: 'Host', html: (x) => `<a href="#" data-host="${esc(x.Name)}">${esc(x.Name)}</a><div class="muted" style="font-size:11px">${esc(x.OS || '')}</div>` }, { key: 'kind', label: 'Kind', val: (x) => webKind(x.Product) }, { key: 'Product', label: 'Software', html: (x) => `<b>${esc(x.Product)}</b>${x.Version ? ' <span class="muted">' + esc(x.Version) + '</span>' : ''}` }, { key: 'Service', label: 'Service', cls: 'mono' },
          { key: 'Running', label: 'Running', html: (x) => (x.Running == null ? '–' : pill(x.Running ? 'OK' : x.Enabled === false ? 'Warning' : 'Critical', x.Running ? 'Running' : 'Stopped')) }, { key: 'Ports', label: 'Ports', cls: 'mono' }, { key: 'Sites', label: 'Sites', n: true, html: (x) => (x.Sites == null ? '–' : x.SitesStopped ? pill('Warning', x.Sites + ' (' + x.SitesStopped + ' stopped)') : String(x.Sites)) }, { key: 'Connections', label: 'Connections', n: true }, { key: 'RequestsPerSec', label: 'Req/s', n: true },
          { key: 'BusyWorkers', label: 'Workers', n: true, html: (x) => (x.Workers == null ? '–' : x.BusyWorkers == null ? String(x.Workers) : x.BusyWorkers + ' / ' + x.Workers) }, { key: 'ConfigOk', label: 'Config test', html: (x) => (x.ConfigOk == null ? '–' : x.ConfigOk ? pill('OK', 'OK') : `<span title="${esc(x.ConfigMessage || '')}">${pill('Warning', 'Failed')}</span>`) }, { key: 'Errors', label: 'Errors 1 h', n: true },
          { key: 'Status', label: 'Status', html: (x) => pill(x.Status) }, { key: 'Message', label: 'Detail', html: (x) => small(x.ConfigOk === false && x.ConfigMessage ? x.ConfigMessage : x.Message) }, { key: 'act', label: '', noCsv: true, html: act }], { sort: 'Status', name: 'web-hosts', empty: 'No web server software read yet. Turn on the Web server software engine and give it Windows (WinRM) or Linux (SSH) hosts.' });
      } else if (tab === 'sites') {
        box.innerHTML = MC.panel('Sites & URLs', 'status, response time, redirects, server software and page content', '<div id="ws"></div>', { act: collect('mon.web.servers') });
        MC.table($('#ws', box), w, [{ key: 'Url', label: 'Site', html: (x) => `<b>${esc(x.Name)}</b><div class="muted mono" style="font-size:11.5px">${esc(x.Url)}</div>` }, { key: 'StatusCode', label: 'HTTP', n: true, html: (x) => pill(x.StatusCode >= 500 || x.StatusCode == null ? 'Critical' : x.StatusCode >= 400 ? 'Warning' : 'OK', String(x.StatusCode == null ? '–' : x.StatusCode)) },
          { key: 'ResponseMs', label: 'Response ms', n: true }, { key: 'ServerKind', label: 'Server', val: (x) => x.Server || x.ServerKind }, { key: 'Redirects', label: 'Redirects', n: true }, { key: 'SizeKB', label: 'KB', n: true }, { key: 'Status', label: 'Status', html: (x) => pill(x.Status) }, { key: 'Message', label: 'Detail', html: (x) => small(x.Message) }], { sort: 'Status', name: 'web-servers', empty: 'No site checked yet.' });
      } else if (tab === 'iis') {
        box.innerHTML = MC.panel('IIS application pools and sites', 'IIS engine on Windows web servers', '<div id="wi"></div>', { act: collect('mon.iis') });
        MC.table($('#wi', box), iis, [{ key: 'ComputerName', label: 'Server', html: (x) => `<a href="#" data-host="${esc(x.ComputerName)}">${esc(x.ComputerName)}</a>` }, { key: 'Pool', label: 'Pool' }, { key: 'State', label: 'State', html: (x) => pill(x.State === 'Started' ? 'OK' : 'Warning', x.State) }, { key: 'Runtime', label: 'CLR' }, { key: 'Identity', label: 'Identity' }, { key: 'Sites', label: 'Sites', val: (x) => [].concat(x.Sites || []).join(', ') }], { sort: 'State', name: 'web-iis', empty: 'No IIS server read yet.' });
      } else {
        box.innerHTML = MC.panel('Certificates', 'certificate audit engine: expiry, chain trust, names, key size, protocol', '<div id="wc"></div>', { act: collect('mon.ssl.certificates') });
        MC.table($('#wc', box), s, [{ key: 'Name', label: 'Endpoint', html: (x) => `<b>${esc(x.Name)}:${x.Port}</b><div class="muted" style="font-size:11.5px">${esc(x.Subject || '')}</div>` }, { key: 'Issuer', label: 'Issuer', html: (x) => small(x.Issuer) },
          { key: 'DaysLeft', label: 'Days left', n: true, html: (x) => pill(x.DaysLeft < 7 ? 'Critical' : x.DaysLeft < 30 ? 'Warning' : 'OK', String(x.DaysLeft)) }, { key: 'Trusted', label: 'Trusted', val: (x) => (x.Trusted ? 'Yes' : 'No') }, { key: 'NameMatch', label: 'Name match', val: (x) => (x.NameMatch ? 'Yes' : 'No') },
          { key: 'KeyBits', label: 'Key', n: true }, { key: 'Protocol', label: 'Protocol' }, { key: 'NotAfter', label: 'Expires', val: (x) => String(x.NotAfter || '').slice(0, 10) }, { key: 'Status', label: 'Status', html: (x) => pill(x.Status) }, { key: 'Message', label: 'Detail', html: (x) => small(x.Message) }], { sort: 'DaysLeft', name: 'web-certs' });
      }
    },
  };

  // ================================================================== DATABASES
  // every database in one place: SQL Server, every engine of the database catalog (sensors.js DB_ENGINES: relational,
  // distributed SQL, warehouses, document, key-value, wide-column, search, time series, graph, vector) and the managed
  // databases of Azure, AWS, Google, Oracle and Huawei
  const DB_TABS = [['overview', 'Overview'], ['sqlserver', 'SQL Server'], ['relational', 'Relational & analytics'], ['nosql', 'Document & key-value'], ['specialty', 'Search, time series & graph'], ['cloud', 'Cloud databases'], ['actions', 'Actions & integrations']];
  const DB_GROUP = { relational: ['Relational', 'Distributed SQL', 'Data warehouse', 'Analytics'], nosql: ['Document', 'Multi-model', 'Key-value', 'In-memory grid', 'Wide-column'], specialty: ['Search', 'Time series', 'Graph', 'Vector'] };
  const DB_TITLE = { relational: ['Relational and analytics engines', 'relational, distributed SQL, warehouse and analytics: Oracle, PostgreSQL, MySQL, MariaDB, Db2, SAP HANA and ASE, Informix, Teradata, CockroachDB, YugabyteDB, TiDB, Greenplum, Vertica, ClickHouse, Trino and more'],
    nosql: ['Document and key-value engines', 'document, key-value, in-memory grid and wide-column: MongoDB, CouchDB, Couchbase, RavenDB, ArangoDB, Redis, Valkey, Memcached, Aerospike, etcd, Hazelcast, Cassandra, ScyllaDB, HBase and more · Amazon DocumentDB, Cosmos DB for MongoDB and Huawei DDS are read as MongoDB'],
    specialty: ['Search, time series and graph', 'search, time series, graph and vector: Elasticsearch, OpenSearch, Solr, InfluxDB, TimescaleDB, Prometheus, VictoriaMetrics, Neo4j, Memgraph, TigerGraph, Qdrant, Weaviate, Milvus and more'] };
  const dbInfo = (e) => ((root.MCSensors && root.MCSensors.DB_ENGINE) || {})[e] || null;
  const ENG = new Proxy({}, { get: (_, e) => (dbInfo(e) || {}).name || e });
  const dbCat = (x) => x.Category || (dbInfo(x.Engine) || {}).category || 'Other';
  const dbTab = (x) => Object.keys(DB_GROUP).find((t) => DB_GROUP[t].includes(dbCat(x))) || 'nosql';
  const dbAct = (x) => {
    const ops = String(x.Actions || '').split(',').filter(Boolean);
    return ops.map((o) => run('act.cloud.db', { Provider: x.Provider, Service: x.Service, Id: x.Id, Region: /^[a-z0-9-]+$/.test(x.Region || '') ? x.Region : '', Operation: o }, o + '…')).join('');
  };
  V.databases = {
    title: 'Databases',
    crumb: () => { const n = MC.data('sql.databases').length + MC.data('databases.health').length + MC.data('cloud.databases').filter((x) => x.Service !== 'Account').length; return n + ' databases and instances · SQL Server, every engine from relational to vector, and cloud'; },
    render(el, route) {
      const tab = DB_TABS.some(([t]) => t === route.tab) ? route.tab : 'overview';
      const sql = MC.data('sql.databases'), eng = MC.data('databases.health'), cl = MC.data('cloud.databases').filter((x) => x.Service !== 'Account'), clErr = MC.data('cloud.databases').filter((x) => x.Service === 'Account');
      const byTab = { relational: eng.filter((x) => dbTab(x) === 'relational'), nosql: eng.filter((x) => dbTab(x) === 'nosql'), specialty: eng.filter((x) => dbTab(x) === 'specialty') };
      const clDoc = cl.filter((x) => ['Document', 'Key-value', 'Wide-column'].includes(x.Category));
      const sqlBad = cnt(sql, (x) => (x.Problems || []).length), b = (n, s) => (n ? { s: s || 'Warning', n } : null);
      el.innerHTML = MC.tabs('databases', DB_TABS.map(([t, l]) => [t, l, t === 'sqlserver' ? b(sqlBad) : byTab[t] ? b(cnt(byTab[t], bad) + (t === 'nosql' ? cnt(clDoc, bad) : 0), byTab[t].some((x) => x.Status === 'Down') ? 'Critical' : 'Warning') : t === 'cloud' ? b(cnt(cl, bad), cl.some((x) => x.Status === 'Critical') ? 'Critical' : 'Warning') : null]), tab) + '<div id="dTab"></div>';
      const box = $('#dTab', el);
      const engCols = [{ key: 'Host', label: 'Server', html: (x) => `<a href="#" data-host="${esc(x.Host)}">${esc(x.Host)}</a><div class="muted mono" style="font-size:11px">${esc((x.Address || '') + ':' + (x.Port || ''))}</div>` }, { key: 'Engine', label: 'Engine', val: (x) => x.Product || ENG[x.Engine], html: (x) => `${esc(x.Product || ENG[x.Engine])}<div class="muted" style="font-size:11px">${esc(dbCat(x))}</div>` }, { key: 'Version', label: 'Version', html: (x) => small(x.Version) }, { key: 'Instance', label: 'Instance' }, { key: 'Role', label: 'Role', html: (x) => small(x.Role) },
        { key: 'ConnectionsPct', label: 'Connections', n: true, html: (x) => (x.ConnectionsPct == null ? (x.Connections == null ? '–' : String(x.Connections)) : MC.minibar(x.ConnectionsPct, 85, 95)) }, { key: 'SizeGB', label: 'Size GB', n: true, html: (x) => (x.SizeGB == null ? '–' : fmt(x.SizeGB, 0)) }, { key: 'ReplicationLagSec', label: 'Lag s', n: true }, { key: 'CacheHitPct', label: 'Cache hit %', n: true },
        { key: 'LastBackupHours', label: 'Backup h', n: true, html: (x) => (x.LastBackupHours == null ? '–' : x.LastBackupHours > 26 ? pill('Warning', fmt(x.LastBackupHours, 0)) : fmt(x.LastBackupHours, 0)) }, { key: 'ResponseMs', label: 'Answer ms', n: true }, { key: 'CheckedBy', label: 'Read by', html: (x) => small(x.CheckedBy || '') },
        { key: 'Status', label: 'Status', html: (x) => pill(x.Status === 'Down' ? 'Critical' : x.Status) }, { key: 'Problems', label: 'Detail', html: (x) => small(x.Error || (x.Problems || []).join(', ') || x.Note || '') }];
      const clCols = [{ key: 'Name', label: 'Database', html: (x) => `<b>${esc(x.Name)}</b><div class="muted" style="font-size:11px">${esc(x.Service)}</div>` }, { key: 'Provider', label: 'Cloud' }, { key: 'Region', label: 'Region' }, { key: 'Engine', label: 'Engine' }, { key: 'Version', label: 'Version' }, { key: 'Tier', label: 'Tier', html: (x) => small(x.Tier) },
        { key: 'State', label: 'State', html: (x) => pill(x.Running === false ? (/stop|paus/i.test(x.State || '') ? 'Warning' : 'Critical') : 'OK', x.State) }, { key: 'CpuPct', label: 'CPU', n: true, html: (x) => (x.CpuPct == null ? '–' : MC.minibar(x.CpuPct, 80, 95)) }, { key: 'UsedPct', label: 'Storage', n: true, html: (x) => (x.UsedPct == null ? (x.StorageGB == null ? '–' : fmt(x.StorageGB, 0) + ' GB') : MC.minibar(x.UsedPct, 85, 95)) },
        { key: 'HighAvailability', label: 'High availability', html: (x) => small(x.HighAvailability) }, { key: 'BackupDays', label: 'Backups', n: true, html: (x) => (x.BackupDays == null ? '–' : x.BackupDays === 0 ? pill('Warning', 'none') : fmt(x.BackupDays, 0) + ' d') }, { key: 'PublicAccess', label: 'Public', html: (x) => (x.PublicAccess ? pill('Warning', 'Yes') : 'No') },
        { key: 'Status', label: 'Status', html: (x) => pill(x.Status) }, { key: 'Message', label: 'Detail', html: (x) => small(x.Message) }, { key: 'act', label: '', noCsv: true, html: dbAct }];
      if (tab === 'overview') {
        const all = [['SQL Server', new Set(sql.map((x) => x.Instance)).size, sql.length + ' databases', 'sqlserver']].concat(Object.entries(eng.reduce((a, x) => { const k = x.Product || ENG[x.Engine]; (a[k] = a[k] || { n: 0, t: dbTab(x), c: dbCat(x) }).n++; return a; }, {})).sort((p, q) => q[1].n - p[1].n).map(([e, v]) => [e, v.n, v.c, v.t + '?cat=' + encodeURIComponent(v.c)]), [['Cloud', cl.length, [...new Set(cl.map((x) => x.Provider))].join(' · '), 'cloud']]);
        const engCats = Object.values(DB_GROUP).flat().map((k) => [k, cnt(eng, (x) => dbCat(x) === k)]).filter((x) => x[1]);
        const cats = ['SQL PaaS', 'Open-source PaaS', 'Document', 'Key-value', 'Wide-column'].map((k) => [k, cnt(cl, (x) => x.Category === k)]).filter((x) => x[1]);
        const att = sql.filter((x) => (x.Problems || []).length).map((x) => ({ What: x.Instance + ' / ' + x.Database, Kind: 'SQL Server', Status: 'Warning', Message: (x.Problems || []).join(', ') })).concat(eng.filter(bad).map((x) => ({ What: x.Host + ' (' + (ENG[x.Engine] || x.Engine) + ')', Kind: 'Engine', Status: x.Status === 'Down' ? 'Critical' : x.Status, Message: x.Error || (x.Problems || []).join(', ') })), cl.filter(bad).map((x) => ({ What: x.Name, Kind: x.Provider + ' ' + x.Service, Status: x.Status, Message: x.Message })));
        box.innerHTML = `<div class="kpis">${MC.kpi('SQL Server', new Set(sql.map((x) => x.Instance)).size + ' instances', sql.length + ' databases')}${MC.kpi('Engines', eng.length, new Set(eng.map((x) => x.Product || x.Engine)).size + ' products · ' + engCats.length + ' categories', { alert: eng.some((x) => x.Status === 'Down') })}${MC.kpi('Cloud databases', cl.length, cnt(cl, (x) => x.Running === false) + ' not running', { alert: cl.some((x) => x.Status === 'Critical') })}${MC.kpi('Backup problems', sqlBad + cnt(eng, (x) => x.LastBackupHours > 26) + cnt(cl, (x) => x.BackupDays === 0), 'missing or stale', { alert: sqlBad > 0 })}${MC.kpi('Public endpoints', cnt(cl, (x) => x.PublicAccess), 'cloud databases open to the internet', { alert: cl.some((x) => x.PublicAccess) })}</div>
          ${clErr.length ? `<div class="notice err">${clErr.map((x) => esc(x.Provider + ' ' + x.Name + ': ' + x.Message)).join('<br>')}</div>` : ''}
          <div class="grid g-1-2">
            ${MC.panel('Database types', 'instances and databases by engine', `<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px">${all.map(([l, n, sub, t]) => `<div class="card" data-href="#/databases/${t}" role="button" tabindex="0" style="cursor:pointer;padding:10px 12px;min-width:0"><div class="muted" style="font-size:12px">${esc(l)}</div><b style="font-size:20px">${fmt(n, 0)}</b><div class="muted" style="font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(sub)}</div></div>`).join('')}</div>`)}
            <div class="grid">${MC.panel('Engines by category', eng.length + ' instances', engCats.length ? C.barList(engCats.map(([k, n]) => ({ label: k, value: n, text: String(n) }))) : '<p class="muted">No database engine read yet.</p>')}
            ${MC.panel('Cloud databases by kind', cl.length + ' managed databases', cats.length ? C.barList(cats.map(([k, n]) => ({ label: k, value: n, text: String(n) }))) : '<p class="muted">No cloud database read yet.</p>')}</div>
          </div>
          ${MC.panel('Needs attention', 'SQL Server, engines and cloud databases', '<div id="dP"></div>')}`;
        MC.table($('#dP', box), att, [{ key: 'What', label: 'Database', html: (x) => `<b>${esc(x.What)}</b>` }, { key: 'Kind', label: 'Kind' }, { key: 'Status', label: 'Status', html: (x) => pill(x.Status) }, { key: 'Message', label: 'Detail', html: (x) => small(x.Message) }], { sort: 'Status', name: 'db-attention', empty: 'Every database is OK.' });
      } else if (tab === 'sqlserver') {
        if (MC.MON && MC.MON.sql) MC.MON.sql(box); else box.innerHTML = empty('SQL Server data', 'Turn on the SQL Server engines.');
      } else if (byTab[tab]) {
        const cats = DB_GROUP[tab].filter((k) => byTab[tab].some((x) => dbCat(x) === k)), cat = cats.includes((route.q || {}).cat) ? route.q.cat : '';
        const list = byTab[tab].filter((x) => !cat || dbCat(x) === cat), [title, sub] = DB_TITLE[tab];
        const chips = cats.length > 1 ? `<div class="mfilter env-chips" role="group" aria-label="Category"><button class="btn sm ${!cat ? 'on' : ''}" data-href="#/databases/${tab}">All <span class="muted">${byTab[tab].length}</span></button>${cats.map((k) => `<button class="btn sm ${k === cat ? 'on' : ''}" data-href="#/databases/${tab}?cat=${encodeURIComponent(k)}">${esc(k)} <span class="muted">${cnt(byTab[tab], (x) => dbCat(x) === k)}</span></button>`).join('')}</div>` : '';
        box.innerHTML = `${chips}${MC.panel(cat ? cat + ' engines' : title, 'database engine: reachability and answer time for every engine, plus connections, size, replication, cache, slow queries and backups where the engine exposes them · ' + sub, '<div id="dE"></div>', { act: collect('mon.databases') })}
          ${tab === 'nosql' ? MC.panel('Cloud document and key-value databases', 'Cosmos DB, DocumentDB, DynamoDB, Firestore, Oracle NoSQL and JSON, Huawei DDS, Azure Cache for Redis', '<div id="dC"></div>', { act: collect('mon.cloud.databases') }) : ''}`;
        MC.table($('#dE', box), list, engCols, { sort: 'Status', name: 'db-' + tab, empty: 'No ' + (cat || title.replace(/ engines$/, '')).toLowerCase() + ' database read yet. Add the server as a Database device with its engine and a Database credential, then add it to the targets of the Database engines collector.' });
        if (tab === 'nosql') MC.table($('#dC', box), clDoc, clCols, { sort: 'Status', name: 'db-cloud-nosql', empty: 'No cloud document or key-value database found.' });
      } else if (tab === 'cloud') {
        const provs = [...new Set(cl.map((x) => x.Provider))];
        box.innerHTML = `<div class="kpis">${provs.map((p) => MC.kpi(p, cnt(cl, (x) => x.Provider === p), cnt(cl, (x) => x.Provider === p && bad(x)) + ' with findings', { alert: cl.some((x) => x.Provider === p && x.Status === 'Critical') })).join('')}</div>
          ${clErr.length ? `<div class="notice err">${clErr.map((x) => esc(x.Provider + ' ' + x.Name + ': ' + x.Message)).join('<br>')}</div>` : ''}
          ${cl.length ? '' : empty('cloud database', 'Add a cloud credential (Azure, AWS, Google, Oracle or Huawei) under <a href="#/credentials">Credentials</a>, then turn on the <b>Cloud databases</b> engine.')}
          ${MC.panel('Cloud databases', 'Azure SQL, Managed Instance, PostgreSQL, MySQL, Cosmos DB, Redis · AWS RDS, Aurora, DocumentDB, DynamoDB · Cloud SQL, Spanner, Firestore · Oracle Autonomous, Base Database, MySQL HeatWave, NoSQL · Huawei RDS, GaussDB, DDS', '<div id="dCl"></div>', { act: collect('mon.cloud.databases') })}`;
        MC.table($('#dCl', box), cl, clCols, { sort: 'Status', name: 'db-cloud' });
      } else {
        const engines = ['mon.cloud.databases', 'mon.databases', 'inv.sql', 'mon.sql.databases'].map((id) => MC.script(id)).filter(Boolean);
        box.innerHTML = `${MC.panel('Actions', 'every action asks for confirmation and is written to the audit log', `<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:10px">
            <div class="card" style="padding:12px"><b>Cloud database</b><p class="muted" style="font-size:12.5px">Start, stop, restart or fail over a managed database in Azure, AWS, Google Cloud, Oracle Cloud or Huawei Cloud. Pick the database on the Cloud databases tab.</p>${run('act.cloud.db', {}, 'Open…', 'primary')}</div>
            <div class="card" style="padding:12px"><b>Database server service</b><p class="muted" style="font-size:12.5px">Restart the database service on a Windows server (SQL Server, Oracle, PostgreSQL) or a Linux host.</p>${run('act.service', { Operation: 'Restart' }, 'Windows service…')}${run('act.lnx.service', { Operation: 'Restart' }, 'Linux service…')}</div>
          </div>`)}
          ${MC.panel('Engines', 'collectors that fill this page', `<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Engine</th><th>Schedule</th><th></th></tr></thead><tbody>${engines.map((x) => `<tr><td><b>${esc(x.title)}</b><div class="muted" style="font-size:11.5px">${esc(x.id)}</div></td><td>${esc(x.schedule || 'on demand')}</td><td style="text-align:right"><a class="btn sm ghost" href="#/engines/${esc(x.id)}">Open</a></td></tr>`).join('')}</tbody></table></div>`)}
          ${MC.panel('Integrations', 'where database alarms go', '<p class="muted" style="font-size:13px">Database sensors raise alarms like every other sensor: notification rules (<a href="#/notifications">Notifications</a>) send them by e-mail, Teams, Slack or webhook, and outgoing integrations (<a href="#/integrations">Integrations</a>) open tickets in ServiceNow or Jira or forward them to Splunk and syslog. Cloud credentials live in <a href="#/credentials">Credentials</a>.</p>')}`;
      }
    },
  };

  // ================================================================== ENTRA ID & INTUNE
  const EN_TABS = [['overview', 'Overview'], ['users', 'Users'], ['devices', 'Entra devices'], ['groups', 'Groups'], ['intune', 'Intune devices'], ['policies', 'Policies & apps'], ['actions', 'Actions & integrations']];
  const yes = (v) => (v == null ? '–' : v ? 'Yes' : 'No');
  V.entra = {
    title: 'Entra ID & Intune',
    crumb: () => MC.data('entra.users').length + ' cloud users · ' + MC.data('entra.devices').length + ' Entra devices · ' + MC.data('intune.devices').length + ' Intune managed devices',
    render(el, route) {
      const tab = EN_TABS.some(([t]) => t === route.tab) ? route.tab : 'overview';
      const u = MC.data('entra.users'), dv = MC.data('entra.devices'), g = MC.data('entra.groups'), h = MC.data('entra.health'), it = MC.data('intune.devices'), ih = MC.data('intune.health');
      const nc = cnt(it, (x) => x.Compliance !== 'compliant' && x.Compliance !== 'inGracePeriod');
      el.innerHTML = MC.tabs('entra', EN_TABS.map(([t, l]) => (t === 'intune' && nc ? [t, l, { s: 'Warning', n: nc }] : [t, l])), tab) + '<div id="eTab" class="grid"></div>';
      const box = $('#eTab', el), q = (route.q || {}).q || '';
      ({ overview: enOverview, users: enUsers, devices: enDevices, groups: enGroups, intune: inDevices, policies: inPolicies, actions: enActions })[tab](box, { u, dv, g, h, it, ih, q });
    },
  };
  function enOverview(el, c) {
    const ten = c.h.find((r) => r.Kind === 'Tenant') || {}, on = c.u.filter((r) => r.Enabled), sm = c.ih.find((r) => r.Kind === 'Summary') || {};
    const creds = c.h.filter((r) => r.Kind === 'App credential'), lic = c.h.filter((r) => r.Kind === 'Licence'), si = c.h.find((r) => r.Kind === 'Sign-ins'), ca = c.h.find((r) => r.Kind === 'Conditional access'), ga = c.h.find((r) => r.Kind === 'Privileged roles');
    const none = !c.u.length && !c.h.length && !c.it.length;
    el.innerHTML = `${none ? empty('Entra ID or Intune data', 'Register an app in Entra ID (App registrations), give it the Graph application permissions listed on each engine (User.Read.All, Device.Read.All, DeviceManagementManagedDevices.Read.All and more) with admin consent, add a client secret, then save it under <a href="#/credentials">Credentials</a> as a Cloud provider credential with provider Azure, the tenant ID and the client ID. Turn on the Entra ID and Intune engines under <a href="#/engines">Monitoring engines</a>.') : ''}
      <div class="kpis">${MC.kpi('Tenant', esc(ten.TenantName || ten.Name || '–'), ten.SyncEnabled ? 'directory sync ' + fmt(ten.SyncAgeHours, 1) + ' h ago' : ten.Name ? 'cloud only' : '', { alert: ten.SyncAgeHours >= 3 || ten.Status === 'Critical' })}${MC.kpi('Users', on.length, cnt(c.u, (r) => r.UserType === 'Guest') + ' guests · ' + cnt(on, (r) => r.Stale) + ' stale', { href: '#/entra/users' })}${MC.kpi('Without MFA', cnt(on, (r) => r.MfaRegistered === false), cnt(on, (r) => r.Admin && r.MfaRegistered === false) + ' of them admins', { alert: on.some((r) => r.Admin && r.MfaRegistered === false), href: '#/entra/users' })}${MC.kpi('Users at risk', cnt(on, (r) => r.Risk), cnt(on, (r) => r.Risk === 'high') + ' high', { alert: on.some((r) => r.Risk === 'high') })}${MC.kpi('Failed sign-ins', si ? si.Failed : '–', si ? 'last 24 h' : 'needs Entra ID P1')}${MC.kpi('Intune devices', c.it.length, nc(c.it) + ' not compliant · ' + cnt(c.it, (r) => r.DaysSinceSync > 7) + ' not checked in for 7 days', { alert: nc(c.it) > 0, href: '#/entra/intune' })}</div>
      <div class="grid g3">
        ${MC.panel('App secrets and certificates', 'app registrations whose credentials expire within 60 days', C.barList(creds.sort((a, b) => a.DaysLeft - b.DaysLeft).slice(0, 8).map((r) => ({ label: r.Name, sub: r.Type + ' · ' + (r.Item || ''), value: Math.max(1, 60 - r.DaysLeft), text: r.DaysLeft < 0 ? 'expired' : r.DaysLeft + ' d', status: r.Status !== 'OK' ? r.Status : null, color: '--s1' })), { compact: true, max: 64 }) || '<p class="muted">Nothing expires soon.</p>')}
        ${MC.panel('Licences', 'assigned of available', C.barList(lic.map((r) => ({ label: r.Name, value: r.UsedPct, text: r.Consumed + ' / ' + r.Available, status: r.Status !== 'OK' ? r.Status : null, color: '--s2' })), { max: 100, compact: true }))}
        ${MC.panel('Devices by platform', 'Intune managed devices', '<div id="enOs"></div>')}
      </div>
      <div class="grid g2">
        ${MC.panel('Sign-ins and access', '', `<dl class="kv"><dt>Failed sign-ins</dt><dd>${si ? `<b>${si.Failed}</b> in 24 h · ${esc((si.TopReasons || []).join(' · '))}` : '<span class="muted">not read (needs AuditLog.Read.All and Entra ID P1)</span>'}</dd><dt>Most failures</dt><dd>${si ? esc((si.TopUsers || []).join(', ')) : '–'}</dd><dt>Countries</dt><dd>${si ? esc((si.TopCountries || []).join(', ')) : '–'}</dd><dt>Global Administrators</dt><dd>${ga ? pill(ga.Status, String(ga.Members)) + ' ' + esc((ga.Users || []).join(', ')) : '–'}</dd><dt>Conditional Access</dt><dd>${ca ? esc(ca.Message) : '<span class="muted">not read (Policy.Read.All)</span>'}</dd></dl>`)}
        ${MC.panel('Intune service', sm.Message ? esc(sm.Message) : '', `<dl class="kv"><dt>Compliance</dt><dd>${sm.Enrolled != null ? `${sm.Compliant} compliant · ${sm.NonCompliant} not compliant · ${sm.InGrace || 0} in grace period` : '–'}</dd><dt>Autopilot</dt><dd>${sm.Autopilot != null ? sm.Autopilot + ' registered devices' : '–'}</dd>${c.ih.filter((r) => r.Kind === 'Connector').map((r) => `<dt>${esc(r.Name)}</dt><dd>${pill(r.Status, r.Message)}</dd>`).join('')}<dt>Policies with errors</dt><dd>${cnt(c.ih, (r) => /policy|profile/.test(r.Kind) && r.Status !== 'OK')} of ${cnt(c.ih, (r) => /policy|profile/.test(r.Kind))} <a href="#/entra/policies">details</a></dd></dl>`)}
      </div>
      ${MC.panel('Problems now', 'tenant health findings', '<div id="enProb"></div>', { act: collect('mon.entra.health', 'Check tenant now…') })}`;
    const os = countBy(c.it, (r) => (/iOS|iPadOS/.test(r.OS) ? 'iOS / iPadOS' : r.OS));
    if (os.length) C.donut($('#enOs', el), os.slice(0, 5).map(([k, n], i) => ({ label: k, value: n, color: C.SERIES[i] })), { centerLabel: 'devices' });
    MC.table($('#enProb', el), c.h.concat(c.ih).filter((r) => r.Status !== 'OK'), [{ key: 'Kind', label: 'Area' }, { key: 'Name', label: 'Item' }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }, { key: 'Message', label: 'Detail', html: (r) => small(r.Message) }], { sort: 'Status', name: 'entra-problems', limit: 12, empty: 'Nothing to look at.' });
  }
  const nc = (list) => cnt(list, (x) => x.Compliance !== 'compliant' && x.Compliance !== 'inGracePeriod');
  const countBy = (list, f) => Object.entries(list.reduce((a, x) => { const k = f(x) || 'Unknown'; a[k] = (a[k] || 0) + 1; return a; }, {})).sort((a, b) => b[1] - a[1]);
  function enUsers(el, c) {
    el.innerHTML = MC.panel('Users', 'Entra ID users engine · every 6 hours', '<div id="eu"></div>', { act: collect('inv.entra.users') });
    MC.table($('#eu', el), c.u, [
      { key: 'DisplayName', label: 'User', html: (r) => `<b>${esc(r.DisplayName)}</b><div class="muted mono" style="font-size:11.5px">${esc(r.UserPrincipalName)}</div>` }, { key: 'UserType', label: 'Type' }, { key: 'Department', label: 'Department' },
      { key: 'Enabled', label: 'Enabled', val: (r) => yes(r.Enabled) }, { key: 'LastSignIn', label: 'Last sign-in', html: (r) => (r.LastSignIn ? ago(r.LastSignIn) : '<span class="muted">–</span>'), val: (r) => r.LastSignIn || '' },
      { key: 'MfaRegistered', label: 'MFA', val: (r) => yes(r.MfaRegistered), html: (r) => (r.MfaRegistered === false ? pill(r.Admin ? 'Critical' : 'Warning', 'none') : r.MfaRegistered ? '<span title="' + esc(r.Methods || '') + '">Yes</span>' : '–') },
      { key: 'Roles', label: 'Admin roles', html: (r) => small(r.Roles || '') }, { key: 'Risk', label: 'Risk', html: (r) => (r.Risk ? pill(r.Risk === 'high' ? 'Critical' : 'Warning', r.Risk) : '') }, { key: 'Synced', label: 'Synced', val: (r) => yes(r.Synced) }, { key: 'Licenses', label: 'Licences', n: true },
      { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }, { key: 'Message', label: 'Detail', html: (r) => small(r.Message) },
      { key: 'act', label: '', noCsv: true, html: (r) => (r.Enabled ? run('act.entra', { Operation: 'RevokeSessions', Target: r.UserPrincipalName }, 'Sign out…') + run('act.entra', { Operation: 'DisableUser', Target: r.UserPrincipalName }, 'Disable…') : run('act.entra', { Operation: 'EnableUser', Target: r.UserPrincipalName }, 'Enable…')) + (r.Risk ? run('act.entra', { Operation: 'DismissRisk', Target: r.UserPrincipalName }, 'Dismiss risk…') : '') },
    ], { q: c.q, sort: 'Status', name: 'entra-users', limit: 50, empty: 'No user read yet. Turn on the Entra ID users engine.' });
  }
  function enDevices(el, c) {
    el.innerHTML = `<div class="kpis">${MC.kpi('Entra joined', cnt(c.dv, (r) => r.Join === 'Entra joined'), '')}${MC.kpi('Hybrid joined', cnt(c.dv, (r) => r.Join === 'Hybrid joined'), 'joined to AD and Entra ID')}${MC.kpi('Registered', cnt(c.dv, (r) => r.Join === 'Registered'), 'personal devices')}${MC.kpi('Stale', cnt(c.dv, (r) => r.Stale), 'no sign-in for 90 days', { alert: c.dv.some((r) => r.Stale) })}</div>
      ${MC.panel('Entra devices', 'Entra ID devices engine · computers here also show in Auto-discovery', '<div id="ed"></div>', { act: collect('inv.entra.devices') })}`;
    MC.table($('#ed', el), c.dv, [{ key: 'Name', label: 'Device', html: (r) => `<a href="#" data-host="${esc(r.Name)}"><b>${esc(r.Name)}</b></a>` }, { key: 'OS', label: 'OS', val: (r) => r.OS + ' ' + (r.OSVersion || '') }, { key: 'Join', label: 'Join type' }, { key: 'Compliant', label: 'Compliant', val: (r) => yes(r.Compliant), html: (r) => (r.Compliant === false ? pill('Warning', 'No') : yes(r.Compliant)) }, { key: 'Managed', label: 'Managed', val: (r) => yes(r.Managed) },
      { key: 'LastSignIn', label: 'Last sign-in', html: (r) => (r.LastSignIn ? ago(r.LastSignIn) : '–'), val: (r) => r.LastSignIn || '' }, { key: 'Model', label: 'Model', val: (r) => [r.Manufacturer, r.Model].filter(Boolean).join(' ') }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status) },
      { key: 'act', label: '', noCsv: true, html: (r) => (r.Enabled ? run('act.entra', { Operation: 'DisableDevice', Target: r.Id }, 'Disable…') : run('act.entra', { Operation: 'EnableDevice', Target: r.Id }, 'Enable…')) }], { q: c.q, sort: 'Status', name: 'entra-devices', limit: 50, empty: 'No device read yet.' });
  }
  function enGroups(el, c) {
    el.innerHTML = MC.panel('Groups', 'security, Microsoft 365 and distribution groups', '<div id="eg"></div>', { act: collect('inv.entra.groups') });
    MC.table($('#eg', el), c.g, [{ key: 'Name', label: 'Group', html: (r) => `<b>${esc(r.Name)}</b>${r.Mail ? `<div class="muted mono" style="font-size:11.5px">${esc(r.Mail)}</div>` : ''}` }, { key: 'Type', label: 'Type' }, { key: 'Dynamic', label: 'Dynamic', val: (r) => yes(r.Dynamic), html: (r) => (r.Dynamic ? `<span title="${esc(r.Rule || '')}">Yes</span>` : 'No') }, { key: 'Members', label: 'Members', n: true },
      { key: 'Synced', label: 'From AD', val: (r) => yes(r.Synced) }, { key: 'RoleAssignable', label: 'Role-assignable', val: (r) => yes(r.RoleAssignable) }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }, { key: 'Message', label: 'Detail', html: (r) => small(r.Message) }], { q: c.q, sort: 'Members', dir: -1, name: 'entra-groups', empty: 'No group read yet.' });
  }
  function inDevices(el, c) {
    const it = c.it;
    el.innerHTML = `<div class="kpis">${MC.kpi('Managed devices', it.length, countBy(it, (r) => r.OS).map(([k, n]) => n + ' ' + k).slice(0, 3).join(' · '))}${MC.kpi('Not compliant', nc(it), '', { alert: nc(it) > 0 })}${MC.kpi('No check-in 7 days', cnt(it, (r) => r.DaysSinceSync > 7), '')}${MC.kpi('Jailbroken / rooted', cnt(it, (r) => r.Jailbroken === 'True'), '', { alert: it.some((r) => r.Jailbroken === 'True') })}${MC.kpi('Not encrypted', cnt(it, (r) => r.Encrypted === false), 'Windows and macOS')}${MC.kpi('Low storage', cnt(it, (r) => r.StorageFreePct != null && r.StorageFreePct < 10), 'under 10 % free')}</div>
      ${MC.panel('Intune managed devices', 'Intune devices engine · every hour', '<div id="id"></div>', { act: collect('inv.intune.devices') })}`;
    MC.table($('#id', el), it, [
      { key: 'Name', label: 'Device', html: (r) => `<a href="#" data-host="${esc(r.Name)}"><b>${esc(r.Name)}</b></a><div class="muted" style="font-size:11.5px">${esc(r.User || '')}</div>` }, { key: 'OS', label: 'OS', val: (r) => r.OS + ' ' + (r.OSVersion || '') },
      { key: 'Compliance', label: 'Compliance', html: (r) => pill(r.Compliance === 'compliant' ? 'OK' : r.Compliance === 'inGracePeriod' ? 'Warning' : 'Critical', r.Compliance) }, { key: 'LastSync', label: 'Check-in', html: (r) => (r.LastSync ? ago(r.LastSync) : '–'), val: (r) => r.LastSync || '' },
      { key: 'Ownership', label: 'Owner' }, { key: 'Encrypted', label: 'Encrypted', val: (r) => yes(r.Encrypted) }, { key: 'StorageFreePct', label: 'Free', n: true, html: (r) => (r.StorageFreePct == null ? '–' : r.StorageFreePct + '%') }, { key: 'Model', label: 'Model', val: (r) => [r.Manufacturer, r.Model].filter(Boolean).join(' ') },
      { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }, { key: 'Message', label: 'Detail', html: (r) => small(r.Message) },
      { key: 'act', label: '', noCsv: true, html: (r) => run('act.intune', { ComputerName: [r.Name], Operation: 'Sync' }, 'Sync') + (r.OS === 'Windows' ? run('act.intune', { ComputerName: [r.Name], Operation: 'DefenderQuickScan' }, 'Defender scan…') + run('act.intune', { ComputerName: [r.Name], Operation: 'Restart' }, 'Restart…') : run('act.intune', { ComputerName: [r.Name], Operation: 'RemoteLock' }, 'Lock…')) },
    ], { q: c.q, sort: 'Status', name: 'intune-devices', limit: 50, empty: 'No Intune device read yet. Turn on the Intune devices engine.' });
  }
  function inPolicies(el, c) {
    const pol = c.ih.filter((r) => /policy|profile/.test(r.Kind)), apps = c.ih.filter((r) => r.Kind === 'App'), con = c.ih.filter((r) => r.Kind === 'Connector');
    el.innerHTML = `${MC.panel('Compliance policies and configuration profiles', 'device status per policy', '<div id="ip"></div>', { act: collect('mon.intune') })}
      <div class="grid g-1-2">${MC.panel('Connectors and tokens', 'Apple push certificate, VPP and enrolment tokens', '<div id="ic"></div>')}${MC.panel('App installs', 'assigned apps', '<div id="ia"></div>')}</div>`;
    MC.table($('#ip', el), pol, [{ key: 'Name', label: 'Policy', html: (r) => `<b>${esc(r.Name)}</b><div class="muted" style="font-size:11.5px">${esc(r.Kind)} · ${esc(r.Platform || '')}</div>` }, { key: 'Succeeded', label: 'Succeeded', n: true }, { key: 'Failed', label: 'Failed', n: true }, { key: 'Errors', label: 'Errors', n: true }, { key: 'Conflicts', label: 'Conflicts', n: true }, { key: 'Pending', label: 'Pending', n: true }, { key: 'Status', label: 'Status', html: (r) => pill(r.Status) }], { sort: 'Status', name: 'intune-policies', empty: 'No policy read yet.' });
    MC.table($('#ic', el), con, [{ key: 'Name', label: 'Connector' }, { key: 'DaysLeft', label: 'Days left', n: true, html: (r) => pill(r.Status, String(r.DaysLeft)) }, { key: 'Expires', label: 'Expires', val: (r) => String(r.Expires || '').slice(0, 10) }], { name: 'intune-connectors', empty: 'No Apple connector set up.' });
    MC.table($('#ia', el), apps, [{ key: 'Name', label: 'App', html: (r) => `<b>${esc(r.Name)}</b><div class="muted" style="font-size:11.5px">${esc(r.Publisher || '')} · ${esc(r.Platform || '')}</div>` }, { key: 'Installed', label: 'Installed', n: true }, { key: 'Failed', label: 'Failed', n: true, html: (r) => (r.Failed ? pill(r.Status, String(r.Failed)) : '0') }, { key: 'Pending', label: 'Pending', n: true }], { sort: 'Failed', dir: -1, name: 'intune-apps', empty: 'No app install summary read.' });
  }
  function enActions(el) {
    const acts = [
      ['act.entra', 'Disable or enable a user', 'Blocks sign-in at once; pair with Sign out everywhere.', { Operation: 'DisableUser' }],
      ['act.entra', 'Sign a user out everywhere', 'Revokes refresh tokens and session cookies.', { Operation: 'RevokeSessions' }],
      ['act.entra', 'Confirm a user compromised or dismiss risk', 'Identity Protection (Entra ID P2).', { Operation: 'ConfirmCompromised' }],
      ['act.entra', 'Add or remove a group member', 'For example the VPN or Conditional Access exclusion group.', { Operation: 'AddToGroup' }],
      ['act.entra', 'Disable or enable a device', 'The device can no longer sign in to Entra ID.', { Operation: 'DisableDevice' }],
      ['act.intune', 'Sync, restart or lock a device', 'Sync asks the device to check in now.', { Operation: 'Sync' }],
      ['act.intune', 'Defender scan or signature update', 'Windows devices.', { Operation: 'DefenderQuickScan' }],
      ['act.intune', 'Rotate BitLocker recovery keys', 'Windows devices; the new key is escrowed to Entra ID.', { Operation: 'RotateBitLockerKeys' }],
      ['act.intune', 'Retire or wipe a device', 'Retire removes company data; wipe resets the device. Both ask you to type the device name.', { Operation: 'Retire' }],
    ];
    el.innerHTML = `${MC.panel('Actions', 'high-risk actions ask you to type the target and are written to the audit log', `<div class="grid g2">${acts.map(([id, t, s, p]) => `<div class="card" style="padding:12px;display:flex;gap:10px;align-items:center"><div style="flex:1"><b>${esc(t)}</b><div class="muted" style="font-size:12.5px">${esc(s)}</div></div>${run(id, p, 'Run…', 'primary') || '<span class="muted" style="font-size:12px">needs operator role</span>'}</div>`).join('')}</div>`)}
      <div class="grid g2">
        ${MC.panel('Alerts in', 'Azure Monitor and Microsoft Sentinel alerts become MonCastle alarms', `<p class="muted" style="margin:0 0 8px;font-size:13px">Send Entra ID sign-in and audit log alerts from an Azure Monitor action group (webhook, common alert schema) to MonCastle.</p><a class="btn sm" href="#/integrations/ingress">${icon('download', 'sev-ico')} Alert integrations</a>`)}
        ${MC.panel('Alarms out', 'tenant, account and Intune alarms to Teams, Slack, ServiceNow, Jira or PagerDuty', `<p class="muted" style="margin:0 0 8px;font-size:13px">Use a notification rule on the group <b>Entra ID &amp; Intune</b> or on the sensor types Entra ID tenant, Entra ID accounts, Intune and Intune device.</p><a class="btn sm" href="#/integrations/egress">${icon('send', 'sev-ico')} Egress integrations</a> <a class="btn sm ghost" href="#/notifications">Notification rules</a>`)}
      </div>`;
  }

  // ================================================================== AUTO-DISCOVERY: discovery methods
  const disc = V.discovery, discRender = disc.render;
  disc.render = function (el, route) {
    const S = root.MCSensors, host = document.createElement('div');
    discRender.call(disc, el, route);
    if (!S || !S.DISCOVERY) return;
    el.after(host);
    const draw = () => {
      if (!document.body.contains(host)) return;
      const rows = S.DISCOVERY.map((m) => { const env = (MC.ds || {})[m.dataset], meta = MC.script(m.script); return Object.assign({}, m, { have: !!meta, finished: env && env.finished, count: env ? env.count : MC.data(m.dataset).length }); });
      host.innerHTML = MC.panel('Discovery methods', 'every engine that can report devices, and the range scan above; candidates from all of them are listed together', '<div id="dmT"></div>');
      MC.table($('#dmT', host), rows, [{ key: 'label', label: 'Method', html: (m) => `<b>${esc(m.label)}</b><div class="muted" style="font-size:12px">${esc(m.desc)}</div>` }, { key: 'script', label: 'Engine', html: (m) => (m.have ? `<a class="mono" href="#/engines/${esc(m.script)}">${esc(m.script)}</a>` : `<span class="mono muted">${esc(m.script)}</span>`) },
        { key: 'count', label: 'Rows', n: true }, { key: 'finished', label: 'Last run', html: (m) => (m.finished ? ago(m.finished) : '<span class="muted">not yet</span>'), val: (m) => m.finished || '' },
        { key: 'act', label: '', noCsv: true, html: (m) => (m.have && m.id !== 'scan' && canAct() ? `<button class="btn sm" ${MC.runAttr(m.script, {})}>Run now…</button>` : '') }], { name: 'discovery-methods', limit: 30 });
    };
    setTimeout(draw, 0);
  };
})(typeof self !== 'undefined' ? self : this);
