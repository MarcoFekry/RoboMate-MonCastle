/*
 * RoboMate MonCastle - PRTG-style monitoring model shared by the browser (window.MCSensors) and the server (module.exports).
 *   probe > groups > devices > sensors > channels
 * Sensor types are the connectors. "native" types are run by the console itself every N seconds (ping, port, HTTP, DNS,
 * SNMP, SSL certificate, script); "collector" types read the datasets the PowerShell collectors / monitoring engines produce
 * (WMI, AD, DHCP, Hyper-V, VMware, SQL, printers, Linux over SSH ...). Every channel has limits; limits decide the state.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCSensors = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // PRTG states, most severe first
  const STATES = ['Down', 'Warning', 'Unknown', 'Up', 'Paused'];
  const RANK = { Down: 5, Warning: 4, Unknown: 2, Up: 1, Paused: 0 };
  const worst = (list) => list.reduce((a, s) => (RANK[s] > RANK[a] ? s : a), 'Paused');

  // ------------------------------------------------------------------ limits
  // limits: { warnHigh, errHigh, warnLow, errLow } - upper limits trip when value > limit, lower when value < limit
  function check(ch) {
    const l = ch.limits || {}, v = ch.value;
    if (v == null || Number.isNaN(v)) return { state: 'Up' };
    const u = ch.unit && ch.unit !== '#' ? ' ' + ch.unit : '';
    const f = (x) => (Math.abs(x) >= 100 || Number.isInteger(x) ? Math.round(x) : Math.round(x * 10) / 10);
    if (l.errHigh != null && v > l.errHigh) return { state: 'Down', text: `${ch.name} ${f(v)}${u} is above the error limit of ${f(l.errHigh)}${u}` };
    if (l.errLow != null && v < l.errLow) return { state: 'Down', text: `${ch.name} ${f(v)}${u} is below the error limit of ${f(l.errLow)}${u}` };
    if (l.warnHigh != null && v > l.warnHigh) return { state: 'Warning', text: `${ch.name} ${f(v)}${u} is above the warning limit of ${f(l.warnHigh)}${u}` };
    if (l.warnLow != null && v < l.warnLow) return { state: 'Warning', text: `${ch.name} ${f(v)}${u} is below the warning limit of ${f(l.warnLow)}${u}` };
    return { state: 'Up' };
  }

  // reading = { channels:[{name,value,unit,limits}], forced?: 'Down'|'Warning', message? }, overrides = { channelName: limits }
  function evaluate(reading, overrides) {
    const channels = (reading.channels || []).map((c) => Object.assign({}, c, { limits: Object.assign({}, c.limits || {}, (overrides || {})[c.name] || {}) }));
    let state = 'Up', texts = [];
    for (const c of channels) {
      const r = check(c);
      c.state = r.state;
      if (r.text) texts.push(r.text);
      state = worst([state, r.state]);
    }
    if (reading.forced) { state = worst([state, reading.forced]); if (reading.message) texts.unshift(reading.message); }
    const message = texts.length ? texts.join('; ') : reading.message || 'OK';
    return { state, message, channels };
  }

  // ------------------------------------------------------------------ sensor types (connectors)
  const P = (name, label, extra) => Object.assign({ name, label, type: 'string' }, extra || {});
  const ch = (name, unit, limits, primary) => ({ name, unit, limits: limits || {}, primary: !!primary });
  // database engines the probe can check natively: id, name, default port
  // every database engine MonCastle knows: id, name, default port, protocol family the native check speaks, category,
  // vendor. Families: tds, mysql, postgres, mongo, redis, memcached, cql, bolt, http (a health or version URL), banner (the
  // server greets first), tcp (the engine waits for the client, so an open port that stays silent is the answer).
  const DB_ENGINES = [
    // relational
    ['mssql', 'Microsoft SQL Server', 1433, 'tds', 'Relational', 'Microsoft'], ['oracle', 'Oracle Database', 1521, 'tcp', 'Relational', 'Oracle'],
    ['mysql', 'MySQL', 3306, 'mysql', 'Relational', 'Oracle'], ['mariadb', 'MariaDB', 3306, 'mysql', 'Relational', 'MariaDB'], ['percona', 'Percona Server for MySQL', 3306, 'mysql', 'Relational', 'Percona'],
    ['postgres', 'PostgreSQL', 5432, 'postgres', 'Relational', 'PostgreSQL'], ['edb', 'EDB Postgres Advanced Server', 5444, 'postgres', 'Relational', 'EnterpriseDB'],
    ['db2', 'IBM Db2', 50000, 'tcp', 'Relational', 'IBM'], ['informix', 'IBM Informix', 9088, 'tcp', 'Relational', 'IBM'], ['sybase', 'SAP ASE (Sybase)', 5000, 'tcp', 'Relational', 'SAP'],
    ['hana', 'SAP HANA', 30015, 'tcp', 'Relational', 'SAP'], ['maxdb', 'SAP MaxDB', 7210, 'tcp', 'Relational', 'SAP'], ['teradata', 'Teradata Vantage', 1025, 'tcp', 'Data warehouse', 'Teradata'],
    ['firebird', 'Firebird', 3050, 'tcp', 'Relational', 'Firebird'], ['iris', 'InterSystems IRIS / Caché', 1972, 'tcp', 'Relational', 'InterSystems'], ['openedge', 'Progress OpenEdge', 20931, 'tcp', 'Relational', 'Progress'],
    ['ingres', 'Actian Ingres / Vector', 21064, 'tcp', 'Relational', 'Actian'], ['mimer', 'Mimer SQL', 1360, 'tcp', 'Relational', 'Mimer'],
    // distributed SQL
    ['cockroach', 'CockroachDB', 26257, 'postgres', 'Distributed SQL', 'Cockroach Labs'], ['yugabyte', 'YugabyteDB', 5433, 'postgres', 'Distributed SQL', 'Yugabyte'],
    ['tidb', 'TiDB', 4000, 'mysql', 'Distributed SQL', 'PingCAP'], ['singlestore', 'SingleStore (MemSQL)', 3306, 'mysql', 'Distributed SQL', 'SingleStore'],
    ['vitess', 'Vitess (VTGate)', 15306, 'mysql', 'Distributed SQL', 'Vitess'], ['oceanbase', 'OceanBase', 2881, 'mysql', 'Distributed SQL', 'OceanBase'], ['citus', 'Citus (distributed PostgreSQL)', 5432, 'postgres', 'Distributed SQL', 'Microsoft'],
    ['nuodb', 'NuoDB', 48004, 'tcp', 'Distributed SQL', 'Dassault Systèmes'],
    // data warehouse and analytics
    ['greenplum', 'Greenplum', 5432, 'postgres', 'Data warehouse', 'Broadcom'], ['redshift', 'Amazon Redshift (endpoint)', 5439, 'postgres', 'Data warehouse', 'Amazon'],
    ['vertica', 'OpenText Vertica', 5433, 'tcp', 'Data warehouse', 'OpenText'], ['exasol', 'Exasol', 8563, 'tcp', 'Data warehouse', 'Exasol'], ['netezza', 'IBM Netezza', 5480, 'postgres', 'Data warehouse', 'IBM'],
    ['clickhouse', 'ClickHouse', 8123, 'http', 'Analytics', 'ClickHouse'], ['druid', 'Apache Druid', 8888, 'http', 'Analytics', 'Apache'], ['pinot', 'Apache Pinot', 9000, 'http', 'Analytics', 'Apache'],
    ['doris', 'Apache Doris', 9030, 'mysql', 'Analytics', 'Apache'], ['starrocks', 'StarRocks', 9030, 'mysql', 'Analytics', 'StarRocks'], ['trino', 'Trino / Presto', 8080, 'http', 'Analytics', 'Trino'],
    ['hive', 'Apache Hive (HiveServer2)', 10000, 'tcp', 'Analytics', 'Apache'], ['impala', 'Apache Impala', 21050, 'tcp', 'Analytics', 'Apache'], ['monetdb', 'MonetDB', 50000, 'tcp', 'Analytics', 'MonetDB'],
    ['kylin', 'Apache Kylin', 7070, 'http', 'Analytics', 'Apache'],
    // document
    ['mongodb', 'MongoDB', 27017, 'mongo', 'Document', 'MongoDB'], ['ferretdb', 'FerretDB', 27017, 'mongo', 'Document', 'FerretDB'], ['documentdb', 'Amazon DocumentDB (endpoint)', 27017, 'mongo', 'Document', 'Amazon'],
    ['couchdb', 'Apache CouchDB', 5984, 'http', 'Document', 'Apache'], ['couchbase', 'Couchbase', 8091, 'http', 'Document', 'Couchbase'], ['ravendb', 'RavenDB', 8080, 'http', 'Document', 'RavenDB'],
    ['arangodb', 'ArangoDB', 8529, 'http', 'Multi-model', 'ArangoDB'], ['marklogic', 'MarkLogic', 7997, 'http', 'Multi-model', 'Progress'], ['orientdb', 'OrientDB', 2480, 'http', 'Multi-model', 'OrientDB'],
    ['rethinkdb', 'RethinkDB', 28015, 'tcp', 'Document', 'RethinkDB'], ['surrealdb', 'SurrealDB', 8000, 'http', 'Multi-model', 'SurrealDB'],
    // key-value and cache
    ['redis', 'Redis', 6379, 'redis', 'Key-value', 'Redis'], ['valkey', 'Valkey', 6379, 'redis', 'Key-value', 'Linux Foundation'], ['keydb', 'KeyDB', 6379, 'redis', 'Key-value', 'Snap'],
    ['dragonfly', 'Dragonfly', 6379, 'redis', 'Key-value', 'DragonflyDB'], ['garnet', 'Microsoft Garnet', 6379, 'redis', 'Key-value', 'Microsoft'], ['memcached', 'Memcached', 11211, 'memcached', 'Key-value', 'Memcached'],
    ['aerospike', 'Aerospike', 3000, 'tcp', 'Key-value', 'Aerospike'], ['etcd', 'etcd', 2379, 'http', 'Key-value', 'CNCF'], ['riak', 'Riak KV', 8098, 'http', 'Key-value', 'Riak'],
    ['tarantool', 'Tarantool', 3301, 'banner', 'Key-value', 'Tarantool'], ['foundationdb', 'FoundationDB', 4500, 'tcp', 'Key-value', 'Apple'], ['hazelcast', 'Hazelcast', 5701, 'http', 'In-memory grid', 'Hazelcast'],
    ['ignite', 'Apache Ignite', 10800, 'tcp', 'In-memory grid', 'Apache'], ['geode', 'Apache Geode / VMware GemFire', 10334, 'tcp', 'In-memory grid', 'Broadcom'],
    // wide-column
    ['cassandra', 'Apache Cassandra', 9042, 'cql', 'Wide-column', 'Apache'], ['scylladb', 'ScyllaDB', 9042, 'cql', 'Wide-column', 'ScyllaDB'], ['datastax', 'DataStax Enterprise', 9042, 'cql', 'Wide-column', 'DataStax'],
    ['hbase', 'Apache HBase', 16010, 'http', 'Wide-column', 'Apache'], ['accumulo', 'Apache Accumulo', 9995, 'http', 'Wide-column', 'Apache'],
    // search
    ['elastic', 'Elasticsearch', 9200, 'http', 'Search', 'Elastic'], ['opensearch', 'OpenSearch', 9200, 'http', 'Search', 'OpenSearch'], ['solr', 'Apache Solr', 8983, 'http', 'Search', 'Apache'],
    ['typesense', 'Typesense', 8108, 'http', 'Search', 'Typesense'], ['meilisearch', 'Meilisearch', 7700, 'http', 'Search', 'Meili'], ['manticore', 'Manticore Search / Sphinx', 9306, 'mysql', 'Search', 'Manticore'],
    // time series
    ['influxdb', 'InfluxDB', 8086, 'http', 'Time series', 'InfluxData'], ['timescale', 'TimescaleDB', 5432, 'postgres', 'Time series', 'Timescale'], ['questdb', 'QuestDB', 8812, 'postgres', 'Time series', 'QuestDB'],
    ['victoriametrics', 'VictoriaMetrics', 8428, 'http', 'Time series', 'VictoriaMetrics'], ['prometheus', 'Prometheus (TSDB)', 9090, 'http', 'Time series', 'CNCF'], ['opentsdb', 'OpenTSDB', 4242, 'http', 'Time series', 'OpenTSDB'],
    ['tdengine', 'TDengine', 6041, 'http', 'Time series', 'TDengine'], ['kdb', 'KX kdb+', 5001, 'tcp', 'Time series', 'KX'], ['iotdb', 'Apache IoTDB', 6667, 'tcp', 'Time series', 'Apache'],
    // graph
    ['neo4j', 'Neo4j', 7687, 'bolt', 'Graph', 'Neo4j'], ['memgraph', 'Memgraph', 7687, 'bolt', 'Graph', 'Memgraph'], ['janusgraph', 'JanusGraph (Gremlin Server)', 8182, 'tcp', 'Graph', 'Linux Foundation'],
    ['tigergraph', 'TigerGraph', 9000, 'http', 'Graph', 'TigerGraph'], ['dgraph', 'Dgraph', 8080, 'http', 'Graph', 'Dgraph'], ['nebula', 'NebulaGraph', 9669, 'tcp', 'Graph', 'Vesoft'],
    // vector
    ['qdrant', 'Qdrant', 6333, 'http', 'Vector', 'Qdrant'], ['weaviate', 'Weaviate', 8080, 'http', 'Vector', 'Weaviate'], ['milvus', 'Milvus', 9091, 'http', 'Vector', 'Zilliz'],
    ['chroma', 'Chroma', 8000, 'http', 'Vector', 'Chroma'], ['vespa', 'Vespa', 19071, 'http', 'Vector', 'Vespa'],
  ];
  const DB_CATEGORIES = ['Relational', 'Distributed SQL', 'Data warehouse', 'Analytics', 'Document', 'Multi-model', 'Key-value', 'In-memory grid', 'Wide-column', 'Search', 'Time series', 'Graph', 'Vector'];
  const DB_ENGINE = Object.fromEntries(DB_ENGINES.map(([id, name, port, family, category, vendor]) => [id, { id, name, port, family, category, vendor }]));
  const TYPES = [
    // ---- passive: set by alerts that other monitoring systems send in (Monitor > Alert integrations)
    { id: 'ext.alert', name: 'External alert', category: 'Integrations', source: 'native', passive: true, interval: 86400, icon: 'bell',
      desc: 'An alert received from another monitoring system (Prometheus, Grafana, Zabbix, Nagios, PRTG, SolarWinds, Datadog, Azure Monitor, CloudWatch, SCOM and others). It goes Down or Warning when the alert fires and Up when the tool resolves it.',
      params: [P('integration', 'Integration'), P('key', 'Alert key')], channels: [] },
    // ---- native: run by the console probe
    { id: 'ping', name: 'Ping', category: 'Availability', source: 'native', interval: 60, icon: 'activity',
      desc: 'ICMP echo to the device: response time and packet loss. The basic "is it up" sensor.',
      params: [P('host', 'Host or IP', { fromDevice: true }), P('count', 'Pings per scan', { type: 'int', def: 3, min: 1, max: 10 })],
      channels: [ch('Ping time', 'ms', { warnHigh: 100, errHigh: 500 }, true), ch('Packet loss', '%', { warnHigh: 20, errHigh: 60 })] },
    { id: 'port', name: 'Port (TCP)', category: 'Availability', source: 'native', interval: 60, icon: 'net',
      desc: 'Opens a TCP connection to a port (RDP 3389, SMB 445, WinRM 5985, LDAP 389, SQL 1433 ...).',
      params: [P('host', 'Host or IP', { fromDevice: true }), P('port', 'Port', { type: 'int', def: 443, min: 1, max: 65535 })],
      channels: [ch('Response time', 'ms', { warnHigh: 500, errHigh: 3000 }, true)] },
    { id: 'http', name: 'HTTP(S)', category: 'Web', source: 'native', interval: 60, icon: 'cloud',
      desc: 'Requests a URL: response time, status code, optional keyword check.',
      params: [P('url', 'URL', { def: 'https://' }), P('keyword', 'Must contain (optional)'), P('expect', 'Expected status', { type: 'int', def: 200 })],
      channels: [ch('Response time', 'ms', { warnHigh: 1500, errHigh: 5000 }, true), ch('Status code', '', {})] },
    { id: 'dns', name: 'DNS query', category: 'DNS', source: 'native', interval: 120, icon: 'net',
      desc: 'Asks a DNS server to resolve a name: response time and number of records.',
      params: [P('server', 'DNS server', { fromDevice: true }), P('name', 'Name to resolve'), P('recordType', 'Record type', { values: ['A', 'AAAA', 'CNAME', 'MX', 'SRV', 'TXT', 'NS', 'SOA'], def: 'A' })],
      channels: [ch('Response time', 'ms', { warnHigh: 200, errHigh: 2000 }, true), ch('Records', '#', { errLow: 1 })] },
    { id: 'sslcert', name: 'SSL certificate', category: 'Web', source: 'native', interval: 3600, icon: 'shield',
      desc: 'Reads the TLS certificate of a host and warns before it expires.',
      params: [P('host', 'Host', { fromDevice: true }), P('port', 'Port', { type: 'int', def: 443 })],
      channels: [ch('Days to expiration', 'd', { warnLow: 30, errLow: 7 }, true)] },
    { id: 'snmp.uptime', name: 'SNMP system uptime', category: 'Network (SNMP)', source: 'native', interval: 60, icon: 'net',
      desc: 'SNMP v2c sysUpTime of switches, firewalls, UPS, printers and appliances. A restart shows as a drop.',
      params: [P('host', 'Host or IP', { fromDevice: true }), P('community', 'Community (empty = device credential)', { secret: true })],
      channels: [ch('System uptime', 'h', { warnLow: 0.25 }, true), ch('Response time', 'ms', { warnHigh: 500 })] },
    { id: 'snmp.traffic', name: 'SNMP traffic', category: 'Network (SNMP)', source: 'native', interval: 60, icon: 'net',
      desc: 'Bandwidth of one interface (64-bit counters) and its operational state.',
      params: [P('host', 'Host or IP', { fromDevice: true }), P('community', 'Community (empty = device credential)', { secret: true }), P('ifIndex', 'Interface index', { type: 'int', def: 1 })],
      channels: [ch('Traffic in', 'Mbit/s', {}, true), ch('Traffic out', 'Mbit/s', {}), ch('Interface up', '', { errLow: 1 })] },
    { id: 'snmp.custom', name: 'SNMP custom OID', category: 'Network (SNMP)', source: 'native', interval: 60, icon: 'net',
      desc: 'Reads any numeric OID (temperature, UPS battery, toner level ...).',
      params: [P('host', 'Host or IP', { fromDevice: true }), P('community', 'Community (empty = device credential)', { secret: true }), P('oid', 'OID', { def: '1.3.6.1.2.1.1.3.0' }), P('label', 'Channel name', { def: 'Value' }), P('unit', 'Unit'), P('scale', 'Multiply the value by', { def: '1' })],
      channels: [ch('Value', '', {}, true)] },
    { id: 'snmp.storage', name: 'SNMP storage volume', category: 'Network (SNMP)', source: 'native', interval: 300, icon: 'db',
      desc: 'Used and free space of one volume from HOST-RESOURCES hrStorageTable (NAS, Linux, appliances). The index is the row in hrStorageTable.',
      params: [P('host', 'Host or IP', { fromDevice: true }), P('community', 'Community (empty = device credential)', { secret: true }), P('index', 'hrStorage index', { type: 'int', def: 1, min: 1, max: 100000 })],
      channels: [ch('Used', '%', { warnHigh: 85, errHigh: 95 }, true), ch('Free', 'GB', {}), ch('Size', 'GB', {})] },
    { id: 'db.service', name: 'Database service', category: 'Databases', source: 'native', interval: 120, icon: 'db',
      desc: 'Speaks the database protocol (TDS, MySQL, PostgreSQL, MongoDB, Redis, CQL, HTTP APIs): response time, version and TLS. With a database credential Redis, Elasticsearch, CouchDB and InfluxDB report health metrics too.',
      params: [P('host', 'Host or IP', { fromDevice: true }), P('engine', 'Engine', { values: DB_ENGINES.map((e) => e[0]), def: 'mysql' }), P('port', 'Port (empty = engine default)', { type: 'int', min: 1, max: 65535 })],
      channels: [ch('Response time', 'ms', { warnHigh: 500, errHigh: 3000 }, true)] },
    { id: 'script', name: 'PowerShell script', category: 'Custom', source: 'native', interval: 900, icon: 'code',
      desc: 'Runs a script from the library on a schedule and uses its row count or a numeric field as the channel.',
      params: [P('script', 'Script id'), P('params', 'Parameters (JSON)', { def: '{}' }), P('field', 'Numeric field (empty = row count)')],
      channels: [ch('Value', '', {}, true), ch('Execution time', 's', {})] },

    // ---- collector based: Windows over WMI / PowerShell remoting
    { id: 'wmi.cpu', name: 'CPU load', category: 'Windows (WMI)', source: 'collector', script: 'mon.compute', dataset: 'servers.compute', icon: 'server', desc: 'Processor load and queue length.' },
    { id: 'wmi.memory', name: 'Memory', category: 'Windows (WMI)', source: 'collector', script: 'mon.compute', dataset: 'servers.compute', icon: 'server', desc: 'Physical memory in use and available.' },
    { id: 'wmi.disk', name: 'Disk free', category: 'Windows (WMI)', source: 'collector', script: 'mon.disks', dataset: 'servers.disks', icon: 'db', desc: 'Free space per volume.' },
    { id: 'wmi.diskio', name: 'Disk I/O', category: 'Windows (WMI)', source: 'collector', script: 'mon.compute', dataset: 'servers.compute', icon: 'db', desc: 'IOPS, latency and queue.' },
    { id: 'wmi.network', name: 'Network traffic', category: 'Windows (WMI)', source: 'collector', script: 'mon.compute', dataset: 'servers.compute', icon: 'net', desc: 'Total network throughput.' },
    { id: 'wmi.availability', name: 'Availability', category: 'Windows (WMI)', source: 'collector', script: 'mon.availability', dataset: 'servers.availability', icon: 'activity', desc: 'Ping, uptime and management ports (WinRM, RDP, SMB).' },
    { id: 'wmi.services', name: 'Windows services', category: 'Windows (WMI)', source: 'collector', script: 'mon.services', dataset: 'servers.services', icon: 'settings', desc: 'Automatic services that are stopped.' },
    { id: 'wmi.iis', name: 'IIS application pools', category: 'Windows (WMI)', source: 'collector', script: 'mon.iis', dataset: 'servers.iis', icon: 'cloud', desc: 'Application pools that are not started.' },
    { id: 'wmi.activation', name: 'Windows activation', category: 'Windows (WMI)', source: 'collector', script: 'mon.activation', dataset: 'servers.activation', icon: 'key', desc: 'Licence status and grace period.' },
    { id: 'sec.defender', name: 'Defender', category: 'Security', source: 'collector', script: 'sec.defender', dataset: 'security.defender', icon: 'shield', desc: 'Real-time protection, signature age and threats.' },
    { id: 'sec.patches', name: 'Windows updates', category: 'Security', source: 'collector', script: 'sec.patches', dataset: 'security.patches', icon: 'shield', desc: 'Days since the last patch, pending updates and reboot.' },
    { id: 'sec.firewall', name: 'Firewall', category: 'Security', source: 'collector', script: 'sec.firewall', dataset: 'security.firewall', icon: 'shield', desc: 'Disabled firewall profiles and SMBv1.' },
    // ---- Active Directory
    { id: 'ad.dc', name: 'Domain controller', category: 'Active Directory', source: 'collector', script: 'mon.ad.health', dataset: 'ad.health', icon: 'id', desc: 'AD services, SYSVOL, NETLOGON, DNS and time offset.' },
    { id: 'ad.replication', name: 'AD replication', category: 'Active Directory', source: 'collector', script: 'mon.ad.replication', dataset: 'ad.replication', icon: 'id', desc: 'Failing replication links and replication lag.' },
    { id: 'ad.accounts', name: 'AD accounts', category: 'Active Directory', source: 'collector', script: 'inv.ad.users', dataset: 'ad.users', icon: 'id', desc: 'Locked-out, stale and never-expiring accounts.' },
    { id: 'ad.computers', name: 'AD computer accounts', category: 'Active Directory', source: 'collector', script: 'inv.ad.computers', dataset: 'ad.computers', icon: 'id', desc: 'Stale and disabled computer accounts.' },
    { id: 'ad.audit', name: 'AD security events', category: 'Active Directory', source: 'collector', script: 'aud.events', dataset: 'audit.events', icon: 'audit', desc: 'Failed logons, lockouts and privileged group changes in the last 24 hours.' },
    { id: 'ad.gpo', name: 'Group Policy', category: 'Active Directory', source: 'collector', script: 'mon.ad.gpo', dataset: 'ad.gpo', icon: 'id', desc: 'GPO version mismatches, unlinked and empty GPOs.' },
    { id: 'ad.sites', name: 'AD sites and site links', category: 'Active Directory', source: 'collector', script: 'mon.ad.sites', dataset: 'ad.sites', icon: 'id', desc: 'Sites without a domain controller, subnets in no site and site links.' },
    // ---- DNS, DHCP, file servers
    { id: 'dns.server', name: 'DNS server', category: 'DNS', source: 'collector', script: 'mon.dns', dataset: 'dns.servers', icon: 'net', desc: 'DNS service, zones, resolution test and DNS errors.' },
    { id: 'dhcp.scope', name: 'DHCP scope', category: 'DHCP', source: 'collector', script: 'mon.dhcp', dataset: 'network.dhcp', icon: 'net', desc: 'Addresses in use per scope.' },
    { id: 'fs.server', name: 'File server', category: 'File servers', source: 'collector', script: 'mon.fileserver', dataset: 'fileserver.health', icon: 'box', desc: 'SMB sessions, open files, quotas and shadow copies.' },
    { id: 'fs.audit', name: 'File access audit', category: 'File servers', source: 'collector', script: 'aud.events', dataset: 'audit.events', icon: 'audit', desc: 'File reads, changes, deletions and permission changes in the last 24 hours.' },
    { id: 'win.events', name: 'Event log errors', category: 'Windows (WMI)', source: 'collector', script: 'mon.events', dataset: 'servers.events', icon: 'alert', desc: 'Critical and error events in System and Application logs.' },
    // ---- virtualization
    { id: 'hv.host', name: 'Hyper-V host', category: 'Hyper-V', source: 'collector', script: 'mon.hyperv', dataset: 'virtualization.hyperv', icon: 'layers', desc: 'Running VMs and host memory.' },
    { id: 'hv.vm', name: 'Hyper-V virtual machine', category: 'Hyper-V', source: 'collector', script: 'mon.hyperv', dataset: 'virtualization.hyperv', icon: 'layers', desc: 'VM state, CPU, heartbeat and checkpoints.' },
    { id: 'vmw.host', name: 'VMware host', category: 'VMware', source: 'collector', script: 'mon.vmware', dataset: 'virtualization.vmware', icon: 'layers', desc: 'ESXi connection state, CPU and memory.' },
    { id: 'vmw.datastore', name: 'VMware datastore', category: 'VMware', source: 'collector', script: 'mon.vmware', dataset: 'virtualization.vmware', icon: 'db', desc: 'Free space per datastore.' },
    { id: 'vmw.vm', name: 'VMware virtual machine', category: 'VMware', source: 'collector', script: 'mon.vmware', dataset: 'virtualization.vmware', icon: 'layers', desc: 'Power state, VMware Tools and snapshot age.' },
    { id: 'ocp.node', name: 'OpenShift node', category: 'OpenShift', source: 'collector', script: 'mon.openshift', dataset: 'virtualization.openshift', icon: 'layers', desc: 'Node ready state, capacity and running VMs (OpenShift Virtualization API).' },
    { id: 'ocp.vm', name: 'OpenShift virtual machine', category: 'OpenShift', source: 'collector', script: 'mon.openshift', dataset: 'virtualization.openshift', icon: 'layers', desc: 'VirtualMachine state, guest agent and CPU (KubeVirt).' },
    { id: 'ntx.host', name: 'Nutanix AHV host', category: 'Nutanix', source: 'collector', script: 'mon.nutanix', dataset: 'virtualization.nutanix', icon: 'layers', desc: 'Host state, capacity and running VMs (Prism API).' },
    { id: 'ntx.vm', name: 'Nutanix virtual machine', category: 'Nutanix', source: 'collector', script: 'mon.nutanix', dataset: 'virtualization.nutanix', icon: 'layers', desc: 'Power state, guest tools and CPU.' },
    { id: 'ntx.container', name: 'Nutanix storage container', category: 'Nutanix', source: 'collector', script: 'mon.nutanix', dataset: 'virtualization.nutanix', icon: 'db', desc: 'Free space per storage container.' },
    { id: 'cluster', name: 'Failover cluster', category: 'Clusters', source: 'collector', script: 'mon.clusters', dataset: 'virtualization.clusters', icon: 'layers', desc: 'Nodes up and roles offline.' },
    { id: 'cluster.csv', name: 'Cluster shared volume', category: 'Clusters', source: 'collector', script: 'mon.clusters.storage', dataset: 'virtualization.clusterstorage', icon: 'db', desc: 'Free space per cluster disk.' },
    // ---- SQL, printers, Linux, network
    { id: 'sql.instance', name: 'SQL Server', category: 'SQL', source: 'collector', script: 'mon.sql.databases', dataset: 'sql.databases', icon: 'db', desc: 'Unhealthy databases and backup age.' },
    { id: 'cloud.db', name: 'Cloud database', category: 'Databases', source: 'collector', script: 'mon.cloud.databases', dataset: 'cloud.databases', icon: 'db', desc: 'Azure SQL, Managed Instance, PostgreSQL, MySQL, Cosmos DB; AWS RDS, Aurora, DocumentDB, DynamoDB; Cloud SQL, Spanner, Firestore; Oracle Autonomous, MySQL HeatWave; Huawei RDS, GaussDB, DDS: state, CPU, storage, high availability, backups and public access.' },
    { id: 'db.instance', name: 'Database instance', category: 'Databases', source: 'collector', script: 'mon.databases', dataset: 'databases.health', icon: 'db', desc: 'Connections, size, replication role and lag, cache hit ratio, slow queries and backup age (Oracle, PostgreSQL, MySQL, MariaDB, MongoDB, Redis, Elasticsearch, Cassandra).' },
    { id: 'cloud.account', name: 'Cloud storage account', category: 'Cloud storage', source: 'collector', script: 'mon.cloud.storage', dataset: 'cloud.storage', icon: 'cloud', desc: 'Azure storage account, AWS account, Google Cloud project, OCI tenancy or Huawei Cloud account: buckets, used capacity, public and unencrypted buckets, API latency.' },
    { id: 'cloud.bucket', name: 'Cloud bucket / container', category: 'Cloud storage', source: 'collector', script: 'mon.cloud.storage', dataset: 'cloud.storage', icon: 'db', desc: 'Used capacity, objects, 24-hour growth, public access, encryption and versioning of one bucket or blob container.' },
    { id: 'printer', name: 'Printer', category: 'Printers', source: 'collector', script: 'mon.printers', dataset: 'printers.health', icon: 'printer', desc: 'Printer state, queued and stuck jobs.' },
    { id: 'os.updates', name: 'OS updates', category: 'Updates', source: 'collector', script: 'mon.os.updates', dataset: 'updates.status', icon: 'download', desc: 'Windows and Linux: release and build, the newest build or point release online, support end, pending (security) updates, days since the last update and pending restart.' },
    { id: 'ssh.linux', name: 'Linux (SSH)', category: 'Linux (SSH)', source: 'collector', script: 'lnx.collect', dataset: 'linux.hosts', icon: 'linux', desc: 'CPU, memory, fullest filesystem, load, failed units, security updates.' },
    { id: 'net.discovery', name: 'Network device ping', category: 'Availability', source: 'collector', script: 'mon.network.discovery', dataset: 'network.discovery', icon: 'net', desc: 'Latency and open ports seen by the network discovery scan.' },
    { id: 'net.snmpdev', name: 'Network device (SNMP engine)', category: 'Network (SNMP)', source: 'collector', script: 'mon.network.devices', dataset: 'network.devices', icon: 'net', desc: 'Interfaces up, interfaces down while enabled, and uptime, read by the network devices engine.' },
    { id: 'storage.snmpdev', name: 'Storage volume (SNMP engine)', category: 'Storage', source: 'collector', script: 'mon.storage.devices', dataset: 'storage.devices', icon: 'db', desc: 'Used space of every volume of a SAN, NAS or backup appliance, read by the storage devices engine.' },
    { id: 'lnx.fs', name: 'Linux filesystems', category: 'Linux (SSH)', source: 'collector', script: 'mon.linux.filesystems', dataset: 'linux.filesystems', icon: 'db', desc: 'Space and inodes per mount, read-only mounts and fstab entries that are not mounted.' },
    { id: 'lnx.services', name: 'Linux services', category: 'Linux (SSH)', source: 'collector', script: 'mon.linux.services', dataset: 'linux.services', icon: 'linux', desc: 'Failed systemd units and watched services that are enabled but not running.' },
    { id: 'lnx.audit', name: 'Linux audit', category: 'Linux (SSH)', source: 'collector', script: 'mon.linux.audit', dataset: 'linux.audit', icon: 'shield', desc: 'Failed and root SSH logins, sudo use and refusals, new accounts, auditd state.' },
    { id: 'web.server', name: 'Web server (engine)', category: 'Web', source: 'collector', script: 'mon.web.servers', dataset: 'web.servers', icon: 'cloud', desc: 'HTTP status, response time, redirects, server software and page content, checked by the web servers engine.' },
    { id: 'web.host', name: 'Web server software (engine)', category: 'Web', source: 'collector', script: 'mon.web.hosts', dataset: 'web.hosts', icon: 'server', desc: 'Every web server, application server, gateway and runtime on Windows and Linux (IIS, Apache, nginx, LiteSpeed, Tomcat, Jetty, WildFly, WebLogic, WebSphere, GlassFish, Node.js, Gunicorn, PHP-FPM, Kestrel and more): service running, version, ports, connections, requests, workers, configuration test and errors.' },
    { id: 'ssl.engine', name: 'Certificate audit (engine)', category: 'Web', source: 'collector', script: 'mon.ssl.certificates', dataset: 'ssl.certificates', icon: 'lock', desc: 'Days to expiry, chain trust, name match, key size, signature and TLS protocol of a TLS endpoint.' },
    { id: 'hw.temp', name: 'Temperature', category: 'Hardware', source: 'collector', script: 'mon.temperature', dataset: 'hardware.temperature', icon: 'gauge', desc: 'Every temperature sensor the device reports: SNMP (ENTITY-SENSOR, Cisco, LM-SENSORS, vendor MIBs), Redfish on BMCs, Linux thermal zones and Windows ACPI.' },
    { id: 'k8s.cluster', name: 'Kubernetes cluster', category: 'Containers', source: 'collector', script: 'mon.kubernetes', dataset: 'containers.kubernetes', icon: 'layers', desc: 'Nodes ready, failing pods, degraded workloads, pending volume claims and warning events of a Kubernetes or OpenShift cluster.' },
    { id: 'k8s.node', name: 'Kubernetes node', category: 'Containers', source: 'collector', script: 'mon.kubernetes', dataset: 'containers.kubernetes', icon: 'server', desc: 'Ready, pressure conditions, cordon, CPU and memory use and pods of one node.' },
    { id: 'k8s.workload', name: 'Kubernetes workload', category: 'Containers', source: 'collector', script: 'mon.kubernetes', dataset: 'containers.kubernetes', icon: 'grid', desc: 'Ready replicas against desired for a deployment, stateful set or daemon set.' },
    { id: 'docker.host', name: 'Container host', category: 'Containers', source: 'collector', script: 'mon.containers', dataset: 'containers.docker', icon: 'box', desc: 'Docker or Podman engine: containers running, containers with problems, images.' },
    { id: 'docker.container', name: 'Container', category: 'Containers', source: 'collector', script: 'mon.containers', dataset: 'containers.docker', icon: 'box', desc: 'State, health check, restarts, CPU and memory of one container.' },
    { id: 'cloud.fw', name: 'Cloud firewall', category: 'Cloud network', source: 'collector', script: 'mon.cloud.network', dataset: 'network.cloud', icon: 'shield', desc: 'Azure Firewall, AWS Network Firewall, OCI Network Firewall, Google VPC firewall rules and Huawei Cloud Firewall: state, policy and risky rules.' },
    { id: 'cloud.waf', name: 'Web application firewall', category: 'Cloud network', source: 'collector', script: 'mon.cloud.network', dataset: 'network.cloud', icon: 'shield', desc: 'Azure WAF, AWS WAF, OCI WAF, Google Cloud Armor and Huawei WAF: enabled, prevention or detection mode, rules.' },
    { id: 'cloud.vpngw', name: 'VPN gateway', category: 'Cloud network', source: 'collector', script: 'mon.cloud.network', dataset: 'network.cloud', icon: 'lock', desc: 'Site-to-site and remote-access VPN gateways and endpoints: state and tunnels up.' },
    { id: 'cloud.vpn', name: 'VPN tunnel', category: 'Cloud network', source: 'collector', script: 'mon.cloud.network', dataset: 'network.cloud', icon: 'net', desc: 'One IPsec tunnel: up or down, peer, traffic.' },
    { id: 'cloud.vpnclients', name: 'VPN clients', category: 'Cloud network', source: 'collector', script: 'mon.cloud.network', dataset: 'network.cloud', icon: 'users', desc: 'Users connected to a remote-access VPN (Azure point-to-site, AWS Client VPN, Huawei P2C).' },
    { id: 'entra.tenant', name: 'Entra ID tenant', category: 'Entra ID & Intune', source: 'collector', script: 'mon.entra.health', dataset: 'entra.health', icon: 'id', desc: 'Directory sync, licences, app secrets and certificates that expire, failed sign-ins, risky users, Global Administrators and Conditional Access.' },
    { id: 'entra.accounts', name: 'Entra ID accounts', category: 'Entra ID & Intune', source: 'collector', script: 'inv.entra.users', dataset: 'entra.users', icon: 'users', desc: 'Stale accounts, users and admins without MFA, users at risk and guests.' },
    { id: 'intune.tenant', name: 'Intune', category: 'Entra ID & Intune', source: 'collector', script: 'mon.intune', dataset: 'intune.health', icon: 'desktop', desc: 'Enrolled and non-compliant devices, compliance policies and configuration profiles with errors, app install failures, Apple push certificate and tokens.' },
    { id: 'intune.device', name: 'Intune device', category: 'Entra ID & Intune', source: 'collector', script: 'inv.intune.devices', dataset: 'intune.devices', icon: 'desktop', desc: 'Compliance, last check-in, encryption and free storage of one Intune managed device.' },
  ];
  const TYPE = Object.fromEntries(TYPES.map((t) => [t.id, t]));

  // ------------------------------------------------------------------ groups and devices
  const GROUPS = [
    ['g:dc', 'Domain controllers'], ['g:ad', 'Active Directory'], ['g:dns', 'DNS & DHCP'], ['g:fs', 'File servers'], ['g:prn', 'Print servers'], ['g:sql', 'SQL servers'],
    ['g:hv', 'Hyper-V'], ['g:vmw', 'VMware'], ['g:ocp', 'OpenShift'], ['g:ntx', 'Nutanix'], ['g:cl', 'Clusters'], ['g:web', 'Web servers'], ['g:srv', 'Servers'], ['g:ws', 'Workstations'], ['g:lnx', 'Linux'],
    ['g:net', 'Network devices'], ['g:fw', 'Firewalls'], ['g:storage', 'Storage (SAN, NAS, backup)'], ['g:power', 'Power and environment'], ['g:hw', 'Server hardware (BMC)'],
    ['g:printers', 'Printers'], ['g:web-checks', 'Websites & services'], ['g:db', 'Databases'], ['g:cloud', 'Cloud storage'], ['g:k8s', 'Containers & Kubernetes'], ['g:cloudnet', 'Cloud network & VPN'], ['g:entra', 'Entra ID & Intune'], ['g:other', 'Other devices'], ['g:ext', 'External alerts'],
  ];
  // short name of a host: SRV01.corp.local -> SRV01; an IP address stays whole
  const isIp = (n) => /^\d{1,3}(\.\d{1,3}){3}$/.test(String(n || '')) || String(n || '').includes(':');
  const short = (n) => (isIp(n) ? String(n) : String(n || '').split('.')[0].toUpperCase());
  const devId = (name) => 'd:' + String(name).toLowerCase();
  const sensorId = (type, dev, sub) => 's:' + type + ':' + String(dev).toLowerCase() + (sub ? ':' + String(sub).toLowerCase().replace(/[^\w.-]+/g, '_') : '');
  const r1 = (v) => (v == null || Number.isNaN(+v) ? null : Math.round(+v * 10) / 10);
  const H = 3600e3;

  function serverGroup(roles) {
    roles = roles || [];
    if (roles.includes('DomainControllers')) return 'g:dc';
    if (roles.includes('HyperV')) return 'g:hv';
    if (roles.includes('SQL')) return 'g:sql';
    if (roles.includes('FileServers')) return 'g:fs';
    if (roles.includes('PrintServers')) return 'g:prn';
    if (roles.includes('IIS')) return 'g:web';
    return 'g:srv';
  }

  // Builds devices and collector sensors from the datasets. Returns { devices: Map, sensors: [] }.
  function derive(ds, opts = {}) {
    const now = opts.now || Date.now();
    const rows = (k) => ((ds[k] || {}).data || []);
    // the console's own devices by address and name: an engine that reports 10.10.0.1 fills the device CORE-SW-HQ01
    const alias = opts.alias || {};
    const lcs = (x) => String(x || '').toLowerCase();
    const nm = (x) => { const k = String(x || '').toLowerCase(); return alias[k] || (isIp(x) ? String(x) : alias[k.split('.')[0]] || short(x)); };
    const devices = new Map();
    const dev = (name, kind, group, extra) => {
      const id = devId(name);
      if (!devices.has(id)) devices.set(id, Object.assign({ id, name, kind, group, host: null, auto: true, tags: [] }, extra || {}));
      const d = devices.get(id);
      if (extra) for (const [k, v] of Object.entries(extra)) if (v != null && d[k] == null) d[k] = v;
      return d;
    };
    const sensors = [];
    const add = (type, d, sub, name, reading, dsKey) => {
      const t = TYPE[type];
      const set = ds[dsKey || t.dataset] || {};
      sensors.push({ id: sensorId(type, d.name, sub), type, device: d.id, name, source: 'collector', script: t.script, dataset: dsKey || t.dataset, lastScan: set.finished || null, reading });
    };

    // devices: servers (roles decide the group)
    const roles = Object.fromEntries(rows('inventory.roles').map((r) => [short(r.ComputerName), r.Roles || []]));
    const hw = Object.fromEntries(rows('inventory.hardware').map((r) => [short(r.Name), r]));
    const avail = Object.fromEntries(rows('servers.availability').map((r) => [short(r.Name), r]));
    const names = new Set([...rows('servers.compute').map((r) => short(r.Name)), ...Object.keys(roles), ...Object.keys(avail)]);
    for (const n of names) {
      const h = hw[n] || {}, a = avail[n] || {};
      dev(n, 'server', serverGroup(roles[n]), { host: a.Address || null, os: h.OperatingSystem || null, site: h.ADSite || null, roles: roles[n] || [], model: [h.Manufacturer, h.Model].filter(Boolean).join(' ') || null });
    }

    // ---- Windows
    for (const c of rows('servers.compute')) {
      const d = dev(short(c.Name), 'server', 'g:srv');
      const off = c.Online === false;
      const down = off ? { forced: 'Down', message: 'No answer from the server' } : {};
      add('wmi.cpu', d, null, 'CPU load', Object.assign({ channels: off ? [] : [ch('Total', '%', { warnHigh: 80, errHigh: 95 }, true), ch('Processor queue', '#', { warnHigh: 10 })].map((x, i) => Object.assign(x, { value: [c.CPU, c.CPUQueue][i] })), message: c.TopProcess ? 'Top process ' + c.TopProcess : '' }, down));
      if (!off) {
        add('wmi.memory', d, null, 'Memory', { channels: [Object.assign(ch('Used', '%', { warnHigh: 85, errHigh: 95 }, true), { value: c.Memory }), Object.assign(ch('Available', 'GB', {}), { value: r1(c.MemoryFreeGB) })] });
        add('wmi.diskio', d, null, 'Disk I/O', { channels: [Object.assign(ch('IOPS', '#/s', {}, true), { value: (c.DiskReadIOPS || 0) + (c.DiskWriteIOPS || 0) }), Object.assign(ch('Latency', 'ms', { warnHigh: 20, errHigh: 50 }), { value: c.DiskLatencyMs }), Object.assign(ch('Queue', '#', { warnHigh: 5 }), { value: c.DiskQueue })] });
        add('wmi.network', d, null, 'Network traffic', { channels: [Object.assign(ch('Total', 'Mbit/s', {}, true), { value: r1((c.NetKBps || 0) * 8 / 1000) })] });
      }
    }
    for (const r of rows('servers.disks')) {
      const d = dev(short(r.ComputerName), 'server', 'g:srv');
      add('wmi.disk', d, r.Volume, 'Disk free ' + r.Volume + (r.Label ? ' ' + r.Label : ''), { channels: [Object.assign(ch('Free space', '%', { warnLow: 15, errLow: 5 }, true), { value: r1(100 - r.UsedPct) }), Object.assign(ch('Free bytes', 'GB', {}), { value: r1(r.FreeGB) })] });
    }
    for (const r of rows('servers.availability')) {
      const d = dev(short(r.Name), 'server', 'g:srv');
      const off = r.Status !== 'Online';
      add('wmi.availability', d, null, 'Availability', { forced: off ? 'Down' : null, message: off ? 'Not answering ping or management ports' : '', channels: off ? [] : [Object.assign(ch('Ping time', 'ms', { warnHigh: 100, errHigh: 500 }, true), { value: r.LatencyMs }), Object.assign(ch('Uptime', 'd', {}), { value: r1(r.UptimeDays) }), Object.assign(ch('WinRM 5985', '', { errLow: 1 }), { value: r.Port5985 ? 1 : 0 }), Object.assign(ch('RDP 3389', '', {}), { value: r.Port3389 ? 1 : 0 }), Object.assign(ch('SMB 445', '', {}), { value: r.Port445 ? 1 : 0 })] });
    }
    groupBy(rows('servers.services'), (r) => short(r.ComputerName)).forEach((list, n) => {
      const bad = list.filter((s) => s.Problem);
      add('wmi.services', dev(n, 'server', 'g:srv'), null, 'Windows services', { channels: [Object.assign(ch('Stopped automatic services', '#', { errHigh: 0 }, true), { value: bad.length }), Object.assign(ch('Watched services', '#', {}), { value: list.length })], message: bad.length ? 'Stopped: ' + bad.map((s) => s.DisplayName || s.Name).join(', ') : list.length + ' services running' });
    });
    groupBy(rows('servers.iis'), (r) => short(r.ComputerName)).forEach((list, n) => {
      const bad = list.filter((p) => p.State !== 'Started');
      add('wmi.iis', dev(n, 'server', 'g:web'), null, 'IIS application pools', { channels: [Object.assign(ch('Pools not started', '#', { errHigh: 0 }, true), { value: bad.length }), Object.assign(ch('Pools', '#', {}), { value: list.length })], message: bad.length ? 'Not started: ' + bad.map((p) => p.Pool).join(', ') : '' });
    });
    for (const r of rows('servers.activation')) {
      const lic = r.Status === 'Licensed';
      add('wmi.activation', dev(short(r.ComputerName), 'server', 'g:srv'), null, 'Windows activation', { forced: lic ? null : 'Warning', message: lic ? r.Channel + ' licence' : 'Windows is ' + r.Status, channels: [Object.assign(ch('Grace period', 'd', {}, true), { value: r1((r.GraceMinutes || 0) / 1440) })] });
    }
    for (const r of rows('security.defender')) {
      const off = r.Installed && !r.RealTime;
      add('sec.defender', dev(short(r.ComputerName), 'server', 'g:srv'), null, 'Defender', { forced: !r.Installed ? 'Warning' : off ? 'Down' : null, message: !r.Installed ? 'Defender not installed' : off ? 'Real-time protection is off' : '', channels: r.Installed ? [Object.assign(ch('Signature age', 'd', { warnHigh: 3, errHigh: 7 }, true), { value: r.SignatureAgeDays }), Object.assign(ch('Active threats', '#', { errHigh: 0 }), { value: (r.Detections || []).length })] : [] });
    }
    for (const r of rows('security.patches')) {
      add('sec.patches', dev(short(r.ComputerName), 'server', 'g:srv'), null, 'Windows updates', { message: r.LastKB ? 'Last ' + r.LastKB : '', channels: [Object.assign(ch('Days since last patch', 'd', { warnHigh: 45, errHigh: 90 }, true), { value: r.DaysSincePatch }), Object.assign(ch('Pending updates', '#', { warnHigh: 10 }), { value: r.PendingUpdates }), Object.assign(ch('Reboot pending', '', { warnHigh: 0 }), { value: r.PendingReboot ? 1 : 0 })] });
    }
    for (const r of rows('security.firewall')) {
      const off = [r.Domain, r.Private, r.Public].filter((x) => x === false).length;
      add('sec.firewall', dev(short(r.ComputerName), 'server', 'g:srv'), null, 'Firewall', { message: (r.Issues || []).join('; '), channels: [Object.assign(ch('Profiles off', '#', { warnHigh: 0 }, true), { value: off }), Object.assign(ch('SMBv1 enabled', '', { errHigh: 0 }), { value: r.SMB1 ? 1 : 0 })] });
    }
    groupBy(rows('servers.events'), (r) => short(r.ComputerName)).forEach((list, n) => {
      const r = list[0];
      add('win.events', dev(n, 'server', 'g:srv'), null, 'Event log errors', { message: r.TopSource ? 'Most frequent: ' + r.TopSource + ' (' + r.TopEventId + ')' : '', channels: [Object.assign(ch('Critical', '#', { errHigh: 0 }, true), { value: r.Critical || 0 }), Object.assign(ch('Errors', '#', { warnHigh: 20 }), { value: r.Errors || 0 }), Object.assign(ch('Warnings', '#', {}), { value: r.Warnings || 0 })] });
    });

    // ---- Active Directory: a device per domain plus DC sensors on the DC devices
    const domain = (ds['ad.health'] || {}).summary ? ds['ad.health'].summary.domain : null;
    const dom = domain ? dev(domain, 'domain', 'g:ad', { host: domain }) : null;
    for (const r of rows('ad.health')) {
      const d = dev(short(r.Name), 'server', 'g:dc', { host: r.IPv4 });
      d.group = 'g:dc';
      const flags = [r.Sysvol, r.Netlogon, r.DnsOK].filter((x) => x === false).length;
      add('ad.dc', d, null, 'Domain controller', { forced: r.Online === false ? 'Down' : null, message: (r.Problems || []).join('; ') || ('FSMO: ' + ((r.FSMO || []).join(', ') || 'none')), channels: r.Online === false ? [] : [Object.assign(ch('AD services down', '#', { errHigh: 0 }, true), { value: (r.ServicesDown || []).length }), Object.assign(ch('Time offset', 's', { warnHigh: 1, errHigh: 5 }), { value: Math.abs(r.TimeOffsetSec || 0) }), Object.assign(ch('SYSVOL / NETLOGON / DNS failures', '#', { errHigh: 0 }), { value: flags })] });
    }
    groupBy(rows('ad.replication'), (r) => short(r.Server)).forEach((list, n) => {
      const fail = list.filter((x) => x.Status !== 'OK');
      add('ad.replication', dev(n, 'server', 'g:dc'), null, 'AD replication', { message: fail.length ? 'Failing from ' + [...new Set(fail.map((f) => f.Partner))].join(', ') + ' (error ' + fail[0].LastResult + ')' : list.length + ' links healthy', channels: [Object.assign(ch('Failing links', '#', { errHigh: 0 }, true), { value: fail.length }), Object.assign(ch('Oldest success', 'min', { warnHigh: 60, errHigh: 180 }), { value: Math.max(0, ...list.map((x) => x.MinutesSinceSuccess || 0)) }), Object.assign(ch('Links', '#', {}), { value: list.length })] });
    });
    if (dom) {
      const users = rows('ad.users');
      if (users.length) add('ad.accounts', dom, null, 'AD accounts', { channels: [Object.assign(ch('Locked out', '#', { warnHigh: 5, errHigh: 25 }, true), { value: users.filter((u) => u.LockedOut).length }), Object.assign(ch('Stale enabled accounts', '#', { warnHigh: 50 }), { value: users.filter((u) => u.Stale && u.Enabled).length }), Object.assign(ch('Password never expires', '#', {}), { value: users.filter((u) => u.PasswordNeverExpires && u.Enabled).length }), Object.assign(ch('Privileged accounts', '#', {}), { value: users.filter((u) => u.Privileged).length }), Object.assign(ch('Enabled users', '#', {}), { value: users.filter((u) => u.Enabled).length })] });
      const comps = rows('ad.computers');
      if (comps.length) add('ad.computers', dom, null, 'AD computer accounts', { channels: [Object.assign(ch('Stale computers', '#', { warnHigh: 25 }, true), { value: comps.filter((c) => c.Stale && c.Enabled).length }), Object.assign(ch('Disabled', '#', {}), { value: comps.filter((c) => !c.Enabled).length }), Object.assign(ch('Total', '#', {}), { value: comps.length })] });
      const ev = rows('audit.events').filter((e) => now - Date.parse(e.Time) < 24 * H);
      if ((ds['audit.events'] || {}).data) add('ad.audit', dom, null, 'AD security events (24 h)', { channels: [Object.assign(ch('Failed logons', '#', { warnHigh: 200 }, true), { value: ev.filter((e) => e.EventSet === 'BadLogon').length }), Object.assign(ch('Lockouts', '#', { warnHigh: 3, errHigh: 20 }), { value: ev.filter((e) => e.EventSet === 'Lockout').length }), Object.assign(ch('Privileged group changes', '#', { errHigh: 0 }), { value: ev.filter((e) => e.Privileged).length }), Object.assign(ch('Kerberos pre-auth failures', '#', { warnHigh: 50 }), { value: ev.filter((e) => e.EventSet === 'KerberosPreAuthFailed').length })] });
      const gpo = rows('ad.gpo');
      const sites = rows('ad.sites');
      if (sites.length) add('ad.sites', dom, null, 'AD sites and site links', { channels: [Object.assign(ch('Sites without a DC', '#', { warnHigh: 0 }, true), { value: sites.filter((r) => r.Kind === 'site' && !(r.DomainControllers || []).length).length }), Object.assign(ch('Subnets in no site', '#', { warnHigh: 0 }), { value: sites.filter((r) => r.Kind === 'subnet' && !r.Site).length }), Object.assign(ch('Sites', '#', {}), { value: sites.filter((r) => r.Kind === 'site').length }), Object.assign(ch('Site links', '#', {}), { value: sites.filter((r) => r.Kind === 'link').length })] });
      if (gpo.length) add('ad.gpo', dom, null, 'Group Policy', { channels: [Object.assign(ch('Version mismatches', '#', { warnHigh: 0 }, true), { value: gpo.filter((g) => g.VersionMismatch).length }), Object.assign(ch('Unlinked GPOs', '#', {}), { value: gpo.filter((g) => !g.Links).length }), Object.assign(ch('Empty GPOs', '#', {}), { value: gpo.filter((g) => g.Empty).length }), Object.assign(ch('GPOs', '#', {}), { value: gpo.length })] });
    }

    // ---- DNS, DHCP, file servers
    for (const r of rows('dns.servers')) {
      const d = dev(short(r.ComputerName), 'server', 'g:dns');
      add('dns.server', d, null, 'DNS server', { forced: r.ServiceState && r.ServiceState !== 'Running' ? 'Down' : null, message: r.ServiceState !== 'Running' ? 'DNS service ' + r.ServiceState : (r.FailedTests || []).join('; '), channels: [Object.assign(ch('Resolution time', 'ms', { warnHigh: 200, errHigh: 2000 }, true), { value: r.ResolveMs }), Object.assign(ch('Failed resolution tests', '#', { errHigh: 0 }), { value: (r.FailedTests || []).length }), Object.assign(ch('Zones', '#', {}), { value: r.Zones }), Object.assign(ch('Zones not running', '#', { errHigh: 0 }), { value: r.ZonesPaused || 0 }), Object.assign(ch('DNS errors 24 h', '#', { warnHigh: 10 }), { value: r.Errors24h || 0 }), Object.assign(ch('Queries/s', '#/s', {}), { value: r.QueriesPerSec })] });
    }
    for (const r of rows('network.dhcp')) {
      const d = dev(short(r.Server), 'server', 'g:dns');
      add('dhcp.scope', d, r.ScopeId, 'DHCP ' + r.Name + ' (' + r.ScopeId + ')', { forced: r.State !== 'Active' ? 'Warning' : null, message: r.State !== 'Active' ? 'Scope is ' + r.State : r.Failover ? 'Failover ' + r.Failover : '', channels: [Object.assign(ch('In use', '%', { warnHigh: 80, errHigh: 95 }, true), { value: r.PercentInUse }), Object.assign(ch('Free addresses', '#', {}), { value: r.Free }), Object.assign(ch('Leased', '#', {}), { value: r.InUse })] });
    }
    for (const r of rows('fileserver.health')) {
      const d = dev(short(r.ComputerName), 'server', 'g:fs');
      add('fs.server', d, null, 'File server', { message: r.Message || '', channels: [Object.assign(ch('SMB sessions', '#', {}, true), { value: r.Sessions }), Object.assign(ch('Open files', '#', {}), { value: r.OpenFiles }), Object.assign(ch('Shares', '#', {}), { value: r.Shares }), Object.assign(ch('Quotas over 90%', '#', { warnHigh: 0 }), { value: r.QuotasNearLimit || 0 }), Object.assign(ch('Lowest volume free', '%', { warnLow: 15, errLow: 5 }), { value: r.LowestFreePct }), Object.assign(ch('Newest shadow copy', 'h', { warnHigh: 36 }), { value: r.ShadowCopyAgeHours })] });
    }
    const fileEv = rows('audit.events').filter((e) => /^File/.test(e.EventSet) && now - Date.parse(e.Time) < 24 * H);
    groupBy(fileEv, (e) => short(e.Server)).forEach((list, n) => {
      add('fs.audit', dev(n, 'server', 'g:fs'), null, 'File access audit (24 h)', { channels: [Object.assign(ch('Access events', '#', {}, true), { value: list.length }), Object.assign(ch('Deletions', '#', { warnHigh: 200 }), { value: list.filter((e) => e.EventSet === 'FileDelete').length }), Object.assign(ch('Permission changes', '#', { warnHigh: 0 }), { value: list.filter((e) => e.EventSet === 'FilePermission').length })] });
    });

    // ---- Hyper-V
    for (const r of rows('virtualization.hyperv')) {
      if (r.Kind === 'Host') {
        const d = dev(short(r.Name), 'server', 'g:hv');
        d.group = 'g:hv';
        add('hv.host', d, null, 'Hyper-V host', { channels: [Object.assign(ch('Running VMs', '#', {}, true), { value: r.VMRunning }), Object.assign(ch('Stopped VMs', '#', {}), { value: (r.VMCount || 0) - (r.VMRunning || 0) }), Object.assign(ch('Memory used', '%', { warnHigh: 90, errHigh: 97 }), { value: r.MemoryGB ? r1(100 - (r.MemoryFreeGB / r.MemoryGB) * 100) : null }), Object.assign(ch('vCPU per logical CPU', ':1', { warnHigh: 4 }), { value: r.LogicalCPUs ? r1(r.vCPUAssigned / r.LogicalCPUs) : null })] });
      } else if (r.Kind === 'VM') {
        const d = dev(short(r.Host), 'server', 'g:hv');
        const run = r.State === 'Running';
        add('hv.vm', d, r.Name, 'VM ' + r.Name, { forced: !run ? 'Warning' : r.Heartbeat && !/^Ok/.test(r.Heartbeat) ? 'Warning' : null, message: !run ? 'VM is ' + r.State : r.Heartbeat && !/^Ok/.test(r.Heartbeat) ? 'Heartbeat ' + r.Heartbeat : '', channels: run ? [Object.assign(ch('CPU usage', '%', { warnHigh: 85, errHigh: 97 }, true), { value: r.CPUUsage }), Object.assign(ch('Memory assigned', 'GB', {}), { value: r.MemoryAssignedGB }), Object.assign(ch('Oldest checkpoint', 'd', { warnHigh: 7, errHigh: 30 }), { value: r.OldestCheckpointDays || 0 })] : [] });
      }
    }
    // ---- VMware: a device per vCenter (datastores) and per ESXi host (host + VMs)
    for (const r of rows('virtualization.vmware')) {
      if (r.Kind === 'ESXi') {
        const d = dev(r.Name.split('.')[0].toLowerCase(), 'esxi', 'g:vmw', { host: r.Name, model: r.Model });
        add('vmw.host', d, null, 'ESXi host', { forced: r.State !== 'Connected' ? 'Down' : null, message: r.State !== 'Connected' ? 'Host is ' + r.State : r.Version, channels: r.State !== 'Connected' ? [] : [Object.assign(ch('CPU usage', '%', { warnHigh: 80, errHigh: 95 }, true), { value: r.CPUUsedPct }), Object.assign(ch('Memory usage', '%', { warnHigh: 85, errHigh: 95 }), { value: r.MemoryUsedPct }), Object.assign(ch('VMs', '#', {}), { value: r.VMs })] });
      } else if (r.Kind === 'Datastore') {
        const d = dev(r.VCenter.split('.')[0].toLowerCase(), 'vcenter', 'g:vmw', { host: r.VCenter });
        add('vmw.datastore', d, r.Name, 'Datastore ' + r.Name, { forced: r.State !== 'Available' ? 'Down' : null, channels: [Object.assign(ch('Free space', '%', { warnLow: 15, errLow: 5 }, true), { value: r1(100 - r.UsedPct) }), Object.assign(ch('Free', 'GB', {}), { value: r.FreeGB })] });
      } else if (r.Kind === 'VM') {
        const d = dev(String(r.Host).split('.')[0].toLowerCase(), 'esxi', 'g:vmw', { host: r.Host });
        const on = r.Power === 'PoweredOn';
        add('vmw.vm', d, r.Name, 'VM ' + r.Name, { forced: !on ? 'Warning' : r.ToolsStatus !== 'toolsOk' ? 'Warning' : null, message: !on ? 'Powered off' : r.ToolsStatus !== 'toolsOk' ? 'VMware Tools: ' + r.ToolsStatus : '', channels: [Object.assign(ch('Snapshot age', 'd', { warnHigh: 7, errHigh: 30 }, true), { value: r.OldestSnapshotDays || 0 }), Object.assign(ch('Disk used', 'GB', {}), { value: r.UsedSpaceGB })] });
      }
    }
    // ---- OpenShift Virtualization: a device per cluster API, sensors per node and per VM
    for (const r of rows('virtualization.openshift')) {
      const d = dev(String(r.Cluster).replace(/^api\./, '').split('.')[0], 'cluster', 'g:ocp', { host: r.Cluster, os: 'OpenShift' });
      if (r.Kind === 'Node') add('ocp.node', d, r.Name, 'Node ' + r.Name, { forced: r.State !== 'Ready' ? 'Down' : null, message: r.State !== 'Ready' ? 'Node is ' + r.State : r.Version || '', channels: [Object.assign(ch('Running VMs', '#', {}, true), { value: r.VMs || 0 }), Object.assign(ch('CPUs', '#', {}), { value: r.CPUs }), Object.assign(ch('Memory', 'GB', {}), { value: r.MemoryGB })] });
      else if (r.Kind === 'VM') { const on = r.Power === 'Running'; add('ocp.vm', d, r.Name, 'VM ' + r.Name, { forced: r.Status === 'Critical' ? 'Down' : !on ? 'Warning' : !r.Agent ? 'Warning' : null, message: !on ? 'VM is ' + r.Power : !r.Agent ? 'Guest agent not connected' : r.Namespace ? 'namespace ' + r.Namespace : '', channels: on ? [Object.assign(ch('CPU usage', '%', { warnHigh: 85, errHigh: 97 }, true), { value: r.CPU || 0 }), Object.assign(ch('vCPU', '#', {}), { value: r.vCPU })] : [] }); }
    }
    // ---- Nutanix AHV: a device per cluster (Prism), sensors per host, VM and storage container
    for (const r of rows('virtualization.nutanix')) {
      const d = dev(String(r.Cluster), 'cluster', 'g:ntx', { os: 'Nutanix AOS' });
      if (r.Kind === 'Host') add('ntx.host', d, r.Name, 'Host ' + r.Name, { forced: r.Status === 'Critical' ? 'Down' : r.Status === 'Warning' ? 'Warning' : null, message: r.Version || '', channels: [Object.assign(ch('Running VMs', '#', {}, true), { value: r.VMs || 0 }), Object.assign(ch('CPUs', '#', {}), { value: r.CPUs }), Object.assign(ch('Memory', 'GB', {}), { value: r.MemoryGB })] });
      else if (r.Kind === 'VM') { const on = r.Power === 'Running'; add('ntx.vm', d, r.Name, 'VM ' + r.Name, { forced: !on ? 'Warning' : !r.Agent ? 'Warning' : null, message: !on ? 'VM is ' + r.Power : !r.Agent ? 'Nutanix Guest Tools not running' : '', channels: on ? [Object.assign(ch('CPU usage', '%', { warnHigh: 85, errHigh: 97 }, true), { value: r.CPU || 0 }), Object.assign(ch('vCPU', '#', {}), { value: r.vCPU })] : [] }); }
      else if (r.Kind === 'Container') add('ntx.container', d, r.Name, 'Container ' + r.Name, { channels: [Object.assign(ch('Free space', '%', { warnLow: 15, errLow: 5 }, true), { value: r1(100 - r.UsedPct) }), Object.assign(ch('Free', 'GB', {}), { value: r.FreeGB })] });
    }
    for (const r of rows('virtualization.clusters')) {
      const d = dev(r.Cluster, 'cluster', 'g:cl');
      const off = (r.Roles || []).filter((x) => x.State !== 'Online');
      add('cluster', d, null, 'Failover cluster', { message: off.length ? 'Offline roles: ' + off.map((x) => x.Name).join(', ') : r.QuorumType, channels: [Object.assign(ch('Nodes down', '#', { errHigh: 0 }, true), { value: (r.Nodes || []).length - (r.NodesUp || 0) }), Object.assign(ch('Roles offline', '#', { errHigh: 0 }), { value: off.length }), Object.assign(ch('Nodes', '#', {}), { value: (r.Nodes || []).length })] });
    }
    for (const r of rows('virtualization.clusterstorage')) {
      add('cluster.csv', dev(r.Cluster, 'cluster', 'g:cl'), r.Name, r.Name, { forced: r.State !== 'Online' ? 'Down' : r.Redirected ? 'Warning' : null, message: r.Redirected ? 'Redirected access' : r.Path, channels: [Object.assign(ch('Free space', '%', { warnLow: 15, errLow: 5 }, true), { value: r1(100 - r.UsedPct) }), Object.assign(ch('Free', 'GB', {}), { value: r.FreeGB })] });
    }

    // ---- SQL, printers, Linux, network devices
    groupBy(rows('sql.databases'), (r) => short(r.Instance)).forEach((list, n) => {
      const d = dev(n, 'server', 'g:sql');
      const bad = list.filter((x) => x.Health !== 'OK');
      add('sql.instance', d, null, 'SQL Server', { message: bad.length ? bad.map((x) => x.Database + ': ' + (x.Problems || []).join(', ')).join('; ') : list.length + ' databases', channels: [Object.assign(ch('Databases with problems', '#', { errHigh: 0 }, true), { value: bad.length }), Object.assign(ch('Oldest full backup', 'h', { warnHigh: 26, errHigh: 50 }), { value: Math.max(0, ...list.filter((x) => x.Database !== 'tempdb').map((x) => (x.FullBackupAgeHours == null ? 9999 : x.FullBackupAgeHours))) }), Object.assign(ch('Total size', 'GB', {}), { value: r1(list.reduce((a, x) => a + (x.SizeMB || 0), 0) / 1024) }), Object.assign(ch('Databases', '#', {}), { value: list.length })] });
    });
    for (const r of rows('printers.health')) {
      const d = dev(r.Printer, 'printer', 'g:printers', { host: r.IPAddress, site: (r.Location || '').split(' / ')[0] || null });
      const down = r.Reachable === false || /Offline|Error/.test(r.Status), warn = /Toner|Paper|Jam/i.test(r.Status);
      add('printer', d, null, 'Printer', { forced: down ? 'Down' : warn ? 'Warning' : null, message: r.Status !== 'Normal' ? r.Status + ' on ' + r.PrintServer : 'Shared on ' + r.PrintServer, channels: [Object.assign(ch('Queued jobs', '#', { warnHigh: 10 }, true), { value: r.Jobs }), Object.assign(ch('Stuck jobs', '#', { warnHigh: 0 }), { value: r.StuckJobs })] });
    }
    for (const r of rows('linux.hosts')) {
      const d = dev(r.Name, 'linux', 'g:lnx', { host: (r.ipAddresses || [])[0], os: r.os, site: r.Site });
      add('ssh.linux', d, null, 'Linux (SSH)', { forced: r.Online === false ? 'Down' : null, channels: r.Online === false ? [] : [Object.assign(ch('CPU', '%', { warnHigh: 85, errHigh: 97 }, true), { value: r.cpuPct }), Object.assign(ch('Memory', '%', { warnHigh: 90, errHigh: 97 }), { value: r.memUsedPct }), Object.assign(ch('Fullest filesystem', '%', { warnHigh: 85, errHigh: 95 }), { value: r.WorstDiskPct }), Object.assign(ch('Load (1 min)', '', { warnHigh: (r.cpuCount || 1) * 1.5 }), { value: (r.load || [])[0] }), Object.assign(ch('Failed units', '#', { warnHigh: 0 }), { value: r.failedUnits }), Object.assign(ch('Security updates', '#', { warnHigh: 0 }), { value: r.securityUpdates })] });
    }
    for (const r of rows('network.discovery')) {
      if (r.DeviceClass === 'Unknown' && !r.HostName) continue;
      const name = r.HostName ? r.HostName.split('.')[0].toUpperCase() : r.IPAddress;
      if (devices.has(devId(name)) && devices.get(devId(name)).kind === 'server') continue;
      const d = dev(name, r.DeviceClass === 'Network device' ? 'network' : 'appliance', 'g:net', { host: r.IPAddress, site: r.Site, mac: r.MAC, ports: r.OpenPorts });
      add('net.discovery', d, null, 'Ping (discovery)', { channels: [Object.assign(ch('Ping time', 'ms', { warnHigh: 100, errHigh: 500 }, true), { value: r.LatencyMs }), Object.assign(ch('Open ports', '#', {}), { value: (r.OpenPorts || []).length })] });
    }
    // ---- engines added in 4.7.2: SNMP network and storage devices, Linux, web, certificates, temperature, containers, cloud network
    const st2 = (v) => (v === 'Critical' ? 'Down' : v === 'Warning' ? 'Warning' : null);
    const val = (c, v) => Object.assign(c, { value: v == null ? null : v });
    const NET_KIND = { Switch: 'network', Router: 'network', Firewall: 'firewall', 'Wireless controller': 'wireless', 'Access point': 'wireless', 'Load balancer': 'loadbalancer', WAF: 'waf', 'VPN gateway': 'vpn' };
    for (const r of rows('network.devices')) {
      const kind = NET_KIND[r.Class] || 'network';
      const d = dev(alias[String(r.Name).toLowerCase()] || (r.SysName ? short(r.SysName) : r.Name), kind, kind === 'firewall' ? 'g:fw' : 'g:net', { host: r.Name, site: r.Location || null, vendor: r.Vendor || null, netClass: r.Class || null });
      const extra = [val(ch('CPU', '%', { warnHigh: 85, errHigh: 97 }), r.CpuPct), val(ch('Memory', '%', { warnHigh: 85, errHigh: 95 }), r.MemPct), val(ch('Sessions', '#', {}), r.Sessions), val(ch('Session table', '%', { warnHigh: 85, errHigh: 95 }), r.SessionPct),
        val(ch('VPN tunnels down', '#', { warnHigh: 0 }), r.VpnTunnelsDown), val(ch('VPN tunnels', '#', {}), r.VpnTunnels), val(ch('VPN users', '#', {}), r.VpnUsers), val(ch('Access points down', '#', { warnHigh: 0 }), r.APsDown), val(ch('Access points', '#', {}), r.APs), val(ch('Wireless clients', '#', {}), r.WifiClients),
        val(ch('BGP peers down', '#', { warnHigh: 0 }), r.BgpDown), val(ch('Connections', '#', {}), r.LbConnections), val(ch('Virtual servers down', '#', { warnHigh: 0 }), r.VirtualServersDown), val(ch('Pool members down', '#', { warnHigh: 0 }), r.PoolMembersDown), val(ch('Input errors', '#', {}), r.InErrors)].filter((c) => c.value != null);
      add('net.snmpdev', d, null, (r.Class && r.Class !== 'Other' ? r.Class : 'Network device') + ' (SNMP)', { forced: r.Status === 'Unknown' && r.UptimeDays == null ? 'Down' : st2(r.Status), message: r.Message + (r.Vendor && r.Vendor !== 'Other' ? ' · ' + r.Vendor : ''), channels: r.UptimeDays == null ? [] : [val(ch('Interfaces down (enabled)', '#', { warnHigh: 0 }, true), r.DownEnabled), val(ch('Interfaces up', '#', {}), r.Up), val(ch('Uptime', 'd', { warnLow: 0.02 }), r.UptimeDays)].concat(extra) });
    }
    for (const r of rows('storage.devices')) {
      if (!r.Volume) continue;
      const d = dev(alias[String(r.Name).toLowerCase()] || (r.SysName ? short(r.SysName) : r.Name), 'nas', 'g:storage', { host: r.Name });
      add('storage.snmpdev', d, r.Volume, 'Volume ' + r.Volume, { forced: st2(r.Status), message: r.Message, channels: [val(ch('Used', '%', { warnHigh: 85, errHigh: 95 }, true), r.UsedPct), val(ch('Free', 'GB', {}), r.SizeGB != null && r.UsedGB != null ? Math.round(r.SizeGB - r.UsedGB) : null)] });
    }
    groupBy(rows('linux.filesystems'), (r) => nm(r.Name)).forEach((list, n) => {
      const d = dev(n, 'linux', 'g:lnx');
      for (const r of list) if (r.Mount) add('lnx.fs', d, r.Mount, 'Filesystem ' + r.Mount, { forced: st2(r.Status), message: r.Message, channels: r.UsedPct == null ? [] : [val(ch('Used', '%', { warnHigh: 85, errHigh: 95 }, true), r.UsedPct), val(ch('Inodes used', '%', { warnHigh: 85, errHigh: 95 }), r.InodesPct), val(ch('Free', 'GB', {}), r.SizeGB != null ? Math.round((r.SizeGB - r.UsedGB) * 10) / 10 : null)] });
    });
    groupBy(rows('linux.services'), (r) => nm(r.Name)).forEach((list, n) => {
      const d = dev(n, 'linux', 'g:lnx');
      const bad = list.filter((r) => r.Status === 'Critical'), host = list.find((r) => r.Kind === 'Host');
      add('lnx.services', d, null, 'Linux services', { forced: host && host.Status === 'Unknown' && !bad.length ? 'Down' : bad.length ? 'Down' : null, message: bad.length ? bad.map((r) => r.Message).slice(0, 4).join('; ') : (host || {}).Message || list.filter((r) => r.Kind === 'Watched service').length + ' watched services running', channels: [val(ch('Failed units', '#', { errHigh: 0 }, true), list.filter((r) => r.Kind === 'Failed unit').length), val(ch('Watched services stopped', '#', { errHigh: 0 }), list.filter((r) => r.Kind === 'Watched service' && r.Status === 'Critical').length)] });
    });
    for (const r of rows('linux.audit')) {
      const d = dev(nm(r.Name), 'linux', 'g:lnx');
      add('lnx.audit', d, null, 'Linux audit', { forced: r.Status === 'Unknown' ? 'Down' : st2(r.Status), message: r.Message, channels: r.FailedLogins == null ? [] : [val(ch('Failed logins', '#', { warnHigh: 20, errHigh: 100 }, true), r.FailedLogins), val(ch('Root SSH logins', '#', { errHigh: 0 }), r.RootLogins), val(ch('Refused sudo', '#', { warnHigh: 0 }), r.SudoFailures), val(ch('Sudo commands', '#', {}), r.SudoCommands)] });
    }
    for (const r of rows('web.servers')) {
      const d = dev(nm(r.Name), 'web', 'g:web-checks', { host: r.Name });
      add('web.server', d, r.Url, 'Web ' + r.Url.replace(/^https?:\/\//, '').replace(/\/$/, ''), { forced: st2(r.Status), message: r.Message + (r.ServerKind && r.ServerKind !== 'Unknown' ? ' · ' + r.ServerKind : ''), channels: r.StatusCode == null ? [] : [val(ch('Response time', 'ms', { warnHigh: 2000, errHigh: 8000 }, true), r.ResponseMs), val(ch('Status code', '', { errHigh: 499 }), r.StatusCode)] });
    }
    for (const r of rows('ssl.certificates')) {
      const known = devices.get(devId(nm(r.Name)));
      const d = known || dev(nm(r.Name), 'web', 'g:web-checks', { host: r.Name });
      add('ssl.engine', d, String(r.Port), 'Certificate ' + r.Name + ':' + r.Port, { forced: r.DaysLeft == null ? 'Down' : st2(r.Status), message: r.Message + (r.Issuer ? ' · issued by ' + r.Issuer : ''), channels: r.DaysLeft == null ? [] : [val(ch('Days to expiration', 'd', { warnLow: 30, errLow: 7 }, true), r.DaysLeft), val(ch('Trusted chain', '', { errLow: 1 }), r.Trusted ? 1 : 0), val(ch('Name matches', '', { warnLow: 1 }), r.NameMatch ? 1 : 0)] });
    }
    for (const r of rows('web.hosts')) {
      if (r.Product === 'None') continue;
      const lnx = /linux/i.test(r.OS || '');
      const d = devices.get(devId(nm(r.Name))) || dev(nm(r.Name), lnx ? 'linux' : 'server', lnx ? 'g:lnx' : 'g:web', { host: r.Name });
      if (r.Product === 'Host') { add('web.host', d, 'host', 'Web server software', { forced: 'Down', message: r.Message, channels: [] }); continue; }
      add('web.host', d, r.Product, r.Product + (r.Service ? ' (' + r.Service + ')' : ''), { forced: st2(r.Status), message: r.Message + (r.Version ? ' · ' + r.Product + ' ' + r.Version : ''), channels: [val(ch('Running', '', { errLow: r.Enabled === false ? null : 1 }, true), r.Running == null ? null : r.Running ? 1 : 0), val(ch('Connections', '#', {}), r.Connections), val(ch('Requests/s', '#/s', {}), r.RequestsPerSec),
        val(ch('Busy workers', '%', { warnHigh: 90 }), r.Workers && r.BusyWorkers != null ? Math.round((r.BusyWorkers / r.Workers) * 100) : null), val(ch('Sites stopped', '#', { warnHigh: 0 }), r.SitesStopped), val(ch('Configuration test', '', { warnLow: 1 }), r.ConfigOk == null ? null : r.ConfigOk ? 1 : 0), val(ch('Errors', '#', { warnHigh: 50 }), r.Errors)].filter((c) => c.value != null) });
    }
    groupBy(rows('hardware.temperature'), (r) => nm(r.Name)).forEach((list, n) => {
      const d = devices.get(devId(n)) || dev(n, 'appliance', 'g:power');
      const got = list.filter((r) => r.Celsius != null).sort((a, b) => b.Celsius - a.Celsius);
      const worst = got.find((r) => r.Status === 'Critical') ? 'Down' : got.find((r) => r.Status === 'Warning') ? 'Warning' : null;
      add('hw.temp', d, null, 'Temperature', { forced: got.length ? worst : 'Down', message: got.length ? got.length + ' sensor(s) · hottest ' + got[0].Sensor + ' ' + got[0].Celsius + ' °C (' + got[0].Source + ')' : (list[0] || {}).Message, channels: got.slice(0, 16).map((r, i) => val(ch(String(r.Sensor || 'Sensor ' + (i + 1)).slice(0, 60), '°C', { warnHigh: r.WarningC, errHigh: r.CriticalC }, i === 0), r.Celsius)) });
    });
    groupBy(rows('containers.kubernetes'), (r) => r.Cluster).forEach((list, cname) => {
      const c = list.find((r) => r.Kind === 'Cluster') || {};
      const cd = dev(alias[String(cname).toLowerCase()] || cname, 'k8scluster', 'g:k8s', { host: c.Address || null, os: c.Version || null });
      add('k8s.cluster', cd, null, 'Kubernetes cluster', { forced: c.Nodes == null ? 'Down' : st2(c.Status), message: c.Message, channels: c.Nodes == null ? [] : [val(ch('Failing pods', '#', { warnHigh: 0, errHigh: 10 }, true), c.PodsFailing), val(ch('Nodes not ready', '#', { errHigh: 0 }), c.Nodes - c.NodesReady), val(ch('Workloads degraded', '#', { warnHigh: 0 }), c.WorkloadsDegraded), val(ch('Pods running', '#', {}), c.PodsRunning), val(ch('Warning events (1 h)', '#', { warnHigh: 50 }), c.WarningEvents1h), val(ch('CPU', '%', { warnHigh: 80, errHigh: 95 }), c.CPUPct), val(ch('Memory', '%', { warnHigh: 85, errHigh: 95 }), c.MemoryPct)] });
      for (const r of list.filter((x) => x.Kind === 'Node')) {
        const nd = dev(alias[String(r.Name).toLowerCase()] || short(r.Name), 'k8snode', 'g:k8s', { host: r.Address || null, os: r.OS || null, cluster: cname });
        add('k8s.node', nd, null, 'Kubernetes node', { forced: st2(r.Status), message: r.Message + ' · ' + (r.Roles || '') + ' · ' + (r.Version || ''), channels: [val(ch('Ready', '', { errLow: 1 }, true), r.Ready ? 1 : 0), val(ch('CPU', '%', { warnHigh: 85, errHigh: 97 }), r.CPUPct), val(ch('Memory', '%', { warnHigh: 85, errHigh: 95 }), r.MemoryPct), val(ch('Pods', '#', {}), r.Pods)] });
      }
      for (const r of list.filter((x) => ['Deployment', 'StatefulSet', 'DaemonSet'].includes(x.Kind)).slice(0, 300)) add('k8s.workload', cd, r.Namespace + '/' + r.Name, r.Kind + ' ' + r.Namespace + '/' + r.Name, { forced: st2(r.Status), message: r.Message, channels: [val(ch('Ready', '%', { warnLow: 100, errLow: 1 }, true), r.Desired ? Math.round((r.ReadyCount / r.Desired) * 100) : 100), val(ch('Ready replicas', '#', {}), r.ReadyCount), val(ch('Desired', '#', {}), r.Desired)] });
    });
    groupBy(rows('containers.docker'), (r) => nm(r.Host)).forEach((list, n) => {
      const h = list.find((r) => r.Kind === 'Host') || {};
      const d = devices.get(devId(n)) || dev(n, 'container', 'g:k8s');
      add('docker.host', d, null, (h.Engine || 'Container') + ' engine', { forced: h.Containers == null ? 'Down' : st2(h.Status), message: h.Message + (h.Version ? ' · ' + h.Engine + ' ' + h.Version : ''), channels: h.Containers == null ? [] : [val(ch('Containers with problems', '#', { warnHigh: 0 }, true), list.filter((r) => r.Kind === 'Container' && r.Status !== 'OK').length), val(ch('Running', '#', {}), h.Running), val(ch('Containers', '#', {}), h.Containers), val(ch('Images', '#', {}), h.Images)] });
      for (const r of list.filter((x) => x.Kind === 'Container').slice(0, 200)) add('docker.container', d, r.Name, 'Container ' + r.Name, { forced: st2(r.Status), message: r.Message + ' · ' + r.Image, channels: [val(ch('Running', '', { errLow: r.RestartPolicy === 'always' || r.RestartPolicy === 'unless-stopped' ? 1 : null }, true), r.State === 'running' ? 1 : 0), val(ch('CPU', '%', { warnHigh: 85 }), r.CPUPct), val(ch('Memory', '%', { warnHigh: 85, errHigh: 95 }), r.MemoryPct), val(ch('Restarts', '#', { warnHigh: 5 }), r.Restarts)] });
    });
    {
      const net = rows('network.cloud'), KIND = { Firewall: 'cloudfw', WAF: 'waf', 'VPN gateway': 'vpn' }, TYPEOF = { Firewall: 'cloud.fw', WAF: 'cloud.waf', 'VPN gateway': 'cloud.vpngw' };
      const cdev = (name, kind, r) => dev(alias[String(name).toLowerCase()] || name, kind, 'g:cloudnet', { provider: r.Provider, region: r.Region, host: r.Address || null });
      for (const r of net.filter((x) => KIND[x.Kind])) add(TYPEOF[r.Kind], cdev(r.Name, KIND[r.Kind], r), null, r.Kind === 'VPN gateway' ? 'VPN gateway' : r.Kind === 'WAF' ? 'WAF policy' : 'Firewall', { forced: st2(r.Status), message: r.Provider + ' · ' + r.Message, channels: [val(ch('OK', '', { errLow: 1 }, true), r.Status === 'Critical' ? 0 : 1)].concat(r.Rules != null && !isNaN(+r.Rules) ? [val(ch('Rules', '#', {}), +r.Rules)] : []) });
      for (const r of net.filter((x) => x.Kind === 'VPN tunnel')) add('cloud.vpn', cdev(r.Gateway || r.Name, 'vpn', r), r.Name + '-' + (r.Address || r.Peer || ''), 'Tunnel ' + r.Name, { forced: st2(r.Status), message: r.Provider + ' · ' + r.Message + (r.Peer ? ' · peer ' + r.Peer : ''), channels: [val(ch('Up', '', { errLow: 1 }, true), r.Status === 'OK' ? 1 : 0), val(ch('Bytes in', 'B', {}), r.BytesIn), val(ch('Bytes out', 'B', {}), r.BytesOut)] });
      groupBy(net.filter((x) => x.Kind === 'VPN client'), (r) => r.Gateway).forEach((list, g) => add('cloud.vpnclients', cdev(g, 'vpn', list[0]), null, 'VPN clients', { message: list.length + ' connected: ' + list.slice(0, 5).map((r) => r.User).join(', '), channels: [val(ch('Connected clients', '#', {}, true), list.length)] }));
      for (const r of net.filter((x) => x.Kind === 'Account')) add('cloud.fw', dev((r.Provider || 'Cloud') + ' ' + r.Name, 'cloudfw', 'g:cloudnet', { provider: r.Provider }), null, 'Cloud network API', { forced: 'Down', message: r.Message, channels: [] });
    }
    // ---- Entra ID and Intune: one device per tenant; Intune readings on the console's own machines and on phones you added
    {
      const tn = {}; for (const r of rows('entra.health')) if (r.Kind === 'Tenant' && r.TenantName) tn[r.Tenant] = r.TenantName;
      const tdev = (t, fallback) => dev(alias[lcs('Entra ID ' + (tn[t] || fallback || t))] || 'Entra ID ' + (tn[t] || fallback || t), 'tenant', 'g:entra', { tenant: t });
      groupBy(rows('entra.health'), (r) => r.Tenant).forEach((list, t) => {
        const ten = list.find((r) => r.Kind === 'Tenant') || {}, d = tdev(t, ten.Name);
        const cnt = (k, f) => list.filter((r) => r.Kind === k && (!f || f(r))).length;
        const si = list.find((r) => r.Kind === 'Sign-ins'), rk = list.find((r) => r.Kind === 'Risky users'), ga = list.find((r) => r.Kind === 'Privileged roles');
        const worst = list.some((r) => r.Status === 'Critical') ? 'Down' : list.some((r) => r.Status === 'Warning') ? 'Warning' : null;
        add('entra.tenant', d, null, 'Entra ID tenant', { forced: ten.Users == null ? 'Down' : worst, message: ten.Users == null ? ten.Message : list.filter((r) => r.Status !== 'OK').map((r) => r.Kind + ': ' + r.Message).slice(0, 4).join('; ') || ten.Message, channels: ten.Users == null ? [] : [
          val(ch('App secrets expiring or expired', '#', { warnHigh: 0 }, true), cnt('App credential', (r) => r.Status !== 'OK')), val(ch('Failed sign-ins', '#', { warnHigh: 50, errHigh: 200 }), si ? si.Failed : null), val(ch('Users at risk', '#', { warnHigh: 0 }), rk ? rk.AtRisk : null),
          val(ch('Licences over 95 %', '#', { warnHigh: 0 }), cnt('Licence', (r) => r.UsedPct >= 95)), val(ch('Directory sync age', 'h', { warnHigh: 3, errHigh: 24 }), ten.SyncAgeHours), val(ch('Global Administrators', '#', { warnHigh: 5, warnLow: 2 }), ga ? ga.Members : null),
          val(ch('Users', '#', {}), ten.Users), val(ch('Guests', '#', {}), ten.Guests)].filter((c) => c.value != null) });
      });
      groupBy(rows('entra.users'), (r) => r.Tenant).forEach((list, t) => {
        const on = list.filter((r) => r.Enabled), d = tdev(t);
        add('entra.accounts', d, null, 'Entra ID accounts', { message: on.length + ' enabled accounts · ' + on.filter((r) => r.Stale).length + ' stale · ' + on.filter((r) => r.MfaRegistered === false).length + ' without MFA', channels: [
          val(ch('Admins without MFA', '#', { errHigh: 0 }, true), on.filter((r) => r.Admin && r.MfaRegistered === false).length), val(ch('Users without MFA', '#', { warnHigh: 0 }), on.filter((r) => r.MfaRegistered === false && r.UserType !== 'Guest').length),
          val(ch('Stale accounts', '#', { warnHigh: 0 }), on.filter((r) => r.Stale).length), val(ch('Users at risk', '#', { warnHigh: 0, errHigh: 5 }), on.filter((r) => r.Risk).length), val(ch('Enabled accounts', '#', {}), on.length)] });
      });
      groupBy(rows('intune.health'), (r) => r.Tenant).forEach((list, t) => {
        const sm = list.find((r) => r.Kind === 'Summary') || {}, d = tdev(t);
        const bad = (k) => list.filter((r) => r.Kind === k && r.Status !== 'OK').length;
        const tok = list.filter((r) => r.Kind === 'Connector' && r.DaysLeft != null).sort((a, b) => a.DaysLeft - b.DaysLeft)[0];
        add('intune.tenant', d, null, 'Intune', { forced: sm.Enrolled == null ? 'Down' : null, message: sm.Enrolled == null ? sm.Message : sm.Message + (tok ? ' · ' + tok.Name + ' ' + tok.Message : ''), channels: sm.Enrolled == null ? [] : [
          val(ch('Non-compliant devices', '#', { warnHigh: 0 }, true), sm.NonCompliant), val(ch('Policies with errors', '#', { warnHigh: 0 }), bad('Compliance policy') + bad('Configuration profile')), val(ch('Apps failing to install', '#', { warnHigh: 0 }), bad('App')),
          val(ch('Days to token or certificate expiry', 'd', { warnLow: 30, errLow: 7 }), tok ? tok.DaysLeft : null), val(ch('Enrolled devices', '#', {}), sm.Enrolled)].filter((c) => c.value != null) });
      });
      for (const r of rows('intune.devices')) {
        const k = lcs(r.Name), known = alias[k] || alias[k.split('.')[0]] || (devices.has(devId(short(r.Name))) ? short(r.Name) : null);
        if (!known) continue;
        const d = devices.get(devId(known)) || dev(known, /iOS|Android|iPad/i.test(r.OS || '') ? 'mobile' : /Server/i.test(r.OS || '') ? 'server' : 'workstation', /iOS|Android|iPad/i.test(r.OS || '') ? 'g:entra' : 'g:ws');
        add('intune.device', d, null, 'Intune device', { forced: st2(r.Status), message: (r.Message === r.Compliance ? r.Compliance : r.Compliance + ' · ' + r.Message) + ' · ' + [r.OS, r.OSVersion].filter(Boolean).join(' '), channels: [
          val(ch('Compliant', '', { errLow: 1 }, true), r.Compliance === 'compliant' || r.Compliance === 'inGracePeriod' ? 1 : 0), val(ch('Days since check-in', 'd', { warnHigh: 7, errHigh: 30 }), r.DaysSinceSync), val(ch('Storage free', '%', { warnLow: 10, errLow: 5 }), r.StorageFreePct)].filter((c) => c.value != null) });
      }
    }
    // ---- databases other than SQL Server (the device is the host; a known Linux or Windows host keeps its kind)
    for (const r of rows('databases.health')) {
      const e = DB_ENGINE[r.Engine] || { name: r.Engine };
      const d = dev(short(r.Host), 'database', 'g:db', { host: r.Address || null, engine: r.Engine });
      const lim = (v, l) => Object.assign(l, { value: v == null ? null : v });
      const chs = [lim(r.ConnectionsPct, ch('Connections', '%', { warnHigh: 85, errHigh: 95 }, true)), lim(r.Connections, ch('Sessions', '#', {})), lim(r.SizeGB, ch('Size', 'GB', {}))];
      if (r.ReplicationLagSec != null) chs.push(lim(r.ReplicationLagSec, ch('Replication lag', 's', { warnHigh: 10, errHigh: 120 })));
      if (r.CacheHitPct != null) chs.push(lim(r.CacheHitPct, ch('Cache hit ratio', '%', { warnLow: 90, errLow: 80 })));
      if (r.SlowQueries1h != null) chs.push(lim(r.SlowQueries1h, ch('Slow queries (1 h)', '#', { warnHigh: 30 })));
      if (r.LastBackupHours != null) chs.push(lim(r.LastBackupHours, ch('Last backup', 'h', { warnHigh: 26, errHigh: 50 })));
      if (r.ConnectionsPct == null) { chs.shift(); chs[0].primary = true; }
      add('db.instance', d, r.Engine + '-' + r.Instance, e.name.split(' / ')[0] + ' ' + r.Instance, { forced: r.Status === 'Down' ? 'Down' : (r.Problems || []).length ? 'Warning' : null, message: r.Status === 'Down' ? r.Error || 'The engine could not read the database' : [r.Version, r.Role].filter(Boolean).join(' · ') + ((r.Problems || []).length ? ' · ' + r.Problems.join(', ') : ''), channels: r.Status === 'Down' ? [] : chs });
    }
    // ---- cloud databases: one device per database (Azure SQL databases are named server/database)
    for (const r of rows('cloud.databases')) {
      if (r.Service === 'Account') { add('cloud.db', dev((r.Provider || 'Cloud') + ' databases ' + r.Name, 'clouddb', 'g:db', { provider: r.Provider }), null, 'Cloud database API', { forced: 'Down', message: r.Message, channels: [] }); continue; }
      const d = dev(alias[lcs(r.Name)] || String(r.Name).replace('/', ' / '), 'clouddb', 'g:db', { provider: r.Provider, region: r.Region, engine: r.Engine, service: r.Service, cloudId: r.Id });
      add('cloud.db', d, null, r.Service, { forced: st2(r.Status), message: r.Provider + ' · ' + r.Message, channels: [val(ch('Running', '', { errLow: 1 }, true), r.Running == null ? null : r.Running ? 1 : 0), val(ch('CPU', '%', { warnHigh: 80, errHigh: 95 }), r.CpuPct), val(ch('Storage used', '%', { warnHigh: 85, errHigh: 95 }), r.UsedPct),
        val(ch('Storage', 'GB', {}), r.StorageGB), val(ch('Backup retention', 'd', { warnLow: 1 }), r.BackupDays), val(ch('Replicas', '#', {}), r.Replicas)].filter((c) => c.value != null) });
    }
    // ---- cloud storage: one device per account / project / tenancy, one sensor per bucket
    const CLOUD_PFX = { Azure: 'AZ', AWS: 'AWS', 'Google Cloud': 'GCP', 'Oracle Cloud': 'OCI', 'Huawei Cloud': 'HWC' };
    // providers without per-bucket metrics (Azure containers) leave values empty: drop them and promote the next channel
    const primaryFirst = (list) => { const out = list.filter((c) => c.value != null); if (out.length && !out.some((c) => c.primary)) out[0].primary = true; return out; };
    const cloudDev = (r) => dev((CLOUD_PFX[r.Provider] || 'CLOUD') + '-' + r.Account, 'cloudstorage', 'g:cloud', { host: r.Endpoint || null, provider: r.Provider, region: r.Region });
    for (const r of rows('cloud.storage').filter((x) => x.Kind === 'Account')) {
      const d = cloudDev(r);
      add('cloud.account', d, null, r.Provider + ' storage', { forced: r.Status === 'Error' ? 'Down' : null, message: r.Status === 'Error' ? r.Error || 'The provider API refused the request' : r.Buckets + ' buckets in ' + r.Region + (r.MonthlyCostUSD != null ? ' · about $' + r.MonthlyCostUSD + '/month' : ''),
        channels: r.Status === 'Error' ? [] : [Object.assign(ch('Used', 'GB', {}, true), { value: r.UsedGB }), Object.assign(ch('Buckets', '#', {}), { value: r.Buckets }), Object.assign(ch('Public buckets', '#', { errHigh: 0 }), { value: r.PublicBuckets }), Object.assign(ch('Unencrypted buckets', '#', { warnHigh: 0 }), { value: r.Unencrypted }), Object.assign(ch('API latency', 'ms', { warnHigh: 1500, errHigh: 5000 }), { value: r.LatencyMs })] });
    }
    for (const r of rows('cloud.storage').filter((x) => x.Kind === 'Bucket')) {
      const d = cloudDev(r);
      add('cloud.bucket', d, r.Name, r.Name, { message: [r.Class, r.Encryption === 'None' ? 'not encrypted' : null, r.Versioning === 'Enabled' ? 'versioned' : null, r.Replication && r.Replication !== 'None' ? r.Replication.toLowerCase() + ' replication' : null].filter(Boolean).join(' · ') + ((r.Problems || []).length ? ' · ' + r.Problems.join(', ') : ''),
        channels: primaryFirst([Object.assign(ch('Used', 'GB', {}, true), { value: r.UsedGB }), Object.assign(ch('Objects', '#', {}), { value: r.Objects }), Object.assign(ch('Growth (24 h)', '%/d', { warnHigh: 25, errHigh: 60 }), { value: r.ChangePct24h }), Object.assign(ch('Public access', '', { errHigh: 0 }), { value: r.PublicAccess ? 1 : 0 }), Object.assign(ch('Encrypted', '', { warnLow: 1 }), { value: r.Encryption === 'None' ? 0 : 1 })]) });
    }
    // ---- OS updates, compared with the newest release known online (os.releases, public/js/osreleases.js)
    const OSR = typeof module === 'object' && module.exports ? require('./osreleases.js') : typeof self !== 'undefined' ? self.MCOSReleases : null;
    if (OSR && rows('updates.status').length) {
      const cat = ds['os.releases'] && ds['os.releases'].families ? ds['os.releases'] : OSR.merge(null);
      for (const r of OSR.assessAll(rows('updates.status'), cat, now)) {
        const d = devices.get(devId(short(r.Name)));
        if (!d) continue; // workstations stay on the Updates page
        const left = r.SupportDaysLeft;
        add('os.updates', d, null, 'OS updates', { forced: r.Supported === false || r.UpdateState === 'Unknown' ? 'Down' : r.UpdateState !== 'OK' ? 'Warning' : null, message: r.UpdateProblems.length ? r.UpdateProblems.join('; ') : (r.Release || r.OS) + ' ' + (r.Current || '') + ' is current',
          channels: r.Status === 'Unreachable' ? [] : [Object.assign(ch('Pending updates', '#', { warnHigh: 0 }, true), { value: r.PendingUpdates || 0 }), Object.assign(ch('Security updates', '#', { warnHigh: 0 }), { value: r.PendingSecurity || 0 }), Object.assign(ch('Days since last update', 'd', { warnHigh: 35, errHigh: 60 }), { value: r.DaysSinceUpdate }), Object.assign(ch('Support days left', 'd', { warnLow: 180, errLow: 0 }), { value: left == null ? null : left }), Object.assign(ch('Restart pending', '', { warnHigh: 0 }), { value: r.RebootPending ? 1 : 0 })].filter((c) => c.value != null) });
      }
    }
    // stale collector data -> Unknown (engine stopped or failing)
    for (const s of sensors) {
      const set = ds[s.dataset] || {};
      const age = set.finished ? (now - Date.parse(set.finished)) / 60e3 : null;
      s.staleMinutes = age;
    }
    return { devices, sensors };
  }

  function groupBy(list, key) {
    const m = new Map();
    for (const x of list) { const k = key(x); if (!k) continue; if (!m.has(k)) m.set(k, []); m.get(k).push(x); }
    return m;
  }

  // default sensors for a device found by discovery (PRTG "auto-discovery" templates)
  function templateFor(kind, host, ports) {
    ports = ports || [];
    // no address of its own: an Entra ID / Intune tenant or a phone is read only through Microsoft Graph
    if (['tenant', 'mobile', 'cloudstorage', 'clouddb'].includes(kind) && !host) return [];
    const t = [{ type: 'ping', params: { host } }];
    if (DEV.includes(kind) && kind !== 'network' && kind !== 'appliance') {
      t.push({ type: 'snmp.uptime', params: { host } });
      if (['firewall', 'loadbalancer', 'fcswitch'].includes(kind)) t.push({ type: 'snmp.traffic', params: { host, ifIndex: 1 } });
      if (ports.includes(443) || ['san', 'nas', 'backup', 'bmc', 'firewall', 'loadbalancer'].includes(kind)) t.push({ type: 'http', params: { url: 'https://' + host + '/', expect: 200 } });
    } else if (kind === 'network' || kind === 'appliance') {
      if (ports.includes(161) || kind === 'network') t.push({ type: 'snmp.uptime', params: { host } }, { type: 'snmp.traffic', params: { host, ifIndex: 1 } });
      if (ports.includes(443)) t.push({ type: 'http', params: { url: 'https://' + host + '/', expect: 200 } }, { type: 'sslcert', params: { host, port: 443 } });
      else if (ports.includes(80)) t.push({ type: 'http', params: { url: 'http://' + host + '/', expect: 200 } });
      if (ports.includes(22)) t.push({ type: 'port', params: { host, port: 22 }, name: 'SSH port' });
    } else if (kind === 'printer') {
      t.push({ type: 'snmp.uptime', params: { host } });
    } else if (kind === 'server' || kind === 'workstation') {
      t.push({ type: 'port', params: { host, port: 3389 }, name: 'RDP port' }, { type: 'port', params: { host, port: 5985 }, name: 'WinRM port' });
    } else if (kind === 'linux') {
      t.push({ type: 'port', params: { host, port: 22 }, name: 'SSH port' });
    } else if (kind === 'web') {
      t.push({ type: 'http', params: { url: 'https://' + host + '/', expect: 200 } }, { type: 'sslcert', params: { host, port: 443 } });
    }
    return t;
  }

  // ------------------------------------------------------------------ monitoring options offered when a device is added
  // native: probe sensors created on the device; script: engine that collects it (the device is added to its targets);
  // types: the engine sensor types the option shows. kinds: device types it applies to ('*' = all).
  // ------------------------------------------------------------------ device classes and vendor profiles
  // kind, label, default group. Profiles add vendor health sensors (SNMP OIDs from the vendor MIBs) and are recognised in
  // discovery by sysObjectID. A status OID uses limits on its integer value (e.g. NetApp 3 = ok, 4 = degraded, 5 = failed).
  const CLASSES = [
    ['server', 'Windows server', 'g:srv'], ['workstation', 'Windows workstation', 'g:ws'], ['linux', 'Linux server', 'g:lnx'],
    ['network', 'Switch or router', 'g:net'], ['firewall', 'Firewall', 'g:fw'], ['wireless', 'Wireless controller or access point', 'g:net'], ['loadbalancer', 'Load balancer / ADC', 'g:net'],
    ['san', 'SAN storage array', 'g:storage'], ['nas', 'NAS storage', 'g:storage'], ['fcswitch', 'Fibre Channel switch', 'g:storage'], ['backup', 'Backup appliance or tape library', 'g:storage'],
    ['ups', 'UPS', 'g:power'], ['pdu', 'Rack PDU', 'g:power'], ['environment', 'Environment sensor (temperature, humidity)', 'g:power'],
    ['bmc', 'Server management (iDRAC, iLO, XCC, IPMI)', 'g:hw'], ['camera', 'IP camera or NVR', 'g:net'], ['voip', 'VoIP gateway or PBX', 'g:net'],
    ['printer', 'Printer', 'g:printers'], ['appliance', 'Other appliance', 'g:other'], ['host', 'VMware ESXi / vCenter', 'g:vmw'], ['sql', 'SQL Server', 'g:sql'], ['cluster', 'Cluster (failover, OpenShift, Nutanix)', 'g:cl'], ['web', 'Website or web service', 'g:web-checks'],
    ['database', 'Database server (Oracle, PostgreSQL, MySQL, MongoDB, Redis …)', 'g:db'], ['clouddb', 'Cloud database (Azure SQL, RDS, Cloud SQL, Cosmos DB, Autonomous …)', 'g:db'], ['cloudstorage', 'Cloud storage (Azure, AWS, Google Cloud, OCI, Huawei)', 'g:cloud'],
    ['k8scluster', 'Kubernetes or OpenShift cluster (API)', 'g:k8s'], ['k8snode', 'Kubernetes node', 'g:k8s'], ['container', 'Container host (Docker, Podman)', 'g:k8s'],
    ['cloudfw', 'Cloud firewall (Azure, AWS, OCI, Google Cloud, Huawei)', 'g:cloudnet'], ['waf', 'Web application firewall (WAF)', 'g:cloudnet'], ['vpn', 'VPN gateway, tunnel or remote-access endpoint', 'g:cloudnet'],
    ['tenant', 'Entra ID / Intune tenant (Microsoft Graph)', 'g:entra'], ['mobile', 'Phone or tablet (Intune)', 'g:entra'],
  ];
  const O = (name, oid, unit, limits, scale) => ({ name, oid, unit: unit || '', limits: limits || {}, scale: scale || null });
  const HR_CPU = O('CPU load', '1.3.6.1.2.1.25.3.3.1.2.1', '%', { warnHigh: 80, errHigh: 95 });
  const CISCO_CPU = O('CPU load (5 min)', '1.3.6.1.4.1.9.9.109.1.1.1.1.8.1', '%', { warnHigh: 70, errHigh: 90 });
  const CISCO_TEMP = O('Temperature', '1.3.6.1.4.1.9.9.13.1.3.1.3.1', '°C', { warnHigh: 55, errHigh: 65 });
  const VOL = (i, name) => ({ storage: i, name: name || 'Volume ' + i });
  const PROFILES = [
    // switches and routers
    { id: 'cisco-ios', kind: 'network', vendor: 'Cisco', name: 'Cisco Catalyst / ISR (IOS, IOS-XE)', sysOid: '1.3.6.1.4.1.9.1.', sensors: [CISCO_CPU, O('Memory used', '1.3.6.1.4.1.9.9.48.1.1.1.5.1', 'MB', {}, 1 / 1048576), CISCO_TEMP] },
    { id: 'cisco-nxos', kind: 'network', vendor: 'Cisco', name: 'Cisco Nexus (NX-OS)', sysOid: '1.3.6.1.4.1.9.12.3.1.3.', sensors: [CISCO_CPU, CISCO_TEMP] },
    { id: 'aruba-sw', kind: 'network', vendor: 'HPE Aruba', name: 'HPE Aruba switches (ProCurve, AOS-CX)', sysOid: '1.3.6.1.4.1.11.2.3.7.11.', sensors: [O('CPU load', '1.3.6.1.4.1.11.2.14.11.5.1.9.6.1.0', '%', { warnHigh: 80, errHigh: 95 })] },
    { id: 'juniper', kind: 'network', vendor: 'Juniper', name: 'Juniper EX / MX / QFX (Junos)', sysOid: '1.3.6.1.4.1.2636.', sensors: [O('Routing engine CPU', '1.3.6.1.4.1.2636.3.1.13.1.8.9.1.0.0', '%', { warnHigh: 80, errHigh: 95 }), O('Routing engine temperature', '1.3.6.1.4.1.2636.3.1.13.1.7.9.1.0.0', '°C', { warnHigh: 55, errHigh: 70 })] },
    { id: 'huawei', kind: 'network', vendor: 'Huawei', name: 'Huawei switches and routers (VRP)', sysOid: '1.3.6.1.4.1.2011.', sensors: [O('CPU load', '1.3.6.1.4.1.2011.5.25.31.1.1.1.1.5.67108873', '%', { warnHigh: 80, errHigh: 95 }), O('Memory used', '1.3.6.1.4.1.2011.5.25.31.1.1.1.1.7.67108873', '%', { warnHigh: 85, errHigh: 95 })] },
    { id: 'mikrotik', kind: 'network', vendor: 'MikroTik', name: 'MikroTik RouterOS', sysOid: '1.3.6.1.4.1.14988.', sensors: [HR_CPU, O('Temperature', '1.3.6.1.4.1.14988.1.1.3.10.0', '°C', { warnHigh: 60, errHigh: 75 }, 0.1)] },
    { id: 'dell-net', kind: 'network', vendor: 'Dell', name: 'Dell networking (OS10, N-series)', sysOid: '1.3.6.1.4.1.674.11000.5000.100.', sensors: [HR_CPU] },
    { id: 'ubiquiti', kind: 'network', vendor: 'Ubiquiti', name: 'Ubiquiti UniFi / EdgeSwitch', sysOid: '1.3.6.1.4.1.41112.', sensors: [HR_CPU] },
    { id: 'extreme', kind: 'network', vendor: 'Extreme', name: 'Extreme Networks (EXOS, VOSS)', sysOid: '1.3.6.1.4.1.1916.', sensors: [HR_CPU] },
    { id: 'meraki', kind: 'network', vendor: 'Cisco', name: 'Cisco Meraki (cloud managed)', sysOid: '1.3.6.1.4.1.29671.', sensors: [] },
    // firewalls
    { id: 'fortigate', kind: 'firewall', vendor: 'Fortinet', name: 'Fortinet FortiGate', sysOid: '1.3.6.1.4.1.12356.101.', sensors: [O('CPU load', '1.3.6.1.4.1.12356.101.4.1.3.0', '%', { warnHigh: 80, errHigh: 95 }), O('Memory used', '1.3.6.1.4.1.12356.101.4.1.4.0', '%', { warnHigh: 80, errHigh: 92 }), O('Sessions', '1.3.6.1.4.1.12356.101.4.1.8.0', '#')] },
    { id: 'paloalto', kind: 'firewall', vendor: 'Palo Alto Networks', name: 'Palo Alto Networks (PAN-OS)', sysOid: '1.3.6.1.4.1.25461.', sensors: [O('Management CPU', '1.3.6.1.2.1.25.3.3.1.2.1', '%', { warnHigh: 85, errHigh: 95 }), O('Data plane CPU', '1.3.6.1.2.1.25.3.3.1.2.2', '%', { warnHigh: 80, errHigh: 95 }), O('Session table used', '1.3.6.1.4.1.25461.2.1.2.3.1.0', '%', { warnHigh: 80, errHigh: 95 }), O('Active sessions', '1.3.6.1.4.1.25461.2.1.2.3.3.0', '#')] },
    { id: 'cisco-asa', kind: 'firewall', vendor: 'Cisco', name: 'Cisco ASA / Firepower', sysOid: null, sensors: [CISCO_CPU, O('Connections', '1.3.6.1.4.1.9.9.147.1.2.2.2.1.5.40.6', '#')] },
    { id: 'sonicwall', kind: 'firewall', vendor: 'SonicWall', name: 'SonicWall', sysOid: '1.3.6.1.4.1.8741.', sensors: [O('CPU load', '1.3.6.1.4.1.8741.1.3.1.3.0', '%', { warnHigh: 80, errHigh: 95 }), O('Memory used', '1.3.6.1.4.1.8741.1.3.1.4.0', '%', { warnHigh: 85, errHigh: 95 }), O('Connections', '1.3.6.1.4.1.8741.1.3.1.2.0', '#')] },
    { id: 'checkpoint', kind: 'firewall', vendor: 'Check Point', name: 'Check Point (Gaia)', sysOid: '1.3.6.1.4.1.2620.', sensors: [HR_CPU, O('Connections', '1.3.6.1.4.1.2620.1.1.25.3.0', '#')] },
    { id: 'sophos', kind: 'firewall', vendor: 'Sophos', name: 'Sophos Firewall (SFOS)', sysOid: '1.3.6.1.4.1.2604.', sensors: [HR_CPU] },
    // wireless
    { id: 'cisco-wlc', kind: 'wireless', vendor: 'Cisco', name: 'Cisco wireless controller (AireOS)', sysOid: '1.3.6.1.4.1.14179.', sensors: [O('CPU load', '1.3.6.1.4.1.14179.1.1.5.1.0', '%', { warnHigh: 80, errHigh: 95 })] },
    { id: 'aruba-wlc', kind: 'wireless', vendor: 'HPE Aruba', name: 'Aruba Mobility Controller', sysOid: '1.3.6.1.4.1.14823.', sensors: [HR_CPU] },
    { id: 'unifi-ap', kind: 'wireless', vendor: 'Ubiquiti', name: 'Ubiquiti UniFi access point', sysOid: null, sensors: [HR_CPU] },
    // load balancers
    { id: 'f5', kind: 'loadbalancer', vendor: 'F5', name: 'F5 BIG-IP', sysOid: '1.3.6.1.4.1.3375.', sensors: [O('Client connections', '1.3.6.1.4.1.3375.2.1.1.2.1.8.0', '#')] },
    { id: 'citrix-adc', kind: 'loadbalancer', vendor: 'Citrix', name: 'Citrix ADC / NetScaler', sysOid: '1.3.6.1.4.1.5951.', sensors: [O('CPU load', '1.3.6.1.4.1.5951.4.1.1.41.1.0', '%', { warnHigh: 80, errHigh: 95 }), O('Memory used', '1.3.6.1.4.1.5951.4.1.1.41.2.0', '%', { warnHigh: 85, errHigh: 95 })] },
    { id: 'kemp', kind: 'loadbalancer', vendor: 'Kemp', name: 'Kemp LoadMaster', sysOid: '1.3.6.1.4.1.12196.', sensors: [HR_CPU] },
    // SAN
    { id: 'netapp', kind: 'san', vendor: 'NetApp', name: 'NetApp ONTAP (AFF, FAS, ASA)', sysOid: '1.3.6.1.4.1.789.', sensors: [O('Global status', '1.3.6.1.4.1.789.1.2.2.4.0', '', { warnHigh: 3, errHigh: 4 }), O('CPU busy', '1.3.6.1.4.1.789.1.2.1.3.0', '%', { warnHigh: 85, errHigh: 95 }), O('Failed disks', '1.3.6.1.4.1.789.1.6.4.7.0', '#', { errHigh: 0 })] },
    { id: 'pure', kind: 'san', vendor: 'Pure Storage', name: 'Pure Storage FlashArray', sysOid: '1.3.6.1.4.1.40482.', sensors: [O('Read latency', '1.3.6.1.4.1.40482.4.5.0', 'µs', { warnHigh: 2000, errHigh: 5000 }), O('Write latency', '1.3.6.1.4.1.40482.4.6.0', 'µs', { warnHigh: 2000, errHigh: 5000 }), O('Read IOPS', '1.3.6.1.4.1.40482.4.3.0', '#'), O('Write IOPS', '1.3.6.1.4.1.40482.4.4.0', '#')] },
    { id: 'dell-powerstore', kind: 'san', vendor: 'Dell', name: 'Dell PowerStore / Unity XT', sysOid: '1.3.6.1.4.1.1139.', sensors: [] },
    { id: 'dell-powermax', kind: 'san', vendor: 'Dell', name: 'Dell PowerMax / VMAX (Unisphere)', sysOid: null, sensors: [] },
    { id: 'dothill', kind: 'san', vendor: 'Dell / HPE', name: 'Dell PowerVault ME / HPE MSA', sysOid: '1.3.6.1.4.1.347.', sensors: [] },
    { id: 'hpe-primera', kind: 'san', vendor: 'HPE', name: 'HPE Alletra 9000 / Primera / 3PAR', sysOid: '1.3.6.1.4.1.12925.', sensors: [] },
    { id: 'hpe-nimble', kind: 'san', vendor: 'HPE', name: 'HPE Alletra 6000 / Nimble', sysOid: '1.3.6.1.4.1.37447.', sensors: [] },
    { id: 'ibm-fs', kind: 'san', vendor: 'IBM', name: 'IBM FlashSystem / Storwize', sysOid: '1.3.6.1.4.1.2.6.190.', sensors: [] },
    { id: 'hitachi', kind: 'san', vendor: 'Hitachi', name: 'Hitachi VSP', sysOid: '1.3.6.1.4.1.116.', sensors: [] },
    { id: 'oceanstor', kind: 'san', vendor: 'Huawei', name: 'Huawei OceanStor', sysOid: '1.3.6.1.4.1.34774.', sensors: [] },
    // NAS
    { id: 'synology', kind: 'nas', vendor: 'Synology', name: 'Synology DiskStation / RackStation', sysOid: null, sensors: [O('System status', '1.3.6.1.4.1.6574.1.1.0', '', { errHigh: 1 }), O('Power status', '1.3.6.1.4.1.6574.1.3.0', '', { errHigh: 1 }), O('Temperature', '1.3.6.1.4.1.6574.1.2.0', '°C', { warnHigh: 55, errHigh: 65 }), O('RAID status', '1.3.6.1.4.1.6574.3.1.1.3.0', '', { warnHigh: 1, errHigh: 10 }), VOL(1, 'Volume 1')] },
    { id: 'qnap', kind: 'nas', vendor: 'QNAP', name: 'QNAP NAS (QTS, QuTS hero)', sysOid: '1.3.6.1.4.1.24681.', sensors: [HR_CPU, VOL(1, 'Volume 1')] },
    { id: 'truenas', kind: 'nas', vendor: 'iXsystems', name: 'TrueNAS', sysOid: null, sensors: [HR_CPU, VOL(1, 'Pool 1')] },
    { id: 'powerscale', kind: 'nas', vendor: 'Dell', name: 'Dell PowerScale / Isilon (OneFS)', sysOid: '1.3.6.1.4.1.12124.', sensors: [O('Cluster health', '1.3.6.1.4.1.12124.1.1.2.0', '', { warnHigh: 0, errHigh: 1 })] },
    { id: 'netapp-nas', kind: 'nas', vendor: 'NetApp', name: 'NetApp ONTAP file services (CIFS, NFS)', sysOid: null, sensors: [O('Global status', '1.3.6.1.4.1.789.1.2.2.4.0', '', { warnHigh: 3, errHigh: 4 })] },
    { id: 'nas-generic', kind: 'nas', vendor: 'Any', name: 'Other NAS with HOST-RESOURCES (WD, Buffalo, Asustor…)', sysOid: null, sensors: [HR_CPU, VOL(1)] },
    // Fibre Channel
    { id: 'brocade', kind: 'fcswitch', vendor: 'Broadcom', name: 'Brocade FC switch (FOS)', sysOid: '1.3.6.1.4.1.1588.', sensors: [O('Switch status', '1.3.6.1.4.1.1588.2.1.1.1.1.7.0', '', { errHigh: 1 }), O('CPU load', '1.3.6.1.4.1.1588.2.1.1.1.26.1.0', '%', { warnHigh: 80, errHigh: 95 }), O('Memory used', '1.3.6.1.4.1.1588.2.1.1.1.26.6.0', '%', { warnHigh: 85, errHigh: 95 })] },
    { id: 'cisco-mds', kind: 'fcswitch', vendor: 'Cisco', name: 'Cisco MDS', sysOid: '1.3.6.1.4.1.9.12.3.1.3.1', sensors: [CISCO_CPU, CISCO_TEMP] },
    // backup
    { id: 'datadomain', kind: 'backup', vendor: 'Dell', name: 'Dell PowerProtect DD / Data Domain', sysOid: '1.3.6.1.4.1.19746.', sensors: [] },
    { id: 'exagrid', kind: 'backup', vendor: 'ExaGrid', name: 'ExaGrid', sysOid: null, sensors: [] },
    { id: 'tape', kind: 'backup', vendor: 'Quantum / HPE / IBM', name: 'Tape library (Quantum, HPE StoreEver, IBM TS)', sysOid: null, sensors: [] },
    // power and environment
    { id: 'apc-ups', kind: 'ups', vendor: 'APC', name: 'APC Smart-UPS / Symmetra (PowerNet MIB)', sysOid: '1.3.6.1.4.1.318.1.3.2.', sensors: [O('Battery capacity', '1.3.6.1.4.1.318.1.1.1.2.2.1.0', '%', { warnLow: 50, errLow: 25 }), O('Runtime remaining', '1.3.6.1.4.1.318.1.1.1.2.2.3.0', 'min', { warnLow: 15, errLow: 5 }, 1 / 6000), O('Output load', '1.3.6.1.4.1.318.1.1.1.4.2.3.0', '%', { warnHigh: 80, errHigh: 95 }), O('Battery temperature', '1.3.6.1.4.1.318.1.1.1.2.2.2.0', '°C', { warnHigh: 35, errHigh: 45 })] },
    { id: 'ups-mib', kind: 'ups', vendor: 'Eaton, Vertiv, Riello…', name: 'UPS with the standard UPS-MIB (RFC 1628)', sysOid: '1.3.6.1.4.1.534.', sensors: [O('Battery charge', '1.3.6.1.2.1.33.1.2.4.0', '%', { warnLow: 50, errLow: 25 }), O('Minutes remaining', '1.3.6.1.2.1.33.1.2.3.0', 'min', { warnLow: 15, errLow: 5 }), O('Output load', '1.3.6.1.2.1.33.1.4.4.1.5.1', '%', { warnHigh: 80, errHigh: 95 }), O('Battery temperature', '1.3.6.1.2.1.33.1.2.7.0', '°C', { warnHigh: 35, errHigh: 45 })] },
    { id: 'apc-pdu', kind: 'pdu', vendor: 'APC', name: 'APC rack PDU', sysOid: '1.3.6.1.4.1.318.1.3.4.', sensors: [O('Load', '1.3.6.1.4.1.318.1.1.12.2.3.1.1.2.1', 'A', { warnHigh: 12, errHigh: 16 }, 0.1)] },
    { id: 'raritan', kind: 'pdu', vendor: 'Raritan', name: 'Raritan PX PDU', sysOid: '1.3.6.1.4.1.13742.', sensors: [] },
    { id: 'akcp', kind: 'environment', vendor: 'AKCP', name: 'AKCP sensorProbe', sysOid: '1.3.6.1.4.1.3854.', sensors: [O('Temperature', '1.3.6.1.4.1.3854.1.2.2.1.16.1.3.0', '°C', { warnHigh: 27, errHigh: 32 }), O('Humidity', '1.3.6.1.4.1.3854.1.2.2.1.17.1.3.0', '%', { warnHigh: 60, errHigh: 70 })] },
    { id: 'netbotz', kind: 'environment', vendor: 'APC', name: 'APC NetBotz', sysOid: '1.3.6.1.4.1.5528.', sensors: [] },
    // server management
    { id: 'idrac', kind: 'bmc', vendor: 'Dell', name: 'Dell iDRAC', sysOid: '1.3.6.1.4.1.674.10892.5', sensors: [O('Global system status', '1.3.6.1.4.1.674.10892.5.2.1.0', '', { warnHigh: 3, errHigh: 4 }), O('Storage status', '1.3.6.1.4.1.674.10892.5.2.3.0', '', { warnHigh: 3, errHigh: 4 })] },
    { id: 'ilo', kind: 'bmc', vendor: 'HPE', name: 'HPE iLO', sysOid: '1.3.6.1.4.1.232.', sensors: [O('Overall condition', '1.3.6.1.4.1.232.6.1.3.0', '', { warnHigh: 2, errHigh: 3 })] },
    { id: 'xcc', kind: 'bmc', vendor: 'Lenovo', name: 'Lenovo XClarity Controller', sysOid: '1.3.6.1.4.1.19046.', sensors: [] },
    { id: 'ipmi', kind: 'bmc', vendor: 'Any', name: 'Other IPMI / Redfish BMC (Supermicro, Fujitsu iRMC)', sysOid: null, sensors: [] },
    // cameras and voice
    { id: 'hikvision', kind: 'camera', vendor: 'Hikvision', name: 'Hikvision camera / NVR', sysOid: '1.3.6.1.4.1.39165.', ports: [554], sensors: [] },
    { id: 'axis', kind: 'camera', vendor: 'Axis', name: 'Axis camera', sysOid: '1.3.6.1.4.1.368.', ports: [554], sensors: [] },
    { id: 'cisco-voice', kind: 'voip', vendor: 'Cisco', name: 'Cisco voice gateway / CUBE', sysOid: null, sensors: [CISCO_CPU] },
    { id: 'pbx', kind: 'voip', vendor: 'Any', name: '3CX / Asterisk / FreePBX', sysOid: null, sensors: [] },
    // databases: the model is the engine the database service sensor speaks
    ...DB_ENGINES.map(([e, name, , , , v]) => ({ id: 'db-' + e, kind: 'database', vendor: v, name, engine: e, sysOid: null, sensors: [] })),
    // cloud storage providers (the collector signs in with a Cloud credential)
    { id: 'cloud-azure', kind: 'cloudstorage', vendor: 'Microsoft', name: 'Azure Blob / Files / Data Lake storage account', provider: 'Azure', sysOid: null, sensors: [] },
    { id: 'cloud-aws', kind: 'cloudstorage', vendor: 'Amazon', name: 'AWS S3 (and S3 Glacier)', provider: 'AWS', sysOid: null, sensors: [] },
    { id: 'cloud-gcp', kind: 'cloudstorage', vendor: 'Google', name: 'Google Cloud Storage', provider: 'Google Cloud', sysOid: null, sensors: [] },
    { id: 'cloud-oci', kind: 'cloudstorage', vendor: 'Oracle', name: 'OCI Object Storage', provider: 'Oracle Cloud', sysOid: null, sensors: [] },
    { id: 'cloud-huawei', kind: 'cloudstorage', vendor: 'Huawei', name: 'Huawei Cloud OBS', provider: 'Huawei Cloud', sysOid: null, sensors: [] },
  ];
  const PROFILE = Object.fromEntries(PROFILES.map((p) => [p.id, p]));
  const profilesFor = (kind) => PROFILES.filter((p) => p.kind === kind);
  // sysObjectID -> profile (longest matching prefix wins)
  // ------------------------------------------------------------------ auto-discovery: what a host is (4.7.4)
  // classifyHost({ ports, name, sysDescr, sysOid, http, cert, ttl, os, deviceClass, roles }) -> { kind, group, profile, confidence, reason }
  // Strongest evidence first: what an inventory or AD says about the OS, the SNMP model, the SNMP description, the web
  // server or certificate a device presents, its open ports, its host name, then the ping TTL. Unknown hosts become
  // "Other appliance" in "Other devices", never a network device by default.
  const DESCR_RULES = [
    [/FortiGate|FortiOS|PAN-OS|Palo Alto|SonicWALL|SonicOS|Check Point|Gaia|pfSense|OPNsense|WatchGuard|Fireware|Sophos (XG|UTM|Firewall)|Cisco (ASA|Firepower|Adaptive Security)|Juniper SRX|Stormshield|Barracuda CloudGen/i, 'firewall'],
    [/BIG-IP|NetScaler|Citrix ADC|Kemp|LoadMaster|A10 Networks|Thunder|AVI Vantage/i, 'loadbalancer'],
    [/Wireless LAN Controller|AireOS|Catalyst 9800|Aruba (Instant|Mobility|AP)|ArubaOS|Ruckus|SmartZone|UniFi AP|Access Point|Meraki MR|Mist AP/i, 'wireless'],
    [/Brocade (Fabric|FOS)|Fabric OS|MDS 9[0-9]{3}|Cisco MDS/i, 'fcswitch'],
    [/NetApp|ONTAP|Isilon|PowerScale|PowerStore|Unity|Pure Storage|Purity|3PAR|Primera|Nimble|HPE Alletra|Compellent|Storwize|FlashSystem|Hitachi VSP|EMC VNX/i, 'san'],
    [/Synology|DiskStation|QNAP|QTS|TrueNAS|FreeNAS|ReadyNAS|Buffalo TeraStation/i, 'nas'],
    [/Data Domain|DDOS|StoreOnce|Quantum|Scalar i|ExaGrid|tape library/i, 'backup'],
    [/APC|Smart-UPS|Symmetra|Eaton|PowerWare|Network Management Card|UPS|Liebert|Vertiv/i, 'ups'],
    [/PDU|Raritan|ServerTech|Sentry/i, 'pdu'],
    [/iDRAC|Integrated Dell Remote|iLO|Integrated Lights-Out|XClarity|IMM2|CIMC|Supermicro BMC|IPMI/i, 'bmc'],
    [/JetDirect|LaserJet|OfficeJet|Lexmark|RICOH|Xerox|Brother NC|Canon|KONICA|bizhub|Kyocera|ECOSYS|EPSON|Zebra|SHARP MX|Toshiba e-STUDIO|printer/i, 'printer'],
    [/Hikvision|Dahua|AXIS|Axis Communications|Hanwha|Bosch (Security|IP camera)|Network Camera|NVR|Milestone/i, 'camera'],
    [/Asterisk|FreePBX|3CX|Avaya|Mitel|Cisco Unified|CUCM|AudioCodes|Mediant|Polycom|Yealink|SIP gateway/i, 'voip'],
    [/VMware ESXi|ESX Server|VMkernel/i, 'host'],
    [/Cisco IOS|IOS-XE|IOS XR|NX-OS|Nexus|JUNOS|Juniper|Arista|EOS|ProCurve|ArubaOS-CX|AOS-CX|Comware|Huawei Versatile|VRP|MikroTik|RouterOS|EdgeOS|EdgeSwitch|Dell (EMC )?Networking|Extreme(XOS| Networks)|Netgear|TP-Link|D-Link|Ubiquiti|Allied Telesis|Cumulus|Mellanox|Onyx|Ruijie|H3C|ZyXEL/i, 'network'],
    [/Windows/i, 'windows'],
    [/Linux|Ubuntu|Debian|Red Hat|CentOS|Rocky|AlmaLinux|SUSE|FreeBSD|OpenBSD|SunOS|Solaris|AIX|HP-UX/i, 'linux'],
  ];
  const WEB_RULES = [
    [/iLO|iDRAC|Integrated Dell|XClarity|Supermicro|IPMI|MegaRAC|AMI/i, 'bmc'], [/Fortinet|FortiGate|Palo Alto|PAN-OS|SonicWALL|WatchGuard|Sophos|pfSense|OPNsense|Check Point/i, 'firewall'],
    [/BIG-IP|NetScaler|Citrix ADC|Kemp/i, 'loadbalancer'], [/VMware ESXi|vSphere|VMware Host Client/i, 'host'], [/Proxmox/i, 'host'], [/Synology|DiskStation|QNAP|TrueNAS/i, 'nas'],
    [/UniFi|Ubiquiti|Aruba|Ruckus|Meraki/i, 'wireless'], [/HP HTTP Server|HP-ChaiSOE|Virata-EmWeb|LaserJet|RICOH|Xerox|Lexmark|KM-MFP|Canon|EPSON|Brother|Kyocera|PRINT_SERVER/i, 'printer'],
    [/Hikvision|DNVRS|Dahua|AXIS|App-webs/i, 'camera'], [/APC|Eaton|Network Management Card|Liebert/i, 'ups'], [/Microsoft-IIS|Microsoft-HTTPAPI/i, 'windows'], [/MikroTik|RouterOS|Cisco|Juniper|Huawei|Allegro-Software-RomPager|GoAhead/i, 'network'],
  ];
  const WS_NAME = /^(PC|WS|WKS|DESKTOP|LAPTOP|LT|NB|NOTEBOOK|CLIENT|VDI|KIOSK|TC)[-_]?|[-_](PC|WS|LT|NB)\d*$|^DESKTOP-[A-Z0-9]{7}$|^LAPTOP-[A-Z0-9]{7}$/i;
  const SRV_NAME = /^(SRV|SVR|SERVER|DC|ADDC|SQL|DB|FS|FILE|APP|WEB|IIS|EXCH|EX|MAIL|HV|HYPERV|RDS|TS|CA|PKI|WSUS|SCCM|PRINT|PRN|BKP|BACKUP|VEEAM)[-_]?\d*|SERVER/i;
  const NET_NAME = [[/^(fw|firewall|fortigate|pa|asa|palo)[-_]?/i, 'firewall'], [/^(ap|wap|wlc|wifi|wlan)[-_]?/i, 'wireless'], [/^(lb|adc|f5|bigip|netscaler)[-_]?/i, 'loadbalancer'], [/^(sw|swi|switch|rtr|router|gw|core|dist|acc|edge|leaf|spine|stack)[-_]?|[-_](sw|rtr)\d*$/i, 'network'], [/^(ups)[-_]?/i, 'ups'], [/^(prn|printer|mfp|mfd)[-_]?/i, 'printer'], [/^(nas)[-_]?/i, 'nas'], [/^(san)[-_]?/i, 'san'], [/^(ilo|idrac|bmc|ipmi|xcc|imm)[-_]?/i, 'bmc'], [/^(cam|ipcam|nvr)[-_]?/i, 'camera'], [/^(esx|esxi)[-_]?/i, 'host']];
  const netName = (n) => (NET_NAME.find(([re]) => re.test(n)) || [])[1] || null;
  function classifyHost(h) {
    h = h || {};
    const ports = (h.ports || []).map(Number), has = (p) => ports.includes(p), any = (...ps) => ps.some(has);
    const name = String(h.name || '').split('.')[0];
    const out = (kind, confidence, reason, extra) => Object.assign({ kind, group: KIND_GROUP[kind] || 'g:other', profile: null, confidence, reason }, extra || {});
    const win = (why, conf) => {
      if (any(88, 389, 636, 3268) && any(53, 445)) return out('server', conf || 'high', why + '; Kerberos and LDAP: domain controller', { group: 'g:dc' });
      if (/server/i.test(h.os || '')) return out('server', 'high', why);
      if (/windows (7|8|10|11|xp|vista)/i.test(h.os || '')) return out('workstation', 'high', why);
      if (WS_NAME.test(name)) return out('workstation', conf || 'medium', why + '; the name looks like a workstation');
      if (SRV_NAME.test(name)) return out('server', conf || 'medium', why + '; the name looks like a server');
      if (has(1433)) return out('server', conf || 'medium', why + '; SQL Server port 1433', { group: 'g:sql' });
      if (has(5985) || has(5986)) return out('server', conf || 'medium', why + '; WinRM answers (on by default on servers)');
      if (!has(3389) && any(135, 445)) return out('workstation', 'low', why + '; no remote desktop or WinRM');
      return out('server', conf || 'low', why);
    };
    const lin = (why, conf) => {
      if (any(2375, 2376) || (has(10250) && !has(6443))) return out(has(10250) ? 'k8snode' : 'container', conf || 'medium', why + (has(10250) ? '; kubelet port 10250' : '; Docker API'));
      if (has(6443)) return out('k8scluster', 'medium', why + '; Kubernetes API 6443');
      if (any(5432, 3306, 1521, 27017, 6379, 9042, 9200, 5984, 8086, 7687, 26257, 50000, 8123, 9000)) return out('database', 'medium', why + '; database port ' + ports.find((p) => [5432, 3306, 1521, 27017, 6379, 9042, 9200, 5984, 8086, 7687, 26257, 50000, 8123, 9000].includes(p)));
      return out('linux', conf || 'medium', why);
    };
    // 1. an inventory, AD, Intune or a hypervisor already knows the OS
    if (h.os) {
      if (/windows/i.test(h.os)) return win('OS ' + h.os, 'high');
      if (/linux|ubuntu|debian|red hat|rhel|centos|rocky|alma|suse|oracle linux|amazon linux|unix|aix|solaris|freebsd/i.test(h.os)) return lin('OS ' + h.os, 'high');
      if (/esxi/i.test(h.os)) return out('host', 'high', 'OS ' + h.os);
      if (/ios|android|ipados/i.test(h.os)) return out('mobile', 'high', 'OS ' + h.os);
    }
    // 2. the SNMP model (sysObjectID) of a known profile
    if (h.sysOid) { const p = profileBySysOid(h.sysOid); if (p) return out(p.kind, 'high', 'SNMP model ' + p.name, { profile: p.id }); }
    // 3. the SNMP system description
    if (h.sysDescr) for (const [re, k] of DESCR_RULES) if (re.test(h.sysDescr)) { const why = 'SNMP description "' + String(h.sysDescr).slice(0, 60) + '"'; return k === 'windows' ? win(why, 'high') : k === 'linux' ? lin(why, 'high') : out(k, 'high', why); }
    // 4. what its web server or TLS certificate says
    const web = [h.http, h.cert, h.title].filter(Boolean).join(' ');
    if (web) for (const [re, k] of WEB_RULES) if (re.test(web)) { const why = 'web interface "' + web.slice(0, 60) + '"'; return k === 'windows' ? win(why, 'medium') : out(k, 'medium', why); }
    // 5. what the network discovery engine decided (its ports are re-checked below)
    // 6. open ports
    if (any(9100, 515, 631)) return out('printer', 'high', 'printing port ' + ports.find((p) => [9100, 515, 631].includes(p)));
    if (has(902) && any(443, 80)) return out('host', 'high', 'VMware ESXi ports 902 and 443');
    if (has(8006)) return out('host', 'medium', 'Proxmox VE port 8006', { group: 'g:srv' });
    if (any(623, 664) && !any(22, 445)) return out('bmc', 'medium', 'IPMI port 623');
    if (any(5060, 5061) && !any(445, 3389)) return out('voip', 'medium', 'SIP port 5060');
    if (any(554, 37777, 8000) && !any(22, 445, 3389)) return out('camera', 'medium', 'video streaming port ' + ports.find((p) => [554, 37777, 8000].includes(p)));
    if (any(3389, 5985, 5986) || (has(445) && has(135))) return win('Windows ports ' + ports.filter((p) => [135, 445, 3389, 5985, 5986].includes(p)).join(', '));
    if (has(445) && !has(22)) return win('SMB port 445', 'low');
    const nn = netName(name);
    if (nn && !any(135, 445, 3389, 5985)) return out(nn, 'medium', 'the name ' + name + ' and ports ' + (ports.join(', ') || 'none') + (h.ttl ? '; TTL ' + h.ttl : ''));
    if (has(22) && !any(23, 161) && !has(445)) return h.ttl && h.ttl > 128 ? out('network', 'medium', 'SSH with TTL ' + h.ttl + ' (network gear)') : lin('SSH port 22');
    if (has(22) && has(161)) return h.ttl && h.ttl > 128 ? out('network', 'medium', 'SSH and SNMP; TTL ' + h.ttl) : lin('SSH and SNMP', 'low');
    if (any(23, 161) && !any(445, 3389)) return out('network', 'medium', (has(23) ? 'Telnet' : 'SNMP') + ' without Windows or SSH ports');
    // 7. the host name, then the ping TTL
    if (WS_NAME.test(name)) return out('workstation', 'low', 'the name looks like a workstation');
    if (SRV_NAME.test(name)) return out('server', 'low', 'the name looks like a server');
    if (ports.length && ports.every((x) => [80, 443, 8080, 8443].includes(x)) && !(h.ttl > 128)) return out('appliance', 'low', 'only a web interface (ports ' + ports.join(', ') + ')');
    if (h.ttl) { if (h.ttl > 128) return out('network', 'low', 'ping TTL ' + h.ttl + ' (network gear)'); if (h.ttl > 64) return win('ping TTL ' + h.ttl + ' (Windows)', 'low'); if (any(80, 443)) return out('appliance', 'low', 'web ports with TTL ' + h.ttl); return lin('ping TTL ' + h.ttl + ' (Linux or Unix)', 'low'); }
    return out('appliance', 'low', ports.length ? 'ports ' + ports.join(', ') + ' do not tell the type' : 'answers ping only');
  }
  function profileBySysOid(oid) {
    const o = String(oid || '').replace(/^\./, '') + '.';
    let best = null;
    for (const p of PROFILES) if (p.sysOid && o.startsWith(p.sysOid.endsWith('.') ? p.sysOid : p.sysOid + '.') && (!best || p.sysOid.length > best.sysOid.length)) best = p;
    return best;
  }
  // probe sensors for a profile (the vendor health option)
  function profileSensors(id) {
    const p = PROFILE[id];
    if (!p) return [];
    const out = p.sensors.map((x) => (x.storage ? { type: 'snmp.storage', name: x.name, params: { index: x.storage } } : { type: 'snmp.custom', name: x.name, params: { oid: x.oid, label: x.name, unit: x.unit, scale: x.scale ? String(x.scale) : '1' }, limits: Object.keys(x.limits).length ? { [x.name]: x.limits } : null }));
    for (const port of p.ports || []) out.push({ type: 'port', name: 'Port ' + port, params: { port } });
    return out;
  }
  const KIND_GROUP = Object.fromEntries(CLASSES.map(([k, , g]) => [k, g]));

  const W = ['server', 'workstation', 'vm'];
  const DEV = ['network', 'firewall', 'wireless', 'loadbalancer', 'san', 'nas', 'fcswitch', 'backup', 'ups', 'pdu', 'environment', 'bmc', 'camera', 'voip', 'appliance'];
  const SNMPK = DEV.concat(['printer', 'linux', 'server']);
  const OPTIONS = [
    { id: 'ping', name: 'Ping', area: 'Availability', kinds: '*', def: (k) => !['cloudstorage', 'cloudfw', 'waf', 'k8scluster', 'tenant', 'mobile', 'clouddb'].includes(k), native: () => [{ type: 'ping' }] },
    { id: 'availability', name: 'Uptime and management ports (WinRM, RDP, SMB)', area: 'Availability', kinds: W, def: true, script: 'mon.availability', types: ['wmi.availability'] },
    { id: 'ports', name: 'TCP port checks for open services', area: 'Availability', kinds: '*', def: (k) => !['tenant', 'mobile', 'clouddb'].includes(k), native: (k, host, ports) => (k === 'linux' ? [22] : W.includes(k) ? [3389, 5985] : (ports || []).filter((p) => [22, 25, 80, 443, 445, 1433, 3389, 5985, 8080, 9100].includes(p)).slice(0, 4)).map((port) => ({ type: 'port', params: { port }, name: ({ 22: 'SSH', 25: 'SMTP', 80: 'HTTP', 443: 'HTTPS', 445: 'SMB', 1433: 'SQL', 3389: 'RDP', 5985: 'WinRM', 8080: 'HTTP 8080', 9100: 'Printing (9100)' }[port] || port) + ' port' })) },
    { id: 'compute', name: 'CPU, memory, disk I/O and network traffic', area: 'Performance', kinds: W, def: true, script: 'mon.compute', types: ['wmi.cpu', 'wmi.memory', 'wmi.diskio', 'wmi.network'] },
    { id: 'storage', name: 'Storage by volume (free space per drive)', area: 'Performance', kinds: W, def: true, script: 'mon.disks', types: ['wmi.disk'] },
    { id: 'services', name: 'Windows services (automatic services stopped)', area: 'Services', kinds: W, def: true, script: 'mon.services', types: ['wmi.services'] },
    { id: 'events', name: 'Event logs: System and Application errors', area: 'Logs', kinds: W, def: true, script: 'mon.events', types: ['win.events'] },
    { id: 'securitylog', name: 'Security log: logons, lockouts, RDP, shutdowns', area: 'Logs', kinds: W, def: false, script: 'aud.events', types: ['ad.audit'] },
    { id: 'fileaudit', name: 'File access audit (reads, changes, deletes, permissions)', area: 'Logs', kinds: ['server'], def: false, script: 'aud.events', types: ['fs.audit'] },
    { id: 'processes', name: 'Top processes (CPU and memory)', area: 'Performance', kinds: W, def: false, script: 'mon.processes', types: [] },
    { id: 'sessions', name: 'Signed-in users and RDP sessions', area: 'Services', kinds: W, def: false, script: 'mon.sessions', types: [] },
    { id: 'printer', name: 'Printer status, errors, pages and supplies', area: 'Performance', kinds: ['printer'], def: true, script: 'mon.printers', types: ['printer'] },
    { id: 'software', name: 'Installed software inventory', area: 'Inventory', kinds: W.concat(['linux']), def: true, script: 'inv.software', types: [] },
    { id: 'hardware', name: 'Hardware, BIOS and OS inventory', area: 'Inventory', kinds: W, def: true, script: 'inv.hardware', types: [] },
    { id: 'patches', name: 'Windows updates and pending reboot', area: 'Security', kinds: W, def: true, script: 'sec.patches', types: ['sec.patches'] },
    { id: 'defender', name: 'Defender: protection, signatures and threats', area: 'Security', kinds: W, def: true, script: 'sec.defender', types: ['sec.defender'] },
    { id: 'firewall', name: 'Firewall profiles and SMBv1', area: 'Security', kinds: W, def: false, script: 'sec.firewall', types: ['sec.firewall'] },
    { id: 'activation', name: 'Windows activation', area: 'Security', kinds: ['server'], def: false, script: 'mon.activation', types: ['wmi.activation'] },
    { id: 'iis', name: 'IIS application pools', area: 'Roles', kinds: ['server'], def: false, script: 'mon.iis', types: ['wmi.iis'] },
    { id: 'fileserver', name: 'File server: sessions, open files, quotas, shadow copies', area: 'Roles', kinds: ['server'], def: false, script: 'mon.fileserver', types: ['fs.server'] },
    { id: 'dns', name: 'DNS server: zones, resolution, errors', area: 'Roles', kinds: ['server'], def: false, script: 'mon.dns', types: ['dns.server'] },
    { id: 'dhcp', name: 'DHCP scopes', area: 'Roles', kinds: ['server'], def: false, script: 'mon.dhcp', types: ['dhcp.scope'] },
    { id: 'adds', name: 'Domain controller: AD services, SYSVOL, replication, sites, Group Policy', area: 'Roles', kinds: ['server'], def: false, script: 'mon.ad.health', types: ['ad.dc', 'ad.replication'] },
    { id: 'sql', name: 'SQL Server databases, backups and sizes', area: 'Roles', kinds: ['server', 'sql'], def: (k) => k === 'sql', script: 'mon.sql.databases', types: ['sql.instance'] },
    { id: 'cluster', name: 'Failover cluster nodes, roles and shared volumes', area: 'Roles', kinds: ['server', 'cluster'], def: (k) => k === 'cluster', script: 'mon.clusters', types: ['cluster', 'cluster.csv'] },
    { id: 'vmware', name: 'VMware hosts, datastores and virtual machines (vCenter API)', area: 'Roles', kinds: ['host', 'appliance'], def: (k) => k === 'host', script: 'mon.vmware', types: ['vmw.host', 'vmw.datastore', 'vmw.vm'] },
    { id: 'openshift', name: 'OpenShift Virtualization nodes and virtual machines (cluster API)', area: 'Roles', kinds: ['cluster', 'appliance', 'host'], def: false, script: 'mon.openshift', types: ['ocp.node', 'ocp.vm'] },
    { id: 'nutanix', name: 'Nutanix AHV hosts, virtual machines and storage containers (Prism API)', area: 'Roles', kinds: ['cluster', 'appliance', 'host'], def: false, script: 'mon.nutanix', types: ['ntx.host', 'ntx.vm', 'ntx.container'] },
    { id: 'hyperv', name: 'Hyper-V host and virtual machines', area: 'Roles', kinds: ['server'], def: false, script: 'mon.hyperv', types: ['hv.host', 'hv.vm'] },
    { id: 'linux', name: 'Linux over SSH: CPU, memory, filesystems, load, failed units, updates', area: 'Performance', kinds: ['linux'], def: true, script: 'lnx.collect', types: ['ssh.linux'] },
    { id: 'snmp-system', name: 'SNMP system uptime (restarts)', area: 'Availability', kinds: SNMPK, def: (k) => k !== 'server' && k !== 'linux', native: () => [{ type: 'snmp.uptime' }] },
    { id: 'vendor', name: 'Vendor health sensors for the chosen model (CPU, memory, temperature, status, sessions…)', area: 'Performance', kinds: DEV.concat(['printer']), def: true, profile: true, native: (k, host, ports, o) => profileSensors(o.profile) },
    { id: 'snmp-storage', name: 'Storage by volume over SNMP (HOST-RESOURCES)', area: 'Performance', kinds: ['nas', 'san', 'linux', 'appliance', 'backup'], def: (k) => k === 'nas', volumes: true, native: (k, host, ports, o) => (o.volumes || []).map((i) => ({ type: 'snmp.storage', params: { index: i }, name: 'Volume ' + i })) },
    { id: 'snmp-traffic', name: 'SNMP interface traffic', area: 'Performance', kinds: ['network', 'firewall', 'wireless', 'loadbalancer', 'fcswitch', 'nas', 'san', 'appliance', 'server', 'linux'], def: (k) => ['network', 'firewall', 'loadbalancer', 'fcswitch', 'appliance'].includes(k), interfaces: true, native: (k, host, ports, o) => (o.interfaces || [1]).map((i) => ({ type: 'snmp.traffic', params: { ifIndex: i }, name: 'Traffic interface ' + i })) },
    { id: 'snmp-cpu', name: 'SNMP CPU load (HOST-RESOURCES)', area: 'Performance', kinds: DEV.concat(['linux']), def: false, native: () => [{ type: 'snmp.custom', name: 'CPU load', params: { oid: '1.3.6.1.2.1.25.3.3.1.2.1', label: 'CPU load', unit: '%' } }] },
    { id: 'snmp-toner', name: 'Printer toner level (Printer MIB)', area: 'Performance', kinds: ['printer'], def: true, native: () => [{ type: 'snmp.custom', name: 'Toner level', params: { oid: '1.3.6.1.2.1.43.11.1.1.9.1.1', label: 'Toner level', unit: '%' } }] },
    { id: 'dbservice', name: 'Database service: protocol check, version, TLS and health for the chosen engine', area: 'Databases', kinds: ['database'], def: true,
      native: (k, host, ports, o) => [{ type: 'db.service', name: ((DB_ENGINE[(PROFILE[o.profile] || {}).engine] || {}).name || 'Database') + ' service', params: { engine: (PROFILE[o.profile] || {}).engine || 'mysql' } }] },
    { id: 'dbdeep', name: 'Database instance: connections, size, replication, cache, slow queries, backups', area: 'Databases', kinds: ['database', 'linux', 'server'], def: (k) => k === 'database', script: 'mon.databases', types: ['db.instance'] },
    { id: 'osupdates', name: 'OS updates: build vs newest release online, pending and security updates, support end, restart pending', area: 'Updates', kinds: ['server', 'workstation', 'linux'], def: true, script: 'mon.os.updates', types: ['os.updates'] },
    { id: 'cloud', name: 'Buckets and containers: capacity, objects, growth, public access, encryption', area: 'Cloud storage', kinds: ['cloudstorage'], def: true, script: 'mon.cloud.storage', types: ['cloud.account', 'cloud.bucket'] },
    { id: 'cloud-endpoint', name: 'Provider endpoint reachability and TLS certificate', area: 'Cloud storage', kinds: ['cloudstorage'], def: true, native: () => [{ type: 'port', name: 'HTTPS endpoint', params: { port: 443 } }, { type: 'sslcert', params: { port: 443 } }] },
    { id: 'http', name: 'Web page (HTTP/HTTPS response and status)', area: 'Web', kinds: ['web', 'server', 'printer'].concat(DEV), def: (k, ports) => k === 'web' || ['san', 'nas', 'backup', 'bmc', 'firewall', 'loadbalancer'].includes(k) || (ports || []).includes(443), native: (k, host, ports) => [{ type: 'http', params: { url: ((ports || []).includes(443) || k === 'web' || DEV.includes(k) && !(ports || []).includes(80) ? 'https://' : 'http://') + host + '/', expect: 200 } }] },
    { id: 'temperature', name: 'Temperature (heat): every sensor the device reports, over SNMP, Redfish, SSH or WinRM', area: 'Performance', kinds: DEV.concat(['server', 'workstation', 'linux', 'printer', 'k8snode', 'container', 'host', 'sql', 'database', 'cluster']), def: (k) => k !== 'camera', script: 'mon.temperature', types: ['hw.temp'] },
    { id: 'snmpdev', name: 'Network devices engine (SNMP): interfaces, CPU, memory, sessions, VPN tunnels, access points, BGP peers, pools', area: 'Network', kinds: ['network', 'firewall', 'wireless', 'loadbalancer', 'waf', 'vpn', 'fcswitch', 'voip'], def: true, script: 'mon.network.devices', types: ['net.snmpdev'] },
    { id: 'snmpstorage', name: 'Storage devices engine (SNMP): every volume and its use', area: 'Performance', kinds: ['san', 'nas', 'backup', 'appliance'], def: (k) => ['san', 'nas', 'backup'].includes(k), script: 'mon.storage.devices', types: ['storage.snmpdev'] },
    { id: 'linux-fs', name: 'Linux filesystems: space and inodes per mount, read-only and missing mounts', area: 'Performance', kinds: ['linux', 'container', 'k8snode'], def: true, script: 'mon.linux.filesystems', types: ['lnx.fs'] },
    { id: 'linux-services', name: 'Linux services: failed systemd units and stopped services', area: 'Services', kinds: ['linux', 'container', 'k8snode'], def: true, script: 'mon.linux.services', types: ['lnx.services'] },
    { id: 'linux-audit', name: 'Linux audit: failed and root logins, sudo, new accounts, auditd', area: 'Security', kinds: ['linux', 'container', 'k8snode'], def: false, script: 'mon.linux.audit', types: ['lnx.audit'] },
    { id: 'webserver', name: 'Web server engine: status, response time, server software, page content', area: 'Web', kinds: ['web', 'server', 'linux', 'loadbalancer', 'waf', 'container'], def: (k) => k === 'web', script: 'mon.web.servers', types: ['web.server'] },
    { id: 'webhost', name: 'Web server software: IIS, Apache, nginx, LiteSpeed, Tomcat, Jetty, WildFly, WebLogic, WebSphere, Node.js, Gunicorn, PHP-FPM, Kestrel and every other web, application server and gateway on Windows and Linux (service, connections, config test, errors)', area: 'Web', kinds: ['web', 'server', 'linux', 'container'], def: (k) => k === 'web', script: 'mon.web.hosts', types: ['web.host'] },
    { id: 'clouddb', name: 'Cloud database: state, CPU, storage, high availability, backups, public access (provider API)', area: 'Databases', kinds: ['clouddb'], def: true, script: 'mon.cloud.databases', types: ['cloud.db'] },
    { id: 'sslaudit', name: 'Certificate audit engine: expiry, chain trust, names, key size, TLS protocol', area: 'Web', kinds: ['web', 'server', 'linux', 'loadbalancer', 'firewall', 'waf', 'vpn', 'appliance', 'bmc'], def: (k) => k === 'web', script: 'mon.ssl.certificates', types: ['ssl.engine'] },
    { id: 'k8s', name: 'Kubernetes: nodes, workloads, failing pods, volume claims and events (cluster API)', area: 'Containers', kinds: ['k8scluster', 'cluster'], def: (k) => k === 'k8scluster', script: 'mon.kubernetes', types: ['k8s.cluster', 'k8s.node', 'k8s.workload'] },
    { id: 'containers', name: 'Containers (Docker, Podman): state, health, restarts, CPU and memory', area: 'Containers', kinds: ['container', 'linux', 'k8snode'], def: (k) => k === 'container', script: 'mon.containers', types: ['docker.host', 'docker.container'] },
    { id: 'cloudnet', name: 'Cloud network: firewall, WAF, VPN tunnels and connected clients (provider API)', area: 'Network', kinds: ['cloudfw', 'waf', 'vpn'], def: true, script: 'mon.cloud.network', types: ['cloud.fw', 'cloud.waf', 'cloud.vpngw', 'cloud.vpn', 'cloud.vpnclients'] },
    { id: 'entra', name: 'Entra ID: tenant health, accounts without MFA, stale and risky users (Microsoft Graph)', area: 'Identity', kinds: ['tenant'], def: true, script: 'mon.entra.health', types: ['entra.tenant', 'entra.accounts'] },
    { id: 'intune', name: 'Intune: compliance, policies, app installs and Apple tokens (Microsoft Graph)', area: 'Identity', kinds: ['tenant'], def: true, script: 'mon.intune', types: ['intune.tenant'] },
    { id: 'intune-device', name: 'Intune device: compliance, last check-in, encryption and storage', area: 'Security', kinds: ['workstation', 'server', 'mobile', 'linux'], def: (k) => k === 'mobile', script: 'inv.intune.devices', types: ['intune.device'] },
    { id: 'ssl', name: 'SSL certificate expiry', area: 'Web', kinds: ['web', 'server'].concat(DEV), def: (k, ports) => k === 'web' || ['firewall', 'loadbalancer'].includes(k) || (ports || []).includes(443), native: () => [{ type: 'sslcert', params: { port: 443 } }] },
  ];
  // Bulk import: the Type column accepts a device type id or name (CLASSES), a model id or name (PROFILES), or a
  // common word for it. Returns { kind, profile } or null.
  const TYPE_WORDS = {
    windows: 'server', 'windows server': 'server', server: 'server', dc: 'server', 'domain controller': 'server', 'file server': 'server', 'print server': 'server', 'hyper-v': 'server',
    pc: 'workstation', desktop: 'workstation', laptop: 'workstation', client: 'workstation', 'windows workstation': 'workstation',
    entra: 'tenant', 'entra id': 'tenant', 'azure ad': 'tenant', aad: 'tenant', intune: 'tenant', tenant: 'tenant', 'microsoft 365': 'tenant', m365: 'tenant', phone: 'mobile', 'cloud database': 'clouddb', 'azure sql': 'clouddb', rds: 'clouddb', aurora: 'clouddb', 'cloud sql': 'clouddb', cosmos: 'clouddb', 'cosmos db': 'clouddb', dynamodb: 'clouddb', 'autonomous database': 'clouddb', 'wireless controller': 'wireless', wlc: 'wireless', 'access point': 'wireless', waf: 'waf', 'vpn gateway': 'vpn', iphone: 'mobile', ipad: 'mobile', android: 'mobile', tablet: 'mobile', mobile: 'mobile',
    linux: 'linux', unix: 'linux', ubuntu: 'linux', rhel: 'linux', centos: 'linux', debian: 'linux', suse: 'linux', rocky: 'linux', alma: 'linux',
    switch: 'network', router: 'network', network: 'network', 'core switch': 'network', firewall: 'firewall', fw: 'firewall', utm: 'firewall',
    wifi: 'wireless', wlan: 'wireless', 'access point': 'wireless', ap: 'wireless', wlc: 'wireless', 'load balancer': 'loadbalancer', adc: 'loadbalancer', lb: 'loadbalancer',
    storage: 'san', san: 'san', 'storage array': 'san', nas: 'nas', 'fc switch': 'fcswitch', 'fibre channel switch': 'fcswitch', backup: 'backup', tape: 'backup',
    ups: 'ups', pdu: 'pdu', environment: 'environment', temperature: 'environment', bmc: 'bmc', idrac: 'bmc', ilo: 'bmc', ipmi: 'bmc', xcc: 'bmc',
    camera: 'camera', cctv: 'camera', nvr: 'camera', voip: 'voip', pbx: 'voip', printer: 'printer', mfp: 'printer', appliance: 'appliance', other: 'appliance',
    esxi: 'host', vcenter: 'host', vmware: 'host', openshift: 'cluster', ocp: 'cluster', nutanix: 'cluster', prism: 'cluster', ahv: 'host', sql: 'sql', 'sql server': 'sql', mssql: 'sql', cluster: 'cluster', 'failover cluster': 'cluster',
    database: 'database', db: 'database', cloud: 'cloudstorage', 'cloud storage': 'cloudstorage', bucket: 'cloudstorage',
    kubernetes: 'k8scluster', k8s: 'k8scluster', aks: 'k8scluster', eks: 'k8scluster', gke: 'k8scluster', oke: 'k8scluster', cce: 'k8scluster', 'k8s node': 'k8snode', docker: 'container', podman: 'container', container: 'container', 'container host': 'container',
    'cloud firewall': 'cloudfw', 'azure firewall': 'cloudfw', 'network firewall': 'cloudfw', cfw: 'cloudfw', waf: 'waf', 'cloud armor': 'waf', vpn: 'vpn', 'vpn gateway': 'vpn', 'vpn tunnel': 'vpn', 'client vpn': 'vpn',
  };
  function kindFor(text) {
    const t = String(text || '').trim().toLowerCase();
    if (!t) return null;
    const c = CLASSES.find(([k, label]) => k === t || label.toLowerCase() === t);
    if (c) return { kind: c[0], profile: null };
    const p = PROFILES.find((x) => x.id === t || x.name.toLowerCase() === t);
    if (p) return { kind: p.kind, profile: p.id };
    if (TYPE_WORDS[t]) return { kind: TYPE_WORDS[t], profile: null };
    const e = DB_ENGINES.find(([id, name]) => id === t || name.toLowerCase() === t);
    if (e && PROFILE['db-' + e[0]]) return { kind: 'database', profile: 'db-' + e[0] };
    const lead = CLASSES.find(([, label]) => label.toLowerCase().startsWith(t));
    return lead ? { kind: lead[0], profile: null } : null;
  }
  const optionsFor = (kind) => OPTIONS.filter((o) => o.kinds === '*' || o.kinds.includes(kind));
  const optionDefault = (o, kind, ports) => (typeof o.def === 'function' ? !!o.def(kind, ports) : !!o.def);
  const TYPE_OPTION = {};
  for (const o of OPTIONS) for (const t of o.types || []) (TYPE_OPTION[t] = TYPE_OPTION[t] || []).push(o.id);
  // native sensors for the chosen options; host fills every "fromDevice" parameter
  function sensorsForOptions(kind, host, ids, ports, extra) {
    const out = [];
    for (const o of OPTIONS) if (o.native && ids.includes(o.id)) for (const t of o.native(kind, host, ports, extra || {})) {
      const params = Object.assign({}, t.params);
      for (const p of (TYPE[t.type] || {}).params || []) if (p.fromDevice && params[p.name] == null) params[p.name] = host;
      out.push({ type: t.type, params, name: t.name, limits: t.limits || null });
    }
    return out;
  }

  // ------------------------------------------------------------------ duplicates
  // what makes two probe sensors "the same" on one device (secrets and tuning values like ping count do not count)
  const KEYS = { 'ext.alert': ['integration', 'key'], ping: ['host'], port: ['host', 'port'], http: ['url'], dns: ['server', 'name', 'recordType'], sslcert: ['host', 'port'], 'snmp.uptime': ['host'], 'snmp.traffic': ['host', 'ifIndex'], 'snmp.custom': ['host', 'oid'], script: ['script', 'params', 'field'], 'db.service': ['host', 'engine', 'port'] };
  // where auto-discovery finds devices: each source is an engine dataset (Auto-discovery > Discovery methods)
  const DISCOVERY = [
    { id: 'scan', label: 'Network scan', script: 'mon.network.discovery', dataset: 'network.discovery', desc: 'Ping sweep and TCP ports of your ranges, reverse DNS and SNMP.' },
    { id: 'ad', label: 'Active Directory', script: 'inv.ad.computers', dataset: 'ad.computers', desc: 'Enabled computer accounts in AD: servers, workstations and Linux machines joined to the domain.' },
    { id: 'ws', label: 'Workstation inventory', script: 'inv.workstations', dataset: 'inventory.workstations', desc: 'Workstations that answered the inventory engine, with their address.' },
    { id: 'print', label: 'Print servers', script: 'inv.printers', dataset: 'inventory.printers', desc: 'Network printers published on your print servers.' },
    { id: 'hyperv', label: 'Hyper-V', script: 'mon.hyperv', dataset: 'virtualization.hyperv', desc: 'Virtual machines on your Hyper-V hosts, with the guest addresses.' },
    { id: 'vmware', label: 'VMware vCenter', script: 'mon.vmware', dataset: 'virtualization.vmware', desc: 'ESXi hosts and virtual machines in vCenter.' },
    { id: 'nutanix', label: 'Nutanix Prism', script: 'mon.nutanix', dataset: 'virtualization.nutanix', desc: 'AHV hosts and virtual machines in Prism.' },
    { id: 'openshift', label: 'OpenShift', script: 'mon.openshift', dataset: 'virtualization.openshift', desc: 'OpenShift Virtualization nodes and virtual machines.' },
    { id: 'k8s', label: 'Kubernetes', script: 'mon.kubernetes', dataset: 'containers.kubernetes', desc: 'Kubernetes and OpenShift cluster nodes.' },
    { id: 'linux', label: 'Linux engine', script: 'lnx.collect', dataset: 'linux.hosts', desc: 'Linux hosts the Linux collector reads over SSH.' },
    { id: 'snmp', label: 'SNMP network and storage', script: 'mon.network.devices', dataset: 'network.devices', desc: 'Switches, routers, firewalls, SANs and NAS that answer SNMP.' },
    { id: 'db', label: 'Database engines', script: 'mon.databases', dataset: 'databases.health', desc: 'Database servers the database engine checks (Oracle, PostgreSQL, MySQL and more).' },
    { id: 'cloudnet', label: 'Cloud network', script: 'mon.cloud.network', dataset: 'network.cloud', desc: 'Cloud firewalls, WAFs and VPN gateways in Azure, AWS, OCI, GCP and Huawei Cloud.' },
    { id: 'clouddb', label: 'Cloud databases', script: 'mon.cloud.databases', dataset: 'cloud.databases', desc: 'Managed databases in Azure, AWS, Google Cloud, Oracle Cloud and Huawei Cloud.' },
    { id: 'entra', label: 'Entra ID', script: 'inv.entra.devices', dataset: 'entra.devices', desc: 'Entra joined and hybrid joined computers that signed in recently (Microsoft Graph).' },
    { id: 'intune', label: 'Intune', script: 'inv.intune.devices', dataset: 'intune.devices', desc: 'Windows, macOS and Linux computers, phones and tablets managed by Intune.' },
  ];
  // probe checks that an engine sensor already makes: a device found by discovery gets no twin of them
  // (Ping next to the network discovery ping, Ping and the RDP/WinRM port checks next to Availability, SSH next to Linux)
  const COVERS = {
    'net.discovery': (t) => t.type === 'ping',
    'wmi.availability': (t) => t.type === 'ping' || (t.type === 'port' && [135, 445, 3389, 5985, 5986].includes(+(t.params || {}).port)),
    'ssh.linux': (t) => t.type === 'port' && +(t.params || {}).port === 22,
  };
  const coveredBy = (t, engineTypes) => (engineTypes || []).find((et) => COVERS[et] && COVERS[et](t)) || null;
  const sensorKey = (type, params) => type + '|' + (KEYS[type] || []).map((k) => String((params || {})[k] == null ? '' : params[k]).trim().toLowerCase()).join('|');
  // sensors that report the same problem on one device; the first type in REACH is the preferred root
  const REACH = ['ping', 'wmi.availability', 'net.discovery', 'snmp.uptime', 'port'];
  const family = (s) => (REACH.includes(s.type) ? 'reach' : s.type === 'wmi.cpu' || (s.type === 'snmp.custom' && /cpu/i.test(s.name)) ? 'cpu' : s.type === 'wmi.memory' || (s.type === 'snmp.custom' && /memory/i.test(s.name)) ? 'memory' : s.type === 'printer' || (s.type === 'snmp.custom' && /toner/i.test(s.name)) ? 'printer' : null);
  const NO_ANSWER = /no answer|not answering|timed? ?out|unreachable|refused|no response|cannot reach|could not connect|host is down/i;
  // marks alarm views (state Down/Warning) that repeat another alarm on the same device: view.related = id of the alarm that covers it.
  // A device that does not answer raises one alarm (the reachability sensor); connection errors of its other sensors fold into it.
  function markRelated(views) {
    const byDev = new Map();
    for (const v of views) { delete v.related; delete v.relatedCount; if (v.state === 'Down' || v.state === 'Warning') { if (!byDev.has(v.device)) byDev.set(v.device, []); byDev.get(v.device).push(v); } }
    for (const list of byDev.values()) {
      if (list.length < 2) continue;
      const rank = (v) => (v.state === 'Down' ? 0 : 1) * 10 + (REACH.indexOf(v.type) < 0 ? 9 : REACH.indexOf(v.type));
      const reach = list.filter((v) => family(v) === 'reach' && v.state === 'Down').sort((a, b) => rank(a) - rank(b));
      const root = reach[0];
      const link = (v, r) => { if (v === r || v.related) return; v.related = r.id; r.relatedCount = (r.relatedCount || 0) + 1; };
      if (root) for (const v of list) if (v !== root && (family(v) === 'reach' || (v.state === 'Down' && NO_ANSWER.test(v.message || '')))) link(v, root);
      const fam = new Map();
      for (const v of list) { const f = family(v); if (!f || f === 'reach' || v.related) continue; if (!fam.has(f)) fam.set(f, []); fam.get(f).push(v); }
      for (const g of fam.values()) { if (g.length < 2) continue; g.sort((a, b) => rank(a) - rank(b)); for (const v of g.slice(1)) link(v, g[0]); }
    }
    return views;
  }

  // ------------------------------------------------------------------ direct sensors (no engine)
  // Any collector type can also run directly from the probe for one device: the probe runs the type's script against
  // that device only and turns the result into a reading with the same rules derive() uses for engine data.
  const DIRECT_EVERY = { 'wmi.cpu': 60, 'wmi.memory': 60, 'wmi.diskio': 60, 'wmi.network': 60, 'wmi.availability': 60, 'wmi.disk': 300, 'wmi.services': 120, 'wmi.iis': 120, 'dns.server': 120, 'dhcp.scope': 300, 'printer': 120, 'ssh.linux': 120, 'hv.host': 120, 'hv.vm': 120, 'vmw.host': 120, 'vmw.vm': 120, 'vmw.datastore': 300, 'ocp.node': 120, 'ocp.vm': 120, 'ntx.host': 120, 'ntx.vm': 120, 'ntx.container': 300, 'cluster': 120, 'cluster.csv': 300, 'ad.dc': 300, 'ad.replication': 300, 'sql.instance': 300, 'db.instance': 300, 'fs.server': 300, 'net.snmpdev': 120, 'storage.snmpdev': 300, 'lnx.fs': 300, 'lnx.services': 120, 'lnx.audit': 900, 'web.server': 120, 'ssl.engine': 3600, 'hw.temp': 300, 'k8s.cluster': 120, 'k8s.node': 120, 'k8s.workload': 120, 'docker.host': 120, 'docker.container': 120, 'cloud.fw': 300, 'cloud.waf': 300, 'cloud.vpngw': 300, 'cloud.vpn': 120, 'cloud.vpnclients': 300, 'web.host': 600, 'cloud.db': 900, 'entra.tenant': 900, 'entra.accounts': 3600, 'intune.tenant': 900, 'intune.device': 900 };
  const directInterval = (typeId) => DIRECT_EVERY[typeId] || 900;
  const hashOf = (x) => { let h = 2166136261; for (const ch2 of String(x)) h = Math.imul(h ^ ch2.charCodeAt(0), 16777619); return h >>> 0; };
  // ds: datasets with the type's dataset (one device's run, or all data in the demo); dev: {id,name,host}; opts: {item, single, simulate}
  function directReading(typeId, ds, dev, opts) {
    opts = opts || {};
    const t = TYPE[typeId];
    if (!t || !t.dataset) throw new Error('This sensor type cannot run directly');
    const set = ds[t.dataset];
    if (!set) return { channels: [], forced: 'Down', message: 'No result from ' + t.script };
    if (set.status === 'error') return { channels: [], forced: 'Down', message: set.message || t.script + ' failed' };
    const input = Object.assign({}, ds);
    if (!input['ad.health']) input['ad.health'] = { data: [], summary: { domain: (dev && (dev.host || dev.name)) || 'domain' } };
    const all = derive(input, { now: opts.now }).sensors.filter((x) => x.type === typeId);
    const names = [dev && dev.name, dev && dev.host].filter(Boolean).map((n) => devId(short(n)));
    let mine = all.filter((x) => x.device === (dev && dev.id) || names.includes(x.device));
    if (!mine.length && opts.single) mine = all; // the run targeted only this device: whatever came back is it
    if (!mine.length && opts.simulate && all.length) mine = [all[hashOf(dev && dev.id) % all.length]];
    if (!mine.length) return { channels: [], forced: 'Down', message: (dev ? dev.name : 'The device') + ' returned no ' + t.name + ' data. Check the requirement steps on this sensor.' };
    if (opts.item) { const it = String(opts.item).toLowerCase(); const one = mine.filter((x) => x.id.toLowerCase().endsWith(':' + it.replace(/[^\w.-]+/g, '_')) || x.name.toLowerCase().includes(it)); if (one.length) mine = one; else return { channels: [], forced: 'Down', message: 'No ' + opts.item + ' on ' + (dev ? dev.name : 'the device') }; }
    if (mine.length === 1) { const r = mine[0].reading || {}; return { channels: (r.channels || []).map((c) => Object.assign({}, c)), forced: r.forced || undefined, message: r.message || '' }; }
    // several items (volumes, scopes, VMs): one channel per item from its primary channel, the worst state wins
    const chans = mine.slice(0, 40).map((x) => { const r = x.reading || {}; const c = (r.channels || []).find((y) => y.primary) || (r.channels || [])[0] || {}; return Object.assign({}, c, { name: x.name.replace(/^(Disk free|VM|DHCP)\s+/i, '') || c.name, primary: false }); });
    if (chans[0]) chans[0].primary = true;
    const forced = mine.map((x) => (x.reading || {}).forced).filter(Boolean);
    return { channels: chans, forced: forced.includes('Down') ? 'Down' : forced.includes('Warning') ? 'Warning' : undefined, message: mine.map((x) => (x.reading || {}).message).filter(Boolean).slice(0, 3).join('; ') };
  }

  // Inventory a device gets when it is onboarded by hand, from auto-discovery or from an import: the same collectors the
  // engines use for the devices they find, aimed at this one device. key = the row field that names the device.
  const INV_WIN = (d) => ['server', 'workstation', 'vm'].includes(d.kind) && !/linux|unix|esxi/i.test(d.os || '') && !(d.kind === 'vm' && !/windows/i.test(d.os || ''));
  const SRV = (d) => INV_WIN(d) && d.kind !== 'workstation';
  const LNX = (d) => d.kind === 'linux' || /linux|ubuntu|debian|red hat|rhel|centos|suse|rocky|alma/i.test(d.os || '');
  const hasRole = (d, r) => (d.roles || []).includes(r) || new RegExp(r, 'i').test(d.profile || '');
  // param: the parameter that names the device when it is not ComputerName
  const INVENTORY = [
    { script: 'inv.hardware', dataset: 'inventory.hardware', key: 'Name', label: 'Hardware, OS, uptime, last user, roles', when: INV_WIN },
    { script: 'inv.workstations', dataset: 'inventory.workstations', key: 'Name', label: 'Workstation hardware and OS', when: (d) => INV_WIN(d) && d.kind === 'workstation' },
    { script: 'inv.software', dataset: 'inventory.software', key: 'ComputerName', label: 'Installed software', when: (d) => INV_WIN(d) || LNX(d) },
    { script: 'inv.server.roles', dataset: 'inventory.roles', key: 'ComputerName', label: 'Roles and features', when: SRV },
    { script: 'inv.storage', dataset: 'inventory.storage', key: 'ComputerName', label: 'Disks and volumes', when: SRV },
    { script: 'mon.disks', dataset: 'servers.disks', key: 'ComputerName', label: 'Free space per volume', when: INV_WIN },
    { script: 'mon.services', dataset: 'servers.services', key: 'ComputerName', label: 'Services', when: INV_WIN },
    { script: 'mon.availability', dataset: 'servers.availability', key: 'Name', label: 'Availability, ports and last boot', when: INV_WIN },
    { script: 'mon.compute', dataset: 'servers.compute', key: 'Name', label: 'CPU, memory, disk and network load', when: INV_WIN },
    { script: 'mon.events', dataset: 'servers.events', key: 'ComputerName', label: 'Event log errors', when: INV_WIN },
    { script: 'sec.patches', dataset: 'security.patches', key: 'ComputerName', label: 'Patches and pending reboot', when: INV_WIN },
    { script: 'sec.defender', dataset: 'security.defender', key: 'ComputerName', label: 'Microsoft Defender', when: INV_WIN },
    { script: 'sec.firewall', dataset: 'security.firewall', key: 'ComputerName', label: 'Firewall, RDP and SMBv1', when: INV_WIN },
    { script: 'mon.localadmins', dataset: 'security.localadmins', key: 'ComputerName', label: 'Local administrators', when: INV_WIN },
    { script: 'mon.activation', dataset: 'servers.activation', key: 'ComputerName', label: 'Windows activation', when: INV_WIN },
    { script: 'mon.os.updates', dataset: 'updates.status', key: 'Name', label: 'OS version against the latest release', when: (d) => INV_WIN(d) || LNX(d), param: (d) => (LNX(d) ? 'LinuxHost' : 'ComputerName') },
    { script: 'mon.iis', dataset: 'servers.iis', key: 'ComputerName', label: 'IIS sites and application pools', when: (d) => SRV(d) && hasRole(d, 'IIS') },
    { script: 'inv.fileshares', dataset: 'inventory.fileshares', key: 'ComputerName', label: 'File shares', when: (d) => SRV(d) && hasRole(d, 'File') },
    { script: 'inv.printers', dataset: 'inventory.printers', key: 'PrintServer', label: 'Printers and queues', when: (d) => SRV(d) && hasRole(d, 'Print') },
    { script: 'inv.sql', dataset: 'inventory.sql', key: 'ComputerName', label: 'SQL Server instances', when: (d) => INV_WIN(d) && hasRole(d, 'SQL') },
    { script: 'lnx.collect', dataset: 'linux.hosts', key: 'Name', label: 'Linux system, packages and updates', when: LNX },
  ];
  // access levels asked for every device added by hand: what MonCastle may do there with the account it is given
  const ACCESS_LEVELS = [
    { id: 'monitor', label: 'Monitor only', desc: 'Ping, ports, SNMP, HTTP and other probe checks. No sign-in on the device: no inventory, no actions.' },
    { id: 'read', label: 'Read (inventory)', desc: 'Signs in with a read account: monitoring plus the full inventory (hardware, software, services, roles, patches, security). Nothing is changed.' },
    { id: 'admin', label: 'Administrator', desc: 'Everything in Read, plus client actions, remote scripting and remote control (RDP, SSH, web). Needs an administrator account on the device.' },
  ];
  const accessOf = (d) => (d && ACCESS_LEVELS.some((a) => a.id === d.accessLevel) ? d.accessLevel : 'admin');
  const inventoryPlan = (d, scripts) => INVENTORY.filter((x) => x.when(d || {}) && (accessOf(d) !== 'monitor' || x.script === 'mon.availability') && (!scripts || scripts.some((s) => s.id === x.script)));

  return { isIp, DISCOVERY, COVERS, coveredBy, INVENTORY, inventoryPlan, ACCESS_LEVELS, accessOf, directReading, directInterval, STATES, RANK, worst, TYPES, TYPE, GROUPS, OPTIONS, optionsFor, optionDefault, TYPE_OPTION, sensorsForOptions, check, evaluate, derive, templateFor, devId, sensorId, short, sensorKey, markRelated, CLASSES, PROFILES, PROFILE, DB_ENGINES, DB_ENGINE, DB_CATEGORIES, profilesFor, profileBySysOid, profileSensors, KIND_GROUP, kindFor, classifyHost };
});
