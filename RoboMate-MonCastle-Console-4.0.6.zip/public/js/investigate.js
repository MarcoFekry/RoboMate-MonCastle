/*
 * RoboMate MonCastle - investigation steps for a sensor that is down, in warning or has no data
 * (browser: window.MCInvestigate, server: require). Reads the sensor type and its error message and returns what
 * to check, in order, from the MonCastle server's point of view: reachability, the port or protocol, the credential,
 * the engine, and finally the limits. Each step can carry a command to run on the MonCastle server and an action
 * the console can run for the user (scan again, network test, DNS lookup, test the credential, open the engine).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCInvestigate = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const has = (re, m) => re.test(String(m || ''));
  const NOREPLY = /no reply|no answer|not answering|timed? ?out|unreachable|host is down|no response|ehostunreach|enetunreach/i;
  const REFUSED = /refused|econnrefused|reset/i;
  const DNSFAIL = /enotfound|eai_again|getaddrinfo|could not resolve|no such host/i;
  const AUTH = /401|403|unauthori[sz]ed|forbidden|access is denied|access denied|logon failure|authentication|wrong .*password|unknown user name|permission denied|login failed/i;
  const TLS = /certificate|self[- ]signed|unable to verify|ssl|tls|cert_/i;
  const STALE = /no new data|stale|check the .* engine/i;
  const NOOID = /did not return a number|does not have this oid|nosuchobject|nosuchinstance|has no size/i;
  const LIMIT = /above the|below the|limit of/i;

  // what the console can do for the user: { label, run: scriptId, params } | { label, scan: true } | { label, href } | { label, cred: kind } | { label, settings: true }
  const scan = { label: 'Scan again now', scan: true };
  const netTest = (host, port) => ({ label: port ? 'Test port ' + port + ' from the server' : 'Ping and trace from the server', run: 'act.nettest', params: port ? { Target: host, Port: port, Test: 'Port' } : { Target: host, Test: 'TraceRoute' } });
  const dnsTest = (host) => ({ label: 'Resolve ' + host, run: 'act.dns', params: { Name: host } });
  const credTest = (kind) => ({ label: 'Test the ' + kind + ' credential', cred: kind });
  const settings = { label: 'Open settings and limits', settings: true };
  const engine = (id) => ({ label: 'Open the ' + id + ' engine', href: '#/engines/' + encodeURIComponent(id) });
  const step = (title, detail, extra) => Object.assign({ title, detail }, extra || {});

  const SNMP_KIND = 'snmp';
  const isIp = (h) => /^\d{1,3}(\.\d{1,3}){3}$|:/.test(String(h || ''));

  function forSensor(s, dev) {
    dev = dev || {};
    const host = (s.params && (s.params.host || s.params.server)) || (s.params && s.params.url ? String(s.params.url).replace(/^\w+:\/\//, '').split(/[/:]/)[0] : '') || s.deviceHost || dev.host || s.deviceName || '';
    const msg = s.message || '';
    const t = s.type || '';
    const srv = dev.serverName || 'the MonCastle server';
    const out = { cause: 'other', summary: '', steps: [] };
    const add = (...x) => out.steps.push(...x);
    const reach = () => {
      add(step('Check that ' + host + ' is powered on and connected', 'Look at the device itself, its switch port and its power. A device that was moved or re-addressed needs its address updated in the device settings.'),
        step('Test the path from ' + srv, 'The probe runs on ' + srv + ', so the test has to come from there. If the trace stops at a router or firewall, the problem is on that hop.', { cmd: 'Test-NetConnection ' + host + ' -TraceRoute', action: netTest(host) }));
      if (!isIp(host)) add(step('Check that the name resolves', host + ' must resolve to the right address on ' + srv + '. A stale DNS record sends the probe to the wrong place.', { cmd: 'Resolve-DnsName ' + host, action: dnsTest(host) }));
      add(step('Allow ICMP echo from ' + srv, 'Firewalls often drop ping. On Windows enable the inbound rule "File and Printer Sharing (Echo Request - ICMPv4-In)"; on network devices allow ICMP from the MonCastle server address in the management ACL.'));
      if (dev.server && dev.servers > 1) add(step('Check which MonCastle server monitors this device', 'This device is assigned to ' + srv + '. If it sits in a site or VLAN that only another MonCastle server can reach, move it to that server in the device settings.'));
    };

    if (s.state === 'Paused') { out.cause = 'paused'; out.summary = 'The sensor is paused, so it does not scan. Resume it to check it again.'; return out; }

    // limit breaches are not connectivity problems
    if (LIMIT.test(msg) && !NOREPLY.test(msg)) {
      out.cause = 'limit';
      out.summary = 'The device answers, but a value is past its limit: ' + msg;
      add(step('Look at the trend', 'Open the graphs above and compare with the last days. A sudden jump points to a change or an incident; a slow climb points to capacity.'));
      if (/cpu|processor|load/i.test(s.name + msg)) add(step('Find the busy processes', 'See which processes use the CPU right now.', { action: { label: 'Show top processes', run: 'mon.processes', params: { ComputerName: s.deviceName || host } } }));
      if (/disk|free|volume|space|datastore|used/i.test(s.name + msg)) add(step('Find what fills the volume', 'Large and old files, logs, backups and shadow copies are the usual causes.', { action: { label: 'Find large files', run: 'mon.largefiles', params: { ComputerName: s.deviceName || host } } }));
      if (/memory/i.test(s.name + msg)) add(step('Check memory use per process', 'A process with growing memory over days usually leaks; SQL Server and Exchange reserve memory on purpose.', { action: { label: 'Show top processes', run: 'mon.processes', params: { ComputerName: s.deviceName || host } } }));
      if (/temperature|°c/i.test(s.name + msg)) add(step('Check cooling', 'Check fans, airflow, blanking panels and the room temperature. Compare with other devices in the same rack.'));
      if (/battery|runtime|minutes remaining|charge/i.test(s.name + msg)) add(step('Check the UPS battery', 'Low runtime with normal load means the batteries are aging or the UPS is on battery. Run a self-test and check the input power.'));
      add(step('Adjust the limit if it is too strict', 'If this value is normal for this device, raise the warning or error limit for this sensor only.', { action: settings }));
      return out;
    }

    if (STALE.test(msg) || s.state === 'Unknown' && s.source === 'collector') {
      out.cause = 'engine';
      out.summary = 'The engine that collects this sensor has not delivered new data.';
      add(step('Check the engine', 'Open the engine to see its last run, its result and errors, and when it runs next.', { action: engine(s.script || '') }),
        step('Run the engine now', 'A manual run shows the error right away if the engine cannot collect.', { action: { label: 'Run ' + (s.script || 'the engine'), run: s.script, params: { ComputerName: s.deviceName || host } } }),
        step('Check the scheduled task on ' + srv, 'Engines run as scheduled tasks under \\RoboMate\\MonCastle\\Engines. A disabled task, an expired service account password or a full disk stops them.', { cmd: "Get-ScheduledTask -TaskPath '\\RoboMate\\MonCastle\\Engines\\' | Get-ScheduledTaskInfo | Format-Table TaskName, LastRunTime, LastTaskResult" }));
      return out;
    }

    if (DNSFAIL.test(msg)) {
      out.cause = 'dns';
      out.summary = 'The name ' + host + ' does not resolve on ' + srv + '.';
      add(step('Resolve the name on ' + srv, 'Check the DNS servers the MonCastle server uses and that the record exists.', { cmd: 'Resolve-DnsName ' + host, action: dnsTest(host) }),
        step('Use the IP address or fix the record', 'Either create the A record, or put the IP address in the device settings.', { action: settings }));
      return out;
    }

    // Windows collectors (WinRM / WMI)
    if (/^(wmi|sec|win|fs|dns\.server|dhcp|ad|hv|cluster|sql)\b/.test(t) && s.source === 'collector') {
      if (NOREPLY.test(msg) || /no answer from the server/i.test(msg)) { out.cause = 'connectivity'; out.summary = s.deviceName + ' does not answer the engine.'; reach(); }
      else out.summary = 'The engine reached ' + (s.deviceName || host) + ' but could not read it: ' + msg;
      add(step('Test PowerShell remoting', 'Engines read Windows servers over WinRM (TCP 5985, or 5986 for HTTPS). The service must run and the firewall must allow the MonCastle server.', { cmd: 'Test-WSMan ' + (s.deviceName || host) + '; Test-NetConnection ' + (s.deviceName || host) + ' -Port 5985', action: netTest(s.deviceName || host, 5985) }),
        step('Enable remoting on the server if needed', 'Run once on ' + (s.deviceName || host) + ' as administrator, or push it with Group Policy (Allow remote server management through WinRM).', { cmd: 'Enable-PSRemoting -Force' }),
        step('Check the Windows credential', 'The account needs to be a local administrator, or a member of Remote Management Users with WMI read rights (wmimgmt.msc, Root\\CIMV2, Remote Enable). Non-domain servers also need the MonCastle server in TrustedHosts.', { action: credTest('windows') }));
      if (AUTH.test(msg)) out.cause = 'auth';
      add(step('Look at the engine result', 'The engine run shows the exact error per server.', { action: engine(s.script || '') }), scanStep());
      return out;
    }
    if (t === 'ssh.linux') {
      out.cause = AUTH.test(msg) ? 'auth' : NOREPLY.test(msg) ? 'connectivity' : 'other';
      out.summary = 'The Linux engine could not read ' + (s.deviceName || host) + ': ' + msg;
      if (out.cause === 'connectivity') reach();
      add(step('Test SSH', 'TCP 22 must be open from ' + srv + ' and sshd must accept the account.', { cmd: 'Test-NetConnection ' + host + ' -Port 22', action: netTest(host, 22) }),
        step('Check the SSH credential', 'Password or key must match; key files need the PEM format. Some checks (updates, failed units) need sudo without a password for the listed commands.', { action: credTest('ssh') }), scanStep());
      return out;
    }
    if (/^db\./.test(t)) {
      const p = s.params || {};
      const eng = p.engine || dev.engine || '';
      const port = +p.port || { mssql: 1433, mysql: 3306, mariadb: 3306, postgres: 5432, oracle: 1521, mongodb: 27017, redis: 6379, elastic: 9200, cassandra: 9042, db2: 50000, hana: 30015, couchdb: 5984, couchbase: 8091, influxdb: 8086, clickhouse: 8123, neo4j: 7687 }[eng] || null;
      const isTls = TLS.test(msg) && !/tls offered/i.test(msg);
      out.cause = /not allowed to connect|pg_hba|refused this host/i.test(msg) ? 'access' : AUTH.test(msg) || /needs a password|noauth|wrongpass|refused the credential|refused the request/i.test(msg) ? 'auth' : isTls ? 'certificate' : /is not \w+|did not answer|not .* engine/i.test(msg) ? 'config' : NOREPLY.test(msg) || REFUSED.test(msg) ? 'connectivity' : 'other';
      out.summary = { access: 'The database answers but does not accept connections from ' + srv + ': ' + msg, auth: 'The database rejects the monitoring login: ' + msg, certificate: 'The TLS handshake with the database failed: ' + msg, config: 'Something answers on port ' + (port || '?') + ', but not the expected engine: ' + msg, connectivity: 'The database port on ' + host + ' does not answer from ' + srv + '.' }[out.cause] || 'The database check failed: ' + msg;
      if (out.cause === 'connectivity') { reach(); if (port) add(step('Test the database port', 'The engine listens on ' + port + ' unless it was changed. Check the service is running and the host firewall allows ' + srv + '.', { cmd: 'Test-NetConnection ' + host + ' -Port ' + port, action: netTest(host, port) })); }
      if (out.cause === 'access') add(step('Allow ' + srv + ' on the database', eng === 'postgres' ? 'Add a line for the MonCastle server address to pg_hba.conf and reload PostgreSQL.' : /mysql|mariadb/.test(eng) ? 'Create the monitoring user for the MonCastle server address (CREATE USER \'moncastle\'@\'<server ip>\') and grant PROCESS, REPLICATION CLIENT and SELECT on performance_schema.' : 'Allow the MonCastle server address in the database access list or network ACL.'));
      if (out.cause === 'auth') add(step('Check the Database credential', 'Assign a Database credential to the device or its group. Use a read-only monitoring account: ' + ({ redis: 'an ACL user with +info +ping is enough', elastic: 'the monitor cluster privilege is enough', mongodb: 'the clusterMonitor role is enough', postgres: 'the pg_monitor role is enough', oracle: 'SELECT_CATALOG_ROLE is enough' }[eng] || 'read access to the status views is enough') + '.', { action: credTest('database') }));
      if (out.cause === 'certificate') add(step('Match the TLS setting', 'Set TLS on the Database credential to Require or Off to match the server, or set Certificate to "Ignore (self-signed)" for a private CA.', { action: credTest('database') }));
      if (out.cause === 'config') add(step('Check the engine and port', 'The sensor speaks the ' + (eng || 'chosen') + ' protocol. Pick the right engine (the device model) and port in the settings.', { action: settings }));
      if (s.source === 'collector') add(step('Look at the engine result', 'The database engine shows the exact error per instance and needs the client tools for each engine on ' + srv + ' (installed by the setup app).', { action: engine(s.script || 'mon.databases') }));
      add(scanStep());
      return out;
    }
    if (/^cloud\./.test(t)) {
      out.cause = AUTH.test(msg) || /invalidaccesskey|signature|expired|aadsts|not authorized/i.test(msg) ? 'auth' : NOREPLY.test(msg) || REFUSED.test(msg) || DNSFAIL.test(msg) ? 'connectivity' : 'other';
      out.summary = out.cause === 'auth' ? 'The cloud provider refused the identity: ' + msg : out.cause === 'connectivity' ? srv + ' cannot reach the provider API.' : 'The cloud storage engine could not read the account: ' + msg;
      if (out.cause === 'connectivity') add(step('Allow outbound HTTPS from ' + srv, 'The engine calls the provider over HTTPS 443. Allow the storage and sign-in endpoints in the proxy or firewall.', { cmd: 'Test-NetConnection ' + (host || 'storage endpoint') + ' -Port 443', action: netTest(host, 443) }));
      add(step('Check the Cloud credential', 'Azure: service principal with Storage Blob Data Reader and Reader on the subscription. AWS: an IAM user or role with s3:ListAllMyBuckets, s3:GetBucket* and cloudwatch:GetMetricData. Google Cloud: a service account with Storage Object Viewer and Monitoring Viewer. OCI: an API key for a user in a group allowed to "inspect buckets" and "read objectstorage-namespaces". Huawei Cloud: an access key with OBS ReadOnlyAccess.', { action: credTest('cloud') }),
        step('Check the secret has not expired', 'Client secrets and access keys expire or get rotated. Create a new one and update the Cloud credential.'),
        step('Look at the engine result', 'The engine run shows the error per account and bucket.', { action: engine('mon.cloud.storage') }), scanStep());
      return out;
    }
    if (/^vmw\./.test(t)) {
      out.summary = 'The VMware engine could not read vCenter or ESXi: ' + msg;
      add(step('Test the vCenter API', 'HTTPS 443 must be open from ' + srv + ' to vCenter.', { action: netTest(host, 443) }),
        step('Check the VMware credential', 'A read-only role on the vCenter root is enough. With a self-signed certificate, set Certificate to "Ignore" on the credential.', { action: credTest('vmware') }), scanStep());
      return out;
    }

    // probe sensors
    switch (t) {
      case 'ping':
        out.cause = 'connectivity'; out.summary = host + ' does not answer ping from ' + srv + '.';
        reach(); add(scanStep());
        return out;
      case 'port': {
        const port = (s.params || {}).port;
        out.cause = 'connectivity';
        out.summary = REFUSED.test(msg) ? host + ' answered, but nothing listens on port ' + port + '.' : 'Port ' + port + ' on ' + host + ' does not answer.';
        if (REFUSED.test(msg)) add(step('Start the service that owns port ' + port, 'The host is up and actively refused the connection, so the service is stopped or listens on another port.', { cmd: 'Get-NetTCPConnection -State Listen -LocalPort ' + port + '   # run on ' + host }));
        else reach();
        add(step('Allow port ' + port + ' from ' + srv, 'Check the host firewall and any firewall in between.', { cmd: 'Test-NetConnection ' + host + ' -Port ' + port, action: netTest(host, port) }), scanStep());
        return out;
      }
      case 'http': {
        out.cause = AUTH.test(msg) ? 'auth' : TLS.test(msg) ? 'certificate' : NOREPLY.test(msg) || REFUSED.test(msg) ? 'connectivity' : 'content';
        out.summary = 'The web check failed: ' + msg;
        if (out.cause === 'connectivity') { reach(); add(step('Test the web port', 'HTTPS uses 443 and HTTP 80 unless the URL names another port.', { action: netTest(host, /^https/.test((s.params || {}).url || '') ? 443 : 80) })); }
        if (out.cause === 'auth') add(step('Check the web credential', 'The site asks for a login. Assign an HTTP credential (Basic, bearer token or API key) to the device or its group.', { action: credTest('http') }));
        if (out.cause === 'certificate') add(step('Trust the certificate', 'The certificate is not trusted on ' + srv + '. Import the issuing CA into the Windows certificate store, or renew the certificate with the full chain.'));
        if (out.cause === 'content') add(step('Compare the expected result', 'Check the expected status code and keyword in the sensor settings against what the page returns now.', { action: settings }), step('Check a proxy', 'If the MonCastle server reaches the internet through a proxy, internal URLs must be excluded from it.'));
        add(scanStep());
        return out;
      }
      case 'sslcert':
        out.cause = NOREPLY.test(msg) || REFUSED.test(msg) ? 'connectivity' : 'certificate';
        out.summary = out.cause === 'connectivity' ? 'The TLS port on ' + host + ' does not answer.' : msg;
        if (out.cause === 'connectivity') { reach(); add(step('Test the TLS port', '', { action: netTest(host, (s.params || {}).port || 443) })); }
        else add(step('Renew the certificate', 'Request a new certificate before it expires and bind it on every server and load balancer that serves ' + host + '.'));
        add(scanStep());
        return out;
      case 'dns':
        out.cause = NOREPLY.test(msg) ? 'connectivity' : 'dns';
        out.summary = 'The DNS query failed: ' + msg;
        add(step('Query the DNS server directly', 'Ask ' + host + ' for the name from ' + srv + '. UDP and TCP 53 must be open.', { cmd: 'Resolve-DnsName ' + ((s.params || {}).name || '') + ' -Server ' + host + ' -Type ' + ((s.params || {}).recordType || 'A'), action: netTest(host, 53) }),
          step('Check the DNS service and zone', 'On the DNS server check that the DNS Server service runs and the record exists in the zone.'), scanStep());
        return out;
      case 'snmp.uptime': case 'snmp.traffic': case 'snmp.custom': case 'snmp.storage':
        if (NOOID.test(msg)) {
          out.cause = 'config';
          out.summary = 'SNMP works, but the device does not have the value this sensor asks for.';
          add(step('Check the model', 'The model chosen for the device decides which vendor OIDs are read. Pick the right model in the device settings, or remove sensors the model does not support.', { action: settings }),
            step('Check the SNMP view', 'Some devices limit what an SNMP user or community can read (an SNMP view). Allow the vendor MIB for the MonCastle user.'),
            step('Read the OID by hand', 'Confirm the OID or the hrStorage/interface index exists.', { cmd: 'snmpget -v2c -c <community> ' + host + ' ' + ((s.params || {}).oid || '1.3.6.1.2.1.1.3.0') }));
          return out;
        }
        out.cause = AUTH.test(msg) || /v3:/i.test(msg) ? 'auth' : 'connectivity';
        out.summary = out.cause === 'auth' ? 'The device rejects the SNMP credential: ' + msg : host + ' does not answer SNMP from ' + srv + '.';
        if (out.cause === 'connectivity') add(step('Check that SNMP is enabled on ' + host, 'Turn on the SNMP agent (v2c or v3) on the device.'),
          step('Allow ' + srv + ' in the SNMP access list', 'Most devices answer SNMP only to listed managers. Add the MonCastle server address to the SNMP ACL or trusted hosts, and allow UDP 161 on any firewall in between.'));
        add(step('Check the SNMP credential', 'The community (v2c) or the user, authentication and privacy protocols and passwords (v3) must match the device exactly.', { action: credTest(SNMP_KIND) }), scanStep());
        return out;
      case 'script':
        out.summary = 'The script sensor failed: ' + msg;
        add(step('Run the script by hand', 'Run the script from the library with the same parameters to see the full error.', { action: { label: 'Run ' + ((s.params || {}).script || 'the script'), run: (s.params || {}).script, params: {} } }), scanStep());
        return out;
      default:
        out.summary = msg || 'The sensor reports a problem.';
        if (NOREPLY.test(msg)) { out.cause = 'connectivity'; reach(); }
        add(scanStep());
        return out;
    }
    function scanStep() { return step('Scan again', 'After a change, scan the sensor to confirm it is back up.', { action: scan }); }
  }

  return { forSensor };
});
