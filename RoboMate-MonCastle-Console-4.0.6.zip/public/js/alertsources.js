/*
 * RoboMate MonCastle - alerts from other monitoring systems. Shared by the browser (window.MCAlertSources) and the
 * server (module.exports). Each source turns the webhook body that the other tool sends into a list of alerts:
 *   { key, host, name, state: 'Down' | 'Warning' | 'Up', message, url, at }
 * key identifies one alert (or one check on one host) so a later "resolved" call clears the same alarm.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MCAlertSources = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const str = (v) => (v == null ? '' : String(v)).trim();
  const lower = (v) => str(v).toLowerCase();
  // severity words used by the common tools, mapped to MonCastle states
  function sev(v, fallback) {
    const s = lower(v);
    if (!s) return fallback || 'Down';
    if (/^(ok|up|normal|resolved|recovered|recovery|reset|cleared|closed|clear|0|green|success|healthy|good)$/.test(s)) return 'Up';
    if (/^(critical|crit|disaster|high|major|error|err|down|fatal|emergency|alert|sev0|sev1|p1|p2|1|2|5|red|unreachable|failed|failure|alarm)$/.test(s)) return 'Down';
    if (/^(warning|warn|average|medium|minor|sev2|sev3|p3|3|4|yellow|degraded|unknown)$/.test(s)) return 'Warning';
    if (/^(info|information|informational|low|not classified|sev4|p4|p5|notice|debug)$/.test(s)) return 'Warning';
    return fallback || 'Down';
  }
  const one = (key, host, name, state, message, extra) => Object.assign({ key: str(key) || lower(host) + '|' + lower(name), host: str(host), name: str(name) || 'Alert', state, message: str(message).slice(0, 2000) }, extra || {});
  const hostOf = (v) => str(v).replace(/^[a-z]+:\/\//i, '').replace(/[:/].*$/, '');

  // Prometheus Alertmanager and Grafana alerting post the same shape: { alerts: [ { status, labels, annotations, fingerprint } ] }
  function alertmanager(b) {
    return (b.alerts || []).map((a) => {
      const l = a.labels || {}, n = a.annotations || {};
      const resolved = lower(a.status) === 'resolved';
      return one(a.fingerprint || l.alertname + '|' + (l.instance || l.host || ''), hostOf(l.host || l.hostname || l.instance || l.node || l.nodename || l.pod || l.job), l.alertname || n.title || 'Alert',
        resolved ? 'Up' : sev(l.severity, 'Down'), n.summary || n.description || n.message || a.valueString || '', { url: a.generatorURL || a.panelURL || a.dashboardURL || '', at: a.startsAt });
    });
  }
  const SOURCES = [
    { id: 'prometheus', name: 'Prometheus Alertmanager', parse: alertmanager,
      setup: 'In alertmanager.yml add a receiver with webhook_configs: [{ url: "<URL>", http_config: { authorization: { credentials: "<TOKEN>" } }, send_resolved: true }] and route alerts to it.',
      sample: { alerts: [{ status: 'firing', labels: { alertname: 'HighCPU', instance: 'lnx-web01:9100', severity: 'warning' }, annotations: { summary: 'CPU above 90% for 10 minutes' }, fingerprint: 'demo-prom-1' }] } },
    { id: 'grafana', name: 'Grafana alerting', parse: alertmanager,
      setup: 'Alerting > Contact points > New contact point, type Webhook, URL <URL>, Authorization header scheme Bearer and credentials <TOKEN>.',
      sample: { alerts: [{ status: 'firing', labels: { alertname: 'Disk almost full', host: 'fs02', severity: 'critical' }, annotations: { summary: 'E: is 97% full' }, fingerprint: 'demo-graf-1' }] } },
    { id: 'zabbix', name: 'Zabbix', parse: (b) => [one(b.event_id || b.eventid, b.host || b.hostname, b.trigger || b.name || b.subject, /resolved|ok|recovery/i.test(str(b.status)) || str(b.value) === '0' ? 'Up' : sev(b.severity, 'Down'), b.message || b.opdata, { url: b.url })],
      setup: 'Alerts > Media types > Create, type Webhook, URL <URL>, add header Authorization: Bearer <TOKEN>, and parameters event_id={EVENT.ID}, host={HOST.NAME}, trigger={EVENT.NAME}, severity={EVENT.SEVERITY}, status={EVENT.STATUS}, message={EVENT.OPDATA}. Send it as JSON.',
      sample: { event_id: 'demo-zbx-1', host: 'core-sw-hq01', trigger: 'Interface Gi1/0/48 down', severity: 'High', status: 'PROBLEM', message: 'Link down for 3m' } },
    { id: 'nagios', name: 'Nagios, Icinga, Checkmk', parse: (b) => {
        const svc = str(b.service || b.service_description || b.SERVICEDESC);
        const st = str(b.state || b.service_state || b.host_state || b.SERVICESTATE || b.HOSTSTATE);
        return [one(lower(b.host || b.HOSTNAME) + '|' + lower(svc || 'host'), b.host || b.HOSTNAME || b.hostname, svc || 'Host check', /recovery|resolved/i.test(str(b.type || b.notification_type || b.NOTIFICATIONTYPE)) ? 'Up' : sev(st, 'Down'), b.output || b.SERVICEOUTPUT || b.HOSTOUTPUT || b.message)];
      },
      setup: 'Add a notification command that posts JSON with curl: curl -s -H "Authorization: Bearer <TOKEN>" -H "Content-Type: application/json" -d \'{"host":"$HOSTNAME$","service":"$SERVICEDESC$","state":"$SERVICESTATE$","type":"$NOTIFICATIONTYPE$","output":"$SERVICEOUTPUT$"}\' <URL>',
      sample: { host: 'lnx-db01', service: 'MySQL replication', state: 'CRITICAL', type: 'PROBLEM', output: 'Slave IO not running' } },
    { id: 'prtg', name: 'PRTG Network Monitor', parse: (b) => [one(b.sensorid || b.id, b.host || b.device, (b.device ? b.device + ': ' : '') + str(b.sensor || b.name), sev(String(b.status || '').replace(/\s*\(.*$/, '').replace(/^(down|down \w+)$/i, 'down').replace(/^(up|up \w+)$/i, 'up').replace(/partial.*|unusual/i, 'warning'), 'Down'), b.message || b.lastmessage)],
      setup: 'Setup > Account settings > Notification templates > Execute HTTP action: URL <URL>?token=<TOKEN>, method POST, payload sensorid=%sensorid&device=%device&host=%host&sensor=%name&status=%status&message=%message.',
      sample: { sensorid: 'demo-prtg-2041', device: 'UPS-HQ-01', host: '10.10.8.10', sensor: 'Battery capacity', status: 'Down', message: 'Battery at 18 %' } },
    { id: 'solarwinds', name: 'SolarWinds Orion', parse: (b) => [one(b.alertId || b.alertObjectId || b.AlertObjectID, b.ip || b.node || b.NodeName, b.alert || b.AlertName, /reset|cleared/i.test(str(b.state || b.action)) ? 'Up' : sev(b.severity, 'Down'), b.message || b.AlertMessage)],
      setup: 'Alert action "Send a GET or POST request to a web server": URL <URL>?token=<TOKEN>, POST, body {"alertId":"${N=Alerting;M=AlertObjectID}","node":"${N=SwisEntity;M=Caption}","ip":"${N=SwisEntity;M=IP_Address}","alert":"${N=Alerting;M=AlertName}","severity":"${N=Alerting;M=Severity}","state":"triggered","message":"${N=Alerting;M=AlertMessage}"}. Add a reset action with "state":"reset".',
      sample: { alertId: 'demo-sw-77', node: 'FW-HQ01', ip: '10.10.0.254', alert: 'High response time', severity: 'Warning', state: 'triggered', message: 'Response time 480 ms' } },
    { id: 'datadog', name: 'Datadog', parse: (b) => [one(b.alert_id || b.id || b.aggreg_key, b.hostname || b.host, b.title || b.alert_title, /recovered|resolved/i.test(str(b.alert_transition)) ? 'Up' : /warn/i.test(str(b.alert_transition)) ? 'Warning' : sev(b.priority || b.alert_type, 'Down'), b.body || b.event_msg, { url: b.link })],
      setup: 'Integrations > Webhooks > New: URL <URL>, custom header {"Authorization":"Bearer <TOKEN>"}, payload {"alert_id":"$ALERT_ID","hostname":"$HOSTNAME","title":"$EVENT_TITLE","alert_transition":"$ALERT_TRANSITION","priority":"$PRIORITY","body":"$EVENT_MSG","link":"$LINK"}. Mention @webhook-moncastle in monitors.',
      sample: { alert_id: 'demo-dd-9', hostname: 'app06', title: 'Error rate above 5 %', alert_transition: 'Triggered', priority: 'normal', body: 'checkout-api 5xx rate 7.2 %' } },
    { id: 'azure', name: 'Azure Monitor', parse: (b) => {
        const e = ((b.data || {}).essentials) || {};
        const target = str((e.configurationItems || [])[0] || (e.alertTargetIDs || [])[0]).split('/').pop();
        return [one(e.alertId || e.originAlertId, target, e.alertRule || 'Azure alert', lower(e.monitorCondition) === 'resolved' ? 'Up' : sev(e.severity, 'Down'), e.description || e.monitoringService)];
      },
      setup: 'Monitor > Alerts > Action groups > Actions > Webhook, URI <URL>?token=<TOKEN>, "Enable the common alert schema" on.',
      sample: { schemaId: 'azureMonitorCommonAlertSchema', data: { essentials: { alertId: 'demo-az-1', alertRule: 'VM CPU above 85 %', severity: 'Sev2', monitorCondition: 'Fired', configurationItems: ['vm-erp-prod-01'], description: 'Percentage CPU 91' } } } },
    { id: 'cloudwatch', name: 'AWS CloudWatch (via SNS)', parse: (b) => {
        if (b.Type === 'SubscriptionConfirmation') return [];
        let m = b.Message; try { m = typeof m === 'string' ? JSON.parse(m) : m || b; } catch (e) { m = { AlarmName: b.Subject, NewStateReason: b.Message }; }
        const dims = ((m.Trigger || {}).Dimensions || []).map((d) => d.value).join(' ');
        return [one(m.AlarmArn || m.AlarmName, dims, m.AlarmName, m.NewStateValue === 'OK' ? 'Up' : m.NewStateValue === 'INSUFFICIENT_DATA' ? 'Warning' : 'Down', m.NewStateReason || m.AlarmDescription)];
      },
      setup: 'Create an SNS topic, add an HTTPS subscription to <URL>?token=<TOKEN> (MonCastle confirms it automatically), and choose that topic as the alarm action for ALARM and OK.',
      sample: { Type: 'Notification', Message: JSON.stringify({ AlarmName: 'RDS free storage low', NewStateValue: 'ALARM', NewStateReason: 'FreeStorageSpace below 10 GB', Trigger: { Dimensions: [{ name: 'DBInstanceIdentifier', value: 'erp-db' }] } }) } },
    { id: 'scom', name: 'Microsoft SCOM', parse: (b) => [one(b.alertId || b.AlertId, b.host || b.MonitoringObjectPath || b.computer, b.name || b.AlertName, /resolved|closed|255/i.test(str(b.resolutionState || b.ResolutionState)) ? 'Up' : sev(b.severity || b.Severity, 'Down'), b.description || b.AlertDescription)],
      setup: 'Create a command channel that runs: powershell -Command "Invoke-RestMethod -Method Post -Uri \'<URL>?token=<TOKEN>\' -ContentType application/json -Body (@{alertId=\'$Data[Default=\'\']/Context/DataItem/AlertId$\';host=\'$Data[Default=\'\']/Context/DataItem/ManagedEntityPath$\';name=\'$Data[Default=\'\']/Context/DataItem/AlertName$\';severity=\'$Data[Default=\'\']/Context/DataItem/Severity$\';resolutionState=\'$Data[Default=\'\']/Context/DataItem/ResolutionStateName$\'} | ConvertTo-Json)" and subscribe it to the alerts you want.',
      sample: { alertId: 'demo-scom-4', host: 'EXCH01', name: 'Exchange transport queue length', severity: 'Error', resolutionState: 'New', description: 'Queue length 1 840' } },
    { id: 'librenms', name: 'LibreNMS / Observium', parse: (b) => [one(b.alert_id || b.id, b.hostname || b.host, b.title || b.name || b.rule, str(b.state) === '0' || /recovered|ok/i.test(str(b.state)) ? 'Up' : sev(b.severity, 'Down'), b.msg || b.message)],
      setup: 'Alerts > Alert transports > Create, type API, method POST, URL <URL>?token=<TOKEN>, body {"alert_id":"{{ $alert->id }}","hostname":"{{ $alert->hostname }}","title":"{{ $alert->title }}","severity":"{{ $alert->severity }}","state":"{{ $alert->state }}","msg":"{{ $alert->msg }}"}.',
      sample: { alert_id: 'demo-lnms-3', hostname: 'ap-hq07', title: 'Device unreachable', severity: 'critical', state: '1', msg: 'ICMP down' } },
    { id: 'elastic', name: 'Elastic / Kibana, Splunk, Graylog', parse: generic,
      setup: 'Create a webhook connector (Kibana), webhook alert action (Splunk) or HTTP notification (Graylog) to <URL> with header Authorization: Bearer <TOKEN> and a JSON body in the generic format below.',
      sample: { id: 'demo-elk-5', host: 'web01', name: 'Failed logons spike', severity: 'warning', status: 'firing', message: '320 failed logons in 5 minutes' } },
    { id: 'generic', name: 'Any tool (generic JSON)', parse: generic,
      setup: 'POST JSON to <URL> with header Authorization: Bearer <TOKEN> (or ?token=<TOKEN>): {"id":"unique alert id","host":"name or IP","name":"what is wrong","severity":"critical|warning|info","status":"firing|resolved","message":"details","url":"link back"}. Send a list to post several alerts at once.',
      sample: { id: 'demo-gen-1', host: 'BKP01', name: 'Backup job failed', severity: 'critical', status: 'firing', message: 'Nightly-SQL failed: target offline' } },
  ];
  function generic(b) {
    const list = Array.isArray(b) ? b : Array.isArray(b.alerts) ? b.alerts : [b];
    return list.map((a) => one(a.id || a.key || a.alertId, a.host || a.hostname || a.device || a.ip, a.name || a.title || a.alert, /resolved|ok|closed|recovered|cleared/i.test(str(a.status || a.state)) ? 'Up' : sev(a.severity || a.priority, 'Down'), a.message || a.description || a.text, { url: a.url || a.link || '' }));
  }
  const SOURCE = Object.fromEntries(SOURCES.map((s) => [s.id, s]));
  // never throws: a body the source cannot read gives no alerts and an error text
  function normalize(id, body) {
    const s = SOURCE[id] || SOURCE.generic;
    try {
      const out = (s.parse(body || {}) || []).filter((a) => a && (a.host || a.name));
      return { alerts: out.slice(0, 500) };
    } catch (e) { return { alerts: [], error: 'Could not read the ' + s.name + ' message: ' + e.message }; }
  }
  return { SOURCES, SOURCE, normalize, sev };
});
