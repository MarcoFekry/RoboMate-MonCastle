/*
 * RoboMate MonCastle - small SVG chart kit (no dependencies).
 * Thin marks, recessive grid, crosshair + tooltip on time series, per-mark tooltips elsewhere.
 * Colors come from CSS custom properties so light and dark themes both work.
 */
(function (root) {
  'use strict';
  const NS = 'http://www.w3.org/2000/svg';
  const css = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmt = (v, d = 1) => (v == null || isNaN(v) ? '–' : Math.abs(v) >= 1000 ? Math.round(v).toLocaleString() : (Math.round(v * 10 ** d) / 10 ** d).toString());
  const SERIES = ['--s1', '--s2', '--s3', '--s4'];
  const STATUS = { OK: '--ok', Warning: '--warn', Critical: '--crit', Offline: '--offline', Unknown: '--muted', Info: '--s1' };

  let tip;
  function tooltip() {
    if (!tip) { tip = document.createElement('div'); tip.className = 'mc-tip'; tip.hidden = true; document.body.appendChild(tip); }
    return tip;
  }
  function showTip(html, x, y) {
    const t = tooltip();
    t.innerHTML = html;
    t.hidden = false;
    const r = t.getBoundingClientRect();
    let left = x + 14, top = y + 14;
    if (left + r.width > window.innerWidth - 8) left = x - r.width - 14;
    if (top + r.height > window.innerHeight - 8) top = y - r.height - 14;
    t.style.left = Math.max(8, left) + 'px';
    t.style.top = Math.max(8, top) + 'px';
  }
  function hideTip() { if (tip) tip.hidden = true; }

  function el(tag, attrs, parent) {
    const n = document.createElementNS(NS, tag);
    for (const k in attrs) if (attrs[k] != null) n.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(n);
    return n;
  }
  function niceMax(v) {
    if (v <= 0) return 1;
    const p = Math.pow(10, Math.floor(Math.log10(v)));
    const n = v / p;
    return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * p;
  }
  const timeLabel = (t, span) => {
    const d = new Date(t);
    return span > 2 * 864e5 ? d.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric' }) : d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
  };

  // ---------------------------------------------------------------- sparkline
  function sparkline(values, opt = {}) {
    const w = opt.width || 120, h = opt.height || 28;
    const vals = (values || []).filter((v) => v != null);
    const svg = el('svg', { viewBox: `0 0 ${w} ${h}`, width: '100%', height: h, class: 'mc-spark', preserveAspectRatio: 'none', role: 'img', 'aria-label': opt.label || 'trend' });
    if (vals.length < 2) return svg;
    const max = opt.max != null ? opt.max : Math.max(...vals) * 1.1 || 1;
    const min = opt.min != null ? opt.min : 0;
    const x = (i) => (i / (vals.length - 1)) * (w - 4) + 2;
    const y = (v) => h - 3 - ((v - min) / (max - min || 1)) * (h - 6);
    const d = vals.map((v, i) => (i ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(v).toFixed(1)).join(' ');
    const color = opt.color ? css(opt.color) || opt.color : css('--s1');
    el('path', { d: d + ` L${x(vals.length - 1)} ${h} L${x(0)} ${h} Z`, fill: color, opacity: 0.12, stroke: 'none' }, svg);
    el('path', { d, fill: 'none', stroke: color, 'stroke-width': 1.6, 'vector-effect': 'non-scaling-stroke', 'stroke-linejoin': 'round' }, svg);
    el('circle', { cx: x(vals.length - 1), cy: y(vals[vals.length - 1]), r: 2.4, fill: color }, svg);
    return svg;
  }

  // ---------------------------------------------------------------- time series (area / line)
  function timeSeries(container, series, opt = {}) {
    container.innerHTML = '';
    const W = Math.max(280, container.clientWidth || 600), H = opt.height || 220;
    const m = { l: 40, r: 12, t: 12, b: 26 };
    const all = series.flatMap((s) => s.points);
    if (!all.length) { container.innerHTML = '<div class="mc-empty">No samples yet. Data appears after the first collection.</div>'; return; }
    const t0 = Math.min(...all.map((p) => p.t)), t1 = Math.max(...all.map((p) => p.t));
    const dataMax = Math.max(...all.map((p) => p.v));
    // channel limits are drawn as dashed lines when they sit near the data (PRTG shows them the same way)
    const limits = (opt.limits || []).filter((l) => l.v != null && l.v >= 0 && l.v <= Math.max(dataMax, 1) * 1.6);
    const yMax = opt.yMax || niceMax(Math.max(dataMax, ...limits.map((l) => l.v)) * 1.05);
    const X = (t) => m.l + ((t - t0) / (t1 - t0 || 1)) * (W - m.l - m.r);
    const Y = (v) => H - m.b - (v / yMax) * (H - m.t - m.b);
    const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: '100%', height: H, class: 'mc-chart', role: 'img', 'aria-label': opt.label || 'time series' }, container);
    for (let i = 0; i <= 4; i++) {
      const v = (yMax / 4) * i, yy = Y(v);
      el('line', { x1: m.l, x2: W - m.r, y1: yy, y2: yy, class: i ? 'grid' : 'axis' }, svg);
      el('text', { x: m.l - 6, y: yy + 3.5, 'text-anchor': 'end', class: 'tick' }, svg).textContent = fmt(v, yMax < 8 ? 1 : 0) + (opt.unit === '%' ? '%' : '');
    }
    const ticks = Math.min(6, Math.floor((W - m.l) / 90));
    for (let i = 0; i <= ticks; i++) {
      const t = t0 + ((t1 - t0) / ticks) * i;
      el('text', { x: X(t), y: H - 8, 'text-anchor': i === 0 ? 'start' : i === ticks ? 'end' : 'middle', class: 'tick' }, svg).textContent = timeLabel(t, t1 - t0);
    }
    for (const l of limits) {
      const yy = Y(l.v);
      el('line', { x1: m.l, x2: W - m.r, y1: yy, y2: yy, class: 'limit ' + (l.kind === 'err' ? 'err' : 'warn') }, svg);
      el('text', { x: W - m.r - 2, y: yy - 3, 'text-anchor': 'end', class: 'tick limit-l' }, svg).textContent = (l.kind === 'err' ? 'error ' : 'warning ') + fmt(l.v);
    }
    if (opt.threshold) {
      const yy = Y(opt.threshold);
      el('line', { x1: m.l, x2: W - m.r, y1: yy, y2: yy, class: 'threshold' }, svg);
    }
    series.forEach((s, i) => {
      const color = css(s.color || SERIES[i % 4]);
      const pts = s.points;
      if (!pts.length) return;
      const d = pts.map((p, k) => (k ? 'L' : 'M') + X(p.t).toFixed(1) + ' ' + Y(p.v).toFixed(1)).join(' ');
      if (opt.area !== false && series.length <= 2) el('path', { d: d + ` L${X(pts[pts.length - 1].t)} ${Y(0)} L${X(pts[0].t)} ${Y(0)} Z`, fill: color, opacity: series.length === 1 ? 0.14 : 0.08 }, svg);
      el('path', { d, fill: 'none', stroke: color, 'stroke-width': 2, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }, svg);
      const last = pts[pts.length - 1];
      el('circle', { cx: X(last.t), cy: Y(last.v), r: 3.5, fill: color, stroke: css('--surface'), 'stroke-width': 2 }, svg);
    });
    const cross = el('line', { y1: m.t, y2: H - m.b, class: 'cross', visibility: 'hidden' }, svg);
    const dots = series.map((s, i) => el('circle', { r: 4, fill: css(s.color || SERIES[i % 4]), stroke: css('--surface'), 'stroke-width': 2, visibility: 'hidden' }, svg));
    const hit = el('rect', { x: m.l, y: m.t, width: W - m.l - m.r, height: H - m.t - m.b, fill: 'transparent' }, svg);
    hit.addEventListener('mousemove', (e) => {
      const r = svg.getBoundingClientRect();
      const px = ((e.clientX - r.left) / r.width) * W;
      const t = t0 + ((px - m.l) / (W - m.l - m.r)) * (t1 - t0);
      let rows = '';
      series.forEach((s, i) => {
        if (!s.points.length) return;
        let best = s.points[0];
        for (const p of s.points) if (Math.abs(p.t - t) < Math.abs(best.t - t)) best = p;
        dots[i].setAttribute('cx', X(best.t)); dots[i].setAttribute('cy', Y(best.v)); dots[i].setAttribute('visibility', 'visible');
        cross.setAttribute('x1', X(best.t)); cross.setAttribute('x2', X(best.t));
        rows += `<div class="row"><i style="background:var(${s.color || SERIES[i % 4]})"></i>${esc(s.name)}<b>${fmt(best.v)}${opt.unit || ''}</b></div>`;
      });
      cross.setAttribute('visibility', 'visible');
      showTip(`<div class="t">${new Date(t).toLocaleString(undefined, { weekday: 'short', hour: '2-digit', minute: '2-digit' })}</div>${rows}`, e.clientX, e.clientY);
    });
    hit.addEventListener('mouseleave', () => { cross.setAttribute('visibility', 'hidden'); dots.forEach((d) => d.setAttribute('visibility', 'hidden')); hideTip(); });
    if (series.length > 1 || opt.legend) {
      const lg = document.createElement('div');
      lg.className = 'mc-legend';
      lg.innerHTML = series.map((s, i) => `<span><i style="background:var(${s.color || SERIES[i % 4]})"></i>${esc(s.name)}</span>`).join('');
      container.appendChild(lg);
    }
  }

  // ---------------------------------------------------------------- columns (stacked by key)
  function columns(container, buckets, keys, opt = {}) {
    container.innerHTML = '';
    const W = Math.max(280, container.clientWidth || 600), H = opt.height || 180;
    const m = { l: 34, r: 8, t: 10, b: 24 };
    const totals = buckets.map((b) => keys.reduce((a, k) => a + (b.values[k.key] || 0), 0));
    const yMax = niceMax(Math.max(1, ...totals));
    const bw = (W - m.l - m.r) / buckets.length;
    const Y = (v) => H - m.b - (v / yMax) * (H - m.t - m.b);
    const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: '100%', height: H, class: 'mc-chart', role: 'img', 'aria-label': opt.label || 'columns' }, container);
    for (let i = 0; i <= 3; i++) {
      const v = (yMax / 3) * i;
      el('line', { x1: m.l, x2: W - m.r, y1: Y(v), y2: Y(v), class: i ? 'grid' : 'axis' }, svg);
      el('text', { x: m.l - 6, y: Y(v) + 3.5, 'text-anchor': 'end', class: 'tick' }, svg).textContent = fmt(v, 0);
    }
    const every = Math.ceil(buckets.length / Math.max(1, Math.floor((W - m.l) / 60)));
    buckets.forEach((b, i) => {
      let acc = 0;
      const x = m.l + i * bw + Math.min(2, bw * 0.15);
      const w = Math.max(1, bw - Math.min(4, bw * 0.3));
      keys.forEach((k, j) => {
        const v = b.values[k.key] || 0;
        if (!v) return;
        const y0 = Y(acc), y1 = Y(acc + v);
        acc += v;
        const top = j === keys.length - 1 || keys.slice(j + 1).every((kk) => !b.values[kk.key]);
        el('rect', { x, y: y1, width: w, height: Math.max(0, y0 - y1 - (acc > v ? 1 : 0)), rx: top ? Math.min(3, w / 2) : 0, fill: css(k.color) }, svg);
      });
      if (i % every === 0) el('text', { x: x + w / 2, y: H - 8, 'text-anchor': 'middle', class: 'tick' }, svg).textContent = b.label;
      const hit = el('rect', { x: m.l + i * bw, y: m.t, width: bw, height: H - m.t - m.b, fill: 'transparent' }, svg);
      hit.addEventListener('mousemove', (e) => showTip(`<div class="t">${esc(b.title || b.label)}</div>` + keys.filter((k) => b.values[k.key]).map((k) => `<div class="row"><i style="background:var(${k.color})"></i>${esc(k.name)}<b>${fmt(b.values[k.key], 0)}</b></div>`).join('') + (totals[i] ? '' : '<div class="row">No events</div>'), e.clientX, e.clientY));
      hit.addEventListener('mouseleave', hideTip);
      if (opt.onClick) { hit.style.cursor = 'pointer'; hit.addEventListener('click', () => opt.onClick(b)); }
    });
    const lg = document.createElement('div');
    lg.className = 'mc-legend';
    lg.innerHTML = keys.map((k) => `<span><i style="background:var(${k.color})"></i>${esc(k.name)}</span>`).join('');
    container.appendChild(lg);
  }

  // ---------------------------------------------------------------- horizontal bar list (HTML)
  function barList(items, opt = {}) {
    const max = opt.max || Math.max(1, ...items.map((i) => i.value || 0));
    return `<div class="mc-bars${opt.compact ? ' compact' : ''}">` + items.map((i) => {
      const pct = Math.max(0, Math.min(100, ((i.value || 0) / max) * 100));
      const color = i.status ? `var(${STATUS[i.status] || '--s1'})` : `var(${i.color || '--s1'})`;
      const attr = i.href ? ` data-href="${esc(i.href)}" tabindex="0" role="button"` : '';
      return `<div class="bar"${attr}><div class="lbl" title="${esc(i.label)}">${esc(i.label)}${i.sub ? `<small>${esc(i.sub)}</small>` : ''}</div><div class="track"><div class="fill" style="width:${pct}%;background:${color}"></div></div><div class="val">${esc(i.text != null ? i.text : fmt(i.value) + (opt.unit || ''))}</div></div>`;
    }).join('') + '</div>';
  }

  // ---------------------------------------------------------------- donut
  function donut(container, items, opt = {}) {
    container.innerHTML = '';
    const size = opt.size || 132, r = size / 2 - 8, sw = opt.stroke || 14;
    const total = items.reduce((a, i) => a + i.value, 0) || 1;
    const wrap = document.createElement('div');
    wrap.className = 'mc-donut';
    const svg = el('svg', { viewBox: `0 0 ${size} ${size}`, width: size, height: size, role: 'img', 'aria-label': opt.label || 'distribution' }, wrap);
    const C = 2 * Math.PI * r;
    let off = 0;
    el('circle', { cx: size / 2, cy: size / 2, r, fill: 'none', stroke: css('--grid'), 'stroke-width': sw }, svg);
    items.forEach((it) => {
      const len = (it.value / total) * C;
      if (!len) return;
      const c = el('circle', { cx: size / 2, cy: size / 2, r, fill: 'none', stroke: css(it.color), 'stroke-width': sw, 'stroke-dasharray': `${Math.max(0, len - 2)} ${C}`, 'stroke-dashoffset': -off, transform: `rotate(-90 ${size / 2} ${size / 2})` }, svg);
      c.addEventListener('mousemove', (e) => showTip(`<div class="row"><i style="background:var(${it.color})"></i>${esc(it.label)}<b>${fmt(it.value, 0)} (${Math.round((it.value / total) * 100)}%)</b></div>`, e.clientX, e.clientY));
      c.addEventListener('mouseleave', hideTip);
      off += len;
    });
    const center = el('text', { x: size / 2, y: size / 2 + 2, 'text-anchor': 'middle', class: 'donut-v' }, svg);
    center.textContent = opt.center != null ? opt.center : fmt(total, 0);
    if (opt.centerLabel) el('text', { x: size / 2, y: size / 2 + 18, 'text-anchor': 'middle', class: 'donut-l' }, svg).textContent = opt.centerLabel;
    const lg = document.createElement('div');
    lg.className = 'mc-legend vertical';
    lg.innerHTML = items.map((i) => `<span><i style="background:var(${i.color})"></i>${esc(i.label)}<b>${fmt(i.value, 0)}</b></span>`).join('');
    wrap.appendChild(lg);
    container.appendChild(wrap);
  }

  // ---------------------------------------------------------------- status stack (one row)
  function statusStack(counts, opt = {}) {
    const order = ['Critical', 'Offline', 'Warning', 'OK', 'Unknown'];
    const total = order.reduce((a, k) => a + (counts[k] || 0), 0) || 1;
    return `<div class="mc-stack${opt.thin ? ' thin' : ''}" role="img" aria-label="${order.filter((k) => counts[k]).map((k) => counts[k] + ' ' + k).join(', ')}">` +
      order.filter((k) => counts[k]).map((k) => `<span style="flex:${counts[k]};background:var(${STATUS[k]})" title="${counts[k]} ${k}"></span>`).join('') + '</div>' +
      (opt.legend ? '<div class="mc-legend">' + order.filter((k) => counts[k]).map((k) => `<span><i style="background:var(${STATUS[k]})"></i>${k}<b>${counts[k]}</b></span>`).join('') + '</div>' : '') + (total ? '' : '');
  }

  // ---------------------------------------------------------------- heatmap
  function heatmap(container, rows, cols, opt = {}) {
    container.innerHTML = '';
    const labelW = opt.labelWidth || 78;
    const W = Math.max(320, container.clientWidth || 700);
    const cell = Math.max(4, (W - labelW - 8) / cols.length);
    const rh = opt.rowHeight || 16;
    const H = rows.length * rh + 24;
    const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: '100%', height: H, class: 'mc-chart', role: 'img', 'aria-label': opt.label || 'heatmap' }, container);
    const lo = hex(css('--seq-lo')), hi = hex(css('--seq-hi'));
    const max = opt.max || 100;
    rows.forEach((r, i) => {
      const y = i * rh;
      const t = el('text', { x: labelW - 6, y: y + rh / 2 + 4, 'text-anchor': 'end', class: 'tick lbl' }, svg);
      t.textContent = r.label;
      if (opt.onRow) { t.style.cursor = 'pointer'; t.addEventListener('click', () => opt.onRow(r)); }
      r.values.forEach((v, j) => {
        if (v == null) return;
        const k = Math.max(0, Math.min(1, v / max));
        const rect = el('rect', { x: labelW + j * cell, y: y + 1, width: Math.max(1, cell - 1), height: rh - 2, rx: 2, fill: mix(lo, hi, Math.pow(k, 0.85)) }, svg);
        rect.addEventListener('mousemove', (e) => showTip(`<div class="t">${esc(r.label)} · ${esc(cols[j])}</div><div class="row">${esc(opt.metric || 'Value')}<b>${fmt(v)}${opt.unit || ''}</b></div>`, e.clientX, e.clientY));
        rect.addEventListener('mouseleave', hideTip);
      });
    });
    const every = Math.ceil(cols.length / Math.max(1, Math.floor((W - labelW) / 56)));
    cols.forEach((c, j) => { if (j % every === 0) el('text', { x: labelW + j * cell + cell / 2, y: H - 6, 'text-anchor': 'middle', class: 'tick' }, svg).textContent = c; });
    const key = document.createElement('div');
    key.className = 'mc-scale';
    key.innerHTML = `<span>0${opt.unit || ''}</span><i style="background:linear-gradient(90deg, var(--seq-lo), var(--seq-hi))"></i><span>${max}${opt.unit || ''}</span>`;
    container.appendChild(key);
  }
  function hex(c) {
    c = (c || '#888888').replace('#', '');
    if (c.length === 3) c = c.split('').map((x) => x + x).join('');
    return [parseInt(c.slice(0, 2), 16), parseInt(c.slice(2, 4), 16), parseInt(c.slice(4, 6), 16)];
  }
  function mix(a, b, k) { return 'rgb(' + a.map((v, i) => Math.round(v + (b[i] - v) * k)).join(',') + ')'; }

  // ---------------------------------------------------------------- gauge (half ring)
  function gauge(value, opt = {}) {
    const v = Math.max(0, Math.min(100, value || 0));
    // invert: higher is better (scores); below crit is red, below warn amber
    const st = opt.invert ? (v < (opt.crit || 70) ? '--crit' : v < (opt.warn || 90) ? '--warn' : '--ok') : v >= (opt.crit || 90) ? '--crit' : v >= (opt.warn || 75) ? '--warn' : '--ok';
    const r = 34, C = Math.PI * r;
    return `<div class="mc-gauge"><svg viewBox="0 0 84 48" width="84" height="48" role="img" aria-label="${esc(opt.label || '')} ${fmt(v)}%"><path d="M8 44 A34 34 0 0 1 76 44" fill="none" stroke="var(--grid)" stroke-width="7" stroke-linecap="round"/><path d="M8 44 A34 34 0 0 1 76 44" fill="none" stroke="var(${st})" stroke-width="7" stroke-linecap="round" stroke-dasharray="${(v / 100) * C} ${C}"/></svg><b>${fmt(v, 0)}%</b><small>${esc(opt.label || '')}</small></div>`;
  }

  root.MCCharts = { sparkline, timeSeries, columns, barList, donut, statusStack, heatmap, gauge, showTip, hideTip, fmt, esc, STATUS, SERIES };
})(typeof self !== 'undefined' ? self : this);
