// Sets the administrator override password (the only way into the console without a licence).
// Prompts without echo, or reads MC_OVERRIDE_PASSWORD. Only a salted scrypt hash is written to data/secrets/override.json.
const cfg = require('../server/lib/config').load();
const ovr = require('../server/lib/override').create(cfg);
function ask(q) {
  return new Promise((resolve) => {
    const stdin = process.stdin;
    process.stdout.write(q);
    if (!stdin.isTTY) { let d = ''; stdin.on('data', (c) => (d += c)); stdin.on('end', () => resolve(d.split(/\r?\n/)[0])); return; }
    stdin.setRawMode(true); stdin.resume(); let pw = '';
    stdin.on('data', function onData(ch) {
      ch = ch.toString('utf8');
      for (const c of ch) {
        if (c === '\r' || c === '\n') { stdin.setRawMode(false); stdin.pause(); stdin.removeListener('data', onData); process.stdout.write('\n'); return resolve(pw); }
        if (c === '\u0003') process.exit(1);
        if (c === '\u007f' || c === '\b') pw = pw.slice(0, -1); else pw += c;
      }
    });
  });
}
(async () => {
  let pw = process.env.MC_OVERRIDE_PASSWORD;
  if (!pw) {
    pw = await ask('New override password: ');
    if (process.stdin.isTTY) { const again = await ask('Repeat: '); if (again !== pw) { console.error('Passwords do not match.'); process.exit(1); } }
  }
  ovr.set(pw);
  console.log('Override password set (hash stored in ' + cfg.dataDir + '/secrets/override.json).');
})().catch((e) => { console.error(e.message); process.exit(1); });
