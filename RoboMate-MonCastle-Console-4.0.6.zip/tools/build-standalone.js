// Builds dist/moncastle-standalone.html: the whole console in one file (CSS, JS, images inlined), running on
// the in-browser demo backend. Used for the hosted test page and for quick demos without the server.
const fs = require('fs'), path = require('path');
const pub = path.join(__dirname, '..', 'public');
const read = (p) => fs.readFileSync(path.join(pub, p), 'utf8');
const dataUri = (p, type) => 'data:' + type + ';base64,' + fs.readFileSync(path.join(pub, p)).toString('base64');
const logo = dataUri('img/moncastle-logo.svg', 'image/svg+xml'), emblem = dataUri('img/robomate-emblem.png', 'image/png');
const fix = (s) => s.split('img/moncastle-logo.svg').join(logo).split('img/robomate-emblem.png').join(emblem);
// same scripts, same order as index.html
const js = [...read('index.html').matchAll(/<script src="js\/([\w.-]+)"><\/script>/g)].map((m) => m[1])
  .map((f) => `<script>\n/* ${f} */\n${fix(read('js/' + f)).replace(/<\/script/gi, '<\\/script')}\n</script>`).join('\n');
const favicon = dataUri('img/moncastle-icon.svg', 'image/svg+xml');
const html = `<title>RoboMate MonCastle</title>
<link rel="icon" href="${favicon}" type="image/svg+xml">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans:wght@400;500;600&family=Sora:wght@600;700&display=swap">
<style>\n${read('css/app.css')}\n</style>
<div id="app"><div style="display:grid;place-items:center;height:100vh;color:#7C90A8;font:14px system-ui">Starting MonCastle…</div></div>
${js}
<script>if (document.readyState !== 'loading') window.dispatchEvent(new Event('DOMContentLoaded'));</script>
`;
fs.mkdirSync(path.join(__dirname, '..', 'dist'), { recursive: true });
const out = path.join(__dirname, '..', 'dist', 'moncastle-standalone.html');
fs.writeFileSync(out, html);
console.log('wrote', out, Math.round(html.length / 1024) + ' KB');
