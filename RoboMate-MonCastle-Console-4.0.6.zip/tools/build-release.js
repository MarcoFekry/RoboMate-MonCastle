'use strict';
// Builds the MonCastle user package: everything a site needs to run MonCastle, without the development sources.
//
//   node tools/build-release.js [--out dist/package] [--launcher <Visual Studio publish folder>] [--setup <MonCastle-Setup.exe>] [--node auto|<node.exe>] [--zip]
//
// Visual Studio runs this after Build > Publish (profile "UserPackage", see host/MonCastle.Launcher.csproj).
//
// The package holds:
//   RoboMate.MonCastle.Launcher.exe   the launcher (self-contained .NET publish, when --launcher is given)
//   MonCastle-Setup.exe               the setup app: prerequisites, service, firewall, licence (when --setup is given)
//   runtime\node.exe                  the Node.js runtime (when --node is given), so the server needs no Node install
//   app.mcpak                         the console (server/ and public/), gzip + AES-256-GCM, integrity-checked
//   moncastle.js                      a small loader that decrypts app.mcpak in memory and starts the console
//   engine\, launcher\                the PowerShell wrappers that Windows runs directly (scheduled tasks, service)
//   config\moncastle.config.example.json, version.json, README.txt
// Nothing from app.mcpak is written to disk: the server code and the web pages are served from memory.
//
// Honest limits: the package key has to travel with the package (it is split inside moncastle.js), so this stops
// casual reading, copying and editing of the application files and makes any change to them fail the integrity
// check at start; it does not stop a determined person with the files and a debugger. The data folder is encrypted
// separately with a per-installation key (server/lib/sealed.js).
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const zip = require('../server/lib/zip');

const ROOT = path.resolve(__dirname, '..');
const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i < 0 ? d : process.argv[i + 1] && !process.argv[i + 1].startsWith('--') ? process.argv[i + 1] : true; };
const OUT = path.resolve(ROOT, arg('out', 'dist/package'));
const version = JSON.parse(fs.readFileSync(path.join(ROOT, 'version.json'), 'utf8')).version;
const NAME = 'RoboMate-MonCastle-' + version;
const PKG = path.join(OUT, NAME);

function walk(dir, filter = () => true) {
  const out = [];
  if (!fs.existsSync(dir)) return out;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...walk(p, filter)); else if (filter(p)) out.push(p);
  }
  return out;
}
const rel = (p) => path.relative(ROOT, p).split(path.sep).join('/');
const copy = (from, to) => { fs.mkdirSync(path.dirname(to), { recursive: true }); fs.copyFileSync(from, to); };

// ---------------------------------------------------------------- 1. the application archive
const files = {};
for (const f of walk(path.join(ROOT, 'server'), (p) => p.endsWith('.js') || p.endsWith('.ps1'))) files[rel(f)] = fs.readFileSync(f).toString('base64');
for (const f of walk(path.join(ROOT, 'public'))) files[rel(f)] = fs.readFileSync(f).toString('base64');
for (const f of ['tools/set-override-password.js', 'tools/set-licence.js', 'version.json', 'package.json']) files[f] = fs.readFileSync(path.join(ROOT, f)).toString('base64');
const plain = zlib.gzipSync(Buffer.from(JSON.stringify({ v: 1, version, built: new Date().toISOString(), files })), { level: 9 });
const key = crypto.randomBytes(32), iv = crypto.randomBytes(12);
const c = crypto.createCipheriv('aes-256-gcm', key, iv);
const ct = Buffer.concat([c.update(plain), c.final()]);
const pak = Buffer.concat([Buffer.from('MCPK1'), iv, c.getAuthTag(), ct]);

fs.rmSync(PKG, { recursive: true, force: true });
fs.mkdirSync(PKG, { recursive: true });
fs.writeFileSync(path.join(PKG, 'app.mcpak'), pak);

// ---------------------------------------------------------------- 2. the loader, with the key split in two
const mask = crypto.randomBytes(32), half = Buffer.from(key.map((b, i) => b ^ mask[i]));
const loader = fs.readFileSync(path.join(__dirname, 'loader.template.js'), 'utf8')
  .replace('__K1__', half.toString('base64')).replace('__K2__', mask.toString('base64')).replace('__SHA__', crypto.createHash('sha256').update(pak).digest('hex'));
fs.writeFileSync(path.join(PKG, 'moncastle.js'), loader);

// ---------------------------------------------------------------- 3. files Windows runs directly
for (const f of walk(path.join(ROOT, 'engine'))) copy(f, path.join(PKG, rel(f)));
for (const f of walk(path.join(ROOT, 'launcher'))) copy(f, path.join(PKG, rel(f)));
copy(path.join(ROOT, 'config', 'moncastle.config.example.json'), path.join(PKG, 'config', 'moncastle.config.example.json'));
copy(path.join(ROOT, 'version.json'), path.join(PKG, 'version.json'));
copy(path.join(ROOT, 'public', 'img', 'moncastle.ico'), path.join(PKG, 'moncastle.ico'));
fs.writeFileSync(path.join(PKG, 'README.txt'), [
  'RoboMate MonCastle ' + version,
  '',
  'Start:     RoboMate.MonCastle.Launcher.exe (or launcher\\Start-MonCastle.cmd)',
  'Install:   MonCastle-Setup.exe checks and installs the prerequisites (PowerShell 7, RSAT modules, firewall rule, service).',
  'Service:   launcher\\Install-MonCastleService.ps1 -Account CORP\\svc-moncastle$',
  'Override:  launcher\\Set-MonCastleAdminPassword.ps1',
  'Join:      launcher\\Join-MonCastleServer.ps1 (remote MonCastle server)',
  '',
  'The application is in app.mcpak (encrypted, integrity-checked) and runs from memory. Your data is kept',
  'encrypted in the data folder. Open the console at http://robomatemoncastle:5050 after starting.',
  '',
].join('\r\n'));

// ---------------------------------------------------------------- 4. launcher and Node.js runtime
const launcher = arg('launcher', null);
if (launcher && launcher !== true) {
  const dir = path.resolve(launcher);
  for (const f of walk(dir, (p) => !/\.pdb$/i.test(p))) copy(f, path.join(PKG, path.relative(dir, f)));
  console.log('launcher from ' + dir);
}
const setup = arg('setup', null);
if (setup && setup !== true) {
  if (fs.existsSync(setup)) { copy(path.resolve(setup), path.join(PKG, 'MonCastle-Setup.exe')); console.log('setup app from ' + setup); }
  else console.warn('setup app not found: ' + setup);
}
const node = arg('node', null);
if (node) {
  const exe = node === true || node === 'auto' ? process.execPath : path.resolve(node);
  if (/node(\.exe)?$/i.test(exe) && fs.existsSync(exe)) { copy(exe, path.join(PKG, 'runtime', process.platform === 'win32' || /\.exe$/i.test(exe) ? 'node.exe' : 'node')); console.log('Node.js runtime from ' + exe); }
}

// ---------------------------------------------------------------- 5. zip
let zipped = null;
if (arg('zip', false)) {
  zipped = path.join(OUT, NAME + '.zip');
  fs.writeFileSync(zipped, zip.create(zip.collect(PKG, []).map((e) => Object.assign(e, { name: NAME + '/' + e.name }))));
}
const size = (p) => (fs.statSync(p).size / 1024).toFixed(0) + ' KB';
console.log(`wrote ${PKG} (app.mcpak ${size(path.join(PKG, 'app.mcpak'))}, ${Object.keys(files).length} files packed)` + (zipped ? `\nwrote ${zipped} (${size(zipped)})` : ''));
