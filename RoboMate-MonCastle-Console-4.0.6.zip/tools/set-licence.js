// Registers the MonCastle licence key from the setup app or a script. Reads MC_LICENSE_KEY (320RMC...) from the
// environment so the key is never on a command line; checks it against the licence registry before it is stored
// in the encrypted store, exactly like Settings > Licence in the console.
const path = require('path');
const cfg = require('../server/lib/config').load();
const store = require('../server/lib/secure-store').create(path.join(cfg.dataDir, 'secrets'));
let license = null;
const gh = require('../server/lib/github').create(cfg, () => license.token());
license = require('../server/lib/license').create(cfg, store, gh, () => {});
(async () => {
  const key = String(process.env.MC_LICENSE_KEY || '').trim();
  delete process.env.MC_LICENSE_KEY;
  if (!key) { console.error('Set MC_LICENSE_KEY to the 320RMC licence key.'); process.exit(2); }
  const st = await license.set(key);
  console.log('Licence registered: ' + st.state + (st.holder ? ' for ' + st.holder : '') + (st.expires ? ', expires ' + String(st.expires).slice(0, 10) : '') + '.');
})().catch((e) => { console.error('Licence not registered: ' + e.message); process.exit(1); });
