// "Monitoring engines" tab: the engine list with per-engine and all-engine controls
// (enable, disable, start, stop, restart, install, remove).
using System.Diagnostics;
using MonCastle.Ui;

namespace MonCastle.Launcher;

internal sealed class EnginesPanel : UserControl
{
    // colors come from the shared theme, so the panel follows light and dark mode (the launcher rebuilds it on a switch)
    static Color Page => Theme.Page;
    static Color Ink => Theme.Ink;
    static Color Muted => Theme.Muted;
    static Color Line => Theme.Line;
    static Color Blue => Theme.Accent;
    static Color Green => Theme.Good;
    static Color Amber => Theme.Warn;
    static Color Red => Theme.Bad;
    static Color Gray => Theme.Idle;

    readonly DataGridView grid = new();
    readonly Label summary = new(), message = new();
    readonly Panel adminBar = new();
    readonly List<Button> changeButtons = new();
    readonly System.Windows.Forms.Timer poll = new() { Interval = 15000 };
    List<EngineRow> rows = new();
    Font? bold;
    bool busy, loaded;

    public EnginesPanel()
    {
        Dock = DockStyle.Fill;
        BackColor = Page;
        Padding = new Padding(18, 14, 18, 14);

        summary.AutoSize = true;
        summary.Font = new Font("Segoe UI Semibold", 11f);
        summary.ForeColor = Ink;
        summary.Dock = DockStyle.Top;
        summary.Padding = new Padding(0, 0, 0, 6);
        summary.Text = "Monitoring engines";

        adminBar.Dock = DockStyle.Top;
        adminBar.Height = 44;
        adminBar.BackColor = Theme.Dark ? Color.FromArgb(0x3A, 0x2E, 0x10) : Color.FromArgb(0xFF, 0xF4, 0xD6);
        adminBar.Padding = new Padding(10, 8, 10, 8);
        var adminText = new Label { Text = "Changing engines needs administrator rights. You can look, but not change.", AutoSize = true, ForeColor = Ink, Dock = DockStyle.Left, Padding = new Padding(0, 5, 0, 0) };
        var elevate = Button("Restart as administrator", true, (_, _) => RestartElevated());
        changeButtons.Remove(elevate);
        elevate.Dock = DockStyle.Right;
        adminBar.Controls.Add(adminText);
        adminBar.Controls.Add(elevate);
        adminBar.Visible = !Engines.IsAdmin;

        var selected = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, BackColor = Page, Margin = new Padding(0), Padding = new Padding(0, 8, 0, 0) };
        selected.Controls.Add(Caption("Selected engines"));
        selected.Controls.Add(Button("Start", true, async (_, _) => await ForSelected("Start", "started")));
        selected.Controls.Add(Button("Stop", false, async (_, _) => await ForSelected("Stop", "stopped")));
        selected.Controls.Add(Button("Restart", false, async (_, _) => await ForSelected("Restart", "restarted")));
        selected.Controls.Add(Button("Enable", false, async (_, _) => await ForSelected("Enable", "enabled")));
        selected.Controls.Add(Button("Disable", false, async (_, _) => await ForSelected("Disable", "disabled")));
        selected.Controls.Add(Button("Interval…", false, async (_, _) => await SetInterval()));
        var all = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, BackColor = Page, Margin = new Padding(0) };
        all.Controls.Add(Caption("All engines"));
        all.Controls.Add(Button("Enable all", false, async (_, _) => await ForAll("Enable", "Enable all engines? Every engine starts collecting again on its own interval.")));
        all.Controls.Add(Button("Disable all", false, async (_, _) => await ForAll("Disable", "Disable all engines? Monitoring stops for every engine until you enable them again. Running engines are stopped.")));
        all.Controls.Add(Button("Stop all", false, async (_, _) => await ForAll("Stop", "Stop all running engines? They stay enabled and run again at their next time.")));
        all.Controls.Add(Button("Restart all", false, async (_, _) => await ForAll("Restart", "Restart all enabled engines now? This puts load on the monitored servers for a few minutes.")));
        all.Controls.Add(Button("Install engines…", false, async (_, _) => await Install()));
        all.Controls.Add(Button("Remove engines", false, async (_, _) => await ForAll("Uninstall", "Remove the engine scheduled tasks? Monitoring then runs only while the console server is running.")));
        var refresh = Button("Refresh", false, async (_, _) => await LoadAsync());
        changeButtons.Remove(refresh);
        all.Controls.Add(refresh);

        grid.Dock = DockStyle.Fill;
        grid.BackgroundColor = Theme.Surface;
        grid.DefaultCellStyle.BackColor = Theme.Surface;
        grid.DefaultCellStyle.ForeColor = Ink;
        grid.BorderStyle = BorderStyle.None;
        grid.ReadOnly = true;
        grid.AllowUserToAddRows = grid.AllowUserToDeleteRows = grid.AllowUserToResizeRows = false;
        grid.RowHeadersVisible = false;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.MultiSelect = true;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI Semibold", 9f);
        grid.ColumnHeadersDefaultCellStyle.BackColor = Page;
        grid.ColumnHeadersDefaultCellStyle.ForeColor = Muted;
        grid.EnableHeadersVisualStyles = false;
        grid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
        grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
        grid.GridColor = Line;
        grid.DefaultCellStyle.SelectionBackColor = Theme.Dark ? Color.FromArgb(0x1D, 0x3A, 0x5A) : Color.FromArgb(0xDC, 0xEC, 0xFA);
        grid.DefaultCellStyle.SelectionForeColor = Ink;
        grid.RowTemplate.Height = 28;
        foreach (var (name, header, weight) in new[] { ("title", "Engine", 22), ("id", "ID", 14), ("category", "Category", 10), ("state", "State", 10), ("every", "Every", 6),
                     ("last", "Last run", 11), ("result", "Last result", 8), ("next", "Next run", 11), ("runAs", "Runs as", 8), ("msg", "Message", 20) })
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = name, HeaderText = header, FillWeight = weight, SortMode = DataGridViewColumnSortMode.Automatic });
        grid.CellFormatting += FormatCell;

        message.Dock = DockStyle.Bottom;
        message.AutoSize = false;
        message.Height = 26;
        message.ForeColor = Muted;
        message.TextAlign = ContentAlignment.MiddleLeft;

        var gridFrame = new Panel { Dock = DockStyle.Fill, Padding = new Padding(0, 8, 0, 0), BackColor = Page };
        gridFrame.Controls.Add(grid);
        Controls.Add(gridFrame);
        Controls.Add(message);
        Controls.Add(all);
        Controls.Add(selected);
        Controls.Add(adminBar);
        Controls.Add(summary);

        poll.Tick += async (_, _) => { if (Visible && !busy) await LoadAsync(true); };
        VisibleChanged += async (_, _) => { poll.Enabled = Visible; if (Visible && !loaded) await LoadAsync(); };
        foreach (var b in changeButtons) b.Enabled = Engines.IsAdmin;
    }

    static Label Caption(string text) => new()
    {
        Text = text, AutoSize = true, ForeColor = Muted, Font = new Font("Segoe UI Semibold", 9f), Margin = new Padding(0, 8, 8, 0), MinimumSize = new Size(110, 0),
    };

    Button Button(string text, bool primary, EventHandler click)
    {
        var b = new ModernButton(text, primary ? ButtonKind.Primary : ButtonKind.Secondary) { Height = 32, Margin = new Padding(0, 0, 6, 6) };
        b.Click += click;
        changeButtons.Add(b);
        return b;
    }

    // ------------------------------------------------------------------ data
    public async Task LoadAsync(bool quiet = false)
    {
        if (busy) return;
        busy = true;
        if (!quiet) Say("Reading the engines…");
        var r = await Engines.RunAsync("List");
        busy = false;
        loaded = true;
        if (!r.Ok) { Say(r.Error ?? "Could not read the engines.", true); return; }
        ShowRows(r);
        if (!quiet) Say("Updated " + DateTime.Now.ToString("T") + ".");
    }

    void ShowRows(EngineAnswer r)
    {
        rows = r.Engines ?? new();
        var keep = SelectedIds();
        grid.Rows.Clear();
        foreach (var e in rows)
        {
            var i = grid.Rows.Add(e.Title ?? e.Id, e.Id, e.Category, StateText(e), e.Installed ? e.Every : e.Schedule,
                Ago(e.LastRun), e.LastStatus ?? "", e.Installed && e.State != "Disabled" ? Local(e.NextRun) : "", e.Installed ? e.RunAs : "", e.Message ?? "");
            grid.Rows[i].Tag = e;
            grid.Rows[i].Selected = keep.Contains(e.Id);
        }
        int installed = rows.Count(e => e.Installed), disabled = rows.Count(e => e.Installed && e.State == "Disabled"),
            running = rows.Count(e => e.State is "Running" or "Queued"), failed = rows.Count(e => e.LastStatus == "error" && e.State != "Disabled");
        summary.Text = installed == 0
            ? $"{rows.Count} engines, none installed as scheduled tasks yet. Use Install engines so monitoring runs even when the console is closed."
            : $"{rows.Count} engines   ·   {installed - disabled} enabled   ·   {running} running   ·   {disabled} disabled   ·   {failed} failed      {r.TaskPath}";
    }

    static string StateText(EngineRow e) => !e.Installed ? "Not installed" : e.State == "Queued" ? "Running" : e.State ?? "";
    static string Local(DateTime? t) => t.HasValue ? t.Value.ToLocalTime().ToString("g") : "";
    static string Ago(DateTime? t)
    {
        if (!t.HasValue) return "";
        var m = (DateTime.UtcNow - t.Value.ToUniversalTime()).TotalMinutes;
        return m < 1 ? "just now" : m < 60 ? $"{(int)m} min ago" : m < 1440 ? $"{(int)(m / 60)} h ago" : t.Value.ToLocalTime().ToString("g");
    }

    void FormatCell(object? sender, DataGridViewCellFormattingEventArgs e)
    {
        if (e.RowIndex < 0 || e.CellStyle == null) return;
        var col = grid.Columns[e.ColumnIndex].Name;
        var v = e.Value as string ?? "";
        if (col == "state") e.CellStyle.ForeColor = v switch { "Ready" => Green, "Running" => Blue, "Disabled" => Gray, _ => Muted };
        if (col == "result") e.CellStyle.ForeColor = v switch { "ok" => Green, "warning" => Amber, "error" => Red, _ => Muted };
        if (col is "id" or "msg" or "runAs") e.CellStyle.ForeColor = Muted;
        if (col is "state" or "result") e.CellStyle.Font = bold ??= new Font(grid.Font, FontStyle.Bold);
    }

    HashSet<string> SelectedIds() => grid.SelectedRows.Cast<DataGridViewRow>().Select(r => (r.Tag as EngineRow)?.Id).Where(x => x != null).ToHashSet()!;

    void Say(string text, bool error = false)
    {
        message.Text = text;
        message.ForeColor = error ? Red : Muted;
        Server.WriteLog("engines: " + text);
    }

    // ------------------------------------------------------------------ actions
    async Task<bool> Run(string action, string id, string? every = null, string? user = null, string? password = null)
    {
        busy = true;
        UseWaitCursor = true;
        foreach (var b in changeButtons) b.Enabled = false;
        try
        {
            var r = await Engines.RunAsync(action, id, every, user, password);
            if (!r.Ok) { Say(r.Error ?? action + " failed.", true); return false; }
            ShowRows(r);
            return true;
        }
        finally
        {
            busy = false;
            UseWaitCursor = false;
            foreach (var b in changeButtons) b.Enabled = Engines.IsAdmin;
        }
    }

    async Task ForSelected(string action, string done)
    {
        var ids = SelectedIds().ToList();
        if (ids.Count == 0) { Say("Select one or more engines in the list first.", true); return; }
        if (action == "Disable" && Ask($"Disable {ids.Count} engine(s)? They stop collecting until enabled again.") != DialogResult.Yes) return;
        foreach (var id in ids) if (!await Run(action, id)) return;
        Say($"{ids.Count} engine(s) {done}.");
    }

    async Task ForAll(string action, string question)
    {
        if (Ask(question) != DialogResult.Yes) return;
        if (await Run(action, "All")) Say(action == "Uninstall" ? "Engine tasks removed." : $"{action}: done for all engines.");
    }

    async Task SetInterval()
    {
        var ids = SelectedIds().ToList();
        if (ids.Count == 0) { Say("Select one or more engines in the list first.", true); return; }
        var current = rows.FirstOrDefault(r => r.Id == ids[0])?.Every ?? "1h";
        var every = Prompt("Interval", "Run the selected engine(s) every (for example 5m, 1h or 24h):", current);
        if (string.IsNullOrWhiteSpace(every)) return;
        foreach (var id in ids) if (!await Run("SetInterval", id, every.Trim())) return;
        Say($"{ids.Count} engine(s) now run every {every.Trim()}.");
    }

    async Task Install()
    {
        using var dlg = new InstallDialog();
        if (dlg.ShowDialog(this) != DialogResult.OK) return;
        Say("Installing the engines…");
        if (await Run("Install", "All", null, dlg.Account, dlg.Password))
            Say("Engines installed as scheduled tasks" + (dlg.Account != null ? " running as " + dlg.Account : " running as SYSTEM") + ".");
    }

    DialogResult Ask(string question) => MessageBox.Show(this, question, "Monitoring engines", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

    string? Prompt(string title, string text, string value)
    {
        using var f = new Form { Text = title, FormBorderStyle = FormBorderStyle.FixedDialog, StartPosition = FormStartPosition.CenterParent, MinimizeBox = false, MaximizeBox = false, ClientSize = new Size(380, 130), Font = Font };
        var l = new Label { Text = text, Left = 14, Top = 14, Width = 350, Height = 36 };
        var t = new TextBox { Text = value, Left = 14, Top = 54, Width = 120 };
        var ok = new Button { Text = "Save", DialogResult = DialogResult.OK, Left = 196, Top = 90, Width = 80 };
        var cancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, Left = 284, Top = 90, Width = 80 };
        f.Controls.AddRange(new Control[] { l, t, ok, cancel });
        f.AcceptButton = ok;
        f.CancelButton = cancel;
        return f.ShowDialog(this) == DialogResult.OK ? t.Text : null;
    }

    void RestartElevated()
    {
        if (MessageBox.Show(this, "The launcher restarts as administrator. The console server is stopped and started again.", "Monitoring engines", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) != DialogResult.OK) return;
        try
        {
            Process.Start(new ProcessStartInfo(Application.ExecutablePath, "--engines") { UseShellExecute = true, Verb = "runas" });
            FindForm()?.Close();
        }
        catch (System.ComponentModel.Win32Exception) { Say("Administrator approval was cancelled.", true); }
    }
}

// Who the engine tasks run as: SYSTEM, or an account with its password (handed to PowerShell in an environment variable, never stored here).
internal sealed class InstallDialog : Form
{
    readonly RadioButton system = new() { Text = "SYSTEM (recommended for a domain member console)", Checked = true, AutoSize = true };
    readonly RadioButton account = new() { Text = "This account:", AutoSize = true };
    readonly TextBox user = new() { Width = 260, Text = Environment.UserDomainName + "\\" + Environment.UserName };
    readonly TextBox pass = new() { Width = 260, UseSystemPasswordChar = true };

    public string? Account => account.Checked ? user.Text.Trim() : null;
    public string? Password => account.Checked ? pass.Text : null;

    public InstallDialog()
    {
        Text = "Install monitoring engines";
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        MinimizeBox = MaximizeBox = false;
        Font = new Font("Segoe UI", 9.75f);
        AutoSize = true;
        AutoSizeMode = AutoSizeMode.GrowAndShrink;
        Padding = new Padding(16);
        var layout = new TableLayoutPanel { AutoSize = true, ColumnCount = 2, Dock = DockStyle.Fill };
        var intro = new Label
        {
            AutoSize = true, MaximumSize = new Size(470, 0), Margin = new Padding(0, 0, 0, 10),
            Text = "Creates one scheduled task per collector under \\RoboMate\\MonCastle\\Engines\\. The tasks run with PowerShell 7 and keep monitoring "
                + "even when the console and this launcher are closed. Existing engines keep their interval and their on/off state.\n\n"
                + "Choose an account that can query your servers (WMI, AD, Hyper-V). Credentials saved with Set-MCCredential must be saved as that same account.",
        };
        layout.Controls.Add(intro, 0, 0); layout.SetColumnSpan(intro, 2);
        layout.Controls.Add(system, 0, 1); layout.SetColumnSpan(system, 2);
        layout.Controls.Add(account, 0, 2); layout.Controls.Add(user, 1, 2);
        layout.Controls.Add(new Label { Text = "Password:", AutoSize = true, Margin = new Padding(20, 6, 3, 3) }, 0, 3); layout.Controls.Add(pass, 1, 3);
        var buttons = new FlowLayoutPanel { FlowDirection = FlowDirection.RightToLeft, AutoSize = true, Dock = DockStyle.Fill, Margin = new Padding(0, 12, 0, 0) };
        var ok = new Button { Text = "Install", AutoSize = true };
        var cancel = new Button { Text = "Cancel", DialogResult = DialogResult.Cancel, AutoSize = true };
        ok.Click += (_, _) =>
        {
            if (account.Checked && (user.Text.Trim().Length == 0 || pass.Text.Length == 0)) { MessageBox.Show(this, "Enter the account and its password.", Text); return; }
            DialogResult = DialogResult.OK;
        };
        buttons.Controls.Add(cancel); buttons.Controls.Add(ok);
        layout.Controls.Add(buttons, 0, 4); layout.SetColumnSpan(buttons, 2);
        Controls.Add(layout);
        AcceptButton = ok;
        CancelButton = cancel;
        void Sync() { user.Enabled = pass.Enabled = account.Checked; }
        account.CheckedChanged += (_, _) => Sync();
        Sync();
    }
}
