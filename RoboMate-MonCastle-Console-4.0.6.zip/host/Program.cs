// RoboMate MonCastle launcher: a window that starts, watches and stops the Node.js console server.
// Any unexpected error is shown in a message box and written to data\logs\launcher.log, so the launcher never just vanishes.
namespace MonCastle.Launcher;

internal static class Program
{
    [STAThread]
    static void Main(string[] args)
    {
        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        Application.ThreadException += (_, e) => Crash(e.Exception);
        AppDomain.CurrentDomain.UnhandledException += (_, e) => Crash(e.ExceptionObject as Exception);
        ApplicationConfiguration.Initialize();
        try { Application.Run(new MainForm(args)); }
        catch (Exception e) { Crash(e); }
    }

    static void Crash(Exception? e)
    {
        var text = e?.ToString() ?? "Unknown error";
        try { Server.WriteLog("launcher error: " + text); } catch { }
        MessageBox.Show("The MonCastle launcher hit an error:\n\n" + (e?.Message ?? text) + "\n\nDetails are in data\\logs\\launcher.log.",
            "RoboMate MonCastle", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}
