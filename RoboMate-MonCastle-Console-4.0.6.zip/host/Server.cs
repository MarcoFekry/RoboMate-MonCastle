// Finds Node.js and the console folder, runs server\index.js, and reports output and state changes.
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text.Json;

namespace MonCastle.Launcher;

internal enum ServerState { Stopped, Starting, Running, External, Failed }

internal sealed class Server
{
    public const string PublicName = "robomatemoncastle";
    // status probes go to 127.0.0.1 only, so the console's own (self-signed) certificate is accepted for them
    static readonly HttpClient Http = new(new HttpClientHandler { ServerCertificateCustomValidationCallback = (m, c, ch, e) => m.RequestUri != null && m.RequestUri.IsLoopback }) { Timeout = TimeSpan.FromSeconds(2) };

    // HTTPS is on unless config\moncastle.config.json says "tls": { "enabled": false }
    public static bool Https
    {
        get
        {
            try
            {
                var f = Root == null ? null : Path.Combine(Root, "config", "moncastle.config.json");
                if (f == null || !File.Exists(f)) return true;
                using var d = JsonDocument.Parse(File.ReadAllText(f));
                return !(d.RootElement.TryGetProperty("tls", out var t) && t.ValueKind == JsonValueKind.Object && t.TryGetProperty("enabled", out var en) && en.ValueKind == JsonValueKind.False);
            }
            catch { return true; }
        }
    }
    public static string Scheme => Https ? "https" : "http";

    // the console's self-signed certificate (data\tls\moncastle.cer) and whether this machine trusts it
    public static (string? Thumbprint, bool Trusted) Certificate()
    {
        try
        {
            var f = Root == null ? null : Path.Combine(Root, "data", "tls", "moncastle.cer");
            if (f == null || !File.Exists(f)) return (null, false);
            using var cert = new System.Security.Cryptography.X509Certificates.X509Certificate2(File.ReadAllBytes(f));
            using var store = new System.Security.Cryptography.X509Certificates.X509Store(System.Security.Cryptography.X509Certificates.StoreName.Root, System.Security.Cryptography.X509Certificates.StoreLocation.LocalMachine);
            store.Open(System.Security.Cryptography.X509Certificates.OpenFlags.ReadOnly);
            return (cert.Thumbprint, store.Certificates.Find(System.Security.Cryptography.X509Certificates.X509FindType.FindByThumbprint, cert.Thumbprint, false).Count > 0);
        }
        catch { return (null, false); }
    }
    static StreamWriter? logFile;

    public static readonly string? Root = FindRoot();

    public event Action<string, bool>? Output;   // line, isError
    public event Action<ServerState, string>? StateChanged;

    Process? process;
    bool stopping;
    readonly Queue<string> lastErrors = new();

    public ServerState State { get; private set; } = ServerState.Stopped;
    public int Port { get; set; } = 5050;
    public bool Demo { get; set; }
    public string LocalUrl => $"{Scheme}://127.0.0.1:{Port}/";

    static Server()
    {
        if (Root == null) return;
        try
        {
            var dir = Path.Combine(Root, "data", "logs");
            Directory.CreateDirectory(dir);
            logFile = new StreamWriter(Path.Combine(dir, "launcher.log"), true) { AutoFlush = true };
        }
        catch { }
    }

    public static void WriteLog(string line)
    {
        lock (Http) { try { logFile?.WriteLine(DateTime.Now.ToString("s") + " " + line); } catch { } }
    }

    public static string Version()
    {
        try
        {
            using var doc = JsonDocument.Parse(File.ReadAllText(Path.Combine(Root!, "version.json")));
            return doc.RootElement.GetProperty("version").GetString() ?? "";
        }
        catch { return ""; }
    }

    // a source tree (server\index.js) or a user package from tools\build-release.js (moncastle.js + app.mcpak, no sources)
    static bool IsRoot(string dir) => File.Exists(Path.Combine(dir, "server", "index.js")) || (File.Exists(Path.Combine(dir, "moncastle.js")) && File.Exists(Path.Combine(dir, "app.mcpak")));
    public static bool Packaged => Root != null && !File.Exists(Path.Combine(Root, "server", "index.js"));

    static string? FindRoot()
    {
        var env = Environment.GetEnvironmentVariable("MC_ROOT");
        if (!string.IsNullOrEmpty(env) && IsRoot(env)) return Path.GetFullPath(env);
        for (var dir = new DirectoryInfo(AppContext.BaseDirectory); dir != null; dir = dir.Parent)
            if (IsRoot(dir.FullName)) return dir.FullName;
        return null;
    }

    // MC_NODE, then PATH (machine and user values are re-read, since Visual Studio keeps the PATH it started with), then the usual install folders
    public static string? FindNode()
    {
        var env = Environment.GetEnvironmentVariable("MC_NODE");
        if (!string.IsNullOrEmpty(env)) return File.Exists(env) ? env : null;
        // the user package carries its own Node.js runtime
        if (Root != null && File.Exists(Path.Combine(Root, "runtime", "node.exe"))) return Path.Combine(Root, "runtime", "node.exe");
        var paths = new List<string>();
        foreach (var target in new[] { EnvironmentVariableTarget.Process, EnvironmentVariableTarget.Machine, EnvironmentVariableTarget.User })
        {
            try { paths.AddRange((Environment.GetEnvironmentVariable("PATH", target) ?? "").Split(Path.PathSeparator)); } catch { }
        }
        paths.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "nodejs"));
        paths.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "nodejs"));
        paths.Add(Environment.GetEnvironmentVariable("NVM_SYMLINK") ?? "");
        foreach (var dir in paths)
        {
            if (string.IsNullOrWhiteSpace(dir)) continue;
            try
            {
                var f = Path.Combine(Environment.ExpandEnvironmentVariables(dir.Trim().Trim('"')), "node.exe");
                if (File.Exists(f)) return f;
            }
            catch { }
        }
        return null;
    }

    public static string? NodeVersion(string node)
    {
        try
        {
            using var p = Process.Start(new ProcessStartInfo(node, "--version") { UseShellExecute = false, RedirectStandardOutput = true, CreateNoWindow = true })!;
            var v = p.StandardOutput.ReadToEnd().Trim();
            return p.WaitForExit(10000) && v.StartsWith('v') ? v : null;
        }
        catch { return null; }
    }

    // body of /api/status, "other" when something else answers, or null when nothing answers
    public async Task<string?> StatusAsync()
    {
        try { return await Http.GetStringAsync(LocalUrl + "api/status"); }
        catch (HttpRequestException e) when (e.StatusCode != null) { return "other"; }
        catch { return null; }
    }

    static bool PortFree(int port)
    {
        try
        {
            var l = new TcpListener(IPAddress.Any, port);
            l.Start();
            l.Stop();
            return true;
        }
        catch { return false; }
    }

    public static async Task<bool> NameResolvesAsync()
    {
        try
        {
            var lookup = Dns.GetHostAddressesAsync(PublicName);
            return await Task.WhenAny(lookup, Task.Delay(3000)) == lookup && lookup.Result.Length > 0;
        }
        catch { return false; }
    }

    void Say(string line, bool error = false) { WriteLog(line); Output?.Invoke(line, error); }

    void Set(ServerState state, string detail)
    {
        State = state;
        if (detail.Length > 0) Say(detail, state == ServerState.Failed);
        StateChanged?.Invoke(state, detail);
    }

    public async Task StartAsync()
    {
        if (State is ServerState.Starting or ServerState.Running) return;
        if (Root == null) { Set(ServerState.Failed, "Could not find MonCastle (server\\index.js or moncastle.js + app.mcpak) above " + AppContext.BaseDirectory + ". Set MC_ROOT to the MonCastle folder."); return; }
        Set(ServerState.Starting, $"Starting MonCastle ({(Demo ? "demo" : "live")}) on port {Port} from {Root}");

        var node = FindNode();
        if (node == null)
        {
            Set(ServerState.Failed, "Node.js was not found. Install Node.js 18 or later from https://nodejs.org (LTS), then start the launcher again. "
                + "If it is installed in an unusual folder, set MC_NODE to the full path of node.exe.");
            return;
        }
        var version = await Task.Run(() => NodeVersion(node));
        Say($"Node.js: {node} ({version ?? "version unknown"})");
        if (version == null) { Set(ServerState.Failed, "Could not run " + node + " --version."); return; }
        if (int.TryParse(version.TrimStart('v').Split('.')[0], out var major) && major < 18) { Set(ServerState.Failed, $"Node.js {version} is too old. MonCastle needs Node.js 18 or later."); return; }

        var status = await StatusAsync();
        if (status != null)
        {
            if (status.Contains("MonCastle")) Set(ServerState.External, $"MonCastle is already running on port {Port}, started outside this launcher.");
            else Set(ServerState.Failed, $"Port {Port} is already used by another program. Stop it, or choose another port.");
            return;
        }
        if (!PortFree(Port))
        {
            Set(ServerState.Failed, $"Port {Port} cannot be opened. Another program may hold it, or Windows reserves it (check with: netsh interface ipv4 show excludedportrange protocol=tcp).");
            return;
        }

        var psi = new ProcessStartInfo(node)
        {
            WorkingDirectory = Root,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
        };
        psi.ArgumentList.Add(Packaged ? "moncastle.js" : Path.Combine("server", "index.js"));
        if (Demo) psi.ArgumentList.Add("--demo");
        psi.Environment["MC_PORT"] = Port.ToString();

        try { process = Process.Start(psi)!; }
        catch (Exception e) { Set(ServerState.Failed, "Could not start Node.js: " + e.Message); return; }
        stopping = false;
        lock (lastErrors) lastErrors.Clear();
        JobObject.Attach(process);
        process.EnableRaisingEvents = true;
        process.OutputDataReceived += (_, e) => { if (e.Data != null) Say(e.Data); };
        process.ErrorDataReceived += (_, e) =>
        {
            if (e.Data == null) return;
            Say(e.Data, true);
            lock (lastErrors) { lastErrors.Enqueue(e.Data); if (lastErrors.Count > 6) lastErrors.Dequeue(); }
        };
        process.Exited += (_, _) => OnExit();
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();

        var deadline = DateTime.UtcNow.AddSeconds(60);
        var me = process;
        while (me == process && !me.HasExited && DateTime.UtcNow < deadline)
        {
            if (await StatusAsync() != null) { Set(ServerState.Running, "The server is up."); return; }
            await Task.Delay(500);
        }
        if (me == process && !me.HasExited)
            Set(ServerState.Starting, $"The server has not answered on {LocalUrl} after 60 seconds. It is still running; check the lines above.");
    }

    void OnExit()
    {
        var p = process;
        if (p == null) return;
        try { p.WaitForExit(); } catch { }
        process = null;
        if (stopping) { Set(ServerState.Stopped, "The server stopped."); return; }
        string tail;
        lock (lastErrors) tail = string.Join(" | ", lastErrors);
        var code = 0;
        try { code = p.ExitCode; } catch { }
        Set(ServerState.Failed, $"The server stopped unexpectedly (exit code {code})." + (tail.Length > 0 ? " Last error: " + tail : ""));
    }

    public void Stop()
    {
        var p = process;
        if (p == null) { if (State == ServerState.External) Set(ServerState.Stopped, ""); return; }
        stopping = true;
        try { if (!p.HasExited) p.Kill(entireProcessTree: true); } catch { }
    }
}

// Kill-on-close job object: Node stops when the launcher ends, even if it is killed or Visual Studio stops debugging.
internal static class JobObject
{
    static IntPtr handle;

    public static void Attach(Process process)
    {
        try
        {
            if (handle == IntPtr.Zero)
            {
                handle = CreateJobObject(IntPtr.Zero, null);
                var info = new JOBOBJECT_EXTENDED_LIMIT_INFORMATION();
                info.BasicLimitInformation.LimitFlags = 0x2000; // JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
                var size = Marshal.SizeOf(info);
                var ptr = Marshal.AllocHGlobal(size);
                try
                {
                    Marshal.StructureToPtr(info, ptr, false);
                    SetInformationJobObject(handle, 9, ptr, (uint)size); // JobObjectExtendedLimitInformation
                }
                finally { Marshal.FreeHGlobal(ptr); }
            }
            AssignProcessToJobObject(handle, process.Handle);
        }
        catch { }
    }

    [StructLayout(LayoutKind.Sequential)]
    struct JOBOBJECT_BASIC_LIMIT_INFORMATION
    {
        public long PerProcessUserTimeLimit, PerJobUserTimeLimit;
        public uint LimitFlags;
        public UIntPtr MinimumWorkingSetSize, MaximumWorkingSetSize;
        public uint ActiveProcessLimit;
        public UIntPtr Affinity;
        public uint PriorityClass, SchedulingClass;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct IO_COUNTERS
    {
        public ulong ReadOperationCount, WriteOperationCount, OtherOperationCount, ReadTransferCount, WriteTransferCount, OtherTransferCount;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct JOBOBJECT_EXTENDED_LIMIT_INFORMATION
    {
        public JOBOBJECT_BASIC_LIMIT_INFORMATION BasicLimitInformation;
        public IO_COUNTERS IoInfo;
        public UIntPtr ProcessMemoryLimit, JobMemoryLimit, PeakProcessMemoryUsed, PeakJobMemoryUsed;
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
    static extern IntPtr CreateJobObject(IntPtr attributes, string? name);

    [DllImport("kernel32.dll")]
    static extern bool SetInformationJobObject(IntPtr job, int infoClass, IntPtr info, uint length);

    [DllImport("kernel32.dll")]
    static extern bool AssignProcessToJobObject(IntPtr job, IntPtr process);
}
