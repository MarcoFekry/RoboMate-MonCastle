// The launcher window: a navigation sidebar (Overview, Engines, Servers, Logs, Settings) beside the selected page.
// Overview shows the console server's state with start / stop / open, Engines the monitoring engines, Servers this
// server's place in the MonCastle infrastructure, Logs the live server output, Settings the launcher preferences.
// Light and dark follow Windows unless chosen in Settings; closing can hide the launcher to the notification area.
using System.ComponentModel;
using System.Diagnostics;
using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Win32;
using MonCastle.Ui;

namespace MonCastle.Launcher;

internal sealed class MainForm : Form
{
    readonly Server server = new();
    readonly Settings settings = Settings.Load();
    readonly Panel side = new() { Dock = DockStyle.Left, Width = 236 };
    readonly Panel pageHost = new() { Dock = DockStyle.Fill };
    readonly Dictionary<string, NavItem> nav = new();
    readonly Dictionary<string, Control> pages = new();
    readonly RichTextBox log = new() { Dock = DockStyle.Fill, ReadOnly = true, BorderStyle = BorderStyle.None, Font = new Font("Consolas", 9.5f), WordWrap = true, DetectUrls = false };
    readonly List<(string Line, bool Error)> lines = new();
    readonly System.Windows.Forms.Timer health = new() { Interval = 5000 };
    readonly NotifyIcon tray = new() { Text = "RoboMate MonCastle" };
    readonly string[] args;
    string current = "overview";
    bool resolves, exiting;
    string? nodePath, nodeVersion;
    DateTime? since;
    int errorsSinceView;

    // overview widgets, kept so state changes can update them in place
    readonly Pill statePill = new();
    readonly Label heroTitle = new() { AutoSize = true }, heroDetail = new() { AutoSize = true, Tag = "muted", MaximumSize = new Size(560, 0) };
    readonly LinkLabel urlLink = new() { AutoSize = true };
    readonly ModernButton startBtn = new("Start server", ButtonKind.Primary, Glyph.Play), stopBtn = new("Stop", ButtonKind.Secondary, Glyph.Stop), openBtn = new("Open console", ButtonKind.Secondary, Glyph.Globe);
    readonly Dictionary<string, Label> tiles = new();
    readonly TextBox logFilter = new() { Width = 260, PlaceholderText = "Filter the log" };

    public MainForm(string[] args)
    {
        this.args = args;
        if (args.Contains("--demo")) settings.Demo = true;
        Theme.Set(settings.ThemeMode);
        Text = "RoboMate MonCastle";
        try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
        tray.Icon = Icon ?? SystemIcons.Application;
        AutoScaleDimensions = new SizeF(96f, 96f);
        AutoScaleMode = AutoScaleMode.Dpi;
        Font = Theme.Body;
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(1120, 720);
        MinimumSize = new Size(880, 580);

        startBtn.Click += async (_, _) => await StartServer();
        stopBtn.Click += (_, _) => server.Stop();
        openBtn.Click += async (_, _) => await OpenConsole();
        urlLink.LinkClicked += async (_, _) => await OpenConsole();
        logFilter.TextChanged += (_, _) => RenderLog();

        BuildSide();
        Controls.Add(pageHost);
        Controls.Add(side);
        BuildTray();

        server.Port = settings.Port;
        server.Demo = settings.Demo;
        server.Output += (line, error) => Ui(() => Append(line, error));
        server.StateChanged += (state, detail) => Ui(() => OnState(state, detail));
        health.Tick += async (_, _) => await CheckHealth();
        Theme.Changed += () => Ui(Rebuild);

        Navigate(args.Contains("--engines") ? "engines" : "overview");
        OnState(ServerState.Stopped, "");
        Shown += async (_, _) =>
        {
            Theme.Frame(this);
            await RefreshEnvironment();
            // restarted as administrator from the engines page: give the previous launcher time to stop its server
            if (args.Contains("--engines")) await Task.Delay(3000);
            if (settings.AutoStart) await StartServer();
            if (args.Contains("--tray")) Hide();
        };
        FormClosing += (_, e) =>
        {
            if (!exiting && settings.MinimizeToTray && e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
                tray.ShowBalloonTip(3000, "RoboMate MonCastle", "MonCastle keeps running here. Right-click the icon to open or exit.", ToolTipIcon.Info);
                return;
            }
            settings.Save();
            server.Stop();
            tray.Visible = false;
        };
    }

    // ------------------------------------------------------------------ chrome
    void BuildSide()
    {
        side.Controls.Clear();
        nav.Clear();
        side.BackColor = Theme.Sidebar;
        var header = new Panel { Dock = DockStyle.Top, Height = 104 };
        header.Paint += (_, e) =>
        {
            var g = e.Graphics;
            g.Clear(Theme.Sidebar);
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            var png = Server.Root == null ? null : Path.Combine(Server.Root, "public", "img", "moncastle-180.png");
            try { if (png != null && File.Exists(png)) { using var img = Image.FromFile(png); g.DrawImage(img, 20, 22, 42, 42); } } catch { }
            TextRenderer.DrawText(g, "ROBOMATE", Theme.Small, new Point(72, 24), Theme.SidebarMuted);
            using var t = new Font("Segoe UI Semibold", 15f);
            TextRenderer.DrawText(g, "MonCastle", t, new Point(70, 38), Color.White);
            var v = Server.Version();
            TextRenderer.DrawText(g, "Launcher" + (v.Length > 0 ? " · " + v : ""), Theme.Small, new Point(22, 76), Theme.SidebarMuted);
        };
        var list = new Panel { Dock = DockStyle.Fill, Padding = new Padding(0, 6, 0, 0), BackColor = Theme.Sidebar };
        foreach (var (id, icon, text) in new[] { ("settings", Glyph.Settings, "Settings"), ("logs", Glyph.Logs, "Server log"), ("servers", Glyph.Servers, "MonCastle servers"), ("engines", Glyph.Engines, "Monitoring engines"), ("overview", Glyph.Home, "Overview") })
        {
            var n = new NavItem(icon, text);
            n.Click += (_, _) => Navigate(id);
            nav[id] = n;
            list.Controls.Add(n);
        }
        var themeBtn = new NavItem(Theme.Dark ? Glyph.Sun : Glyph.Moon, Theme.Dark ? "Light mode" : "Dark mode") { Dock = DockStyle.Bottom };
        themeBtn.Click += (_, _) => { settings.ThemeMode = Theme.Dark ? ThemeMode.Light : ThemeMode.Dark; settings.Save(); Theme.Set(settings.ThemeMode); };
        var consoleBtn = new NavItem(Glyph.Open, "Open console") { Dock = DockStyle.Bottom };
        consoleBtn.Click += async (_, _) => await OpenConsole();
        side.Controls.Add(list);
        side.Controls.Add(consoleBtn);
        side.Controls.Add(themeBtn);
        side.Controls.Add(header);
        if (nav.TryGetValue(current, out var sel)) sel.Selected = true;
    }

    void BuildTray()
    {
        var menu = new ContextMenuStrip();
        menu.Items.Add("Open MonCastle launcher", null, (_, _) => ShowWindow());
        menu.Items.Add("Open the console", null, async (_, _) => await OpenConsole());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Start server", null, async (_, _) => await StartServer());
        menu.Items.Add("Stop server", null, (_, _) => server.Stop());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Exit", null, (_, _) => { exiting = true; Close(); });
        tray.ContextMenuStrip = menu;
        tray.DoubleClick += (_, _) => ShowWindow();
        tray.Visible = true;
    }

    void ShowWindow() { Show(); if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal; Activate(); }

    void Rebuild()
    {
        Theme.Frame(this);
        BuildSide();
        foreach (var p in pages.Values) p.Dispose();
        pages.Clear();
        Navigate(current);
        OnState(server.State, "");
        RefreshTiles();
    }

    void Navigate(string id)
    {
        current = id;
        foreach (var (k, n) in nav) n.Selected = k == id;
        if (id == "logs") { errorsSinceView = 0; nav["logs"].Badge = null; }
        if (!pages.TryGetValue(id, out var page))
        {
            page = id switch { "engines" => EnginesPage(), "servers" => ServersPage(), "logs" => LogsPage(), "settings" => SettingsPage(), _ => OverviewPage() };
            pages[id] = page;
        }
        pageHost.Controls.Clear();
        pageHost.BackColor = Theme.Page;
        pageHost.Controls.Add(page);
        Restyle.Apply(page);
        if (id == "servers") _ = RefreshServers();
        if (id == "logs") RenderLog();
    }

    Panel PageFrame(string title, string subtitle, out FlowLayoutPanel stack)
    {
        var scroller = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(28, 22, 28, 16), BackColor = Theme.Page };
        stack = new FlowLayoutPanel { FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoSize = true, Dock = DockStyle.Top };
        stack.Controls.Add(new Label { Text = title, Font = Theme.Title, AutoSize = true, Margin = new Padding(0, 0, 0, 2) });
        stack.Controls.Add(new Label { Text = subtitle, AutoSize = true, Tag = "muted", Margin = new Padding(0, 0, 0, 14), MaximumSize = new Size(780, 0) });
        scroller.Controls.Add(stack);
        return scroller;
    }

    static Card CardOf(int width, params Control[] children)
    {
        var card = new Card { AutoSize = true, MinimumSize = new Size(width, 0) };
        var flow = new FlowLayoutPanel { FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoSize = true, Dock = DockStyle.Fill };
        flow.Controls.AddRange(children);
        card.Controls.Add(flow);
        return card;
    }
    static FlowLayoutPanel Row(params Control[] children)
    {
        var f = new FlowLayoutPanel { FlowDirection = FlowDirection.LeftToRight, AutoSize = true, WrapContents = true, Margin = new Padding(0) };
        f.Controls.AddRange(children);
        return f;
    }

    // ------------------------------------------------------------------ pages
    Control OverviewPage()
    {
        var frame = PageFrame("Overview", "The MonCastle console server on this computer.", out var stack);
        heroTitle.Font = new Font("Segoe UI Semibold", 15f);
        urlLink.Font = new Font("Segoe UI Semibold", 11f);
        statePill.Margin = new Padding(0, 0, 0, 8);
        heroTitle.Margin = new Padding(0, 0, 0, 2);
        heroDetail.Margin = new Padding(0, 0, 0, 8);
        urlLink.Margin = new Padding(0, 0, 0, 12);
        stack.Controls.Add(CardOf(760, statePill, heroTitle, heroDetail, urlLink, Row(startBtn, stopBtn, openBtn)));

        var grid = new FlowLayoutPanel { AutoSize = true, WrapContents = true, MaximumSize = new Size(800, 0), Margin = new Padding(0) };
        foreach (var (key, caption) in new[] { ("mode", "Mode"), ("port", "Port"), ("node", "Node.js runtime"), ("address", "Address"), ("uptime", "Running for"), ("package", "Installation") })
        {
            var value = new Label { AutoSize = true, Font = Theme.Heading, MaximumSize = new Size(220, 0) };
            tiles[key] = value;
            var c = CardOf(240, new Caption(caption) { Margin = new Padding(0, 0, 0, 4) }, value);
            c.Margin = new Padding(0, 0, 12, 12);
            c.MaximumSize = new Size(240, 0);
            grid.Controls.Add(c);
        }
        stack.Controls.Add(grid);

        var hostsBtn = new ModernButton("Add robomatemoncastle to hosts", ButtonKind.Secondary, Glyph.Globe);
        hostsBtn.Click += async (_, _) => await AddHostsEntry();
        var logsBtn = new ModernButton("Open logs folder", ButtonKind.Secondary, Glyph.Folder);
        logsBtn.Click += (_, _) => OpenFolder("data", "logs");
        var setupBtn = new ModernButton("Run setup (prerequisites, service)", ButtonKind.Secondary, Glyph.Package);
        setupBtn.Click += (_, _) => RunSetup();
        stack.Controls.Add(CardOf(760, new Label { Text = "Quick actions", Font = Theme.Heading, AutoSize = true, Margin = new Padding(0, 0, 0, 8) }, Row(hostsBtn, logsBtn, setupBtn)));
        RefreshTiles();
        return frame;
    }

    Control EnginesPage()
    {
        var host = new Panel { Dock = DockStyle.Fill, Padding = new Padding(10, 8, 10, 8), BackColor = Theme.Page };
        host.Controls.Add(new EnginesPanel());
        return host;
    }

    readonly Label srvRole = new() { AutoSize = true }, srvDetail = new() { AutoSize = true, Tag = "muted", MaximumSize = new Size(700, 0) };
    Control ServersPage()
    {
        var frame = PageFrame("MonCastle servers", "One console can manage several MonCastle servers; each remote server monitors the devices the central console assigns to it.", out var stack);
        srvRole.Font = Theme.Heading;
        var openSrv = new ModernButton("Open MonCastle servers in the console", ButtonKind.Primary, Glyph.Servers);
        openSrv.Click += async (_, _) => await OpenConsole("#/servers");
        var joinBtn = new ModernButton("Join a central console…", ButtonKind.Secondary, Glyph.Key);
        joinBtn.Click += async (_, _) => await Join();
        var leaveBtn = new ModernButton("Leave (stand-alone again)", ButtonKind.Ghost);
        leaveBtn.Click += async (_, _) => await LeaveInfra();
        stack.Controls.Add(CardOf(760, new Caption("This server"), srvRole, srvDetail, Row(openSrv, joinBtn, leaveBtn)));
        stack.Controls.Add(CardOf(760, new Label { Text = "How it fits together", Font = Theme.Heading, AutoSize = true },
            new Label { AutoSize = true, Tag = "muted", MaximumSize = new Size(700, 0), Text =
                "1. On the central console open Monitor > MonCastle servers > Add MonCastle server and copy the one-time join code.\n" +
                "2. Install MonCastle on the remote server (MonCastle-Setup.exe) and paste the code there, or use Join a central console here.\n" +
                "3. The remote server checks in every 30 seconds with its CPU, memory and disk. Choose it as \"Monitored by\" when you add devices.\n" +
                "Traffic is HTTPS-ready, signed with a per-server secret, and credentials travel sealed." }));
        return frame;
    }

    Control LogsPage()
    {
        var wrap = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(28, 22, 28, 16), RowCount = 3, ColumnCount = 1, BackColor = Theme.Page };
        wrap.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        wrap.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        wrap.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        wrap.Controls.Add(new Label { Text = "Server log", Font = Theme.Title, AutoSize = true }, 0, 0);
        var copy = new ModernButton("Copy", ButtonKind.Secondary, Glyph.Copy);
        copy.Click += (_, _) => { if (log.TextLength > 0) Clipboard.SetText(log.Text); };
        var clear = new ModernButton("Clear", ButtonKind.Ghost);
        clear.Click += (_, _) => { lines.Clear(); RenderLog(); };
        var folder = new ModernButton("Logs folder", ButtonKind.Secondary, Glyph.Folder);
        folder.Click += (_, _) => OpenFolder("data", "logs");
        logFilter.Margin = new Padding(0, 4, 12, 8);
        wrap.Controls.Add(Row(logFilter, copy, clear, folder), 0, 1);
        var frame = new Panel { Dock = DockStyle.Fill, Padding = new Padding(12), BackColor = Theme.Console, Tag = "keep" };
        log.BackColor = Theme.Console;
        log.ForeColor = Color.FromArgb(0xD6, 0xE2, 0xF0);
        frame.Controls.Add(log);
        wrap.Controls.Add(frame, 0, 2);
        return wrap;
    }

    Control SettingsPage()
    {
        var frame = PageFrame("Settings", "Launcher preferences for this Windows user.", out var stack);
        var mode = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 260 };
        mode.Items.AddRange(new object[] { "Live (runs the scripts)", "Demo (sample data)" });
        mode.SelectedIndex = settings.Demo ? 1 : 0;
        mode.SelectedIndexChanged += (_, _) => { settings.Demo = server.Demo = mode.SelectedIndex == 1; settings.Save(); RefreshTiles(); };
        var port = new NumericUpDown { Minimum = 1, Maximum = 65535, Value = Math.Clamp(settings.Port, 1, 65535), Width = 110 };
        port.ValueChanged += (_, _) => { settings.Port = server.Port = (int)port.Value; settings.Save(); RefreshTiles(); };
        var running = server.State is ServerState.Running or ServerState.Starting;
        mode.Enabled = port.Enabled = !running;
        var theme = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 260 };
        theme.Items.AddRange(new object[] { "Follow Windows", "Light", "Dark" });
        theme.SelectedIndex = (int)settings.ThemeMode;
        theme.SelectedIndexChanged += (_, _) => { settings.ThemeMode = (ThemeMode)theme.SelectedIndex; settings.Save(); Theme.Set(settings.ThemeMode); };
        ToggleSwitch Toggle(string text, bool value, Action<bool> set) { var t = new ToggleSwitch(text) { Checked = value }; t.CheckedChanged += (_, _) => { set(t.Checked); settings.Save(); }; return t; }
        stack.Controls.Add(CardOf(760, new Label { Text = "Console server", Font = Theme.Heading, AutoSize = true },
            new Caption("Mode"), mode, new Caption("Port"), port,
            new Label { Text = running ? "Stop the server to change the mode or port." : "Used the next time the server starts.", AutoSize = true, Tag = "muted", Margin = new Padding(0, 6, 0, 0) }));
        stack.Controls.Add(CardOf(760, new Label { Text = "Behaviour", Font = Theme.Heading, AutoSize = true, Margin = new Padding(0, 0, 0, 6) },
            Toggle("Start the server when the launcher opens", settings.AutoStart, v => settings.AutoStart = v),
            Toggle("Open the console in the browser when the server is up", settings.OpenBrowser, v => settings.OpenBrowser = v),
            Toggle("Keep running in the notification area when the window is closed", settings.MinimizeToTray, v => settings.MinimizeToTray = v),
            Toggle("Start the launcher when I sign in to Windows", StartWithWindows, v => StartWithWindows = v)));
        stack.Controls.Add(CardOf(760, new Label { Text = "Appearance", Font = Theme.Heading, AutoSize = true }, new Caption("Theme"), theme));
        return frame;
    }

    // ------------------------------------------------------------------ behaviour
    void Ui(Action a)
    {
        if (IsDisposed) return;
        if (InvokeRequired) { try { BeginInvoke(a); } catch (InvalidOperationException) { } }
        else a();
    }

    void Append(string line, bool error)
    {
        lines.Add((line, error));
        if (lines.Count > 5000) lines.RemoveRange(0, 1000);
        if (error && current != "logs") { errorsSinceView++; nav["logs"].Badge = errorsSinceView > 99 ? "99+" : errorsSinceView.ToString(); }
        if (current == "logs" && Matches(line)) WriteLine(line, error);
    }
    bool Matches(string line) => logFilter.Text.Length == 0 || line.Contains(logFilter.Text, StringComparison.OrdinalIgnoreCase);
    void WriteLine(string line, bool error)
    {
        log.SelectionStart = log.TextLength;
        log.SelectionColor = error ? Color.FromArgb(0xFF, 0x8A, 0x8A) : log.ForeColor;
        log.AppendText(line + Environment.NewLine);
        log.ScrollToCaret();
    }
    void RenderLog()
    {
        log.Clear();
        foreach (var (l, e) in lines) if (Matches(l)) WriteLine(l, e);
    }

    void OnState(ServerState state, string detail)
    {
        (statePill.Color, statePill.Text, heroTitle.Text) = state switch
        {
            ServerState.Starting => (Theme.Warn, "Starting", "The console is starting"),
            ServerState.Running => (Theme.Good, "Running", "The console is running"),
            ServerState.External => (Theme.Teal, "Running elsewhere", "The console runs outside this launcher"),
            ServerState.Failed => (Theme.Bad, "Needs attention", "The console is not running"),
            _ => (Theme.Idle, "Stopped", "The console is stopped"),
        };
        heroDetail.Text = detail.Length > 0 ? detail : state switch
        {
            ServerState.Running => $"{(server.Demo ? "Demo" : "Live")} mode on port {server.Port}. Sign in with your licence in the browser.",
            ServerState.External => "Another process (for example the MonCastle service) serves the console on this port.",
            ServerState.Stopped => "Press Start server to launch the console.",
            _ => heroDetail.Text,
        };
        if (state == ServerState.Running && since == null) since = DateTime.Now;
        if (state is ServerState.Stopped or ServerState.Failed) since = null;
        var up = state is ServerState.Running or ServerState.External;
        startBtn.Enabled = state is ServerState.Stopped or ServerState.Failed;
        stopBtn.Enabled = state is ServerState.Starting or ServerState.Running;
        openBtn.Enabled = up;
        health.Enabled = state == ServerState.Running;
        tray.Text = "RoboMate MonCastle: " + statePill.Text;
        nav["overview"].Badge = state == ServerState.Failed ? "!" : null;
        UpdateUrl();
        RefreshTiles();
        foreach (var c in new Control[] { statePill, startBtn, stopBtn, openBtn }) c.Invalidate();
        if (state == ServerState.Running && settings.OpenBrowser) _ = OpenConsole();
    }

    void RefreshTiles()
    {
        void Set(string k, string v, Color? c = null) { if (tiles.TryGetValue(k, out var l)) { l.Text = v; l.ForeColor = c ?? Theme.Ink; } }
        Set("mode", server.Demo ? "Demo (sample data)" : "Live");
        Set("port", server.Port.ToString());
        Set("node", nodePath == null ? "Not found" : nodeVersion ?? "…", nodePath == null ? Theme.Bad : null);
        Set("address", resolves ? Server.PublicName : Server.PublicName + " (name not set up yet)", resolves ? null : Theme.Warn);
        Set("uptime", since == null ? "–" : Since(DateTime.Now - since.Value));
        Set("package", Server.Packaged ? "User package" : "Source tree");
    }
    static string Since(TimeSpan t) => t.TotalDays >= 1 ? $"{(int)t.TotalDays} d {t.Hours} h" : t.TotalHours >= 1 ? $"{(int)t.TotalHours} h {t.Minutes} min" : $"{Math.Max(1, t.Minutes)} min";

    async Task StartServer()
    {
        lines.Clear();
        if (current == "logs") RenderLog();
        await server.StartAsync();
    }

    async Task CheckHealth()
    {
        RefreshTiles();
        if (server.State != ServerState.Running) return;
        heroDetail.Text = await server.StatusAsync() == null
            ? $"The server is running but did not answer on port {server.Port}. See the server log."
            : $"{(server.Demo ? "Demo" : "Live")} mode on port {server.Port}. Sign in with your licence in the browser.";
    }

    async Task RefreshEnvironment()
    {
        nodePath = await Task.Run(Server.FindNode);
        nodeVersion = nodePath == null ? null : await Task.Run(() => Server.NodeVersion(nodePath));
        resolves = await Server.NameResolvesAsync();
        UpdateUrl();
        RefreshTiles();
    }

    // The console is always reached by its RoboMate MonCastle name. Until the hosts entry exists the launcher uses
    // robomatemoncastle.localhost, which Edge and Chrome resolve to this PC by themselves.
    string ConsoleUrl => $"{Server.Scheme}://{(resolves ? Server.PublicName : Server.PublicName + ".localhost")}:{server.Port}/";
    void UpdateUrl() => urlLink.Text = ConsoleUrl.TrimEnd('/');

    async Task OpenConsole(string hash = "")
    {
        resolves = await Server.NameResolvesAsync();
        if (!resolves && !settings.HostsOffered)
        {
            settings.HostsOffered = true; settings.Save();
            if (MessageBox.Show(this, "Open the console as " + Server.Scheme + "://" + Server.PublicName + ":" + server.Port + "?\n\nWindows needs a hosts entry for that name, which asks for administrator approval once.",
                    "RoboMate MonCastle", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                await AddHostsEntry();
        }
        if (Server.Https) await TrustCertificate();
        UpdateUrl();
        var url = ConsoleUrl + hash;
        // the user's default browser, as a normal tab
        try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); }
        catch (Exception e) { Append("Could not open the browser (" + e.Message + "). Open " + ConsoleUrl + " yourself.", true); }
    }

    // HTTPS: trust the console's self-signed certificate in Local Machine > Trusted Root (administrator approval, asked once
    // per certificate) so the browser shows a normal padlock. Runs launcher\Trust-MonCastleCertificate.ps1.
    async Task TrustCertificate()
    {
        var (thumb, trusted) = Server.Certificate();
        if (thumb == null || trusted || settings.CertOffered == thumb) return;
        settings.CertOffered = thumb; settings.Save();
        if (MessageBox.Show(this, "Trust the console's HTTPS certificate on this computer?\n\nThe browser then opens " + ConsoleUrl + " without a security warning. Windows asks for administrator approval once.",
                "RoboMate MonCastle", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        try
        {
            var script = Path.Combine(Server.Root!, "launcher", "Trust-MonCastleCertificate.ps1");
            var psi = new ProcessStartInfo("powershell.exe")
            {
                UseShellExecute = true, Verb = "runas", WindowStyle = ProcessWindowStyle.Hidden,
                Arguments = $"-NoProfile -ExecutionPolicy Bypass -File \"{script}\" -InstallDir \"{Server.Root}\"",
            };
            using var p = Process.Start(psi)!;
            await p.WaitForExitAsync();
            Append(Server.Certificate().Trusted ? "The HTTPS certificate is trusted on this computer." : "The HTTPS certificate could not be trusted (exit code " + p.ExitCode + "). Run launcher\\Trust-MonCastleCertificate.ps1 as administrator.", !Server.Certificate().Trusted);
        }
        catch (Win32Exception) { Append("The certificate was not trusted: administrator approval was cancelled. The browser will show a warning.", true); }
    }

    async Task AddHostsEntry()
    {
        var hosts = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "drivers", "etc", "hosts");
        try
        {
            if (File.ReadAllText(hosts).Contains(Server.PublicName, StringComparison.OrdinalIgnoreCase))
            {
                Append("The hosts file already has a robomatemoncastle entry. If the name still does not resolve, check that the line is not commented out.", false);
                await RefreshEnvironment();
                return;
            }
        }
        catch { }
        try
        {
            var psi = new ProcessStartInfo("powershell.exe")
            {
                UseShellExecute = true, Verb = "runas", WindowStyle = ProcessWindowStyle.Hidden,
                Arguments = $"-NoProfile -Command \"Add-Content -Path '{hosts}' -Value \\\"`r`n127.0.0.1 {Server.PublicName}`t# RoboMate MonCastle console\\\" -Encoding ascii\"",
            };
            using var p = Process.Start(psi)!;
            await p.WaitForExitAsync();
            Append(p.ExitCode == 0 ? "Added 127.0.0.1 robomatemoncastle to the hosts file." : "Could not update the hosts file (exit code " + p.ExitCode + ").", p.ExitCode != 0);
        }
        catch (Win32Exception) { Append("The hosts file was not changed: administrator approval was cancelled.", true); }
        await RefreshEnvironment();
    }

    void OpenFolder(params string[] parts)
    {
        if (Server.Root == null) return;
        var dir = Path.Combine(new[] { Server.Root }.Concat(parts).ToArray());
        Directory.CreateDirectory(dir);
        Process.Start(new ProcessStartInfo(dir) { UseShellExecute = true });
    }

    void RunSetup()
    {
        var exe = Server.Root == null ? null : Path.Combine(Server.Root, "MonCastle-Setup.exe");
        if (exe == null || !File.Exists(exe)) { MessageBox.Show(this, "MonCastle-Setup.exe is part of the user package (Build > Publish > UserPackage). In the source tree run launcher\\Install-MonCastle.ps1 instead.", Text); return; }
        try { Process.Start(new ProcessStartInfo(exe) { UseShellExecute = true }); } catch (Win32Exception) { }
    }

    // ------------------------------------------------------------------ MonCastle infrastructure
    async Task RefreshServers()
    {
        var cfg = ReadConfig();
        var role = cfg?["infra"]?["role"]?.GetValue<string>();
        var central = cfg?["infra"]?["central"]?.GetValue<string>();
        srvRole.Text = role == "remote" ? "Remote MonCastle server" : "Central console (or stand-alone)";
        srvDetail.Text = role == "remote"
            ? $"Reports to {central ?? "the central console"}. The devices it monitors are assigned on the central console."
            : "Remote MonCastle servers that joined this console appear on its MonCastle servers page with their utilisation.";
        if (server.State is ServerState.Running or ServerState.External)
        {
            var status = await server.StatusAsync();
            if (status != null && status != "other")
                try { var j = JsonNode.Parse(status); if (j?["infra"]?["servers"] is JsonValue n) srvDetail.Text += $" {n} server(s) in this installation."; } catch { }
        }
    }

    static JsonNode? ReadConfig()
    {
        try { return Server.Root == null ? null : JsonNode.Parse(File.ReadAllText(Path.Combine(Server.Root, "config", "moncastle.config.json"))); }
        catch { return null; }
    }

    async Task Join()
    {
        var code = Prompt.Secret(this, "Join a central console", "Paste the one-time join code from the central console (Monitor > MonCastle servers > Add MonCastle server). It is handed to MonCastle in memory and never written to a log.", "MCJ1.");
        if (string.IsNullOrWhiteSpace(code)) return;
        if (!System.Text.RegularExpressions.Regex.IsMatch(code.Trim(), @"^MCJ1\.[A-Za-z0-9_-]+$")) { MessageBox.Show(this, "That is not a MonCastle join code.", Text); return; }
        var node = Server.FindNode();
        if (node == null || Server.Root == null) { MessageBox.Show(this, "Node.js was not found.", Text); return; }
        var psi = new ProcessStartInfo(node) { WorkingDirectory = Server.Root, UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true };
        psi.ArgumentList.Add(Server.Packaged ? "moncastle.js" : Path.Combine("server", "index.js"));
        psi.Environment["MC_JOIN"] = code.Trim();
        using var p = Process.Start(psi)!;
        var output = await p.StandardOutput.ReadToEndAsync() + await p.StandardError.ReadToEndAsync();
        await p.WaitForExitAsync();
        Append(output.Trim(), p.ExitCode != 0);
        MessageBox.Show(this, p.ExitCode == 0 ? "Joined. Restart the server to run as a remote MonCastle server." : "Joining failed:\n\n" + output.Trim(), Text, MessageBoxButtons.OK, p.ExitCode == 0 ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        await RefreshServers();
    }

    async Task LeaveInfra()
    {
        var file = Server.Root == null ? null : Path.Combine(Server.Root, "config", "moncastle.config.json");
        var cfg = ReadConfig() as JsonObject;
        if (file == null || cfg == null || cfg["infra"] == null) { MessageBox.Show(this, "This server is not joined to a central console.", Text); return; }
        if (MessageBox.Show(this, "Turn this server back into a stand-alone console? Remove it on the central console too.", Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
        cfg.Remove("infra");
        await File.WriteAllTextAsync(file, cfg.ToJsonString(new JsonSerializerOptions { WriteIndented = true }));
        await RefreshServers();
    }

    // ------------------------------------------------------------------ start with Windows (per user)
    static bool StartWithWindows
    {
        get { try { return Registry.GetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run", "RoboMate MonCastle", null) != null; } catch { return false; } }
        set
        {
            try
            {
                using var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true);
                if (value) k?.SetValue("RoboMate MonCastle", $"\"{Application.ExecutablePath}\" --tray");
                else k?.DeleteValue("RoboMate MonCastle", false);
            }
            catch { }
        }
    }
}

// A small dialog that asks for one secret value without showing it.
internal static class Prompt
{
    public static string? Secret(IWin32Window owner, string title, string text, string placeholder)
    {
        using var f = new Form { Text = title, FormBorderStyle = FormBorderStyle.FixedDialog, MinimizeBox = false, MaximizeBox = false, StartPosition = FormStartPosition.CenterParent, ClientSize = new Size(520, 190), BackColor = Theme.Page, Font = Theme.Body };
        var label = new Label { Text = text, AutoSize = false, Bounds = new Rectangle(18, 14, 484, 60), ForeColor = Theme.Ink };
        var box = new TextBox { Bounds = new Rectangle(18, 84, 484, 28), UseSystemPasswordChar = true, PlaceholderText = placeholder, BackColor = Theme.Surface2, ForeColor = Theme.Ink };
        var ok = new ModernButton("Join", ButtonKind.Primary) { DialogResult = DialogResult.OK, Location = new Point(404, 134) };
        var cancel = new ModernButton("Cancel", ButtonKind.Secondary) { DialogResult = DialogResult.Cancel, Location = new Point(304, 134) };
        f.Controls.AddRange(new Control[] { label, box, ok, cancel });
        f.AcceptButton = ok;
        f.CancelButton = cancel;
        Theme.Frame(f);
        var r = f.ShowDialog(owner) == DialogResult.OK ? box.Text : null;
        box.Text = "";
        return r;
    }
}

// Launcher preferences, kept per user in %LOCALAPPDATA%\RoboMate\MonCastle\launcher.json
internal sealed class Settings
{
    public bool Demo { get; set; }
    public int Port { get; set; } = 5050;
    public bool OpenBrowser { get; set; } = true;
    public bool AutoStart { get; set; } = true;
    public bool MinimizeToTray { get; set; } = true;
    public ThemeMode ThemeMode { get; set; } = ThemeMode.System;
    public bool HostsOffered { get; set; }
    public string? CertOffered { get; set; }

    static string File => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "RoboMate", "MonCastle", "launcher.json");

    public static Settings Load()
    {
        try { return JsonSerializer.Deserialize<Settings>(System.IO.File.ReadAllText(File)) ?? new Settings(); }
        catch { return new Settings(); }
    }

    public void Save()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(File)!);
            System.IO.File.WriteAllText(File, JsonSerializer.Serialize(this));
        }
        catch { }
    }
}
