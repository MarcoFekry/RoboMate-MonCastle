// Talks to engine\MonCastle-Engines.ps1, which manages the monitoring engines (one scheduled task per collector
// under \RoboMate\MonCastle\Engines\).
using System.Diagnostics;
using System.Security.Principal;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace MonCastle.Launcher;

internal sealed class EngineRow
{
    [JsonPropertyName("id")] public string Id { get; set; } = "";
    [JsonPropertyName("title")] public string? Title { get; set; }
    [JsonPropertyName("category")] public string? Category { get; set; }
    [JsonPropertyName("schedule")] public string? Schedule { get; set; }
    [JsonPropertyName("installed")] public bool Installed { get; set; }
    [JsonPropertyName("state")] public string? State { get; set; }
    [JsonPropertyName("every")] public string? Every { get; set; }
    [JsonPropertyName("runAs")] public string? RunAs { get; set; }
    [JsonPropertyName("lastRun")] public DateTime? LastRun { get; set; }
    [JsonPropertyName("nextRun")] public DateTime? NextRun { get; set; }
    [JsonPropertyName("lastStatus")] public string? LastStatus { get; set; }
    [JsonPropertyName("message")] public string? Message { get; set; }
}

internal sealed class EngineAnswer
{
    [JsonPropertyName("ok")] public bool Ok { get; set; }
    [JsonPropertyName("error")] public string? Error { get; set; }
    [JsonPropertyName("admin")] public bool Admin { get; set; }
    [JsonPropertyName("taskPath")] public string? TaskPath { get; set; }
    [JsonPropertyName("changed")] public List<string>? Changed { get; set; }
    [JsonPropertyName("engines")] public List<EngineRow>? Engines { get; set; }
}

internal static class Engines
{
    public static bool IsAdmin
    {
        get
        {
            try { return new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator); }
            catch { return false; }
        }
    }

    public static string? FindPwsh()
    {
        var paths = new List<string>();
        foreach (var target in new[] { EnvironmentVariableTarget.Process, EnvironmentVariableTarget.Machine, EnvironmentVariableTarget.User })
        {
            try { paths.AddRange((Environment.GetEnvironmentVariable("PATH", target) ?? "").Split(Path.PathSeparator)); } catch { }
        }
        paths.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "PowerShell", "7"));
        foreach (var dir in paths)
        {
            if (string.IsNullOrWhiteSpace(dir)) continue;
            try
            {
                var f = Path.Combine(Environment.ExpandEnvironmentVariables(dir.Trim().Trim('"')), "pwsh.exe");
                if (File.Exists(f)) return f;
            }
            catch { }
        }
        return null;
    }

    // action: List, Install, Uninstall, Enable, Disable, Start, Stop, Restart, SetInterval
    public static async Task<EngineAnswer> RunAsync(string action, string id = "All", string? every = null, string? user = null, string? password = null)
    {
        if (Server.Root == null) return new EngineAnswer { Error = "Could not find the MonCastle folder." };
        var pwsh = FindPwsh();
        if (pwsh == null) return new EngineAnswer { Error = "PowerShell 7 (pwsh.exe) was not found. Install it from https://aka.ms/powershell; the engines run on it." };
        var psi = new ProcessStartInfo(pwsh)
        {
            WorkingDirectory = Server.Root, UseShellExecute = false, CreateNoWindow = true,
            RedirectStandardOutput = true, RedirectStandardError = true,
        };
        foreach (var a in new[] { "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", Path.Combine(Server.Root, "engine", "MonCastle-Engines.ps1"), "-Action", action, "-Id", id })
            psi.ArgumentList.Add(a);
        if (every != null) { psi.ArgumentList.Add("-Every"); psi.ArgumentList.Add(every); }
        if (user != null) { psi.ArgumentList.Add("-User"); psi.ArgumentList.Add(user); }
        if (password != null) psi.Environment["MC_ENGINE_PASSWORD"] = password; // never on the command line
        try
        {
            using var p = Process.Start(psi)!;
            var outTask = p.StandardOutput.ReadToEndAsync();
            var errTask = p.StandardError.ReadToEndAsync();
            await p.WaitForExitAsync();
            var output = await outTask;
            var err = await errTask;
            const string begin = "##MC-ENGINES-BEGIN##", end = "##MC-ENGINES-END##";
            int a = output.LastIndexOf(begin), b = output.LastIndexOf(end);
            if (a < 0 || b < a) return new EngineAnswer { Error = "Engine control gave no answer. " + (err.Length > 0 ? err : output).Trim() };
            return JsonSerializer.Deserialize<EngineAnswer>(output.Substring(a + begin.Length, b - a - begin.Length)) ?? new EngineAnswer { Error = "Empty answer." };
        }
        catch (Exception e) { return new EngineAnswer { Error = "Could not run PowerShell: " + e.Message }; }
    }
}
